/* NGÂN HÀNG MĨ THUẬT – LỚP 2–9 — bù câu đặc thù theo lớp. Câu hỏi nguyên bản, bám SGK Kết nối tri thức. */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Mĩ thuật';
 /* Bảo đảm chủ đề tồn tại đúng tên (tránh khớp mờ chuỗi con, ví dụ "(Bổ sung) Màu sắc và bố cục") */
 function pre(lop,cd){
  if(!NH[M])NH[M]={};
  if(!Array.isArray(NH[M][lop]))NH[M][lop]=[];
  if(!NH[M][lop].some(function(x){return x.cd===cd;}))NH[M][lop].push({cd:cd,q:[]});
 }
 [7,8,9].forEach(function(l){pre(l,'Kiến thức tạo hình');pre(l,'Thường thức mĩ thuật');pre(l,'Yếu tố và nguyên lí tạo hình');pre(l,'Thưởng thức và ứng dụng');pre(l,'(Bổ sung) Màu sắc và bố cục');});

 /* ===== LỚP 2 ===== */
 add(M,2,'Đồ dùng và sản phẩm mĩ thuật',[
  [1,'Khi làm sản phẩm từ vỏ hộp sữa, nắp chai, ống hút đã dùng, em nên làm gì với vật liệu trước khi tạo hình?','Rửa sạch, để khô rồi mới dùng','Dùng ngay khi còn dính sữa, nước ngọt','Bỏ vào thùng rác vì không dùng được','Cắt vụn hết rồi mới chọn'],
  [2,'Bạn Nam dùng bút sáp màu tô một mảng lớn bầu trời nhưng màu bị lộ nhiều vệt trắng. Cách khắc phục đúng là gì?','Tô theo cùng một chiều, các nét sát nhau và tô lại lần hai cho kín','Đổi sang tô bằng bút chì','Tô thật nhanh theo nhiều hướng khác nhau','Lấy nước đổ lên mảng màu'],
  [3,'Em làm một con vật bằng vỏ hộp sữa và nắp chai. Hãy nêu các bước làm và cho biết em dùng gì để gắn các bộ phận.','Bước 1: chọn vỏ hộp làm thân, nắp chai làm mắt hoặc chân; bước 2: cắt, gấp bìa làm đầu, đuôi, tai; bước 3: gắn các bộ phận bằng keo dán hoặc băng dính hai mặt; bước 4: dán giấy màu hoặc tô màu trang trí. Khi cắt cần người lớn hoặc thầy cô hỗ trợ để an toàn.']
 ]);
 add(M,2,'Màu sắc',[
  [1,'Ba màu cam, lục, tím được tạo ra bằng cách nào?','Pha từng cặp hai màu cơ bản với nhau','Pha ba màu cơ bản cùng lúc','Pha màu cơ bản với màu đen','Lấy trực tiếp từ hộp màu, không thể pha được'],
  [2,'Em muốn tô lá cây gần thì đậm, lá cây xa thì nhạt bằng bút sáp màu lục. Em làm thế nào?','Lá gần tô ấn mạnh tay nhiều lớp; lá xa tô nhẹ tay, ít lớp','Lá gần tô màu lục, lá xa tô màu đỏ','Tô tất cả đều tay rồi vẽ thêm viền đen cho lá gần','Lá xa tô bằng màu đen'],
  [3,'Em có hộp màu chỉ gồm đỏ, vàng, lam và trắng. Hãy cho biết em pha thế nào để có màu cam, màu lục, màu hồng nhạt.','Màu cam: pha đỏ với vàng; màu lục: pha vàng với lam; màu hồng nhạt: pha đỏ với nhiều màu trắng. Muốn màu nhạt hơn thì thêm trắng, muốn đậm hơn thì thêm màu gốc.']
 ]);
 add(M,2,'Chấm, nét, hình, mảng',[
  [1,'Khi vẽ con sâu bằng cách xếp nhiều hình tròn to nhỏ nối liền nhau, em đã dùng cách tạo hình nào?','Lặp lại một hình cơ bản để tạo hình con vật','Xé dán mảng giấy','Chấm màu bằng đầu ngón tay','Vẽ bằng một nét thẳng duy nhất'],
  [2,'Trong bức tranh xé dán, mảng hình được tạo ra chủ yếu nhờ điều gì?','Những miếng giấy màu xé và dán kín một vùng','Những chấm bút màu rải rác','Một đường viền bằng bút chì','Các nét gạch chéo thưa'],
  [3,'Em dùng nét thẳng, nét cong, nét gấp khúc để vẽ một khu rừng. Hãy cho biết mỗi loại nét em dùng để vẽ bộ phận nào của cây cối và cảnh vật.','Nét thẳng vẽ thân cây, cành cây lớn; nét cong vẽ tán lá, đám mây, đường mòn uốn lượn; nét gấp khúc vẽ răng cưa ở mép lá, ngọn núi phía xa hoặc cỏ nhọn. Kết hợp nét to đậm cho cây gần và nét nhỏ nhạt cho cây xa.']
 ]);
 add(M,2,'Quan sát và cảm nhận',[
  [1,'Muốn xé dán bức tranh "Khu rừng thân thiện", trước khi làm em nên quan sát điều gì về các con vật?','Hình dáng, màu sắc và những bộ phận đặc trưng như tai, sừng, đuôi','Giá bán của các con vật','Tên con vật bằng tiếng Anh','Số lượng con vật trong sở thú'],
  [1,'Khi quan sát các đồ vật như hộp bánh, lon nước, quả bóng để sáng tạo sản phẩm, em nhận ra chúng có dạng gì?','Dạng các khối cơ bản như khối hộp, khối trụ, khối cầu','Dạng các nét cong','Dạng mảng màu phẳng','Dạng chấm nhỏ'],
  [2,'Hai bạn cùng làm con vật từ hộp giấy: bạn An dán thêm tai, đuôi, mắt; bạn Bình chỉ tô màu hộp. Sản phẩm của bạn nào dễ nhận ra là con vật hơn và vì sao?','Bạn An, vì các bộ phận đặc trưng giúp nhận ra con vật','Bạn Bình, vì tô màu là đủ','Hai sản phẩm giống nhau hoàn toàn','Không bạn nào, vì hộp giấy không thể thành con vật'],
  [3,'Em được xem sản phẩm "ngôi nhà" làm từ vỏ hộp của bạn trong lớp. Hãy nêu ba điều em sẽ quan sát để nhận xét sản phẩm đó.','Quan sát hình dáng ngôi nhà có cân đối, đứng vững không; màu sắc và cách trang trí (cửa, mái, cây) có hài hòa, rõ ràng không; các bộ phận có được gắn chắc, gọn gàng không. Khi nhận xét nên nói điểm em thích trước, sau đó góp ý nhẹ nhàng.']
 ]);

 /* ===== LỚP 3 ===== */
 add(M,3,'Quan sát và cảm nhận',[
  [1,'Khi quan sát một sản phẩm mĩ thuật được tạo bằng cách in (in lá, in khuôn), em thường nhận ra điều gì?','Hình được lặp lại nhiều lần giống nhau','Mỗi hình đều khác nhau hoàn toàn','Chỉ có một màu đen trắng','Không có đường nét nào'],
  [1,'Khi quan sát một pho tượng hoặc mô hình để nhận xét, em nên làm gì?','Xem từ nhiều phía: trước, sau, hai bên','Chỉ nhìn từ phía trước như xem tranh','Chỉ sờ mà không nhìn','Chỉ xem từ trên cao xuống'],
  [2,'Khi xem một bức tranh vẽ cảnh mùa hè với nhiều màu đỏ, cam, vàng, em cảm nhận được điều gì?','Không khí nóng, rực rỡ, vui tươi','Không khí lạnh lẽo, buồn tẻ','Cảnh ban đêm yên tĩnh','Không cảm nhận được gì từ màu sắc'],
  [3,'Em vẽ tranh về một trò chơi dân gian trong ngày hội (kéo co, bịt mắt bắt dê). Em cần quan sát hoặc nhớ lại những điều gì để vẽ đúng không khí trò chơi?','Nhớ lại dáng người đang chơi (ngả người kéo dây, dang tay đuổi bắt), vị trí của người chơi và người xem, trang phục nhiều màu, cờ hoa và sân chơi. Khi vẽ, nhóm người chơi làm hình chính to rõ ở giữa, người xem và cảnh vật làm hình phụ nhỏ hơn xung quanh.']
 ]);

 /* ===== LỚP 4 ===== */
 add(M,4,'Màu sắc và đậm nhạt',[
  [1,'Màu bổ túc của màu đỏ là màu nào?','Lục','Cam','Tím','Vàng'],
  [2,'Em vẽ tranh "Ngày hội" với nền chủ yếu màu lục. Muốn lá cờ trong tranh nổi bật nhất, em nên tô lá cờ màu gì?','Đỏ, vì đỏ là màu bổ túc của lục','Lục nhạt, cùng gam với nền','Lam, vì gần với lục','Trắng, vì nền nào cũng hợp'],
  [3,'Em vẽ một quả cam đặt trên bàn dưới ánh sáng từ cửa sổ bên trái. Hãy mô tả cách tô đậm nhạt để quả cam có khối.','Phần bên trái hướng về cửa sổ tô màu cam nhạt (sáng), phần giữa tô màu cam vừa (trung gian), phần bên phải xa ánh sáng tô cam đậm pha thêm chút nâu hoặc đỏ (tối); vẽ thêm bóng đổ màu đậm trên mặt bàn phía bên phải quả cam. Chuyển từ sáng sang tối cần mềm, không có ranh giới cứng.']
 ]);
 add(M,4,'Mĩ thuật dân gian và thường thức',[
  [1,'Tranh Hàng Trống xưa thường được treo ở đâu và vào dịp nào?','Trong nhà, dịp Tết và thờ cúng','Ngoài đường phố vào mùa hè','Trong trường học vào ngày khai giảng','Trên tàu thuyền khi đi biển'],
  [1,'Trong tranh Hàng Trống, phần nào được in từ ván khắc, phần nào do nghệ nhân làm bằng tay?','Nét đen in từ ván khắc, màu được tô bằng tay','Toàn bộ in từ nhiều ván màu','Toàn bộ vẽ tay, không in','Màu in bằng ván, nét vẽ tay'],
  [2,'Khi vận dụng hình ảnh con gà, con cá trong tranh dân gian để trang trí đồ vật, vì sao em nên vẽ lại theo lối đơn giản, mảng màu phẳng?','Vì đó là cách tạo hình đặc trưng của tranh dân gian, giúp sản phẩm giữ được tinh thần dân gian','Vì vẽ giống thật là sai quy định','Vì màu phẳng rẻ hơn','Vì tranh dân gian không có hình con vật'],
  [3,'Em được giao làm một chiếc đèn lồng giấy trang trí bằng hình ảnh tranh dân gian. Hãy nêu cách em chọn hình ảnh, màu sắc và các bước thực hiện.','Chọn một hình ảnh quen thuộc trong tranh dân gian như gà, cá, em bé ôm gà; vẽ lại theo lối đơn giản bằng nét đen rõ, tô mảng màu phẳng với các màu đỏ, vàng, lục, lam tươi; các bước: phác hình lên giấy màu, tô màu, cắt dán lên khung đèn, kiểm tra cân đối rồi hoàn thiện. Giới thiệu ý nghĩa hình ảnh đã chọn khi trưng bày.']
 ]);
 add(M,4,'Tạo hình và thủ công',[
  [1,'Khi làm khuôn in từ củ khoai hoặc tấm xốp, em cần làm gì để hình in có nền trắng và họa tiết màu?','Khắc bỏ phần nền, chỉ để nổi phần họa tiết rồi quét màu lên phần nổi','Quét màu lên toàn bộ mặt khuôn','Vẽ họa tiết bằng bút màu rồi ấn lên giấy','Cắt khuôn thành nhiều mảnh nhỏ'],
  [2,'Khi in họa tiết lặp lại thành dải viền trang trí, để các hình đều nhau em nên làm gì?','Dùng một khuôn in và in lần lượt theo đường kẻ, giữ khoảng cách bằng nhau','Mỗi lần in dùng một khuôn khác','In chồng các hình lên nhau','In tùy ý rồi tô lại bằng bút'],
  [3,'Nêu các bước làm một con rối tay (con vật) từ tất hoặc túi giấy và vật liệu sẵn có.','Bước 1: chọn tất hoặc túi giấy làm thân rối, xác định vị trí đầu, miệng; bước 2: cắt giấy màu, vải, cúc áo làm mắt, tai, lưỡi; bước 3: dán hoặc khâu các bộ phận vào thân; bước 4: trang trí thêm hoa văn, màu sắc; bước 5: thử lồng tay vào, điều chỉnh để rối cử động được. Khi dùng kéo, kim cần cẩn thận, làm xong cất gọn.']
 ]);
 add(M,4,'Quan sát và cảm nhận',[
  [1,'Khi quan sát cảnh đồng quê để vẽ, em thấy đường chân trời nằm ở đâu trong tranh?','Đường ngang nơi mặt đất hoặc mặt nước giáp với bầu trời','Đường viền của ngôi nhà','Đường thẳng đứng ở giữa tranh','Đường cong của cầu vồng'],
  [1,'Trong bức tranh phong cảnh có núi ở xa và cây ở gần, cây gần so với núi xa thường được vẽ thế nào?','To, rõ, màu đậm hơn núi xa','Nhỏ, mờ hơn núi xa','Cùng kích thước với núi','Chỉ vẽ bằng một nét mảnh'],
  [2,'Bạn em vẽ cảnh sân trường ngày hội nhưng mọi người và cây cối đều to bằng nhau, nằm trên một hàng ngang. Em sẽ góp ý thế nào để tranh có xa gần?','Vẽ người và cây ở gần to hơn, đặt thấp trong tranh; người và cây ở xa nhỏ hơn, đặt cao hơn gần đường chân trời','Tô tất cả cùng một màu','Xóa hết cây, chỉ giữ người','Vẽ thêm thật nhiều người cùng cỡ'],
  [3,'Sau khi lớp trưng bày tranh "Ngày hội ở trường em", em được mời nhận xét tranh của một bạn. Hãy nêu cách em quan sát và những điều em sẽ nói.','Quan sát tổng thể trước: hình chính có rõ không, bố cục có cân đối không; sau đó xem màu sắc có hòa sắc, có đậm nhạt và điểm nhấn không; cuối cùng xem chi tiết dáng người, nét vẽ. Khi nói, nêu điều em thích nhất, nêu cảm nhận về không khí ngày hội trong tranh, rồi góp ý một điểm bạn có thể làm tốt hơn với lời lẽ tôn trọng.']
 ]);

 /* ===== LỚP 5 ===== */
 add(M,5,'Màu sắc và đậm nhạt',[
  [1,'Cặp màu nào sau đây là cặp màu tương đồng?','Vàng và cam','Đỏ và lục','Lam và cam','Vàng và tím'],
  [2,'Khi vẽ bằng màu bột, muốn có sắc độ sáng của màu lam mà màu vẫn tươi, em pha thêm màu gì?','Màu trắng','Màu đen','Màu đỏ','Màu nâu'],
  [3,'Hãy nêu cách dùng màu tương phản để tạo điểm nhấn cho bức tranh "Buổi biểu diễn văn nghệ của lớp" có nền sân khấu màu lam.','Nền sân khấu và phông màn dùng các sắc độ lam, lam tím làm gam lạnh chủ đạo; nhân vật chính đứng giữa sân khấu mặc trang phục màu cam hoặc vàng cam (tương phản với lam) để nổi bật thành điểm nhấn; các nhân vật phụ dùng màu trung gian, sắc độ nhạt hơn để không tranh với hình chính; ánh đèn sân khấu vẽ sáng nhất ở quanh nhân vật chính.']
 ]);
 add(M,5,'Mĩ thuật dân gian và thường thức',[
  [1,'Hoa văn trên trống đồng Đông Sơn thường được sắp xếp theo kiểu nào?','Các vành tròn đồng tâm quanh ngôi sao ở giữa','Các ô vuông xếp thành bàn cờ','Rải rác tự do, không theo quy luật','Chỉ một hình lớn duy nhất phủ kín mặt trống'],
  [1,'Chạm khắc gỗ ở đình làng Việt Nam thường thuộc loại hình nào?','Phù điêu (chạm nổi) trên các cấu kiện kiến trúc','Tranh vẽ trên giấy','Tượng đồng đúc liền khối','Tranh in trên vải'],
  [2,'Vì sao các cảnh sinh hoạt trong chạm khắc đình làng (đấu vật, chèo thuyền, đánh cờ) được coi là có giá trị đặc biệt?','Vì phản ánh đời sống thật của người dân làng quê xưa bằng lối tạo hình mộc mạc, sinh động','Vì được tạo bằng máy móc hiện đại','Vì chỉ mô tả vua chúa và quan lại','Vì được vẽ bằng màu sơn dầu'],
  [3,'Em thiết kế một chiếc túi vải lấy cảm hứng từ hoa văn trống đồng Đông Sơn. Hãy nêu cách em chọn họa tiết và cách sắp xếp.','Chọn một vài họa tiết đặc trưng như ngôi sao nhiều cánh, hình chim lạc, hình người hóa trang hoặc hoa văn răng cưa, vòng tròn chấm giữa; vẽ lại theo lối cách điệu bằng nét đơn giản; sắp xếp họa tiết chính (ngôi sao) ở giữa mặt túi, các họa tiết phụ xếp thành vành tròn hoặc dải viền lặp lại quanh mép túi; dùng hai hoặc ba màu như nâu đồng, vàng đất trên nền vải sẫm để gợi chất liệu đồng.']
 ]);
 add(M,5,'Tạo hình và thủ công',[
  [1,'Khi làm mô hình đồ vật bằng bìa cứng cần có mặt cong (như thân bình hoa), em nên làm thế nào?','Cuộn hoặc uốn bìa mỏng rồi dán cố định mép','Gấp bìa thành nhiều nếp vuông góc','Cắt bìa thành các hình vuông rồi xếp chồng','Dùng bìa thật dày để tự cong'],
  [2,'Khi thiết kế một chiếc đèn trang trí để bàn, vì sao em phải chú ý đến chỗ đặt nguồn sáng và chất liệu chao đèn?','Để ánh sáng tỏa ra đẹp, an toàn và chao đèn không bị nóng, cháy','Để đèn nặng hơn, không bị đổ','Để đèn có thể dùng làm hộp bút','Vì chao đèn phải làm bằng kim loại mới đẹp'],
  [3,'Nêu các bước tạo một sản phẩm mĩ thuật ứng dụng (hộp đựng quà) có trang trí hoa văn dân gian, từ ý tưởng đến hoàn thiện.','Bước 1: xác định mục đích dùng và kích cỡ hộp theo món quà; bước 2: phác thảo hình dáng hộp và vị trí trang trí; bước 3: đo, cắt, gấp bìa tạo hộp và nắp; bước 4: vẽ hoặc in hoa văn dân gian (hoa sen, chim lạc, họa tiết sóng nước) lên các mặt hộp theo nguyên tắc lặp lại, cân đối; bước 5: dán, hoàn thiện và kiểm tra nắp đóng mở dễ dàng; bước 6: giới thiệu sản phẩm, nêu công dụng và ý nghĩa hoa văn.']
 ]);
 add(M,5,'Quan sát và cảm nhận',[
  [1,'Khi quan sát đầu bạn để vẽ chân dung, hai mắt thường nằm ở vị trí nào so với chiều cao của đầu (tính từ đỉnh đầu đến cằm)?','Khoảng giữa chiều cao của đầu','Sát đỉnh đầu','Ngay trên miệng','Ở phần ba dưới, gần cằm'],
  [1,'Khi quan sát dáng người đang gánh lúa, điều gì giúp em thể hiện được cảm giác nặng của gánh?','Vai lệch, lưng hơi khom, đòn gánh cong, bước chân chùng','Hai tay giơ cao, người đứng thẳng','Người nhảy lên khỏi mặt đất','Vẽ gánh lúa thật nhỏ'],
  [2,'Khi vẽ chân dung bạn, vì sao em không nên chỉ vẽ cho giống mà còn cần quan sát biểu cảm khuôn mặt?','Vì biểu cảm (vui, buồn, ngạc nhiên) giúp bức chân dung có cảm xúc và cá tính riêng','Vì vẽ giống là điều không thể làm được','Vì biểu cảm giúp tranh có nhiều màu hơn','Vì giáo viên chỉ chấm điểm biểu cảm'],
  [3,'Em được xem một tác phẩm điêu khắc dân gian (phù điêu đình làng) và một bức tranh chân dung hiện đại. Hãy nêu những điểm em sẽ quan sát ở mỗi tác phẩm để cảm nhận.','Với phù điêu đình làng: quan sát chất liệu gỗ, độ nổi của hình, cách tạo dáng người mộc mạc, đề tài sinh hoạt làng quê và cảm giác vui tươi, gần gũi. Với tranh chân dung: quan sát tỉ lệ khuôn mặt, ánh sáng và đậm nhạt tạo khối, biểu cảm nhân vật, màu sắc và bố cục. Sau đó so sánh cảm nhận của em về hai cách thể hiện con người khác nhau.']
 ]);

 /* ===== LỚP 7 ===== */
 add(M,7,'Kiến thức tạo hình',[
  [1,'Khi vẽ tĩnh vật gồm lọ hoa và quả, bước đầu tiên sau khi quan sát mẫu là gì?','Phác khung hình chung của toàn bộ mẫu lên giấy','Tô màu nền trước','Vẽ chi tiết từng cánh hoa','Vẽ bóng đổ trước'],
  [2,'Khi kí họa dáng người tại một di tích, vì sao người vẽ chỉ dùng vài nét nhanh thay cho vẽ kĩ từng chi tiết?','Vì kí họa nhằm ghi lại nhanh dáng, động tác và đặc điểm chính để làm tư liệu sáng tác','Vì kí họa không cần quan sát mẫu','Vì kí họa luôn phải vẽ bằng màu nước','Vì kí họa chỉ dành cho phong cảnh'],
  [3,'Em được giao tạo mô hình một cổng làng cổ bằng bìa và đất nặn. Hãy nêu các bước thực hiện và cách thể hiện vẻ cổ kính của công trình.','Bước 1: quan sát hoặc tìm tư liệu về cổng làng, kí họa hình dáng chính và các chi tiết mái, trụ, hoa văn; bước 2: phác thảo bản vẽ tổng thể và tỉ lệ; bước 3: cắt, gấp bìa dựng thân cổng, trụ và mái; bước 4: dùng đất nặn hoặc giấy bồi tạo ngói, hoa văn, chữ, rêu phong trên tường; bước 5: tô màu gam trầm (nâu, xám, rêu), nhấn đậm ở các khe gạch, chân tường để gợi vẻ cũ kĩ; bước 6: hoàn thiện, đặt lên nền và giới thiệu.']
 ]);
 add(M,7,'Thường thức mĩ thuật',[
  [1,'Chùa Một Cột (Hà Nội) là công trình kiến trúc tiêu biểu của thời kì nào trong lịch sử mĩ thuật Việt Nam?','Thời Lý','Thời Nguyễn','Thời tiền sử','Thời hiện đại'],
  [2,'Vì sao các họa sĩ Phục Hưng nghiên cứu giải phẫu và luật xa gần?','Để thể hiện con người và không gian giống thật, có chiều sâu','Để vẽ tranh trừu tượng không có hình','Để làm tranh nhanh hơn','Để không phải quan sát mẫu'],
  [3,'Nêu một số đặc điểm của mĩ thuật thời Trần so với thời Lý mà em biết.','Mĩ thuật thời Trần kế thừa thời Lý nhưng khoẻ khoắn, giản dị và phóng khoáng hơn; kiến trúc tiêu biểu có tháp Phổ Minh, khu lăng mộ An Sinh; điêu khắc có tượng hổ ở lăng Trần Thủ Độ, các bệ đá hoa sen; hình rồng thời Trần mập, khỏe hơn rồng thời Lý vốn thanh mảnh, uốn lượn đều đặn. Gốm thời Trần có gốm hoa nâu nổi tiếng.']
 ]);
 add(M,7,'Yếu tố và nguyên lí tạo hình',[
  [1,'Trong một bài trang trí, họa tiết chính được vẽ to, màu nổi, đặt ở trung tâm; họa tiết phụ nhỏ hơn ở xung quanh. Cách sắp xếp này thể hiện nguyên lí nào?','Nhấn mạnh (điểm nhấn)','Lặp lại','Cân bằng đối xứng','Tương đồng'],
  [2,'Khi vẽ một ngôi chùa cổ với ba lớp: cây ở gần, chùa ở giữa, núi ở xa, yếu tố không gian được tạo chủ yếu bằng cách nào?','Lớp gần đậm, rõ, to; lớp xa nhạt, mờ, nhỏ','Tô cả ba lớp cùng độ đậm','Vẽ núi to hơn chùa và cây','Dùng duy nhất màu đen cho cả tranh'],
  [3,'Hãy nêu cách vận dụng nguyên lí tỉ lệ và cân bằng khi thiết kế một tấm bưu thiếp có hình di tích và dòng chữ giới thiệu.','Xác định tỉ lệ giữa hình và chữ, ví dụ hình chiếm khoảng hai phần ba, chữ một phần ba để hình là trọng tâm; không đặt hình chính giữa chia đôi thiệp mà lệch nhẹ về một bên và dùng khối chữ ở phía đối diện để tạo cân bằng bất đối xứng; kích cỡ chữ tiêu đề lớn hơn chữ phụ theo tỉ lệ rõ ràng; chừa khoảng trống hợp lí quanh hình và chữ để thiệp thoáng, dễ nhìn.']
 ]);
 add(M,7,'Thưởng thức và ứng dụng',[
  [1,'Khi làm sản phẩm lưu niệm hình di tích bằng đất nặn hoặc bìa, hình ảnh di tích thường được thu nhỏ theo cách nào?','Giữ các đặc điểm nhận biết chính, lược bỏ chi tiết nhỏ','Thêm thật nhiều chi tiết mới cho phong phú','Thay đổi hoàn toàn hình dáng di tích','Chỉ giữ lại màu sắc, bỏ hình dáng'],
  [1,'Một chiếc áo dài hiện đại in họa tiết lấy từ hình hoa cúc, hoa sen trên gốm thời Lý là ví dụ của việc gì?','Vận dụng di sản mĩ thuật truyền thống vào thiết kế thời trang','Sao chép nguyên vẹn một tác phẩm cổ','Phục chế hiện vật khảo cổ','Vẽ tranh tĩnh vật'],
  [2,'Khi thưởng thức một bức tranh về cuộc sống xưa và nay, em có thể nhận ra sự khác biệt giữa hai thời kì nhờ điều gì trong tranh?','Trang phục, phương tiện, công trình và cách dùng màu sắc cho từng thời kì','Kích cỡ khung tranh','Tên của họa sĩ','Chất liệu giấy vẽ'],
  [3,'Hãy nêu cách em tổ chức một buổi giới thiệu sản phẩm mô hình và bưu thiếp di tích quê hương của nhóm cho các bạn trong lớp.','Chuẩn bị: sắp xếp sản phẩm theo nhóm (mô hình riêng, bưu thiếp riêng), ghi tên di tích và nhóm thực hiện; phân công người thuyết trình, người trả lời câu hỏi. Giới thiệu: nêu tên, vị trí, đặc điểm kiến trúc của di tích; cách nhóm chọn hình ảnh, vật liệu, màu sắc; điều nhóm muốn gửi gắm. Mời các bạn quan sát từ nhiều phía, đặt câu hỏi và nhận xét; cuối cùng nhóm rút ra điểm cần cải thiện.']
 ]);
 add(M,7,'(Bổ sung) Màu sắc và bố cục',[
  [1,'Trong một bức tranh vẽ di tích vào buổi hoàng hôn, hòa sắc chủ đạo thường thuộc gam nào?','Gam nóng với cam, đỏ, vàng','Gam lạnh với lam, lục','Chỉ đen và trắng','Toàn màu trung tính xám'],
  [2,'Trong bức tranh "Cuộc sống xưa và nay", phần quá khứ được vẽ bằng màu nâu, vàng đất nhạt; phần hiện tại bằng màu tươi, rõ. Cách dùng màu này nhằm mục đích gì?','Gợi cảm giác thời gian: xưa trầm, cũ kĩ; nay tươi mới, sống động','Làm hai phần tranh giống nhau','Tiết kiệm màu vẽ','Che đi lỗi sai của phần vẽ xưa'],
  [3,'Em vẽ tranh về một ngôi đình cổ bên hồ nước với vài người đi lễ. Hãy nêu cách em chọn hòa sắc và sắp xếp bố cục.','Hòa sắc: dùng gam trầm, tương đồng như nâu, vàng đất, rêu cho mái đình, tường và cây cổ thụ để gợi vẻ cổ kính; mặt hồ lam xám nhạt phản chiếu; điểm nhấn là trang phục người đi lễ màu đỏ hoặc vàng tươi nhỏ. Bố cục: đặt đình hơi lệch một bên theo quy tắc chia ba, cây cổ thụ ở phía đối diện để cân bằng; mặt hồ ở tiền cảnh tạo chiều sâu, nhóm người đặt gần lối vào đình để dẫn mắt người xem về hình chính.']
 ]);

 /* ===== LỚP 8 ===== */
 add(M,8,'Kiến thức tạo hình',[
  [1,'Khi phác dáng người đang chạy, đường trục cơ thể thường được vẽ như thế nào?','Nghiêng về phía trước theo hướng chuyển động','Thẳng đứng vuông góc với mặt đất','Nằm ngang song song mặt đất','Cong thành hình tròn'],
  [2,'Vì sao khi vẽ tranh sinh hoạt nhóm người, họa sĩ thường kí họa nhiều dáng khác nhau trước khi vẽ bố cục?','Để có tư liệu dáng phong phú, chọn và sắp xếp các dáng phù hợp với nội dung tranh','Để tranh có nhiều người hơn','Vì không được phép vẽ trực tiếp bố cục','Vì kí họa bắt buộc dùng màu'],
  [3,'Hãy nêu cách tạo một nhân vật đang nhảy múa bằng dây thép và giấy bồi, từ phác thảo đến hoàn thiện.','Bước 1: vẽ phác dáng nhân vật, xác định trục và các khớp (vai, khuỷu, hông, gối) theo tỉ lệ khoảng bảy đến bảy rưỡi đầu; bước 2: uốn dây thép thành khung xương theo dáng đã phác, gắn vào đế cho đứng vững; bước 3: quấn giấy báo và bồi giấy với hồ dán tạo khối thân, tay, chân, đầu; bước 4: để khô, tô màu da, trang phục, thêm chi tiết tóc, phụ kiện; bước 5: kiểm tra dáng từ nhiều phía để động tác rõ và sinh động.']
 ]);
 add(M,8,'Thường thức mĩ thuật',[
  [1,'Bức tranh lụa "Chơi ô ăn quan" là tác phẩm của họa sĩ nào?','Nguyễn Phan Chánh','Tô Ngọc Vân','Nguyễn Gia Trí','Bùi Xuân Phái'],
  [2,'Vì sao các họa sĩ Ấn tượng thường vẽ ngoài trời và vẽ cùng một cảnh vào các thời điểm khác nhau trong ngày?','Để ghi lại sự thay đổi của ánh sáng và màu sắc theo thời gian','Vì không có xưởng vẽ trong nhà','Để tranh có nhiều nhân vật hơn','Vì họ chỉ vẽ bằng bút chì'],
  [3,'Nêu một số đóng góp của Trường Mĩ thuật Đông Dương đối với mĩ thuật Việt Nam hiện đại.','Đào tạo thế hệ họa sĩ đầu tiên của mĩ thuật hiện đại Việt Nam như Nguyễn Phan Chánh, Tô Ngọc Vân, Nguyễn Gia Trí, Trần Văn Cẩn; đưa phương pháp tạo hình châu Âu (giải phẫu, xa gần, vẽ theo mẫu) vào kết hợp với truyền thống dân tộc; nâng sơn mài và lụa từ chất liệu trang trí thủ công thành chất liệu hội họa độc đáo của Việt Nam; hình thành phong cách vừa hiện đại vừa mang bản sắc dân tộc.']
 ]);
 add(M,8,'Yếu tố và nguyên lí tạo hình',[
  [1,'Trong tranh sinh hoạt có nhóm người ở tiền cảnh và cảnh vật phía sau, để nhóm người là trọng tâm, họa sĩ thường xử lí phía sau như thế nào?','Vẽ đơn giản hơn, đậm nhạt và màu nhẹ hơn nhóm người','Vẽ chi tiết và đậm hơn nhóm người','Tô một màu đen kín','Vẽ các nhân vật khác to hơn'],
  [2,'Khi sắp xếp ba nhân vật trong tranh, nếu đặt họ ở ba độ cao khác nhau thay vì cùng một hàng ngang, bố cục sẽ đạt được điều gì?','Nhịp điệu và sự sinh động, tránh đơn điệu','Cân bằng đối xứng tuyệt đối','Không gian phẳng hoàn toàn','Tất cả nhân vật đều là trọng tâm'],
  [3,'Hãy phân tích cách vận dụng nguyên lí tương phản về đậm nhạt và kích cỡ khi vẽ bức tranh về người lao động trên công trường xây dựng.','Tương phản kích cỡ: nhân vật lao động ở tiền cảnh vẽ lớn, công trình và máy móc phía sau nhỏ dần theo xa gần để nhấn mạnh con người; hoặc ngược lại, vẽ người nhỏ trước công trình đồ sộ để gợi sự kì vĩ của lao động. Tương phản đậm nhạt: dáng người đậm trên nền trời sáng hoặc trang phục sáng trước khối bê tông tối để tách hình khỏi nền; vùng đậm nhất đặt gần trọng tâm, các mảng còn lại giảm dần độ tương phản để mắt tập trung vào hành động chính.']
 ]);
 add(M,8,'Thưởng thức và ứng dụng',[
  [1,'Khi thiết kế bìa sách giới thiệu quê hương, thứ tự đọc của người xem thường bắt đầu từ đâu?','Hình ảnh và tiêu đề lớn, rõ nhất trên bìa','Tên nhà xuất bản in nhỏ','Mã số ở gáy sách','Số trang'],
  [2,'Khi thưởng thức một bức tranh lụa Việt Nam, vì sao màu sắc thường mềm, trong và nhẹ?','Vì màu được nhuộm nhiều lần, thấm vào sợi lụa và được rửa nước nên loang nhẹ, trong','Vì họa sĩ chỉ dùng một màu duy nhất','Vì lụa không thể giữ màu đậm','Vì tranh lụa luôn vẽ bằng sơn dầu'],
  [3,'Em được giao thiết kế một tấm áp phích cổ động về an toàn giao thông cho trường. Hãy nêu cách em vận dụng ngôn ngữ tạo hình của tranh cổ động.','Chọn một hình tượng trung tâm đơn giản, dễ hiểu (ví dụ học sinh đội mũ bảo hiểm) vẽ to, khái quát bằng mảng phẳng; dùng ít màu nhưng tương phản mạnh như đỏ, vàng, đen, trắng để gây chú ý từ xa; khẩu hiệu ngắn gọn, chữ to, rõ, đặt ở vị trí dễ đọc; bố cục chặt, hình và chữ liên kết thành một khối; loại bỏ các chi tiết thừa để thông điệp truyền đạt nhanh nhất.']
 ]);
 add(M,8,'(Bổ sung) Màu sắc và bố cục',[
  [1,'Trong tranh Ấn tượng, bóng của vật thường được vẽ bằng màu gì?','Các màu có sắc như lam, tím thay cho đen hoặc nâu','Luôn là màu đen','Luôn là màu nâu đậm','Không vẽ bóng'],
  [2,'Khi vẽ tranh về đề tài gia đình quây quần bên mâm cơm, họa sĩ thường dùng bố cục nào để gợi sự gắn kết?','Bố cục hướng tâm, các nhân vật quay về trung tâm','Bố cục rải đều, mỗi người một góc tranh','Bố cục đường chéo mạnh','Bố cục một hàng ngang cách xa nhau'],
  [3,'Hãy nêu cách xây dựng hòa sắc theo tinh thần Ấn tượng cho bức tranh cảnh chợ quê buổi sớm có nắng.','Chọn gam sáng, tươi: nắng sớm dùng vàng chanh, vàng cam nhạt đặt cạnh các mảng lam, tím nhạt ở phần bóng để tạo tương phản sáng tối bằng màu thay cho đen trắng; màu của vật chịu ảnh hưởng của ánh nắng và màu vật kề bên nên không tô màu cục bộ; đặt các nét màu nhỏ cạnh nhau để màu hòa vào mắt người xem; giữ hòa sắc thống nhất bằng cách để màu vàng của nắng lan nhẹ lên hầu hết các mảng.']
 ]);

 /* ===== LỚP 9 ===== */
 add(M,9,'Kiến thức tạo hình',[
  [1,'Trong quy trình in khắc nổi trên tấm cao su, sau khi khắc xong bước tiếp theo là gì?','Lăn mực đều lên mặt khuôn rồi đặt giấy và ấn hoặc xoa đều','Tô màu trực tiếp lên giấy','Cắt giấy thành hình khuôn','Ngâm khuôn vào nước'],
  [2,'Khi tạo hình nhân vật hoạt hình, vì sao người thiết kế thường vẽ nhân vật ở nhiều góc nhìn và nhiều biểu cảm trên cùng một bảng?','Để nhân vật giữ được hình dáng nhất quán khi chuyển động và thể hiện được tính cách','Để trang trí cho bảng vẽ đẹp hơn','Vì mỗi góc nhìn là một nhân vật khác','Vì phần mềm bắt buộc như vậy'],
  [3,'Hãy nêu cách thiết kế một bộ hình ảnh lặp lại (họa tiết) in trên túi vải bằng khuôn khắc cao su, từ ý tưởng đến sản phẩm.','Bước 1: chọn chủ đề họa tiết (lá, cá, hoa văn dân gian) và vẽ phác hình đơn giản, rõ mảng vì khắc nổi không thể hiện chi tiết quá nhỏ; bước 2: chuyển hình lên tấm cao su, nhớ hình in sẽ ngược chiều; bước 3: khắc bỏ phần nền, giữ phần nổi là họa tiết; bước 4: thử in lên giấy, chỉnh sửa khuôn; bước 5: lăn mực in vải, in lặp lại lên túi theo lưới đã kẻ để họa tiết đều, có thể đổi hai màu xen kẽ tạo nhịp điệu; bước 6: để khô, cố định màu và hoàn thiện.']
 ]);
 add(M,9,'Thường thức mĩ thuật',[
  [1,'Nghệ thuật sắp đặt, trình diễn, video art được xếp vào nhóm nào?','Các hình thức của nghệ thuật đương đại','Hội họa Phục Hưng','Mĩ thuật thời tiền sử','Tranh dân gian'],
  [2,'Vì sao Pop Art thường dùng kĩ thuật in lưới và hình ảnh lặp lại nhiều lần?','Để phản ánh tính sản xuất hàng loạt của xã hội tiêu dùng hiện đại','Vì họa sĩ không biết vẽ tay','Để tiết kiệm giấy','Vì in lưới chỉ in được một màu'],
  [3,'Nêu một số điểm khác biệt giữa nghệ thuật đương đại và hội họa truyền thống về chất liệu, không gian và vai trò người xem.','Chất liệu: đương đại dùng mọi vật liệu, kể cả vật dụng sẵn có, ánh sáng, âm thanh, video, cơ thể nghệ sĩ; truyền thống chủ yếu dùng màu trên mặt phẳng hoặc chất liệu điêu khắc. Không gian: đương đại chiếm lĩnh cả không gian, có thể ở ngoài bảo tàng; truyền thống gắn với khung tranh, bệ tượng. Người xem: đương đại mời người xem đi vào, tương tác, tham gia tạo nghĩa cho tác phẩm; truyền thống người xem đứng ngoài chiêm ngưỡng.']
 ]);
 add(M,9,'Yếu tố và nguyên lí tạo hình',[
  [1,'Trong một mẫu lô-gô, việc dùng cùng một độ dày nét cho mọi chi tiết thể hiện nguyên lí nào?','Thống nhất (hài hòa)','Tương phản','Chuyển động','Nhấn mạnh'],
  [2,'Khi thiết kế áp phích sự kiện, vì sao tiêu đề thường được đặt lớn nhất, thông tin thời gian và địa điểm nhỏ hơn?','Để tạo thứ bậc thị giác, người xem nắm được nội dung chính trước rồi đến chi tiết','Vì chữ nhỏ luôn đẹp hơn','Vì áp phích không được có chữ to','Để lấp đầy khoảng trống trên giấy'],
  [3,'Hãy phân tích cách vận dụng nguyên lí cân bằng và nhịp điệu khi sắp đặt một nhóm tác phẩm điêu khắc nhỏ từ vật liệu tái chế trong khuôn viên trường.','Cân bằng: phân bố các khối theo trọng lượng thị giác, một khối lớn ở một phía đối trọng với vài khối nhỏ ở phía kia; chú ý cân bằng về màu và chất liệu để không bên nào quá nặng. Nhịp điệu: lặp lại một hình dáng hoặc màu ở các khoảng cách tăng giảm đều, tạo đường dẫn mắt người xem đi qua toàn bộ sắp đặt; xen kẽ khối cao thấp để tạo chuyển động. Đồng thời tính đến lối đi, góc nhìn từ nhiều phía và ánh sáng tự nhiên trong sân trường.']
 ]);
 add(M,9,'Thưởng thức và ứng dụng',[
  [1,'Người làm công việc vẽ minh họa sách, truyện tranh thuộc nhóm nghề nào?','Mĩ thuật ứng dụng (thiết kế đồ họa, minh họa)','Điêu khắc tượng đài','Phục chế tranh cổ','Kiến trúc cảnh quan'],
  [2,'Khi tìm hiểu nghề nhà thiết kế nội thất, em thấy nghề này cần kết hợp kiến thức mĩ thuật với lĩnh vực nào?','Kĩ thuật xây dựng, vật liệu và công năng sử dụng không gian','Âm nhạc và vũ đạo','Y học và dinh dưỡng','Thiên văn học'],
  [3,'Em dự định làm hồ sơ sản phẩm (portfolio) để giới thiệu khả năng mĩ thuật của mình khi chọn hướng học tiếp. Hãy nêu cách em chọn sản phẩm và trình bày hồ sơ.','Chọn khoảng tám đến mười sản phẩm tốt nhất, thể hiện đa dạng kĩ năng: vẽ hình họa, màu sắc, thiết kế đồ họa, sản phẩm ba chiều, bài kĩ thuật số; mỗi sản phẩm chụp rõ, ánh sáng đều, ghi tên, chất liệu, kích cỡ, năm và vài dòng về ý tưởng; sắp xếp từ mạnh nhất đến các bài hỗ trợ, bố cục trang thống nhất về lưới, phông chữ và bảng màu; có trang giới thiệu bản thân và định hướng nghề; cập nhật hồ sơ sau mỗi bài tốt hơn.']
 ]);
 add(M,9,'(Bổ sung) Màu sắc và bố cục',[
  [1,'Trong một bộ nhận diện thương hiệu, bảng màu thường gồm những nhóm màu nào?','Màu chủ đạo, màu phụ và màu nhấn','Chỉ một màu duy nhất','Tất cả các màu trên vòng thuần sắc','Màu thay đổi tùy ý mỗi lần in'],
  [2,'Khi thiết kế bài đăng mạng xã hội giới thiệu triển lãm của lớp, vì sao nên giới hạn bảng màu trong khoảng hai đến ba màu?','Để bài đăng thống nhất, dễ nhận diện và thông điệp không bị loãng','Vì phần mềm chỉ cho dùng ba màu','Để tiết kiệm mực in','Vì càng nhiều màu càng ít người xem'],
  [3,'Hãy nêu cách xây dựng bố cục và bảng màu cho một tấm áp phích Pop Art giới thiệu món ăn đường phố địa phương.','Bố cục: chọn hình món ăn làm trung tâm, phóng to, vẽ khái quát bằng nét viền đậm và mảng màu phẳng; lặp lại hình đó thành lưới hai hoặc bốn ô với màu nền khác nhau theo tinh thần Pop Art; tên món ăn dùng chữ lớn, dạng chữ đậm kiểu truyện tranh. Bảng màu: dùng các màu tươi, tương phản mạnh như vàng, đỏ, lam, hồng, lục trên nền phẳng; mỗi ô đổi cặp màu nền và hình để tạo nhịp điệu nhưng giữ nét viền đen thống nhất; chừa viền trắng quanh lưới để áp phích gọn, nổi bật.']
 ]);
})();
