/* KIỂM ĐỊNH KHO CÂU HỎI — chạy: node kiemdinh_kho.js  (trong thư mục chứa index.html)
   Nạp đúng các file index.html đang dùng + bước khử trùng như app, rồi kiểm:
   cấu trúc TN/TL, mức 1–4, phương án trùng, đáp án rỗng, HTML/JS không an toàn, câu trùng giữa chủ đề,
   chuẩn mỗi chủ đề ≥6 TN + ≥4 TL + ≥1 mức 4 (trừ Toán tự sinh). Xuất báo cáo kiemdinh_baocao.txt */
const fs=require('fs');let NH={},TOAN;global.window=global;try{eval(fs.readFileSync('hinhanh.js','utf8'))}catch(e){console.log('hinhanh.js lỗi:',e.message)}
const html=fs.readFileSync('index.html','utf8');
const THU_TU=['nganhang.js','nganhang_bs.js','nganhang_bai.js','nganhang_nc.js','nganhang_bs2.js','nganhang_bs3.js','nganhang_gdcd.js','nganhang_tienganh.js','nganhang_tinhoc.js','nganhang_congnghe.js','nganhang_lsdl.js','nganhang_lsdl7.js','nganhang_lsdl8.js','nganhang_lsdl9.js','nganhang_khtn6.js','nganhang_khtn7.js','nganhang_khtn8.js','nganhang_khtn9.js','nganhang_van67.js','nganhang_van89.js','nganhang_tienganh2.js','nganhang_tincn2.js','nganhang_gdtc.js','nganhang_amnhac.js','nganhang_mithuat.js','nganhang_hdtn.js','nganhang_hsg_tn.js','nganhang_bs4.js','nganhang_hinh_toan15.js','nganhang_hinh_toan69.js','nganhang_hinh_khac.js','nganhang_thay_gdtc.js','nganhang_thay_amnhac.js','nganhang_thay_mithuat.js','nganhang_thay_hdtn.js'];   // thứ tự nạp kho nguồn (như index.html trước v15)
const files=THU_TU.filter(f=>fs.existsSync(f));
for(const f of files){let s=fs.readFileSync(f,'utf8').replace('const NH={}','NH={}').replace('const TOAN=','TOAN=');eval(s)}
{const i=html.indexOf('/* Khử trùng câu hỏi giữa');if(i>0)eval(html.slice(i,html.indexOf('</script>',i)))}
const noImg=q=>q.filter(x=>!(typeof x==='string'&&x.startsWith('@img:')));const isMC=q=>noImg(q).length>=4;const L=[];const st={mon:{},tong:0,chuDe:0,loi:0,thieu:0};
const seenArr=new Set();
for(const mon of Object.keys(NH)){for(const lop of Object.keys(NH[mon])){const T=NH[mon][lop];if(!Array.isArray(T)||seenArr.has(T))continue;seenArr.add(T);
 st.mon[mon]=st.mon[mon]||{chuDe:0,cau:0,tn:0,tl:0,nc:0,thieu:0};
 for(const t of T){st.chuDe++;st.mon[mon].chuDe++;let tn=0,tl=0,nc=0;
  for(const q0 of t.q){const q=noImg(q0);if(q0.length!==q.length){const sp=q0.find(x=>typeof x==='string'&&x.startsWith('@img:'));const kind=sp.split(':')[1];st.hinh=(st.hinh||0)+1;if(!(global.DS_HINH||[]).includes(kind)){L.push(`MÃ HÌNH LẠ\t${mon}\t${lop}\t${t.cd}\t${sp}`);st.loi++}}st.tong++;st.mon[mon].cau++;
   if(!(q.length===3||q.length>=4)){L.push(`LỖI CẤU TRÚC\t${mon}\t${lop}\t${t.cd}\t${String(q[1]).slice(0,60)}`);st.loi++}
   if(![1,2,3,4].includes(q[0])){L.push(`SAI MỨC\t${mon}\t${lop}\t${t.cd}\t${String(q[1]).slice(0,60)}`);st.loi++}
   if(q.slice(1).some(x=>!String(x).trim())){L.push(`RỖNG\t${mon}\t${lop}\t${t.cd}\t${String(q[1]).slice(0,60)}`);st.loi++}
   if(q.length>=4&&new Set(q.slice(2).map(x=>String(x).trim())).size<q.length-2){L.push(`TRÙNG PHƯƠNG ÁN\t${mon}\t${lop}\t${t.cd}\t${String(q[1]).slice(0,60)}`);st.loi++}
   if(q.some(x=>/<script|javascript:|onerror=|onload=/i.test(String(x)))){L.push(`HTML KHÔNG AN TOÀN\t${mon}\t${lop}\t${t.cd}\t${String(q[1]).slice(0,60)}`);st.loi++}
   if(isMC(q)){tn++;st.mon[mon].tn++}else{tl++;st.mon[mon].tl++}if(q[0]===4){nc++;st.mon[mon].nc++}}
  if(mon!=='Toán'&&(tn<6||tl<4||!nc)){st.thieu++;st.mon[mon].thieu++;L.push(`DƯỚI CHUẨN\t${mon}\t${lop}\t${t.cd}\tTN=${tn} TL=${tl} NC=${nc}`)}}}}
let out=`KIỂM ĐỊNH KHO CÂU HỎI — ${new Date().toLocaleString('vi-VN')}\nFile nạp: ${files.length}\nTổng: ${st.chuDe} chủ đề · ${st.tong} câu (sau khử trùng) · lỗi cấu trúc: ${st.loi} · chủ đề dưới chuẩn: ${st.thieu} · câu có hình gắn mã: ${st.hinh||0}\n\nMôn\tChủ đề\tCâu\tTN\tTL\tNC\tDưới chuẩn\n`;
for(const m of Object.keys(st.mon)){const x=st.mon[m];out+=`${m}\t${x.chuDe}\t${x.cau}\t${x.tn}\t${x.tl}\t${x.nc}\t${x.thieu}\n`}
out+=`\nCHI TIẾT (${L.length}):\n`+L.join('\n')+'\n';
fs.writeFileSync('kiemdinh_baocao.txt',out);console.log(out.split('\nCHI TIẾT')[0]);console.log('Chi tiết:',L.length,'dòng → kiemdinh_baocao.txt');
