/* NGÂN HÀNG ÂM NHẠC – LỚP 1–9 — bổ sung đủ chuẩn. Câu hỏi nguyên bản, bám SGK Kết nối tri thức. Không trích lời bài hát. */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Âm nhạc';

 /* ===== LỚP 1 ===== */
 add(M,1,'Nghe và cảm nhận âm thanh',[
  [1,'Âm thanh nào sau đây do con người tạo ra?','tiếng hát','tiếng mưa rơi','tiếng gió thổi','tiếng sấm'],
  [1,'Tiếng còi tàu và tiếng gõ nhẹ vào bàn, tiếng nào kéo dài hơn?','tiếng còi tàu','tiếng gõ nhẹ vào bàn','hai tiếng dài bằng nhau','không tiếng nào kéo dài'],
  [1,'Tiếng chim hót và tiếng trống trường, tiếng nào cao hơn?','tiếng chim hót','tiếng trống trường','hai tiếng cao bằng nhau','không so sánh được'],
  [2,'Khi muốn nghe rõ các âm thanh xung quanh, em cần làm gì?','giữ yên lặng và lắng nghe','nói chuyện thật to','chạy nhảy xung quanh','bịt tai lại'],
  [2,'Tiếng nói thì thầm thuộc loại âm thanh nào?','âm thanh nhỏ','âm thanh to','âm thanh rất to','âm thanh kéo dài'],
  [2,'Khi nghe một bản nhạc êm dịu, em thường cảm thấy thế nào?','nhẹ nhàng, thư thái','sốt ruột, lo lắng','muốn chạy nhanh','ồn ào, khó chịu'],
  [3,'Em hãy kể tên hai âm thanh to và hai âm thanh nhỏ mà em từng nghe.','Ví dụ: âm thanh to – tiếng sấm, tiếng trống; âm thanh nhỏ – tiếng lá rơi, tiếng đồng hồ tích tắc.'],
  [3,'Em hãy dùng giọng nói của mình để thể hiện một âm thanh cao và một âm thanh thấp.','HS tạo được âm cao (giọng mảnh, như tiếng chim) và âm thấp (giọng trầm, như tiếng trống), phân biệt rõ hai mức cao độ.'],
  [3,'Hãy dùng tay vỗ để tạo ra hai tiếng: một tiếng to và một tiếng nhỏ.','HS vỗ tay mạnh tạo tiếng to, vỗ tay nhẹ tạo tiếng nhỏ; phân biệt rõ hai mức to – nhỏ.'],
  [4,'Vì sao cùng là tiếng gõ trống nhưng có lúc nghe to, có lúc nghe nhỏ? Em hãy giải thích và nêu cách tạo ra hai mức âm thanh đó.','Âm thanh to hay nhỏ phụ thuộc vào lực tác động: gõ mạnh thì tiếng to, gõ nhẹ thì tiếng nhỏ. Vì vậy khi chơi trống, muốn tiếng to ta gõ mạnh tay, muốn tiếng nhỏ ta gõ nhẹ tay. Biết điều chỉnh to – nhỏ giúp tiếng gõ đệm phù hợp với bài hát.']
 ]);
 add(M,1,'Hát và nghe nhạc',[
  [1,'Trước khi hát, em cần làm gì để lấy hơi?','hít vào nhẹ nhàng bằng mũi','hít thật mạnh bằng miệng','nín thở thật lâu','vừa nói vừa hít'],
  [1,'Khi hát, miệng của em nên như thế nào?','mở tròn, rõ ràng','ngậm chặt','mở thật rộng hết mức','nghiêng sang một bên'],
  [1,'Khi hát theo đàn hoặc theo nhạc, em cần hát như thế nào?','khớp với nhạc, không nhanh không chậm','nhanh hơn nhạc','chậm hơn nhạc','không cần để ý đến nhạc'],
  [2,'Khi cả lớp cùng hát, em cần chú ý điều gì?','hát hòa giọng cùng các bạn','hát to hơn tất cả các bạn','hát chậm hơn các bạn','hát một bài khác với các bạn'],
  [2,'Khi nghe một bản nhạc, điều em nên làm là gì?','ngồi yên, chú ý lắng nghe','nói chuyện với bạn','đứng lên đi lại','lấy đồ chơi ra chơi'],
  [2,'Hát đúng lời ca có nghĩa là gì?','hát đủ và đúng các từ trong bài hát','hát thật to','hát thật nhanh','hát tùy ý theo trí nhớ'],
  [3,'Em hãy nêu tư thế đúng khi đứng hát.','Đứng thẳng, hai chân vững, đầu không cúi, hai tay thả lỏng tự nhiên, mắt nhìn thẳng, miệng mở rõ khi hát.'],
  [3,'Em hãy kể tên một bài hát đã học ở lớp 1 và cho biết bài hát đó vui tươi hay nhẹ nhàng.','HS nêu đúng tên một bài hát đã học trong sách Âm nhạc 1 và nhận xét đúng tính chất bài hát (vui tươi, rộn ràng hoặc nhẹ nhàng, êm ái).'],
  [3,'Hãy hát một câu của bài hát em đã học rồi tự nhận xét mình đã hát rõ lời chưa.','HS hát được một câu đúng giai điệu, lời ca; tự nhận xét trung thực về độ rõ lời và nêu được điểm cần sửa.'],
  [4,'Vì sao khi hát em không nên gào to hoặc hát quá sức? Nêu cách hát để giọng luôn đẹp.','Gào to hoặc hát quá sức làm dây thanh bị căng, dễ đau họng, khàn tiếng và hát sai cao độ. Để giọng đẹp, em cần hát vừa phải, lấy hơi nhẹ nhàng, mở miệng rõ, hát hòa giọng với các bạn và uống nước ấm, không la hét.']
 ]);
 add(M,1,'Nhạc cụ gõ',[
  [1,'Thanh phách thường được làm bằng chất liệu gì?','tre hoặc gỗ','sắt','nhựa mềm','giấy'],
  [1,'Để chơi trống nhỏ, em dùng gì để gõ vào mặt trống?','dùi trống','thước kẻ','bút chì','bàn chân'],
  [1,'Song loan tạo ra âm thanh khi em làm gì?','gõ hoặc nhịp vào mặt gõ của nó','thổi vào nó','kéo dây của nó','xoay tròn nó'],
  [2,'Hai thanh phách tạo ra âm thanh khi nào?','khi gõ hai thanh vào nhau','khi thổi vào thanh phách','khi lắc nhẹ trong tay','khi để yên trên bàn'],
  [2,'Khi gõ đệm theo nhịp bài hát, em cần gõ như thế nào?','đều đặn, khớp với bài hát','lúc nhanh lúc chậm tùy ý','càng to càng tốt','gõ liên tục không nghỉ'],
  [2,'Sau khi dùng xong nhạc cụ gõ, em nên làm gì?','cất đúng chỗ, giữ gìn cẩn thận','ném vào góc lớp','để trên sàn','mang về nhà chơi'],
  [3,'Em hãy kể tên ba nhạc cụ gõ đã học ở lớp 1.','Trống nhỏ, thanh phách, song loan.'],
  [3,'Em hãy mô tả cách cầm và gõ thanh phách cho đúng.','Mỗi tay cầm một thanh phách, cầm chắc nhưng không gò bó; gõ hai thanh vào nhau theo nhịp, lực vừa phải để tiếng kêu rõ, gọn.'],
  [3,'Hãy gõ đệm bằng trống nhỏ theo nhịp cho một bài hát em thích.','HS gõ đều, đúng nhịp, tiếng gõ khớp với bài hát, không quá to làm át tiếng hát.'],
  [4,'Vì sao khi hát có nhạc cụ gõ đệm thì bài hát nghe hay hơn? Em sẽ chọn gõ to hay nhỏ khi đệm cho bạn hát và vì sao?','Nhạc cụ gõ giúp giữ nhịp đều, tạo không khí rộn ràng và làm bài hát sinh động hơn. Khi đệm cho bạn hát, em nên gõ vừa phải hoặc nhỏ để không át tiếng hát, giúp người nghe vẫn nghe rõ lời ca và giai điệu.']
 ]);
 add(M,1,'Thói quen nghe và biểu diễn',[
  [1,'Khi lên biểu diễn trước lớp, em cần làm gì đầu tiên?','chào khán giả','hát ngay thật nhanh','quay lưng về phía các bạn','ngồi xuống sàn'],
  [1,'Khi biểu diễn xong, em nên làm gì?','cúi chào và cảm ơn khán giả','chạy nhanh về chỗ','nói to với bạn','bỏ nhạc cụ xuống đất'],
  [1,'Khi xem bạn biểu diễn, hành động nào là đúng?','ngồi ngay ngắn, chăm chú xem','chê bai bạn','nói chuyện riêng','đứng lên che tầm nhìn của bạn khác'],
  [2,'Khi hát, nét mặt của em nên như thế nào?','tươi tắn, tự nhiên','cúi gằm xuống','nhăn nhó','quay sang nhìn chỗ khác'],
  [2,'Khi bạn hát chưa đúng, em nên làm gì?','động viên và góp ý nhẹ nhàng','cười chê bạn','bỏ ra ngoài','la hét để bạn dừng lại'],
  [2,'Trước buổi biểu diễn, em nên làm gì để tự tin hơn?','luyện tập bài hát nhiều lần','không tập để giữ sức','hét thật to cho đỡ hồi hộp','không ăn uống gì'],
  [3,'Em hãy nêu ba việc cần làm khi lên biểu diễn trước lớp.','Ví dụ: chào khán giả, đứng ngay ngắn và tự tin, hát rõ lời đúng nhịp, nét mặt tươi tắn, cúi chào cảm ơn khi hát xong.'],
  [3,'Theo em, khán giả tốt là người như thế nào khi xem biểu diễn?','Khán giả tốt ngồi trật tự, chăm chú theo dõi, không nói chuyện riêng, vỗ tay cổ vũ khi bạn biểu diễn xong, không chê bai bạn.'],
  [3,'Em hãy biểu diễn một bài hát đã học với động tác vỗ tay theo nhịp.','HS hát đúng giai điệu, lời ca, vỗ tay đều theo nhịp, tư thế tự tin, có chào khán giả trước và sau khi hát.'],
  [4,'Vì sao cần luyện tập trước khi biểu diễn? Nếu em quên lời khi đang hát trước lớp, em sẽ làm gì?','Luyện tập giúp em nhớ lời, hát đúng nhịp và tự tin, biểu diễn mới hay. Nếu quên lời, em cần bình tĩnh, tiếp tục hát theo giai điệu hoặc hát theo các bạn, không dừng lại đột ngột hay bỏ chạy; sau đó về nhà luyện lại chỗ đã quên.']
 ]);

 /* ===== LỚP 2 ===== */
 add(M,2,'Nghe và cảm nhận âm thanh',[
  [1,'Âm thanh nào sau đây là âm thanh trong gia đình?','tiếng chuông đồng hồ','tiếng sóng biển','tiếng chim rừng','tiếng thác đổ'],
  [1,'Khi một bài hát được hát nhanh dần lên, ta nói bài hát thay đổi về yếu tố gì?','nhịp độ','cao độ','lời ca','số người hát'],
  [1,'Tiếng vỗ tay kéo dài khi khán giả tán thưởng thuộc loại âm thanh nào?','âm thanh dài','âm thanh ngắn','âm thanh rất nhỏ','âm thanh rất cao'],
  [2,'Một bài hát ru em thường có nhịp độ như thế nào?','chậm, nhẹ nhàng','rất nhanh, sôi nổi','lúc nhanh lúc chậm liên tục','mạnh mẽ, dồn dập'],
  [2,'Khi nghe một bản nhạc có tiếng to dần rồi nhỏ dần, đó là sự thay đổi về yếu tố nào?','độ to – nhỏ của âm thanh','tên bài hát','số nốt nhạc','người sáng tác'],
  [2,'Khi nghe bạn gõ hai âm, âm thứ nhất ngân lâu, âm thứ hai dứt ngay. Hai âm đó khác nhau về điều gì?','độ dài – ngắn','độ cao – thấp','tên nhạc cụ','màu sắc nhạc cụ'],
  [3,'Em hãy kể hai âm thanh có độ cao khác nhau mà em từng nghe và cho biết tiếng nào cao hơn.','Ví dụ: tiếng chim hót cao hơn tiếng trống; tiếng chuông xe đạp cao hơn tiếng còi ô tô tải.'],
  [3,'Hãy dùng tay gõ lên bàn để thể hiện một đoạn âm thanh từ nhỏ đến to dần.','HS gõ bắt đầu nhẹ rồi mạnh dần, thể hiện rõ sự tăng dần về độ to.'],
  [3,'Em hãy nêu cảm nhận của mình sau khi nghe một bản nhạc vui tươi.','HS nêu được cảm xúc phù hợp: thấy vui vẻ, phấn khởi, muốn vận động theo nhịp…; diễn đạt rõ ràng.'],
  [4,'Vì sao cùng một bài hát, khi hát nhanh và khi hát chậm lại đem đến cảm xúc khác nhau cho người nghe? Cho ví dụ.','Nhịp độ ảnh hưởng đến tính chất âm nhạc: hát nhanh tạo cảm giác vui tươi, sôi nổi, rộn ràng; hát chậm tạo cảm giác êm dịu, trầm lắng, tha thiết. Ví dụ bài hát ru hát chậm để em bé dễ ngủ, bài hành khúc hát nhanh và mạnh để tạo khí thế.']
 ]);
 add(M,2,'Hát và nghe nhạc',[
  [1,'Khi hát một bài hát có nhịp độ nhanh, em cần chú ý điều gì?','hát rõ lời, giữ đúng nhịp','hát thật chậm lại','bỏ bớt lời cho kịp','hát thật nhỏ'],
  [1,'Hát với sắc thái vui tươi nghĩa là hát như thế nào?','rộn ràng, tươi sáng','buồn bã, chậm rãi','thật nhỏ, thì thầm','ngắt quãng liên tục'],
  [1,'Khi hát nối tiếp theo nhóm, mỗi nhóm cần làm gì?','hát đúng câu của nhóm mình và vào đúng lúc','hát tất cả các câu','hát cùng lúc với nhóm khác','hát câu nào tùy ý'],
  [2,'Khi hát một bài dân ca, em cần thể hiện như thế nào?','mềm mại, đúng tính chất của bài','thật nhanh và mạnh','hô to như khẩu hiệu','không cần quan tâm sắc thái'],
  [2,'Lấy hơi ở cuối câu hát giúp ích gì?','hát câu tiếp theo trọn vẹn, không bị đứt hơi','hát to hơn','hát nhanh hơn','không giúp ích gì'],
  [2,'Khi nghe một bản nhạc không lời, em có thể cảm nhận điều gì?','tính chất vui hay buồn, nhanh hay chậm của bản nhạc','lời bài hát','tên người hát','số câu của bài hát'],
  [3,'Em hãy kể tên một bài hát đã học ở lớp 2 và nêu tính chất của bài hát đó.','HS nêu đúng tên một bài hát trong sách Âm nhạc 2 và nhận xét đúng tính chất (vui tươi, trong sáng, nhẹ nhàng, tha thiết…).'],
  [3,'Em hãy nêu các bước để học thuộc một bài hát mới.','Nghe mẫu cả bài, đọc lời ca, tập hát từng câu theo giáo viên, hát nối các câu, hát cả bài kết hợp gõ đệm hoặc vận động.'],
  [3,'Hãy hát một bài hát đã học bằng hai cách: hát thường và hát với sắc thái nhẹ nhàng hơn, rồi nói cảm nhận của em.','HS hát được hai cách khác nhau về sắc thái, nhận ra cách hát thay đổi làm bài hát nghe khác đi.'],
  [4,'Vì sao cần thể hiện đúng sắc thái khi hát? Hãy giải thích bằng một ví dụ về bài hát vui và bài hát nhẹ nhàng.','Sắc thái giúp truyền tải đúng nội dung và cảm xúc của bài hát; hát sai sắc thái làm người nghe không cảm nhận được ý nghĩa bài hát. Ví dụ bài hát vui tươi cần hát rộn ràng, tươi sáng; bài hát nhẹ nhàng cần hát mềm mại, êm ái. Nếu hát bài ru em mà hát to, nhanh thì không còn tính chất ru ngủ nữa.']
 ]);
 add(M,2,'Nhạc cụ gõ',[
  [1,'Tem-bơ-rin (trống lắc) tạo ra âm thanh bằng cách nào?','lắc hoặc vỗ vào mặt trống','thổi vào','kéo bằng vĩ','gảy dây'],
  [1,'Trai-en-gô (nhạc cụ hình tam giác) được làm bằng chất liệu gì?','kim loại','tre','gỗ','vải'],
  [1,'Khi chơi trai-en-gô, em cần làm gì để tiếng ngân vang?','treo lỏng trên dây và gõ bằng que kim loại','bóp chặt trong tay rồi gõ','đặt lên bàn rồi gõ','gõ bằng tay không'],
  [2,'Trong các nhạc cụ sau, nhạc cụ nào không phải nhạc cụ gõ?','sáo','trống nhỏ','thanh phách','tem-bơ-rin'],
  [2,'Gõ đệm theo phách khác gõ đệm theo nhịp ở điểm nào?','gõ theo phách gõ nhiều tiếng hơn, đều theo từng phách','gõ theo phách gõ ít tiếng hơn','hai cách giống nhau hoàn toàn','gõ theo phách không cần đều'],
  [2,'Nhạc cụ nào có âm thanh trong, ngân dài, thường dùng điểm nhịp nhẹ?','trai-en-gô','trống nhỏ','thanh phách','song loan'],
  [3,'Em hãy kể tên hai nhạc cụ gõ mới được làm quen ở lớp 2 và cách chơi mỗi nhạc cụ.','Tem-bơ-rin: cầm vành trống, lắc hoặc vỗ vào mặt trống. Trai-en-gô: cầm dây treo, dùng que kim loại gõ vào cạnh tam giác.'],
  [3,'Em hãy gõ đệm theo phách cho một bài hát đã học bằng thanh phách hoặc song loan.','HS gõ đều từng phách, khớp với bài hát, lực vừa phải, tiếng rõ.'],
  [3,'Theo em, cần làm gì để giữ gìn nhạc cụ gõ ở lớp?','Dùng nhẹ tay, không ném, không dùng để đùa nghịch; cất đúng nơi quy định sau khi dùng; lau sạch nếu bị bẩn.'],
  [4,'Khi cả nhóm gõ đệm cho một bài hát mà dùng nhiều loại nhạc cụ gõ khác nhau, em sẽ phân công như thế nào để tiếng gõ hòa hợp? Giải thích.','Nên phân công mỗi nhạc cụ một cách gõ: trống nhỏ hoặc song loan gõ theo nhịp (ít tiếng, giữ nhịp chính), thanh phách gõ theo phách (đều hơn), trai-en-gô hoặc tem-bơ-rin điểm vào đầu câu hoặc cuối câu. Làm vậy các tiếng gõ không chồng lên nhau quá nhiều, bài hát vừa đều nhịp vừa sinh động, không bị ồn.']
 ]);
 add(M,2,'Thói quen nghe và biểu diễn',[
  [1,'Khi biểu diễn theo nhóm, các bạn trong nhóm cần làm gì?','phối hợp nhịp nhàng, đều nhau','mỗi người hát một kiểu','ai hát to nhất thì được khen','không cần nhìn nhau'],
  [1,'Khi xem biểu diễn, lúc nào ta nên vỗ tay?','khi bài biểu diễn kết thúc','liên tục trong khi bạn đang hát','khi bạn hát sai','không bao giờ vỗ tay'],
  [1,'Khi lên sân khấu, em cần bước đi như thế nào?','tự tin, ngay ngắn','chạy thật nhanh','vừa đi vừa đùa với bạn','cúi gằm mặt'],
  [2,'Biểu diễn có kết hợp vận động phụ họa nghĩa là gì?','vừa hát vừa làm động tác phù hợp lời ca','chỉ đứng yên hát','nhảy tự do không theo bài hát','chỉ làm động tác không hát'],
  [2,'Khi được giáo viên góp ý sau khi biểu diễn, em nên có thái độ thế nào?','lắng nghe, cảm ơn và sửa chữa','buồn và không hát nữa','cãi lại','không quan tâm'],
  [2,'Khi hát trong giờ chào cờ, em cần hát như thế nào?','nghiêm trang, đúng nhịp, rõ lời','hát đùa cho vui','hát thật nhỏ không ai nghe','hát nhanh để kết thúc sớm'],
  [3,'Em hãy nêu cách tập một bài hát theo nhóm để biểu diễn đều nhau.','Thống nhất cách hát, nhịp độ và động tác; tập từng câu rồi ghép cả bài; cử một bạn bắt nhịp; tập nhiều lần và nhìn nhau khi biểu diễn.'],
  [3,'Theo em, vì sao cần vỗ tay cổ vũ khi bạn biểu diễn xong?','Vỗ tay là cách thể hiện sự tôn trọng, động viên bạn, giúp bạn tự tin hơn và tạo không khí vui vẻ cho buổi biểu diễn.'],
  [3,'Hãy biểu diễn một bài hát đã học theo nhóm với hình thức hát nối tiếp.','Các nhóm hát đúng câu của mình, vào đúng lúc, giọng hát đều, tư thế biểu diễn tự tin.'],
  [4,'Em hãy phân tích vì sao một nhóm biểu diễn hay không chỉ cần hát đúng mà còn cần phối hợp tốt với nhau.','Hát đúng là cơ sở, nhưng khi biểu diễn nhóm, nếu mỗi người hát nhanh chậm khác nhau hoặc làm động tác không khớp thì bài biểu diễn sẽ rời rạc, người nghe khó cảm nhận. Phối hợp tốt (cùng nhịp, cùng sắc thái, động tác đều, biết lắng nghe nhau) làm tiết mục hài hòa, đẹp mắt và thể hiện tinh thần đoàn kết của nhóm.']
 ]);

 /* ===== LỚP 3 ===== */
 add(M,3,'Lí thuyết âm nhạc',[
  [1,'Kí hiệu đặt ở đầu khuông nhạc để xác định tên nốt nhạc gọi là gì?','khóa Son','dấu lặng','vạch nhịp','dấu nối'],
  [1,'Trên khuông nhạc, nốt nhạc được ghi ở vị trí nào?','trên các dòng kẻ và trong các khe','chỉ ở phía trên khuông nhạc','chỉ ở phía dưới khuông nhạc','ở bất kì chỗ nào'],
  [1,'Khóa Son được viết bắt đầu từ dòng kẻ thứ mấy của khuông nhạc (tính từ dưới lên)?','dòng thứ 2','dòng thứ 1','dòng thứ 3','dòng thứ 5'],
  [2,'Giữa 5 dòng kẻ của khuông nhạc có bao nhiêu khe?','4 khe','5 khe','3 khe','6 khe'],
  [2,'Hình nốt nào có thân nốt rỗng (không tô đen) và có đuôi?','nốt trắng','nốt đen','nốt móc đơn','nốt móc kép'],
  [2,'Nốt nhạc nằm trên dòng kẻ thứ 2 của khuông nhạc có khóa Son là nốt gì?','Son','Đô','Mi','La'],
  [3,'Em hãy nêu các bộ phận của một nốt nhạc (nốt đen) ghi trên khuông nhạc.','Nốt đen gồm thân nốt (hình bầu dục tô đen) và đuôi nốt (nét thẳng đứng); nốt móc đơn có thêm dấu móc ở đuôi.'],
  [3,'Em hãy so sánh độ dài của nốt trắng, nốt đen và nốt móc đơn.','Nốt trắng dài nhất, bằng 2 nốt đen; nốt đen bằng 2 nốt móc đơn; nốt móc đơn ngắn nhất trong ba hình nốt.'],
  [3,'Hãy kể tên các nốt nhạc nằm trên 5 dòng kẻ của khuông nhạc có khóa Son, tính từ dưới lên.','Mi – Son – Si – Rê – Pha.'],
  [4,'Vì sao cần có khóa Son ở đầu khuông nhạc? Nếu không có khóa Son thì điều gì xảy ra khi đọc nốt nhạc?','Khóa Son quy định dòng kẻ thứ 2 là nốt Son, từ đó xác định tên và cao độ của tất cả các nốt khác trên khuông. Nếu không có khóa Son, các nốt chỉ là những dấu chấm trên dòng kẻ, không biết tên nốt nào, không đọc được cao độ, bản nhạc không thể hát hoặc chơi đúng.']
 ]);
 add(M,3,'Nhạc cụ',[
  [1,'Ri-coóc-đơ (recorder) là loại nhạc cụ gì?','nhạc cụ thổi','nhạc cụ gõ','nhạc cụ dây','nhạc cụ bàn phím'],
  [1,'Kèn phím là nhạc cụ vừa dùng hơi thổi vừa dùng gì để tạo âm thanh?','bấm các phím','gõ dùi','kéo vĩ','lắc'],
  [1,'Ma-ra-cát (maracas) tạo âm thanh khi em làm gì?','lắc','thổi','gảy','ấn phím'],
  [2,'Khi chơi ri-coóc-đơ, em cần đặt miệng vào bộ phận nào?','đầu thổi (phần đầu kèn)','lỗ bấm ở giữa','đuôi kèn','bất kì chỗ nào'],
  [2,'Khi thổi ri-coóc-đơ, hơi thổi quá mạnh sẽ dẫn đến điều gì?','âm thanh bị chói, sai cao độ','âm thanh êm hơn','không ảnh hưởng gì','kèn kêu to và hay hơn'],
  [2,'Khi bấm lỗ trên ri-coóc-đơ, ngón tay cần như thế nào?','bịt kín lỗ bằng phần mềm của đầu ngón','chỉ chạm nhẹ hờ','dùng móng tay bấm','bấm bằng hai ngón cùng lúc'],
  [3,'Em hãy nêu cách giữ gìn, vệ sinh ri-coóc-đơ sau khi chơi.','Lau khô đầu thổi và thân kèn, không để nước bọt đọng bên trong; cất vào hộp hoặc túi; không dùng chung đầu thổi với bạn để bảo đảm vệ sinh.'],
  [3,'Hãy kể tên hai nhạc cụ gõ tự tạo từ vật liệu đơn giản mà em có thể làm.','Ví dụ: hộp nhựa đựng hạt đậu làm nhạc cụ lắc; hai nắp chai gõ vào nhau; chai thủy tinh có nước gõ bằng que.'],
  [3,'Em hãy mô tả tư thế đúng khi chơi kèn phím.','Ngồi hoặc đứng thẳng, kèn đặt vững (trên bàn hoặc đeo dây), tay phải bấm phím, miệng ngậm ống thổi, thổi hơi đều và nhẹ.'],
  [4,'Vì sao cùng một nốt nhạc nhưng khi thổi ri-coóc-đơ, có bạn thổi ra đúng, có bạn thổi ra tiếng chói hoặc không kêu? Nêu hai nguyên nhân và cách khắc phục.','Nguyên nhân thường gặp: bấm lỗ không kín làm hơi thoát ra, tiếng không kêu hoặc sai nốt; thổi hơi quá mạnh khiến tiếng chói, thổi quá yếu thì không rõ. Khắc phục: bấm kín lỗ bằng phần mềm đầu ngón tay, thổi hơi đều, nhẹ như thở ra bình thường, luyện từng nốt chậm trước khi ghép bài.']
 ]);
 add(M,3,'Hát và thường thức âm nhạc',[
  [1,'Hình thức một người hát gọi là gì?','đơn ca','song ca','tốp ca','đồng ca'],
  [1,'Hình thức hai người hát cùng nhau gọi là gì?','song ca','đơn ca','tốp ca','hợp xướng'],
  [1,'Khi nhiều người (cả lớp) cùng hát một bài gọi là hình thức gì?','đồng ca','đơn ca','song ca','độc tấu'],
  [2,'Tốp ca là hình thức hát của bao nhiêu người?','một nhóm nhỏ, thường từ 3 đến khoảng 10 người','một người','hai người','hàng trăm người'],
  [2,'Khi hát có lĩnh xướng, người lĩnh xướng làm gì?','hát một đoạn riêng, sau đó cả nhóm hát tiếp','hát nhỏ nhất','chỉ gõ đệm','chỉ làm động tác'],
  [2,'Khi hát đồng ca, điều quan trọng nhất là gì?','hòa giọng, đều nhịp với mọi người','mỗi người hát một tốc độ','ai hát to nhất là tốt','không cần nhìn người bắt nhịp'],
  [3,'Em hãy phân biệt hình thức đơn ca và tốp ca.','Đơn ca là một người hát; tốp ca là một nhóm nhỏ nhiều người cùng hát, cần phối hợp đều nhau về nhịp, lời ca và sắc thái.'],
  [3,'Em hãy kể tên một bài hát đã học ở lớp 3 và cho biết bài hát đó nói về chủ đề gì.','HS nêu đúng tên một bài trong sách Âm nhạc 3 và nêu được chủ đề (ví dụ: mái trường, quê hương, gia đình, thiếu nhi…).'],
  [3,'Em hãy trình bày một bài hát đã học theo hình thức song ca cùng một bạn.','Hai HS hát hòa giọng, đúng giai điệu và lời ca, đều nhịp, phối hợp tự nhiên.'],
  [4,'Vì sao khi hát tốp ca các bạn phải nhìn người bắt nhịp và lắng nghe nhau? Nếu không làm vậy, tiết mục sẽ như thế nào?','Người bắt nhịp giúp cả nhóm bắt đầu cùng lúc và giữ cùng một tốc độ; lắng nghe nhau giúp điều chỉnh giọng để hòa đều, không ai hát to hoặc nhanh quá. Nếu không làm vậy, nhóm sẽ hát lệch nhịp, người trước người sau, giọng không đều, tiết mục trở nên lộn xộn và khó nghe.']
 ]);
 add(M,3,'Thói quen nghe và biểu diễn',[
  [1,'Khi nghe nhạc trong lớp, em nên giữ thái độ như thế nào?','trật tự, tập trung','nói chuyện riêng','làm việc khác','đi lại tự do'],
  [1,'Khi biểu diễn, em nên hướng mặt về đâu?','về phía khán giả','về phía tường','xuống sàn','về phía cửa'],
  [1,'Trước khi biểu diễn, việc em nên làm là gì?','kiểm tra trang phục, nhạc cụ và chuẩn bị tâm thế','ăn thật nhiều','la hét để lấy tinh thần','ngủ ngay trước giờ diễn'],
  [2,'Việc nhận xét bài biểu diễn của bạn nên như thế nào?','nêu điểm tốt trước, góp ý nhẹ nhàng điểm cần sửa','chỉ chê điểm yếu','không nhận xét gì','nhận xét thật to cho cả lớp nghe'],
  [2,'Nghe nhạc với âm lượng quá lớn trong thời gian dài có hại gì?','làm giảm khả năng nghe, hại tai','giúp tai nghe tốt hơn','không ảnh hưởng gì','giúp nhớ bài hát nhanh hơn'],
  [2,'Khi biểu diễn với nhạc cụ gõ đệm, em cần sắp xếp thế nào?','người gõ đệm và người hát phối hợp nhịp nhàng, tiếng gõ không át tiếng hát','gõ càng to càng tốt','gõ không cần theo bài hát','người gõ đệm đứng quay lưng về khán giả'],
  [3,'Em hãy nêu ba điều cần chú ý để trở thành người nghe nhạc có văn hóa.','Giữ trật tự khi nghe; không nói chuyện, không làm việc riêng; vỗ tay đúng lúc; tôn trọng người biểu diễn; nghe với âm lượng vừa phải.'],
  [3,'Em hãy xây dựng chương trình biểu diễn ngắn gồm hai tiết mục cho nhóm của mình.','HS nêu được hai tiết mục (ví dụ: hát tốp ca có gõ đệm; hát kết hợp vận động), phân công người hát, người gõ đệm, thứ tự biểu diễn.'],
  [3,'Hãy biểu diễn một bài hát đã học với hình thức có lĩnh xướng và đồng ca.','Người lĩnh xướng hát rõ, tự tin phần riêng; cả nhóm vào đúng lúc, hòa giọng đều, tư thế biểu diễn tốt.'],
  [4,'Theo em, vì sao việc chuẩn bị kĩ (trang phục, nhạc cụ, luyện tập) lại ảnh hưởng đến chất lượng buổi biểu diễn? Hãy lấy một ví dụ.','Chuẩn bị kĩ giúp tiết mục diễn ra trôi chảy, người biểu diễn tự tin và không bị gián đoạn. Ví dụ nếu không kiểm tra nhạc cụ, đến lúc diễn trống bị hỏng dây hoặc thanh phách thiếu một chiếc sẽ làm cả nhóm lúng túng; nếu không luyện tập, các bạn dễ quên lời, lệch nhịp, tiết mục mất hay.']
 ]);

 /* ===== LỚP 4 ===== */
 add(M,4,'Lí thuyết âm nhạc',[
  [1,'Trong nhịp 2/4, phách thứ nhất là phách gì?','phách mạnh','phách nhẹ','phách lấy đà','phách nghỉ'],
  [1,'Dấu lặng đen có độ dài bằng hình nốt nào?','nốt đen','nốt trắng','nốt móc đơn','nốt tròn'],
  [1,'Trong nhịp 2/4, số 4 ở dưới cho biết điều gì?','mỗi phách bằng một nốt đen','mỗi ô nhịp có 4 phách','bài hát có 4 câu','mỗi phách bằng một nốt tròn'],
  [2,'Đường kẻ thẳng đứng chia khuông nhạc thành các ô nhịp gọi là gì?','vạch nhịp','khóa Son','dấu nối','dấu lặng'],
  [2,'Nốt tròn có độ dài bằng mấy nốt trắng?','2 nốt trắng','1 nốt trắng','4 nốt trắng','3 nốt trắng'],
  [2,'Một ô nhịp 2/4 có thể gồm những hình nốt nào sau đây?','một nốt đen và hai nốt móc đơn','ba nốt đen','một nốt tròn','hai nốt trắng'],
  [3,'Em hãy giải thích ý nghĩa của số chỉ nhịp 2/4.','Số 2 cho biết mỗi ô nhịp có 2 phách; số 4 cho biết mỗi phách có độ dài bằng một nốt đen. Phách 1 mạnh, phách 2 nhẹ.'],
  [3,'Em hãy phân biệt dấu lặng đen và dấu lặng đơn.','Dấu lặng đen là thời gian nghỉ dài bằng một nốt đen; dấu lặng đơn là thời gian nghỉ dài bằng một nốt móc đơn (bằng nửa dấu lặng đen).'],
  [3,'Hãy sắp xếp các hình nốt tròn, đen, trắng, móc đơn theo thứ tự từ dài đến ngắn.','Nốt tròn – nốt trắng – nốt đen – nốt móc đơn.'],
  [4,'Vì sao khi gõ đệm theo nhịp 2/4, ta thường gõ mạnh ở phách 1 và nhẹ ở phách 2? Việc này giúp gì cho người hát?','Nhịp 2/4 có phách 1 là phách mạnh, phách 2 là phách nhẹ; gõ mạnh – nhẹ đúng như vậy làm nổi rõ chu kì của nhịp. Người hát nghe tiếng gõ mạnh sẽ biết đâu là đầu ô nhịp, dễ vào câu đúng chỗ, giữ nhịp đều và thể hiện đúng tính chất nhịp đi, nhịp hành khúc của bài.']
 ]);
 add(M,4,'Nhạc cụ',[
  [1,'Đàn nhị là nhạc cụ dân tộc Việt Nam có mấy dây?','2 dây','1 dây','4 dây','6 dây'],
  [1,'Đàn nhị được chơi bằng cách nào?','kéo bằng vĩ (cung)','gõ bằng dùi','thổi','lắc'],
  [1,'Đàn tranh của Việt Nam thường có bao nhiêu dây?','16 dây','1 dây','2 dây','6 dây'],
  [2,'Đàn tranh được chơi bằng cách nào?','gảy dây bằng móng','kéo vĩ','thổi','gõ bằng dùi'],
  [2,'Nhạc cụ nào sau đây là nhạc cụ gõ của dân tộc Việt Nam?','trống cơm','đàn nhị','sáo trúc','đàn tranh'],
  [2,'Khi chơi nhạc cụ giai điệu (ri-coóc-đơ, kèn phím) theo bản nhạc, em cần đọc được điều gì?','tên nốt và hình nốt','chỉ lời ca','chỉ tên bài hát','chỉ tên tác giả'],
  [3,'Em hãy kể tên hai nhạc cụ dân tộc được chơi bằng cách gảy và hai nhạc cụ được chơi bằng cách kéo vĩ hoặc thổi.','Gảy: đàn tranh, đàn nguyệt, đàn bầu (gảy que). Kéo vĩ: đàn nhị. Thổi: sáo trúc, kèn.'],
  [3,'Hãy trình bày cách giữ nhịp đều khi nhóm cùng chơi ri-coóc-đơ hoặc kèn phím một bài đọc nhạc.','Một bạn đếm phách hoặc gõ nhịp; cả nhóm tập chậm từng câu rồi tăng tốc độ; lắng nghe nhau, thổi hơi đều, vào và kết thúc cùng lúc.'],
  [3,'Em hãy mô tả hình dáng và cách chơi đàn tranh.','Đàn tranh có thân dài, mặt đàn cong, nhiều dây (thường 16 dây) căng trên các con nhạn; người chơi gảy dây bằng móng đeo ở ngón tay, tay trái nhấn dây để tạo độ rung, luyến.'],
  [4,'Em hãy so sánh đàn nhị và đàn tranh về số dây và cách chơi, từ đó giải thích vì sao âm thanh hai đàn khác nhau.','Đàn nhị có 2 dây, chơi bằng cách kéo vĩ nên âm thanh ngân dài, liền mạch, giống tiếng người hát. Đàn tranh có nhiều dây (16 dây), chơi bằng cách gảy nên âm thanh trong, vang rồi tắt dần, nghe lấp lánh. Cách tạo âm (kéo vĩ hay gảy) và cấu tạo khác nhau làm âm sắc hai đàn khác nhau rõ rệt.']
 ]);
 add(M,4,'Hát và thường thức âm nhạc',[
  [1,'Nhạc sĩ Lưu Hữu Phước là tác giả bài hát nào dành cho thiếu nhi?','Thiếu nhi thế giới liên hoan','Tiến quân ca','Em yêu trường em','Chiếc đèn ông sao'],
  [1,'Bài hát "Chiếc đèn ông sao" là sáng tác của nhạc sĩ nào?','Phạm Tuyên','Văn Cao','Lưu Hữu Phước','Hoàng Vân'],
  [1,'Hát với sắc thái "trong sáng, vui tươi" là cách hát như thế nào?','giọng sáng, nhẹ, tươi vui','thật trầm và buồn','gào to hết sức','chậm, nặng nề'],
  [2,'Khi hát một bài hành khúc, ta cần thể hiện tính chất gì?','khỏe khoắn, nhịp đi dứt khoát','mềm mại, ru ngủ','thì thầm, nhỏ nhẹ','chậm rãi, buồn'],
  [2,'Nhạc sĩ Lưu Hữu Phước còn là tác giả bài hát nổi tiếng nào sau đây?','Lên đàng','Tiến quân ca','Em yêu trường em','Như có Bác Hồ trong ngày vui đại thắng'],
  [2,'Khi hát đúng cao độ nghĩa là gì?','hát đúng độ cao thấp của từng nốt theo giai điệu','hát thật to','hát đúng lời','hát nhanh đúng tốc độ'],
  [3,'Em hãy nêu một vài hiểu biết của em về nhạc sĩ Lưu Hữu Phước.','Lưu Hữu Phước là nhạc sĩ nổi tiếng của Việt Nam, tác giả nhiều bài hát hào hùng như Lên đàng, Tiến về Sài Gòn và nhiều bài cho thiếu nhi như Thiếu nhi thế giới liên hoan, Reo vang bình minh. Ông được tặng Giải thưởng Hồ Chí Minh về văn học nghệ thuật.'],
  [3,'Em hãy phân biệt cách hát bài hát tính chất hành khúc và bài hát tính chất trữ tình.','Bài hành khúc hát khỏe khoắn, nhịp rõ, dứt khoát, âm thanh đầy đặn; bài trữ tình hát mềm mại, liền tiếng, tình cảm, sắc thái to nhỏ linh hoạt.'],
  [3,'Hãy trình bày một bài hát đã học ở lớp 4 kết hợp gõ đệm theo nhịp và thể hiện đúng sắc thái.','HS hát đúng giai điệu, lời ca; gõ đệm đúng nhịp; thể hiện đúng tính chất bài hát (vui tươi hoặc tình cảm…).'],
  [4,'Vì sao các bài hát của nhạc sĩ Lưu Hữu Phước viết cho thiếu nhi lại được nhiều thế hệ yêu thích? Hãy giải thích dựa trên tính chất âm nhạc.','Các bài hát thiếu nhi của ông có giai điệu vui tươi, trong sáng, dễ hát, dễ nhớ; nhịp điệu rõ ràng phù hợp với hoạt động tập thể, sinh hoạt Đội; nội dung ca ngợi tình bạn, hòa bình, niềm vui tuổi thơ. Vì vậy các bài hát vượt qua thời gian, được dùng rộng rãi trong nhà trường và sinh hoạt thiếu nhi.']
 ]);
 add(M,4,'Thói quen nghe và biểu diễn',[
  [1,'Khi nghe một tác phẩm âm nhạc, em nên nghe như thế nào để cảm nhận tốt?','nghe từ đầu đến cuối, chú ý giai điệu và tính chất','nghe một đoạn rồi bỏ','vừa nghe vừa nói chuyện','chỉ nghe phần có lời'],
  [1,'Hành vi nào thể hiện sự tôn trọng người biểu diễn?','giữ trật tự, vỗ tay sau tiết mục','bấm điện thoại trong khi xem','nói chuyện to','rời chỗ ngồi liên tục'],
  [1,'Khi biểu diễn, động tác phụ họa cần như thế nào?','phù hợp với lời ca và nhịp điệu','càng nhiều càng tốt','không liên quan đến bài hát','chỉ làm khi quên lời'],
  [2,'Một chương trình biểu diễn của lớp cần có người làm gì để giới thiệu tiết mục?','người dẫn chương trình','người gõ trống','người quét lớp','người đóng cửa'],
  [2,'Khi hát trước đám đông, cách nào giúp em bớt hồi hộp?','hít thở sâu, nhớ rằng mình đã luyện tập kĩ','nhìn xuống sàn suốt bài','hát thật nhanh để xong sớm','nói với khán giả rằng mình không biết hát'],
  [2,'Sau buổi biểu diễn, việc nên làm của nhóm là gì?','cùng rút kinh nghiệm những điểm tốt và chưa tốt','đổ lỗi cho bạn hát sai','không nói gì về buổi biểu diễn','bỏ hết nhạc cụ lại sân khấu'],
  [3,'Em hãy nêu các bước tổ chức một buổi biểu diễn âm nhạc nhỏ của lớp.','Chọn tiết mục và người biểu diễn; phân công người dẫn chương trình, chuẩn bị nhạc cụ, trang phục; luyện tập; sắp xếp thứ tự tiết mục; biểu diễn; nhận xét, rút kinh nghiệm.'],
  [3,'Em hãy nêu cách nhận xét một tiết mục biểu diễn của bạn một cách tích cực.','Nêu điểm hay (hát đúng, tự tin, động tác đẹp…), sau đó góp ý nhẹ nhàng điểm cần cải thiện (nhịp, lời, sắc thái), dùng lời lẽ tôn trọng và động viên.'],
  [3,'Hãy sáng tạo hình thức biểu diễn mới (hát nối tiếp, hát có lĩnh xướng, kết hợp nhạc cụ gõ) cho một bài hát đã học và thực hiện cùng nhóm.','HS đề xuất được hình thức biểu diễn hợp lí, phân công rõ, thực hiện đúng giai điệu, nhịp và sắc thái.'],
  [4,'Vì sao thói quen nghe nhạc có chọn lọc và nghe với âm lượng vừa phải lại quan trọng với học sinh? Hãy đưa ra lời khuyên cho các bạn.','Nghe nhạc có chọn lọc giúp tiếp nhận những bài hát phù hợp lứa tuổi, nội dung lành mạnh, nuôi dưỡng tình cảm tốt đẹp; nghe với âm lượng vừa phải bảo vệ tai, tránh giảm thính lực và giúp tập trung cảm nhận âm nhạc. Lời khuyên: chọn bài hát phù hợp, không đeo tai nghe mở to quá lâu, dành thời gian nghe nhạc hợp lí, không ảnh hưởng việc học và nghỉ ngơi.']
 ]);

 /* ===== LỚP 5 ===== */
 add(M,5,'Lí thuyết âm nhạc',[
  [1,'Trong nhịp 3/4, mỗi ô nhịp có mấy phách?','3 phách','2 phách','4 phách','6 phách'],
  [1,'Trong nhịp 3/4, phách nào là phách mạnh?','phách 1','phách 2','phách 3','cả 3 phách đều mạnh'],
  [1,'Trọng âm trong âm nhạc là gì?','âm được nhấn mạnh hơn các âm khác','âm có cao độ cao nhất','âm kéo dài nhất','âm cuối cùng của bài'],
  [2,'Một ô nhịp 3/4 có thể gồm những hình nốt nào?','một nốt trắng và một nốt đen','hai nốt trắng','một nốt tròn','bốn nốt đen'],
  [2,'Bài hát có tính chất nhịp nhàng, đung đưa như điệu nhảy van thường được viết ở nhịp nào?','nhịp 3/4','nhịp 2/4','nhịp 1/4','nhịp 4/4'],
  [2,'Trong nhịp 3/4, phách 2 và phách 3 là phách gì?','phách nhẹ','phách mạnh','phách lấy đà','phách nghỉ'],
  [3,'Em hãy giải thích ý nghĩa của số chỉ nhịp 3/4 và cách gõ đệm theo nhịp này.','Số 3: mỗi ô nhịp có 3 phách; số 4: mỗi phách bằng một nốt đen. Gõ đệm: phách 1 gõ mạnh, phách 2 và 3 gõ nhẹ (mạnh – nhẹ – nhẹ).'],
  [3,'Em hãy so sánh nhịp 2/4 và nhịp 3/4.','Giống: mỗi phách đều bằng một nốt đen, phách 1 là phách mạnh. Khác: nhịp 2/4 có 2 phách (mạnh – nhẹ), tính chất khỏe, nhịp đi; nhịp 3/4 có 3 phách (mạnh – nhẹ – nhẹ), tính chất nhịp nhàng, đung đưa.'],
  [3,'Hãy đọc tên và gõ đúng trường độ một chuỗi gồm nốt trắng, nốt đen, hai nốt móc đơn trong nhịp 3/4.','HS đọc đúng tên hình nốt, gõ đúng độ dài: nốt trắng 2 phách, nốt đen 1 phách, hai móc đơn mỗi nốt nửa phách; tổng cộng đủ ô nhịp.'],
  [4,'Vì sao cần xác định đúng trọng âm (phách mạnh) khi hát một bài ở nhịp 3/4? Nếu hát nhấn sai trọng âm thì bài hát sẽ như thế nào?','Trọng âm ở phách 1 tạo nên chu kì mạnh – nhẹ – nhẹ đặc trưng của nhịp 3/4, làm bài hát có tính chất nhịp nhàng, đung đưa. Nếu nhấn sai (ví dụ nhấn ở phách 2), chu kì nhịp bị phá vỡ, người nghe cảm thấy lệch nhịp, bài hát mất đi tính chất uyển chuyển vốn có và khó gõ đệm hoặc vận động theo.']
 ]);
 add(M,5,'Nhạc cụ',[
  [1,'Đàn t\'rưng là nhạc cụ của vùng nào ở Việt Nam?','Tây Nguyên','Đồng bằng sông Hồng','Đồng bằng sông Cửu Long','Ven biển miền Trung'],
  [1,'Đàn t\'rưng được làm chủ yếu từ vật liệu gì?','ống tre, nứa','kim loại','đá','gốm'],
  [1,'Cồng chiêng là loại nhạc cụ gì?','nhạc cụ gõ bằng kim loại','nhạc cụ dây','nhạc cụ thổi','nhạc cụ bàn phím'],
  [2,'Đàn t\'rưng được chơi bằng cách nào?','gõ bằng dùi vào các ống','thổi vào ống','gảy dây','kéo vĩ'],
  [2,'Khi chơi nhạc cụ giai điệu, muốn chuyển từ nốt thấp lên nốt cao, em cần làm gì?','thay đổi vị trí bấm (ngón tay hoặc phím) theo đúng nốt','thổi mạnh hơn mà không đổi ngón','gõ nhanh hơn','không cần thay đổi gì'],
  [2,'Khi hòa tấu nhạc cụ gõ với nhạc cụ giai điệu, nhạc cụ gõ có vai trò gì?','giữ nhịp và tạo màu sắc tiết tấu','chơi toàn bộ giai điệu','thay cho lời hát','át tiếng nhạc cụ giai điệu'],
  [3,'Em hãy giới thiệu ngắn về đàn t\'rưng.','Đàn t\'rưng là nhạc cụ gõ của đồng bào Tây Nguyên, làm từ các ống tre nứa dài ngắn khác nhau treo thành hàng; người chơi gõ bằng dùi, ống dài cho âm thấp, ống ngắn cho âm cao; âm thanh trong trẻo, rộn ràng.'],
  [3,'Em hãy nêu ba lưu ý để chơi tốt một bài đọc nhạc bằng ri-coóc-đơ hoặc kèn phím.','Đọc kĩ tên nốt, hình nốt và số chỉ nhịp; tập chậm từng câu, bấm đúng thế tay; thổi hơi đều, nhẹ; giữ nhịp đều, có thể đếm phách; ghép cả bài khi đã thuần thục.'],
  [3,'Hãy kể tên các nhạc cụ dân tộc đã học từ lớp 3 đến lớp 5 và phân loại theo cách chơi (gõ, gảy, kéo, thổi).','Gõ: trống, thanh phách, song loan, đàn t\'rưng, cồng chiêng. Gảy: đàn tranh, đàn bầu. Kéo: đàn nhị. Thổi: sáo trúc.'],
  [4,'Vì sao các ống của đàn t\'rưng có độ dài khác nhau? Điều này liên quan thế nào đến cao độ của âm thanh?','Mỗi ống tre nứa khi gõ sẽ rung và phát ra một âm; ống càng dài, cột không khí và thân ống rung chậm hơn nên âm trầm hơn; ống càng ngắn rung nhanh hơn nên âm cao hơn. Người làm đàn cắt các ống dài ngắn khác nhau để tạo thành dãy âm từ thấp đến cao, nhờ đó đàn t\'rưng chơi được giai điệu.']
 ]);
 add(M,5,'Hát và thường thức âm nhạc',[
  [1,'Bài hát "Em yêu trường em" là sáng tác của nhạc sĩ nào?','Hoàng Vân','Phạm Tuyên','Văn Cao','Phong Nhã'],
  [1,'Nhạc sĩ Phong Nhã là tác giả bài hát nào sau đây?','Ai yêu Bác Hồ Chí Minh hơn thiếu niên nhi đồng','Tiến quân ca','Em yêu trường em','Lên đàng'],
  [1,'Bài hát chính thức của Đội Thiếu niên Tiền phong Hồ Chí Minh (Đội ca) do nhạc sĩ nào sáng tác?','Phong Nhã','Văn Cao','Hoàng Vân','Lưu Hữu Phước'],
  [2,'Khi hát một bài hát hai bè, điều quan trọng nhất là gì?','mỗi bè giữ đúng giai điệu của mình và hòa với bè khác','bè nào hát to hơn thì thắng','hai bè hát cùng một giai điệu','bè phụ không cần hát rõ'],
  [2,'Hát có lĩnh xướng và hòa giọng là hình thức như thế nào?','một người hát đoạn riêng, sau đó cả nhóm cùng hát','tất cả cùng hát từ đầu đến cuối','mỗi người hát một bài','chỉ một người hát cả bài'],
  [2,'Nhạc sĩ Hoàng Vân còn là tác giả bài hát nào sau đây?','Hò kéo pháo','Tiến quân ca','Chiếc đèn ông sao','Lên đàng'],
  [3,'Em hãy nêu những hiểu biết của em về nhạc sĩ Phong Nhã.','Phong Nhã là nhạc sĩ gắn bó với thiếu nhi, tác giả Đội ca (Cùng nhau ta đi lên), Ai yêu Bác Hồ Chí Minh hơn thiếu niên nhi đồng, Kim Đồng…; ông được coi là nhạc sĩ của tuổi thơ Việt Nam.'],
  [3,'Em hãy nêu cách tập hát một bài hát có hai bè đơn giản trong lớp.','Chia lớp thành hai nhóm; mỗi nhóm tập riêng giai điệu bè của mình thật chắc; sau đó ghép hai bè chậm từng câu, lắng nghe nhau, giữ đều nhịp và cân bằng âm lượng; cuối cùng hát cả bài.'],
  [3,'Hãy trình bày một bài hát đã học ở lớp 5 theo hình thức có lĩnh xướng, hòa giọng và gõ đệm.','HS phân công lĩnh xướng hợp lí, hát đúng giai điệu, lời ca, sắc thái; cả nhóm hòa giọng đều, gõ đệm đúng nhịp.'],
  [4,'Vì sao hát bè khó hơn hát đồng ca một bè? Em hãy nêu hai khó khăn và cách khắc phục.','Khi hát bè, mỗi nhóm hát một giai điệu khác nhau cùng lúc nên dễ bị kéo theo bè kia hoặc hát sai cao độ; khó cân bằng âm lượng giữa hai bè. Khắc phục: tập riêng từng bè thật chắc trước khi ghép; ghép chậm, lắng nghe nhau; giáo viên hoặc một bạn giữ nhịp; điều chỉnh âm lượng để hai bè hòa quyện, không bè nào át bè nào.']
 ]);
 add(M,5,'Thói quen nghe và biểu diễn',[
  [1,'Khi nghe một bài hát mới, điều em nên tìm hiểu đầu tiên là gì?','tên bài hát, tác giả và nội dung bài hát','số trang trong sách','màu bìa sách','tên người đệm đàn'],
  [1,'Khi biểu diễn ở nơi công cộng, trang phục của em cần như thế nào?','gọn gàng, phù hợp với tiết mục','càng lạ càng tốt','không cần quan tâm','giống trang phục ở nhà'],
  [1,'Nghe nhạc bằng tai nghe trong thời gian dài với âm lượng lớn có thể gây hậu quả gì?','giảm thính lực','tăng khả năng nghe','không có ảnh hưởng','giúp học tốt hơn'],
  [2,'Khi tham gia hoạt động âm nhạc ở trường, học sinh có thể giữ vai trò gì?','người biểu diễn, người dẫn chương trình hoặc khán giả','chỉ được làm khán giả','chỉ được hát đơn ca','không được tham gia'],
  [2,'Khi một bạn biểu diễn bị lỗi, khán giả nên làm gì?','vẫn vỗ tay động viên','cười chê','hô to để bạn dừng','bỏ về giữa tiết mục'],
  [2,'Việc giới thiệu tên bài hát và tác giả trước khi biểu diễn có ý nghĩa gì?','tôn trọng tác giả và giúp người nghe hiểu về bài hát','làm tiết mục kéo dài','không có ý nghĩa gì','để khán giả biết mình giỏi'],
  [3,'Em hãy nêu các việc cần chuẩn bị để tham gia một buổi liên hoan văn nghệ ở trường.','Chọn bài hát phù hợp chủ đề; luyện tập giai điệu, lời ca, động tác; chuẩn bị trang phục, nhạc cụ, nhạc đệm; tập dượt trên sân khấu; giữ sức khỏe và tâm lí tự tin.'],
  [3,'Em hãy viết lời giới thiệu ngắn cho một tiết mục hát của nhóm (nêu tên bài, tác giả, hình thức biểu diễn).','HS viết được lời giới thiệu đủ: tên bài hát, tác giả, hình thức (tốp ca, có lĩnh xướng…), tên nhóm biểu diễn; lời lẽ rõ ràng, lịch sự.'],
  [3,'Hãy tự đánh giá một lần biểu diễn gần đây của em theo ba tiêu chí: hát đúng, sắc thái, tự tin.','HS tự nhận xét trung thực từng tiêu chí, nêu điểm tốt và điểm cần khắc phục, đề ra cách luyện tập tiếp.'],
  [4,'Theo em, vì sao việc giữ gìn và biểu diễn các bài hát dân ca, bài hát truyền thống của Việt Nam lại có ý nghĩa với học sinh? Hãy nêu cách em góp phần thực hiện.','Dân ca và bài hát truyền thống chứa đựng tâm hồn, lịch sử, phong tục của dân tộc; hát và biểu diễn chúng giúp học sinh hiểu, yêu quý và tự hào về văn hóa Việt Nam, đồng thời góp phần lưu truyền cho thế hệ sau. Em có thể tập hát dân ca, biểu diễn trong các buổi văn nghệ, giới thiệu cho bạn bè, tìm hiểu ý nghĩa của các làn điệu và trân trọng các nghệ nhân.']
 ]);

 /* ===== LỚP 6 ===== */
 add(M,6,'Lí thuyết âm nhạc',[
  [1,'Âm thanh có tính nhạc có bao nhiêu thuộc tính cơ bản?','4 thuộc tính','2 thuộc tính','3 thuộc tính','5 thuộc tính'],
  [1,'Thuộc tính nào của âm thanh cho biết độ cao thấp của âm?','cao độ','trường độ','cường độ','âm sắc'],
  [1,'Thuộc tính nào của âm thanh cho biết độ dài ngắn của âm?','trường độ','cao độ','cường độ','âm sắc'],
  [2,'Âm sắc là thuộc tính giúp ta phân biệt điều gì?','màu sắc âm thanh của các giọng hát, nhạc cụ khác nhau','độ dài của âm','độ mạnh nhẹ của âm','độ cao của âm'],
  [2,'Cường độ của âm thanh là gì?','độ mạnh, nhẹ (to, nhỏ) của âm','độ cao, thấp của âm','độ dài, ngắn của âm','màu sắc của âm'],
  [2,'Theo hệ thống chữ cái La-tinh, nốt Đô được kí hiệu bằng chữ nào?','C','A','D','G'],
  [3,'Em hãy kể tên bốn thuộc tính của âm thanh có tính nhạc và nêu ý nghĩa của mỗi thuộc tính.','Cao độ: độ cao thấp của âm; trường độ: độ dài ngắn của âm; cường độ: độ mạnh nhẹ của âm; âm sắc: màu sắc riêng của âm thanh (phân biệt giọng người, nhạc cụ).'],
  [3,'Em hãy viết kí hiệu bằng chữ cái La-tinh của bảy nốt nhạc cơ bản.','Đô – C, Rê – D, Mi – E, Pha – F, Son – G, La – A, Si – B (một số tài liệu ghi Si là H).'],
  [3,'Em hãy phân biệt âm thanh có tính nhạc và tiếng động (âm thanh không có tính nhạc).','Âm thanh có tính nhạc có cao độ xác định, nghe rõ cao thấp, dài ngắn, mạnh nhẹ, âm sắc (tiếng hát, tiếng đàn); tiếng động không có cao độ rõ ràng (tiếng gõ bàn, tiếng ồn, tiếng sấm).'],
  [4,'Vì sao cùng hát một nốt La ở cùng độ to, ta vẫn phân biệt được đó là giọng của bạn A hay bạn B, là tiếng đàn hay tiếng kèn? Hãy giải thích bằng thuộc tính của âm thanh.','Đó là nhờ thuộc tính âm sắc. Cao độ (nốt La) và cường độ giống nhau, nhưng mỗi giọng người, mỗi nhạc cụ có cấu tạo và cách tạo âm khác nhau nên tạo ra màu sắc âm thanh riêng. Âm sắc giúp ta nhận ra nguồn phát âm, và trong âm nhạc người ta kết hợp nhiều âm sắc để bản nhạc phong phú.']
 ]);
 add(M,6,'Thường thức âm nhạc',[
  [1,'Nhạc sĩ Mô-da (Mozart) là người nước nào?','Áo','Đức','Pháp','Nga'],
  [1,'Nhạc sĩ Mô-da được gọi là gì vì bộc lộ tài năng từ rất sớm?','thần đồng âm nhạc','vua nhạc nhẹ','ông hoàng dân ca','người thầy của nhạc cụ gõ'],
  [1,'Nhạc sĩ Văn Cao sáng tác bài Tiến quân ca vào năm nào?','1944','1954','1930','1975'],
  [2,'Nhạc sĩ Mô-da sống và sáng tác vào thời kì nào?','thế kỉ XVIII','thế kỉ XX','thế kỉ XV','thế kỉ XXI'],
  [2,'Nhạc cụ nào sau đây là nhạc cụ dân tộc Việt Nam được chơi bằng cách gảy que vào dây duy nhất?','đàn bầu','đàn nhị','đàn t\'rưng','sáo trúc'],
  [2,'Hát bè là hình thức như thế nào?','hai hoặc nhiều bè hát các giai điệu khác nhau cùng lúc, hòa hợp với nhau','mọi người hát cùng một giai điệu','hát nối tiếp từng người','một người hát, người khác đọc lời'],
  [3,'Em hãy nêu những hiểu biết cơ bản của em về nhạc sĩ Mô-da.','Vôn-gang A-ma-đơ Mô-da (1756–1791) là nhạc sĩ thiên tài người Áo thời kì cổ điển; biểu diễn và sáng tác từ nhỏ nên được gọi là thần đồng âm nhạc; ông viết nhiều thể loại: giao hưởng, nhạc kịch, công-xéc-tô, xô-nát…'],
  [3,'Em hãy giới thiệu ngắn về đàn bầu.','Đàn bầu là nhạc cụ dân tộc độc đáo của Việt Nam, chỉ có một dây; người chơi gảy bằng que và dùng tay trái điều khiển vòi đàn để thay đổi cao độ, tạo âm thanh trong trẻo, ngân nga, giàu sức biểu cảm.'],
  [3,'Em hãy nêu các bước tập hát bè đơn giản (bè hòa âm hoặc hát đuổi) trong lớp.','Chia nhóm bè; tập chắc giai điệu từng bè; ghép chậm từng câu, lắng nghe bè khác; giữ đều nhịp, cân bằng âm lượng; hát hoàn chỉnh cả bài.'],
  [4,'Vì sao đàn bầu chỉ có một dây mà vẫn chơi được nhiều cao độ khác nhau? Điều đó cho thấy gì về sự sáng tạo của người Việt?','Người chơi gảy vào các điểm khác nhau trên dây để tạo bồi âm có cao độ khác nhau, đồng thời dùng tay trái uốn vòi đàn làm dây căng hoặc chùng, thay đổi cao độ liên tục và tạo luyến, rung. Chỉ với một dây mà diễn tả được giai điệu phong phú, gần với giọng người, cho thấy sự sáng tạo tinh tế của cha ông ta trong chế tác nhạc cụ.']
 ]);
 add(M,6,'Nhạc lí và kí hiệu',[
  [1,'Khoảng cách cao độ nhỏ nhất giữa hai âm trong âm nhạc thường được gọi là gì?','nửa cung','một cung','một quãng tám','một phách'],
  [1,'Dấu hóa nào làm nốt nhạc giảm xuống nửa cung?','dấu giáng (b)','dấu thăng (#)','dấu bình','dấu lặng'],
  [1,'Dấu hóa nào hủy bỏ hiệu lực của dấu thăng hoặc dấu giáng trước đó?','dấu bình','dấu thăng','dấu giáng','dấu nối'],
  [2,'Trong bảy nốt cơ bản, giữa hai cặp nốt nào cách nhau nửa cung?','Mi – Pha và Si – Đô','Đô – Rê và Rê – Mi','Pha – Son và Son – La','La – Si và Đô – Rê'],
  [2,'Dấu hóa đặt ở đầu khuông nhạc, sau khóa Son, có hiệu lực với những nốt nào?','tất cả các nốt cùng tên trong cả bản nhạc','chỉ nốt đứng ngay sau nó','chỉ các nốt trong ô nhịp đầu','không có hiệu lực'],
  [2,'Nhịp 4/4 có sơ đồ phách mạnh nhẹ như thế nào?','mạnh – nhẹ – mạnh vừa – nhẹ','mạnh – nhẹ – nhẹ – nhẹ','nhẹ – mạnh – nhẹ – mạnh','mạnh – mạnh – nhẹ – nhẹ'],
  [3,'Em hãy phân biệt dấu hóa suốt và dấu hóa bất thường.','Dấu hóa suốt đặt đầu khuông nhạc sau khóa, có hiệu lực với mọi nốt cùng tên trong cả bản nhạc; dấu hóa bất thường đặt ngay trước nốt nhạc, chỉ có hiệu lực với các nốt cùng tên đứng sau nó trong phạm vi ô nhịp chứa nó.'],
  [3,'Em hãy trình bày khoảng cách cung và nửa cung giữa các nốt trong dãy Đô – Rê – Mi – Pha – Son – La – Si – Đô.','Đô–Rê: 1 cung; Rê–Mi: 1 cung; Mi–Pha: nửa cung; Pha–Son: 1 cung; Son–La: 1 cung; La–Si: 1 cung; Si–Đô: nửa cung.'],
  [3,'Em hãy giải thích số chỉ nhịp 4/4 và nêu một cách gõ đệm phù hợp.','Số 4 trên: mỗi ô nhịp có 4 phách; số 4 dưới: mỗi phách bằng một nốt đen; phách 1 mạnh, phách 2 nhẹ, phách 3 mạnh vừa, phách 4 nhẹ. Gõ đệm: gõ mạnh phách 1, nhẹ phách 2, hơi mạnh phách 3, nhẹ phách 4.'],
  [4,'Vì sao trong một bản nhạc, cùng là nốt Si nhưng có chỗ phải hát Si giáng, có chỗ hát Si bình? Em hãy giải thích dựa vào quy tắc của dấu hóa.','Nếu đầu bản nhạc có dấu giáng ở vị trí nốt Si (dấu hóa suốt) thì mọi nốt Si trong bài đều hát thành Si giáng. Khi tác giả muốn một nốt Si trở lại cao độ gốc, họ đặt dấu bình trước nốt đó (dấu hóa bất thường), và nó chỉ có hiệu lực trong ô nhịp ấy; sang ô nhịp sau, dấu giáng suốt lại có hiệu lực. Vì vậy người hát phải chú ý cả dấu hóa suốt lẫn dấu hóa bất thường.']
 ]);
 add(M,6,'Thường thức và biểu diễn',[
  [1,'Đàn pi-a-nô (piano) thuộc nhóm nhạc cụ nào?','nhạc cụ phím','nhạc cụ gõ dân tộc','nhạc cụ hơi','nhạc cụ dây gảy'],
  [1,'Đàn vi-ô-lông (violin) được chơi bằng cách nào?','kéo vĩ trên dây','gõ dùi','thổi hơi','ấn phím'],
  [1,'Dân ca quan họ là làn điệu dân ca của vùng nào?','Bắc Ninh – Bắc Giang (vùng Kinh Bắc)','Nam Bộ','Tây Nguyên','Nghệ Tĩnh'],
  [2,'Dân ca Việt Nam có đặc điểm gì về tác giả?','do nhân dân sáng tác, không rõ tác giả, truyền miệng','do một nhạc sĩ nổi tiếng viết','chỉ do vua sáng tác','luôn ghi rõ tên tác giả'],
  [2,'Đàn ghi-ta (guitar) thường có bao nhiêu dây?','6 dây','4 dây','2 dây','16 dây'],
  [2,'Khi biểu diễn một bài hát dân ca, người hát cần chú ý điều gì?','thể hiện đúng tính chất, luyến láy đặc trưng của làn điệu','hát thật nhanh và mạnh','bỏ các nốt luyến cho dễ hát','hát như bài hành khúc'],
  [3,'Em hãy kể tên ba nhạc cụ phương Tây và phân loại theo cách chơi.','Ví dụ: pi-a-nô (nhạc cụ phím), vi-ô-lông (dây kéo vĩ), ghi-ta (dây gảy), sáo phơ-luýt (hơi), kèn trôm-pét (hơi, kèn đồng).'],
  [3,'Em hãy nêu một số vùng dân ca tiêu biểu của Việt Nam và một làn điệu của mỗi vùng.','Ví dụ: Bắc Bộ – quan họ Bắc Ninh, hát xoan Phú Thọ; Trung Bộ – ví giặm Nghệ Tĩnh, hò Huế; Nam Bộ – lí (lí cây bông, lí con sáo), hát ru Nam Bộ; Tây Nguyên – dân ca các dân tộc Ba-na, Ê-đê, Gia-rai.'],
  [3,'Hãy trình bày một bài dân ca đã học ở lớp 6 theo nhóm, có kết hợp nhạc cụ gõ đệm.','HS hát đúng giai điệu, lời ca, thể hiện được nét luyến láy của dân ca; gõ đệm đúng nhịp, hòa hợp với giọng hát.'],
  [4,'Vì sao dân ca của mỗi vùng miền ở Việt Nam lại có màu sắc khác nhau? Em hãy giải thích và lấy ví dụ.','Dân ca gắn với đời sống, lao động, phương ngữ và phong tục của từng vùng, nên mỗi vùng tạo ra giai điệu, cách luyến láy, tiết tấu riêng. Ví dụ quan họ Bắc Ninh mượt mà, nhiều luyến láy, hát đối đáp giao duyên; ví giặm Nghệ Tĩnh mộc mạc, gắn với lao động và giọng nói địa phương; lí Nam Bộ ngắn gọn, vui tươi, phóng khoáng. Sự khác nhau ấy làm nên sự đa dạng, phong phú của dân ca Việt Nam.']
 ]);
 add(M,6,'(Bổ sung) Nhạc lí và thường thức',[
  [1,'Nốt nhạc nào đứng ngay trước nốt Son trong dãy bảy nốt cơ bản?','Pha','Mi','La','Rê'],
  [1,'Hình nốt móc kép có độ dài bằng mấy phần của nốt móc đơn?','một nửa','gấp đôi','bằng nhau','một phần tư'],
  [1,'Dấu lặng đơn có độ dài bằng hình nốt nào?','nốt móc đơn','nốt đen','nốt trắng','nốt tròn'],
  [2,'Hai nốt Mi và Pha cách nhau bao nhiêu?','nửa cung','một cung','hai cung','một quãng tám'],
  [2,'Khoảng cách từ nốt Đô đến nốt Đô cao hơn liền kề gọi là gì?','một quãng tám','nửa cung','một cung','một phách'],
  [2,'Nhạc sĩ nào được coi là thần đồng âm nhạc người Áo thế kỉ XVIII?','Mô-da','Văn Cao','Lưu Hữu Phước','Phạm Tuyên'],
  [3,'Em hãy kể tên các hình nốt đã học theo thứ tự từ dài đến ngắn và nêu quan hệ độ dài giữa chúng.','Nốt tròn = 2 nốt trắng; nốt trắng = 2 nốt đen; nốt đen = 2 nốt móc đơn; nốt móc đơn = 2 nốt móc kép.'],
  [3,'Em hãy nêu tác dụng của dấu lặng trong bản nhạc và kể tên hai loại dấu lặng thường gặp.','Dấu lặng chỉ thời gian ngừng nghỉ, tạo sự ngắt câu, lấy hơi và làm giai điệu sinh động hơn. Hai loại thường gặp: dấu lặng đen (nghỉ bằng nốt đen), dấu lặng đơn (nghỉ bằng nốt móc đơn).'],
  [3,'Em hãy giới thiệu ngắn gọn về nhạc sĩ Văn Cao.','Văn Cao (1923–1995) là nhạc sĩ, nhà thơ, họa sĩ Việt Nam; tác giả Tiến quân ca (Quốc ca Việt Nam) và nhiều ca khúc nổi tiếng như Làng tôi, Tiến về Hà Nội; ông được tặng Giải thưởng Hồ Chí Minh về văn học nghệ thuật.'],
  [4,'Vì sao dấu lặng cũng quan trọng như nốt nhạc trong một bản nhạc? Hãy phân tích vai trò của dấu lặng với người hát và với giai điệu.','Dấu lặng tuy không phát ra âm thanh nhưng được tính vào trường độ của ô nhịp, giúp giữ đúng nhịp. Với người hát, dấu lặng là chỗ lấy hơi, ngắt câu, giúp hát rõ ý và bền giọng. Với giai điệu, khoảng lặng tạo sự tương phản, nhấn mạnh, làm câu nhạc có hơi thở và biểu cảm; bỏ dấu lặng sẽ làm giai điệu dồn dập, sai nhịp và mất ý đồ của tác giả.']
 ]);

 /* ===== LỚP 7 ===== */
 add(M,7,'Lí thuyết âm nhạc',[
  [1,'Ô nhịp đầu tiên của bản nhạc không đủ số phách theo số chỉ nhịp gọi là gì?','nhịp lấy đà','nhịp đủ','nhịp kết','nhịp đôi'],
  [1,'Dấu chấm dôi đặt sau nốt nhạc có tác dụng gì?','tăng độ dài của nốt thêm một nửa giá trị của nó','giảm độ dài của nốt','tăng cao độ nửa cung','làm nốt nghỉ'],
  [1,'Dấu nối (cung nối) nối hai nốt cùng cao độ có tác dụng gì?','kéo dài trường độ, hai nốt vang thành một âm liên tục','hát ngắt hai nốt','tăng cao độ','giảm cường độ'],
  [2,'Nốt đen có dấu chấm dôi có độ dài bằng mấy phách (trong nhịp 2/4, 3/4, 4/4)?','1 phách rưỡi','1 phách','2 phách','nửa phách'],
  [2,'Dấu luyến (cung luyến) nối hai nốt khác cao độ cho biết điều gì?','hát liền tiếng, một từ hát qua hai nốt','hát ngắt từng nốt','ngừng nghỉ','lặp lại câu nhạc'],
  [2,'Khi bản nhạc bắt đầu bằng nhịp lấy đà, ô nhịp cuối cùng thường như thế nào?','thiếu số phách tương ứng để bù cho nhịp lấy đà','luôn đủ phách','luôn dài gấp đôi','không có nốt nào'],
  [3,'Em hãy giải thích thế nào là nhịp lấy đà và cho biết phách đầu của nhịp lấy đà thường là phách gì.','Nhịp lấy đà là ô nhịp đầu tiên không đủ số phách theo số chỉ nhịp. Vì phần đầu ô nhịp bị thiếu, các nốt của nhịp lấy đà thường rơi vào phách nhẹ, tạo đà dẫn vào phách mạnh ở ô nhịp sau.'],
  [3,'Em hãy phân biệt dấu nối và dấu luyến.','Dấu nối nối hai nốt cùng cao độ, cộng trường độ hai nốt thành một âm kéo dài; dấu luyến nối hai hay nhiều nốt khác cao độ, hát hoặc chơi liền tiếng, thường một từ hát qua nhiều nốt.'],
  [3,'Em hãy tính độ dài (số phách) của nốt trắng có dấu chấm dôi và nốt móc đơn có dấu chấm dôi.','Nốt trắng chấm dôi = 2 + 1 = 3 phách; nốt móc đơn chấm dôi = 1/2 + 1/4 = 3/4 phách.'],
  [4,'Vì sao nhiều bài hát bắt đầu bằng nhịp lấy đà? Việc này ảnh hưởng thế nào đến cách bắt nhịp và gõ đệm?','Lời ca thường có những tiếng nhẹ ở đầu câu cần rơi vào phách nhẹ, còn tiếng quan trọng rơi vào phách mạnh, nên tác giả dùng nhịp lấy đà để giai điệu tự nhiên, tạo đà dẫn vào ô nhịp đủ. Khi bắt nhịp, người chỉ huy phải đếm trước đủ phách rồi cho vào ở phách nhẹ; khi gõ đệm theo nhịp, phách mạnh đầu tiên không rơi vào nốt đầu bài mà vào nốt đầu ô nhịp thứ hai, nên cần chú ý để không gõ lệch.']
 ]);
 add(M,7,'Thường thức âm nhạc',[
  [1,'Nhạc sĩ Bét-tô-ven (Beethoven) là người nước nào?','Đức','Áo','Ý','Nga'],
  [1,'Thể loại tác phẩm nào gắn liền với tên tuổi Bét-tô-ven với 9 bản nổi tiếng?','giao hưởng','dân ca','hành khúc thiếu nhi','chèo'],
  [1,'Nhạc sĩ Hoàng Việt là tác giả bản giao hưởng đầu tiên của Việt Nam có tên là gì?','Quê hương','Tiến quân ca','Nhạc rừng','Đất nước'],
  [2,'Điều đặc biệt trong cuộc đời Bét-tô-ven là gì?','ông bị điếc nhưng vẫn sáng tác những tác phẩm vĩ đại','ông không biết đọc nhạc','ông chỉ sáng tác dân ca','ông chỉ sống ở Việt Nam'],
  [2,'Bài hát "Nhạc rừng" là sáng tác của nhạc sĩ nào?','Hoàng Việt','Văn Cao','Lưu Hữu Phước','Phạm Tuyên'],
  [2,'Bét-tô-ven sống vào thời kì nào?','cuối thế kỉ XVIII – đầu thế kỉ XIX','thế kỉ XX','thế kỉ XV','thế kỉ XXI'],
  [3,'Em hãy nêu những hiểu biết của em về nhạc sĩ Bét-tô-ven.','Lút-vích van Bét-tô-ven (1770–1827) là nhạc sĩ thiên tài người Đức, cầu nối giữa thời kì cổ điển và lãng mạn; nổi tiếng với 9 bản giao hưởng, nhiều xô-nát cho pi-a-nô; dù bị điếc ông vẫn sáng tác những tác phẩm bất hủ.'],
  [3,'Em hãy giới thiệu ngắn về nhạc sĩ Hoàng Việt.','Hoàng Việt (1928–1967) là nhạc sĩ Việt Nam, tác giả các ca khúc Nhạc rừng, Lên ngàn, Tình ca và bản giao hưởng Quê hương – bản giao hưởng đầu tiên của Việt Nam; ông hi sinh trong kháng chiến chống Mỹ và được tặng Giải thưởng Hồ Chí Minh.'],
  [3,'Giao hưởng là thể loại âm nhạc như thế nào? Em hãy nêu ngắn gọn.','Giao hưởng là tác phẩm âm nhạc lớn viết cho dàn nhạc giao hưởng biểu diễn, thường gồm nhiều chương, thể hiện nội dung sâu sắc, quy mô đồ sộ.'],
  [4,'Vì sao câu chuyện Bét-tô-ven bị điếc mà vẫn sáng tác được những tác phẩm vĩ đại lại là tấm gương cho học sinh? Em rút ra bài học gì?','Mất khả năng nghe là bi kịch lớn nhất với một nhạc sĩ, nhưng Bét-tô-ven không từ bỏ mà dựa vào trí tưởng tượng âm nhạc, ý chí và lao động sáng tạo để viết nên những bản giao hưởng bất hủ. Điều đó cho thấy nghị lực và niềm say mê có thể vượt lên nghịch cảnh. Bài học: kiên trì theo đuổi mục tiêu, không nản lòng trước khó khăn, biến thử thách thành động lực.']
 ]);
 add(M,7,'Nhạc lí và kí hiệu',[
  [1,'Dấu nhắc lại cho biết điều gì?','đoạn nhạc được trình bày lại một lần nữa','kết thúc bản nhạc','ngừng nghỉ','tăng tốc độ'],
  [1,'Khung thay đổi (số 1, số 2 trên khuông nhạc) được dùng khi nào?','khi nhắc lại một đoạn nhạc nhưng ô nhịp kết thúc khác nhau','khi bắt đầu bản nhạc','khi thay đổi nhịp','khi thay đổi khóa nhạc'],
  [1,'Dấu miễn nhịp (dấu mắt ngỗng) đặt trên nốt nhạc cho biết điều gì?','ngân nốt đó tự do, dài hơn trường độ ghi','hát nốt đó thật ngắn','bỏ qua nốt đó','hát nốt đó nhỏ'],
  [2,'Dấu quay lại (dấu hồi) kí hiệu bằng hình gì?','chữ S có gạch chéo và hai chấm hai bên','dấu chấm trên nốt','khóa Son','vạch nhịp đôi'],
  [2,'Khi gặp khung thay đổi, lần hát thứ hai ta thực hiện như thế nào?','bỏ ô nhịp trong khung số 1, hát ô nhịp trong khung số 2','hát cả hai khung','chỉ hát khung số 1','dừng lại'],
  [2,'Kí hiệu nào sau đây dùng để tăng trường độ của nốt nhạc?','dấu chấm dôi, dấu nối, dấu miễn nhịp','dấu thăng, dấu giáng','dấu lặng','khóa Son'],
  [3,'Em hãy kể tên các kí hiệu dùng để tăng trường độ nốt nhạc và nêu tác dụng của mỗi kí hiệu.','Dấu chấm dôi: thêm nửa giá trị nốt; dấu nối: cộng trường độ hai nốt cùng cao độ; dấu miễn nhịp: ngân tự do theo ý người biểu diễn.'],
  [3,'Em hãy trình bày cách thực hiện một đoạn nhạc có dấu nhắc lại kèm khung thay đổi 1 và 2.','Hát từ đầu đến hết khung 1, gặp dấu nhắc lại thì quay về đầu đoạn (hoặc dấu nhắc lại mở); lần thứ hai hát đến trước khung 1 thì bỏ khung 1, hát tiếp vào khung 2 rồi đi tiếp.'],
  [3,'Em hãy nêu ý nghĩa của các kí hiệu nhắc lại trong bản nhạc đối với người sáng tác và người biểu diễn.','Với người sáng tác: viết bản nhạc gọn hơn, không phải chép lại đoạn giống nhau. Với người biểu diễn: biết chỗ nào trình bày lại, nhớ cấu trúc bài, thực hiện đúng ý đồ tác giả.'],
  [4,'Phân tích vì sao cần phân biệt rõ dấu nhắc lại, dấu quay lại và khung thay đổi khi đọc một bản nhạc. Nếu nhầm lẫn, phần trình bày sẽ bị ảnh hưởng thế nào?','Dấu nhắc lại chỉ nhắc lại đoạn giữa hai dấu; dấu quay lại yêu cầu quay về vị trí có dấu tương ứng ở trước đó rồi đi tiếp hoặc đến đoạn kết; khung thay đổi quy định ô nhịp khác nhau ở mỗi lần hát. Nếu nhầm, người biểu diễn có thể hát thừa hoặc thiếu đoạn, hát sai ô nhịp kết, vào sai câu so với nhạc đệm hoặc với các bạn, làm cấu trúc bài bị phá vỡ và tiết mục không khớp nhau.']
 ]);
 add(M,7,'Thường thức và biểu diễn',[
  [1,'Dàn nhạc giao hưởng gồm bộ nhạc cụ nào là chủ yếu?','bộ dây, bộ gỗ, bộ đồng, bộ gõ','chỉ có bộ gõ','chỉ có nhạc cụ dân tộc','chỉ có pi-a-nô'],
  [1,'Nhạc cụ nào sau đây thuộc bộ dây của dàn nhạc giao hưởng?','vi-ô-lông','trôm-pét','sáo phơ-luýt','trống định âm'],
  [1,'Đàn nguyệt của Việt Nam có mấy dây?','2 dây','1 dây','4 dây','16 dây'],
  [2,'Người đứng trước dàn nhạc, điều khiển cả dàn nhạc biểu diễn gọi là gì?','nhạc trưởng','ca sĩ chính','nghệ sĩ độc tấu','người dẫn chương trình'],
  [2,'Hình thức một nhạc cụ biểu diễn chính cùng dàn nhạc đệm gọi là gì?','độc tấu (có đệm)','hòa tấu toàn dàn nhạc','đồng ca','hát bè'],
  [2,'Kèn trôm-pét (trumpet) thuộc bộ nhạc cụ nào trong dàn nhạc giao hưởng?','bộ đồng','bộ dây','bộ gỗ','bộ gõ'],
  [3,'Em hãy kể tên các bộ nhạc cụ trong dàn nhạc giao hưởng và một nhạc cụ tiêu biểu của mỗi bộ.','Bộ dây: vi-ô-lông, vi-ô-lông-xen; bộ gỗ: sáo phơ-luýt, cla-ri-nét; bộ đồng: trôm-pét, kèn co; bộ gõ: trống định âm, xanh-ban (cymbal).'],
  [3,'Em hãy giới thiệu ngắn về đàn nguyệt.','Đàn nguyệt (đàn kìm) là nhạc cụ dân tộc Việt Nam, thân đàn tròn như mặt trăng, có 2 dây, cần đàn dài, chơi bằng cách gảy; thường dùng trong hát chầu văn, ca Huế, nhạc tài tử.'],
  [3,'Hãy trình bày một bài hát đã học ở lớp 7 theo hình thức tốp ca có hát bè hoặc hát đuổi đơn giản.','HS hát đúng giai điệu, lời ca; phần bè hoặc đuổi vào đúng chỗ, giữ đều nhịp; thể hiện sắc thái, tư thế biểu diễn tự tin.'],
  [4,'Vì sao dàn nhạc giao hưởng cần có nhạc trưởng dù mỗi nhạc công đều có bản nhạc riêng? Hãy phân tích vai trò của nhạc trưởng.','Dàn nhạc có hàng chục đến hàng trăm nhạc công chơi các bè khác nhau; nhạc trưởng thống nhất tốc độ, cho vào – ngắt đúng lúc, điều chỉnh sắc thái to nhỏ, cân bằng âm lượng giữa các bộ và thể hiện ý tưởng nghệ thuật chung cho toàn tác phẩm. Nếu không có nhạc trưởng, mỗi người có thể hiểu và chơi khác nhau, dàn nhạc dễ lệch nhịp, không hòa hợp và không truyền tải được nội dung tác phẩm.']
 ]);
 add(M,7,'(Bổ sung) Nhạc lí và thường thức',[
  [1,'Nốt trắng có dấu chấm dôi có độ dài bằng mấy nốt đen?','3 nốt đen','2 nốt đen','4 nốt đen','1 nốt đen'],
  [1,'Trong nhịp 3/4, ô nhịp lấy đà có thể có mấy phách?','ít hơn 3 phách (1 hoặc 2 phách)','đúng 3 phách','4 phách','6 phách'],
  [1,'Nhạc sĩ nào bị điếc nhưng vẫn sáng tác 9 bản giao hưởng nổi tiếng?','Bét-tô-ven','Mô-da','Hoàng Việt','Văn Cao'],
  [2,'Hai nốt Son cùng cao độ nối với nhau bằng dấu nối trong nhịp 2/4 (mỗi nốt là nốt đen) sẽ ngân bao nhiêu phách?','2 phách','1 phách','3 phách','nửa phách'],
  [2,'Dấu luyến thường xuất hiện trong bài hát khi nào?','một tiếng của lời ca được hát qua hai hoặc nhiều nốt','mỗi tiếng ứng với một nốt','khi nghỉ giữa câu','khi kết thúc bài'],
  [2,'Nhạc sĩ Hoàng Việt đã sáng tác bản giao hưởng đầu tiên của Việt Nam vào thời kì nào?','những năm 1960 (thế kỉ XX)','thế kỉ XIX','những năm 2000','thế kỉ XVIII'],
  [3,'Em hãy nêu cách xác định một bài hát có nhịp lấy đà hay không khi nhìn vào bản nhạc.','So số phách của ô nhịp đầu với số chỉ nhịp: nếu ô nhịp đầu có ít phách hơn số chỉ nhịp quy định thì đó là nhịp lấy đà; thường ô nhịp cuối cũng thiếu phần phách tương ứng.'],
  [3,'Em hãy giải thích vì sao dấu miễn nhịp thường được đặt ở nốt kết của bài hát.','Nốt kết là điểm dừng của toàn bài, đặt dấu miễn nhịp để người hát có thể ngân dài tự do, tạo cảm giác kết trọn vẹn, thể hiện sắc thái và cảm xúc kết bài theo ý người biểu diễn.'],
  [3,'Em hãy kể tên hai nhạc sĩ thế giới và hai nhạc sĩ Việt Nam đã học ở lớp 6, 7 cùng một tác phẩm tiêu biểu của mỗi người.','Mô-da (Áo) – nhiều giao hưởng, nhạc kịch; Bét-tô-ven (Đức) – 9 bản giao hưởng; Văn Cao – Tiến quân ca; Hoàng Việt – giao hưởng Quê hương, Nhạc rừng.'],
  [4,'So sánh tác dụng của dấu nối và dấu chấm dôi trong việc kéo dài trường độ. Trong trường hợp nào tác giả buộc phải dùng dấu nối mà không thể dùng dấu chấm dôi?','Cả hai đều kéo dài trường độ: dấu chấm dôi thêm nửa giá trị nốt, dấu nối cộng trường độ của hai nốt cùng cao độ. Tác giả buộc phải dùng dấu nối khi nốt cần kéo dài vượt qua vạch nhịp (ngân từ ô nhịp này sang ô nhịp sau), vì một nốt không thể nằm trên hai ô nhịp; hoặc khi tổng trường độ cần ngân không thể biểu diễn bằng một hình nốt có chấm dôi (ví dụ 5 phách = nốt tròn nối nốt đen).']
 ]);

 /* ===== LỚP 8 ===== */
 add(M,8,'Lí thuyết âm nhạc',[
  [1,'Gam trưởng là hệ thống gồm bao nhiêu bậc âm được sắp xếp liền bậc?','7 bậc âm','5 bậc âm','12 bậc âm','3 bậc âm'],
  [1,'Âm ổn định nhất trong gam, được gọi là âm chủ, là bậc thứ mấy?','bậc I','bậc III','bậc V','bậc VII'],
  [1,'Giọng Đô trưởng có đặc điểm gì về dấu hóa?','không có dấu hóa ở đầu khuông','có một dấu thăng','có một dấu giáng','có hai dấu thăng'],
  [2,'Trong gam trưởng, các cặp bậc nào cách nhau nửa cung?','bậc III – IV và bậc VII – I (VIII)','bậc I – II và bậc II – III','bậc IV – V và bậc V – VI','bậc II – III và bậc V – VI'],
  [2,'Giọng La thứ có quan hệ gì với giọng Đô trưởng?','là giọng song song (cùng hóa biểu, khác âm chủ)','không có quan hệ','cùng âm chủ','hơn Đô trưởng một dấu thăng'],
  [2,'Âm chủ của giọng La thứ là nốt nào?','La','Đô','Mi','Son'],
  [3,'Em hãy trình bày cấu tạo của gam trưởng (khoảng cách cung và nửa cung giữa các bậc).','Gam trưởng gồm 7 bậc theo công thức: I–II: 1 cung; II–III: 1 cung; III–IV: nửa cung; IV–V: 1 cung; V–VI: 1 cung; VI–VII: 1 cung; VII–I (VIII): nửa cung.'],
  [3,'Em hãy trình bày cấu tạo của gam thứ (gam thứ tự nhiên).','Gam thứ gồm 7 bậc theo công thức: I–II: 1 cung; II–III: nửa cung; III–IV: 1 cung; IV–V: 1 cung; V–VI: nửa cung; VI–VII: 1 cung; VII–I: 1 cung.'],
  [3,'Thế nào là giọng? Em hãy nêu cách gọi tên một giọng.','Giọng là các bậc âm trong gam được sử dụng để xây dựng giai điệu bản nhạc, mang tên âm chủ kèm tính chất trưởng hoặc thứ. Tên giọng = tên âm chủ + trưởng/thứ (ví dụ: Đô trưởng, La thứ).'],
  [4,'Vì sao giọng Đô trưởng và La thứ cùng không có dấu hóa nhưng khi nghe lại cho cảm giác khác nhau? Em hãy phân tích.','Hai giọng dùng chung bảy nốt (cùng hóa biểu) nên là giọng song song, nhưng khác âm chủ và thứ tự cung – nửa cung tính từ âm chủ. Đô trưởng có quãng ba từ bậc I đến III là 2 cung (quãng ba trưởng) nên nghe sáng, vui, khỏe; La thứ có quãng ba từ bậc I đến III chỉ 1 cung rưỡi (quãng ba thứ) nên nghe mềm, trầm, buồn hơn. Chính cấu tạo quãng từ âm chủ quyết định màu sắc trưởng hay thứ.']
 ]);
 add(M,8,'Thường thức âm nhạc',[
  [1,'Nhạc sĩ Sô-panh (Chopin) là người nước nào?','Ba Lan','Đức','Áo','Nga'],
  [1,'Nhạc cụ gắn liền với sự nghiệp sáng tác và biểu diễn của Sô-panh là gì?','pi-a-nô','vi-ô-lông','ghi-ta','sáo'],
  [1,'Dân ca ví, giặm là di sản văn hóa của vùng nào ở Việt Nam?','Nghệ An – Hà Tĩnh','Bắc Ninh','Nam Bộ','Tây Nguyên'],
  [2,'Sô-panh sống và sáng tác vào thời kì nào của âm nhạc phương Tây?','thời kì lãng mạn (thế kỉ XIX)','thời kì cổ điển (thế kỉ XVIII)','thời kì Phục hưng','thế kỉ XX'],
  [2,'Nhạc sĩ Trịnh Công Sơn là tác giả ca khúc thiếu nhi nào sau đây?','Em là bông hồng nhỏ','Chiếc đèn ông sao','Em yêu trường em','Thiếu nhi thế giới liên hoan'],
  [2,'Ca khúc "Nối vòng tay lớn" là sáng tác của nhạc sĩ nào?','Trịnh Công Sơn','Phạm Tuyên','Hoàng Vân','Văn Cao'],
  [3,'Em hãy nêu những hiểu biết của em về nhạc sĩ Sô-panh.','Phrê-đê-rích Sô-panh (1810–1849) là nhạc sĩ, nghệ sĩ pi-a-nô thiên tài người Ba Lan thời kì lãng mạn; hầu hết tác phẩm của ông viết cho pi-a-nô (các bản van, pô-lô-ne, ma-duốc-ca, nốc-tuyếc, ê-tuýt…), mang đậm tâm hồn dân tộc Ba Lan.'],
  [3,'Em hãy giới thiệu ngắn về dân ca ví, giặm Nghệ Tĩnh.','Ví, giặm là hai lối hát dân ca của người dân Nghệ An, Hà Tĩnh, gắn với lao động và sinh hoạt; giai điệu mộc mạc, sâu lắng, lời ca giàu tình cảm; được UNESCO ghi danh là Di sản văn hóa phi vật thể đại diện của nhân loại năm 2014.'],
  [3,'Em hãy kể tên một số thể loại ca khúc theo nội dung mà em biết và nêu một ví dụ cho mỗi thể loại.','Ví dụ: hành khúc (Lên đàng – Lưu Hữu Phước), ca khúc thiếu nhi (Em là bông hồng nhỏ – Trịnh Công Sơn), ca khúc trữ tình (Tình ca – Hoàng Việt), ca khúc mang âm hưởng dân ca.'],
  [4,'Vì sao âm nhạc của Sô-panh được coi là mang đậm tâm hồn dân tộc Ba Lan dù ông sống phần lớn cuộc đời ở nước ngoài? Hãy phân tích.','Sô-panh rời Ba Lan từ khi còn trẻ và sống chủ yếu ở Pháp, nhưng ông luôn hướng về quê hương đang mất độc lập. Ông đưa các điệu nhảy dân gian Ba Lan như pô-lô-ne, ma-duốc-ca vào âm nhạc chuyên nghiệp, giữ tiết tấu, màu sắc giai điệu dân tộc nhưng nâng lên thành tác phẩm nghệ thuật. Nhờ vậy, tác phẩm của ông vừa có giá trị nghệ thuật cao vừa thể hiện nỗi nhớ và lòng yêu nước, trở thành biểu tượng âm nhạc của Ba Lan.']
 ]);
 add(M,8,'Nhạc lí và kí hiệu',[
  [1,'Nhịp 6/8 có mấy phách trong một ô nhịp?','6 phách','8 phách','3 phách','4 phách'],
  [1,'Trong nhịp 6/8, mỗi phách có giá trị bằng hình nốt nào?','nốt móc đơn','nốt đen','nốt trắng','nốt móc kép'],
  [1,'Hợp âm là gì?','sự kết hợp từ 3 âm trở lên vang cùng lúc, các âm cách nhau quãng 3','hai nốt nối tiếp nhau','một nốt ngân dài','một đoạn giai điệu'],
  [2,'Trong nhịp 6/8, phách mạnh và phách mạnh vừa lần lượt là phách nào?','phách 1 (mạnh) và phách 4 (mạnh vừa)','phách 1 (mạnh) và phách 2 (mạnh vừa)','phách 3 (mạnh) và phách 6 (mạnh vừa)','phách 1 và phách 4 đều mạnh như nhau'],
  [2,'Hợp âm ba gồm mấy âm?','3 âm','2 âm','4 âm','5 âm'],
  [2,'Hợp âm Đô trưởng gồm các nốt nào?','Đô – Mi – Son','Đô – Rê – Mi','Đô – Pha – La','Đô – Mi – La'],
  [3,'Em hãy giải thích ý nghĩa số chỉ nhịp 6/8 và nêu tính chất của nhịp này.','Số 6: mỗi ô nhịp có 6 phách; số 8: mỗi phách bằng một nốt móc đơn; trọng âm ở phách 1 (mạnh) và phách 4 (mạnh vừa). Nhịp 6/8 có tính chất nhịp nhàng, đung đưa, uyển chuyển, thường gặp trong các bài hát trữ tình, bài hát ru.'],
  [3,'Em hãy phân biệt hợp âm ba trưởng và hợp âm ba thứ.','Hợp âm ba trưởng: quãng ba dưới là quãng ba trưởng (2 cung), quãng ba trên là quãng ba thứ (1,5 cung), nghe sáng, vui. Hợp âm ba thứ: quãng ba dưới là quãng ba thứ (1,5 cung), quãng ba trên là quãng ba trưởng (2 cung), nghe mềm, buồn hơn.'],
  [3,'Em hãy nêu các nốt của hợp âm La thứ và hợp âm Son trưởng.','Hợp âm La thứ: La – Đô – Mi. Hợp âm Son trưởng: Son – Si – Rê.'],
  [4,'Vì sao nhịp 6/8 và nhịp 3/4 đều có số phách chia hết cho 3 nhưng tính chất lại khác nhau? Hãy phân tích dựa trên cách phân chia trọng âm.','Nhịp 3/4 có 3 phách bằng nốt đen, một trọng âm ở phách 1, chu kì mạnh – nhẹ – nhẹ rõ, tính chất đung đưa kiểu điệu van. Nhịp 6/8 có 6 phách bằng nốt móc đơn, chia thành hai nhóm 3 phách: phách 1 mạnh (trọng âm chính), phách 4 mạnh vừa (trọng âm phụ), nên thực chất là nhịp phức có hai nhịp lớn, mỗi nhịp lớn chia ba. Vì vậy nhịp 6/8 vừa có sự uyển chuyển của nhóm ba vừa có cảm giác đi hai bước đều của nhịp đôi, nghe trôi chảy, mềm mại khác với nhịp 3/4.']
 ]);
 add(M,8,'Thường thức và biểu diễn',[
  [1,'Cồng chiêng Tây Nguyên được UNESCO ghi danh là di sản văn hóa với tên gọi nào?','Không gian văn hóa cồng chiêng Tây Nguyên','Nhã nhạc cung đình Huế','Dân ca quan họ Bắc Ninh','Ca trù'],
  [1,'Sự khác nhau cơ bản giữa cồng và chiêng là gì?','cồng có núm ở giữa, chiêng không có núm','cồng làm bằng gỗ, chiêng làm bằng đồng','cồng được thổi, chiêng được gõ','cồng nhỏ hơn chiêng'],
  [1,'Hát bè quãng ba là cách hát như thế nào?','bè phụ hát cách bè chính một quãng ba, đi song song','hai bè hát cùng cao độ','bè phụ hát sau bè chính một ô nhịp','bè phụ chỉ gõ nhịp'],
  [2,'Hát đuổi (ca-nông) là hình thức hát như thế nào?','các bè hát cùng một giai điệu nhưng bắt đầu lệch nhau một khoảng thời gian','các bè hát các giai điệu khác hẳn nhau','một người hát, người khác đọc','tất cả hát cùng lúc, cùng giai điệu'],
  [2,'Đàn đá là nhạc cụ thuộc loại nào và có ở vùng nào của Việt Nam?','nhạc cụ gõ, phát hiện nhiều ở Tây Nguyên và Nam Trung Bộ','nhạc cụ dây, ở Bắc Bộ','nhạc cụ hơi, ở Nam Bộ','nhạc cụ phím, ở Huế'],
  [2,'Khi dàn dựng một bài hát có bè, bè chính cần được xử lí âm lượng như thế nào so với bè phụ?','rõ hơn một chút để nổi giai điệu chính, bè phụ hòa hợp nâng đỡ','nhỏ hơn bè phụ','hoàn toàn bằng nhau mọi lúc','không cần quan tâm'],
  [3,'Em hãy giới thiệu ngắn về cồng chiêng Tây Nguyên.','Cồng chiêng là nhạc cụ gõ bằng đồng của các dân tộc Tây Nguyên (Ba-na, Gia-rai, Ê-đê…), dùng trong lễ hội, sinh hoạt cộng đồng; cồng có núm, chiêng không có núm, được diễn tấu theo dàn. Không gian văn hóa cồng chiêng Tây Nguyên được UNESCO ghi danh năm 2005.'],
  [3,'Em hãy nêu các bước dàn dựng một bài hát theo hình thức hát đuổi đơn giản cho nhóm.','Chọn bài phù hợp; chia hai bè; thống nhất khoảng cách bắt đầu (ví dụ bè 2 vào sau bè 1 một ô nhịp hoặc một câu); tập chắc giai điệu; ghép chậm, lắng nghe nhau; chọn cách kết (cùng dừng ở nốt kết hoặc bè 2 kết sau); luyện với tốc độ bài hát.'],
  [3,'Hãy trình bày một bài hát đã học ở lớp 8 có hát bè hoặc hát đuổi, kết hợp gõ đệm hoặc vận động.','HS hát đúng giai điệu, các bè vào đúng chỗ, hòa hợp; gõ đệm hoặc vận động phù hợp nhịp điệu; thể hiện sắc thái và biểu diễn tự tin.'],
  [4,'Vì sao hát bè làm bài hát hay hơn nhưng nếu không luyện kĩ lại dễ làm bài hát bị hỏng? Hãy phân tích và nêu điều kiện để hát bè thành công.','Hát bè tạo hòa âm nhiều tầng, làm giai điệu dày dặn, phong phú, giàu màu sắc. Nhưng nếu một bè hát sai cao độ, lệch nhịp hoặc quá to, sẽ tạo ra những âm chồng chéo nghịch tai, làm người nghe mất cả giai điệu chính. Điều kiện thành công: mỗi bè thuộc chắc phần của mình, có người giữ nhịp, các bè lắng nghe nhau, cân bằng âm lượng để bè chính nổi rõ, và luyện ghép bè từ chậm đến nhanh.']
 ]);
 add(M,8,'(Bổ sung) Nhạc lí và thường thức',[
  [1,'Gam Đô trưởng gồm các nốt nào?','Đô – Rê – Mi – Pha – Son – La – Si – (Đô)','La – Si – Đô – Rê – Mi – Pha – Son – (La)','Son – La – Si – Đô – Rê – Mi – Pha thăng – (Son)','Đô – Mi – Son – Đô'],
  [1,'Gam La thứ gồm các nốt nào?','La – Si – Đô – Rê – Mi – Pha – Son – (La)','Đô – Rê – Mi – Pha – Son – La – Si – (Đô)','La – Đô – Mi – La','Mi – Pha thăng – Son – La – Si – Đô – Rê – (Mi)'],
  [1,'Trong hợp âm ba, các âm cách nhau quãng mấy?','quãng ba','quãng hai','quãng năm','quãng tám'],
  [2,'Bài hát kết ở nốt La và không có dấu hóa đầu khuông thường được viết ở giọng nào?','La thứ','Đô trưởng','Son trưởng','Mi thứ'],
  [2,'Bài hát không có dấu hóa đầu khuông và kết ở nốt Đô thường được viết ở giọng nào?','Đô trưởng','La thứ','Pha trưởng','Rê thứ'],
  [2,'Một ô nhịp 6/8 có thể gồm những hình nốt nào?','hai nốt đen chấm dôi','ba nốt trắng','một nốt tròn','bốn nốt đen'],
  [3,'Em hãy nêu cách xác định giọng của một bài hát dựa vào hóa biểu và nốt kết.','Nhìn hóa biểu đầu khuông để biết cặp giọng song song có thể (ví dụ không dấu hóa: Đô trưởng hoặc La thứ); nhìn nốt kết bài (thường là âm chủ) để xác định giọng trưởng hay thứ trong cặp đó.'],
  [3,'Em hãy giải thích thế nào là hai giọng song song và cho ví dụ.','Hai giọng song song là một giọng trưởng và một giọng thứ có chung hóa biểu (cùng các dấu hóa), âm chủ giọng thứ thấp hơn âm chủ giọng trưởng một quãng ba thứ. Ví dụ: Đô trưởng – La thứ.'],
  [3,'Em hãy kể tên các nốt của ba hợp âm ba xây trên bậc I, IV, V của giọng Đô trưởng.','Bậc I: Đô – Mi – Son (Đô trưởng); bậc IV: Pha – La – Đô (Pha trưởng); bậc V: Son – Si – Rê (Son trưởng).'],
  [4,'Vì sao khi đệm hát người ta thường dùng ba hợp âm bậc I, IV, V của giọng? Hãy phân tích vai trò của từng hợp âm.','Ba hợp âm này chứa đủ bảy nốt của giọng nên có thể đệm cho hầu hết các nốt trong giai điệu. Hợp âm bậc I (chủ) tạo cảm giác ổn định, dùng ở đầu và kết; hợp âm bậc V (át) tạo sự căng, thúc đẩy trở về chủ; hợp âm bậc IV (hạ át) tạo sự chuyển động, mở rộng màu sắc. Sự luân chuyển giữa ổn định và không ổn định của ba hợp âm làm phần đệm có sức hút và nâng đỡ giai điệu.']
 ]);

 /* ===== LỚP 9 ===== */
 add(M,9,'Lí thuyết âm nhạc',[
  [1,'Quãng trong âm nhạc là gì?','khoảng cách về cao độ giữa hai âm','khoảng cách thời gian giữa hai nốt','độ to của âm thanh','số ô nhịp của bài hát'],
  [1,'Quãng mà hai âm vang lên cùng lúc gọi là gì?','quãng hòa âm','quãng giai điệu','quãng tám','quãng đồng âm'],
  [1,'Quãng mà hai âm vang lên lần lượt gọi là gì?','quãng giai điệu','quãng hòa âm','quãng năm','quãng kép'],
  [2,'Tên quãng được xác định dựa vào điều gì?','số bậc âm từ âm gốc đến âm ngọn','số phách giữa hai nốt','độ to của hai âm','số dấu hóa của bài'],
  [2,'Quãng từ nốt Đô đến nốt Son (đi lên) là quãng mấy?','quãng 5','quãng 4','quãng 3','quãng 6'],
  [2,'Quãng từ nốt Mi đến nốt Son (đi lên) là quãng mấy?','quãng 3','quãng 2','quãng 4','quãng 5'],
  [3,'Em hãy phân biệt quãng hòa âm và quãng giai điệu.','Quãng hòa âm: hai âm vang cùng một lúc (ví dụ hát bè, đệm hợp âm); quãng giai điệu: hai âm vang lần lượt, nối tiếp nhau (ví dụ trong giai điệu bài hát).'],
  [3,'Em hãy xác định tên các quãng sau (tính từ âm thấp lên): Đô – Rê, Đô – Mi, Đô – Pha, Đô – La, Đô – Đô (cao hơn).','Đô – Rê: quãng 2; Đô – Mi: quãng 3; Đô – Pha: quãng 4; Đô – La: quãng 6; Đô – Đô cao hơn: quãng 8.'],
  [3,'Em hãy giải thích thế nào là quãng 1 (quãng đồng âm) và quãng 8.','Quãng 1 là hai âm cùng cao độ, cùng tên (hai nốt giống nhau); quãng 8 là hai âm cùng tên nhưng cách nhau 8 bậc, âm trên cao hơn âm dưới một quãng tám (ví dụ Đô – Đô cao).'],
  [4,'Vì sao hai quãng cùng tên (ví dụ cùng là quãng 3) lại có thể cho cảm giác trưởng hay thứ khác nhau? Em hãy phân tích dựa vào số cung.','Tên quãng chỉ cho biết số bậc, còn tính chất quãng phụ thuộc vào số cung giữa hai âm. Quãng 3 Đô – Mi có 2 cung (quãng 3 trưởng) nghe sáng, vui; quãng 3 Mi – Son chỉ có 1 cung rưỡi (quãng 3 thứ) nghe mềm, trầm hơn. Vì các cặp Mi – Pha và Si – Đô cách nhau nửa cung nên cùng số bậc nhưng số cung khác nhau; đây cũng là cơ sở phân biệt hợp âm trưởng và thứ.']
 ]);
 add(M,9,'Thường thức âm nhạc',[
  [1,'Nhạc sĩ Trai-cốp-xki (Tchaikovsky) là người nước nào?','Nga','Đức','Pháp','Ba Lan'],
  [1,'Vở vũ kịch (ba-lê) nổi tiếng nào sau đây là của Trai-cốp-xki?','Hồ thiên nga','Tiến quân ca','Quê hương','Nối vòng tay lớn'],
  [1,'Nhạc kịch (ô-pê-ra) là thể loại kết hợp âm nhạc với yếu tố nào là chủ yếu?','hát và diễn xuất trên sân khấu','múa không lời','chỉ độc tấu nhạc cụ','đọc thơ'],
  [2,'Trai-cốp-xki sống và sáng tác vào thời kì nào?','thế kỉ XIX','thế kỉ XVII','thế kỉ XX','thế kỉ XVI'],
  [2,'Ca khúc mang âm hưởng dân ca là gì?','ca khúc do nhạc sĩ sáng tác, sử dụng chất liệu, màu sắc của dân ca','bài dân ca cổ không rõ tác giả','bài hát nước ngoài dịch lời','bài hát không có giai điệu'],
  [2,'Vở vũ kịch "Kẹp hạt dẻ" là tác phẩm của nhạc sĩ nào?','Trai-cốp-xki','Mô-da','Bét-tô-ven','Sô-panh'],
  [3,'Em hãy nêu những hiểu biết của em về nhạc sĩ Trai-cốp-xki.','Pi-ốt I-lích Trai-cốp-xki (1840–1893) là nhạc sĩ vĩ đại người Nga thời kì lãng mạn; nổi tiếng với các vở vũ kịch Hồ thiên nga, Kẹp hạt dẻ, Người đẹp ngủ trong rừng, các bản giao hưởng, công-xéc-tô và nhạc kịch; âm nhạc của ông giàu chất trữ tình và màu sắc dân tộc Nga.'],
  [3,'Em hãy nêu đặc điểm của ca khúc mang âm hưởng dân ca và cho một ví dụ về vùng miền.','Ca khúc mang âm hưởng dân ca do nhạc sĩ sáng tác nhưng khai thác thang âm, giai điệu, tiết tấu, cách luyến láy và lời ca gần với dân ca một vùng. Ví dụ ca khúc mang âm hưởng dân ca Bắc Bộ, Trung Bộ, Nam Bộ hoặc Tây Nguyên, mỗi loại mang màu sắc của vùng đó.'],
  [3,'Em hãy phân biệt nhạc kịch (ô-pê-ra) và vũ kịch (ba-lê).','Nhạc kịch là tác phẩm sân khấu trong đó nội dung được thể hiện chủ yếu bằng hát (độc ca, hợp xướng) cùng dàn nhạc, có diễn xuất; vũ kịch là tác phẩm sân khấu thể hiện nội dung chủ yếu bằng múa trên nền âm nhạc của dàn nhạc, không có lời hát.'],
  [4,'Vì sao các nhạc sĩ Việt Nam thường khai thác chất liệu dân ca khi sáng tác ca khúc? Hãy phân tích ý nghĩa của việc này đối với nền âm nhạc dân tộc.','Dân ca là kho tàng giai điệu, thang âm, tiết tấu gần gũi với tâm hồn người Việt; khai thác chất liệu dân ca giúp ca khúc dễ đi vào lòng người, mang bản sắc riêng, không lẫn với âm nhạc nước ngoài. Đồng thời việc này làm dân ca sống tiếp trong hình thức mới, góp phần bảo tồn và phát triển âm nhạc truyền thống, tạo nên nền âm nhạc Việt Nam hiện đại mà vẫn đậm đà tính dân tộc.']
 ]);
 add(M,9,'Nhạc lí và kí hiệu',[
  [1,'Giọng Son trưởng có hóa biểu gồm dấu hóa nào?','một dấu thăng (Pha thăng)','một dấu giáng (Si giáng)','không có dấu hóa','hai dấu thăng'],
  [1,'Giọng Pha trưởng có hóa biểu gồm dấu hóa nào?','một dấu giáng (Si giáng)','một dấu thăng (Pha thăng)','không có dấu hóa','hai dấu giáng'],
  [1,'Giọng song song của giọng Son trưởng là giọng nào?','Mi thứ','La thứ','Rê thứ','Đô thứ'],
  [2,'Giọng song song của giọng Pha trưởng là giọng nào?','Rê thứ','Mi thứ','La thứ','Son thứ'],
  [2,'Dịch giọng là gì?','chuyển bản nhạc từ giọng này sang giọng khác, giai điệu không đổi, cao độ chung thay đổi','đổi lời bài hát','đổi nhịp của bài hát','đổi tốc độ bài hát'],
  [2,'Khi dịch giọng một bài hát, yếu tố nào không thay đổi?','quan hệ cao độ giữa các nốt (giai điệu) và tiết tấu','tên các nốt nhạc','hóa biểu','độ cao chung của bài'],
  [3,'Em hãy nêu các nốt trong gam Son trưởng và gam Mi thứ.','Son trưởng: Son – La – Si – Đô – Rê – Mi – Pha thăng – (Son). Mi thứ: Mi – Pha thăng – Son – La – Si – Đô – Rê – (Mi).'],
  [3,'Em hãy nêu các nốt trong gam Pha trưởng và gam Rê thứ.','Pha trưởng: Pha – Son – La – Si giáng – Đô – Rê – Mi – (Pha). Rê thứ: Rê – Mi – Pha – Son – La – Si giáng – Đô – (Rê).'],
  [3,'Em hãy nêu mục đích của việc dịch giọng và cách thực hiện cơ bản.','Mục đích: đưa bài hát về tầm cữ phù hợp với giọng người hát hoặc nhạc cụ. Cách làm: xác định giọng gốc và giọng mới, tính khoảng cách giữa hai âm chủ, chuyển tất cả các nốt lên hoặc xuống đúng khoảng cách đó, ghi hóa biểu của giọng mới, giữ nguyên tiết tấu.'],
  [4,'Vì sao bài hát viết ở giọng Đô trưởng dịch sang Son trưởng vẫn là bài hát đó nhưng người hát lại thấy hát dễ hoặc khó hơn? Em hãy phân tích.','Dịch giọng giữ nguyên quan hệ cao độ giữa các nốt (các quãng) và tiết tấu, nên giai điệu không đổi, người nghe vẫn nhận ra bài hát. Tuy nhiên độ cao chung của toàn bài thay đổi: chuyển từ Đô trưởng lên Son trưởng (lên quãng 5) hoặc xuống Son trưởng (xuống quãng 4) làm các nốt cao nhất và thấp nhất thay đổi, có thể vượt ra hoặc nằm gọn trong tầm cữ giọng của người hát. Vì vậy dịch giọng đúng giúp hát thoải mái, dịch không phù hợp sẽ làm người hát với quá cao hoặc quá thấp.']
 ]);
 add(M,9,'Thường thức và biểu diễn',[
  [1,'Nhã nhạc cung đình Huế được UNESCO ghi danh là di sản văn hóa phi vật thể vào năm nào?','2003','1995','2010','2015'],
  [1,'Nhã nhạc cung đình Huế là loại hình âm nhạc gắn với không gian nào?','cung đình, lễ nghi triều đình nhà Nguyễn','lao động trên đồng ruộng','lễ hội Tây Nguyên','hát đối đáp trên sông'],
  [1,'Đờn ca tài tử là loại hình nghệ thuật của vùng nào?','Nam Bộ','Bắc Bộ','Tây Nguyên','Tây Bắc'],
  [2,'Khi dàn dựng một tiết mục hát có vận động và nhạc cụ đệm, việc cần làm đầu tiên là gì?','phân tích bài hát (nhịp, sắc thái, cấu trúc) để chọn hình thức phù hợp','mua trang phục','tập động tác trước khi thuộc bài','chọn người hát to nhất'],
  [2,'Hợp xướng là hình thức biểu diễn như thế nào?','nhiều người hát nhiều bè, chia theo các loại giọng, thường có người chỉ huy','một người hát với nhạc đệm','hai người hát cùng một giai điệu','nhóm nhạc cụ hòa tấu không lời'],
  [2,'Ca trù là loại hình nghệ thuật truyền thống của vùng nào?','Bắc Bộ','Nam Bộ','Tây Nguyên','Tây Nam Bộ'],
  [3,'Em hãy giới thiệu ngắn về Nhã nhạc cung đình Huế.','Nhã nhạc là âm nhạc dùng trong các nghi lễ của triều đình, phát triển rực rỡ dưới thời Nguyễn ở Huế, biểu diễn bằng dàn nhạc cụ dân tộc với các bài bản trang trọng; được UNESCO ghi danh là Di sản văn hóa phi vật thể đại diện của nhân loại năm 2003.'],
  [3,'Em hãy kể tên bốn loại hình âm nhạc truyền thống Việt Nam đã được UNESCO ghi danh và vùng của mỗi loại.','Ví dụ: Nhã nhạc cung đình Huế (Trung Bộ, 2003); Không gian văn hóa cồng chiêng Tây Nguyên (2005); Dân ca quan họ Bắc Ninh (Bắc Bộ, 2009); Ca trù (Bắc Bộ, 2009); Hát xoan Phú Thọ (2011); Đờn ca tài tử Nam Bộ (2013); Ví giặm Nghệ Tĩnh (2014).'],
  [3,'Hãy xây dựng kế hoạch dàn dựng một tiết mục biểu diễn tổng hợp (hát, nhạc cụ, vận động) cho nhóm để biểu diễn trong lễ tổng kết năm học.','HS nêu được: bài hát và lí do chọn; hình thức (tốp ca có bè, lĩnh xướng); phân công người hát, người chơi nhạc cụ, người vận động; lịch tập; trang phục, đạo cụ; cách mở đầu và kết tiết mục.'],
  [4,'Vì sao việc bảo tồn các loại hình âm nhạc truyền thống được UNESCO ghi danh không chỉ là trách nhiệm của nghệ nhân mà còn của học sinh? Em hãy phân tích và đề xuất hành động cụ thể.','Di sản âm nhạc chỉ sống khi có người nghe, người hiểu và người kế thừa; nghệ nhân ngày càng ít, nếu thế hệ trẻ quay lưng thì di sản sẽ dần mai một dù đã được ghi danh. Học sinh là lớp người kế tục, hiểu biết và yêu thích của các em quyết định tương lai của di sản. Hành động: tìm hiểu, tập hát một làn điệu, tham gia câu lạc bộ dân ca, tổ chức tiết mục truyền thống trong trường, giới thiệu di sản trên mạng xã hội một cách trân trọng, tôn trọng và học hỏi nghệ nhân.']
 ]);
 add(M,9,'(Bổ sung) Nhạc lí và thường thức',[
  [1,'Quãng giữa hai nốt Rê và La (đi lên) là quãng mấy?','quãng 5','quãng 4','quãng 3','quãng 6'],
  [1,'Bài hát có hóa biểu một dấu thăng và kết ở nốt Mi thường viết ở giọng nào?','Mi thứ','Son trưởng','La thứ','Rê thứ'],
  [1,'Bài hát có hóa biểu một dấu giáng và kết ở nốt Pha thường viết ở giọng nào?','Pha trưởng','Rê thứ','Đô trưởng','Son trưởng'],
  [2,'Hợp âm ba của giọng Son trưởng xây trên bậc I gồm các nốt nào?','Son – Si – Rê','Son – La – Si','Son – Đô – Mi','Son – Si – Mi'],
  [2,'Hợp âm ba của giọng Mi thứ xây trên bậc I gồm các nốt nào?','Mi – Son – Si','Mi – Son thăng – Si','Mi – Pha thăng – Son','Mi – La – Đô'],
  [2,'Khi dịch một bài từ giọng Đô trưởng lên giọng Rê trưởng, mọi nốt được chuyển lên quãng mấy?','quãng 2','quãng 3','quãng 5','quãng 8'],
  [3,'Em hãy xác định giọng của một bài hát có hóa biểu một dấu thăng, nốt kết là Son và giải thích.','Hóa biểu một dấu thăng cho biết bài ở Son trưởng hoặc Mi thứ (hai giọng song song); nốt kết là Son – âm chủ của Son trưởng – nên bài hát ở giọng Son trưởng.'],
  [3,'Em hãy so sánh cấu tạo hợp âm ba trưởng và hợp âm ba thứ qua ví dụ hợp âm Pha trưởng và Rê thứ.','Pha trưởng: Pha – La – Đô, quãng 3 dưới (Pha – La) là 3 trưởng, quãng 3 trên (La – Đô) là 3 thứ. Rê thứ: Rê – Pha – La, quãng 3 dưới (Rê – Pha) là 3 thứ, quãng 3 trên (Pha – La) là 3 trưởng. Vị trí của quãng 3 trưởng và 3 thứ đảo nhau tạo ra màu sắc trưởng hoặc thứ.'],
  [3,'Em hãy kể tên bốn nhạc sĩ nước ngoài đã học ở cấp THCS theo thứ tự thời gian và nêu quốc tịch của mỗi người.','Mô-da (Áo, thế kỉ XVIII) – Bét-tô-ven (Đức, cuối thế kỉ XVIII – đầu XIX) – Sô-panh (Ba Lan, thế kỉ XIX) – Trai-cốp-xki (Nga, thế kỉ XIX).'],
  [4,'Phân tích vì sao kiến thức về quãng, giọng và dịch giọng lại cần thiết cho việc tập hát và dàn dựng tiết mục ở trường.','Hiểu quãng giúp hát đúng cao độ, hát bè chuẩn (ví dụ bè quãng 3) và nhận biết màu sắc trưởng – thứ của bài. Hiểu giọng giúp xác định âm chủ, hóa biểu, đọc đúng nốt thăng giáng và chọn hợp âm đệm phù hợp. Hiểu dịch giọng giúp đưa bài hát về tầm cữ phù hợp với giọng học sinh hoặc nhạc cụ sẵn có, tránh hát quá cao hoặc quá thấp. Kết hợp ba kiến thức này, người dàn dựng chọn được bài, phân bè và đệm hát hợp lí, tiết mục nghe hòa hợp và dễ hát hơn.']
 ]);
})();
