/* NGÂN HÀNG CÂU HỎI CÓ HÌNH – TN&XH, Khoa học, KHTN, Địa lí, Tiếng Anh — bổ sung đủ chuẩn. Câu hỏi nguyên bản, bám SGK Kết nối tri thức. Mỗi câu có phần tử cuối '@img:...' (engine hinhanh.js). */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 /* ===================== TỰ NHIÊN VÀ XÃ HỘI ===================== */
 var M='Tự nhiên và Xã hội';
 add(M,1,'Gia đình và trường học',[
  [1,'Quan sát hình gia đình. Việc làm nào thể hiện tình cảm yêu thương với người thân trong gia đình?','Giúp bố mẹ làm việc nhà vừa sức','Đòi mua đồ chơi mới mỗi ngày','Không chào hỏi ông bà','Bỏ bữa cơm cùng gia đình','@img:ILLUS:giadinh'],
  [1,'Hình vẽ ngôi trường. Khi gặp thầy cô ở trường, em cần làm gì?','Lễ phép chào hỏi thầy cô','Chạy nhanh qua không chào','Nói to, cười đùa','Quay mặt đi chỗ khác','@img:ILLUS:truonghoc'],
  [3,'Nhìn hình gia đình, em hãy kể hai việc em có thể làm để giúp đỡ người thân trong gia đình.','Ví dụ: quét nhà, lau bàn, gấp quần áo, lấy nước mời ông bà, trông em giúp mẹ... (nêu được hai việc vừa sức).','@img:ILLUS:giadinh']
 ]);
 add(M,1,'Thực vật và động vật',[
  [1,'Quan sát cây trong hình. Bộ phận nào của cây nằm dưới mặt đất?','Rễ','Lá','Hoa','Thân','@img:ILLUS:caytrong'],
  [1,'Có bao nhiêu con cá trong hình? Cá là động vật sống ở đâu?','Có 5 con cá; cá sống ở dưới nước.','@img:dem:ca:5'],
  [1,'Trong hình có mấy con chim?','3 con','2 con','4 con','5 con','@img:dem:chim:3'],
  [2,'Quan sát những con bướm trong hình. Bướm di chuyển bằng cách nào?','Bay bằng cánh','Bơi bằng vây','Bò bằng bụng','Chạy bằng chân','@img:dem:buom:4']
 ]);
 add(M,1,'Con người và sức khỏe',[
  [1,'Quan sát hình cơ thể người. Bộ phận nào giúp em nhìn thấy mọi vật xung quanh?','Mắt','Tai','Mũi','Lưỡi','@img:ILLUS:cothe'],
  [2,'Quan sát hình cơ thể. Để bảo vệ tai, em không nên làm gì?','Dùng vật nhọn ngoáy tai','Giữ tai sạch sẽ','Tránh nghe tiếng ồn quá to','Lau khô tai sau khi tắm','@img:ILLUS:cothe'],
  [3,'Quan sát hình đĩa chất dinh dưỡng. Vì sao hằng ngày em cần ăn nhiều loại thức ăn khác nhau?','Vì mỗi loại thức ăn cung cấp những chất khác nhau; ăn đủ nhiều loại thức ăn giúp cơ thể khỏe mạnh, lớn lên và ít bị bệnh.','@img:ILLUS:dinhduong']
 ]);
 add(M,1,'Trái Đất và bầu trời',[
  [1,'Quan sát hình thời tiết. Khi trời mưa, em cần mang theo gì khi ra ngoài?','Ô hoặc áo mưa','Kính râm','Quạt giấy','Khăn mỏng','@img:ILLUS:thoitiet'],
  [1,'Quan sát hình bầu trời. Vật nào chiếu sáng và sưởi ấm Trái Đất vào ban ngày?','Mặt Trời','Mặt Trăng','Các ngôi sao','Đám mây','@img:ILLUS:vutru'],
  [4,'Quan sát hình thời tiết. Vì sao em cần xem dự báo thời tiết trước khi đi học hoặc đi chơi?','Vì biết trước trời nắng, mưa hay lạnh giúp em chuẩn bị trang phục và đồ dùng phù hợp (áo mưa, mũ, áo ấm), tránh bị ốm và giữ an toàn cho bản thân.','@img:ILLUS:thoitiet']
 ]);
 add(M,1,'Cộng đồng địa phương',[
  [1,'Quan sát hình. Khi đi bộ trên đường phố, em nên đi ở đâu để an toàn?','Trên vỉa hè, sát lề bên phải','Giữa lòng đường','Trên làn xe ô tô','Chạy qua đường ở bất cứ chỗ nào','@img:ILLUS:antoan'],
  [2,'Quan sát những chiếc ô tô trong hình. Khi muốn sang đường có xe cộ qua lại, em cần làm gì?','Đi trên vạch kẻ dành cho người đi bộ và có người lớn dắt','Chạy thật nhanh qua đường','Đi ở nơi xe đang chạy','Vừa đi vừa chơi điện thoại','@img:dem:xe:3']
 ]);
 add(M,2,'Gia đình và trường học',[
  [1,'Quan sát hình gia đình. Để phòng tránh ngộ độc khi ở nhà, em cần làm gì?','Không ăn thức ăn ôi thiu, không uống nước lạ','Ăn thức ăn để lâu ngày','Tự ý uống thuốc trong tủ','Uống nước trong chai không có nhãn','@img:ILLUS:giadinh'],
  [2,'Quan sát hình ngôi trường. Khi ở trường, việc làm nào có thể gây nguy hiểm?','Chạy nhảy, xô đẩy nhau ở cầu thang','Đi nhẹ, nói khẽ trong hành lang','Chơi ở sân trường theo hướng dẫn','Xếp hàng ngay ngắn khi ra về','@img:ILLUS:truonghoc'],
  [3,'Quan sát hình ngôi trường. Hãy kể tên hai sự kiện thường được tổ chức ở trường em và nêu ý nghĩa của một sự kiện.','Ví dụ: lễ khai giảng, ngày hội đọc sách, ngày Nhà giáo Việt Nam 20/11... Lễ khai giảng mở đầu năm học mới, giúp học sinh vui vẻ, háo hức bước vào năm học.','@img:ILLUS:truonghoc']
 ]);
 add(M,2,'Cộng đồng địa phương',[
  [1,'Quan sát hình đồng ruộng. Người nông dân làm ra sản phẩm nào sau đây?','Lúa gạo','Quần áo','Máy tính','Ô tô','@img:ILLUS:nongnghiep'],
  [2,'Quan sát hình. Khi ngồi xe máy cùng bố mẹ, em cần làm gì để giữ an toàn?','Đội mũ bảo hiểm và ngồi ngay ngắn','Đứng lên yên xe','Thò tay ra ngoài vẫy','Không cần đội mũ bảo hiểm vì đi gần','@img:ILLUS:antoan']
 ]);
 add(M,2,'Thực vật và động vật',[
  [1,'Cây trong hình được trồng trong đất. Cây này sống ở môi trường nào?','Trên cạn','Dưới nước','Trong không khí','Trong hang đá','@img:ILLUS:caytrong'],
  [1,'Trong hình có mấy con cá? Những con vật này sống ở môi trường nào?','Có 5 con cá; chúng sống ở dưới nước (ao, hồ, sông, biển).','@img:dem:ca:5'],
  [2,'Quan sát hình con vật nuôi. Việc làm nào giúp bảo vệ môi trường sống của động vật?','Không xả rác, không phá rừng','Săn bắt động vật hoang dã','Đổ rác xuống ao hồ','Chặt cây bừa bãi','@img:ILLUS:dongvat']
 ]);
 add(M,2,'Con người và sức khỏe',[
  [1,'Quan sát hình cơ quan hô hấp. Bộ phận nào trong hình gồm hai lá?','Phổi','Mũi','Khí quản','Dạ dày','@img:ILLUS:hohap'],
  [2,'Quan sát hình cơ quan hô hấp. Khi hít vào, không khí đi theo thứ tự nào?','Mũi → khí quản → phế quản → phổi','Phổi → khí quản → mũi','Mũi → dạ dày → phổi','Miệng → ruột → phổi','@img:ILLUS:hohap'],
  [4,'Quan sát hình cơ quan hô hấp. Vì sao chúng ta nên thở bằng mũi mà không nên thở bằng miệng?','Trong mũi có lông mũi và chất nhầy giúp cản bụi, làm ấm và làm ẩm không khí trước khi vào phổi. Thở bằng miệng, không khí không được lọc nên dễ gây bệnh đường hô hấp.','@img:ILLUS:hohap']
 ]);
 add(M,2,'Trái Đất và bầu trời',[
  [1,'Nhiệt kế trong hình chỉ bao nhiêu độ? Thời tiết lúc đó như thế nào?','Nhiệt kế chỉ 35°C; thời tiết nóng, em cần mặc quần áo thoáng mát và uống đủ nước.','@img:nhietke:35'],
  [2,'Nhiệt kế trong hình chỉ 10°C. Em nên mặc trang phục nào khi đi học?','Áo ấm, khăn quàng','Áo cộc tay','Quần đùi, áo ba lỗ','Đồ bơi','@img:nhietke:10'],
  [1,'Quan sát hình bầu trời. Những vật nào thường chỉ nhìn thấy rõ vào ban đêm?','Mặt Trăng và các ngôi sao','Mặt Trời','Cầu vồng','Đám mây trắng','@img:ILLUS:vutru']
 ]);
 add(M,3,'Gia đình và trường học',[
  [1,'Quan sát hình gia đình. Anh, chị, em ruột của bố em được gọi là gì?','Họ hàng bên nội','Họ hàng bên ngoại','Hàng xóm','Bạn bè của bố','@img:ILLUS:giadinh'],
  [2,'Quan sát hình. Khi phát hiện có cháy trong nhà, em cần làm gì trước tiên?','Hô to báo cho mọi người và thoát ra ngoài','Chạy vào lấy đồ chơi','Trốn trong tủ quần áo','Dùng thang máy để xuống','@img:ILLUS:antoan']
 ]);
 add(M,3,'Cộng đồng địa phương',[
  [1,'Quan sát hình đồng ruộng. Sản phẩm của hoạt động sản xuất trong hình được dùng để làm gì?','Làm lương thực cho con người','Làm máy móc','Làm đồ dùng học tập','Làm quần áo','@img:ILLUS:nongnghiep'],
  [2,'Quan sát hình di tích. Khi đến tham quan di tích lịch sử, văn hóa, em không nên làm gì?','Viết, vẽ lên tường di tích','Giữ trật tự, đi nhẹ nói khẽ','Lắng nghe hướng dẫn viên','Bỏ rác đúng nơi quy định','@img:ILLUS:den'],
  [3,'Quan sát hình di tích lịch sử. Vì sao chúng ta cần giữ gìn các di tích lịch sử, văn hóa ở địa phương?','Vì di tích ghi dấu truyền thống, lịch sử của ông cha; giữ gìn di tích giúp thế hệ sau hiểu về quá khứ, tự hào về quê hương và góp phần phát triển du lịch.','@img:ILLUS:den']
 ]);
 add(M,3,'Thực vật và động vật',[
  [1,'Quan sát hình cây. Bộ phận nào của cây có chức năng hút nước và chất khoáng từ đất?','Rễ','Lá','Hoa','Quả','@img:ILLUS:caytrong'],
  [2,'Quan sát hình cây. Lá cây có chức năng chính nào?','Quang hợp, hô hấp và thoát hơi nước','Hút nước từ đất','Tạo ra hạt','Giữ cây đứng vững trong đất','@img:ILLUS:caytrong'],
  [2,'Quan sát con vật trong hình. Cơ thể của động vật này gồm những phần nào?','Đầu, mình và cơ quan di chuyển','Rễ, thân, lá','Đầu, cánh, vây','Thân, lá, hoa','@img:ILLUS:dongvat'],
  [3,'Trong hình có mấy con chim? Chim di chuyển bằng cách nào và cơ quan di chuyển của chim là gì?','Có 3 con chim; chim di chuyển bằng cách bay (và đi bằng chân); cơ quan di chuyển là cánh và chân.','@img:dem:chim:3']
 ]);
 add(M,3,'Con người và sức khỏe',[
  [1,'Quan sát hình dạ dày. Thức ăn từ miệng đi xuống dạ dày qua bộ phận nào?','Thực quản','Khí quản','Ruột non','Ruột già','@img:ILLUS:tieuhoa'],
  [2,'Quan sát hình dạ dày. Việc làm nào có hại cho cơ quan tiêu hóa?','Ăn quá no rồi chạy nhảy ngay','Ăn chậm, nhai kĩ','Ăn đúng giờ','Rửa tay trước khi ăn','@img:ILLUS:tieuhoa'],
  [1,'Quan sát hình trái tim. Cơ quan tuần hoàn gồm những bộ phận nào?','Tim và các mạch máu','Phổi và khí quản','Não và tủy sống','Dạ dày và ruột','@img:ILLUS:tuanhoan'],
  [2,'Quan sát hình tim. Máu từ tim được đưa đi nuôi cơ thể theo loại mạch máu nào?','Động mạch','Tĩnh mạch','Khí quản','Thực quản','@img:ILLUS:tuanhoan'],
  [1,'Quan sát hình bộ não. Cơ quan thần kinh gồm những bộ phận nào?','Não, tủy sống và các dây thần kinh','Tim và mạch máu','Phổi và khí quản','Xương và cơ','@img:ILLUS:thankinh'],
  [4,'Quan sát hình bộ não. Vì sao khi ngủ đủ giấc, ăn uống điều độ thì cơ quan thần kinh được bảo vệ tốt hơn?','Khi ngủ, não và cơ quan thần kinh được nghỉ ngơi, phục hồi sau một ngày hoạt động. Ăn uống điều độ cung cấp đủ chất dinh dưỡng cho não. Thiếu ngủ, căng thẳng kéo dài làm thần kinh mệt mỏi, giảm trí nhớ và khả năng tập trung.','@img:ILLUS:thankinh']
 ]);
 add(M,3,'Trái Đất và bầu trời',[
  [1,'Quan sát hình la bàn. Nếu em đứng quay mặt về phía Bắc thì phía sau lưng em là hướng nào?','Nam','Đông','Tây','Đông Bắc','@img:phuonghuong'],
  [2,'Quan sát hình la bàn. Buổi sáng, Mặt Trời mọc ở hướng nào?','Đông','Tây','Nam','Bắc','@img:phuonghuong'],
  [1,'Quan sát hình Mặt Trời, Trái Đất, Mặt Trăng. Mặt Trăng là vệ tinh của thiên thể nào?','Trái Đất','Mặt Trời','Sao Hỏa','Sao Kim','@img:ILLUS:vutru'],
  [2,'Quan sát hình. Dạng địa hình nào nhô cao rõ rệt, có đỉnh nhọn và sườn dốc?','Núi','Đồng bằng','Cao nguyên','Biển','@img:ILLUS:nui'],
  [3,'Quan sát hình biển đảo. Hãy nêu hai lợi ích của biển đối với đời sống con người.','Biển cho tôm cá, muối, dầu mỏ; là nơi phát triển du lịch, giao thông đường biển; biển còn giúp điều hòa khí hậu.','@img:ILLUS:bien']
 ]);
 /* ===================== KHOA HỌC ===================== */
 M='Khoa học';
 add(M,4,'Chất: nước và không khí',[
  [1,'Quan sát hình ba trạng thái của chất. Nước đá thuộc thể nào?','Thể rắn','Thể lỏng','Thể khí','Thể dẻo','@img:ILLUS:chat'],
  [2,'Quan sát hình ba trạng thái của chất. Khi nước ở thể lỏng bị đun nóng và bay hơi, nước chuyển sang thể nào?','Thể khí','Thể rắn','Thể lỏng','Không thay đổi thể','@img:ILLUS:chat'],
  [1,'Nhiệt kế trong hình chỉ nhiệt độ của nước đang sôi. Nhiệt độ đó là bao nhiêu?','100°C','0°C','37°C','50°C','@img:nhietke:100'],
  [2,'Nhiệt kế trong hình chỉ 0°C. Ở nhiệt độ này, nước có hiện tượng gì?','Nước bắt đầu đông thành đá (thể rắn)','Nước sôi mạnh','Nước bay hơi hết','Nước chuyển thành hơi','@img:nhietke:0'],
  [3,'Quan sát hình vòng tuần hoàn của nước. Hãy mô tả ngắn gọn các giai đoạn trong vòng tuần hoàn của nước trong tự nhiên.','Nước ở sông, hồ, biển bay hơi lên cao; gặp lạnh, hơi nước ngưng tụ thành mây; mây nặng tạo thành mưa rơi xuống; nước mưa chảy ra sông, hồ, biển rồi lại bay hơi.','@img:ILLUS:vongnuoc'],
  [1,'Quan sát hình không khí chuyển động. Không khí chuyển động tạo thành gì?','Gió','Mưa','Sấm sét','Sương mù','@img:ILLUS:khongkhi'],
  [2,'Quan sát hình cốc nước. Hòa tan đường vào nước, ta được gì?','Dung dịch nước đường','Nước đá','Hơi nước','Cát lắng trong nước','@img:ILLUS:nuoc']
 ]);
 add(M,4,'Năng lượng: ánh sáng, âm thanh, nhiệt',[
  [1,'Quan sát hình. Khi một vật chắn ánh sáng, phía sau vật xuất hiện gì?','Bóng tối','Cầu vồng','Ánh sáng mạnh hơn','Hơi nước','@img:ILLUS:anhsang'],
  [2,'Quan sát hình chiếc loa. Âm thanh phát ra từ loa truyền đến tai ta chủ yếu qua môi trường nào?','Không khí','Chân không','Chỉ qua dây điện','Ánh sáng','@img:ILLUS:amthanh'],
  [1,'Nhiệt kế trong hình chỉ nhiệt độ cơ thể người khỏe mạnh. Giá trị đó khoảng bao nhiêu?','37°C','100°C','0°C','50°C','@img:nhietke:37'],
  [4,'Bảng ghi nhiệt độ của một cốc nước nóng để trong phòng, đo sau mỗi 10 phút (số liệu giả định). Em rút ra kết luận gì về sự truyền nhiệt? Giải thích.','Nhiệt độ cốc nước giảm dần theo thời gian vì cốc nước nóng truyền nhiệt cho không khí xung quanh lạnh hơn. Vật nóng luôn truyền nhiệt cho vật lạnh hơn cho đến khi nhiệt độ hai vật bằng nhau.','@img:bang:Thời gian;Nhiệt độ|0 phút;80°C|10 phút;60°C|20 phút;45°C|30 phút;35°C']
 ]);
 add(M,4,'Thực vật, động vật và nấm',[
  [1,'Quan sát hình cây. Thực vật cần những gì để sống và phát triển?','Nước, ánh sáng, không khí, chất khoáng','Chỉ cần nước','Chỉ cần đất','Chỉ cần ánh sáng','@img:ILLUS:caytrong'],
  [2,'Quan sát hình nấm. Nhận định nào sau đây đúng?','Có nấm ăn được và có nấm độc, không nên ăn nấm lạ','Mọi loại nấm đều ăn được','Nấm là thực vật vì có lá xanh','Nấm chỉ mọc ở nơi khô ráo','@img:ILLUS:nam'],
  [3,'Trong hình có mấy cây nấm? Nấm thường mọc ở những nơi nào và vì sao ta không nên tự ý hái nấm lạ trong rừng để ăn?','Có 3 cây nấm. Nấm thường mọc ở nơi ẩm ướt, có chất hữu cơ (gốc cây mục, đất ẩm). Không nên hái nấm lạ để ăn vì nhiều loại nấm độc trông giống nấm ăn được, có thể gây ngộ độc nguy hiểm.','@img:dem:nam:3']
 ]);
 add(M,4,'Con người và sức khỏe',[
  [1,'Quan sát hình đĩa chất dinh dưỡng. Nhóm chất nào cung cấp năng lượng chính cho cơ thể?','Chất bột đường','Vi-ta-min','Chất khoáng','Nước','@img:ILLUS:dinhduong'],
  [2,'Quan sát hình đĩa chất dinh dưỡng. Nhóm thức ăn nào giàu chất đạm?','Thịt, cá, trứng, đậu','Cơm, bánh mì','Rau xanh','Dầu ăn, mỡ','@img:ILLUS:dinhduong']
 ]);
 add(M,4,'Sinh vật và môi trường',[
  [1,'Quan sát chuỗi thức ăn cỏ → sâu → chim. Sinh vật nào là sinh vật sản xuất?','Cỏ','Sâu','Chim','Cả sâu và chim','@img:ILLUS:chuoithucan'],
  [2,'Trong chuỗi thức ăn ở hình, sâu là thức ăn của sinh vật nào?','Chim','Cỏ','Không sinh vật nào','Mặt Trời','@img:ILLUS:chuoithucan'],
  [4,'Quan sát chuỗi thức ăn cỏ → sâu → chim. Nếu con người phun thuốc diệt hết sâu thì điều gì có thể xảy ra với chim? Giải thích.','Chim thiếu thức ăn, số lượng chim giảm hoặc phải đi nơi khác kiếm ăn. Vì trong chuỗi thức ăn, các sinh vật phụ thuộc lẫn nhau; mất một mắt xích sẽ ảnh hưởng đến các mắt xích phía sau.','@img:ILLUS:chuoithucan']
 ]);
 add(M,5,'Chất',[
  [1,'Quan sát hình cốc nước có chất tan phân bố đều. Hỗn hợp nào sau đây là dung dịch?','Nước muối','Cát trộn với sỏi','Gạo lẫn trấu','Dầu ăn nổi trên nước','@img:ILLUS:nuoc'],
  [2,'Quan sát hình ba thể của chất. Sự chuyển từ thể lỏng sang thể rắn được gọi là gì?','Đông đặc','Bay hơi','Ngưng tụ','Nóng chảy','@img:ILLUS:chat'],
  [3,'Nhiệt kế trong hình chỉ 100°C. Ở nhiệt độ này nước có hiện tượng gì? Hiện tượng đó là biến đổi vật lí hay biến đổi hóa học? Vì sao?','Nước sôi và bay hơi mạnh. Đây là biến đổi vật lí vì nước chỉ chuyển thể từ lỏng sang khí, vẫn là nước, không tạo ra chất mới.','@img:nhietke:100']
 ]);
 add(M,5,'Năng lượng',[
  [1,'Quan sát mạch điện trong hình. Vì sao bóng đèn sáng?','Mạch điện kín, công tắc đóng nên có dòng điện chạy qua đèn','Vì công tắc đang mở','Vì không có pin','Vì dây dẫn bị đứt','@img:ILLUS:dien'],
  [2,'Quan sát mạch điện gồm pin, công tắc và bóng đèn. Nếu mở công tắc thì điều gì xảy ra?','Mạch hở, đèn tắt','Đèn sáng hơn','Pin hết điện ngay','Đèn vẫn sáng bình thường','@img:ILLUS:dien'],
  [1,'Quan sát hình Mặt Trời. Năng lượng mặt trời được con người sử dụng để làm gì?','Phơi khô quần áo, làm muối, chạy pin mặt trời','Làm nước đóng băng','Làm tối phòng học','Làm cây chậm lớn','@img:ILLUS:nangluong'],
  [4,'Quan sát hình năng lượng mặt trời. Vì sao năng lượng mặt trời, gió, nước chảy được gọi là năng lượng sạch, còn than đá, dầu mỏ thì không?','Năng lượng mặt trời, gió, nước chảy là năng lượng tái tạo, không cạn kiệt và khi sử dụng không thải khí gây ô nhiễm. Than đá, dầu mỏ có hạn, khi đốt thải khói bụi và khí các-bô-níc gây ô nhiễm không khí và biến đổi khí hậu.','@img:ILLUS:nangluong']
 ]);
 add(M,5,'Thực vật và động vật',[
  [1,'Quan sát hình hạt nảy mầm. Bộ phận nào của hạt mọc ra trước tiên khi hạt nảy mầm?','Rễ mầm','Lá thật','Hoa','Quả','@img:ILLUS:hat'],
  [2,'Quan sát hình hạt nảy mầm. Hạt cần những điều kiện nào để nảy mầm?','Đủ nước, không khí và nhiệt độ thích hợp','Chỉ cần ánh sáng mạnh','Ngâm hoàn toàn trong nước lâu ngày','Để ở nơi khô ráo, không tưới','@img:ILLUS:hat'],
  [3,'Quan sát hình từ hạt nảy mầm thành cây. Hãy nêu thứ tự các giai đoạn phát triển của cây mọc lên từ hạt.','Hạt hút nước và nảy mầm → rễ mầm đâm xuống đất, thân mầm vươn lên → cây con có lá → cây trưởng thành ra hoa, kết quả và tạo hạt mới.','@img:ILLUS:hat']
 ]);
 add(M,5,'Vi khuẩn',[
  [1,'Quan sát hình vi khuẩn. Để nhìn thấy vi khuẩn, ta cần dùng dụng cụ nào?','Kính hiển vi','Kính lúp','Mắt thường','Ống nhòm','@img:ILLUS:vikhuan'],
  [2,'Quan sát hình vi khuẩn. Loại vi khuẩn nào sau đây có ích cho con người?','Vi khuẩn lên men làm sữa chua','Vi khuẩn gây bệnh tả','Vi khuẩn làm hỏng thức ăn','Vi khuẩn gây sâu răng','@img:ILLUS:vikhuan'],
  [4,'Quan sát hình vi khuẩn. Vì sao thức ăn để trong tủ lạnh lâu hỏng hơn để ở ngoài?','Vi khuẩn sinh sản rất nhanh ở nhiệt độ ấm. Nhiệt độ thấp trong tủ lạnh làm vi khuẩn hoạt động và sinh sản chậm lại nên thức ăn lâu hỏng hơn. Tuy nhiên tủ lạnh không diệt được vi khuẩn nên thức ăn vẫn không để được mãi.','@img:ILLUS:vikhuan']
 ]);
 add(M,5,'Con người và sức khỏe',[
  [1,'Quan sát hình đĩa dinh dưỡng. Ở tuổi dậy thì, cơ thể lớn nhanh nên cần chú ý điều gì trong ăn uống?','Ăn đủ chất, đủ bữa, nhiều rau quả','Bỏ bữa sáng để giảm cân','Chỉ ăn đồ ăn nhanh','Uống nhiều nước ngọt có ga','@img:ILLUS:dinhduong'],
  [2,'Quan sát hình. Khi có người lạ rủ đi chơi hoặc đụng chạm khiến em khó chịu, em cần làm gì?','Nói không, bỏ đi và kể với người tin cậy','Im lặng làm theo','Giữ bí mật không nói với ai','Đi theo vì được cho quà','@img:ILLUS:antoan']
 ]);
 add(M,5,'Sinh vật và môi trường',[
  [2,'Biểu đồ cho biết diện tích rừng của một địa phương qua các năm (đơn vị: nghìn ha, số liệu giả định). Diện tích rừng thay đổi như thế nào từ năm 2000 đến năm 2020?','Giảm dần','Tăng dần','Không đổi','Tăng rồi giảm','@img:bieudo:cot:2000=50,2010=40,2020=30'],
  [3,'Quan sát hình Trái Đất. Hãy nêu hai việc con người làm gây ảnh hưởng xấu đến môi trường và hai việc giúp bảo vệ môi trường.','Gây hại: chặt phá rừng, xả rác và nước thải chưa xử lí ra sông biển, dùng nhiều túi ni lông. Bảo vệ: trồng cây, phân loại và tái chế rác, tiết kiệm điện nước, dùng túi vải thay túi ni lông.','@img:ILLUS:moitruong']
 ]);
 /* ===================== KHOA HỌC TỰ NHIÊN ===================== */
 M='Khoa học tự nhiên';
 add(M,6,'Bài 5: Đo chiều dài',[
  [1,'Đoạn thẳng màu xanh đặt trên thước có độ dài bao nhiêu?','6 cm','5 cm','7 cm','60 cm','@img:thuoc:6'],
  [2,'Quan sát thước trong hình. Giới hạn đo (GHĐ) của thước là bao nhiêu?','10 cm','6 cm','1 cm','100 cm','@img:thuoc:6']
 ]);
 add(M,6,'Bài 6: Đo khối lượng',[
  [1,'Dụng cụ trong hình dùng để đo đại lượng nào?','Khối lượng','Chiều dài','Thời gian','Nhiệt độ','@img:ILLUS:can']
 ]);
 add(M,6,'Bài 8: Đo nhiệt độ',[
  [1,'Nhiệt kế trong hình chỉ bao nhiêu độ C? Đó thường là nhiệt độ của vật nào?','Nhiệt kế chỉ 37°C; đây là nhiệt độ bình thường của cơ thể người khỏe mạnh.','@img:nhietke:37'],
  [1,'Nhiệt kế trong hình chỉ nhiệt độ sôi của nước ở điều kiện thường. Giá trị đó là bao nhiêu?','100°C','0°C','37°C','80°C','@img:nhietke:100'],
  [4,'Bảng ghi nhiệt độ của nước khi đun liên tục (số liệu giả định). Từ phút thứ 6 trở đi nhiệt độ không tăng nữa dù vẫn đun. Hãy giải thích.','Khi đạt 100°C, nước sôi; nhiệt lượng cung cấp tiếp được dùng để nước chuyển từ thể lỏng sang thể hơi chứ không làm nước nóng thêm. Vì vậy trong suốt thời gian sôi, nhiệt độ của nước giữ nguyên ở 100°C (nhiệt độ sôi) cho đến khi nước bay hơi hết.','@img:bang:Phút;°C|0;25|2;50|4;75|6;100|8;100']
 ]);
 add(M,6,'Bài 10: Các thể của chất và sự chuyển thể',[
  [1,'Quan sát hình ba thể của chất. Ở thể nào các hạt sắp xếp chặt chẽ, chất có hình dạng và thể tích xác định?','Thể rắn','Thể lỏng','Thể khí','Thể hơi','@img:ILLUS:chat'],
  [2,'Quan sát hình ba thể của chất. Thể nào dễ bị nén, không có hình dạng và thể tích xác định?','Thể khí','Thể rắn','Thể lỏng','Cả thể rắn và lỏng','@img:ILLUS:chat']
 ]);
 add(M,6,'Bài 11: Oxygen. Không khí',[
  [1,'Biểu đồ cho biết thành phần không khí theo thể tích (%). Khí nào chiếm tỉ lệ lớn nhất?','Nitrogen (78%)','Oxygen (21%)','Carbon dioxide','Hơi nước','@img:bieudo:cot:Nitrogen=78,Oxygen=21,Khác=1'],
  [3,'Quan sát hình không khí. Nêu vai trò của oxygen trong không khí đối với sự sống và sự cháy.','Oxygen cần cho sự hô hấp của người, động vật, thực vật; không có oxygen sinh vật không sống được. Oxygen cũng cần cho sự cháy: nhiên liệu chỉ cháy được khi có đủ oxygen, do đó muốn dập lửa có thể ngăn không cho tiếp xúc với oxygen.','@img:ILLUS:khongkhi']
 ]);
 add(M,6,'Bài 16: Hỗn hợp các chất',[
  [2,'Hình vẽ cốc nước có chất tan phân bố đều trong nước. Hỗn hợp như vậy được gọi là gì?','Dung dịch (hỗn hợp đồng nhất)','Huyền phù','Nhũ tương','Chất tinh khiết','@img:ILLUS:nuoc']
 ]);
 add(M,6,'Bài 27: Vi khuẩn',[
  [1,'Quan sát hình vi khuẩn. Vi khuẩn là sinh vật có đặc điểm cấu tạo nào?','Cơ thể đơn bào, nhân sơ (chưa có nhân hoàn chỉnh)','Cơ thể đa bào, có nhân','Không có cấu tạo tế bào','Cơ thể có rễ, thân, lá','@img:ILLUS:vikhuan']
 ]);
 add(M,6,'Bài 32: Nấm',[
  [1,'Quan sát hình nấm. Trong hệ thống phân loại năm giới, nấm được xếp vào giới nào?','Giới Nấm','Giới Thực vật','Giới Động vật','Giới Khởi sinh','@img:ILLUS:nam']
 ]);
 add(M,6,'Bài 53: Mặt Trăng',[
  [2,'Quan sát hình Mặt Trời, Trái Đất, Mặt Trăng. Mặt Trăng không tự phát sáng nhưng ta vẫn nhìn thấy Mặt Trăng vì sao?','Mặt Trăng phản xạ ánh sáng mặt trời','Mặt Trăng tự phát ra ánh sáng','Trái Đất chiếu sáng Mặt Trăng','Các ngôi sao chiếu sáng Mặt Trăng','@img:ILLUS:vutru']
 ]);
 add(M,6,'Bài 54: Hệ Mặt Trời',[
  [1,'Quan sát hình Mặt Trời, Trái Đất, Mặt Trăng. Trong hệ Mặt Trời, Trái Đất là hành tinh thứ mấy tính từ Mặt Trời?','Thứ ba','Thứ nhất','Thứ hai','Thứ tư','@img:ILLUS:vutru']
 ]);
 add(M,6,'Bài 50: Năng lượng tái tạo',[
  [2,'Quan sát hình Mặt Trời. Năng lượng mặt trời là năng lượng tái tạo hay không tái tạo? Vì sao?','Năng lượng mặt trời là năng lượng tái tạo vì nguồn năng lượng này có sẵn trong thiên nhiên, liên tục được bổ sung và coi như vô tận, không bị cạn kiệt khi sử dụng.','@img:ILLUS:nangluong']
 ]);
 add(M,7,'Bài 3: Nguyên tố hóa học',[
  [2,'Bảng cho số hiệu nguyên tử của bốn nguyên tố. Nguyên tố nào có 3 proton trong hạt nhân?','Li','H','He','Be','@img:bang:Nguyên tố;Số hiệu|H;1|He;2|Li;3|Be;4']
 ]);
 add(M,7,'Bài 8: Tốc độ chuyển động',[
  [2,'Bảng ghi quãng đường và thời gian đi của một ô tô. Tốc độ của ô tô là bao nhiêu?','30 km/h','120 km/h','62 km/h','58 km/h','@img:bang:Quãng đường;Thời gian|60 km;2 h']
 ]);
 add(M,7,'Bài 9: Đo tốc độ',[
  [3,'Bảng ghi thời gian ba lần đo khi một xe đồ chơi đi hết quãng đường 10 m. Tính thời gian trung bình và tốc độ trung bình của xe.','Thời gian trung bình t = (2,1 + 2,0 + 1,9) : 3 = 2,0 s. Tốc độ trung bình v = s : t = 10 : 2,0 = 5 m/s.','@img:bang:Lần đo;t (s)|1;2,1|2;2,0|3;1,9']
 ]);
 add(M,7,'Bài 10: Đồ thị quãng đường - thời gian',[
  [2,'Đồ thị quãng đường – thời gian của một vật chuyển động (trục hoành là thời gian t tính bằng giờ, trục tung là quãng đường s tính bằng km, xét phần t ≥ 0; đường thẳng y = 2x biểu diễn s = 2t). Tốc độ của vật là bao nhiêu?','2 km/h','1 km/h','4 km/h','0,5 km/h','@img:dothi:2:0'],
  [3,'Đồ thị quãng đường – thời gian của một người đi bộ (trục hoành là t tính bằng giờ, trục tung là s tính bằng km, xét phần t ≥ 0; đường thẳng y = x biểu diễn s = t). Sau 4 giờ người đó đi được bao nhiêu km? Đồ thị là đường thẳng đi qua gốc tọa độ cho biết điều gì về chuyển động?','Sau 4 giờ đi được 4 km (tốc độ 1 km/h). Đồ thị là đường thẳng qua gốc tọa độ cho biết quãng đường tỉ lệ thuận với thời gian, tức là vật chuyển động với tốc độ không đổi.','@img:dothi:1:0'],
  [4,'Đồ thị s = 2t (trục hoành t tính bằng giờ, trục tung s tính bằng km) mô tả chuyển động của xe A. Xe B chuyển động với tốc độ 1 km/h. Nếu vẽ đồ thị của xe B trên cùng hệ trục thì đồ thị nào dốc hơn? Vì sao? Sau 2 giờ hai xe cách nhau bao xa nếu xuất phát cùng lúc, cùng chỗ, cùng chiều?','Đồ thị của xe A dốc hơn vì tốc độ xe A (2 km/h) lớn hơn tốc độ xe B (1 km/h); độ dốc của đồ thị s – t càng lớn thì tốc độ càng lớn. Sau 2 giờ: xe A đi được 4 km, xe B đi được 2 km, hai xe cách nhau 2 km.','@img:dothi:2:0']
 ]);
 add(M,7,'Bài 12: Sóng âm',[
  [1,'Quan sát hình chiếc loa đang phát âm thanh. Nguồn âm trong trường hợp này là gì?','Màng loa đang dao động','Không khí trong phòng','Tai người nghe','Dây điện của loa','@img:ILLUS:amthanh']
 ]);
 add(M,7,'Bài 13: Độ to và độ cao của âm',[
  [2,'Quan sát hình loa phát âm. Khi tăng âm lượng của loa, đại lượng nào của dao động màng loa tăng lên?','Biên độ dao động','Tần số dao động','Tốc độ truyền âm','Khối lượng màng loa','@img:ILLUS:amthanh']
 ]);
 add(M,7,'Bài 15: Năng lượng ánh sáng. Tia sáng, vùng tối',[
  [1,'Quan sát hình. Vì sao phía sau vật cản lại xuất hiện vùng tối?','Vì ánh sáng truyền theo đường thẳng, bị vật cản chắn lại','Vì vật cản hút ánh sáng','Vì ánh sáng bị uốn cong quanh vật','Vì không khí phía sau vật lạnh hơn','@img:ILLUS:anhsang']
 ]);
 add(M,7,'Bài 16: Sự phản xạ ánh sáng',[
  [1,'Hình vẽ góc tới của tia sáng chiếu đến gương phẳng là 60°. Góc phản xạ bằng bao nhiêu?','60°','30°','90°','120°','@img:goc:60'],
  [2,'Hình vẽ góc tới bằng 30°. Góc hợp bởi tia tới và tia phản xạ trên gương phẳng bằng bao nhiêu?','60°','30°','90°','150°','@img:goc:30']
 ]);
 add(M,7,'Bài 22: Quang hợp ở thực vật',[
  [1,'Quan sát hình cây xanh. Quá trình quang hợp diễn ra chủ yếu ở bộ phận nào của cây?','Lá','Rễ','Hoa','Quả','@img:ILLUS:caytrong']
 ]);
 add(M,7,'Bài 28: Trao đổi khí ở sinh vật',[
  [2,'Quan sát hình hai lá phổi. Ở người, sự trao đổi khí giữa cơ thể và môi trường diễn ra chủ yếu ở đâu?','Các phế nang trong phổi','Khí quản','Mũi','Dạ dày','@img:ILLUS:hohap']
 ]);
 add(M,7,'Bài 31: Trao đổi nước và chất dinh dưỡng ở động vật',[
  [2,'Quan sát hình tim. Ở người và động vật có hệ tuần hoàn, cơ quan nào bơm máu để vận chuyển chất dinh dưỡng đi khắp cơ thể?','Tim','Phổi','Thận','Dạ dày','@img:ILLUS:tuanhoan']
 ]);
 add(M,8,'Bài 9: Base - thang pH',[
  [1,'Trên thang pH từ 0 đến 14, điểm đánh dấu đỏ ứng với giá trị nào và cho biết môi trường gì?','pH = 7, môi trường trung tính','pH = 7, môi trường acid','pH = 14, môi trường base','pH = 0, môi trường trung tính','@img:truc:0:14:7'],
  [2,'Hai điểm đánh dấu trên thang pH ứng với pH = 3 và pH = 11. Dung dịch có pH = 3 có môi trường gì?','Acid','Base','Trung tính','Không xác định được','@img:truc:0:14:3,11']
 ]);
 add(M,8,'Bài 22: Mạch điện đơn giản',[
  [1,'Mạch điện trong hình gồm pin, công tắc đóng và bóng đèn. Bộ phận nào là nguồn điện?','Pin','Bóng đèn','Công tắc','Dây dẫn','@img:ILLUS:dien'],
  [2,'Quan sát mạch điện kín trong hình. Theo quy ước, chiều dòng điện ở mạch ngoài đi như thế nào?','Từ cực dương của pin qua dây dẫn, bóng đèn đến cực âm','Từ cực âm của pin qua bóng đèn đến cực dương','Chỉ chạy trong bóng đèn','Không có chiều xác định','@img:ILLUS:dien']
 ]);
 add(M,8,'Bài 24: Cường độ dòng điện và hiệu điện thế',[
  [3,'Bảng ghi kết quả đo hiệu điện thế U và cường độ dòng điện I qua một bóng đèn (số liệu giả định). Nhận xét mối quan hệ giữa I và U.','Khi U tăng thì I tăng theo: U tăng gấp đôi (3 V lên 6 V) thì I cũng tăng gấp đôi (0,1 A lên 0,2 A). Cường độ dòng điện qua đèn tỉ lệ thuận với hiệu điện thế đặt vào hai đầu đèn.','@img:bang:U (V);I (A)|3;0,1|6;0,2|9;0,3']
 ]);
 add(M,8,'Bài 28: Sự truyền nhiệt',[
  [1,'Quan sát hình Mặt Trời. Nhiệt từ Mặt Trời truyền đến Trái Đất chủ yếu bằng hình thức nào?','Bức xạ nhiệt','Dẫn nhiệt','Đối lưu','Truyền qua không khí bằng dẫn nhiệt','@img:ILLUS:nangluong']
 ]);
 add(M,8,'Bài 32: Dinh dưỡng và tiêu hóa ở người',[
  [1,'Quan sát hình dạ dày. Ở dạ dày, loại chất dinh dưỡng nào bắt đầu được tiêu hóa hóa học nhờ enzyme pepsin?','Protein','Tinh bột','Lipid','Vitamin','@img:ILLUS:tieuhoa'],
  [2,'Quan sát hình đĩa chất dinh dưỡng. Nhóm chất nào cung cấp năng lượng nhiều nhất trên cùng một đơn vị khối lượng?','Lipid (chất béo)','Carbohydrate','Protein','Vitamin','@img:ILLUS:dinhduong']
 ]);
 add(M,8,'Bài 33: Máu và hệ tuần hoàn của cơ thể người',[
  [1,'Quan sát hình tim. Tim người có mấy ngăn?','4 ngăn','2 ngăn','3 ngăn','1 ngăn','@img:ILLUS:tuanhoan'],
  [4,'Quan sát hình tim. Vì sao thành của tâm thất trái dày hơn thành của tâm thất phải?','Tâm thất trái bơm máu vào động mạch chủ để đi khắp cơ thể (vòng tuần hoàn lớn) nên cần lực co bóp mạnh, thành cơ phải dày. Tâm thất phải chỉ bơm máu lên phổi (vòng tuần hoàn nhỏ), quãng đường ngắn nên thành mỏng hơn.','@img:ILLUS:tuanhoan']
 ]);
 add(M,8,'Bài 34: Hệ hô hấp ở người',[
  [2,'Quan sát hình hai lá phổi. Phổi được cấu tạo từ rất nhiều phế nang có tác dụng gì?','Làm tăng diện tích bề mặt trao đổi khí','Giúp lọc bụi trong không khí','Làm ấm không khí','Phát ra âm thanh','@img:ILLUS:hohap']
 ]);
 add(M,8,'Bài 37: Hệ thần kinh và các giác quan ở người',[
  [1,'Quan sát hình bộ não. Não thuộc bộ phận nào của hệ thần kinh?','Bộ phận trung ương','Bộ phận ngoại biên','Dây thần kinh','Hạch thần kinh','@img:ILLUS:thankinh']
 ]);
 add(M,8,'Bài 39: Da và điều hòa thân nhiệt ở người',[
  [2,'Nhiệt kế chỉ 37°C là thân nhiệt bình thường. Khi trời nóng, cơ thể giữ được thân nhiệt ổn định chủ yếu nhờ cơ chế nào của da?','Mạch máu dưới da dãn ra và tiết mồ hôi','Mạch máu dưới da co lại','Cơ dựng lông co làm nổi da gà','Run cơ để sinh nhiệt','@img:nhietke:37']
 ]);
 add(M,8,'Bài 44: Hệ sinh thái',[
  [2,'Trong chuỗi thức ăn cỏ → sâu → chim ở hình, sinh vật tiêu thụ bậc 1 là gì?','Sâu','Cỏ','Chim','Vi sinh vật phân giải','@img:ILLUS:chuoithucan']
 ]);
 add(M,9,'Bài 5: Khúc xạ ánh sáng',[
  [1,'Hình vẽ góc tới 30° của tia sáng truyền từ không khí vào nước. Góc khúc xạ so với góc tới như thế nào?','Nhỏ hơn 30°','Bằng 30°','Lớn hơn 30°','Bằng 60°','@img:goc:30']
 ]);
 add(M,9,'Bài 6: Phản xạ toàn phần',[
  [2,'Tia sáng truyền từ nước ra không khí với góc tới 60° như hình (góc tới hạn của nước – không khí khoảng 48,6°). Hiện tượng gì xảy ra?','Phản xạ toàn phần, không có tia khúc xạ','Khúc xạ với góc khúc xạ nhỏ hơn 60°','Tia sáng truyền thẳng không đổi hướng','Khúc xạ với góc khúc xạ bằng 60°','@img:goc:60']
 ]);
 add(M,9,'Bài 11: Điện trở. Định luật Ohm',[
  [2,'Đồ thị biểu diễn cường độ dòng điện I theo hiệu điện thế U của một điện trở (trục hoành U tính bằng V, trục tung I tính bằng A, xét phần U ≥ 0; đường thẳng y = x). Điện trở có giá trị bao nhiêu?','1 Ω','2 Ω','0,5 Ω','10 Ω','@img:dothi:1:0'],
  [3,'Đồ thị I – U của một dây dẫn (trục hoành U tính bằng V, trục tung I tính bằng A, xét phần U ≥ 0; đường thẳng y = 0,5x). Tính điện trở của dây dẫn và cường độ dòng điện khi U = 4 V.','Từ đồ thị: khi U = 2 V thì I = 1 A nên R = U/I = 2 Ω. Khi U = 4 V thì I = U/R = 4 : 2 = 2 A.','@img:dothi:0.5:0']
 ]);
 add(M,9,'Bài 12: Đoạn mạch nối tiếp, song song',[
  [2,'Hai điện trở có giá trị như bảng được mắc nối tiếp. Điện trở tương đương của đoạn mạch là bao nhiêu?','5 Ω','1,2 Ω','6 Ω','1 Ω','@img:bang:Điện trở;Giá trị|R1;2 Ω|R2;3 Ω']
 ]);
 add(M,9,'Bài 13: Năng lượng của dòng điện và công suất điện',[
  [3,'Bảng ghi công suất của hai thiết bị. Nếu cả hai cùng hoạt động trong 5 giờ thì năng lượng điện tiêu thụ là bao nhiêu kWh?','Tổng công suất P = 20 + 60 = 80 W = 0,08 kW. Năng lượng điện tiêu thụ W = P.t = 0,08 × 5 = 0,4 kWh (400 Wh).','@img:bang:Thiết bị;Công suất|Đèn;20 W|Quạt;60 W']
 ]);
 add(M,9,'Bài 16: Vòng năng lượng trên Trái Đất. Năng lượng hóa thạch',[
  [1,'Quan sát hình Mặt Trời. Nguồn năng lượng gốc của hầu hết các dạng năng lượng trên Trái Đất (gió, nước, sinh khối, hóa thạch) là gì?','Mặt Trời','Lõi Trái Đất','Mặt Trăng','Thủy triều','@img:ILLUS:nangluong']
 ]);
 add(M,9,'Bài 17: Một số dạng năng lượng tái tạo',[
  [2,'Quan sát hình năng lượng mặt trời. Pin mặt trời chuyển hóa năng lượng ánh sáng thành dạng năng lượng nào?','Điện năng','Nhiệt năng','Cơ năng','Hóa năng','@img:ILLUS:nangluong']
 ]);
 add(M,9,'Bài 29: Carbohydrate glucose và saccharose',[
  [1,'Quan sát hình đĩa chất dinh dưỡng. Glucose thuộc nhóm chất dinh dưỡng nào?','Carbohydrate (chất bột đường)','Protein','Lipid','Vitamin','@img:ILLUS:dinhduong']
 ]);
 add(M,9,'Bài 35: Khai thác nhiên liệu hóa thạch. Nguồn carbon. Chu trình carbon và sự ấm lên toàn cầu',[
  [4,'Quan sát hình Trái Đất và môi trường. Việc đốt nhiều nhiên liệu hóa thạch ảnh hưởng như thế nào đến chu trình carbon và sự ấm lên toàn cầu?','Đốt nhiên liệu hóa thạch giải phóng lượng lớn CO2 đã được tích trữ hàng triệu năm vào khí quyển, nhanh hơn khả năng hấp thụ của cây xanh và đại dương, làm chu trình carbon mất cân bằng. CO2 là khí nhà kính, nồng độ tăng làm Trái Đất giữ nhiệt nhiều hơn, gây ấm lên toàn cầu, băng tan, nước biển dâng và thời tiết cực đoan.','@img:ILLUS:moitruong']
 ]);
 add(M,9,'Bài 37: Các quy luật di truyền của Mendel',[
  [3,'Bảng ghi kết quả ở thế hệ F2 trong thí nghiệm của Mendel về màu hoa đậu Hà Lan. Tính tỉ lệ kiểu hình và cho biết tính trạng nào là trội.','Tỉ lệ hoa tím : hoa trắng = 705 : 224 ≈ 3 : 1. Hoa tím là tính trạng trội, hoa trắng là tính trạng lặn.','@img:bang:Kiểu hình;Số cây|Hoa tím;705|Hoa trắng;224'],
  [4,'Dựa vào bảng kết quả F2 (705 hoa tím : 224 hoa trắng), hãy giải thích kết quả này theo quy luật phân li của Mendel.','F1 đều có kiểu gene dị hợp Aa (A quy định hoa tím trội hoàn toàn so với a hoa trắng). Khi F1 giảm phân, hai allele phân li đồng đều cho giao tử A và a với tỉ lệ 1 : 1. Sự tổ hợp ngẫu nhiên của giao tử tạo F2 có tỉ lệ kiểu gene 1 AA : 2 Aa : 1 aa, tức 3 hoa tím : 1 hoa trắng, phù hợp với số liệu 705 : 224.','@img:bang:Kiểu hình;Số cây|Hoa tím;705|Hoa trắng;224']
 ]);
 add(M,9,'Bài 44: Nhiễm sắc thể giới tính và cơ chế xác định giới tính',[
  [1,'Bảng cho biết cặp nhiễm sắc thể giới tính ở người. Giới tính của con được quyết định bởi yếu tố nào?','Tinh trùng mang nhiễm sắc thể X hay Y của bố','Trứng của mẹ mang X hay Y','Số lượng nhiễm sắc thể thường','Tuổi của bố mẹ','@img:bang:Giới tính;NST giới tính|Nữ;XX|Nam;XY']
 ]);
 /* ===================== LỊCH SỬ VÀ ĐỊA LÍ (phần Địa lí) ===================== */
 M='Lịch sử và Địa lí';
 add(M,4,'Địa phương em',[
  [1,'Quan sát la bàn trong hình. Theo quy ước, phía trên của bản đồ là hướng nào?','Bắc','Nam','Đông','Tây','@img:phuonghuong'],
  [2,'Quan sát hình bản đồ. Muốn biết các kí hiệu trên bản đồ địa phương thể hiện đối tượng gì, em cần dựa vào đâu?','Bảng chú giải của bản đồ','Tên bản đồ','Màu nền của bản đồ','Khung bản đồ','@img:ILLUS:bando']
 ]);
 add(M,4,'Trung du và miền núi Bắc Bộ',[
  [1,'Quan sát hình. Địa hình của vùng Trung du và miền núi Bắc Bộ chủ yếu là gì?','Núi cao và đồi','Đồng bằng rộng lớn','Cao nguyên xếp tầng','Bãi cát ven biển','@img:ILLUS:nui'],
  [3,'Quan sát hình núi. Kể tên dãy núi cao, đồ sộ nhất nước ta ở vùng Trung du và miền núi Bắc Bộ và đỉnh núi cao nhất của dãy này.','Dãy Hoàng Liên Sơn, có đỉnh Phan-xi-păng cao hơn 3.100 m, được gọi là "nóc nhà" của Việt Nam (và của Đông Dương).','@img:ILLUS:nui']
 ]);
 add(M,4,'Đồng bằng Bắc Bộ',[
  [2,'Quan sát hình đồng ruộng. Đồng bằng Bắc Bộ là vựa lúa lớn thứ mấy của cả nước?','Thứ hai (sau Đồng bằng Nam Bộ)','Thứ nhất','Thứ ba','Thứ tư','@img:ILLUS:nongnghiep'],
  [2,'Quan sát hình di tích. Di tích nào ở Hà Nội được coi là trường đại học đầu tiên của nước ta?','Văn Miếu – Quốc Tử Giám','Chùa Một Cột','Đền Ngọc Sơn','Hoàng thành Thăng Long','@img:ILLUS:den']
 ]);
 add(M,4,'Duyên hải miền Trung',[
  [1,'Quan sát hình biển. Người dân Duyên hải miền Trung phát triển những hoạt động kinh tế nào nhờ biển?','Đánh bắt hải sản, làm muối, du lịch biển','Trồng cà phê, cao su','Khai thác than đá','Trồng lúa trên ruộng bậc thang','@img:ILLUS:bien']
 ]);
 add(M,4,'Tây Nguyên',[
  [1,'Quan sát hình. Dạng địa hình đặc trưng của Tây Nguyên là gì?','Các cao nguyên xếp tầng','Đồng bằng ven biển','Núi đá vôi','Đồi bát úp','@img:ILLUS:nui'],
  [3,'Biểu đồ lượng mưa các tháng (mm, số liệu giả định) của một địa điểm ở Tây Nguyên. Hãy cho biết địa điểm này có mấy mùa và thời gian của mỗi mùa.','Có hai mùa rõ rệt: mùa mưa (khoảng tháng 5 đến tháng 10, lượng mưa lớn như tháng 7 là 250 mm) và mùa khô (khoảng tháng 11 đến tháng 4, mưa rất ít như tháng 1 chỉ 5 mm).','@img:bieudo:cot:Th1=5,Th4=90,Th7=250,Th10=120']
 ]);
 add(M,4,'Nam Bộ',[
  [2,'Quan sát hình đồng ruộng. Đồng bằng Nam Bộ dẫn đầu cả nước về sản phẩm nông nghiệp nào?','Lúa gạo và trái cây','Chè và cà phê','Cao su và hồ tiêu','Rau vụ đông','@img:ILLUS:nongnghiep']
 ]);
 add(M,5,'Đất nước và con người Việt Nam',[
  [1,'Quan sát hình bản đồ. Lãnh thổ Việt Nam gồm những bộ phận nào?','Vùng đất, vùng biển và vùng trời','Chỉ có vùng đất liền','Vùng đất và vùng trời','Chỉ có vùng biển','@img:ILLUS:bando'],
  [2,'Biểu đồ dân số Việt Nam (triệu người, làm tròn theo các cuộc tổng điều tra dân số). Nhận xét sự thay đổi dân số nước ta từ năm 1979 đến năm 2019.','Tăng liên tục','Giảm dần','Không thay đổi','Tăng rồi giảm','@img:bieudo:cot:1979=53,1989=64,1999=76,2009=86,2019=96'],
  [3,'Quan sát hình biển đảo. Nêu vai trò của biển đối với nước ta.','Biển cung cấp hải sản, muối, dầu khí; là đường giao thông quan trọng; có nhiều bãi biển đẹp để phát triển du lịch; biển còn điều hòa khí hậu và là không gian sinh tồn của người dân ven biển.','@img:ILLUS:bien']
 ]);
 add(M,5,'Các nước láng giềng và thế giới',[
  [1,'Quan sát hình bản đồ. Nước láng giềng nào giáp với phần đất liền phía bắc của Việt Nam?','Trung Quốc','Lào','Cam-pu-chia','Thái Lan','@img:ILLUS:bando'],
  [2,'Bảng cho diện tích (nghìn km², làm tròn) của Việt Nam và hai nước láng giềng. Nước nào có diện tích nhỏ nhất?','Cam-pu-chia','Lào','Việt Nam','Ba nước bằng nhau','@img:bang:Nước;Nghìn km²|Lào;237|Cam-pu-chia;181|Việt Nam;331']
 ]);
 add(M,6,'Bài 2 (Địa lí): Bản đồ',[
  [1,'Quan sát hình bản đồ có kí hiệu la bàn ở góc. Kí hiệu này dùng để xác định gì trên bản đồ?','Phương hướng','Tỉ lệ bản đồ','Độ cao địa hình','Loại đối tượng địa lí','@img:ILLUS:bando']
 ]);
 add(M,6,'Bài 3 (Địa lí): Tỉ lệ bản đồ',[
  [2,'Trên bản đồ tỉ lệ 1 : 100.000, đoạn thẳng màu xanh đo được như hình. Khoảng cách thực tế tương ứng là bao nhiêu?','5 km','50 km','0,5 km','500 km','@img:thuoc:5']
 ]);
 add(M,6,'Bài 9 (Địa lí): Xác định phương hướng ngoài thực địa',[
  [1,'Quan sát la bàn. Khi đứng quay mặt về hướng Bắc, tay phải của em chỉ hướng nào?','Đông','Tây','Nam','Bắc','@img:phuonghuong'],
  [3,'Dựa vào la bàn trong hình, hãy nêu cách xác định phương hướng ngoài thực địa bằng Mặt Trời vào buổi sáng khi không có la bàn.','Buổi sáng Mặt Trời mọc ở hướng Đông. Đứng dang tay, tay phải chỉ về phía Mặt Trời mọc (Đông) thì trước mặt là Bắc, sau lưng là Nam, tay trái là Tây.','@img:phuonghuong']
 ]);
 add(M,6,'Bài 13 (Địa lí): Các dạng địa hình chính trên Trái Đất',[
  [1,'Quan sát hình. Dạng địa hình nhô cao rõ rệt trên mặt đất, thường có độ cao trên 500 m so với mực nước biển, có đỉnh và sườn là gì?','Núi','Đồng bằng','Đồi','Cao nguyên','@img:ILLUS:nui']
 ]);
 add(M,6,'Bài 16 (Địa lí): Nhiệt độ không khí',[
  [1,'Nhiệt kế trong hình đo nhiệt độ không khí. Giá trị đọc được là bao nhiêu?','25°C','20°C','30°C','35°C','@img:nhietke:25'],
  [3,'Bảng ghi nhiệt độ không khí đo được ở ba thời điểm trong ngày tại một trạm (số liệu giả định). Tính nhiệt độ trung bình ngày.','Nhiệt độ trung bình ngày = (20 + 28 + 24) : 3 = 24°C.','@img:bang:Giờ đo;°C|5 giờ;20|13 giờ;28|21 giờ;24']
 ]);
 add(M,6,'Bài 17 (Địa lí): Thời tiết và khí hậu',[
  [1,'Quan sát hình nắng, mây, mưa. Trạng thái của khí quyển tại một nơi trong một thời gian ngắn (ngày, giờ) được gọi là gì?','Thời tiết','Khí hậu','Mùa','Gió','@img:ILLUS:thoitiet']
 ]);
 add(M,6,'Bài 18 (Địa lí): Thực hành: Phân tích biểu đồ nhiệt độ, lượng mưa',[
  [2,'Biểu đồ nhiệt độ các tháng (°C, số liệu giả định) của một địa điểm. Tháng nào có nhiệt độ cao nhất?','Tháng 7','Tháng 1','Tháng 4','Tháng 10','@img:bieudo:cot:Th1=16,Th4=24,Th7=29,Th10=25'],
  [4,'Biểu đồ nhiệt độ các tháng (°C, số liệu giả định) của một địa điểm. Tính biên độ nhiệt năm và cho biết địa điểm này thuộc bán cầu nào, có đặc điểm khí hậu gì.','Biên độ nhiệt năm = 29 – 16 = 13°C. Nhiệt độ cao nhất vào tháng 7 nên địa điểm thuộc bán cầu Bắc. Khí hậu có mùa hè nóng, mùa đông mát/lạnh; nhiệt độ các tháng đều trên 15°C nên thuộc đới nóng nhưng có mùa đông lạnh hơn rõ rệt.','@img:bieudo:cot:Th1=16,Th4=24,Th7=29,Th10=25']
 ]);
 add(M,6,'Bài 19 (Địa lí): Thủy quyển và vòng tuần hoàn lớn của nước',[
  [2,'Quan sát hình vòng tuần hoàn của nước. Trong vòng tuần hoàn lớn, hơi nước bốc lên cao, gặp lạnh ngưng tụ tạo thành gì?','Mây','Sông','Băng','Gió','@img:ILLUS:vongnuoc']
 ]);
 add(M,6,'Bài 21 (Địa lí): Biển và đại dương',[
  [1,'Quan sát hình biển. Độ muối trung bình của nước biển và đại dương là bao nhiêu?','35‰','10‰','50‰','3,5‰','@img:ILLUS:bien']
 ]);
 add(M,6,'Bài 6 (Địa lí): Trái Đất trong hệ Mặt Trời',[
  [1,'Quan sát hình Mặt Trời, Trái Đất, Mặt Trăng. Trái Đất ở vị trí thứ mấy theo thứ tự xa dần Mặt Trời?','Thứ ba','Thứ nhất','Thứ hai','Thứ năm','@img:ILLUS:vutru']
 ]);
 add(M,6,'Bài 27 (Địa lí): Dân số và sự phân bố dân cư trên thế giới',[
  [2,'Biểu đồ dân số thế giới (tỉ người) tại một số mốc năm. Dân số thế giới tăng nhanh nhất trong giai đoạn nào?','1960 – 2011 (tăng 4 tỉ người trong 51 năm)','1804 – 1927 (tăng 1 tỉ người trong 123 năm)','1927 – 1960','Dân số tăng đều ở mọi giai đoạn','@img:bieudo:cot:1804=1,1927=2,1960=3,1999=6,2011=7']
 ]);
 add(M,7,'Bài 5 (Địa lí): Vị trí địa lí, đặc điểm tự nhiên Châu Á',[
  [1,'Quan sát hình núi. Dãy núi cao và đồ sộ nhất châu Á (cũng là của thế giới) là dãy nào?','Hi-ma-lay-a','An-pơ','An-đét','U-ran','@img:ILLUS:nui']
 ]);
 add(M,7,'Bài 6 (Địa lí): Đặc điểm dân cư, xã hội Châu Á',[
  [2,'Bảng cho dân số một số châu lục năm 2020 (tỉ người, làm tròn). Châu lục nào đông dân nhất thế giới?','Châu Á','Châu Phi','Châu Âu','Châu Mỹ','@img:bang:Châu lục;Tỉ người|Á;4,6|Phi;1,3|Âu;0,7|Mỹ;1,0']
 ]);
 add(M,7,'Bài 9 (Địa lí): Vị trí địa lí, đặc điểm tự nhiên châu Phi',[
  [3,'Biểu đồ lượng mưa các tháng (mm, số liệu giả định) của một trạm trong hoang mạc Xa-ha-ra. Nhận xét và giải thích.','Lượng mưa rất thấp, các tháng chỉ 0 – 3 mm, cả năm hầu như không có mưa. Nguyên nhân: Xa-ha-ra nằm ở khu vực chí tuyến có áp cao thống trị quanh năm, lãnh thổ rộng, ít chịu ảnh hưởng của biển nên khí hậu khô hạn.','@img:bieudo:cot:Th1=2,Th4=1,Th7=0,Th10=3']
 ]);
 add(M,7,'Bài 18 (Địa lí): Châu Đại Dương',[
  [1,'Quan sát hình biển đảo. Châu Đại Dương gồm lục địa Ô-xtrây-li-a và các đảo, quần đảo nằm trong đại dương nào?','Thái Bình Dương','Đại Tây Dương','Ấn Độ Dương','Bắc Băng Dương','@img:ILLUS:bien']
 ]);
 add(M,7,'Bài 19 (Địa lí): Châu Nam Cực',[
  [2,'Bảng cho nhiệt độ trung bình tháng 1 và tháng 7 tại một trạm ven biển châu Nam Cực (°C, số liệu giả định). Vì sao tháng 1 ấm hơn tháng 7?','Vì tháng 1 là mùa hạ ở bán cầu Nam','Vì tháng 1 là mùa hạ ở bán cầu Bắc','Vì tháng 7 Trái Đất xa Mặt Trời hơn','Vì tháng 1 băng tan nhiều hơn','@img:bang:Tháng;°C|Tháng 1;-5|Tháng 7;-25']
 ]);
 add(M,8,'Bài 1 (Địa lí): Vị trí địa lí và phạm vi lãnh thổ Việt Nam',[
  [2,'Quan sát hình biển đảo. Đường bờ biển phần đất liền nước ta dài khoảng bao nhiêu?','3.260 km','1.650 km','5.000 km','2.000 km','@img:ILLUS:bien']
 ]);
 add(M,8,'Bài 2 (Địa lí): Địa hình Việt Nam',[
  [1,'Quan sát hình. Địa hình đồi núi chiếm khoảng bao nhiêu phần diện tích đất liền nước ta?','3/4','1/4','1/2','1/3','@img:ILLUS:nui']
 ]);
 add(M,8,'Bài 4 (Địa lí): Khí hậu Việt Nam',[
  [2,'Biểu đồ nhiệt độ trung bình một số tháng ở Hà Nội (°C, số liệu làm tròn). Tháng lạnh nhất là tháng nào và điều đó thể hiện đặc điểm gì của khí hậu miền Bắc?','Tháng 1; miền Bắc có mùa đông lạnh','Tháng 7; miền Bắc nóng quanh năm','Tháng 4; miền Bắc có mùa xuân lạnh','Tháng 10; miền Bắc có mùa thu lạnh','@img:bieudo:cot:Th1=17,Th4=24,Th7=29,Th10=25']
 ]);
 add(M,8,'Bài 5 (Địa lí): Thực hành: Đọc biểu đồ khí hậu',[
  [3,'Biểu đồ lượng mưa một số tháng (mm, số liệu giả định) của một trạm khí tượng ở nước ta. Hãy xác định mùa mưa của địa điểm này và nhận xét sự phân bố mưa.','Mưa tập trung vào các tháng mùa hạ (tháng 7 tới 290 mm), các tháng mùa đông mưa ít (tháng 1 chỉ 20 mm). Lượng mưa phân bố không đều trong năm, có mùa mưa và mùa khô rõ rệt.','@img:bieudo:cot:Th1=20,Th4=90,Th7=290,Th10=130']
 ]);
 add(M,8,'Bài 11 (Địa lí): Phạm vi biển Đông',[
  [1,'Quan sát hình biển. Biển Đông là một biển thuộc đại dương nào?','Thái Bình Dương','Ấn Độ Dương','Đại Tây Dương','Bắc Băng Dương','@img:ILLUS:bien']
 ]);
 add(M,9,'Bài 1 (Địa lí): Dân tộc và dân số',[
  [3,'Biểu đồ dân số Việt Nam qua các cuộc tổng điều tra (triệu người, làm tròn). Tính số dân tăng thêm trong giai đoạn 1999 – 2019 và nhận xét.','Giai đoạn 1999 – 2019 dân số tăng thêm 96 – 76 = 20 triệu người, trung bình khoảng 1 triệu người mỗi năm. Dân số nước ta vẫn tăng nhưng tốc độ tăng đã chậm hơn so với giai đoạn 1979 – 1999.','@img:bieudo:cot:1979=53,1989=64,1999=76,2009=86,2019=96']
 ]);
 add(M,9,'Bài 5 (Địa lí): Nông nghiệp',[
  [1,'Quan sát hình đồng ruộng. Cây lương thực chính của nước ta là cây gì?','Lúa','Ngô','Khoai lang','Sắn','@img:ILLUS:nongnghiep']
 ]);
 add(M,9,'Bài 12 (Địa lí): Vùng Trung du và miền núi phía Bắc',[
  [1,'Quan sát hình núi. Địa hình núi cao, sông ngòi có độ dốc lớn tạo cho vùng Trung du và miền núi phía Bắc thế mạnh phát triển ngành nào?','Thủy điện','Nuôi trồng thủy sản nước mặn','Trồng lúa nước quy mô lớn','Du lịch biển','@img:ILLUS:nui']
 ]);
 add(M,9,'Bài 13 (Địa lí): Vùng Đồng bằng sông Hồng',[
  [3,'Bảng cho diện tích và dân số vùng Đồng bằng sông Hồng (số liệu làm tròn). Tính mật độ dân số của vùng và nhận xét.','Mật độ dân số ≈ 23.000.000 : 21.000 ≈ 1.095 người/km², tức trên 1.000 người/km². Đây là vùng có mật độ dân số cao nhất cả nước, cao hơn nhiều lần mức trung bình của cả nước.','@img:bang:Chỉ tiêu;Giá trị|Diện tích;21 nghìn km²|Dân số;23 triệu']
 ]);
 add(M,9,'Bài 21 (Địa lí): Phát triển tổng hợp kinh tế và bảo vệ tài nguyên, môi trường biển đảo',[
  [2,'Quan sát hình biển đảo. Ngành nào sau đây KHÔNG thuộc các ngành kinh tế biển của nước ta?','Trồng cây công nghiệp lâu năm','Khai thác và nuôi trồng hải sản','Du lịch biển – đảo','Giao thông vận tải biển','@img:ILLUS:bien']
 ]);
 /* ===================== TIẾNG ANH ===================== */
 M='Tiếng Anh';
 add(M,1,'Greetings & Colours',[
  [1,'Look at the apples. What colour are they?','They are red.','They are blue.','They are yellow.','They are green.','@img:dem:tao:2'],
  [1,'Look at the leaves. What colour are they?','They are green.','They are red.','They are orange.','They are pink.','@img:dem:la:3'],
  [1,'Look at the picture. Which word do you say when you meet your friend?','Hello','Goodbye','Thank you','Sorry','@img:ILLUS:tienganh']
 ]);
 add(M,1,'Numbers & Animals',[
  [1,'How many fish are there?','There are five fish.','There are four fish.','There are six fish.','There are three fish.','@img:dem:ca:5'],
  [1,'How many birds are there?','There are three birds.','There are two birds.','There are four birds.','There are five birds.','@img:dem:chim:3'],
  [2,'Count the butterflies and answer: How many butterflies are there?','There are four butterflies.','@img:dem:buom:4']
 ]);
 add(M,2,'School & Family',[
  [1,'How many books are there?','There are four books.','There are three books.','There are five books.','There are six books.','@img:dem:sach:4'],
  [1,'How many pencils are there?','There are five pencils.','There are four pencils.','There are six pencils.','There are seven pencils.','@img:dem:but:5'],
  [1,'Look at the picture. What is it?','It is a school.','It is a hospital.','It is a zoo.','It is a park.','@img:ILLUS:truonghoc']
 ]);
 add(M,2,'Food & Toys',[
  [1,'How many sweets are there?','There are eight sweets.','There are seven sweets.','There are nine sweets.','There are six sweets.','@img:dem:keo:8'],
  [1,'How many balls are there?','There are nine balls.','There are eight balls.','There are ten balls.','There are seven balls.','@img:dem:bong:9'],
  [1,'How many eggs are there?','There are six eggs.','There are five eggs.','There are seven eggs.','There are eight eggs.','@img:dem:trung:6'],
  [2,'Answer the question: How many bananas are there?','There are four bananas.','@img:dem:chuoi:4']
 ]);
 add(M,2,'Places & Actions',[
  [1,'How many cars are there?','There are three cars.','There are two cars.','There are four cars.','There are five cars.','@img:dem:xe:3']
 ]);
 add(M,3,'Hello – Friends – Body',[
  [1,'Look at the boy. Which part of the body do we use to see?','eyes','ears','nose','hands','@img:ILLUS:cothe'],
  [2,'Look at the picture. Which is a good answer to "Hello! How are you?"','I am fine, thank you.','I am seven years old.','It is a pen.','Goodbye.','@img:ILLUS:tienganh']
 ]);
 add(M,3,'School – Classroom',[
  [1,'Look at the picture. How many books are there?','There are seven books.','There are six books.','There are eight books.','There are five books.','@img:dem:sach:7'],
  [2,'Count the pencils and answer: How many pencils are there?','There are six pencils.','@img:dem:but:6']
 ]);
 add(M,3,'Family – House – Pets',[
  [2,'These are my pet fish. Answer the question: How many fish do I have?','You have five fish.','You have four fish.','You have six fish.','You have three fish.','@img:dem:ca:5']
 ]);
 add(M,4,'Friends – Time – Daily routines',[
  [1,'What time is it?','It\'s seven o\'clock.','It\'s six o\'clock.','It\'s eight o\'clock.','It\'s half past seven.','@img:dongho:7:0'],
  [1,'Look at the clock. What time is it?','It\'s half past six.','It\'s half past seven.','It\'s six o\'clock.','It\'s a quarter past six.','@img:dongho:6:30'],
  [2,'Look at the clock and choose the correct answer. What time is it?','It\'s a quarter past eight.','It\'s a quarter to eight.','It\'s half past eight.','It\'s eight o\'clock.','@img:dongho:8:15'],
  [2,'Read the clock. What time is it?','It\'s a quarter to ten.','It\'s a quarter to nine.','It\'s a quarter past nine.','It\'s nine o\'clock.','@img:dongho:9:45'],
  [3,'Nam gets up at this time every day. Answer the question: What time does Nam get up?','He gets up at seven o\'clock.','@img:dongho:7:0']
 ]);
 add(M,4,'Birthday – Abilities – Subjects',[
  [2,'The Maths lesson starts at this time. What time does it start?','It starts at eight o\'clock.','It starts at nine o\'clock.','It starts at half past eight.','It starts at a quarter past eight.','@img:dongho:8:0']
 ]);
 add(M,4,'Home – Jobs – Weekend',[
  [1,'Look at the family. "What does your father do?" is a question about his ___.','job','age','name','house','@img:ILLUS:giadinh']
 ]);
 add(M,5,'Holidays – Health – Weather',[
  [1,'Look at the thermometer. What\'s the weather like today?','It\'s hot.','It\'s cold.','It\'s snowy.','It\'s cool.','@img:nhietke:35'],
  [1,'Look at the thermometer. It shows the temperature today. What\'s the weather like?','It\'s cold.','It\'s hot.','It\'s warm.','It\'s sunny and hot.','@img:nhietke:5'],
  [2,'Look at the cloud and the rain in the picture. What\'s the weather like?','It\'s rainy.','It\'s snowy.','It\'s windy.','It\'s foggy.','@img:ILLUS:thoitiet'],
  [3,'Look at the thermometer and answer: What\'s the temperature today?','It\'s thirty-five degrees Celsius.','@img:nhietke:35']
 ]);
 add(M,5,'Transport – Places',[
  [2,'Look at the picture. Complete the sentence: "There ___ three cars in the picture."','are','is','am','be','@img:dem:xe:3'],
  [1,'Look at the picture. Where do you study every day?','I study at school.','I study at the zoo.','I study at the cinema.','I study at the supermarket.','@img:ILLUS:truonghoc']
 ]);
 add(M,5,'About me – Home – Friends',[
  [2,'Look at the picture. Complete the sentence: "Look! There ___ three birds."','are','is','was','has','@img:dem:chim:3']
 ]);
 add(M,5,'Future job – School activities',[
  [2,'Our lessons start at this time. What time do they start?','They start at eight o\'clock.','They start at nine o\'clock.','They start at half past eight.','They start at a quarter past eight.','@img:dongho:8:0']
 ]);
})();
