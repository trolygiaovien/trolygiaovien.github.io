/* NGÂN HÀNG TIN HỌC – CÔNG NGHỆ – GDCD (LỚP 3–9) — bổ sung đủ chuẩn. Câu hỏi nguyên bản, bám SGK Kết nối tri thức. */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Tin học';
 /* ===== TIN HỌC 3 ===== */
 add(M,3,'Máy tính và em',[
  [1,'Máy tính để bàn thường gồm những bộ phận cơ bản nào?','Thân máy, màn hình, bàn phím và chuột','Chỉ có màn hình và loa','Chỉ có bàn phím và chuột','Máy in, loa và tai nghe'],
  [1,'Bộ phận nào của máy tính được coi là "bộ não", nơi xử lí thông tin?','Thân máy (bộ xử lí)','Màn hình','Bàn phím','Chuột'],
  [1,'Hai phím có gai trên hàng phím cơ sở là hai phím nào?','F và J','A và L','G và H','D và K'],
  [2,'Khi gõ bàn phím đúng cách, hai ngón tay cái được đặt ở phím nào?','Phím cách','Phím Enter','Phím Shift','Phím Tab'],
  [2,'Loại máy tính nào có thể gấp gọn, mang theo và có bàn phím gắn liền với màn hình?','Máy tính xách tay','Máy tính để bàn','Máy tính bảng','Máy in'],
  [2,'Khi dùng máy tính, khoảng cách từ mắt đến màn hình nên khoảng bao nhiêu để bảo vệ mắt?','Khoảng 50 đến 80 cm','Càng gần càng tốt','Khoảng 10 cm','Hơn 3 m'],
  [3,'Kể tên ba loại máy tính thông dụng mà em biết và nêu một điểm khác nhau giữa chúng.','Ba loại máy tính thông dụng: máy tính để bàn, máy tính xách tay, máy tính bảng. Khác nhau: máy tính để bàn có các bộ phận tách rời, đặt cố định; máy tính xách tay gọn nhẹ, bàn phím gắn liền với màn hình; máy tính bảng dùng màn hình cảm ứng, không có bàn phím vật lí.'],
  [3,'Em hãy mô tả cách đặt các ngón tay lên hàng phím cơ sở khi bắt đầu gõ bàn phím.','Đặt ngón trỏ tay trái lên phím F, ngón trỏ tay phải lên phím J (hai phím có gai); các ngón còn lại lần lượt đặt lên các phím bên cạnh: tay trái D, S, A; tay phải K, L, dấu chấm phẩy; hai ngón cái đặt lên phím cách.'],
  [4,'Vì sao khi ngồi học với máy tính, em cần giữ lưng thẳng, mắt cách màn hình đủ xa và không dùng máy quá lâu? Hãy giải thích.','Ngồi cong lưng lâu sẽ gây đau lưng, lệch cột sống; mắt nhìn quá gần và quá lâu vào màn hình làm mắt mỏi, dễ bị cận thị. Dùng máy quá lâu còn ảnh hưởng đến sức khỏe và thời gian học tập, vui chơi khác. Vì vậy, cần ngồi đúng tư thế, giữ khoảng cách hợp lí và nghỉ ngơi sau mỗi khoảng thời gian sử dụng để bảo vệ sức khỏe.']
 ]);
 add(M,3,'Thông tin và xử lí thông tin',[
  [1,'Tiếng chuông báo hiệu giờ ra chơi là thông tin ở dạng nào?','Âm thanh','Chữ viết','Hình ảnh','Số'],
  [1,'Tấm biển có vẽ hình người đi bộ ở lối sang đường cho ta thông tin ở dạng nào?','Hình ảnh','Âm thanh','Chữ viết','Mùi vị'],
  [1,'Khi em đọc thời khóa biểu để chuẩn bị sách vở, em đang tiếp nhận thông tin ở dạng nào?','Chữ viết','Âm thanh','Hình ảnh','Chuyển động'],
  [2,'Bộ phận nào của máy tính giúp đưa thông tin vào máy?','Bàn phím và chuột','Màn hình và loa','Máy in','Thân máy'],
  [2,'Bộ phận nào của máy tính giúp đưa thông tin ra cho người dùng?','Màn hình và loa','Bàn phím','Chuột','Dây nguồn'],
  [2,'Thấy trời có nhiều mây đen, em quyết định mang áo mưa đi học. Việc "quyết định mang áo mưa" là kết quả của bước nào?','Xử lí thông tin để ra quyết định','Tiếp nhận thông tin','Lưu trữ thông tin','Truyền thông tin'],
  [3,'Nêu ba bước xử lí thông tin của con người và lấy một ví dụ minh họa.','Ba bước: tiếp nhận thông tin, xử lí thông tin, đưa ra kết quả (quyết định hoặc hành động). Ví dụ: nghe tiếng trống báo vào lớp (tiếp nhận), hiểu rằng đã đến giờ học (xử lí), nhanh chóng vào lớp ngồi đúng chỗ (hành động).'],
  [3,'Máy tính xử lí thông tin như thế nào? Hãy nêu vai trò của bàn phím, thân máy và màn hình trong quá trình đó.','Máy tính nhận thông tin vào qua bàn phím, chuột; thân máy (bộ xử lí) xử lí thông tin đó; kết quả được đưa ra qua màn hình, loa hoặc máy in. Bàn phím đưa thông tin vào, thân máy xử lí, màn hình hiển thị kết quả.'],
  [4,'Vì sao cùng một thông tin (ví dụ đèn giao thông chuyển màu đỏ) nhưng mỗi người lại có thể đưa ra quyết định khác nhau? Theo em, quyết định đúng phải dựa vào điều gì?','Vì bước xử lí thông tin ở mỗi người khác nhau: người hiểu đúng ý nghĩa của đèn đỏ sẽ dừng lại, người không chú ý hoặc hiểu sai có thể đi tiếp gây nguy hiểm. Quyết định đúng phải dựa trên việc tiếp nhận đầy đủ thông tin, hiểu đúng ý nghĩa của thông tin và tuân theo quy tắc, luật lệ; như vậy thông tin mới giúp ta hành động an toàn, hợp lí.']
 ]);
 add(M,3,'Đạo đức và an toàn trên mạng',[
  [1,'Thông tin nào sau đây là thông tin cá nhân cần được bảo vệ?','Số điện thoại và địa chỉ nhà của em','Tên trường học được in trên cổng trường','Tên một bài hát em thích','Màu sắc em yêu thích'],
  [1,'Em lưu ảnh gia đình vào máy tính. Đây là việc gì đối với thông tin?','Lưu trữ thông tin','Xóa thông tin','Mua bán thông tin','Phát tán thông tin'],
  [2,'Việc nào sau đây giúp bảo vệ thông tin của em và gia đình trên máy tính?','Đặt mật khẩu cho máy tính và không cho người lạ biết','Ghi mật khẩu lên bàn học cho dễ nhớ','Nói mật khẩu cho bất kì ai hỏi','Để máy tính luôn mở ở nơi công cộng'],
  [2,'Khi dùng Internet, em thấy một trò chơi yêu cầu nhập tên, tuổi, địa chỉ nhà để nhận quà. Em nên làm gì?','Không nhập và hỏi ý kiến bố mẹ hoặc thầy cô','Nhập ngay để nhận quà','Nhập thông tin của bạn cùng lớp thay cho mình','Chia sẻ cho các bạn cùng nhập'],
  [2,'Khi trao đổi thông tin với người khác qua máy tính, điện thoại, em cần lưu ý điều gì?','Dùng lời nói lễ phép, không gửi thông tin xấu hay làm phiền người khác','Gửi càng nhiều tin càng tốt','Chỉ nhắn tin vào ban đêm','Dùng tên của người khác để nhắn'],
  [1,'Em được phép sử dụng máy tính, Internet khi nào là phù hợp nhất?','Khi được người lớn cho phép và theo thời gian quy định','Bất cứ lúc nào em muốn','Chỉ khi bố mẹ không có nhà','Suốt ngày không nghỉ'],
  [3,'Nêu ba thông tin của gia đình em không nên chia sẻ với người lạ trên mạng và giải thích ngắn gọn vì sao.','Ba thông tin không nên chia sẻ: địa chỉ nhà, số điện thoại của bố mẹ, hình ảnh và lịch sinh hoạt của gia đình (giờ đi làm, đi học). Vì người xấu có thể lợi dụng những thông tin này để làm phiền, lừa đảo hoặc gây nguy hiểm cho gia đình em.'],
  [3,'Em được bố mẹ cho dùng máy tính để học. Hãy nêu ba việc em nên làm để sử dụng máy tính đúng mục đích và an toàn.','Ba việc nên làm: chỉ mở các phần mềm, trang web phục vụ học tập đã được bố mẹ, thầy cô hướng dẫn; không tự ý tải hay cài phần mềm lạ; sử dụng trong thời gian cho phép, gặp điều lạ hoặc đáng sợ thì báo ngay cho người lớn.'],
  [4,'Bạn An cho rằng "chia sẻ ảnh của bạn khác lên mạng là chuyện bình thường vì ai cũng làm thế". Em có đồng ý không? Hãy giải thích.','Không đồng ý. Hình ảnh là thông tin cá nhân của mỗi người; đăng ảnh người khác mà chưa được họ đồng ý là thiếu tôn trọng, có thể làm bạn buồn, bị trêu chọc hoặc bị người xấu lợi dụng. Việc nhiều người làm không có nghĩa là việc đó đúng. Trước khi chia sẻ ảnh hay thông tin của ai, em cần hỏi ý kiến người đó và người lớn.']
 ]);
 /* ===== TIN HỌC 4 ===== */
 add(M,4,'Phần cứng và phần mềm',[
  [1,'Phần cứng máy tính là gì?','Các bộ phận, thiết bị của máy tính mà ta có thể nhìn thấy và chạm vào','Các chương trình chạy trong máy tính','Các tệp ảnh và bài hát','Các trang web trên Internet'],
  [1,'Trò chơi, phần mềm vẽ tranh, phần mềm luyện gõ bàn phím thuộc loại nào?','Phần mềm','Phần cứng','Thiết bị vào','Thiết bị ra'],
  [2,'Máy in thuộc nhóm thiết bị nào của máy tính?','Thiết bị ra (phần cứng)','Thiết bị vào','Phần mềm','Bộ nhớ'],
  [2,'Vì sao máy tính không thể hoạt động nếu chỉ có phần cứng mà không có phần mềm?','Vì phần mềm là các chương trình điều khiển phần cứng làm việc','Vì phần cứng quá nặng','Vì phần mềm làm máy đẹp hơn','Vì phần cứng chỉ dùng để trang trí'],
  [2,'Thiết bị nào vừa dùng để đưa thông tin vào máy tính thông qua việc chạm tay?','Màn hình cảm ứng','Loa','Máy in','Dây mạng'],
  [1,'Phần mềm nào sau đây là phần mềm trình chiếu?','PowerPoint','Paint','Scratch','Word'],
  [3,'Phân biệt phần cứng và phần mềm, mỗi loại cho hai ví dụ.','Phần cứng là các thiết bị vật lí của máy tính có thể nhìn thấy, chạm vào, ví dụ: bàn phím, màn hình. Phần mềm là các chương trình được cài trong máy tính để thực hiện công việc, ví dụ: phần mềm soạn thảo văn bản, phần mềm luyện gõ bàn phím.'],
  [3,'Em muốn gõ một bài thơ và in ra giấy. Hãy kể tên các phần cứng và phần mềm em cần sử dụng.','Phần cứng: bàn phím để gõ, chuột để điều khiển, màn hình để xem, thân máy để xử lí, máy in để in ra giấy. Phần mềm: hệ điều hành để máy hoạt động và phần mềm soạn thảo văn bản để gõ, chỉnh sửa, in bài thơ.'],
  [4,'Vì sao có thể nói phần cứng và phần mềm "không thể tách rời" trong một chiếc máy tính? Lấy ví dụ minh họa.','Phần cứng là cơ thể của máy tính nhưng nếu không có phần mềm thì nó không biết phải làm gì; phần mềm chứa các lệnh điều khiển nhưng cần phần cứng để chạy và hiển thị kết quả. Ví dụ: muốn vẽ tranh, cần phần mềm vẽ để tạo hình ảnh, nhưng phải có chuột để vẽ, màn hình để hiển thị và thân máy để xử lí. Thiếu một trong hai, máy tính không thể hoàn thành công việc.']
 ]);
 add(M,4,'Soạn thảo văn bản và trình chiếu',[
  [1,'Trong phần mềm soạn thảo văn bản, phím nào dùng để xóa kí tự ở bên trái con trỏ soạn thảo?','Backspace','Enter','Shift','Caps Lock'],
  [1,'Phím Enter trong soạn thảo văn bản dùng để làm gì?','Xuống dòng, kết thúc một đoạn văn bản','Xóa chữ','Viết chữ hoa','Lưu văn bản'],
  [2,'Muốn chữ in nghiêng, em dùng tổ hợp phím nào?','Ctrl + I','Ctrl + B','Ctrl + U','Ctrl + P'],
  [2,'Khi muốn chọn toàn bộ văn bản để định dạng, em dùng tổ hợp phím nào?','Ctrl + A','Ctrl + Z','Ctrl + X','Ctrl + N'],
  [2,'Trong bài trình chiếu, mỗi "trang" nội dung được gọi là gì?','Trang chiếu','Tệp','Thư mục','Dòng'],
  [1,'Để trình chiếu bài trình chiếu từ trang đầu tiên, em nhấn phím nào?','F5','F1','Esc','Delete'],
  [2,'Khi soạn thảo một đoạn văn, em nên nhấn Enter khi nào?','Khi kết thúc một đoạn văn','Khi hết mỗi dòng trên màn hình','Sau mỗi từ','Sau mỗi dấu phẩy'],
  [3,'Nêu các bước sao chép một đoạn văn bản từ vị trí này sang vị trí khác trong cùng văn bản.','Bước 1: chọn (bôi đen) đoạn văn bản cần sao chép. Bước 2: nhấn Ctrl + C để sao chép. Bước 3: nháy chuột đặt con trỏ vào vị trí cần dán. Bước 4: nhấn Ctrl + V để dán.'],
  [3,'Em cần làm bài trình chiếu về một loài vật em yêu thích. Hãy nêu nội dung em sẽ đặt ở trang tiêu đề và hai trang nội dung tiếp theo.','Trang tiêu đề: tên bài trình chiếu (ví dụ "Chú chó của em"), tên người thực hiện. Trang 2: giới thiệu đặc điểm của con vật (hình dáng, màu lông, kèm hình ảnh). Trang 3: ích lợi hoặc thói quen đáng yêu của con vật và cách em chăm sóc nó. Mỗi trang nên có tiêu đề ngắn, chữ rõ, hình ảnh phù hợp.'],
  [4,'Vì sao một trang chiếu không nên chứa quá nhiều chữ? Em sẽ trình bày trang chiếu như thế nào để người xem dễ theo dõi?','Trang chiếu dùng để hỗ trợ người nói; quá nhiều chữ làm người xem phải đọc, không nghe được người trình bày và dễ chán. Em sẽ chỉ ghi các ý chính ngắn gọn, dùng cỡ chữ to, màu chữ tương phản với nền, thêm hình ảnh minh họa phù hợp và mỗi trang chỉ nói về một ý. Như vậy người xem vừa nhìn vừa nghe sẽ hiểu bài tốt hơn.']
 ]);
 add(M,4,'Lập trình Scratch',[
  [1,'Trong Scratch, khu vực nhân vật thực hiện các hành động được gọi là gì?','Sân khấu','Thư mục','Bảng tính','Trang chiếu'],
  [1,'Trong Scratch, các lệnh được thể hiện dưới dạng gì?','Các khối lệnh có thể kéo thả, ghép với nhau','Các dòng chữ phải gõ bằng tay','Các hình ảnh động','Các con số'],
  [2,'Khối lệnh "di chuyển 10 bước" thuộc nhóm lệnh nào trong Scratch?','Chuyển động','Âm thanh','Hiển thị','Sự kiện'],
  [2,'Muốn nhân vật nói một câu trong 2 giây, em dùng khối lệnh thuộc nhóm nào?','Hiển thị','Chuyển động','Điều khiển','Cảm biến'],
  [2,'Để dừng mọi hoạt động của chương trình Scratch, em nháy vào nút nào?','Nút hình tròn màu đỏ','Lá cờ xanh','Nút hình loa','Nút lưu tệp'],
  [1,'Khối lệnh "xoay phải 15 độ" làm nhân vật làm gì?','Quay sang phải một góc 15 độ','Đi thẳng 15 bước','Nói "15"','Đổi màu'],
  [3,'Nêu các bước để tạo và chạy một chương trình Scratch đơn giản cho nhân vật mèo di chuyển trên sân khấu.','Bước 1: mở Scratch, chọn nhân vật mèo. Bước 2: kéo khối "khi bấm vào lá cờ xanh" từ nhóm Sự kiện vào khu vực lập trình. Bước 3: kéo khối "di chuyển 10 bước" từ nhóm Chuyển động ghép bên dưới. Bước 4: nháy lá cờ xanh để chạy và quan sát nhân vật di chuyển; có thể sửa số bước rồi chạy lại.'],
  [3,'Mô tả chương trình Scratch để nhân vật đi 50 bước, đợi 1 giây rồi nói "Tôi đã đến!".','Chương trình: khi bấm vào lá cờ xanh → di chuyển 50 bước → đợi 1 giây → nói "Tôi đã đến!" trong 2 giây. Các khối lệnh được ghép nối tiếp từ trên xuống dưới và thực hiện theo đúng thứ tự.'],
  [4,'Bạn Nam ghép các khối lệnh "di chuyển 10 bước" và "xoay phải 90 độ" vào trong khối "lặp lại 4 lần". Hãy giải thích nhân vật sẽ chuyển động theo hình gì và vì sao.','Nhân vật sẽ đi theo một hình vuông nhỏ. Vì mỗi lần lặp, nhân vật đi thẳng 10 bước rồi quay phải 90 độ; sau 4 lần lặp, nhân vật đã đi 4 cạnh bằng nhau và quay tổng cộng 360 độ, trở về vị trí ban đầu. Cấu trúc lặp giúp không phải kéo 4 lần cùng một cặp khối lệnh.']
 ]);
 /* ===== TIN HỌC 5 ===== */
 add(M,5,'Tìm kiếm thông tin, thư mục',[
  [1,'Trong máy tính, tệp (file) là gì?','Đơn vị lưu trữ thông tin như văn bản, hình ảnh, âm thanh','Một thiết bị phần cứng','Một trang web','Một phím trên bàn phím'],
  [1,'Để đổi tên một thư mục, em nháy chuột phải vào thư mục rồi chọn lệnh nào?','Rename (Đổi tên)','Delete (Xóa)','Copy (Sao chép)','Open (Mở)'],
  [2,'Thư mục nằm bên trong một thư mục khác được gọi là gì?','Thư mục con','Thư mục gốc','Tệp','Ổ đĩa'],
  [2,'Khi tìm kiếm trên máy tìm kiếm, kết quả trả về thường là gì?','Danh sách các liên kết đến các trang web có liên quan','Chỉ một trang web duy nhất','Một tệp đã được tải về máy','Một bài trình chiếu'],
  [2,'Khi tìm kiếm thông tin về "cách trồng rau trong chậu", em nên chọn từ khóa nào để kết quả sát nhất?','trồng rau trong chậu','rau','chậu','cách'],
  [1,'Sau khi xóa một tệp trên máy tính, tệp đó thường được chuyển vào đâu?','Thùng rác (Recycle Bin)','Thư mục gốc','Máy in','Internet'],
  [3,'Nêu các bước sao chép một tệp từ thư mục này sang thư mục khác.','Bước 1: mở thư mục chứa tệp, nháy chuột phải vào tệp, chọn Copy. Bước 2: mở thư mục đích. Bước 3: nháy chuột phải vào vùng trống trong thư mục đích, chọn Paste. Tệp được sao chép sang thư mục mới, tệp cũ vẫn còn.'],
  [3,'Em cần tìm thông tin về một danh lam thắng cảnh ở quê em để làm bài trình chiếu. Hãy nêu các bước tìm kiếm và chọn lọc thông tin.','Bước 1: xác định rõ nội dung cần tìm (tên danh lam, vị trí, đặc điểm). Bước 2: mở trình duyệt, vào máy tìm kiếm, gõ từ khóa phù hợp. Bước 3: xem danh sách kết quả, chọn các trang đáng tin cậy (trang chính thức, báo, cổng thông tin). Bước 4: đọc, so sánh thông tin ở vài trang, ghi lại nội dung cần dùng và nguồn trang web.'],
  [4,'Vì sao cần sắp xếp tệp vào các thư mục theo một cách hợp lí thay vì để tất cả trên màn hình nền? Hãy đề xuất cách tổ chức thư mục cho các bài học của em.','Nếu để lộn xộn, khi số tệp nhiều sẽ rất khó tìm, dễ nhầm hoặc xóa nhầm; sắp xếp theo thư mục giúp tìm nhanh, quản lí gọn gàng và dễ sao lưu. Đề xuất: tạo thư mục "Lớp 5", bên trong là các thư mục con theo môn học (Toán, Tiếng Việt, Tin học...); trong mỗi môn lại chia theo tuần hoặc bài; đặt tên tệp rõ ràng, có số bài để dễ nhận biết.']
 ]);
 add(M,5,'Lập trình Scratch nâng cao',[
  [1,'Cấu trúc tuần tự trong Scratch có nghĩa là gì?','Các lệnh được thực hiện lần lượt theo thứ tự từ trên xuống dưới','Các lệnh được thực hiện cùng lúc','Chỉ thực hiện lệnh đầu tiên','Thực hiện lệnh theo thứ tự ngẫu nhiên'],
  [1,'Khối lệnh "lặp lại 10 lần" thuộc loại cấu trúc nào?','Cấu trúc lặp với số lần biết trước','Cấu trúc rẽ nhánh','Cấu trúc tuần tự','Cấu trúc tạo biến'],
  [2,'Khối lệnh "nếu … thì … nếu không thì …" khác khối "nếu … thì …" ở điểm nào?','Có thêm phần lệnh được thực hiện khi điều kiện sai','Chỉ thực hiện khi điều kiện đúng','Lặp lại mãi mãi','Không cần điều kiện'],
  [2,'Để kiểm tra hai số có bằng nhau không, em dùng khối lệnh thuộc nhóm nào?','Các phép toán (toán tử so sánh)','Chuyển động','Âm thanh','Hiển thị'],
  [2,'Khối lệnh "lặp lại cho đến khi …" sẽ dừng lặp khi nào?','Khi điều kiện trong khối trở thành đúng','Khi đã lặp đúng 10 lần','Khi người dùng nháy lá cờ xanh','Không bao giờ dừng'],
  [1,'Khối lệnh "hỏi … và đợi" giúp chương trình làm gì?','Nhận câu trả lời do người dùng gõ vào','Vẽ hình trên sân khấu','Đổi trang phục nhân vật','Phát âm thanh'],
  [3,'Mô tả chương trình Scratch tính tổng hai số do người dùng nhập vào và thông báo kết quả.','Tạo hai biến a, b. Dùng khối "hỏi Nhập số thứ nhất và đợi", đặt a bằng "trả lời"; tiếp tục "hỏi Nhập số thứ hai và đợi", đặt b bằng "trả lời". Dùng khối toán tử (a + b) và cho nhân vật "nói (kết nối "Tổng là " với (a + b))". Chương trình chạy khi bấm lá cờ xanh.'],
  [3,'Em hãy mô tả kịch bản và các khối lệnh để nhân vật di chuyển liên tục và quay lại khi chạm vào cạnh sân khấu.','Kịch bản: khi bấm lá cờ xanh, nhân vật di chuyển mãi; chạm cạnh thì quay đầu. Khối lệnh: "khi bấm vào lá cờ xanh" → "liên tục" chứa "di chuyển 10 bước" và "nếu chạm cạnh thì bật lại". Có thể thêm "đặt kiểu xoay trái-phải" để nhân vật không bị lộn ngược.'],
  [4,'So sánh cấu trúc lặp "lặp lại 10 lần" và "liên tục" trong Scratch. Khi nào nên dùng mỗi loại? Cho ví dụ.','"Lặp lại 10 lần" thực hiện nhóm lệnh đúng một số lần biết trước rồi dừng, phù hợp khi biết rõ số lần cần làm, ví dụ vẽ hình vuông cần lặp 4 lần. "Liên tục" lặp không ngừng cho đến khi chương trình bị dừng, phù hợp cho hành động diễn ra suốt trò chơi, ví dụ nhân vật luôn kiểm tra xem có chạm vật cản hay không. Chọn đúng cấu trúc giúp chương trình chạy đúng ý và không bị lặp vô ích.']
 ]);
 add(M,5,'Đạo đức, an toàn số',[
  [1,'Việc sao chép tranh, bài viết của người khác trên mạng rồi ghi tên mình là hành vi gì?','Vi phạm bản quyền, không trung thực','Chia sẻ thông tin hợp lệ','Sáng tạo nội dung mới','Học tập tích cực'],
  [1,'Khi dùng chung máy tính ở trường, sau khi dùng xong tài khoản trực tuyến em cần làm gì?','Đăng xuất tài khoản','Để tài khoản mở cho bạn dùng tiếp','Ghi mật khẩu lên màn hình','Tắt màn hình là đủ'],
  [2,'Vì sao không nên dùng cùng một mật khẩu cho tất cả tài khoản?','Vì lộ một mật khẩu thì tất cả tài khoản đều có thể bị xâm nhập','Vì mật khẩu sẽ hết hạn','Vì máy tính không cho phép','Vì sẽ quên tên đăng nhập'],
  [2,'Khi sử dụng hình ảnh trên Internet cho bài trình chiếu, em nên làm gì để tôn trọng bản quyền?','Ghi rõ nguồn hình ảnh và ưu tiên hình được phép dùng miễn phí','Xóa tên tác giả trước khi dùng','Dùng tùy ý vì ảnh trên mạng là của chung','Đổi màu ảnh để thành của mình'],
  [2,'Em nhận được tin nhắn từ người lạ gửi đường liên kết kèm lời "nhấn vào để nhận thưởng". Cách xử lí đúng là gì?','Không nhấn vào, báo cho bố mẹ hoặc thầy cô','Nhấn vào ngay để xem','Gửi tiếp cho các bạn','Trả lời tin nhắn và cung cấp số điện thoại'],
  [1,'Phần mềm có bản quyền là phần mềm như thế nào?','Phần mềm được pháp luật bảo hộ, muốn dùng phải được tác giả cho phép hoặc mua giấy phép','Phần mềm ai cũng được sao chép tùy ý','Phần mềm không có tác giả','Phần mềm chỉ chạy trên điện thoại'],
  [3,'Nêu ba việc nên làm để sử dụng Internet an toàn và văn minh.','Ba việc nên làm: giữ bí mật thông tin cá nhân và mật khẩu; chỉ truy cập các trang web phù hợp lứa tuổi, không nhấn vào liên kết lạ; ứng xử lễ phép, tôn trọng người khác, không chia sẻ nội dung xấu, sai sự thật.'],
  [3,'Em muốn dùng một bài hát trên mạng làm nhạc nền cho video của lớp. Em cần lưu ý điều gì về bản quyền?','Cần kiểm tra bài hát có được phép sử dụng không; ưu tiên nhạc được cho phép dùng miễn phí hoặc xin phép tác giả; khi dùng phải ghi rõ tên bài hát, tác giả, nguồn; không dùng để kinh doanh nếu chưa được phép.'],
  [4,'Vì sao tôn trọng bản quyền nội dung thông tin lại quan trọng đối với cả người sáng tạo và người sử dụng? Hãy phân tích.','Đối với người sáng tạo, bản quyền bảo vệ công sức, trí tuệ của họ, giúp họ được ghi nhận và tiếp tục sáng tạo. Đối với người sử dụng, tôn trọng bản quyền thể hiện sự trung thực, tránh vi phạm pháp luật và học được cách tạo ra sản phẩm của chính mình. Nếu ai cũng sao chép tùy ý, người sáng tạo sẽ không muốn làm ra sản phẩm mới, xã hội sẽ thiếu đi những nội dung chất lượng.']
 ]);
 /* ===== TIN HỌC 6–9 (Bổ sung) ===== */
 add(M,6,'(Bổ sung) Thông tin và Internet',[
  [1,'Dữ liệu là gì?','Thông tin được ghi lên vật mang tin dưới dạng chữ, số, hình ảnh, âm thanh','Những điều ta hiểu được về thế giới xung quanh','Một thiết bị lưu trữ','Một chương trình máy tính'],
  [1,'Đơn vị cơ bản để đo lượng thông tin trong máy tính là gì?','Bit','Mét','Giây','Héc'],
  [2,'Một byte bằng bao nhiêu bit?','8 bit','2 bit','10 bit','1024 bit'],
  [2,'Mạng máy tính là gì?','Hai hay nhiều máy tính và thiết bị được kết nối để trao đổi dữ liệu, dùng chung tài nguyên','Một máy tính có kết nối máy in','Một tập hợp các trang web','Một phần mềm trình duyệt'],
  [2,'Siêu văn bản (hypertext) là loại văn bản như thế nào?','Văn bản tích hợp nhiều dạng dữ liệu và chứa các liên kết đến văn bản khác','Văn bản chỉ gồm chữ viết tay','Văn bản được in trên giấy khổ lớn','Văn bản chỉ dùng trong máy tính xách tay'],
  [1,'Phần mềm nào dùng để truy cập các trang web?','Trình duyệt web','Phần mềm bảng tính','Phần mềm vẽ','Phần mềm nén tệp'],
  [2,'Sơ đồ tư duy được dùng để làm gì?','Trình bày thông tin trực quan bằng từ khóa, hình ảnh và các nhánh liên kết','Tính toán số liệu','Soạn thảo văn bản dài','Lưu trữ tệp tin'],
  [3,'Nêu các bước xử lí thông tin và chỉ ra các bộ phận của máy tính tương ứng với từng bước.','Các bước: thu nhận thông tin (thiết bị vào: bàn phím, chuột, micro, máy quét); lưu trữ (bộ nhớ, ổ đĩa, USB); xử lí (bộ xử lí trung tâm CPU); truyền hoặc đưa ra thông tin (thiết bị ra: màn hình, loa, máy in). Máy tính thực hiện bốn hoạt động này giống quá trình xử lí thông tin của con người.'],
  [3,'Kể ba lợi ích của Internet trong học tập và ba nguy cơ có thể gặp khi sử dụng Internet.','Lợi ích: tra cứu tài liệu, kiến thức nhanh; học trực tuyến, xem bài giảng; trao đổi, hợp tác với bạn và thầy cô. Nguy cơ: tiếp xúc thông tin xấu, sai sự thật; bị lừa đảo, lộ thông tin cá nhân; nghiện mạng, bị bắt nạt trên mạng.'],
  [4,'Vì sao cùng một nguồn thông tin trên Internet nhưng không phải thông tin nào cũng đáng tin? Em cần làm gì để đánh giá độ tin cậy của thông tin tìm được?','Vì ai cũng có thể đăng nội dung lên Internet mà không bị kiểm duyệt chặt, nên có cả thông tin đúng, sai, lạc hậu hoặc cố ý lừa dối. Để đánh giá, cần xem nguồn gốc (trang chính thức, cơ quan uy tín hay trang lạ), tác giả là ai, thời gian đăng, mục đích đăng, đối chiếu với các nguồn khác và chú ý các dấu hiệu sai sót, giật gân. Chỉ sử dụng thông tin đã kiểm chứng.']
 ]);
 add(M,7,'(Bổ sung) Bảng tính và mạng xã hội',[
  [1,'Trong phần mềm bảng tính, giao của một hàng và một cột được gọi là gì?','Ô tính','Khối','Trang tính','Công thức'],
  [1,'Địa chỉ ô ở cột B, hàng 5 được viết là gì?','B5','5B','B-5','Ô 5 cột 2'],
  [2,'Hàm nào dùng để tính giá trị trung bình cộng của một khối ô?','AVERAGE','SUM','MAX','COUNT'],
  [2,'Khi sao chép công thức =A2+B2 từ ô C2 xuống ô C3, công thức ở C3 trở thành gì?','=A3+B3','=A2+B2','=C2+C3','=A2+B3'],
  [2,'Hệ điều hành có vai trò gì trong máy tính?','Quản lí phần cứng, phần mềm và tạo môi trường cho người dùng làm việc','Soạn thảo văn bản','Tính toán số liệu trong bảng tính','Chỉ dùng để chơi trò chơi'],
  [1,'Mạng xã hội là gì?','Dịch vụ trực tuyến cho phép người dùng tạo hồ sơ, kết nối và chia sẻ thông tin với nhau','Một loại phần mềm bảng tính','Một thiết bị mạng','Một trình duyệt web'],
  [2,'Hành vi nào sau đây là ứng xử thiếu văn hóa trên mạng xã hội?','Bình luận chế giễu, xúc phạm người khác','Chia sẻ bài viết về hoạt động thiện nguyện','Chúc mừng sinh nhật bạn','Hỏi bài tập trong nhóm lớp'],
  [3,'Trình bày các bước định dạng một bảng điểm trong phần mềm bảng tính để dễ đọc hơn.','Chọn dòng tiêu đề, định dạng chữ đậm, căn giữa; chọn các cột điểm, chọn định dạng số với số chữ số thập phân phù hợp; điều chỉnh độ rộng cột; tạo đường viền cho bảng; có thể tô màu nền dòng tiêu đề để phân biệt với dữ liệu.'],
  [3,'Em được mời tham gia một nhóm trên mạng xã hội. Hãy nêu ba quy tắc em sẽ tuân thủ khi tham gia nhóm.','Ba quy tắc: không đăng, chia sẻ thông tin sai sự thật hoặc nội dung xấu; tôn trọng ý kiến người khác, không công kích, bắt nạt; bảo vệ thông tin cá nhân của mình và không tiết lộ thông tin của người khác khi chưa được phép.'],
  [4,'Vì sao nên dùng hàm (như SUM, AVERAGE) thay cho việc gõ công thức cộng từng ô khi tính toán trên bảng tính? Phân tích ưu điểm.','Hàm cho phép tính trên cả khối ô bằng một biểu thức ngắn gọn, ví dụ =SUM(B2:B30) thay cho =B2+B3+...+B30, nên viết nhanh và ít sai sót. Khi dữ liệu thay đổi hay thêm hàng trong khối, kết quả tự động cập nhật. Công thức dùng hàm cũng dễ đọc, dễ kiểm tra và sao chép sang ô khác chính xác hơn.']
 ]);
 add(M,8,'(Bổ sung) Sơ đồ, thuật toán',[
  [1,'Thuật toán là gì?','Dãy các bước hữu hạn, rõ ràng để giải quyết một bài toán','Một phần mềm máy tính','Một loại biểu đồ','Một ngôn ngữ lập trình'],
  [1,'Trong sơ đồ khối mô tả thuật toán, hình thoi biểu diễn điều gì?','Bước kiểm tra điều kiện (rẽ nhánh)','Bước bắt đầu hoặc kết thúc','Bước nhập hoặc xuất dữ liệu','Bước xử lí tính toán'],
  [2,'Cấu trúc điều khiển nào thực hiện một nhóm lệnh nhiều lần?','Cấu trúc lặp','Cấu trúc tuần tự','Cấu trúc rẽ nhánh','Cấu trúc khai báo'],
  [2,'Biểu đồ nào phù hợp nhất để thể hiện tỉ lệ phần trăm của các phần trong một tổng thể?','Biểu đồ hình tròn','Biểu đồ đường','Biểu đồ cột','Biểu đồ phân tán'],
  [2,'Khi mô tả thuật toán, bước "Bắt đầu" và "Kết thúc" được vẽ bằng hình gì trong sơ đồ khối?','Hình ô-van (hình tròn dẹt)','Hình chữ nhật','Hình thoi','Hình bình hành'],
  [1,'Trong Scratch, để lặp một nhóm lệnh khi điều kiện còn chưa đúng, em dùng khối lệnh nào?','lặp lại cho đến khi','nếu thì','liên tục','chờ'],
  [2,'Trong phần mềm bảng tính, muốn sắp xếp dữ liệu theo điểm từ cao xuống thấp, em dùng chức năng nào?','Sort (Sắp xếp) giảm dần','Filter (Lọc)','Chart (Biểu đồ)','Format (Định dạng)'],
  [3,'Mô tả bằng liệt kê các bước thuật toán tìm số lớn nhất trong ba số a, b, c.','Bước 1: nhập a, b, c. Bước 2: gán Max = a. Bước 3: nếu b > Max thì Max = b. Bước 4: nếu c > Max thì Max = c. Bước 5: thông báo Max là số lớn nhất. Kết thúc.'],
  [3,'Em được giao vẽ biểu đồ so sánh số sách đã đọc của các tổ trong lớp. Hãy nêu loại biểu đồ nên dùng và các bước tạo biểu đồ trong phần mềm bảng tính.','Nên dùng biểu đồ cột vì so sánh số lượng giữa các tổ. Các bước: nhập bảng dữ liệu tên tổ và số sách; chọn khối dữ liệu; chọn lệnh chèn biểu đồ, chọn kiểu biểu đồ cột; đặt tiêu đề biểu đồ, tên trục, chú giải; chỉnh màu sắc cho rõ ràng.'],
  [4,'Vì sao cần mô tả thuật toán rõ ràng trước khi viết chương trình? Hãy phân tích bằng ví dụ một bài toán đơn giản.','Thuật toán là lời giải được trình bày thành các bước rõ ràng, giúp người lập trình hiểu đúng bài toán, kiểm tra tính đúng trước khi viết mã, dễ phát hiện sai sót và dễ chuyển sang bất kì ngôn ngữ lập trình nào. Ví dụ bài toán tính trung bình ba số: nếu không xác định trước các bước nhập ba số, tính tổng, chia cho 3 rồi in kết quả thì có thể viết nhầm thành chia cho 2 hoặc quên nhập đủ số. Mô tả thuật toán trước giúp chương trình đúng ngay từ đầu.']
 ]);
 add(M,9,'(Bổ sung) Lập trình và đạo đức số',[
  [1,'Trong lập trình, biến dùng để làm gì?','Lưu trữ một giá trị có thể thay đổi trong khi chương trình chạy','Vẽ hình trên màn hình','Kết nối Internet','Lưu tệp vào thư mục'],
  [1,'Chương trình con (hàm, thủ tục) có lợi ích gì?','Chia chương trình lớn thành các phần nhỏ, dễ hiểu và dùng lại được','Làm chương trình chạy chậm hơn','Thay thế hoàn toàn cấu trúc lặp','Chỉ dùng để trang trí mã nguồn'],
  [2,'Hành vi nào sau đây là vi phạm pháp luật khi sử dụng công nghệ số?','Đăng tin giả, bịa đặt về người khác trên mạng','Tra cứu tài liệu học tập trên mạng','Gửi thư điện tử cho thầy cô','Chia sẻ bài báo chính thống'],
  [2,'Khi dùng thông tin trên Internet cho bài tập, cách làm đúng là gì?','Chọn lọc, tổng hợp bằng lời của mình và ghi rõ nguồn trích dẫn','Sao chép nguyên văn và ghi tên mình','Chỉ dùng một nguồn duy nhất mà không kiểm tra','Xóa tên tác giả gốc'],
  [2,'Đoạn mã kiểm tra một số n chia hết cho 2 hay không nên dùng cấu trúc nào?','Rẽ nhánh với điều kiện n chia 2 dư 0','Lặp vô hạn','Khai báo hằng','Tuần tự không điều kiện'],
  [1,'Trong Scratch, danh sách (list) dùng để làm gì?','Lưu nhiều giá trị trong một cấu trúc có thứ tự','Thay đổi trang phục nhân vật','Phát âm thanh','Vẽ biểu đồ'],
  [2,'Tin học ảnh hưởng đến nghề nghiệp như thế nào trong xã hội hiện nay?','Nhiều nghề mới xuất hiện và hầu hết các nghề đều cần kĩ năng sử dụng công nghệ số','Chỉ người làm lập trình mới cần tin học','Tin học làm biến mất hoàn toàn mọi nghề cũ','Không có ảnh hưởng đáng kể'],
  [3,'Nêu các bước giải quyết một bài toán bằng lập trình và cho ví dụ với bài toán tính diện tích hình chữ nhật.','Các bước: xác định bài toán (đầu vào: chiều dài a, chiều rộng b; đầu ra: diện tích S); xây dựng thuật toán (nhập a, b; S = a × b; in S); viết chương trình bằng ngôn ngữ lập trình; chạy thử với dữ liệu mẫu (a = 4, b = 3 cho S = 12) và sửa lỗi nếu có.'],
  [3,'Em thấy một bạn trong lớp bị chế ảnh và lan truyền trên nhóm chat. Em sẽ làm gì? Giải thích ngắn gọn.','Không chia sẻ tiếp, nhắn riêng động viên bạn; nhắc các bạn dừng lan truyền vì xúc phạm danh dự người khác; báo cho thầy cô hoặc cha mẹ để được hỗ trợ; lưu lại bằng chứng nếu cần. Hành vi chế ảnh, bôi nhọ người khác là vi phạm đạo đức và có thể vi phạm pháp luật.'],
  [4,'Vì sao người học lập trình cần có đạo đức và trách nhiệm trong thế giới số? Phân tích với một tình huống cụ thể.','Người biết lập trình có khả năng tạo ra phần mềm tác động đến nhiều người; nếu dùng vào việc xấu (viết chương trình gian lận, lấy cắp dữ liệu, phát tán thông tin sai) sẽ gây hại lớn và vi phạm pháp luật. Ví dụ, một bạn viết công cụ tự động gửi tin rác vào nhóm lớp: dù chỉ "cho vui" nhưng làm phiền, có thể lộ thông tin của mọi người và làm mất lòng tin. Ngược lại, dùng kĩ năng để tạo ứng dụng học tập hữu ích sẽ đem lại giá trị cho cộng đồng. Do đó, kĩ năng phải đi cùng đạo đức và trách nhiệm.']
 ]);
 /* ===== CÔNG NGHỆ 3 ===== */
 M='Công nghệ';
 add(M,3,'Tự nhiên và công nghệ',[
  [1,'Sản phẩm công nghệ là gì?','Sản phẩm do con người tạo ra để phục vụ đời sống','Vật có sẵn trong tự nhiên','Cây cối trong rừng','Các con vật hoang dã'],
  [1,'Trong các đối tượng sau, đối tượng nào do con người làm ra?','Chiếc xe đạp','Dòng sông','Mặt Trời','Cơn mưa'],
  [2,'Công nghệ mang lại lợi ích gì cho con người?','Giúp cuộc sống thuận tiện, dễ dàng và vui vẻ hơn','Làm con người lười vận động hoàn toàn','Chỉ dùng để trang trí nhà cửa','Không có lợi ích gì'],
  [2,'Việc nào sau đây thể hiện em biết giữ gìn sản phẩm công nghệ?','Lau chùi, cất đồ dùng đúng chỗ sau khi sử dụng','Ném đồ chơi khi không thích','Để quạt điện chạy cả khi không có ai','Tháo rời ti vi để xem bên trong'],
  [2,'Vật nào sau đây là sản phẩm công nghệ giúp em học tập?','Đèn học','Hòn đá','Đám mây','Con chim'],
  [1,'Đối tượng nào sau đây thuộc tự nhiên, không phải sản phẩm công nghệ?','Ngọn núi','Chiếc cầu','Tòa nhà','Chiếc ô tô'],
  [3,'Hãy kể hai sản phẩm công nghệ ở trường em và cho biết mỗi sản phẩm giúp ích gì cho việc học.','Ví dụ: quạt điện giúp lớp học thoáng mát, dễ tập trung học; bảng (hoặc máy chiếu) giúp thầy cô trình bày bài học rõ ràng, học sinh dễ quan sát. Các sản phẩm này đều do con người tạo ra để phục vụ việc dạy và học.'],
  [3,'Phân biệt đối tượng tự nhiên và sản phẩm công nghệ. Mỗi loại nêu hai ví dụ.','Đối tượng tự nhiên là những gì có sẵn trong thiên nhiên, không do con người tạo ra, ví dụ: cây cỏ, con sông. Sản phẩm công nghệ là những vật do con người làm ra để phục vụ cuộc sống, ví dụ: cái bàn, chiếc đèn pin.'],
  [4,'Vì sao con người cần tạo ra các sản phẩm công nghệ dù tự nhiên đã có sẵn rất nhiều thứ? Hãy giải thích bằng một ví dụ.','Tự nhiên cung cấp nguyên liệu, nhưng nhiều nhu cầu của con người tự nhiên không đáp ứng được trực tiếp. Ví dụ, trời tối không có ánh sáng tự nhiên nên con người tạo ra đèn điện để học tập, làm việc ban đêm. Sản phẩm công nghệ giúp cuộc sống an toàn, thuận tiện và tốt hơn; tuy nhiên khi tạo ra và dùng chúng, con người cần bảo vệ thiên nhiên và sử dụng tiết kiệm.']
 ]);
 add(M,3,'Sử dụng đèn học, quạt điện, ti vi',[
  [1,'Bộ phận nào của đèn học dùng để phát sáng?','Bóng đèn','Chân đèn','Dây điện','Công tắc'],
  [1,'Bộ phận nào của quạt điện tạo ra gió?','Cánh quạt','Lồng quạt','Đế quạt','Dây nguồn'],
  [2,'Lồng quạt có tác dụng gì?','Bảo vệ, tránh tay chạm vào cánh quạt đang quay','Làm quạt chạy nhanh hơn','Trang trí cho quạt','Tạo ra gió'],
  [2,'Khi ngồi học, em nên đặt đèn học ở vị trí nào?','Phía đối diện với tay viết để không bị bóng che chữ','Ngay trước mặt, chiếu thẳng vào mắt','Sau lưng em','Dưới gầm bàn'],
  [2,'Khi xem ti vi, em nên ngồi như thế nào?','Ngồi cách ti vi khoảng cách phù hợp, không quá gần, không nằm xem','Ngồi sát màn hình để nhìn rõ','Nằm xem trong bóng tối','Vừa xem vừa ăn và đi lại liên tục'],
  [1,'Trên điều khiển ti vi, các nút có dấu "+" và "–" ở phần âm lượng dùng để làm gì?','Tăng hoặc giảm âm thanh','Bật hoặc tắt ti vi','Chuyển sang kênh khác','Đổi màu hình ảnh'],
  [2,'Việc nào sau đây là sử dụng máy thu thanh (ra-đi-ô) đúng cách?','Chọn kênh phù hợp, chỉnh âm lượng vừa đủ nghe','Mở âm thanh thật to để cả xóm nghe','Để ra-đi-ô dưới nước','Rút dây khi đang nghe bằng cách giật mạnh'],
  [3,'Nêu các bước sử dụng quạt điện an toàn, đúng cách.','Bước 1: đặt quạt ở nơi bằng phẳng, khô ráo. Bước 2: cắm phích điện vào ổ. Bước 3: bấm nút chọn tốc độ phù hợp, có thể bật chế độ quay. Bước 4: khi không dùng, bấm nút tắt và rút phích điện. Không đưa tay, vật vào lồng quạt khi quạt đang chạy.'],
  [3,'Theo em, dùng đèn học thế nào để bảo vệ mắt và tiết kiệm điện?','Chọn đèn có ánh sáng vừa đủ, không quá chói; đặt đèn phía đối diện tay viết để không bị bóng che chữ; học ở nơi có đủ ánh sáng chung trong phòng; tắt đèn khi không học để tiết kiệm điện và kéo dài tuổi thọ của đèn.'],
  [4,'Vì sao không nên tự ý sửa chữa đèn học, quạt điện hay ti vi khi chúng bị hỏng? Em nên làm gì trong trường hợp đó?','Vì các đồ dùng này sử dụng điện, khi tháo mở có thể bị điện giật, chập cháy, rất nguy hiểm với trẻ em; đồng thời tự sửa sai cách có thể làm đồ dùng hỏng nặng hơn. Khi phát hiện hỏng, em cần tắt công tắc, rút phích điện (nếu an toàn) và báo ngay cho người lớn để đưa đi sửa ở nơi có chuyên môn.']
 ]);
 add(M,3,'Thủ công kĩ thuật',[
  [1,'Vật liệu nào sau đây thường được dùng để làm đồ dùng học tập thủ công?','Giấy bìa','Sắt tấm','Kính','Đá'],
  [1,'Dụng cụ nào dùng để dán các mảnh giấy lại với nhau?','Hồ dán hoặc băng dính','Kéo','Thước kẻ','Bút chì'],
  [2,'Dụng cụ nào giúp em vẽ các đường thẳng và đo kích thước khi làm sản phẩm thủ công?','Thước kẻ','Hồ dán','Kéo','Khăn lau'],
  [2,'Khi dùng xong kéo, em nên làm gì?','Đóng kéo, cất vào hộp đúng chỗ','Để kéo mở trên bàn','Ném kéo cho bạn','Cầm kéo chạy chơi'],
  [2,'Biển báo giao thông hình tròn, viền màu đỏ có nghĩa chung là gì?','Biển báo cấm','Biển chỉ dẫn','Biển hiệu lệnh','Biển báo nguy hiểm'],
  [1,'Khi làm đồ chơi bằng giấy, bước nào thường được làm đầu tiên?','Chuẩn bị vật liệu và dụng cụ','Trang trí sản phẩm','Dán các bộ phận','Cất sản phẩm'],
  [3,'Nêu các bước làm một chiếc thẻ đánh dấu sách (bookmark) bằng giấy bìa.','Bước 1: chuẩn bị giấy bìa, thước, bút chì, kéo, bút màu. Bước 2: dùng thước và bút chì vẽ hình chữ nhật trên giấy bìa. Bước 3: cắt theo đường vẽ. Bước 4: trang trí bằng bút màu, có thể đục lỗ buộc dây. Bước 5: kiểm tra sản phẩm và thu dọn dụng cụ.'],
  [3,'Nêu ba quy tắc an toàn khi sử dụng dụng cụ làm thủ công.','Ba quy tắc: cầm kéo đúng cách, cắt cẩn thận, không hướng mũi kéo về phía người khác; không bôi hồ dán lên tay, mặt, quần áo, dùng xong rửa tay; dùng xong cất dụng cụ đúng chỗ và dọn sạch chỗ làm.'],
  [4,'Vì sao khi làm biển báo giao thông bằng giấy, em cần làm đúng hình dạng và màu sắc như biển báo thật? Giải thích.','Vì mỗi hình dạng, màu sắc của biển báo mang một ý nghĩa quy định: hình tròn đỏ là biển cấm, hình tam giác vàng viền đỏ là biển nguy hiểm, hình tròn xanh là biển hiệu lệnh. Làm đúng giúp sản phẩm có ý nghĩa, giúp em và các bạn ghi nhớ đúng luật giao thông; làm sai hình, sai màu sẽ gây hiểu nhầm và sản phẩm không còn giá trị học tập.']
 ]);
 /* ===== CÔNG NGHỆ 4 ===== */
 add(M,4,'Hoa và cây cảnh',[
  [1,'Hoa và cây cảnh mang lại lợi ích gì cho con người?','Làm đẹp không gian sống, làm không khí trong lành, giúp thư giãn','Chỉ dùng để làm thức ăn','Làm nhà cửa thêm bụi bẩn','Không có lợi ích'],
  [1,'Loài hoa nào thường có màu vàng, nở nhiều vào dịp Tết ở miền Nam?','Hoa mai','Hoa đào','Hoa sen','Hoa phượng'],
  [2,'Loại cây nào sau đây thường được trồng làm cây cảnh trong nhà?','Cây lưỡi hổ','Cây lúa','Cây ngô','Cây mía'],
  [2,'Khi trồng cây trong chậu, giá thể (đất trồng) cần có đặc điểm gì?','Tơi xốp, thoát nước tốt và giữ được độ ẩm','Cứng như đá','Luôn ngập nước','Khô hoàn toàn, không có chất dinh dưỡng'],
  [2,'Sau khi gieo hạt vào chậu, em cần làm gì để hạt nảy mầm tốt?','Tưới nước giữ ẩm và đặt chậu ở nơi có đủ ánh sáng','Đặt chậu trong tủ kín','Tưới thật nhiều nước cho ngập chậu','Không tưới nước cho đến khi cây lớn'],
  [1,'Dụng cụ nào dùng để tưới nước cho cây trong chậu?','Bình tưới','Kéo cắt tỉa','Xẻng','Cuốc'],
  [2,'Vì sao cần tỉa bớt lá vàng, cành khô cho cây cảnh?','Giúp cây thông thoáng, đẹp hơn và hạn chế sâu bệnh','Để cây nhỏ đi','Để cây không cần tưới nước','Để cây không ra hoa'],
  [3,'Nêu các công việc chăm sóc cây hoa trồng trong chậu để cây phát triển tốt.','Tưới nước đủ ẩm, không để ngập úng; đặt chậu nơi có ánh sáng phù hợp với từng loại cây; bón phân định kì với lượng vừa phải; nhổ cỏ, tỉa lá vàng, cành khô; theo dõi và bắt sâu, phòng bệnh cho cây.'],
  [3,'Kể tên hai loại hoa và hai loại cây cảnh phổ biến, nêu một đặc điểm nhận biết của mỗi loại.','Hoa: hoa hồng có nhiều cánh xếp lớp, thân có gai; hoa cúc có nhiều cánh nhỏ dài xếp quanh nhụy. Cây cảnh: cây lưỡi hổ lá dài, cứng, mọc thẳng, có sọc; cây trầu bà lá hình tim, thân mềm có thể buông rủ hoặc leo.'],
  [4,'Bạn Lan tưới cây cảnh thật nhiều nước mỗi ngày nhưng cây vẫn bị vàng lá và héo. Theo em nguyên nhân có thể là gì và nên chăm sóc lại như thế nào?','Nguyên nhân có thể do tưới quá nhiều nước làm đất ngập úng, rễ thiếu không khí và bị thối, hoặc chậu không thoát nước được. Cần giảm lượng nước, chỉ tưới khi mặt đất khô; kiểm tra lỗ thoát nước của chậu, thay giá thể tơi xốp nếu đất bị bết; đặt cây ở nơi thoáng, đủ sáng và tỉa bỏ lá vàng. Chăm sóc đúng nhu cầu của cây quan trọng hơn chăm sóc nhiều.']
 ]);
 add(M,4,'Lắp ghép mô hình kĩ thuật',[
  [1,'Trong bộ lắp ghép mô hình kĩ thuật, chi tiết nào dùng để nối các tấm, thanh lại với nhau?','Vít và đai ốc','Bánh xe','Trục','Tấm lớn'],
  [1,'Dụng cụ nào dùng để tháo, lắp vít khi lắp ghép mô hình?','Tua vít và cờ lê','Kéo','Búa','Thước kẻ'],
  [2,'Khi lắp ghép mô hình, bản vẽ hoặc hình mẫu có vai trò gì?','Giúp em biết cần những chi tiết nào và lắp theo thứ tự nào','Dùng để trang trí sản phẩm','Không cần thiết','Chỉ để đếm số chi tiết'],
  [2,'Khi lắp ghép xong mô hình, em cần làm gì?','Kiểm tra lại các mối ghép và vận hành thử','Cất ngay vào hộp mà không kiểm tra','Tháo hết ra ngay','Vứt các chi tiết dư thừa'],
  [2,'Khi tháo mô hình, em nên tháo theo thứ tự nào?','Ngược lại với thứ tự lắp, tháo từng chi tiết và xếp gọn','Tháo tùy ý, chi tiết nào dễ thì tháo trước','Dùng búa đập cho rời ra','Không cần tháo, để nguyên'],
  [1,'Trong các mô hình sau, mô hình nào thường có hai bánh xe quay quanh trục?','Mô hình xe đẩy','Mô hình cái đu','Mô hình cầu','Mô hình ngôi nhà'],
  [3,'Nêu các bước chung khi lắp ghép một mô hình kĩ thuật từ bộ lắp ghép.','Bước 1: quan sát hình mẫu, chọn và kiểm tra đủ các chi tiết cần dùng. Bước 2: lắp từng bộ phận theo hướng dẫn. Bước 3: lắp ráp các bộ phận thành mô hình hoàn chỉnh, siết chặt vít. Bước 4: kiểm tra, vận hành thử và chỉnh sửa. Bước 5: sau khi dùng, tháo rời, xếp chi tiết vào hộp đúng vị trí.'],
  [3,'Nêu ba lưu ý về an toàn khi lắp ghép mô hình kĩ thuật.','Ba lưu ý: không cho các chi tiết nhỏ vào miệng, tránh để rơi vào tay em bé; dùng tua vít, cờ lê đúng cách, không đùa nghịch với dụng cụ; sau khi lắp, thu dọn và cất đủ các chi tiết vào hộp, không để rơi vãi trên sàn gây trượt ngã.'],
  [4,'Vì sao khi lắp ghép mô hình cần siết vít đủ chặt nhưng không quá chặt? Hãy phân tích hậu quả của hai trường hợp này.','Nếu vít lỏng, các bộ phận sẽ lung lay, mô hình dễ bị gãy rời hoặc chạy không ổn định, có thể gây nguy hiểm. Nếu siết quá chặt, có thể làm hỏng ren vít, nứt tấm nhựa hoặc rất khó tháo rời sau khi dùng. Vì vậy cần siết vừa tay, kiểm tra lại từng mối ghép sau khi lắp để mô hình chắc chắn, hoạt động tốt và vẫn tháo được dễ dàng.']
 ]);
 add(M,4,'Đồ chơi dân gian',[
  [1,'Vật liệu nào thường được dùng để làm diều giấy?','Giấy, thanh tre và dây','Sắt và nhựa cứng','Vải len','Đá và cát'],
  [1,'Đèn lồng (đèn ông sao) thường được chơi trong dịp nào?','Tết Trung thu','Ngày khai giảng','Tết Dương lịch','Ngày Quốc tế Thiếu nhi'],
  [2,'Đồ chơi dân gian có đặc điểm gì?','Làm từ vật liệu đơn giản, gần gũi với thiên nhiên và gắn với văn hóa truyền thống','Chạy bằng pin và có đèn nhấp nháy','Chỉ mua được ở nước ngoài','Được làm từ kim loại quý'],
  [2,'Khi thả diều, em nên chọn nơi nào để an toàn?','Nơi rộng, thoáng, xa đường dây điện và đường giao thông','Dưới đường dây điện','Trên sân thượng nhà cao tầng','Trên đường phố đông xe cộ'],
  [2,'Khung của đèn ông sao được làm bằng gì?','Các thanh tre (hoặc nan) buộc lại','Dây sắt hàn','Giấy xếp chồng lên nhau','Nhựa đúc'],
  [1,'Đồ chơi dân gian nào sau đây quay được nhờ gió?','Chong chóng','Đèn ông sao','Con quay bằng gỗ','Mặt nạ giấy'],
  [3,'Nêu các bước làm một chiếc đèn lồng (đèn ông sao) đơn giản bằng giấy và thanh tre.','Bước 1: chuẩn bị thanh tre vót mỏng, dây buộc, giấy màu, hồ dán, kéo. Bước 2: buộc các thanh tre tạo khung hình ngôi sao, chống thêm thanh ngang để khung phồng lên. Bước 3: cắt giấy màu dán kín các cánh sao. Bước 4: trang trí viền, gắn cán cầm. Bước 5: kiểm tra độ chắc chắn của đèn.'],
  [3,'Theo em, vì sao nên giữ gìn và chơi các đồ chơi dân gian?','Vì đồ chơi dân gian gắn với văn hóa truyền thống của dân tộc; làm đồ chơi giúp em khéo tay, sáng tạo và hiểu thêm về ông bà, quê hương; vật liệu đơn giản, thân thiện với môi trường; khi chơi thường cùng bạn bè ở ngoài trời nên vui và khỏe mạnh hơn.'],
  [4,'So sánh đồ chơi dân gian (như diều, đèn ông sao) với đồ chơi điện tử hiện đại về vật liệu, cách chơi và ảnh hưởng đến sức khỏe.','Về vật liệu: đồ chơi dân gian làm từ tre, giấy, dây, gần gũi và dễ tái chế; đồ chơi điện tử dùng nhựa, pin, mạch điện, thải ra khó phân hủy. Về cách chơi: đồ chơi dân gian thường tự làm, chơi ngoài trời cùng bạn bè; đồ chơi điện tử thường chơi một mình, trong nhà. Về sức khỏe: thả diều, rước đèn giúp vận động, mắt được nhìn xa; chơi điện tử lâu dễ mỏi mắt, ít vận động. Mỗi loại đều có giá trị, nhưng cần cân đối và ưu tiên hoạt động ngoài trời.']
 ]);
 /* ===== CÔNG NGHỆ 5 ===== */
 add(M,5,'Công nghệ và đời sống',[
  [1,'Nhà sáng chế là người như thế nào?','Người tạo ra sản phẩm mới hoặc cải tiến sản phẩm để giải quyết vấn đề trong cuộc sống','Người chỉ sử dụng sản phẩm công nghệ','Người bán hàng','Người sửa chữa đồ dùng'],
  [1,'Sản phẩm công nghệ nào giúp con người đi lại nhanh hơn trên quãng đường dài?','Ô tô, tàu hỏa, máy bay','Đèn học','Tủ lạnh','Máy giặt'],
  [2,'Bước đầu tiên trong quá trình thiết kế một sản phẩm là gì?','Xác định vấn đề cần giải quyết và yêu cầu của sản phẩm','Trang trí sản phẩm','Bán sản phẩm','Chụp ảnh sản phẩm'],
  [2,'Vì sao sau khi làm xong sản phẩm mẫu, cần thử nghiệm và đánh giá?','Để phát hiện điểm chưa tốt và cải tiến sản phẩm','Để sản phẩm đẹp hơn ngay lập tức','Vì đó là bước không bắt buộc','Để cất sản phẩm đi'],
  [2,'Công nghệ có thể gây ra tác động tiêu cực nào nếu sử dụng không hợp lí?','Ô nhiễm môi trường, lạm dụng thiết bị ảnh hưởng sức khỏe','Giúp liên lạc nhanh hơn','Giúp sản xuất nhiều hàng hóa hơn','Giúp chữa bệnh tốt hơn'],
  [1,'Trong quá trình thiết kế, "bản vẽ phác thảo" dùng để làm gì?','Thể hiện ý tưởng về hình dạng, các bộ phận của sản phẩm trước khi làm','Đo kích thước phòng học','Ghi lại giá tiền của sản phẩm','Kiểm tra sản phẩm sau khi dùng'],
  [2,'Khi đánh giá một sản phẩm công nghệ, tiêu chí nào quan trọng?','An toàn, dễ sử dụng, hữu ích và tiết kiệm','Chỉ cần đẹp','Chỉ cần đắt tiền','Chỉ cần to lớn'],
  [3,'Nêu các bước chính của quá trình thiết kế một sản phẩm đơn giản.','Bước 1: xác định vấn đề và yêu cầu của sản phẩm. Bước 2: tìm hiểu thông tin, đưa ra ý tưởng và vẽ phác thảo. Bước 3: lựa chọn vật liệu, làm sản phẩm mẫu. Bước 4: thử nghiệm, đánh giá sản phẩm. Bước 5: điều chỉnh, hoàn thiện sản phẩm.'],
  [3,'Kể hai phẩm chất cần có của một nhà sáng chế và giải thích vì sao cần phẩm chất đó.','Óc quan sát và tò mò: giúp phát hiện những vấn đề trong cuộc sống cần giải quyết. Kiên trì, không nản khi thất bại: vì sản phẩm thường phải thử nghiệm, sửa chữa nhiều lần mới thành công. Ngoài ra còn cần sáng tạo, ham học hỏi và làm việc cẩn thận.'],
  [4,'Vì sao có thể nói công nghệ vừa đem lại lợi ích vừa có thể gây hại cho con người? Theo em, cần sử dụng công nghệ như thế nào?','Công nghệ giúp cuộc sống thuận tiện: đi lại, liên lạc, học tập, chữa bệnh tốt hơn. Nhưng nếu lạm dụng hoặc dùng sai mục đích sẽ gây hại: dùng điện thoại quá nhiều ảnh hưởng mắt và việc học, rác điện tử và khí thải gây ô nhiễm. Vì vậy cần dùng công nghệ đúng mục đích, có thời gian hợp lí, tiết kiệm năng lượng và chọn những sản phẩm thân thiện với môi trường.']
 ]);
 add(M,5,'Sử dụng điện thoại, tủ lạnh',[
  [1,'Số điện thoại 114 dùng để gọi khi nào?','Khi cần báo cháy hoặc cứu nạn, cứu hộ','Khi cần gọi cấp cứu y tế','Khi muốn hỏi giờ','Khi muốn đặt đồ ăn'],
  [1,'Số điện thoại 115 là số gọi dịch vụ gì?','Cấp cứu y tế','Cứu hỏa','Công an','Tra cứu thông tin'],
  [2,'Khi nghe điện thoại của người lạ gọi đến hỏi thông tin gia đình, em nên làm gì?','Không cung cấp thông tin và báo cho người lớn','Trả lời đầy đủ mọi câu hỏi','Đọc địa chỉ nhà cho họ','Mời họ đến nhà'],
  [2,'Thức ăn đã nấu chín nên được bảo quản trong tủ lạnh như thế nào?','Để nguội, đậy kín rồi cho vào ngăn mát','Để nóng và cho ngay vào ngăn đá','Để mở không đậy trong ngăn mát','Không cần cho vào tủ lạnh'],
  [2,'Ngăn đá của tủ lạnh dùng để làm gì?','Làm đá và bảo quản thực phẩm cần đông lạnh như thịt, cá','Bảo quản rau xanh','Để bánh mì cho mềm','Cất đồ dùng học tập'],
  [1,'Việc nào sau đây giúp tiết kiệm điện khi dùng tủ lạnh?','Đóng cửa tủ ngay sau khi lấy đồ, không mở tủ quá lâu','Mở cửa tủ thường xuyên để hơi mát ra phòng','Cho nhiều đồ nóng vào tủ','Để cửa tủ hé khi không dùng'],
  [2,'Khi dùng điện thoại, hành vi nào là lịch sự?','Nói vừa đủ nghe, xưng hô lễ phép, chào hỏi khi bắt đầu và kết thúc','Hét to trong thư viện','Nghe điện thoại trong giờ học','Nói chuyện rất lâu về việc không cần thiết'],
  [3,'Nêu các bước gọi điện thoại cho ông bà bằng điện thoại di động một cách lịch sự.','Bước 1: mở danh bạ, tìm tên ông bà hoặc bấm số. Bước 2: bấm nút gọi, đợi ông bà nghe máy. Bước 3: chào hỏi lễ phép, nói rõ mình là ai, nói chuyện vừa đủ nghe. Bước 4: chào tạm biệt rồi bấm nút kết thúc cuộc gọi.'],
  [3,'Hãy nêu cách sắp xếp thực phẩm trong tủ lạnh để bảo quản tốt và an toàn.','Thực phẩm sống (thịt, cá) để ngăn đá hoặc ngăn riêng, bọc kín để không chảy nước sang thức ăn khác; thức ăn đã nấu chín đậy kín để ngăn mát, để riêng với đồ sống; rau, củ, quả cho vào ngăn rau; không xếp quá chật để hơi lạnh lưu thông; thường xuyên kiểm tra, bỏ đồ hỏng.'],
  [4,'Vì sao không nên để thức ăn sống và thức ăn chín cạnh nhau, không đậy kín trong tủ lạnh? Phân tích hậu quả và cách phòng tránh.','Thức ăn sống có thể chứa vi khuẩn gây bệnh; để lẫn với thức ăn chín không đậy kín, vi khuẩn và nước từ đồ sống sẽ lây sang thức ăn chín, ăn vào có thể bị ngộ độc, đau bụng. Mùi của các loại thức ăn cũng lẫn vào nhau làm giảm chất lượng. Cách phòng tránh: đựng riêng từng loại trong hộp kín, đồ sống để ngăn dưới hoặc ngăn đá, đồ chín để ngăn trên, vệ sinh tủ lạnh thường xuyên.']
 ]);
 add(M,5,'Mô hình điện',[
  [1,'Trong mô hình xe điện chạy pin, bộ phận nào biến điện năng thành chuyển động quay?','Động cơ điện','Công tắc','Dây dẫn','Bánh xe'],
  [1,'Bộ phận nào dùng để đóng, ngắt mạch điện trong mô hình điện?','Công tắc','Pin','Động cơ','Trục xe'],
  [2,'Trong mô hình máy phát điện gió, cánh quạt gió có vai trò gì?','Nhận sức gió làm quay trục nối với máy phát điện','Tạo ra ánh sáng','Chứa điện','Làm mát mô hình'],
  [2,'Trong mô hình điện mặt trời, tấm pin mặt trời làm nhiệm vụ gì?','Biến ánh sáng mặt trời thành điện','Làm gương phản chiếu','Tạo ra gió','Làm nóng nước'],
  [2,'Nếu lắp pin ngược cực trong mô hình xe điện, điều gì có thể xảy ra?','Động cơ quay ngược chiều hoặc không hoạt động đúng','Xe chạy nhanh hơn','Pin tự nạp đầy','Không có gì thay đổi'],
  [1,'Dây dẫn điện trong mô hình có tác dụng gì?','Nối các bộ phận để dòng điện đi qua','Giữ cho mô hình đứng vững','Phát ra ánh sáng','Tạo ra gió'],
  [2,'Khi mô hình xe điện không chạy sau khi lắp xong, em nên kiểm tra điều gì trước tiên?','Pin có còn điện và các mối nối dây có chắc chắn không','Màu sơn của xe','Kích thước bánh xe','Hình dáng của vỏ xe'],
  [3,'Nêu các bước lắp mô hình máy phát điện gió đơn giản.','Bước 1: chuẩn bị các chi tiết: cánh quạt, trục, máy phát (mô tơ nhỏ), đèn LED, dây dẫn, đế. Bước 2: lắp cánh quạt vào trục máy phát. Bước 3: nối dây từ máy phát tới đèn LED. Bước 4: lắp máy phát lên cột và đế. Bước 5: tạo gió (dùng quạt hoặc thổi) để cánh quạt quay, quan sát đèn sáng; kiểm tra, điều chỉnh nếu đèn không sáng.'],
  [3,'Nêu ba lưu ý an toàn khi thực hành lắp ráp mô hình điện dùng pin.','Ba lưu ý: chỉ dùng pin đúng loại, không dùng điện lưới gia đình; không nối trực tiếp hai cực của pin bằng dây dẫn vì gây nóng, hỏng pin; tháo pin khi không dùng, không vứt pin cũ lung tung mà bỏ vào nơi thu gom riêng.'],
  [4,'So sánh nguồn năng lượng của mô hình xe điện chạy pin với mô hình điện mặt trời và mô hình máy phát điện gió. Theo em, nguồn nào thân thiện với môi trường hơn và vì sao?','Xe điện chạy pin dùng năng lượng dự trữ trong pin; pin hết phải thay hoặc nạp, pin thải gây ô nhiễm. Mô hình điện mặt trời và điện gió dùng ánh sáng và gió là năng lượng có sẵn trong tự nhiên, không bao giờ cạn và không tạo ra khí thải khi hoạt động. Vì vậy năng lượng mặt trời và gió thân thiện với môi trường hơn, tuy nhiên chúng phụ thuộc thời tiết nên thường cần kết hợp với bộ lưu điện.']
 ]);
 /* ===== CÔNG NGHỆ 6–9 (Bổ sung) ===== */
 add(M,6,'(Bổ sung) Nhà ở và thực phẩm',[
  [1,'Nhà ở có vai trò gì đối với con người?','Bảo vệ con người trước tác động của thiên nhiên và là nơi sinh hoạt của gia đình','Chỉ để trưng bày đồ đạc','Chỉ dùng để nấu ăn','Không có vai trò quan trọng'],
  [1,'Kiểu nhà nào phổ biến ở vùng sông nước, có sàn cao để tránh lũ và thú dữ?','Nhà sàn','Nhà chung cư','Nhà biệt thự','Nhà liền kề'],
  [2,'Ngôi nhà thông minh có đặc điểm gì?','Các thiết bị được điều khiển tự động hoặc từ xa, tiết kiệm năng lượng, an toàn, tiện nghi','Chỉ có nhiều tầng','Chỉ sử dụng gạch cao cấp','Không dùng điện'],
  [2,'Phương pháp bảo quản thực phẩm nào sử dụng nhiệt độ thấp dưới 0 độ C?','Đông lạnh','Phơi khô','Ướp muối','Hun khói'],
  [2,'Món ăn nào được chế biến bằng phương pháp không sử dụng nhiệt?','Rau trộn (nộm)','Rau luộc','Cá kho','Thịt nướng'],
  [1,'Nhóm thực phẩm nào cung cấp chủ yếu chất bột đường?','Cơm, bánh mì, khoai','Thịt, cá, trứng','Rau xanh','Dầu, mỡ'],
  [2,'Trang phục đi học của học sinh nên có đặc điểm gì?','Gọn gàng, lịch sự, thoải mái, phù hợp quy định của trường','Thật nhiều màu sắc rực rỡ','Rộng thùng thình và kéo lê','Đắt tiền để nổi bật'],
  [3,'Nêu các nhóm thực phẩm chính và ý nghĩa của việc ăn uống đủ các nhóm.','Các nhóm chính: nhóm giàu chất bột đường (gạo, ngô, khoai); nhóm giàu chất đạm (thịt, cá, trứng, đậu); nhóm giàu chất béo (dầu, mỡ, lạc); nhóm giàu vitamin và chất khoáng (rau, củ, quả). Ăn đủ, cân đối các nhóm giúp cơ thể phát triển khỏe mạnh, có năng lượng hoạt động và phòng tránh bệnh tật.'],
  [3,'Nêu ba biện pháp sử dụng năng lượng tiết kiệm, hiệu quả trong gia đình.','Ba biện pháp: tắt các thiết bị điện khi không sử dụng, rút phích cắm; tận dụng ánh sáng và gió tự nhiên, dùng đèn LED tiết kiệm điện; sử dụng thiết bị có nhãn tiết kiệm năng lượng và dùng hợp lí (không mở tủ lạnh lâu, giặt đủ khối lượng).'],
  [4,'Vì sao thực phẩm cần được bảo quản đúng cách? Hãy phân tích và chọn phương pháp bảo quản phù hợp cho cá tươi, rau xanh và gạo.','Thực phẩm để lâu bị vi sinh vật phân hủy, mất chất dinh dưỡng, gây hỏng và có thể gây ngộ độc; bảo quản đúng giúp giữ chất lượng, kéo dài thời gian sử dụng và tránh lãng phí. Cá tươi: làm sạch, bảo quản lạnh ở ngăn mát nếu dùng ngay hoặc đông lạnh nếu để lâu, có thể ướp muối, làm khô. Rau xanh: rửa sạch, để ráo, bọc kín cho vào ngăn mát, dùng trong vài ngày. Gạo: bảo quản ở nơi khô ráo, thoáng, đựng trong thùng kín tránh ẩm mốc, mối mọt.']
 ]);
 add(M,7,'(Bổ sung) Trồng trọt, chăn nuôi',[
  [1,'Phương thức trồng trọt nào giúp cây tránh được tác động xấu của thời tiết và sâu bệnh?','Trồng trọt trong nhà có mái che','Trồng trọt ngoài trời','Trồng xen canh ngoài ruộng','Trồng trên nương rẫy'],
  [1,'Trong quy trình trồng trọt, công việc "tưới nước, bón phân, làm cỏ, vun xới" thuộc giai đoạn nào?','Chăm sóc','Làm đất','Gieo trồng','Thu hoạch'],
  [2,'Biện pháp nào sau đây là biện pháp sinh học trong phòng trừ sâu bệnh?','Sử dụng thiên địch như ong mắt đỏ, bọ rùa','Phun thuốc hóa học','Bắt sâu bằng tay','Dùng bẫy đèn'],
  [2,'Rừng có vai trò gì đối với môi trường?','Điều hòa khí hậu, chống xói mòn, giữ nước, là nơi sống của sinh vật','Chỉ cung cấp gỗ','Làm tăng lũ lụt','Không có vai trò'],
  [2,'Vật nuôi nào sau đây là giống vật nuôi bản địa của Việt Nam?','Gà Đông Tảo','Bò sữa Hà Lan','Gà công nghiệp','Lợn Landrace'],
  [1,'Trong chăn nuôi, việc tiêm vắc xin cho vật nuôi nhằm mục đích gì?','Phòng bệnh cho vật nuôi','Làm vật nuôi lớn nhanh hơn','Làm thức ăn cho vật nuôi','Trang trí chuồng trại'],
  [2,'Khi nuôi cá trong ao, yếu tố nào của nước cần được quan tâm?','Nhiệt độ, độ trong, lượng oxy hòa tan','Màu sắc của bờ ao','Số cây trên bờ','Hình dạng của ao'],
  [3,'Nêu các bước trong quy trình trồng trọt và cho ví dụ với việc trồng rau cải tại nhà.','Quy trình: làm đất, bón phân lót → gieo trồng → chăm sóc (tưới nước, tỉa dặm, làm cỏ, bón thúc, phòng trừ sâu bệnh) → thu hoạch. Ví dụ trồng rau cải: xới đất tơi, trộn phân hữu cơ vào khay; gieo hạt, phủ lớp đất mỏng, tưới ẩm; hằng ngày tưới nước, tỉa cây dày, nhặt sâu; sau khoảng 25–30 ngày thu hoạch.'],
  [3,'Nêu các công việc chính trong nuôi dưỡng và chăm sóc vật nuôi non.','Giữ ấm cho vật nuôi non, chuồng khô ráo, sạch sẽ; cho ăn đủ chất, phù hợp lứa tuổi (bú sữa mẹ đầy đủ với gia súc non); cho vận động, tắm nắng hợp lí; tiêm phòng vắc xin, theo dõi sức khỏe, cách li và điều trị kịp thời khi bị bệnh.'],
  [4,'Vì sao cần hạn chế thuốc hóa học và ưu tiên biện pháp phòng trừ tổng hợp trong trồng trọt? Phân tích lợi ích đối với sản phẩm, môi trường và con người.','Thuốc hóa học diệt sâu nhanh nhưng để lại dư lượng trên nông sản gây hại sức khỏe người tiêu dùng, diệt cả thiên địch, gây ô nhiễm đất, nước và làm sâu bệnh kháng thuốc. Phòng trừ tổng hợp kết hợp canh tác hợp lí, giống kháng bệnh, biện pháp thủ công, sinh học và chỉ dùng hóa học khi cần, nên nông sản an toàn hơn, bảo vệ môi trường và cân bằng sinh thái, giảm chi phí lâu dài cho người nông dân.']
 ]);
 add(M,8,'(Bổ sung) Cơ khí và an toàn điện',[
  [1,'Gang và thép thuộc nhóm vật liệu nào?','Kim loại đen','Kim loại màu','Chất dẻo','Cao su'],
  [1,'Đồng và nhôm thuộc nhóm vật liệu nào?','Kim loại màu','Kim loại đen','Phi kim loại','Gốm'],
  [2,'Dụng cụ nào dùng để cắt kim loại bằng tay trong gia công cơ khí?','Cưa tay','Búa','Dũa','Thước lá'],
  [2,'Cơ cấu truyền động nào dùng xích để truyền chuyển động giữa hai đĩa như ở xe đạp?','Truyền động xích','Truyền động đai','Truyền động bánh răng','Cơ cấu tay quay – con trượt'],
  [2,'Nguyên nhân nào thường gây tai nạn điện trong gia đình?','Chạm vào dây điện hở, dùng thiết bị điện khi tay ướt','Tắt điện khi ra khỏi phòng','Dùng ổ cắm có nắp che','Kiểm tra dây điện định kì'],
  [1,'Dụng cụ nào dùng để kiểm tra một vật có mang điện hay không?','Bút thử điện','Thước đo','Tua vít thường','Kìm cắt'],
  [2,'Khi phát hiện người bị điện giật, việc đầu tiên cần làm là gì?','Ngắt nguồn điện hoặc dùng vật khô cách điện tách nạn nhân ra khỏi nguồn điện','Dùng tay kéo nạn nhân ra ngay','Đổ nước lên người nạn nhân','Chờ nạn nhân tự thoát ra'],
  [3,'Nêu các biện pháp an toàn khi sử dụng đồ dùng điện trong gia đình.','Kiểm tra dây dẫn, phích cắm trước khi dùng, không dùng thiết bị hở dây; không chạm vào thiết bị điện khi tay ướt, chân trần ở nơi ẩm; rút phích cắm khi không dùng và khi sửa chữa; dùng thiết bị có nối đất, cầu dao chống rò; để ổ cắm xa tầm tay trẻ nhỏ.'],
  [3,'Kể tên ba vật liệu cơ khí thường gặp và nêu ứng dụng của mỗi loại.','Thép: làm khung nhà, dụng cụ, chi tiết máy vì cứng và bền. Nhôm: làm khung cửa, vỏ máy, dụng cụ nhà bếp vì nhẹ, chống ăn mòn. Chất dẻo (nhựa): làm vỏ thiết bị điện, ống nước, đồ dùng vì nhẹ, cách điện, dễ tạo hình.'],
  [4,'Vì sao các bộ phận chịu lực, dẫn điện và cách điện của một thiết bị lại được chế tạo từ những vật liệu khác nhau? Phân tích với ví dụ chiếc kìm điện.','Mỗi vật liệu có tính chất riêng và được chọn theo chức năng của bộ phận. Ở kìm điện: hai má kìm và thân làm bằng thép vì cần cứng, chịu lực để cắt, kẹp; tay cầm bọc bằng chất dẻo hoặc cao su vì cần cách điện, êm tay để bảo vệ người dùng khỏi điện giật. Nếu dùng chung một vật liệu, kìm sẽ hoặc không đủ cứng, hoặc không an toàn. Việc chọn vật liệu đúng tính chất giúp sản phẩm bền, an toàn và tiết kiệm.']
 ]);
 add(M,9,'(Bổ sung) Nghề nghiệp và chế biến',[
  [1,'Nghề nghiệp là gì?','Công việc mà con người thực hiện lâu dài, tạo ra giá trị và thu nhập, phù hợp năng lực của bản thân','Việc làm trong một ngày','Sở thích lúc rảnh rỗi','Môn học yêu thích'],
  [1,'Sau khi tốt nghiệp trung học cơ sở, học sinh có thể lựa chọn hướng nào?','Học tiếp trung học phổ thông hoặc học nghề ở cơ sở giáo dục nghề nghiệp','Chỉ được học tiếp trung học phổ thông','Chỉ được đi làm ngay','Không có lựa chọn nào khác'],
  [2,'Khi chọn nghề, yếu tố nào cần được xem xét?','Sở thích, năng lực bản thân, điều kiện gia đình và nhu cầu của thị trường lao động','Chỉ theo ý bạn bè','Chỉ chọn nghề có thu nhập cao nhất','Chọn ngẫu nhiên'],
  [2,'Thị trường lao động là gì?','Nơi diễn ra sự trao đổi giữa người cần việc và người sử dụng lao động về việc làm, tiền công','Nơi bán các dụng cụ lao động','Một chợ nông sản','Một trung tâm mua sắm'],
  [2,'Phương pháp chế biến thực phẩm nào làm chín bằng hơi nước?','Hấp','Chiên (rán)','Nướng','Trộn'],
  [1,'Khi chế biến thực phẩm, việc nào giúp đảm bảo an toàn vệ sinh?','Rửa tay sạch, dùng dụng cụ riêng cho thực phẩm sống và chín','Để thực phẩm chín cạnh thực phẩm sống','Dùng chung một dao thớt cho mọi loại','Nấu xong để ngoài nhiều giờ'],
  [2,'Yêu cầu nào quan trọng đối với người làm nghề chế biến thực phẩm?','Sức khỏe tốt, cẩn thận, tuân thủ vệ sinh an toàn thực phẩm','Chỉ cần ăn ngon','Chỉ cần nói hay','Không cần kiến thức về dinh dưỡng'],
  [3,'Trình bày các bước cơ bản để lựa chọn nghề nghiệp phù hợp với bản thân.','Bước 1: tự đánh giá sở thích, năng lực, tính cách, sức khỏe của bản thân. Bước 2: tìm hiểu các nghề (công việc, yêu cầu, điều kiện làm việc, nhu cầu lao động). Bước 3: đối chiếu đặc điểm bản thân với yêu cầu của nghề, cân nhắc điều kiện gia đình. Bước 4: lựa chọn nghề và lập kế hoạch học tập, rèn luyện để đạt mục tiêu.'],
  [3,'Nêu quy trình chung để chế biến một món ăn và ví dụ với món rau xào.','Quy trình: lựa chọn thực phẩm → sơ chế (rửa, cắt, thái) → chế biến (nấu chín) → trình bày món ăn. Ví dụ rau xào: chọn rau tươi; nhặt, rửa sạch, cắt khúc, băm tỏi; phi tỏi với dầu, cho rau vào xào lửa lớn, nêm gia vị vừa ăn; bày ra đĩa, trang trí.'],
  [4,'Vì sao khi chọn nghề không nên chỉ dựa vào thu nhập hoặc theo bạn bè? Phân tích và nêu cách chọn nghề hợp lí.','Thu nhập chỉ là một yếu tố; nếu nghề không phù hợp với năng lực và sở thích thì khó làm tốt, dễ chán nản, bỏ việc, lãng phí thời gian học tập. Chọn theo bạn bè là bỏ qua đặc điểm riêng của bản thân, mỗi người có thế mạnh khác nhau. Cách hợp lí là kết hợp ba yếu tố: bản thân thích và có khả năng, nghề đó có nhu cầu trong xã hội và điều kiện gia đình có thể theo học; từ đó lập kế hoạch rèn luyện phù hợp.']
 ]);
 /* ===== GIÁO DỤC CÔNG DÂN 6–9 (Bổ sung) ===== */
 M='Giáo dục công dân';
 add(M,6,'(Bổ sung) Đạo đức và pháp luật',[
  [1,'Siêng năng, kiên trì được hiểu là gì?','Cần cù, tự giác, miệt mài làm việc và quyết tâm vượt khó đến cùng','Làm việc khi có người nhắc nhở','Chỉ làm những việc dễ','Bỏ dở khi gặp khó khăn'],
  [1,'Tôn trọng sự thật là gì?','Công nhận cái có thật, nói và làm theo đúng sự thật','Nói những điều người khác muốn nghe','Che giấu lỗi của bạn','Im lặng trước mọi việc'],
  [2,'Biểu hiện nào sau đây thể hiện tính tự lập?','Tự giác làm bài tập và chuẩn bị đồ dùng học tập','Luôn nhờ bố mẹ làm bài tập','Chờ người khác nhắc mới làm việc','Dựa dẫm vào bạn trong giờ kiểm tra'],
  [2,'Khi gặp tình huống nguy hiểm như hỏa hoạn, em cần làm gì?','Giữ bình tĩnh, thoát ra theo lối an toàn, gọi 114 và báo người lớn','Trốn vào nhà vệ sinh và đóng cửa','Quay lại lấy đồ đạc','Chạy vào thang máy'],
  [2,'Hành vi nào sau đây thể hiện tính tiết kiệm?','Tắt điện, khóa nước khi không sử dụng','Mua nhiều đồ không cần thiết','Bỏ thừa thức ăn','Xé vở còn dùng được để gấp đồ chơi'],
  [1,'Công dân nước Cộng hòa xã hội chủ nghĩa Việt Nam là người như thế nào?','Người có quốc tịch Việt Nam','Người sinh sống ở Việt Nam dưới một năm','Người nước ngoài đến du lịch','Người chỉ nói tiếng Việt'],
  [2,'Nhóm quyền nào của trẻ em bao gồm quyền được học tập, vui chơi, giải trí?','Nhóm quyền phát triển','Nhóm quyền sống còn','Nhóm quyền bảo vệ','Nhóm quyền tham gia'],
  [3,'Nêu ý nghĩa của việc tự nhận thức bản thân và hai cách để tự nhận thức bản thân.','Tự nhận thức bản thân giúp em hiểu rõ điểm mạnh, điểm yếu, sở thích, giá trị của mình để phát huy ưu điểm, khắc phục hạn chế và đặt mục tiêu phù hợp. Hai cách: tự đánh giá qua kết quả học tập, hành vi, cảm xúc của mình; lắng nghe nhận xét của người thân, bạn bè, thầy cô và so sánh với bản thân.'],
  [3,'Kể bốn nhóm quyền cơ bản của trẻ em và nêu một việc em làm để thực hiện tốt quyền của mình.','Bốn nhóm quyền: quyền sống còn, quyền bảo vệ, quyền phát triển, quyền tham gia. Việc em làm: chăm chỉ học tập, tham gia hoạt động của lớp, mạnh dạn nêu ý kiến, đồng thời tôn trọng quyền của các bạn khác và biết tự bảo vệ bản thân trước nguy hiểm.'],
  [4,'Vì sao tôn trọng sự thật lại cần thiết cho cả cá nhân và xã hội? Khi nói thật có thể làm người khác buồn, em sẽ làm thế nào?','Với cá nhân, tôn trọng sự thật giúp người đó được tin tưởng, có lòng tự trọng và sửa được sai lầm. Với xã hội, sự thật là nền tảng của công bằng, pháp luật và các mối quan hệ lành mạnh; dối trá làm mất lòng tin, gây hậu quả xấu. Khi sự thật có thể làm người khác buồn, em vẫn nói thật nhưng chọn thời điểm phù hợp, lời nói nhẹ nhàng, chân thành và góp ý mang tính xây dựng để người đó hiểu và tốt hơn.']
 ]);
 add(M,7,'(Bổ sung) Kĩ năng và giá trị',[
  [1,'Quan tâm, cảm thông, chia sẻ được biểu hiện qua hành vi nào?','Lắng nghe, động viên, giúp đỡ người gặp khó khăn','Chỉ quan tâm đến bản thân','Chế giễu người gặp hoạn nạn','Thờ ơ với nỗi buồn của bạn'],
  [1,'Học tập tự giác, tích cực là gì?','Chủ động, cố gắng thực hiện tốt nhiệm vụ học tập mà không cần ai nhắc nhở','Học khi bị ép buộc','Chỉ học môn mình thích','Chép bài của bạn cho nhanh'],
  [2,'Biểu hiện nào của tâm lí căng thẳng?','Mất ngủ, lo lắng, khó tập trung, dễ cáu gắt','Vui vẻ, ngủ ngon','Tập trung tốt','Thích giao tiếp với mọi người'],
  [2,'Hành vi nào sau đây là bạo lực học đường?','Đánh, đe dọa, cô lập hoặc lan truyền thông tin xấu về bạn','Góp ý nhẹ nhàng khi bạn mắc lỗi','Từ chối cho bạn chép bài','Tranh luận lịch sự trong giờ học'],
  [2,'Quản lí tiền hiệu quả bao gồm việc gì?','Lập kế hoạch chi tiêu, tiết kiệm và chi tiêu đúng mức cần thiết','Tiêu hết tiền ngay khi có','Vay mượn để mua đồ không cần thiết','Không ghi chép khoản thu chi'],
  [1,'Hành vi nào sau đây là tệ nạn xã hội?','Đánh bạc, sử dụng ma túy','Chơi thể thao','Tham gia câu lạc bộ đọc sách','Làm việc nhà giúp bố mẹ'],
  [2,'Di sản văn hóa phi vật thể là gì?','Sản phẩm tinh thần như lễ hội, nghệ thuật trình diễn, tiếng nói, chữ viết, tri thức dân gian','Các công trình kiến trúc cổ','Các di vật, cổ vật trong bảo tàng','Các danh lam thắng cảnh'],
  [3,'Nêu ba cách ứng phó tích cực khi gặp tâm lí căng thẳng trong học tập.','Ba cách: sắp xếp thời gian học hợp lí, chia nhỏ nhiệm vụ để làm dần; tập thể dục, thư giãn, nghỉ ngơi, ngủ đủ giấc; chia sẻ với bố mẹ, thầy cô, bạn bè để nhận được lời khuyên và sự hỗ trợ.'],
  [3,'Em chứng kiến một bạn bị nhóm bạn khác đe dọa, bắt nạt. Em sẽ làm gì? Giải thích ngắn gọn.','Không tham gia, không cổ vũ hay quay phim lan truyền; tìm cách giúp bạn tách khỏi tình huống nếu an toàn; báo ngay cho thầy cô, bảo vệ hoặc người lớn; động viên, ở bên cạnh bạn bị bắt nạt. Làm vậy để ngăn bạo lực học đường, bảo vệ bạn và giữ môi trường học tập an toàn.'],
  [4,'Vì sao giữ chữ tín lại quan trọng trong các mối quan hệ? Phân tích hậu quả của việc thất hứa qua một tình huống thực tế.','Giữ chữ tín tạo nên sự tin tưởng, tôn trọng giữa người với người; người giữ chữ tín được quý mến, dễ hợp tác và thành công. Ví dụ, một bạn hứa mang tài liệu cho nhóm làm bài thuyết trình nhưng nhiều lần quên: cả nhóm bị chậm tiến độ, điểm thấp, các bạn không còn muốn giao việc cho bạn ấy. Thất hứa dù nhỏ cũng làm mất lòng tin, mà lòng tin rất khó lấy lại; vì vậy chỉ hứa điều có thể làm và cố gắng thực hiện đúng lời hứa.']
 ]);
 add(M,8,'(Bổ sung) Lối sống và pháp luật',[
  [1,'Lao động cần cù, sáng tạo là gì?','Chăm chỉ, chịu khó làm việc và luôn tìm cách cải tiến để làm việc hiệu quả hơn','Làm việc khi được giao, không cần suy nghĩ','Chỉ làm theo cách cũ','Làm việc để được khen'],
  [1,'Bảo vệ lẽ phải là gì?','Công nhận, ủng hộ, làm theo điều đúng và lên tiếng trước điều sai','Im lặng trước việc sai để tránh rắc rối','Làm theo số đông dù sai','Chỉ bảo vệ người quen'],
  [2,'Hành vi nào góp phần bảo vệ môi trường và tài nguyên thiên nhiên?','Phân loại rác, tiết kiệm nước, trồng cây xanh','Xả rác ra sông suối','Đốt rác nhựa ngoài trời','Săn bắt động vật hoang dã'],
  [2,'Mục tiêu cá nhân cần có đặc điểm gì để dễ thực hiện?','Cụ thể, đo lường được, khả thi, có thời hạn và phù hợp với bản thân','Càng chung chung càng tốt','Thật xa vời để cố gắng','Không cần thời hạn'],
  [2,'Hành vi nào sau đây là bạo lực gia đình?','Đánh đập, lăng mạ, xúc phạm, cô lập thành viên trong gia đình','Góp ý với con khi con mắc lỗi','Phân công việc nhà cho các thành viên','Quan tâm hỏi thăm sức khỏe người thân'],
  [1,'Khi phát hiện vật nghi là bom, mìn, vật liệu nổ, em cần làm gì?','Không chạm vào, giữ khoảng cách an toàn và báo ngay cho người lớn hoặc cơ quan chức năng','Mang về nhà cất giữ','Dùng đá đập để kiểm tra','Rủ bạn đến xem'],
  [2,'Theo pháp luật Việt Nam, lao động là quyền và nghĩa vụ của ai?','Của mọi công dân','Chỉ của người lớn tuổi','Chỉ của nam giới','Chỉ của người có bằng đại học'],
  [3,'Nêu các bước lập kế hoạch chi tiêu cá nhân và một ví dụ về khoản chi em có thể cắt giảm.','Bước 1: xác định mục tiêu và các khoản thu. Bước 2: liệt kê các khoản chi, phân loại thiết yếu và không thiết yếu. Bước 3: phân bổ tiền cho từng khoản, dành một phần tiết kiệm. Bước 4: thực hiện, ghi chép và điều chỉnh. Ví dụ khoản có thể cắt giảm: tiền mua đồ ăn vặt, đồ chơi không cần thiết.'],
  [3,'Tôn trọng sự đa dạng của các dân tộc có ý nghĩa gì? Nêu hai việc em có thể làm để thể hiện điều đó.','Ý nghĩa: giúp các dân tộc hiểu nhau, học hỏi lẫn nhau, chung sống hòa bình, cùng phát triển và chống phân biệt đối xử. Hai việc: tìm hiểu, tôn trọng phong tục, ngôn ngữ, trang phục của các dân tộc; không chế giễu, kì thị bạn bè có văn hóa khác và sẵn sàng kết bạn, giúp đỡ nhau.'],
  [4,'Vì sao nói bảo vệ môi trường và tài nguyên thiên nhiên là trách nhiệm của mỗi công dân chứ không chỉ của Nhà nước? Phân tích và nêu hành động cụ thể của học sinh.','Môi trường là điều kiện sống chung của tất cả mọi người; ô nhiễm, cạn kiệt tài nguyên ảnh hưởng trực tiếp đến sức khỏe và tương lai của mỗi người. Nhà nước ban hành luật, quản lí, nhưng hiệu quả phụ thuộc vào hành vi hằng ngày của từng người dân: một người xả rác, lãng phí thì luật khó phát huy tác dụng. Học sinh có thể: phân loại và bỏ rác đúng nơi, tiết kiệm điện nước, hạn chế đồ nhựa dùng một lần, trồng và chăm sóc cây, tuyên truyền cho gia đình và bạn bè, lên tiếng khi thấy hành vi phá hoại môi trường.']
 ]);
 add(M,9,'(Bổ sung) Công dân và xã hội',[
  [1,'Khoan dung là gì?','Rộng lòng tha thứ, tôn trọng và thông cảm với người khác, biết tha thứ khi họ hối hận và sửa chữa lỗi lầm','Bỏ qua mọi hành vi sai trái mà không nhắc nhở','Luôn nhường nhịn kể cả khi bị xâm hại','Chỉ tha thứ cho người thân'],
  [1,'Khách quan, công bằng được hiểu là gì?','Nhìn nhận sự việc đúng bản chất, không thiên vị, đối xử bình đẳng','Đánh giá theo cảm tính cá nhân','Ưu tiên người quen','Bênh vực số đông'],
  [2,'Việc nào thể hiện bảo vệ hòa bình?','Giải quyết mâu thuẫn bằng đối thoại, tôn trọng sự khác biệt','Dùng vũ lực để giải quyết tranh chấp','Kích động thù hằn dân tộc','Thờ ơ với xung đột quanh mình'],
  [2,'Quản lí thời gian hiệu quả giúp em điều gì?','Hoàn thành công việc đúng hạn, giảm căng thẳng và có thời gian cho việc khác','Có nhiều thời gian chơi điện tử hơn','Không cần lập kế hoạch','Làm việc tùy hứng'],
  [2,'Vi phạm pháp luật là gì?','Hành vi trái pháp luật, có lỗi, do người có năng lực trách nhiệm pháp lí thực hiện, xâm hại quan hệ xã hội được pháp luật bảo vệ','Mọi hành vi mà người khác không thích','Chỉ những hành vi gây chết người','Hành vi vi phạm nội quy lớp học'],
  [1,'Nộp thuế là gì đối với công dân?','Nghĩa vụ của công dân và tổ chức theo quy định của pháp luật','Việc tự nguyện, muốn nộp hay không tùy ý','Chỉ bắt buộc với người nước ngoài','Hình thức phạt'],
  [2,'Khi môi trường học tập, cuộc sống thay đổi (chuyển trường, chuyển chỗ ở), cách thích ứng tích cực là gì?','Chủ động tìm hiểu, làm quen, điều chỉnh thói quen và tìm sự hỗ trợ khi cần','Thu mình, không giao tiếp','Chống đối mọi thay đổi','Chờ mọi người phải thay đổi theo mình'],
  [3,'Nêu các loại vi phạm pháp luật và trách nhiệm pháp lí tương ứng.','Vi phạm hình sự (tội phạm) – trách nhiệm hình sự; vi phạm hành chính – trách nhiệm hành chính; vi phạm dân sự – trách nhiệm dân sự; vi phạm kỉ luật – trách nhiệm kỉ luật. Mỗi loại do pháp luật quy định và được áp dụng tùy mức độ, tính chất của hành vi vi phạm.'],
  [3,'Nêu các biểu hiện của người tiêu dùng thông minh và lấy ví dụ khi em mua một chiếc cặp sách.','Biểu hiện: xác định nhu cầu thật sự, lập kế hoạch chi tiêu, tìm hiểu thông tin sản phẩm, so sánh giá và chất lượng, chọn sản phẩm an toàn, có nguồn gốc rõ ràng, không mua theo quảng cáo hay số đông. Ví dụ mua cặp: xác định cần cặp vừa sức, bền; xem chất liệu, đường may, giá ở vài cửa hàng; chọn chiếc phù hợp túi tiền thay vì chiếc đắt nhất hay đang được quảng cáo.'],
  [4,'Vì sao sống có lí tưởng lại quan trọng với thanh niên và sự phát triển của đất nước? Phân tích và nêu cách em xác định lí tưởng sống của mình.','Lí tưởng sống là mục đích cao đẹp định hướng suy nghĩ, hành động, tạo động lực vượt khó và cống hiến. Thanh niên có lí tưởng sẽ học tập, rèn luyện nghiêm túc, sống có trách nhiệm, góp phần xây dựng đất nước giàu mạnh; thiếu lí tưởng dễ sống buông thả, lãng phí tuổi trẻ. Em xác định lí tưởng bằng cách hiểu rõ năng lực, sở thích của bản thân; học tập tấm gương những người có đóng góp cho xã hội; đặt mục tiêu cụ thể cho học tập, nghề nghiệp gắn với lợi ích cộng đồng và kiên trì thực hiện.']
 ]);
})();
