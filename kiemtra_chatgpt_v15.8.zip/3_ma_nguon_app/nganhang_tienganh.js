/* ============================================================
   NGÂN HÀNG TIẾNG ANH (THCS 6–9) — bổ sung cho đủ chuẩn
   Mỗi mục: ≥6 trắc nghiệm + ≥4 tự luận + có câu nâng cao (mức 4).
   Câu hỏi nguyên bản (từ vựng, ngữ pháp, phát âm) theo chương trình
   Tiếng Anh THCS. Không trích văn bản có bản quyền.
   TN [mức,'câu','ĐÚNG','sai','sai','sai'] · TL [mức,'câu','đáp án']
   ============================================================ */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Tiếng Anh';

 /* ===================== LỚP 6 ===================== */
 add(M,6,'Vocabulary — School, House, Friends',[
  [1,'Choose the odd one out.','kitchen','pen','pencil','ruler'],
  [1,'"Phòng để nấu ăn" in English is ___.','kitchen','bedroom','bathroom','garden'],
  [2,'Choose the correct word: My father and mother are my ___.','parents','friends','teachers','students'],
  [2,'Đồ dùng nào KHÔNG dùng để viết?','rubber','pen','pencil','marker'],
  [2,'Viết 4 từ chỉ đồ dùng học tập bằng tiếng Anh.','VD: pen, pencil, ruler, book, rubber/eraser, school bag, notebook.'],
  [3,'Đặt một câu tiếng Anh giới thiệu về trường của em (dùng "My school ...").','VD: "My school is big and beautiful." (câu đúng, có be/adjective).'],
  [3,'Dịch sang tiếng Anh: "Tôi có hai người bạn thân."','"I have two close friends."'],
  [4,'Write one sentence describing a room in your house, using "There is / There are".','VD: "There is a big table in the living room." (câu đúng ngữ pháp).']
 ]);
 add(M,6,'Grammar — Present simple, This/That/These/Those',[
  [1,'Choose the correct form: She ___ to school every day.','goes','go','going','gone'],
  [1,'Choose: ___ is my book. (vật ở gần, số ít)','This','Those','These','Them'],
  [2,'Choose: They ___ my friends.','are','is','am','be'],
  [2,'Complete: ___ are my pens. (nhiều, ở gần)','These','This','That','It'],
  [3,'Chia động từ: He (play) ___ football every afternoon.','plays'],
  [3,'Viết câu phủ định của: "I like coffee."','"I do not (don’t) like coffee."'],
  [3,'Đổi sang câu hỏi: "She gets up early."','"Does she get up early?"'],
  [4,'Find and correct the mistake: "My brother don’t like fish."','Sửa "don’t" thành "doesn’t": "My brother doesn’t like fish." (chủ ngữ số ít ngôi 3 dùng doesn’t).']
 ]);
 add(M,6,'Pronunciation',[
  [1,'Choose the word with a different final sound: books, maps, pens, cats.','pens','books','maps','cats'],
  [2,'Which word has the /ɪz/ sound for the ending -es?','watches','books','pens','maps'],
  [2,'Choose the word with two syllables.','teacher','pen','book','desk'],
  [2,'How many syllables are there in "banana"?','Three','One','Two','Four'],
  [4,'Which word has a different stress pattern: teacher, pencil, hello, table?','hello','teacher','pencil','table'],
  [2,'Nêu 3 cách phát âm đuôi -s/-es của danh từ số nhiều, mỗi cách một ví dụ.','/s/ (books), /z/ (pens), /ɪz/ (watches/boxes).'],
  [2,'Đuôi -es trong từ "watches" được phát âm là gì?','/ɪz/.'],
  [3,'Xếp các từ vào nhóm phát âm đuôi -s: cats, dogs, boxes.','cats: /s/; dogs: /z/; boxes: /ɪz/.'],
  [3,'Viết một câu có danh từ số nhiều và cho biết đuôi -s phát âm thế nào.','VD: "I have two books." – books: /s/.']
 ]);

 /* ===================== LỚP 7 ===================== */
 add(M,7,'Vocabulary — Hobbies, Health, Community',[
  [1,'Choose the odd one out.','hospital','reading','cooking','fishing'],
  [1,'"Sở thích" in English is ___.','hobby','health','homework','holiday'],
  [2,'Choose the correct word: You should eat more fruit and vegetables to stay ___.','healthy','lazy','tired','sick'],
  [2,'Which is a community activity?','collecting rubbish on the beach','watching TV at home','sleeping','eating lunch'],
  [2,'Viết 4 sở thích (hobbies) bằng tiếng Anh.','VD: reading, cooking, fishing, swimming, cycling, playing football.'],
  [3,'Đặt một câu tiếng Anh nói về sở thích của em (dùng "I like + V-ing").','VD: "I like reading books." (đúng ngữ pháp).'],
  [3,'Dịch sang tiếng Anh: "Em nên tập thể dục mỗi ngày."','"You should do exercise every day."'],
  [4,'Write one sentence about a volunteer activity you can do in your community.','VD: "I can help old people in my neighbourhood." (câu đúng, phù hợp nghĩa).']
 ]);
 add(M,7,'Grammar — Past simple, Comparatives',[
  [1,'Choose the past form of "go".','went','goed','gone','going'],
  [1,'Choose: Yesterday, I ___ to the zoo.','went','go','goes','going'],
  [2,'Choose the comparative: This book is ___ than that one.','more interesting','interestinger','most interesting','interesting'],
  [2,'Complete: An elephant is ___ than a dog.','bigger','big','biggest','more big'],
  [3,'Chia động từ (quá khứ): She (visit) ___ her grandmother last week.','visited'],
  [3,'Viết câu phủ định (quá khứ): "They played football."','"They did not (didn’t) play football."'],
  [3,'Viết dạng so sánh hơn của tính từ: "good" → ___ ; "happy" → ___.','better; happier.'],
  [4,'Find and correct the mistake: "He is more tall than his brother."','Sửa "more tall" thành "taller": "He is taller than his brother." (tính từ ngắn thêm -er, không dùng more).']
 ]);
 add(M,7,'Pronunciation',[
  [1,'Choose the word with a different sound of the ending -ed: worked, played, watched, stopped.','played','worked','watched','stopped'],
  [2,'Which word has the /ɪd/ sound for the ending -ed?','wanted','played','opened','lived'],
  [2,'Choose the word with the stress on the first syllable.','happy','relax','hotel','enjoy'],
  [2,'How many syllables are there in "beautiful"?','Three','One','Two','Five'],
  [4,'Which word has a different stress pattern: begin, enjoy, hobby, prepare?','hobby','begin','enjoy','prepare'],
  [2,'Nêu 3 cách phát âm đuôi -ed của động từ quá khứ, mỗi cách một ví dụ.','/t/ (worked), /d/ (played), /ɪd/ (wanted).'],
  [2,'Đuôi -ed trong từ "needed" được phát âm là gì?','/ɪd/.'],
  [3,'Xếp các từ vào nhóm phát âm đuôi -ed: looked, lived, visited.','looked: /t/; lived: /d/; visited: /ɪd/.'],
  [3,'Viết một câu ở quá khứ và cho biết đuôi -ed phát âm thế nào.','VD: "I watched a film." – watched: /t/.']
 ]);

 /* ===================== LỚP 8 ===================== */
 add(M,8,'Vocabulary — Leisure, Customs, Environment',[
  [1,'Choose the odd one out.','pollution','reading','cycling','gardening'],
  [1,'"Ô nhiễm" in English is ___.','pollution','tradition','leisure','custom'],
  [2,'Choose the correct word: We should use public transport to reduce air ___.','pollution','tradition','festival','hobby'],
  [2,'Which is a leisure activity?','playing the guitar','doing homework','taking an exam','cleaning pollution'],
  [2,'Viết 4 hoạt động giải trí (leisure activities) bằng tiếng Anh.','VD: reading, cycling, gardening, playing music, watching films.'],
  [3,'Đặt một câu tiếng Anh về việc bảo vệ môi trường (dùng "We should ...").','VD: "We should recycle paper and bottles." (đúng ngữ pháp).'],
  [3,'Dịch sang tiếng Anh: "Chúng ta không nên vứt rác xuống sông."','"We should not (shouldn’t) throw rubbish into the river."'],
  [4,'Write one sentence about a traditional custom in your area, in English.','VD: "People in my village hold a spring festival every year." (câu đúng, phù hợp nghĩa).']
 ]);
 add(M,8,'Grammar — Present perfect, Reported speech (basic)',[
  [1,'Choose the correct form: I ___ my homework already.','have done','did','do','doing'],
  [1,'Choose: She has lived here ___ 2010.','since','for','in','at'],
  [2,'Choose: We have studied English ___ five years.','for','since','in','at'],
  [2,'Reported speech: He said, "I am tired." → He said (that) he ___ tired.','was','is','are','be'],
  [3,'Chia động từ (present perfect): They (visit) ___ Ha Long Bay twice.','have visited'],
  [3,'Viết câu present perfect phủ định: "I have finished the book." (phủ định)','"I have not (haven’t) finished the book."'],
  [3,'Đổi sang lời nói gián tiếp: She said, "I like tea." → ___','She said (that) she liked tea.'],
  [4,'Find and correct the mistake: "I have seen him yesterday."','Sửa: "I saw him yesterday." (có "yesterday" – thời gian xác định trong quá khứ nên dùng past simple, không dùng present perfect).']
 ]);
 add(M,8,'Pronunciation',[
  [1,'Choose the word with a different sound of the ending -s: wants, needs, stops, books.','needs','wants','stops','books'],
  [2,'Which word has a silent letter?','listen','pencil','table','open'],
  [2,'Choose the word with the stress on the second syllable.','enjoy','happy','hobby','table'],
  [2,'How many syllables are there in "environment"?','Four','Two','Three','Five'],
  [4,'Which word has a different stress pattern: pollution, tradition, festival, reduction?','festival','pollution','tradition','reduction'],
  [2,'Khi nào đuôi -s/-es của động từ ngôi thứ ba số ít được phát âm /ɪz/?','Khi động từ kết thúc bằng âm /s/, /z/, /ʃ/, /tʃ/, /dʒ/ (VD: watches, washes, misses).'],
  [2,'Đuôi -s trong từ "plays" được phát âm là gì?','/z/.'],
  [3,'Xếp các từ vào nhóm phát âm đuôi -s: works, goes, watches.','works: /s/; goes: /z/; watches: /ɪz/.'],
  [3,'Viết một câu ở thì hiện tại đơn (ngôi 3 số ít) và cho biết đuôi -s phát âm thế nào.','VD: "She watches TV." – watches: /ɪz/.']
 ]);

 /* ===================== LỚP 9 ===================== */
 add(M,9,'Vocabulary — Community, City life, Tourism',[
  [1,'Choose the odd one out.','traffic jam','tourism','sightseeing','travelling'],
  [1,'"Du lịch" in English is ___.','tourism','traffic','custom','leisure'],
  [2,'Choose the correct word: A big problem of city life is traffic ___.','jam','trip','guide','map'],
  [2,'Which word is related to tourism?','sightseeing','homework','kitchen','exam'],
  [2,'Viết 4 từ liên quan đến du lịch (tourism) bằng tiếng Anh.','VD: tourist, sightseeing, hotel, travel, beach, guide.'],
  [3,'Đặt một câu tiếng Anh giới thiệu một địa điểm du lịch ở Việt Nam.','VD: "Ha Long Bay is a famous tourist attraction in Viet Nam." (đúng ngữ pháp).'],
  [3,'Dịch sang tiếng Anh: "Sống ở thành phố có nhiều thuận lợi và bất lợi."','"Living in the city has many advantages and disadvantages."'],
  [4,'Write one sentence about one advantage and one disadvantage of city life, in English.','VD: "City life offers good jobs, but it is often crowded and noisy." (câu đúng, nêu đủ ý).']
 ]);
 add(M,9,'Grammar — Conditional sentences, Passive, Relative clauses',[
  [1,'Choose the correct form (first conditional): If it rains, we ___ at home.','will stay','stay','stayed','would stay'],
  [1,'Choose the passive form: English ___ in many countries.','is spoken','speaks','is speaking','speak'],
  [2,'Choose the correct relative pronoun: The man ___ helped me is a teacher.','who','which','where','whose'],
  [2,'Second conditional: If I ___ rich, I would travel around the world.','were','am','will be','was being'],
  [3,'Chuyển sang câu bị động: "People grow rice in the Mekong Delta."','"Rice is grown in the Mekong Delta (by people)."'],
  [3,'Viết câu điều kiện loại 1: "If you (study) ___ hard, you (pass) ___ the exam."','study; will pass.'],
  [3,'Nối hai câu bằng đại từ quan hệ: "This is the book. I bought it yesterday."','"This is the book which/that I bought yesterday."'],
  [4,'Find and correct the mistake: "If I will have time, I will visit you."','Sửa: "If I have time, I will visit you." (mệnh đề if ở câu điều kiện loại 1 dùng hiện tại đơn, không dùng will).']
 ]);
 add(M,9,'Pronunciation',[
  [1,'Choose the word with a different sound of the ending -ed: decided, visited, played, needed.','played','decided','visited','needed'],
  [2,'Choose the word with the stress on the second syllable.','enjoy','city','travel','tourist'],
  [2,'Which word has three syllables?','tourism','city','travel','guide'],
  [2,'Choose the word with a silent letter.','island','pencil','travel','open'],
  [4,'Which word has a different stress pattern: advantage, disadvantage, tradition, pollution?','disadvantage','advantage','tradition','pollution'],
  [2,'Nêu quy tắc chung về phát âm đuôi -ed: khi nào là /ɪd/?','Khi động từ kết thúc bằng âm /t/ hoặc /d/ (VD: wanted, needed, decided).'],
  [2,'Trọng âm của từ "tourism" rơi vào âm tiết thứ mấy?','Âm tiết thứ nhất (TOU-rism).'],
  [3,'Xếp các từ vào nhóm phát âm đuôi -ed: hoped, closed, wanted.','hoped: /t/; closed: /d/; wanted: /ɪd/.'],
  [3,'Viết một câu có động từ bị động và cho biết một từ có đuôi -ed phát âm thế nào.','VD: "The house was painted last week." – painted: /ɪd/.']
 ]);

})();
