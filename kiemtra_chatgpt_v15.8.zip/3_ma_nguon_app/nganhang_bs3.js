/* ============================================================
   NGÂN HÀNG BỔ SUNG 3 — ĐÀO SÂU (tăng số câu mỗi chủ đề)
   Mục tiêu: mỗi chủ đề ~15–20 câu để nhiều giáo viên cùng khối
   tạo đề KHÔNG trùng nhau. Nguyên bản, bám SGK Kết nối tri thức.
   Lượt này: ĐẠO ĐỨC, TỰ NHIÊN & XÃ HỘI, KHOA HỌC (Tiểu học).
   TN [mức,'câu','ĐÚNG','sai','sai','sai'] · TL [mức,'câu','đáp án']
   ============================================================ */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }

 /* ===================== ĐẠO ĐỨC ===================== */
 add('Đạo đức',1,'Tự chăm sóc bản thân',[
  [1,'Trước khi ăn và sau khi đi vệ sinh, em cần làm gì?','Rửa tay bằng xà phòng','Lau tay vào áo','Không cần rửa','Chỉ thổi cho sạch'],
  [1,'Để mắt sáng khỏe, khi đọc sách em cần ngồi thế nào?','Ngồi thẳng, đủ ánh sáng, giữ khoảng cách hợp lí','Nằm đọc','Đọc nơi tối','Để sách sát mắt'],
  [2,'Khi trời lạnh, em nên mặc thế nào để giữ sức khỏe?','Mặc đủ ấm','Mặc áo cộc','Để chân trần','Không đội mũ'],
  [3,'Buổi tối em nên đi ngủ sớm hay thức khuya xem ti vi? Vì sao?','Nên ngủ sớm, đủ giấc để cơ thể khỏe, sáng dậy tỉnh táo học tốt; thức khuya hại sức khỏe.'],
  [2,'Móng tay dài, bẩn thì nên làm gì?','Cắt ngắn, rửa sạch; móng bẩn chứa vi khuẩn dễ gây bệnh.']
 ]);
 add('Đạo đức',1,'Gia đình và nhà trường',[
  [2,'Khi ông bà, cha mẹ đi làm về, em nên làm gì?','Chào hỏi, mời nước, hỏi thăm','Phớt lờ','Đòi quà','Chạy đi chơi'],
  [1,'Với bạn bè trong lớp, em nên cư xử thế nào?','Hòa đồng, giúp đỡ, không đánh nhau','Trêu chọc bạn','Tranh giành','Nói xấu bạn'],
  [3,'Em sẽ làm gì khi thấy em nhỏ trong nhà khóc vì ngã?','Đỡ em dậy, dỗ dành, báo người lớn nếu em đau nhiều.'],
  [2,'Việc nào giúp lớp học sạch, đẹp?','Trực nhật, bỏ rác đúng chỗ, giữ bàn ghế ngăn nắp.']
 ]);
 add('Đạo đức',1,'An toàn',[
  [1,'Khi chơi, em không nên leo trèo ở đâu?','Lan can, cây cao, nơi nguy hiểm','Sân chơi bằng phẳng','Trong lớp','Sân cỏ'],
  [2,'Thấy dây điện đứt rơi xuống đất, em nên làm gì?','Tránh xa và báo người lớn','Cầm lên xem','Dùng tay kéo','Giẫm lên'],
  [1,'Khi sang đường cùng người lớn, em nên nắm tay ai?','Nắm tay người lớn đi cùng','Chạy một mình','Tự đi trước','Buông tay ra'],
  [3,'Nếu thấy bạn nghịch lửa, diêm, em nên làm gì?','Can ngăn bạn và báo người lớn vì dễ gây cháy, bỏng rất nguy hiểm.']
 ]);
 add('Đạo đức',2,'Quê hương, thầy cô, bạn bè',[
  [1,'Ngày Nhà giáo Việt Nam là ngày nào?','20/11','1/6','8/3','2/9'],
  [2,'Việc làm nào thể hiện quý trọng bạn bè?','Chia sẻ, giúp đỡ, không nói xấu bạn','Tẩy chay bạn','Giành đồ của bạn','Chê bai bạn'],
  [2,'Em làm gì để giữ gìn cảnh đẹp quê hương?','Không xả rác, trồng cây, bảo vệ di tích, cây xanh.'],
  [3,'Bạn ngồi cạnh quên mang bút, em nên làm gì?','Cho bạn mượn bút, vui vẻ giúp bạn để cùng học tốt.']
 ]);
 add('Đạo đức',2,'Quý trọng thời gian, nhận lỗi',[
  [1,'Đi học đúng giờ thể hiện điều gì?','Biết quý trọng thời gian, có kỉ luật','Ham chơi','Lười biếng','Thiếu trách nhiệm'],
  [2,'Khi làm vỡ đồ của bạn, em nên làm gì?','Xin lỗi và tìm cách đền, sửa','Giấu đi','Đổ cho bạn khác','Bỏ chạy'],
  [2,'Vì sao không nên để dành việc học đến phút cuối?','Dễ làm vội, không kĩ, kết quả kém; nên làm sớm, có kế hoạch.'],
  [3,'Hãy kể một việc em đã làm đúng giờ và kết quả của nó.','HS kể việc cụ thể (đi học, nộp bài, hẹn bạn...) và lợi ích của việc đúng giờ.']
 ]);
 add('Đạo đức',2,'Cảm xúc và nơi công cộng',[
  [1,'Khi xếp hàng mua vé, em nên làm gì?','Xếp hàng trật tự, chờ đến lượt','Chen lên trước','Xô đẩy','La hét'],
  [2,'Thấy bạn vui khi được khen, đó là cảm xúc gì?','Vui, hạnh phúc','Tức giận','Buồn bã','Sợ hãi'],
  [2,'Nêu cách thể hiện niềm vui đúng mực nơi công cộng.','Cười nói vừa phải, không reo hò quá to, không làm phiền người khác.'],
  [3,'Khi tức giận với bạn, làm thế nào để không cãi nhau?','Hít thở sâu, bình tĩnh, nói rõ cảm giác hoặc tạm dừng rồi nói chuyện lại; nhờ thầy cô nếu cần.']
 ]);
 add('Đạo đức',3,'Tổ quốc, hàng xóm',[
  [1,'Khi chào cờ và hát Quốc ca, em cần có thái độ nào?','Nghiêm trang, đứng thẳng','Nói chuyện','Cười đùa','Đứng ngả nghiêng'],
  [2,'Việc nào thể hiện quan hệ tốt với hàng xóm?','Chào hỏi, giúp đỡ nhau','Gây ồn ào','Xả rác sang nhà bên','Nói xấu hàng xóm'],
  [2,'Vì sao cần giữ gìn tình làng nghĩa xóm?','Để mọi người sống chan hòa, giúp đỡ nhau lúc khó khăn, xóm làng yên vui.'],
  [3,'Nhà hàng xóm có đám hiếu, em và gia đình nên cư xử thế nào?','Giữ yên tĩnh, chia buồn, giúp đỡ việc phù hợp, thể hiện sự cảm thông.']
 ]);
 add('Đạo đức',3,'Ham học hỏi, giữ lời hứa',[
  [1,'Khi gặp bài khó, người ham học hỏi sẽ làm gì?','Suy nghĩ, hỏi thầy cô, bạn bè','Bỏ qua','Chép bài bạn','Nản chí'],
  [2,'Đã hứa với bạn mà không thực hiện sẽ dẫn đến điều gì?','Mất lòng tin của bạn','Được khen','Bạn quý hơn','Không sao cả'],
  [3,'Nêu một cách giúp em nhớ và thực hiện đúng lời hứa.','Ghi lại, nhắc mình, sắp xếp thời gian; chỉ hứa điều mình làm được.'],
  [2,'Vì sao đọc sách giúp em ham học hỏi hơn?','Sách cho nhiều kiến thức, điều mới lạ, kích thích tò mò và hiểu biết.']
 ]);
 add('Đạo đức',3,'An toàn giao thông, xử lí bất hòa',[
  [1,'Người đi bộ qua đường ở nơi có vạch kẻ thì đi vào đâu?','Đi trên vạch kẻ dành cho người đi bộ','Đi chỗ nào cũng được','Đi giữa đường','Trèo qua dải phân cách'],
  [2,'Khi có bất hòa với bạn, cách tốt nhất là gì?','Bình tĩnh nói chuyện, lắng nghe nhau','Đánh nhau','Giận dỗi lâu','Rủ bạn khác tẩy chay'],
  [2,'Vì sao phải đội mũ bảo hiểm khi đi xe máy, xe đạp điện?','Bảo vệ đầu, giảm chấn thương khi xảy ra tai nạn; đồng thời là quy định bắt buộc.'],
  [3,'Hai bạn tranh nhau quả bóng. Em khuyên các bạn thế nào?','Nhường nhịn, thay nhau chơi hoặc chơi chung; không giành giật, cãi nhau.']
 ]);
 add('Đạo đức',4,'Biết ơn người lao động',[
  [1,'Thức ăn trên bàn là thành quả lao động của ai?','Nhiều người lao động (nông dân, người chế biến...)','Tự nhiên có','Chỉ của em','Không của ai'],
  [2,'Thái độ nào là lãng phí thành quả lao động?','Bỏ thừa cơm, phá đồ dùng','Ăn hết suất','Giữ gìn đồ dùng','Tiết kiệm'],
  [2,'Vì sao cần quý trọng người lao động chân tay?','Vì họ làm ra của cải, phục vụ cuộc sống; mọi nghề chân chính đều đáng quý.'],
  [3,'Em thể hiện lòng biết ơn thầy cô giáo bằng việc làm nào?','Chăm học, lễ phép, vâng lời, hoàn thành bài, chúc mừng ngày 20/11.']
 ]);
 add('Đạo đức',4,'Cảm thông, giúp đỡ người gặp khó khăn',[
  [1,'Người gặp khó khăn có thể là ai?','Người nghèo, người bệnh, người gặp thiên tai','Người giàu có','Người khỏe mạnh','Người may mắn'],
  [2,'Giúp đỡ người khác, em nên có thái độ thế nào?','Chân thành, không coi thường, không kể công','Khoe khoang','Coi thường họ','Đòi trả ơn'],
  [2,'Nêu một việc lớp em có thể làm để giúp bạn có hoàn cảnh khó khăn.','Quyên góp sách vở, quần áo; đôi bạn cùng tiến; động viên, giúp bạn học.'],
  [3,'Thấy người khuyết tật đang mang vác nặng, em làm gì?','Lễ phép hỏi và giúp đỡ trong khả năng, hoặc nhờ người lớn giúp.']
 ]);
 add('Đạo đức',4,'Yêu lao động, tôn trọng tài sản',[
  [1,'Việc nào thể hiện yêu lao động?','Tự giác làm việc nhà, trực nhật','Trốn việc','Ỷ lại người khác','Chê việc'],
  [2,'Nhặt được của rơi, em nên làm gì?','Tìm cách trả lại người mất hoặc nhờ người lớn, thầy cô','Giữ làm của mình','Giấu đi','Vứt bỏ'],
  [2,'Vì sao cần giữ gìn của công (bàn ghế, cây xanh ở trường)?','Vì là tài sản chung của mọi người; giữ gìn để dùng lâu dài, đỡ tốn kém.'],
  [3,'Em làm gì để góp phần tiết kiệm điện, nước ở trường và ở nhà?','Tắt điện, quạt khi ra khỏi phòng; khóa vòi nước; không để lãng phí.']
 ]);
 add('Đạo đức',4,'Quyền và bổn phận trẻ em',[
  [1,'Việc được bày tỏ ý kiến là gì của trẻ em?','Một quyền của trẻ em','Việc bị cấm','Lỗi','Điều không nên'],
  [2,'Bổn phận của trẻ em với bản thân là gì?','Chăm học, rèn luyện, giữ vệ sinh, sống trung thực','Lười học','Ham chơi','Nói dối'],
  [2,'Khi người lớn quyết định việc liên quan đến em, em có quyền gì?','Được bày tỏ ý kiến, nguyện vọng của mình một cách lễ phép.'],
  [3,'Theo em, trẻ em cần làm gì để thực hiện tốt cả quyền và bổn phận?','Vừa biết hưởng quyền đúng mực, vừa chăm học, lễ phép, giúp đỡ gia đình, sống có trách nhiệm.']
 ]);
 add('Đạo đức',5,'Biết ơn người có công',[
  [1,'Giỗ Tổ Hùng Vương được tổ chức vào ngày nào (âm lịch)?','Mùng 10 tháng 3','Mùng 1 tháng 1','Rằm tháng 8','Mùng 5 tháng 5'],
  [2,'Việc nào KHÔNG thể hiện lòng biết ơn người có công?','Phá hoại, xem thường di tích lịch sử','Thăm viếng nghĩa trang liệt sĩ','Chăm sóc gia đình thương binh','Tìm hiểu lịch sử'],
  [2,'Vì sao cần ghi nhớ công lao các vua Hùng?','Vì các vua Hùng có công dựng nước; nhớ ơn để giữ gìn và xây dựng đất nước.'],
  [3,'Trường phát động phong trào "Đền ơn đáp nghĩa". Em tham gia bằng việc gì?','Góp quỹ, thăm hỏi gia đình chính sách, chăm sóc nghĩa trang, viết thư tri ân.']
 ]);
 add('Đạo đức',5,'Tôn trọng sự khác biệt, bảo vệ cái đúng',[
  [1,'Việc làm nào thể hiện tôn trọng người khác?','Lắng nghe, không chê bai ngoại hình, hoàn cảnh của họ','Chế giễu','Kì thị','Xa lánh'],
  [2,'Khi biết mình sai, người biết bảo vệ cái đúng sẽ làm gì?','Nhận sai và sửa, theo lẽ phải','Bảo thủ','Giấu lỗi','Đổ cho người khác'],
  [2,'Vì sao cần bảo vệ cái đúng dù số đông phản đối?','Vì lẽ phải cần được tôn trọng; bảo vệ cái đúng giúp xã hội công bằng, tốt đẹp.'],
  [3,'Em thấy bạn bị nghi oan lấy đồ của lớp. Em làm gì?','Bình tĩnh tìm hiểu sự thật, nói rõ điều mình biết để bảo vệ bạn, báo thầy cô.']
 ]);
 add('Đạo đức',5,'Bảo vệ môi trường, kế hoạch cá nhân',[
  [1,'Hành động nào gây hại cho môi trường?','Vứt rác xuống sông, đốt rác bừa bãi','Trồng cây','Phân loại rác','Tiết kiệm nước'],
  [2,'Lập kế hoạch cá nhân nên bắt đầu bằng việc gì?','Xác định mục tiêu và các việc cần làm','Làm tùy hứng','Bỏ qua việc khó','Chép của bạn'],
  [2,'Nêu ích lợi của việc phân loại rác.','Dễ tái chế, giảm ô nhiễm, tiết kiệm tài nguyên, giữ môi trường sạch.'],
  [3,'Hãy nêu kế hoạch của em để góp phần làm trường xanh – sạch – đẹp.','VD: chăm sóc cây, trực nhật sạch, bỏ rác đúng nơi, nhắc bạn giữ vệ sinh, tham gia trồng cây.']
 ]);
 add('Đạo đức',5,'Phòng tránh xâm hại, sử dụng tiền hợp lí',[
  [1,'Bộ phận nào trên cơ thể là vùng riêng tư cần được bảo vệ?','Vùng được quần áo lót che','Bàn tay','Khuôn mặt','Cánh tay'],
  [2,'Khi người lạ trên mạng xin ảnh hoặc hẹn gặp, em nên làm gì?','Từ chối và kể cho bố mẹ biết','Gửi ảnh','Hẹn gặp một mình','Giữ bí mật'],
  [2,'Vì sao cần ghi chép các khoản chi tiêu?','Để biết tiền dùng vào việc gì, tránh lãng phí và biết tiết kiệm.'],
  [3,'Em muốn mua một món đồ đắt tiền. Em nên làm gì thay vì đòi mua ngay?','Tiết kiệm dần, cân nhắc có thật sự cần không, xin ý kiến bố mẹ.']
 ]);

 /* ================= TỰ NHIÊN VÀ XÃ HỘI ================= */
 add('Tự nhiên và Xã hội',1,'Gia đình và trường học',[
  [1,'Trong lớp, ai là người giúp em học tập mỗi ngày?','Thầy, cô giáo','Bác tài xế','Người bán hàng','Chú thợ xây'],
  [2,'Đồ dùng học tập của em gồm những gì?','Sách, vở, bút, thước','Nồi, chảo','Cuốc, xẻng','Búa, đinh'],
  [2,'Việc nào thể hiện em yêu quý trường lớp?','Giữ gìn bàn ghế, không vẽ bậy, bỏ rác đúng chỗ.'],
  [3,'Kể một việc em làm để giúp đỡ bố mẹ ở nhà.','VD: cất đồ chơi, gấp quần áo, tưới cây, trông em.']
 ]);
 add('Tự nhiên và Xã hội',1,'Thực vật và động vật',[
  [1,'Con vật nào biết bay?','Con chim','Con cá','Con rùa','Con ốc'],
  [1,'Bộ phận nào của cây thường có màu xanh và giúp cây quang hợp?','Lá','Rễ','Gốc','Hạt khô'],
  [2,'Vì sao cần chăm sóc, bảo vệ cây xanh?','Cây cho bóng mát, quả, làm sạch không khí, làm đẹp cảnh quan.'],
  [3,'Kể hai con vật có ích và ích lợi của chúng.','VD: con gà cho trứng, thịt; con mèo bắt chuột; con ong cho mật...']
 ]);
 add('Tự nhiên và Xã hội',1,'Con người và sức khỏe',[
  [1,'Bộ phận nào giúp em cầm, nắm đồ vật?','Bàn tay','Bàn chân','Cái tai','Cái mũi'],
  [2,'Để không bị sâu răng, em nên hạn chế ăn gì?','Bánh kẹo ngọt','Rau xanh','Trái cây','Cơm'],
  [2,'Nêu các bữa ăn chính trong ngày.','Bữa sáng, bữa trưa, bữa tối (ăn đủ bữa, đúng giờ).'],
  [3,'Vì sao cần ngủ đủ giấc mỗi ngày?','Để cơ thể nghỉ ngơi, khỏe mạnh, sáng dậy tỉnh táo học tập tốt.']
 ]);
 add('Tự nhiên và Xã hội',1,'Trái Đất và bầu trời',[
  [1,'Khi trời nắng to, muốn ra ngoài em nên làm gì?','Đội mũ, che ô','Cởi áo','Nhìn thẳng Mặt Trời','Chạy dưới nắng lâu'],
  [2,'Cầu vồng thường xuất hiện khi nào?','Sau cơn mưa, lúc có nắng','Giữa đêm tối','Khi trời khô hạn','Khi có tuyết'],
  [2,'Nêu một số việc nên làm khi trời mưa to.','Mặc áo mưa, che ô, trú nơi an toàn, không ra đồng trống khi có sấm sét.'],
  [3,'Vì sao buổi trưa trời thường nóng hơn buổi sáng và chiều?','Buổi trưa Mặt Trời lên cao, chiếu thẳng nên nóng hơn.']
 ]);
 add('Tự nhiên và Xã hội',1,'Cộng đồng địa phương',[
  [1,'Người giúp giữ gìn an ninh trật tự ở khu phố, làng xóm là ai?','Chú công an','Bác nông dân','Cô bán hàng','Người đưa thư'],
  [2,'Khi đi bộ trên đường không có vỉa hè, em nên đi thế nào?','Đi sát lề bên phải','Đi giữa đường','Đi hàng ngang','Vừa đi vừa chạy'],
  [2,'Kể một số người làm việc phục vụ cộng đồng và công việc của họ.','VD: bác sĩ khám bệnh, cô giáo dạy học, chú công an giữ trật tự, người đưa thư chuyển thư.'],
  [3,'Em làm gì để giữ gìn vệ sinh nơi mình ở?','Quét dọn, bỏ rác đúng nơi, không vứt rác ra đường, nhắc mọi người giữ sạch.']
 ]);
 add('Tự nhiên và Xã hội',2,'Gia đình và trường học',[
  [1,'Nơi cả nhà cùng ăn cơm, trò chuyện thường là ở đâu?','Phòng ăn/phòng khách','Nhà kho','Nhà xe','Ngoài đường'],
  [2,'Việc làm nào giúp phòng tránh tai nạn khi ở trường?','Không chạy nhảy ở cầu thang, không xô đẩy','Leo lan can','Chạy đuổi nhau','Ném đồ vật'],
  [2,'Kể tên một số nghề nghiệp của người thân trong gia đình em.','HS kể nghề của bố mẹ, ông bà (nông dân, công nhân, giáo viên, buôn bán...).'],
  [3,'Vì sao các thành viên trong gia đình cần yêu thương, giúp đỡ nhau?','Để gia đình hạnh phúc, đầm ấm, cùng chia sẻ vui buồn và khó khăn.']
 ]);
 add('Tự nhiên và Xã hội',2,'Cộng đồng địa phương',[
  [1,'Nghề làm ra lúa gạo là nghề gì?','Nghề nông','Nghề dệt','Nghề mộc','Nghề may'],
  [2,'Biển báo giao thông hình tam giác viền đỏ thường mang ý nghĩa gì?','Báo nguy hiểm','Được phép đi','Hết cấm','Nơi đỗ xe'],
  [2,'Kể một nghề thủ công và sản phẩm của nghề đó.','VD: nghề gốm làm bát đĩa; nghề mây tre đan làm rổ rá; nghề dệt làm vải, chiếu.'],
  [3,'Vì sao cần tôn trọng người làm các nghề khác nhau?','Mọi nghề đều có ích cho xã hội; cần trân trọng công sức của mỗi người.']
 ]);
 add('Tự nhiên và Xã hội',2,'Thực vật và động vật',[
  [1,'Môi trường sống của con cá là ở đâu?','Dưới nước','Trên cây','Trong hang khô','Trên trời'],
  [2,'Cây xanh cần gì để sống và lớn lên?','Nước, ánh sáng, không khí, chất dinh dưỡng','Chỉ cần bóng tối','Không cần nước','Chỉ cần đá'],
  [2,'Nêu nơi sống của một số con vật em biết.','VD: cá sống dưới nước; chim sống trên cây; trâu bò sống ở đồng; gà sống quanh nhà.'],
  [3,'Chúng ta cần làm gì để bảo vệ các con vật?','Không săn bắt bừa bãi, chăm sóc vật nuôi, bảo vệ nơi ở của chúng.']
 ]);
 add('Tự nhiên và Xã hội',2,'Con người và sức khỏe',[
  [1,'Cơ quan hô hấp gồm những bộ phận chính nào?','Mũi, khí quản, hai lá phổi','Dạ dày, ruột','Tim, mạch máu','Tay, chân'],
  [2,'Để giữ gìn cơ quan hô hấp, em nên tránh điều gì?','Hít khói thuốc, khói bụi','Tập thể dục','Ở nơi thoáng sạch','Giữ ấm cơ thể'],
  [3,'Nêu việc nên làm để phòng bệnh khi thời tiết thay đổi.','Giữ ấm, ăn uống đủ chất, đeo khẩu trang nơi bụi, rửa tay sạch, tập thể dục.']
 ]);
 add('Tự nhiên và Xã hội',2,'Trái Đất và bầu trời',[
  [1,'Hình dạng của Mặt Trăng mà ta nhìn thấy thay đổi hay cố định?','Thay đổi theo ngày (trăng tròn, trăng khuyết)','Luôn tròn','Luôn khuyết','Không nhìn thấy'],
  [2,'Khi có gió to, bão, em nên ở đâu cho an toàn?','Ở trong nhà chắc chắn','Ra đường chơi','Đứng dưới cây to','Ra bờ sông'],
  [2,'Kể tên một số hiện tượng thời tiết theo mùa ở nơi em sống.','VD: mùa hè nắng nóng, mưa rào; mùa đông lạnh; mùa mưa, mùa khô (miền Nam).'],
  [3,'Vì sao cần xem dự báo thời tiết trước khi đi xa?','Để chuẩn bị quần áo, đồ dùng phù hợp và phòng tránh mưa bão, nắng nóng.']
 ]);
 add('Tự nhiên và Xã hội',3,'Gia đình và trường học',[
  [1,'Anh (chị) của bố em thì em gọi là gì?','Bác','Em','Cháu','Ông'],
  [2,'Để an toàn khi dùng điện ở nhà, em nên làm gì?','Không chạm tay ướt vào ổ điện, công tắc','Cắm nhiều phích một ổ','Nghịch dây điện','Dùng vật kim loại chọc ổ điện'],
  [2,'Kể các thế hệ trong gia đình hai thế hệ và ba thế hệ.','Hai thế hệ: bố mẹ và con. Ba thế hệ: ông bà, bố mẹ và con.'],
  [3,'Vì sao cần sắp xếp góc học tập gọn gàng?','Để dễ tìm đồ dùng, học tập tập trung, giữ vệ sinh và rèn tính ngăn nắp.']
 ]);
 add('Tự nhiên và Xã hội',3,'Cộng đồng địa phương',[
  [1,'Sản phẩm của hoạt động trồng trọt là gì?','Lúa, rau, hoa quả','Bàn ghế','Vải vóc','Xe máy'],
  [2,'Hoạt động công nghiệp thường dùng gì để sản xuất?','Máy móc trong nhà máy','Chỉ dùng tay','Chỉ dùng cuốc','Chỉ dùng thuyền'],
  [2,'Kể một di tích hoặc lễ hội ở địa phương em (nếu có) hoặc ở Việt Nam.','HS kể tên và một hiểu biết ngắn (VD: đền, chùa, lễ hội của quê hương/đất nước).'],
  [3,'Em làm gì khi tham gia lễ hội ở địa phương?','Giữ trật tự, vệ sinh, tôn trọng phong tục, không chen lấn, không xả rác.']
 ]);
 add('Tự nhiên và Xã hội',3,'Con người và sức khỏe',[
  [1,'Cơ quan tuần hoàn gồm tim và gì?','Các mạch máu','Hai lá phổi','Dạ dày','Xương'],
  [2,'Để cơ quan bài tiết nước tiểu khỏe mạnh, em nên làm gì?','Uống đủ nước, không nhịn tiểu','Nhịn uống nước','Nhịn tiểu lâu','Ăn quá mặn thường xuyên'],
  [2,'Nêu việc nên làm để giữ gìn cơ quan tiêu hóa.','Ăn chín uống sôi, ăn đúng bữa, nhai kĩ, rửa tay trước khi ăn, không ăn quá nhiều đồ ngọt, cay.'],
  [3,'Vì sao cần tập thể dục thường xuyên?','Giúp cơ thể khỏe mạnh, xương chắc, tim khỏe, tinh thần thoải mái, phòng bệnh.']
 ]);
 add('Tự nhiên và Xã hội',3,'Thực vật và động vật',[
  [1,'Động vật nào dưới đây đẻ trứng?','Con gà','Con mèo','Con chó','Con lợn'],
  [2,'Rễ cây có chức năng chính là gì?','Hút nước, chất dinh dưỡng và giữ cây','Quang hợp','Ra hoa','Tạo quả'],
  [2,'Nêu ích lợi của cây xanh đối với con người.','Cho bóng mát, gỗ, hoa quả, rau; làm sạch không khí; giữ đất, chống xói mòn.'],
  [4,'Vì sao nói mỗi loài vật đều có vai trò trong tự nhiên?','Các loài liên hệ nhau qua chuỗi thức ăn, giữ cân bằng tự nhiên; mất một loài có thể ảnh hưởng nhiều loài khác.']
 ]);
 add('Tự nhiên và Xã hội',3,'Trái Đất và bầu trời',[
  [1,'Trái Đất có dạng hình gì?','Hình cầu (gần tròn)','Hình vuông','Hình tam giác','Mặt phẳng'],
  [2,'Ban ngày và ban đêm luân phiên nhau là do đâu?','Trái Đất tự quay quanh mình nó','Mặt Trăng che Mặt Trời','Trời có mây','Đèn tắt bật'],
  [2,'Nêu tên bốn phương chính.','Đông, Tây, Nam, Bắc.'],
  [4,'Vì sao ở Việt Nam có nơi 4 mùa, có nơi chỉ 2 mùa?','Do vị trí và khí hậu khác nhau: miền Bắc có mùa đông lạnh nên rõ 4 mùa; miền Nam nóng quanh năm nên chủ yếu 2 mùa mưa – khô.']
 ]);

 /* ===================== KHOA HỌC ===================== */
 add('Khoa học',4,'Chất: nước và không khí',[
  [1,'Nước tồn tại ở mấy thể?','Ba thể: rắn, lỏng, khí','Một thể','Hai thể','Bốn thể'],
  [2,'Hiện tượng nước bốc hơi xảy ra khi nào?','Khi nước được đun nóng hoặc gặp nắng','Khi nước đóng băng','Khi trời lạnh','Khi để trong tủ đá'],
  [2,'Không khí có ở đâu?','Ở khắp nơi quanh ta','Chỉ ở trên núi','Chỉ trong bình','Chỉ dưới nước'],
  [3,'Vì sao cần bảo vệ nguồn nước sạch?','Nước sạch cần cho ăn uống, sinh hoạt, sản xuất; thiếu nước sạch gây bệnh và khó khăn cho đời sống.'],
  [2,'Nêu một số việc làm giúp tiết kiệm nước.','Khóa vòi khi không dùng, hứng nước vừa đủ, tận dụng nước vo gạo tưới cây, sửa vòi rò rỉ.']
 ]);
 add('Khoa học',4,'Năng lượng: ánh sáng, âm thanh, nhiệt',[
  [1,'Vật nào dưới đây là nguồn sáng tự nhiên?','Mặt Trời','Bóng đèn','Ngọn nến','Đèn pin'],
  [2,'Âm thanh được tạo ra khi nào?','Khi vật rung động','Khi vật đứng yên','Khi trời tối','Khi vật lạnh đi'],
  [2,'Vật nào dẫn nhiệt tốt?','Kim loại (nồi nhôm, thìa sắt)','Gỗ','Nhựa','Vải'],
  [3,'Vì sao không nên nhìn trực tiếp vào Mặt Trời?','Ánh sáng Mặt Trời rất mạnh, nhìn thẳng có thể làm hại mắt.'],
  [2,'Nêu cách phòng tránh tiếng ồn quá lớn để bảo vệ tai.','Tránh nơi quá ồn, không mở loa quá to, bịt tai khi có tiếng động mạnh.']
 ]);
 add('Khoa học',4,'Thực vật, động vật và nấm',[
  [1,'Cây xanh tự tạo chất dinh dưỡng nhờ quá trình nào?','Quang hợp','Hô hấp','Tiêu hóa','Bài tiết'],
  [2,'Để sống và phát triển, động vật cần gì?','Thức ăn, nước, không khí, nơi ở','Chỉ cần ánh sáng','Chỉ cần đất','Không cần gì'],
  [2,'Nấm thường mọc ở nơi như thế nào?','Nơi ẩm ướt','Nơi khô nóng','Trong lửa','Giữa sa mạc'],
  [3,'Vì sao có loại nấm ăn được nhưng có loại không ăn được?','Nhiều nấm là thực phẩm bổ dưỡng, nhưng một số nấm có độc gây ngộ độc; chỉ ăn nấm biết rõ, an toàn.'],
  [2,'Nêu vai trò của thực vật đối với động vật và con người.','Cung cấp thức ăn, khí ô-xi, nơi ở; là nguyên liệu, thuốc; làm đẹp và cân bằng tự nhiên.']
 ]);
 add('Khoa học',4,'Con người và sức khỏe',[
  [1,'Chất nào giúp cơ thể lớn lên, xây dựng cơ bắp?','Chất đạm','Chỉ có nước','Chỉ có đường','Không có chất nào'],
  [2,'Ăn nhiều rau xanh và trái cây cung cấp chủ yếu chất gì?','Vi-ta-min và chất khoáng, chất xơ','Chỉ chất béo','Chỉ chất đạm','Chỉ đường'],
  [2,'Nêu một bữa ăn cân đối gồm những nhóm thức ăn nào.','Có đủ: chất bột đường (cơm), chất đạm (thịt, cá, trứng, đậu), chất béo, rau và trái cây.'],
  [3,'Vì sao cần ăn phối hợp nhiều loại thức ăn?','Vì mỗi loại cung cấp chất khác nhau; ăn phối hợp giúp cơ thể đủ chất, khỏe mạnh.']
 ]);
 add('Khoa học',4,'Sinh vật và môi trường',[
  [1,'Sinh vật nào tự tạo được chất dinh dưỡng cho mình?','Cây xanh','Con hổ','Con rắn','Con người'],
  [2,'Nếu số lượng chuột tăng quá nhiều sẽ ảnh hưởng gì đến mùa màng?','Phá hoại mùa màng, gây hại cho con người','Giúp lúa tốt hơn','Không ảnh hưởng gì','Làm sạch đồng ruộng'],
  [2,'Kể một ví dụ về mối quan hệ thức ăn giữa ba sinh vật.','VD: cây lúa → chuột → rắn (hoặc cây → sâu → chim).'],
  [4,'Vì sao cần giữ cân bằng giữa các loài trong tự nhiên?','Vì các loài phụ thuộc nhau qua chuỗi thức ăn; mất cân bằng (một loài quá nhiều hay bị diệt) gây hại cho cả hệ sinh vật và con người.']
 ]);
 add('Khoa học',5,'Chất',[
  [1,'Khi đun nước đá, nước đá chuyển từ thể rắn sang thể gì?','Thể lỏng','Thể khí ngay','Vẫn thể rắn','Biến mất'],
  [2,'Hiện tượng hơi nước gặp lạnh đọng thành giọt nước gọi là gì?','Sự ngưng tụ','Sự bay hơi','Sự đông đặc','Sự nóng chảy'],
  [2,'Kể một ví dụ về sự biến đổi của chất trong đời sống.','VD: nước đun sôi bốc hơi; sáp nến chảy khi gặp nóng; nước đóng băng khi lạnh.'],
  [3,'Vì sao phơi quần áo nơi có nắng và gió thì nhanh khô?','Nắng và gió làm nước trong quần áo bay hơi nhanh hơn nên mau khô.']
 ]);
 add('Khoa học',5,'Năng lượng',[
  [1,'Nguồn năng lượng nào là năng lượng sạch, không gây ô nhiễm?','Năng lượng Mặt Trời, gió','Xăng dầu','Than đá','Củi đốt'],
  [2,'Điện được dùng để làm gì trong gia đình?','Thắp sáng, chạy quạt, ti vi, tủ lạnh','Chỉ để trang trí','Không dùng được','Chỉ để nghịch'],
  [2,'Nêu một số cách tiết kiệm điện trong nhà.','Tắt đèn, quạt, ti vi khi không dùng; dùng đèn tiết kiệm điện; tận dụng ánh sáng tự nhiên.'],
  [3,'Vì sao cần sử dụng năng lượng tiết kiệm và hiệu quả?','Năng lượng không phải vô hạn; tiết kiệm giúp giảm chi phí, bảo vệ tài nguyên và môi trường.']
 ]);
 add('Khoa học',5,'Thực vật và động vật',[
  [1,'Cơ quan sinh sản của cây có hoa là gì?','Hoa','Rễ','Thân','Lá'],
  [2,'Phần lớn thực vật sinh sản bằng gì?','Bằng hạt (từ hoa, quả)','Bằng lông','Bằng vảy','Bằng chân'],
  [2,'Nêu các giai đoạn phát triển của con gà.','Trứng → gà con → gà trưởng thành (gà mái đẻ trứng).'],
  [3,'Vì sao cần bảo vệ các loài thực vật, động vật quý hiếm?','Giữ đa dạng sinh học, cân bằng tự nhiên; nhiều loài có giá trị và đang có nguy cơ tuyệt chủng.']
 ]);
 add('Khoa học',5,'Vi khuẩn',[
  [1,'Muốn nhìn thấy vi khuẩn, người ta phải dùng dụng cụ gì?','Kính hiển vi','Kính lúp thường','Mắt thường','Ống nhòm'],
  [2,'Món ăn nào được làm nhờ vi khuẩn có ích?','Sữa chua, dưa muối','Cơm trắng','Nước lọc','Muối ăn'],
  [2,'Nêu cách bảo quản thức ăn để hạn chế vi khuẩn gây hỏng.','Để tủ lạnh, đậy kín, phơi khô, ướp muối, nấu chín và ăn ngay.'],
  [4,'Vì sao thức ăn để trong tủ lạnh lâu hỏng hơn để ngoài?','Nhiệt độ thấp làm vi khuẩn chậm phát triển nên thức ăn lâu ôi thiu hơn.']
 ]);
 add('Khoa học',5,'Con người và sức khỏe',[
  [1,'Giai đoạn cơ thể lớn nhanh, có nhiều thay đổi để thành người lớn gọi là gì?','Tuổi dậy thì','Tuổi sơ sinh','Tuổi già','Tuổi nhà trẻ'],
  [2,'Để phòng bệnh sốt xuất huyết, em cần làm gì?','Diệt muỗi, lăng quăng; ngủ màn; dọn nơi đọng nước','Không cần làm gì','Để nước đọng','Không ngủ màn'],
  [2,'Nêu việc nên làm để giữ vệ sinh tuổi dậy thì.','Tắm rửa hằng ngày, thay quần áo sạch, giữ vệ sinh cá nhân, ăn uống đủ chất, vận động.'],
  [3,'Vì sao cần nói "không" với thuốc lá, rượu bia và chất gây nghiện?','Vì chúng gây hại nghiêm trọng cho sức khỏe, học tập và cuộc sống; dễ nghiện, khó bỏ.']
 ]);
 add('Khoa học',5,'Sinh vật và môi trường',[
  [1,'Tài nguyên nào có thể cạn kiệt nếu dùng lãng phí?','Nước sạch, rừng, khoáng sản','Ánh sáng Mặt Trời','Gió','Không khí'],
  [2,'Việc nào giúp bảo vệ nguồn nước?','Không xả rác, nước thải xuống sông hồ','Đổ dầu thải ra sông','Vứt rác xuống ao','Xả nước bẩn ra suối'],
  [2,'Nêu một số việc học sinh làm được để bảo vệ môi trường.','Bỏ rác đúng nơi, tiết kiệm điện nước, trồng cây, hạn chế túi ni-lông, tuyên truyền bạn bè.'],
  [4,'Vì sao bảo vệ môi trường cũng là bảo vệ cuộc sống con người?','Môi trường cung cấp nước, không khí, thức ăn; môi trường ô nhiễm gây bệnh tật, thiên tai, ảnh hưởng trực tiếp đến con người.']
 ]);

 /* ================= LỊCH SỬ VÀ ĐỊA LÍ ================= */
 add('Lịch sử và Địa lí',4,'Địa phương em',[
  [1,'Để chỉ đường và tìm vị trí một nơi trong tỉnh, em dùng công cụ nào?','Bản đồ hành chính','Quyển truyện','Tờ lịch','Bức tranh'],
  [2,'Cơ quan nào quản lí hành chính ở cấp tỉnh?','Ủy ban nhân dân tỉnh','Trường tiểu học','Bệnh viện xã','Chợ huyện'],
  [2,'Di sản văn hóa của địa phương gồm những gì?','Di tích, lễ hội, nghề truyền thống, phong tục','Chỉ có nhà cao tầng','Chỉ có siêu thị','Chỉ có đường nhựa'],
  [3,'Nêu một việc em làm để giữ gìn vệ sinh và cảnh quan nơi em sống.','Bỏ rác đúng nơi, không bẻ cây hái hoa, tham gia dọn vệ sinh, nhắc mọi người giữ sạch đẹp.'],
  [3,'Vì sao cần tìm hiểu lịch sử, văn hóa của địa phương mình?','Để hiểu, yêu quý và tự hào về quê hương; biết giữ gìn và phát huy truyền thống tốt đẹp.']
 ]);
 add('Lịch sử và Địa lí',4,'Trung du và miền núi Bắc Bộ',[
  [1,'Dãy núi cao và đồ sộ nhất nước ta nằm ở vùng này có tên là gì?','Hoàng Liên Sơn','Trường Sơn','Tam Đảo','Ba Vì'],
  [1,'Đỉnh núi cao nhất Việt Nam tên là gì?','Phan-xi-păng','Bà Đen','Fan Ngài','Lang Biang'],
  [2,'Ruộng bậc thang được người dân làm ra để làm gì?','Trồng lúa, hoa màu trên sườn đồi núi dốc','Làm sân chơi','Nuôi cá','Làm đường đi'],
  [3,'Vì sao vùng này có nhiều khoáng sản được khai thác?','Vùng núi có nhiều loại khoáng sản (than, a-pa-tít, sắt...) trong lòng đất nên được khai thác phục vụ sản xuất.']
 ]);
 add('Lịch sử và Địa lí',4,'Đồng bằng Bắc Bộ',[
  [1,'Đồng bằng Bắc Bộ được bồi đắp bởi phù sa của sông nào là chủ yếu?','Sông Hồng và sông Thái Bình','Sông Cửu Long','Sông Đồng Nai','Sông Hương'],
  [2,'Thủ đô Hà Nội nằm ở vùng nào?','Đồng bằng Bắc Bộ','Tây Nguyên','Nam Bộ','Duyên hải miền Trung'],
  [2,'Người dân Đồng bằng Bắc Bộ có nhiều kinh nghiệm trong nghề gì?','Trồng lúa nước','Trồng cà phê','Nuôi tôm nước mặn','Khai thác dầu khí'],
  [3,'Kể một số nghề thủ công truyền thống ở Đồng bằng Bắc Bộ.','VD: làm gốm (Bát Tràng), dệt lụa, chạm khắc gỗ, làm nón, đúc đồng... (nhiều làng nghề nổi tiếng).']
 ]);
 add('Lịch sử và Địa lí',4,'Duyên hải miền Trung',[
  [1,'Đặc điểm địa hình nổi bật của Duyên hải miền Trung là gì?','Dải đồng bằng nhỏ hẹp ven biển','Đồng bằng rộng lớn','Cao nguyên rộng','Toàn núi cao'],
  [2,'Cố đô Huế từng là kinh đô của triều đại nào?','Triều Nguyễn','Triều Lý','Triều Trần','Triều Lê sơ'],
  [2,'Phố cổ Hội An thuộc tỉnh nào?','Quảng Nam','Thừa Thiên Huế','Khánh Hòa','Bình Định'],
  [3,'Người dân ven biển miền Trung thường làm những nghề gì?','Đánh bắt và nuôi hải sản, làm muối, du lịch biển, đóng tàu thuyền.'],
  [3,'Vì sao du lịch là thế mạnh của vùng Duyên hải miền Trung?','Có nhiều bãi biển đẹp, di sản văn hóa (Huế, Hội An, Mỹ Sơn), khí hậu và cảnh quan hấp dẫn khách.']
 ]);
 add('Lịch sử và Địa lí',4,'Tây Nguyên',[
  [1,'Địa hình chủ yếu của Tây Nguyên là gì?','Các cao nguyên xếp tầng','Đồng bằng ven biển','Vùng đồi trung du','Vùng ngập mặn'],
  [2,'Loại đất nào màu mỡ, thích hợp trồng cây công nghiệp ở Tây Nguyên?','Đất đỏ badan','Đất phèn','Đất mặn','Đất cát ven biển'],
  [2,'Không gian văn hóa nào của Tây Nguyên được UNESCO ghi danh?','Không gian văn hóa Cồng chiêng Tây Nguyên','Nhã nhạc cung đình','Dân ca quan họ','Hát xoan'],
  [3,'Kể một số cây công nghiệp lâu năm được trồng nhiều ở Tây Nguyên.','Cà phê, cao su, hồ tiêu, điều, chè.'],
  [3,'Vì sao cần bảo vệ rừng ở Tây Nguyên?','Rừng giữ đất, giữ nước cho mùa khô, bảo vệ động vật và điều hòa khí hậu; mất rừng gây hạn hán, lũ lụt.']
 ]);
 add('Lịch sử và Địa lí',4,'Nam Bộ',[
  [1,'Đồng bằng lớn nhất nước ta nằm ở vùng nào?','Nam Bộ (Đồng bằng sông Cửu Long)','Bắc Bộ','Tây Nguyên','Miền Trung'],
  [2,'Hệ thống sông lớn bồi đắp cho Đồng bằng Nam Bộ là sông nào?','Sông Mê Công (Cửu Long)','Sông Hồng','Sông Mã','Sông Cả'],
  [2,'Hình thức mua bán độc đáo trên sông nước ở Nam Bộ gọi là gì?','Chợ nổi','Chợ phiên','Chợ đêm','Hội chợ'],
  [3,'Vì sao Nam Bộ sản xuất được nhiều lúa gạo và trái cây để xuất khẩu?','Đất phù sa màu mỡ, nhiều sông ngòi kênh rạch, khí hậu nóng ẩm quanh năm nên cây trồng phát triển tốt, năng suất cao.'],
  [3,'Kể một di tích lịch sử nổi tiếng ở Nam Bộ và nêu hiểu biết ngắn.','VD: Địa đạo Củ Chi – hệ thống đường hầm trong kháng chiến; Bến Nhà Rồng – nơi Bác Hồ ra đi tìm đường cứu nước.']
 ]);
 add('Lịch sử và Địa lí',5,'Đất nước và con người Việt Nam',[
  [1,'Phần đất liền nước ta có dạng cong hình chữ gì?','Hình chữ S','Hình chữ O','Hình chữ U','Hình chữ L'],
  [2,'Vùng biển nước ta là một phần của biển nào?','Biển Đông','Biển Đỏ','Biển Đen','Biển Ban-tích']
 ]);
 add('Lịch sử và Địa lí',5,'Những quốc gia đầu tiên',[
  [1,'Kinh đô của nước Văn Lang đặt ở đâu?','Phong Châu (Phú Thọ ngày nay)','Cổ Loa','Hoa Lư','Thăng Long'],
  [2,'Ngoài Văn Lang – Âu Lạc, trên lãnh thổ nước ta thời cổ còn có quốc gia cổ nào ở miền Trung?','Vương quốc Chăm-pa','Vương quốc Anh','Nước Nhật','Nước Thái'],
  [2,'Nhà nước Văn Lang ra đời cách ngày nay khoảng mấy nghìn năm?','Khoảng 2700 năm (thế kỉ VII TCN)','Khoảng 200 năm','Khoảng 500 năm','Mới đây'],
  [3,'Vì sao các vua Hùng được nhân dân ta đời đời ghi nhớ?','Vì các vua Hùng có công dựng nước Văn Lang – nhà nước đầu tiên; thể hiện đạo lí "Uống nước nhớ nguồn".'],
  [4,'Sự ra đời của nhà nước Văn Lang có ý nghĩa gì đối với dân tộc ta?','Đánh dấu nước ta bước vào thời kì có nhà nước, mở đầu lịch sử dựng nước; là cội nguồn, niềm tự hào của dân tộc.']
 ]);
 add('Lịch sử và Địa lí',5,'Các nước láng giềng và thế giới',[
  [1,'Nước ta là thành viên của tổ chức các nước Đông Nam Á có tên viết tắt là gì?','ASEAN','WHO','FIFA','UNICEF'],
  [2,'Công trình kiến trúc nổi tiếng của Cam-pu-chia là gì?','Đền Ăng-co Vát','Vạn Lí Trường Thành','Tháp Ép-phen','Kim tự tháp'],
  [3,'Nêu lợi ích của việc nước ta hợp tác, giao lưu với các nước khác.','Phát triển kinh tế, học hỏi khoa học – kĩ thuật, giao lưu văn hóa, giữ gìn hòa bình và cùng nhau phát triển.']
 ]);

 /* ===================== TIẾNG VIỆT ===================== */
 add('Tiếng Việt',1,'Từ và câu',[
  [1,'Từ nào dưới đây chỉ hoạt động?','chạy','cái ghế','quả cam','màu đỏ'],
  [1,'Từ nào dưới đây chỉ màu sắc?','xanh','con chó','cái bàn','chạy nhảy'],
  [2,'Trong câu "Bé ngoan học giỏi", từ nào chỉ hoạt động?','học','Bé','ngoan','giỏi'],
  [2,'Đặt câu với từ "bà" nói về tình cảm của em.','VD: "Em rất yêu bà." (câu đủ ý, viết hoa đầu câu, cuối câu có dấu chấm).'],
  [3,'Tìm 2 từ chỉ người trong gia đình và đặt 1 câu với một từ.','VD: ông, mẹ. Câu: "Mẹ nấu cơm rất ngon."']
 ]);
 add('Tiếng Việt',1,'Đọc hiểu',[
  [1,'Trước khi trả lời câu hỏi về bài, em cần làm gì?','Đọc kĩ bài','Nhắm mắt đoán','Hỏi bạn ngay','Bỏ qua bài'],
  [2,'Tên bài (nhan đề) thường cho em biết điều gì?','Bài nói về điều gì','Giá quyển sách','Tên người in sách','Số trang'],
  [2,'Khi đọc, gặp từ chưa hiểu em nên làm gì?','Hỏi thầy cô, bố mẹ hoặc tra từ điển','Bỏ qua luôn','Đoán bừa','Đóng sách lại'],
  [3,'Kể lại ngắn gọn một câu chuyện em đã được đọc hoặc nghe.','HS kể được nội dung chính của một câu chuyện quen thuộc, có mở đầu – diễn biến – kết thúc.'],
  [2,'Đọc truyện giúp em điều gì?','Hiểu biết nhiều hơn, biết điều hay lẽ phải, đọc trôi chảy hơn.']
 ]);
 add('Tiếng Việt',2,'Chính tả',[
  [2,'Điền s hay x: "…e đạp", "dòng …ông".','xe đạp; dòng sông.'],
  [3,'Tìm và sửa lỗi: "Em quét nhà sạch xẽ."','Sửa "sạch xẽ" thành "sạch sẽ".']
 ]);
 add('Tiếng Việt',2,'Từ chỉ sự vật, hoạt động, đặc điểm',[
  [1,'Từ "bông hoa" là từ chỉ gì?','Sự vật','Hoạt động','Đặc điểm','Màu sắc riêng'],
  [2,'Trong câu "Chú gà trống gáy vang", từ nào chỉ hoạt động?','gáy','Chú','gà trống','vang'],
  [3,'Tìm 2 từ chỉ đặc điểm tả bầu trời và đặt 1 câu.','VD: trong xanh, cao rộng. Câu: "Bầu trời mùa thu trong xanh."']
 ]);
 add('Tiếng Việt',2,'Câu và dấu câu',[
  [1,'Cuối câu kể (câu trần thuật), ta dùng dấu gì?','Dấu chấm (.)','Dấu chấm hỏi (?)','Dấu phẩy (,)','Dấu hai chấm (:)'],
  [2,'Cuối câu bộc lộ cảm xúc (câu cảm) thường dùng dấu gì?','Dấu chấm than (!)','Dấu chấm (.)','Dấu phẩy (,)','Dấu ngoặc kép'],
  [2,'Câu nào dưới đây là câu hỏi?','Bạn đã làm bài chưa?','Em đi học.','Trời nắng to.','Hoa nở đẹp.'],
  [3,'Đặt một câu kể và một câu hỏi về việc học của em.','VD kể: "Em đang học bài." Hỏi: "Em đã học bài xong chưa?" (đúng dấu câu).'],
  [3,'Thêm dấu phẩy cho đúng: "Trong vườn hoa hồng hoa cúc hoa lan đua nhau nở."','"Trong vườn, hoa hồng, hoa cúc, hoa lan đua nhau nở."']
 ]);
 add('Tiếng Việt',2,'Viết đoạn',[
  [2,'Đoạn văn tả con vật nuôi nên nói đến những gì?','Hình dáng, hoạt động, ích lợi của con vật','Giá tiền con vật','Số nhà của em','Thời tiết nước ngoài'],
  [3,'Viết 3–4 câu kể về một đồ chơi em thích.','HS viết đoạn 3–4 câu: tên đồ chơi, hình dáng/màu sắc, vì sao thích; câu đúng, có dấu câu.'],
  [1,'Câu kết đoạn thường làm gì?','Nêu cảm nghĩ hoặc ý khép lại đoạn','Giới thiệu mở đầu','Ghi tên sách','Đánh số câu'],
  [2,'Vì sao cần đọc lại đoạn văn sau khi viết?','Để sửa lỗi chính tả, dấu câu và cho câu văn rõ ý hơn.']
 ]);
 add('Tiếng Việt',3,'Từ chỉ sự vật, hoạt động, đặc điểm',[
  [2,'Trong câu "Dòng sông xanh biếc uốn quanh làng", từ nào chỉ đặc điểm?','xanh biếc','Dòng sông','uốn quanh','làng'],
  [2,'Từ "học tập" thuộc nhóm từ chỉ gì?','Hoạt động','Sự vật','Đặc điểm','Màu sắc'],
  [3,'Đặt câu có cả từ chỉ hoạt động và từ chỉ đặc điểm.','VD: "Đàn chim hót líu lo (hoạt động) trên cành cây xanh (đặc điểm)."'],
  [3,'Tìm 3 từ chỉ đặc điểm của một người chăm chỉ.','VD: siêng năng, cần cù, chịu khó.']
 ]);
 add('Tiếng Việt',3,'Biện pháp so sánh',[
  [1,'Từ nào thường dùng để so sánh?','như','và','nhưng','vì'],
  [2,'Câu nào dưới đây có hình ảnh so sánh?','Trăng tròn như cái đĩa.','Trăng đã lên cao.','Trời tối rồi.','Em đi ngủ.'],
  [2,'Trong câu "Cô giáo hiền như mẹ hiền", cô giáo được so sánh với ai?','Mẹ hiền','Bạn bè','Cô tiên','Chị gái'],
  [3,'Đặt một câu có hình ảnh so sánh tả hàng cây hoặc cánh đồng.','VD: "Cánh đồng lúa chín vàng như tấm thảm khổng lồ."'],
  [4,'Nêu tác dụng của biện pháp so sánh trong câu "Những ngôi sao như những hạt ngọc lấp lánh".','So sánh ngôi sao với hạt ngọc làm câu văn sinh động, gợi hình ảnh đẹp, giúp người đọc dễ hình dung bầu trời đêm.']
 ]);
 add('Tiếng Việt',3,'Câu và dấu câu',[
  [1,'Dấu hai chấm (:) thường dùng để làm gì?','Báo hiệu lời liệt kê hoặc lời nói tiếp theo','Kết thúc câu hỏi','Ngăn cách các vế đối lập','Thể hiện cảm xúc mạnh'],
  [2,'Câu "Ôi, đẹp quá!" là loại câu gì?','Câu cảm','Câu hỏi','Câu kể','Câu khiến'],
  [2,'Câu khiến (câu cầu khiến) dùng để làm gì?','Nêu yêu cầu, đề nghị, mong muốn','Hỏi điều chưa biết','Kể lại sự việc','Chỉ bộc lộ cảm xúc'],
  [3,'Đặt một câu khiến đề nghị bạn giữ trật tự.','VD: "Các bạn hãy giữ trật tự nhé!" (có ý đề nghị, dấu câu phù hợp).']
 ]);
 add('Tiếng Việt',3,'Đọc hiểu',[
  [2,'Để tìm ý chính của bài, em nên chú ý câu nào?','Câu nêu nội dung bao quát (thường ở đầu hoặc cuối)','Câu khó nhất','Câu ngắn nhất','Câu cuối cùng bất kì'],
  [2,'Chi tiết trong bài giúp em điều gì?','Hiểu rõ và cụ thể hơn nội dung','Làm bài dài ra','Trang trí','Không có tác dụng'],
  [3,'Sau khi đọc một bài, hãy đặt một câu hỏi về nội dung bài đó.','HS đặt được câu hỏi đúng về nhân vật, sự việc hoặc ý nghĩa của bài.'],
  [4,'Vì sao hai người đọc cùng một bài có thể rút ra bài học khác nhau?','Vì mỗi người có suy nghĩ, trải nghiệm riêng nên cảm nhận và liên hệ khác nhau; miễn là bài học phù hợp với nội dung.']
 ]);
 add('Tiếng Việt',3,'Viết đoạn văn',[
  [2,'Khi tả cảnh, em nên tả theo trình tự nào cho hợp lí?','Từ bao quát đến chi tiết, hoặc theo không gian, thời gian','Lộn xộn','Chỉ tả một màu','Chỉ kể tên'],
  [3,'Viết 4–5 câu kể về một hoạt động em thích ở trường.','HS viết đoạn 4–5 câu: hoạt động gì, diễn ra thế nào, cảm nghĩ; câu đúng, mạch lạc.'],
  [2,'Để câu văn hay, em nên dùng thêm gì?','Hình ảnh so sánh, nhân hóa, từ gợi tả','Nhiều từ khó hiểu','Câu thật dài','Lặp lại một từ']
 ]);
 add('Tiếng Việt',4,'Danh từ, động từ, tính từ',[
  [1,'Từ "chạy, nhảy, học" thuộc từ loại nào?','Động từ','Danh từ','Tính từ','Quan hệ từ'],
  [2,'Trong câu "Bầu trời cao và trong xanh", từ "cao", "trong xanh" là từ loại gì?','Tính từ','Danh từ','Động từ','Số từ'],
  [3,'Đặt câu có đủ danh từ, động từ, tính từ.','VD: "Chú chó (danh từ) chạy (động từ) rất nhanh (tính từ)."']
 ]);
 add('Tiếng Việt',4,'Biện pháp nhân hóa',[
  [1,'Cách nào dưới đây là nhân hóa?','Gọi, tả vật bằng từ ngữ dùng cho người','So sánh hai sự vật','Liệt kê sự vật','Hỏi một điều'],
  [2,'Câu nào có dùng nhân hóa?','Bác gà trống gọi ông mặt trời dậy.','Gà trống gáy vào buổi sáng.','Mặt trời mọc ở đằng đông.','Buổi sáng trời đẹp.'],
  [3,'Đặt một câu nhân hóa tả đồ vật trong lớp học.','VD: "Chiếc bảng đen lặng lẽ nghe cô giảng bài."'],
  [4,'Nêu tác dụng của nhân hóa trong câu "Những hạt mưa tinh nghịch nhảy nhót trên mái nhà".','Làm hạt mưa trở nên sinh động, có hành động như con người (nhảy nhót, tinh nghịch), giúp câu văn gợi cảm, hình ảnh vui tươi.']
 ]);
 add('Tiếng Việt',4,'Câu: chủ ngữ, vị ngữ, trạng ngữ',[
  [1,'Bộ phận trả lời cho câu hỏi "Ai? / Con gì? / Cái gì?" là gì?','Chủ ngữ','Vị ngữ','Trạng ngữ','Dấu câu'],
  [2,'Trong câu "Sáng nay, em đi học sớm", bộ phận "Sáng nay" là gì?','Trạng ngữ (chỉ thời gian)','Chủ ngữ','Vị ngữ','Danh từ riêng'],
  [2,'Vị ngữ thường trả lời cho câu hỏi nào?','Làm gì? / Thế nào? / Là gì?','Ở đâu?','Khi nào?','Vì sao?'],
  [3,'Xác định chủ ngữ, vị ngữ trong câu "Đàn cò trắng bay lượn trên cánh đồng".','Chủ ngữ: "Đàn cò trắng"; vị ngữ: "bay lượn trên cánh đồng".']
 ]);
 add('Tiếng Việt',4,'Đọc hiểu',[
  [2,'Muốn hiểu ý nghĩa của một bài văn, em cần làm gì?','Đọc kĩ, suy nghĩ về điều tác giả muốn nói','Chỉ đọc nhan đề','Đọc thật nhanh','Chỉ xem tranh'],
  [2,'Hình ảnh so sánh, nhân hóa trong bài giúp người đọc điều gì?','Cảm nhận rõ, sinh động hơn','Khó hiểu hơn','Bài dài hơn','Không giúp gì'],
  [3,'Đọc một đoạn văn tả cảnh và cho biết cảnh được tả vào thời gian nào.','HS xác định đúng thời gian (buổi sáng, chiều, mùa...) dựa vào chi tiết trong đoạn.'],
  [4,'Vì sao tác giả thường dùng hình ảnh đẹp khi tả thiên nhiên?','Để bộc lộ tình cảm yêu mến thiên nhiên và giúp người đọc cảm nhận được vẻ đẹp, thêm yêu cảnh vật, quê hương.']
 ]);
 add('Tiếng Việt',4,'Viết bài văn',[
  [2,'Khi tả con vật, phần thân bài nên tả gì?','Hình dáng và hoạt động, thói quen của con vật','Giá tiền con vật','Địa chỉ nhà em','Thời khóa biểu'],
  [3,'Viết mở bài cho bài văn tả một con vật nuôi trong nhà.','HS viết mở bài giới thiệu con vật định tả (tên, của ai, ấn tượng chung), 2–3 câu.'],
  [3,'Nêu dàn ý ba phần cho bài văn tả một đồ vật em yêu thích.','Mở bài: giới thiệu đồ vật. Thân bài: tả hình dáng, bộ phận, công dụng. Kết bài: tình cảm của em.']
 ]);
 add('Tiếng Việt',5,'Từ đồng nghĩa, từ đa nghĩa',[
  [1,'Từ đồng nghĩa là những từ có nghĩa như thế nào?','Giống nhau hoặc gần giống nhau','Trái ngược nhau','Không liên quan','Viết giống nhau'],
  [2,'Từ nào đồng nghĩa với "to lớn"?','khổng lồ','nhỏ bé','tí hon','bé xíu'],
  [3,'Đặt câu với từ "ăn" theo nghĩa chuyển (đa nghĩa).','VD: "Chiếc áo này ăn màu." / "Xe ăn xăng." (nghĩa chuyển, không phải ăn cơm).'],
  [4,'Phân biệt nghĩa của từ "chạy" trong "em chạy nhanh" và "đồng hồ chạy đúng giờ".','"Chạy" (em chạy) chỉ hoạt động di chuyển nhanh bằng chân; "chạy" (đồng hồ chạy) chỉ sự hoạt động của máy móc. Đây là từ đa nghĩa.']
 ]);
 add('Tiếng Việt',5,'Đại từ, kết từ',[
  [1,'Từ nào dưới đây là đại từ xưng hô?','chúng em','bàn ghế','xinh đẹp','chạy nhảy'],
  [2,'Trong câu "Lan học giỏi nên bạn ấy được khen", từ "bạn ấy" thay cho ai?','Lan','người khác','cô giáo','mẹ Lan'],
  [3,'Đặt câu có cặp kết từ "vì... nên...".','VD: "Vì trời mưa to nên chúng em nghỉ đá bóng."'],
  [4,'Nêu tác dụng của việc dùng đại từ thay thế trong đoạn văn.','Tránh lặp lại một từ nhiều lần, giúp câu văn gọn gàng và liên kết chặt chẽ hơn.']
 ]);
 add('Tiếng Việt',5,'Câu ghép và liên kết câu',[
  [1,'Câu ghép có mấy vế câu trở lên?','Hai vế trở lên','Một vế','Không có vế','Chỉ có chủ ngữ'],
  [2,'Các vế của câu ghép thường được nối với nhau bằng gì?','Quan hệ từ hoặc dấu câu','Chỉ dấu chấm hỏi','Số thứ tự','Hình vẽ'],
  [3,'Đặt một câu ghép dùng cặp quan hệ từ "tuy... nhưng...".','VD: "Tuy trời rét nhưng các bạn vẫn đi học đầy đủ."'],
  [4,'Nêu một cách liên kết các câu trong đoạn văn và ví dụ.','Dùng từ ngữ nối (và, nhưng, vì vậy...) hoặc lặp từ, thay thế bằng đại từ. VD: "Lan rất chăm học. Vì vậy, bạn ấy luôn đạt điểm cao."']
 ]);
 add('Tiếng Việt',5,'Đọc hiểu',[
  [2,'Để hiểu sâu một bài đọc, sau khi đọc em nên làm gì?','Suy nghĩ về ý nghĩa, liên hệ bản thân','Quên ngay','Chỉ nhớ nhan đề','Đọc thêm bài khác'],
  [2,'Giọng điệu, hình ảnh trong bài thơ giúp thể hiện điều gì?','Tình cảm, cảm xúc của tác giả','Số câu của bài','Tên nhà in','Giá quyển sách'],
  [3,'Đọc một đoạn văn và nêu chủ đề của đoạn.','HS nêu đúng, ngắn gọn chủ đề (đoạn nói về điều gì).'],
  [4,'Vì sao cần liên hệ bài đọc với cuộc sống của mình?','Để hiểu sâu hơn, rút ra bài học và vận dụng điều hay vào thực tế cuộc sống.']
 ]);
 add('Tiếng Việt',5,'Viết bài văn',[
  [2,'Bài văn tả cảnh gồm những phần nào?','Mở bài, thân bài, kết bài','Chỉ thân bài','Chỉ mở bài','Hai phần bất kì'],
  [3,'Viết mở bài gián tiếp cho bài văn tả cảnh đẹp quê hương em.','HS viết mở bài dẫn dắt (từ câu thơ, kỉ niệm, cảm xúc...) rồi giới thiệu cảnh định tả.'],
  [3,'Nêu dàn ý thân bài cho bài văn tả một người thân.','Tả ngoại hình tiêu biểu; tả hoạt động, việc làm; tả tính cách; xen kẽ tình cảm của em.']
 ]);

})();
