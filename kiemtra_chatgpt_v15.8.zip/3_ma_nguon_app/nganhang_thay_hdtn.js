/* NGÂN HÀNG HOẠT ĐỘNG TRẢI NGHIỆM – LỚP 2–9 — bù câu đặc thù theo lớp. Câu hỏi nguyên bản, bám SGK Kết nối tri thức. */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Hoạt động trải nghiệm';
 /* Bảo đảm chủ đề tồn tại đúng tên trước khi add (tránh khớp mờ chuỗi con giữa "Kĩ năng sống, bản thân", "(Bổ sung) Kĩ năng sống", "Trách nhiệm cộng đồng và hướng nghiệp", "Trách nhiệm với gia đình, cộng đồng và hướng nghiệp") */
 function pre(lop,cd){
  if(!NH[M])NH[M]={};
  if(!Array.isArray(NH[M][lop]))NH[M][lop]=[];
  if(!NH[M][lop].some(function(x){return x.cd===cd;}))NH[M][lop].push({cd:cd,q:[]});
 }
 [2,3,4,5].forEach(function(l){['Khám phá bản thân','Gia đình, trường lớp','Cộng đồng và môi trường','Nghề nghiệp','An toàn và kĩ năng sống'].forEach(function(c){pre(l,c);});});
 [7,8,9].forEach(function(l){['Kĩ năng sống, bản thân','Trách nhiệm với gia đình, cộng đồng và hướng nghiệp','Phát triển bản thân','Trách nhiệm cộng đồng và hướng nghiệp','(Bổ sung) Kĩ năng sống'].forEach(function(c){pre(l,c);});});

 /* ===== LỚP 2 ===== */
 add(M,2,'Khám phá bản thân',[
  [1,'Nụ cười thân thiện khi gặp bạn bè, thầy cô giúp em điều gì?','Tạo thiện cảm, giúp mọi người thấy em gần gũi, dễ mến','Làm bạn sợ và tránh xa em','Khiến em bị thầy cô nhắc nhở','Không có tác dụng gì'],
  [2,'Sau khi tan học về nhà, việc sắp xếp sách vở, quần áo gọn gàng vào đúng chỗ thể hiện em là người như thế nào?','Có nếp sống ngăn nắp, biết tự phục vụ','Lười biếng, ỷ lại','Chỉ làm khi bị bố mẹ nhắc','Thích khoe đồ dùng của mình'],
  [2,'Khi bạn Hoa được cô khen vì viết chữ đẹp, bạn Nam cũng được khen vì chạy nhanh nhất lớp. Điều này cho thấy điều gì?','Mỗi bạn có một điểm mạnh khác nhau, ai cũng có điểm đáng khen','Chỉ bạn Hoa mới có điểm mạnh','Chạy nhanh không phải là điểm mạnh','Bạn Nam cần bỏ chạy để tập viết'],
  [3,'Em hãy nêu ba việc em làm mỗi sáng để có hình ảnh gọn gàng, tươi tắn khi đến lớp và ba cách em chào hỏi thân thiện với bạn bè, thầy cô.','Gợi ý: đánh răng, rửa mặt, chải tóc; mặc đồng phục sạch, bỏ áo trong quần/đeo khăn quàng ngay ngắn; kiểm tra lại cặp sách. Chào hỏi thân thiện: mỉm cười và nói "Chào bạn/Em chào cô", vẫy tay, nhìn vào người mình chào, nói lời cảm ơn, xin lỗi đúng lúc.']
 ]);
 add(M,2,'Gia đình, trường lớp',[
  [1,'Khi ông bà ở quê lên thăm, việc nào thể hiện em biết quan tâm đến ông bà?','Chào hỏi, rót nước mời ông bà, hỏi thăm sức khỏe và trò chuyện cùng ông bà','Tiếp tục chơi điện tử không để ý','Nhờ ông bà làm việc nhà cho mình','Đòi ông bà mua quà rồi mới chào'],
  [2,'Lớp 2A cùng nhau trang trí góc học tập, chăm sóc chậu cây của lớp. Việc này thể hiện điều gì?','Các bạn biết cùng nhau xây dựng lớp học sạch đẹp, thân thiện','Các bạn làm việc riêng trong giờ học','Chỉ lớp trưởng mới cần làm việc này','Các bạn muốn được cô thưởng điểm'],
  [2,'Khi em muốn được bố mẹ cho đi chơi công viên vào cuối tuần, cách nói nào là lễ phép và phù hợp?','"Bố mẹ ơi, cuối tuần này cả nhà mình đi công viên được không ạ?"','"Phải cho con đi công viên!"','Khóc và giận bố mẹ cho đến khi được đồng ý','Tự đi mà không xin phép'],
  [3,'Em hãy kể ba việc nhà phù hợp với học sinh lớp 2 mà em có thể làm hằng ngày và nói rõ em làm vào lúc nào trong ngày.','Gợi ý: gấp chăn màn sau khi ngủ dậy; quét nhà hoặc lau bàn sau bữa ăn; tưới cây, cho vật nuôi ăn vào buổi chiều; xếp bát đũa, dọn mâm cơm cùng mẹ vào bữa tối; cất đồ chơi, sách vở trước khi đi ngủ.']
 ]);
 add(M,2,'Cộng đồng và môi trường',[
  [1,'Khi đi bộ qua đường ở nơi có đèn tín hiệu, em được đi khi nào?','Khi đèn dành cho người đi bộ chuyển màu xanh và đã quan sát hai bên','Khi đèn đỏ vì xe đang dừng hết','Bất cứ lúc nào thấy đường vắng','Khi có bạn chạy sang trước'],
  [2,'Đến dự lễ hội ở quê, em thấy một số người chen lấn, xô đẩy để vào xem trước. Em nên làm gì?','Xếp hàng trật tự, đi cùng người lớn, không chen lấn','Chen lấn theo mọi người cho nhanh','Hò hét để mọi người tránh đường','Bỏ về vì không thích lễ hội'],
  [2,'Chú hàng xóm bị ốm, không ra ngoài được. Việc nào em có thể làm để thể hiện tình làng nghĩa xóm?','Cùng bố mẹ sang hỏi thăm, giúp việc nhỏ như lấy giúp đồ, gọi người lớn khi cần','Đứng ngoài cửa nhìn vào rồi bỏ đi','Kể chuyện chú ốm với bạn bè cho vui','Không quan tâm vì không phải người nhà'],
  [3,'Em hãy kể tên một lễ hội hoặc hoạt động chung ở nơi em sống (ví dụ Tết Trung thu, dọn vệ sinh ngõ phố) và nêu ba việc em cần làm để giữ an toàn, lịch sự khi tham gia.','Gợi ý: nêu đúng tên hoạt động ở địa phương. Việc cần làm: luôn đi cùng người lớn, không chạy lung tung, nhớ số điện thoại bố mẹ; không chen lấn, không nói to, xếp hàng; bỏ rác đúng nơi, không bẻ cành hái hoa, không phá đồ trang trí; chào hỏi lễ phép với mọi người.']
 ]);
 add(M,2,'Nghề nghiệp',[
  [1,'Người lái xe đưa đón hành khách trên các tuyến xe buýt làm nghề gì?','Lái xe (tài xế)','Thợ sửa xe','Công an giao thông','Bán vé'],
  [2,'Mẹ bạn An là y tá ở trạm y tế, bố bạn An là thợ điện. Hai nghề này giống nhau ở điểm nào?','Đều là công việc có ích, giúp đỡ mọi người trong cuộc sống','Đều làm việc trong bệnh viện','Đều dùng kim tiêm làm dụng cụ','Đều không cần học nghề'],
  [2,'Khi tìm hiểu nghề của bố mẹ, em có thể hỏi điều gì để hiểu rõ hơn về nghề đó?','Hằng ngày bố mẹ làm những việc gì, ở đâu, dùng dụng cụ gì','Bố mẹ kiếm được bao nhiêu tiền mỗi ngày','Bố mẹ có hay bị mắng không','Bố mẹ có thích nghỉ việc không'],
  [3,'Em hãy chọn một nghề của người thân trong gia đình và nói về nghề đó theo ba ý: tên nghề, nơi làm việc, một dụng cụ hoặc đồ dùng gắn với nghề.','Gợi ý ví dụ: Mẹ em làm nghề may; mẹ làm ở xưởng may gần nhà; dụng cụ là máy may, kéo, thước dây. Hoặc: Bố em là thợ xây; bố làm ở công trình; dụng cụ là bàn xoa, thước, xô đựng vữa, mũ bảo hộ. Học sinh nêu đúng ba ý và nói được một điều em quý ở nghề đó.']
 ]);
 add(M,2,'An toàn và kĩ năng sống',[
  [1,'Khi chơi ở sân trường, trò chơi nào có thể gây nguy hiểm cần tránh?','Đuổi nhau xô đẩy ở cầu thang, trèo lên lan can','Nhảy dây ở sân trống','Chơi ô ăn quan dưới gốc cây','Đá cầu ở sân thể thao'],
  [2,'Khi bị bạn lớn hơn trêu chọc, giật đồ nhiều lần, cách ứng xử nào là đúng?','Nói to, dứt khoát "Dừng lại!", đi khỏi chỗ đó và kể với thầy cô, bố mẹ','Im lặng chịu đựng, không kể với ai','Đánh lại bạn cho hả giận','Lấy đồ của bạn khác để bù lại'],
  [2,'Khi ở nhà có mùi khét và thấy khói bốc lên từ ổ điện, em nên làm gì?','Không lại gần, chạy ra ngoài gọi người lớn hoặc gọi 114','Lấy nước dội vào ổ điện','Dùng tay rút phích cắm thật nhanh','Ngồi yên chờ khói tự hết'],
  [3,'Em hãy nêu ba quy tắc an toàn khi vui chơi ở sân trường và ở công viên để không bị thương.','Gợi ý: không chạy nhảy, xô đẩy ở cầu thang, hành lang, nơi trơn trượt; không trèo cây, trèo lan can, không chơi gần ao hồ, đường xe chạy; dùng đồ chơi, xích đu, cầu trượt đúng cách và chờ đến lượt; không chơi với vật sắc nhọn, que, đá; nếu bị thương báo ngay cho người lớn.']
 ]);

 /* ===== LỚP 3 ===== */
 add(M,3,'Khám phá bản thân',[
  [1,'Sở trường của một người là gì?','Việc mà người đó làm tốt, làm giỏi hơn hẳn các việc khác','Việc mà người đó chưa làm được','Môn học người đó sợ nhất','Thói quen xấu của người đó'],
  [2,'Bạn Lâm hay nổi nóng khi thua trong trò chơi. Cách nào giúp Lâm kiểm soát cơn tức giận tốt nhất?','Dừng lại, hít thở sâu và đếm từ 1 đến 10 rồi mới nói','Hét to cho hết bực','Bỏ về và không chơi với các bạn nữa','Đổ lỗi cho bạn chơi gian'],
  [3,'Em hãy giới thiệu một nét riêng của bản thân (về ngoại hình, giọng nói, sở thích hoặc sở trường) và nêu cách em giữ gìn, phát huy nét riêng đó.','Gợi ý: nêu một nét riêng cụ thể (ví dụ: em hát hay, em có nụ cười tươi, em vẽ đẹp, em nói nhanh). Cách phát huy: luyện tập thường xuyên, tham gia câu lạc bộ, biểu diễn trong giờ sinh hoạt lớp; tự tin về nét riêng của mình và tôn trọng nét riêng của bạn.']
 ]);
 add(M,3,'Gia đình, trường lớp',[
  [1,'Khi ông bà kể cho em nghe về những kỉ niệm ngày xưa của gia đình, việc đó giúp em điều gì?','Hiểu thêm về truyền thống gia đình và yêu quý ông bà hơn','Biết cách chơi trò chơi điện tử mới','Có thêm tiền tiêu vặt','Không giúp gì cho em'],
  [2,'Tuần này gia đình em dự định cùng về quê thăm ông bà vào Chủ nhật. Em nên chuẩn bị gì để góp phần vào hoạt động chung đó?','Làm xong bài tập trước, chuẩn bị quần áo gọn gàng và nghĩ một món quà nhỏ tặng ông bà','Đòi mang theo thật nhiều đồ chơi','Xin ở nhà để chơi với bạn','Để bố mẹ chuẩn bị hết mọi việc'],
  [3,'Em hãy kể về một việc em đã làm để góp phần giữ gìn lớp học sạch đẹp, thân thiện trong tuần qua và nói cảm xúc của em khi làm việc đó.','Gợi ý: ví dụ em lau bảng, kê lại bàn ghế, tưới cây, nhặt rác trong lớp, trang trí góc sáng tạo, nhắc bạn bỏ rác đúng chỗ, giúp bạn ốm ghi bài. Cảm xúc: vui, tự hào vì lớp sạch đẹp hơn, được bạn bè và cô giáo ghi nhận.']
 ]);
 add(M,3,'Cộng đồng và môi trường',[
  [1,'Khi đi xe đạp đến trường, em nên đội gì để bảo vệ đầu khi chẳng may bị ngã?','Mũ bảo hiểm cài khóa chắc chắn','Mũ lưỡi trai cho đẹp','Mũ len giữ ấm','Không cần đội vì đi gần'],
  [2,'Lớp em quyên góp quần áo cũ còn tốt gửi các bạn vùng cao. Trước khi gửi, em nên làm gì với quần áo?','Giặt sạch, gấp gọn, phân loại theo kích cỡ để các bạn dùng được ngay','Gửi nguyên quần áo rách, bẩn vì là đồ cho','Chỉ gửi những bộ em không thích','Để bố mẹ gửi gì cũng được'],
  [2,'Hành vi nào sau đây gây ô nhiễm không khí ở khu dân cư?','Đốt rác, đốt lá cây ngoài đường','Trồng thêm cây xanh ven đường','Đi bộ, đi xe đạp đến trường','Phân loại rác tại nhà'],
  [3,'Em hãy nêu các quy tắc an toàn khi đi xe đạp trên đường mà học sinh lớp 3 cần nhớ.','Gợi ý: đội mũ bảo hiểm; đi sát bên phải đường, đi đúng phần đường cho xe đạp; không dàn hàng ngang, không buông hai tay, không đèo quá số người; quan sát và giơ tay báo hiệu khi rẽ; dừng lại khi đèn đỏ, nhường đường cho người đi bộ; kiểm tra phanh, lốp trước khi đi.']
 ]);
 add(M,3,'Nghề nghiệp',[
  [1,'Sản phẩm của nghề làm nón lá, nghề dệt chiếu là gì?','Nón lá, chiếu – những đồ dùng thủ công truyền thống','Gạo, ngô, khoai','Máy tính, điện thoại','Thuốc chữa bệnh'],
  [2,'Nghề làm gốm ở Bát Tràng được gọi là nghề truyền thống vì sao?','Vì nghề đó có từ lâu đời, được truyền từ đời này sang đời khác và gắn với một địa phương','Vì nghề đó mới xuất hiện gần đây','Vì nghề đó chỉ dùng máy móc hiện đại','Vì ai cũng có thể làm trong một ngày'],
  [2,'Khi đến thăm xưởng mộc, điều nào dưới đây là KHÔNG an toàn?','Tự ý cầm cưa, bào để thử làm','Đứng xa máy đang chạy theo hướng dẫn của bác thợ','Đeo khẩu trang khi có bụi gỗ','Quan sát và ghi chép công việc của bác thợ'],
  [3,'Em hãy giới thiệu nghề của một người thân (bố, mẹ, ông, bà, cô, chú) theo các ý: tên nghề, công việc hằng ngày, một khó khăn của nghề và điều em học được từ người đó.','Gợi ý: ví dụ bác em làm nghề đánh cá; hằng ngày ra biển từ sớm, gỡ lưới, bán cá; khó khăn là sóng to, thức đêm; em học được sự chăm chỉ, chịu khó. Học sinh nêu đủ bốn ý, thể hiện sự tôn trọng nghề.']
 ]);
 add(M,3,'An toàn và kĩ năng sống',[
  [1,'Khi đang dùng máy tính, có cửa sổ hiện lên yêu cầu nhập tên, địa chỉ nhà và số điện thoại của bố mẹ để nhận quà. Em nên làm gì?','Không nhập, đóng cửa sổ và báo cho bố mẹ','Nhập ngay để nhận quà','Chỉ nhập tên, không nhập số điện thoại','Hỏi bạn cùng lớp rồi nhập'],
  [2,'Đang đi học về thì trời đổ mưa to, sấm sét liên tục. Nơi trú an toàn nhất là ở đâu?','Vào nhà, trường học hoặc cửa hàng gần nhất có mái che kín','Dưới gốc cây to ven đường','Cạnh cột điện để tránh gió','Đứng giữa sân rộng cho thoáng'],
  [2,'Khi chơi gần ao, hồ, một bạn trượt chân rơi xuống nước. Việc nào là đúng?','Hô to gọi người lớn, ném cho bạn vật nổi như phao, can nhựa, cành cây dài','Nhảy ngay xuống kéo bạn lên','Chạy về nhà không nói với ai','Đứng xem bạn tự bơi lên'],
  [3,'Em hãy nêu các việc cần làm để an toàn khi dùng in-tơ-nét ở lứa tuổi lớp 3.','Gợi ý: chỉ dùng khi có bố mẹ cho phép và trong thời gian quy định; không chia sẻ tên, địa chỉ, trường học, ảnh của mình và gia đình; không trò chuyện, không gặp người lạ quen trên mạng; không nhấn vào đường dẫn, quảng cáo lạ; khi thấy nội dung đáng sợ hoặc bị người lạ làm phiền phải báo ngay cho bố mẹ, thầy cô.']
 ]);

 /* ===== LỚP 4 ===== */
 add(M,4,'Khám phá bản thân',[
  [1,'"Cẩn thận, chu đáo, hay giúp đỡ người khác" là đặc điểm thuộc về điều gì của một người?','Tính cách','Ngoại hình','Sức khỏe','Sở hữu đồ dùng'],
  [2,'Sắp đến buổi thuyết trình nhóm, bạn Hà lo lắng đến mất ngủ. Việc nào giúp Hà điều chỉnh cảm xúc tích cực nhất?','Tập nói trước gương, hít thở sâu và nghĩ rằng mình đã chuẩn bị kĩ','Xin cô cho nghỉ buổi thuyết trình','Nhờ bạn khác nói thay toàn bộ','Thức khuya thêm để học thuộc từng chữ'],
  [2,'Bạn Minh bị điểm thấp môn Toán. Suy nghĩ nào là suy nghĩ tích cực?','"Mình sẽ xem lại lỗi sai để lần sau làm tốt hơn."','"Mình kém, chẳng bao giờ học được Toán."','"Do cô ra đề khó nên không phải lỗi của mình."','"Thôi, không cần cố nữa."'],
  [3,'Em hãy kể một tình huống em đã suy nghĩ tích cực khi gặp việc không như ý (ví dụ trời mưa không đi chơi được, bị bạn trách nhầm) và nêu kết quả của cách suy nghĩ đó.','Gợi ý: nêu tình huống cụ thể, suy nghĩ tiêu cực có thể nảy ra, suy nghĩ tích cực em đã chọn (ví dụ: không đi chơi thì tranh thủ đọc sách cùng em; bạn trách nhầm thì bình tĩnh giải thích). Kết quả: tâm trạng nhẹ nhàng, không cãi vã, giữ được tình bạn, làm được việc có ích.']
 ]);
 add(M,4,'Gia đình, trường lớp',[
  [1,'Mẹ bị sốt, phải nằm nghỉ. Việc nào em có thể tự làm để chăm sóc mẹ?','Lấy nước ấm, khăn ấm, giữ nhà yên tĩnh và trông em cho mẹ nghỉ','Mở ti vi to để mẹ đỡ buồn','Rủ bạn về nhà chơi cho vui','Đòi mẹ nấu món em thích'],
  [2,'Trường em có truyền thống "Nuôi heo đất giúp bạn nghèo" mỗi năm. Việc em góp phần tiếp nối truyền thống này là gì?','Dành một phần tiền tiêu vặt để góp đều đặn và vận động bạn bè cùng tham gia','Chỉ góp khi được điểm thưởng','Nói với các bạn rằng việc này không cần thiết','Lấy tiền của bố mẹ góp thật nhiều để được khen'],
  [2,'Khi anh trai đang ôn thi căng thẳng, em nên làm gì để thể hiện sự quan tâm phù hợp?','Giữ yên lặng, không làm phiền, có thể mang nước hoặc hỏi anh có cần giúp gì','Mở nhạc to để anh thư giãn','Liên tục vào hỏi anh học đến đâu','Trêu anh để anh vui'],
  [3,'Em hãy lập kế hoạch chăm sóc một người thân trong gia đình trong một tuần (ví dụ ông bà, em nhỏ), gồm: việc làm, thời gian, kết quả mong muốn.','Gợi ý bảng kế hoạch: Thứ Hai – đọc truyện cho em nghe 20 phút buổi tối; Thứ Ba – xoa bóp vai cho ông 10 phút; Thứ Tư – cùng bà tưới cây lúc 5 giờ chiều; Thứ Năm – nhắc ông uống thuốc đúng giờ… Kết quả mong muốn: người thân vui, khỏe hơn, gia đình gắn bó; em rèn được tính quan tâm, trách nhiệm.']
 ]);
 add(M,4,'Cộng đồng và môi trường',[
  [1,'Trong rạp chiếu phim, thư viện, hành vi nào là ứng xử có văn hóa?','Nói nhỏ, để điện thoại im lặng, không ăn uống gây mùi, bỏ rác đúng chỗ','Nói chuyện to cho bạn ở xa nghe rõ','Gác chân lên ghế trước','Chụp ảnh có đèn flash liên tục'],
  [2,'Hiện tượng nào sau đây là biểu hiện của biến đổi khí hậu?','Mùa hè nóng hơn, bão lũ và hạn hán xảy ra bất thường hơn trước','Ngày và đêm luân phiên nhau','Mưa vào mùa mưa như mọi năm','Trăng tròn vào giữa tháng âm lịch'],
  [2,'Việc nào của học sinh góp phần giảm tác động của biến đổi khí hậu?','Đi bộ, đi xe đạp đến trường, tắt điện khi ra khỏi phòng, trồng cây','Dùng nhiều túi ni-lông vì tiện','Bật điều hòa cả ngày cho mát','Đốt rác ngoài vườn'],
  [3,'Em hãy đề xuất ba việc lớp em có thể làm để ứng phó với biến đổi khí hậu ngay tại trường và giải thích vì sao mỗi việc đó có ích.','Gợi ý: trồng và chăm sóc cây xanh trong sân trường vì cây hấp thụ khí các-bô-níc, tạo bóng mát; tắt đèn, quạt khi ra khỏi lớp để tiết kiệm điện, giảm khí thải từ sản xuất điện; mang bình nước cá nhân, hạn chế chai nhựa dùng một lần để giảm rác thải; tuyên truyền bằng tranh vẽ, bảng tin để nhiều bạn cùng làm.']
 ]);
 add(M,4,'Nghề nghiệp',[
  [1,'Nghề nào sau đây đòi hỏi người làm phải leo cao và luôn đeo dây an toàn, đội mũ bảo hộ?','Thợ điện lắp đặt đường dây trên cột điện','Thu ngân siêu thị','Giáo viên tiểu học','Nhân viên văn phòng'],
  [2,'Vì sao mỗi nghề lại có quy định về trang phục và dụng cụ bảo hộ riêng?','Vì mỗi nghề có những nguy cơ khác nhau nên cần cách bảo vệ phù hợp','Vì để phân biệt người giàu, người nghèo','Vì trang phục đẹp sẽ làm việc tốt hơn','Vì quy định bắt buộc cho tất cả mọi nghề giống nhau'],
  [3,'Em mơ ước làm nghề gì? Hãy nêu hai phẩm chất và hai kĩ năng nghề đó cần và cho biết từ bây giờ em rèn luyện chúng bằng cách nào ở trường, ở nhà.','Gợi ý: ví dụ nghề giáo viên – phẩm chất kiên nhẫn, yêu thương trẻ; kĩ năng nói rõ ràng, giải thích dễ hiểu. Rèn luyện: tập hướng dẫn bài cho em nhỏ, tham gia thuyết trình trước lớp, giữ bình tĩnh khi bạn hỏi nhiều lần, đọc thêm sách. Học sinh nêu rõ nghề, đủ hai phẩm chất, hai kĩ năng và cách rèn luyện cụ thể.']
 ]);
 add(M,4,'An toàn và kĩ năng sống',[
  [1,'Quy tắc "5 ngón tay" giúp em phân biệt điều gì?','Những người được phép và không được phép có hành vi gần gũi với cơ thể em','Năm việc cần làm khi có cháy','Cách đếm tiền tiêu vặt','Năm bước làm bài kiểm tra'],
  [2,'Một người quen của gia đình thường rủ em vào phòng riêng, đóng cửa và bảo "đây là bí mật của hai người". Em nên làm gì?','Từ chối, không giữ bí mật đó và kể ngay với bố mẹ hoặc người lớn em tin tưởng','Giữ bí mật vì đó là người quen','Đồng ý để người đó không giận','Chỉ kể với bạn cùng lớp'],
  [2,'Em có 50.000 đồng, muốn mua một cuốn truyện 45.000 đồng và một que kem 15.000 đồng nhưng không đủ tiền mua cả hai. Cách chi tiêu nào là hợp lí nhất?','Chọn mua thứ cần hơn (cuốn truyện) và để dành phần còn lại; thứ kia mua dịp khác nếu còn cần','Mua cả hai rồi xin thêm tiền bố mẹ','Vay tiền bạn để mua đủ cả hai','Mua kem trước, truyện để sau vì đang thèm'],
  [3,'Em hãy nêu các bước xử lí khi em bị một bạn trong lớp bắt nạt nhiều lần (bị gọi bằng tên xấu, bị giấu đồ).','Gợi ý: giữ bình tĩnh, nói dứt khoát với bạn rằng em không thích và yêu cầu dừng lại; tránh xa chỗ vắng, luôn ở gần bạn bè tin cậy; kể ngay với thầy cô, bố mẹ, không im lặng chịu đựng; ghi nhớ hoặc nhờ bạn làm chứng; không đánh lại hay trả thù; nếu việc tiếp diễn thì tiếp tục báo cho người lớn đến khi được giải quyết.']
 ]);

 /* ===== LỚP 5 ===== */
 add(M,5,'Khám phá bản thân',[
  [1,'Việc nào thể hiện em biết quản lí thời gian hợp lí?','Lập thời gian biểu và hoàn thành bài tập trước khi xem phim, chơi game','Học bài đến khuya vì ban ngày chơi hết giờ','Làm nhiều việc cùng lúc cho nhanh','Để việc hôm nay sang ngày mai'],
  [2,'Khi lên lớp 5, nhiều bạn bắt đầu thấy ngại ngùng, muốn có không gian riêng, dễ xúc động hơn. Em nên nhìn nhận điều này như thế nào?','Đó là sự thay đổi bình thường của lứa tuổi, cần hiểu và biết cách chăm sóc bản thân','Đó là biểu hiện của người hư, cần che giấu','Chỉ bạn nữ mới có thay đổi này','Không cần quan tâm vì sẽ tự hết'],
  [2,'Bạn Vy nhặt được 200.000 đồng trong sân trường. Hành động nào thể hiện lòng tự trọng?','Mang nộp cho thầy cô để trả lại người đánh mất','Giữ lại vì không ai biết','Chia cho bạn thân để giữ bí mật','Mua quà cho cả lớp'],
  [3,'Em hãy phân tích vì sao biết quản lí thời gian lại giúp học sinh lớp 5 vừa học tốt, vừa có thời gian vui chơi, giúp gia đình và chuẩn bị tốt cho việc lên lớp 6.','Gợi ý: học sinh lớp 5 có nhiều môn, nhiều hoạt động hơn, lên lớp 6 còn nhiều hơn nữa; quản lí thời gian giúp sắp xếp việc quan trọng trước, tránh dồn việc, giảm căng thẳng; có thời gian cố định cho học, chơi, việc nhà nên không bỏ sót việc nào; rèn được tính kỉ luật, tự giác – nền tảng để tự học ở bậc trung học cơ sở.']
 ]);
 add(M,5,'Gia đình, trường lớp',[
  [1,'Khi gia đình phải tiết kiệm chi tiêu, việc nào của em là phù hợp?','Không đòi mua đồ chơi, đồ ăn vặt không cần thiết; giữ gìn sách vở, quần áo để dùng lâu','Đòi mua điện thoại mới để bằng bạn','Lấy tiền tiết kiệm của bố mẹ đi chơi','Giấu bố mẹ xin tiền ông bà'],
  [2,'Hai bạn thân cãi nhau vì một bạn kể bí mật của bạn kia cho người khác. Để giữ tình bạn, bạn kể bí mật nên làm gì?','Thành thật nhận lỗi, xin lỗi và hứa không tái phạm','Nói rằng chuyện đó không quan trọng','Kể thêm để mọi người cùng biết','Chờ bạn kia hết giận rồi coi như không có gì'],
  [2,'Việc nào thể hiện em chủ động chia sẻ việc nhà khi bố mẹ đi làm về muộn?','Tự nấu cơm đơn giản, dọn nhà và trông em mà không cần nhắc','Chờ bố mẹ về rồi mới hỏi phải làm gì','Gọi điện giục bố mẹ về sớm','Để em nhỏ tự chơi, mình xem ti vi'],
  [3,'Em hãy lập kế hoạch cho một buổi "họp mặt lớp cuối cấp" của lớp 5 với các mục: mục đích, thời gian, nội dung hoạt động, phân công chuẩn bị, dự kiến chi phí tiết kiệm.','Gợi ý: mục đích – tri ân thầy cô, lưu giữ kỉ niệm trước khi chia tay trường tiểu học; thời gian – một buổi chiều cuối tháng 5 tại lớp; nội dung – chiếu ảnh kỉ niệm, viết lời nhắn gửi bạn, văn nghệ, trò chơi; phân công – nhóm ảnh, nhóm văn nghệ, nhóm trang trí, nhóm hậu cần; chi phí – tự làm thiệp, trang trí bằng vật liệu tái chế, mỗi bạn góp một phần nhỏ, mời bố mẹ hỗ trợ bánh kẹo.']
 ]);
 add(M,5,'Cộng đồng và môi trường',[
  [1,'Khi gặp du khách nước ngoài hỏi đường ở điểm du lịch, cách ứng xử nào là văn minh?','Mỉm cười, cố gắng chỉ đường bằng câu đơn giản hoặc chỉ tay, nhờ người lớn giúp nếu không hiểu','Bỏ chạy vì không biết tiếng Anh','Cười to và chỉ trỏ vào trang phục của họ','Đòi tiền rồi mới chỉ đường'],
  [2,'Việc nào góp phần bảo tồn cảnh quan thiên nhiên khi đi tham quan rừng, biển, hang động?','Đi theo lối quy định, không khắc vẽ lên đá, không mang sinh vật về làm kỉ niệm','Bẻ nhũ đá nhỏ làm quà','Thả rác xuống biển vì nước sẽ cuốn đi','Cho khỉ, chim ăn đồ ăn của mình'],
  [2,'Vì sao các di tích lịch sử ở địa phương cần được bảo vệ?','Vì đó là bằng chứng về lịch sử, văn hóa của cha ông, giúp thế hệ sau hiểu và tự hào về quê hương','Vì di tích chỉ dùng để thu tiền khách du lịch','Vì di tích là nơi để tổ chức ăn uống','Vì không bảo vệ sẽ bị phạt tiền rất nặng'],
  [3,'Em hãy thiết kế nội dung một tờ rơi tuyên truyền bảo vệ cảnh quan thiên nhiên hoặc di tích ở địa phương em: tên gọi, ba thông điệp chính, hình ảnh gợi ý, đối tượng phát tờ rơi.','Gợi ý: tên – "Giữ xanh bãi biển quê em" / "Di tích là của chúng ta"; thông điệp – không xả rác, không khắc vẽ, không hái hoa bẻ cành; hình ảnh – cảnh đẹp địa phương, thùng rác phân loại, hình ảnh bàn tay nắm cây; đối tượng – du khách, học sinh, người dân; cách phát – tại cổng trường, điểm du lịch, nhà văn hóa vào dịp lễ hội.']
 ]);
 add(M,5,'Nghề nghiệp',[
  [1,'Người viết chương trình cho máy tính, điện thoại hoạt động làm nghề gì?','Lập trình viên','Thợ sửa điện thoại','Nhân viên bán máy tính','Kĩ sư xây dựng'],
  [2,'Nghề nào sau đây có thể phát triển mạnh trong tương lai do công nghệ và nhu cầu xã hội thay đổi?','Chuyên gia về trí tuệ nhân tạo, kĩ sư năng lượng tái tạo, chăm sóc người cao tuổi','Người đưa thư bằng ngựa','Người quay số điện thoại tổng đài bằng tay','Người thắp đèn đường'],
  [2,'Khi trải nghiệm bán hàng phụ giúp gia đình trong dịp hè, em rèn luyện được kĩ năng gì?','Giao tiếp, tính toán tiền, sắp xếp hàng hóa và chịu trách nhiệm với công việc','Chỉ học được cách xem ti vi','Không học được gì vì việc nhỏ','Biết cách tránh làm việc nhà'],
  [3,'Em hãy so sánh hai nghề: một nghề thuộc lĩnh vực công nghệ thông tin và một nghề thuộc lĩnh vực nghệ thuật về công việc chính, nơi làm việc, phẩm chất cần có và cho biết nghề nào gần với sở thích, khả năng của em hơn, vì sao.','Gợi ý: lập trình viên – viết phần mềm, làm ở công ty, cần tư duy lô-gic, kiên trì, cẩn thận; họa sĩ/ca sĩ – sáng tạo tác phẩm, làm ở xưởng vẽ, sân khấu, cần óc sáng tạo, cảm xúc, chăm luyện tập. Học sinh tự đối chiếu với sở thích (thích máy tính, giải đố hay thích vẽ, hát) và khả năng của mình để chọn và giải thích hợp lí.']
 ]);
 add(M,5,'An toàn và kĩ năng sống',[
  [1,'Khi nhận tin nhắn "Bạn đã trúng thưởng điện thoại, bấm vào đường dẫn và nhập mã OTP để nhận quà", em nên làm gì?','Không bấm, không nhập mã, xóa tin nhắn và báo cho bố mẹ','Bấm ngay vì được quà miễn phí','Nhập mã rồi đợi quà về nhà','Chuyển tin cho bạn bè để cùng nhận'],
  [2,'Bạn rủ em cùng trốn học đi quán in-tơ-nét. Lời từ chối nào vừa dứt khoát vừa giữ được tình bạn?','"Mình không đi đâu, trốn học là sai. Chiều tan học mình chơi cầu lông với bạn nhé."','"Để mình nghĩ xem, có thể lần sau."','"Đi thì đi, nhưng bạn trả tiền nhé."','Im lặng rồi đi theo bạn'],
  [2,'Trước khi bão đổ bộ vào địa phương, gia đình em cần làm gì?','Chằng chống nhà cửa, dự trữ nước uống, lương thực, đèn pin, sạc điện thoại, theo dõi tin dự báo','Ra bờ biển xem sóng lớn','Để cửa mở cho gió lưu thông','Đi câu cá vì cá nhiều'],
  [3,'Em hãy phân tích vì sao kẻ lừa đảo qua mạng thường tạo cảm giác "gấp gáp" (chỉ còn 5 phút, nhận ngay kẻo mất) và em cần làm gì để không bị cuốn theo.','Gợi ý: cảm giác gấp gáp làm người nhận hoảng hốt, không có thời gian suy nghĩ, kiểm chứng nên dễ làm theo yêu cầu (bấm đường dẫn, nhập mã, chuyển tiền). Cách ứng phó: dừng lại, không làm gì ngay; tự hỏi "mình có tham gia chương trình này không, vì sao họ biết mình"; kiểm tra với bố mẹ, người lớn; không bao giờ đưa mật khẩu, mã OTP, thông tin cá nhân; chặn và báo cáo số lạ.']
 ]);

 /* ===== LỚP 7 ===== */
 add(M,7,'Kĩ năng sống, bản thân',[
  [1,'Khi làm bài kiểm tra bị điểm thấp dù đã cố gắng, cảm xúc tiêu cực nào dễ xuất hiện ở học sinh lớp 7?','Buồn chán, thất vọng, tự trách bản thân','Vui mừng, phấn khích','Bình thản vì không quan tâm','Tự hào về kết quả'],
  [2,'Bạn Khoa thấy mình nói chuyện tự nhiên, dễ kết bạn nhưng hay quên làm bài tập về nhà. Cách xác định điểm mạnh, điểm hạn chế của Khoa đúng nhất là gì?','Điểm mạnh là giao tiếp tốt; điểm hạn chế là chưa có trách nhiệm trong học tập','Điểm mạnh là quên bài; điểm hạn chế là nói nhiều','Khoa không có điểm mạnh nào','Khoa không có điểm hạn chế nào'],
  [2,'Trong giờ thực hành, nhóm em bất đồng về cách làm sản phẩm. Cách giải quyết mâu thuẫn mang tính xây dựng là gì?','Mỗi người trình bày ý kiến, cùng phân tích ưu – nhược điểm rồi biểu quyết hoặc kết hợp phương án','Người nói to nhất được quyết định','Tách nhóm, ai làm theo ý người đó','Nhờ cô quyết định mà không trao đổi'],
  [3,'Em hãy xây dựng kế hoạch rèn luyện kĩ năng kiểm soát cảm xúc trong 4 tuần, nêu rõ mục tiêu, biện pháp từng tuần và cách tự đánh giá.','Gợi ý: mục tiêu – giảm số lần nổi nóng với bạn bè, người thân. Tuần 1: ghi nhật kí cảm xúc, nhận diện tình huống gây tức giận. Tuần 2: luyện hít thở sâu, đếm 1–10, tạm rời khỏi tình huống. Tuần 3: tập nói "Mình cảm thấy… vì… mình mong…" thay vì trách móc. Tuần 4: nhờ bạn thân, bố mẹ nhận xét sự thay đổi. Tự đánh giá: đếm số lần kiểm soát được so với tuần 1, rút kinh nghiệm, điều chỉnh kế hoạch.']
 ]);
 add(M,7,'Trách nhiệm với gia đình, cộng đồng và hướng nghiệp',[
  [1,'Lắng nghe tích cực khi người thân chia sẻ thể hiện qua điều gì?','Nhìn vào người nói, gật đầu, hỏi lại để hiểu rõ và không ngắt lời','Vừa nghe vừa bấm điện thoại','Chen ngang để kể chuyện của mình','Khuyên ngay khi người thân chưa nói hết'],
  [2,'Gia đình bạn Thảo trồng rau để bán. Việc nào của Thảo góp phần phát triển kinh tế gia đình phù hợp với lứa tuổi học sinh lớp 7?','Giúp bố mẹ tưới rau, thu hoạch, giới thiệu rau sạch cho hàng xóm sau giờ học','Bỏ học để ra chợ bán rau cả ngày','Vay tiền để mở rộng vườn rau','Không giúp vì đó là việc của người lớn'],
  [2,'Nghề nào sau đây là nghề đặc trưng ở vùng đồng bằng sông Cửu Long?','Trồng lúa, nuôi cá tra, trồng cây ăn trái','Khai thác than','Chăn nuôi bò sữa trên cao nguyên','Dệt thổ cẩm vùng núi cao'],
  [3,'Em hãy nêu các bước lập kế hoạch chi tiêu của bản thân trong một tháng với số tiền tiêu vặt cố định và cho biết cách em ưu tiên khoản "cần" trước khoản "muốn".','Gợi ý: bước 1 – xác định tổng số tiền có; bước 2 – liệt kê khoản cần (ăn sáng, dụng cụ học tập, gửi xe) và khoản muốn (trà sữa, đồ chơi); bước 3 – phân bổ tiền cho khoản cần trước, dành một phần tiết kiệm (10–20%), phần còn lại cho khoản muốn; bước 4 – ghi chép chi tiêu hằng ngày; bước 5 – cuối tháng đối chiếu, điều chỉnh. Ưu tiên "cần" vì thiếu sẽ ảnh hưởng học tập, sức khỏe; "muốn" có thể trì hoãn hoặc bỏ.']
 ]);
 add(M,7,'Phát triển bản thân',[
  [1,'Thói quen ngăn nắp, gọn gàng trong học tập thể hiện ở việc nào?','Sắp xếp sách vở theo môn, ghi chép có hệ thống, dọn góc học tập sau khi học','Để sách vở bừa trên bàn để tiện tìm','Ghi chép lung tung vào bất kì vở nào','Chỉ dọn bàn học khi có khách đến'],
  [2,'Bạn Huy đặt mục tiêu "học giỏi hơn" cho học kì này. Vì sao mục tiêu này chưa tốt và nên sửa như thế nào?','Vì chưa cụ thể, không đo được; nên sửa thành "nâng điểm trung bình môn Toán từ 6,5 lên 7,5 vào cuối kì"','Vì mục tiêu quá dễ, nên đặt "đứng đầu khối"','Vì học sinh không cần đặt mục tiêu','Vì mục tiêu chỉ nên do bố mẹ đặt'],
  [2,'Khi gặp bài tập khó, biểu hiện nào cho thấy tính kiên trì?','Thử nhiều cách giải, xem lại bài giảng, hỏi bạn hoặc thầy cô cho đến khi hiểu','Bỏ qua ngay và chờ bạn giải','Chép đáp án từ sách giải','Đổ lỗi đề bài sai'],
  [3,'Em hãy phân tích mối quan hệ giữa thói quen ngăn nắp, gọn gàng và hiệu quả học tập của học sinh lớp 7, cho ví dụ cụ thể.','Gợi ý: ngăn nắp giúp tiết kiệm thời gian tìm tài liệu, không quên bài tập, đồ dùng; góc học tập gọn gàng giúp tập trung, ít bị phân tán; ghi chép có hệ thống giúp ôn tập nhanh và nhớ lâu; thói quen này rèn tính kỉ luật, tự chủ – là cơ sở để hoàn thành mục tiêu học tập. Ví dụ: bạn sắp lịch kiểm tra trên bảng kế hoạch sẽ không bị dồn bài; bạn để lộn xộn thường quên sách, mất điểm.']
 ]);
 add(M,7,'Trách nhiệm cộng đồng và hướng nghiệp',[
  [1,'Khi cùng nhóm bạn đến thăm, tặng quà người già neo đơn ở địa phương, thái độ phù hợp là gì?','Lễ phép, trò chuyện ân cần, lắng nghe và không tỏ ra thương hại','Tặng quà thật nhanh rồi về chụp ảnh đăng mạng','Chỉ chụp ảnh với người già để làm kỉ niệm','Chê nhà cửa không sạch sẽ'],
  [2,'Khi tìm hiểu nghề làm muối ở vùng ven biển, yếu tố nào cần được tìm hiểu để đánh giá sự an toàn và sức khỏe của người làm nghề?','Thời gian làm việc ngoài trời nắng gắt, nguy cơ say nắng, cần mũ, áo dài tay, nước uống','Số lượng khách du lịch đến tham quan','Giá muối bán ở siêu thị','Màu sắc trang phục của người làm muối'],
  [2,'Hiệu ứng nhà kính gia tăng chủ yếu do hoạt động nào của con người?','Đốt nhiên liệu hóa thạch, phá rừng, xả nhiều khí thải','Trồng rừng, phủ xanh đồi trọc','Dùng năng lượng mặt trời','Đi bộ, đi xe đạp'],
  [3,'Em hãy lập kế hoạch tìm hiểu một nghề ở địa phương em theo các mục: tên nghề, câu hỏi cần tìm hiểu, nguồn thông tin, cách thu thập, sản phẩm báo cáo.','Gợi ý: tên nghề – ví dụ nghề nuôi trồng thủy sản; câu hỏi – công việc chính, dụng cụ, thu nhập, khó khăn, yêu cầu phẩm chất, an toàn lao động; nguồn – người làm nghề, cán bộ xã, báo địa phương; cách thu thập – phỏng vấn, quan sát, chụp ảnh được phép; sản phẩm – bài thuyết trình, tập ảnh, sơ đồ tư duy. Kèm thời gian và phân công nếu làm theo nhóm.']
 ]);
 add(M,7,'(Bổ sung) Kĩ năng sống',[
  [1,'Khi bị một tài khoản lạ liên tục gửi tin nhắn đe dọa, chế giễu, việc đầu tiên nên làm là gì?','Không trả lời, chụp lại bằng chứng, chặn tài khoản và báo cho người lớn tin cậy','Nhắn lại chửi mắng cho bõ tức','Đăng bài kể tên người đó lên mạng','Xóa hết tin nhắn và coi như không có gì'],
  [2,'Bạn em mời hút thử thuốc lá điện tử và nói "thử một lần không sao". Kĩ năng từ chối phù hợp là gì?','Nói rõ "Mình không hút", nêu lí do ngắn gọn và rời đi hoặc đổi chủ đề','Nhận lấy nhưng không hút để bạn vui','Thử một lần rồi không thử nữa','Im lặng và chờ bạn đổi ý'],
  [2,'Dấu hiệu nào cho thấy một học sinh đang bị căng thẳng quá mức vì học tập?','Mất ngủ, đau đầu thường xuyên, dễ cáu gắt, mất hứng thú với mọi việc','Thấy hào hứng khi đến lớp','Ngủ đủ giấc, ăn ngon','Thích chơi thể thao cùng bạn'],
  [3,'Em hãy phân tích vì sao việc giữ bằng chứng (ảnh chụp màn hình, tin nhắn) và tìm sự hỗ trợ của người lớn là cần thiết khi bị bắt nạt trên mạng.','Gợi ý: bằng chứng giúp người lớn, nhà trường, cơ quan chức năng xác định đúng người, đúng hành vi để xử lí; kẻ bắt nạt có thể xóa tin, đổi tài khoản nên cần lưu ngay; người lớn có kinh nghiệm và quyền hạn để liên hệ nhà trường, gia đình kẻ bắt nạt hoặc báo cáo nền tảng; học sinh tự xử lí thường dễ bị cuốn vào trả đũa làm sự việc trầm trọng hơn; chia sẻ cũng giúp giảm áp lực tâm lí.']
 ]);

 /* ===== LỚP 8 ===== */
 add(M,8,'Kĩ năng sống, bản thân',[
  [1,'Khi thương thuyết với bạn về việc phân chia nhiệm vụ trong dự án nhóm, điều cần có trước khi bắt đầu là gì?','Xác định rõ mục tiêu chung và điều mình có thể nhân nhượng','Quyết tâm giành phần việc nhẹ nhất','Chuẩn bị lí lẽ để chê bai ý kiến của bạn','Nhờ cô phân công sẵn'],
  [2,'Bạn Dũng thường hứa giúp bạn nhưng hay quên, khiến bạn bè phải chờ. Nét tính cách nào của Dũng cần điều chỉnh?','Thiếu trách nhiệm, chưa giữ lời hứa','Quá cẩn thận, kĩ tính','Quá tự tin','Quá nhút nhát'],
  [2,'Khi tranh biện về chủ đề "Học sinh có nên dùng điện thoại trong lớp", người tranh biện tốt sẽ làm gì?','Đưa ra luận điểm rõ ràng, có dẫn chứng và tôn trọng lượt nói của đối phương','Nói thật to và cắt lời đối phương','Công kích cá nhân đối phương','Chỉ nhắc lại ý kiến của mình nhiều lần'],
  [3,'Em hãy phân tích sự khác nhau giữa tranh biện và cãi vã, từ đó nêu ba nguyên tắc để một cuộc tranh biện trong lớp diễn ra hiệu quả.','Gợi ý: tranh biện dựa trên lí lẽ, dẫn chứng, hướng tới làm rõ vấn đề, tôn trọng người khác; cãi vã dựa trên cảm xúc, muốn thắng bằng mọi giá, dễ công kích cá nhân. Nguyên tắc: nói đúng lượt, không ngắt lời; tập trung vào vấn đề, không vào con người; dùng dẫn chứng xác thực; sẵn sàng thừa nhận khi đối phương đúng; kết luận bằng điểm chung tìm được.']
 ]);
 add(M,8,'Trách nhiệm với gia đình, cộng đồng và hướng nghiệp',[
  [1,'Khi muốn thuyết phục bố mẹ cho tham gia câu lạc bộ bóng rổ, điều em cần chuẩn bị là gì?','Lí do rõ ràng, cam kết về thời gian học tập và lợi ích của hoạt động','Thái độ giận dỗi nếu bị từ chối','Lời hứa hẹn không có cơ sở','Nhờ bạn đến xin thay'],
  [2,'Bố mẹ bận việc, em được giao sắp xếp bữa tối và nhắc em nhỏ học. Cách sắp xếp công việc hợp lí là gì?','Lập thứ tự: nấu món đơn giản trước, trong lúc chờ nấu thì hướng dẫn em học, dọn dẹp sau bữa ăn','Chơi điện tử xong rồi làm vội mọi việc','Gọi đồ ăn và để em tự học','Chỉ làm một việc, bỏ việc còn lại'],
  [2,'Nghề nào sau đây được coi là nghề phổ biến trong xã hội hiện đại, gắn với công nghệ số?','Chuyên viên phân tích dữ liệu, kĩ sư phần mềm, nhân viên kinh doanh trực tuyến','Người kéo xe tay','Người gõ máy chữ','Người đốt than củi'],
  [3,'Em hãy phân tích vì sao việc tôn trọng ý kiến của các thành viên trong gia đình (kể cả ý kiến của học sinh lớp 8) góp phần xây dựng gia đình hạnh phúc, và nêu cách em thể hiện sự tôn trọng đó.','Gợi ý: tôn trọng giúp mọi người cảm thấy được lắng nghe, giảm mâu thuẫn, tăng sự gắn kết và tin tưởng; quyết định chung dễ được mọi người đồng thuận và thực hiện; học sinh được tôn trọng sẽ tự tin, có trách nhiệm hơn. Cách thể hiện: lắng nghe hết ý, không ngắt lời; nói ý kiến khác biệt bằng lời lễ phép; chấp nhận quyết định chung dù chưa hoàn toàn đồng ý; giữ lời hứa với người thân.']
 ]);
 add(M,8,'Phát triển bản thân',[
  [1,'Lên lớp 8, nhiều môn học có yêu cầu cao hơn, bài tập dài hơn. Việc đầu tiên để thích ứng là gì?','Điều chỉnh lại kế hoạch học tập, phân bổ thời gian hợp lí cho từng môn','Than phiền với bạn bè về thầy cô','Bỏ qua các môn khó','Học thuộc lòng tất cả'],
  [2,'Trong lớp có bạn theo tôn giáo khác, có bạn là người dân tộc thiểu số với phong tục riêng. Biểu hiện nào cho thấy em tôn trọng sự khác biệt?','Tìm hiểu, lắng nghe và không chê bai, trêu chọc phong tục, tín ngưỡng của bạn','Tránh chơi với bạn vì khác mình','Bắt bạn làm theo cách của mình','Bàn tán về trang phục của bạn'],
  [2,'Việc tự đánh giá bản thân cuối mỗi tháng nên dựa trên điều gì?','Mục tiêu đã đặt ra, kết quả đạt được và nhận xét của thầy cô, bạn bè, người thân','Cảm giác vui hay buồn trong ngày đánh giá','So với người giỏi nhất lớp','Số lượt thích trên mạng xã hội'],
  [3,'Em hãy lập kế hoạch tự rèn luyện thói quen đọc sách trong một học kì: mục tiêu, loại sách, thời gian đọc mỗi ngày, cách ghi chép và cách duy trì khi mất hứng thú.','Gợi ý: mục tiêu – đọc 4 cuốn sách/học kì; loại sách – văn học thiếu niên, khoa học phổ thông, kĩ năng sống; thời gian – 20 phút trước khi ngủ; ghi chép – nhật kí đọc sách: tên sách, ý hay, cảm nhận; duy trì – chọn sách yêu thích, đọc cùng bạn, chia sẻ trong giờ sinh hoạt, tự thưởng khi đạt mốc, đặt sách ở nơi dễ thấy, giảm thời gian dùng điện thoại.']
 ]);
 add(M,8,'Trách nhiệm cộng đồng và hướng nghiệp',[
  [1,'Khi xảy ra lũ quét, sạt lở đất ở vùng núi, hành động an toàn nhất là gì?','Di chuyển ngay lên vùng đất cao, xa sông suối và sườn dốc theo hướng dẫn của chính quyền','Ở lại nhà để trông đồ','Ra bờ suối xem nước lũ','Chạy xuống vùng trũng cho gần đường'],
  [2,'Khi tổ chức truyền thông về bảo vệ môi trường ở khu dân cư, hình thức nào phù hợp với học sinh lớp 8?','Vẽ tranh cổ động, làm video ngắn, phát tờ rơi, tổ chức ngày hội đổi rác lấy cây','Dán giấy lên tường nhà người dân mà không xin phép','Dùng loa phát suốt đêm','Phạt tiền người xả rác'],
  [2,'Khi khảo sát hứng thú nghề nghiệp, một bạn thích tìm hiểu cách máy móc hoạt động, thích sửa đồ hỏng. Nhóm nghề nào gần với hứng thú đó?','Kĩ thuật, cơ khí, điện – điện tử','Diễn viên, ca sĩ','Kế toán, thủ quỹ','Hướng dẫn viên du lịch'],
  [3,'Em hãy xây dựng kế hoạch phòng chống thiên tai thường xảy ra ở địa phương em (bão, lũ, hạn hán, sạt lở…) cho gia đình gồm: trước, trong và sau thiên tai.','Gợi ý: trước – theo dõi dự báo, gia cố nhà cửa, dự trữ lương thực, nước, thuốc, đèn pin, sạc dự phòng, thống nhất nơi sơ tán; trong – ở nơi an toàn, không ra ngoài, không chạm vào dây điện đứt, nghe thông báo của chính quyền; sau – kiểm tra nhà cửa, dọn vệ sinh, khử khuẩn nước, phòng dịch bệnh, giúp đỡ hàng xóm, báo thiệt hại với chính quyền. Nêu rõ phân công từng thành viên.']
 ]);
 add(M,8,'(Bổ sung) Kĩ năng sống',[
  [1,'Bắt nạt học đường bao gồm những hình thức nào?','Bạo lực thể chất, lời nói xúc phạm, cô lập, tẩy chay và bắt nạt qua mạng','Chỉ gồm đánh nhau','Chỉ gồm chửi mắng','Chỉ gồm nói xấu trên mạng'],
  [2,'Em chứng kiến một nhóm bạn thường xuyên giấu cặp, xô đẩy một bạn yếu thế trong lớp. Cách can thiệp an toàn và có trách nhiệm là gì?','Không cổ vũ, đứng về phía bạn bị bắt nạt, báo cho thầy cô và động viên bạn chia sẻ với gia đình','Quay video đăng lên mạng cho mọi người biết','Im lặng vì sợ bị trả thù','Tham gia cùng để không bị cô lập'],
  [2,'Khi lập kế hoạch tài chính cá nhân, khoản nào nên được dành ra ngay sau khi nhận tiền?','Khoản tiết kiệm cho mục tiêu dài hạn và tình huống khẩn cấp','Khoản mua đồ chơi mới','Khoản mời bạn ăn uống','Không cần dành khoản nào'],
  [3,'Em hãy phân tích tác hại của bắt nạt học đường đối với người bị bắt nạt, người bắt nạt và người chứng kiến, từ đó đề xuất hai hoạt động lớp em có thể làm để phòng tránh.','Gợi ý: người bị bắt nạt – sợ hãi, cô lập, học sa sút, tổn thương tâm lí lâu dài; người bắt nạt – hình thành thói quen bạo lực, bị kỉ luật, khó hòa nhập; người chứng kiến – lo lắng, mất niềm tin vào môi trường an toàn, có thể quen với bạo lực. Hoạt động: xây dựng nội quy lớp "nói không với bắt nạt" và hộp thư góp ý; tổ chức tiểu phẩm, diễn đàn về kĩ năng ứng xử, lập nhóm bạn đồng hành hỗ trợ bạn mới, bạn yếu thế.']
 ]);

 /* ===== LỚP 9 ===== */
 add(M,9,'Kĩ năng sống, bản thân',[
  [1,'Khi phải cân bằng giữa ôn thi vào lớp 10 và các hoạt động khác, kĩ năng nào quan trọng nhất?','Quản lí thời gian theo ưu tiên, kết hợp học tập với nghỉ ngơi hợp lí','Học liên tục không nghỉ','Bỏ hết hoạt động thể dục thể thao','Chỉ học môn mình thích'],
  [2,'Khi tiếp nhận một thông tin lan truyền về việc "đổi cấu trúc đề thi vào lớp 10", học sinh có tư duy phản biện sẽ làm gì?','Kiểm chứng nguồn tin từ thông báo chính thức của Sở Giáo dục hoặc nhà trường trước khi tin và chia sẻ','Chia sẻ ngay cho các bạn để cùng lo','Tin ngay vì nhiều người nói','Bỏ ôn tập theo cách cũ'],
  [2,'Bạn Hạnh thấy mình ngại phát biểu nhưng rất kiên trì và cẩn thận. Nhận định nào đúng về cách rèn luyện của Hạnh?','Phát huy kiên trì, cẩn thận; đặt mục tiêu nhỏ như phát biểu ít nhất một lần mỗi buổi học để khắc phục sự ngại ngùng','Phải thay đổi hoàn toàn tính cách để giống bạn hoạt bát','Không cần thay đổi gì','Chỉ tập trung vào điểm yếu, bỏ qua điểm mạnh'],
  [3,'Em hãy phân tích vì sao việc nhận diện đúng điểm tích cực và chưa tích cực của bản thân là cơ sở quan trọng để học sinh lớp 9 chọn hướng đi sau trung học cơ sở.','Gợi ý: biết điểm mạnh giúp chọn hướng học, nghề phát huy được sở trường, dễ thành công và hứng thú; biết điểm hạn chế để tránh chọn nghề đòi hỏi điều mình khó đáp ứng hoặc có kế hoạch khắc phục; đánh giá đúng bản thân tránh chọn theo phong trào, theo bạn bè; kết hợp với yêu cầu của nghề và nhu cầu xã hội mới có quyết định phù hợp; thiếu tự nhận thức dễ dẫn đến chọn sai, lãng phí thời gian.']
 ]);
 add(M,9,'Trách nhiệm với gia đình, cộng đồng và hướng nghiệp',[
  [1,'Trường trung cấp, trường cao đẳng nghề và trung tâm giáo dục nghề nghiệp – giáo dục thường xuyên thuộc hệ thống nào?','Cơ sở giáo dục nghề nghiệp và giáo dục thường xuyên mà học sinh có thể theo học sau trung học cơ sở','Cơ sở giáo dục mầm non','Cơ sở giáo dục đại học','Cơ sở y tế cộng đồng'],
  [2,'Bạn Nam muốn học nghề sửa chữa ô tô sau lớp 9 nhưng bố mẹ muốn Nam vào trung học phổ thông. Cách ứng xử phù hợp của Nam là gì?','Tìm hiểu kĩ thông tin về hai hướng đi, trình bày sở thích, năng lực và kế hoạch của mình, lắng nghe lí do của bố mẹ để cùng quyết định','Tự nộp hồ sơ học nghề mà không nói với bố mẹ','Bỏ học để phản đối','Làm theo bố mẹ dù không thích và không nói gì'],
  [2,'Khi gia đình gặp khó khăn (bố mẹ mất việc, người thân ốm nặng), trách nhiệm phù hợp của học sinh lớp 9 là gì?','Chia sẻ việc nhà, chi tiêu tiết kiệm, động viên người thân và vẫn duy trì học tập','Nghỉ học để đi làm kiếm tiền','Giấu mọi người, tự lo một mình','Trách bố mẹ vì không lo được'],
  [3,'Em hãy so sánh hai hướng đi sau khi tốt nghiệp trung học cơ sở: học trung học phổ thông và học nghề (trung cấp, cao đẳng nghề) về thời gian, chi phí, cơ hội việc làm, khả năng học tiếp, và cho biết hướng đi nào phù hợp với em, vì sao.','Gợi ý: THPT – 3 năm, học văn hóa toàn diện, sau đó thi đại học, cao đẳng; phù hợp bạn muốn học lên cao, thích học thuật. Học nghề – 2–3 năm, vừa học văn hóa vừa học nghề, sớm có việc làm, chi phí thấp hơn, có chính sách hỗ trợ, có thể liên thông lên cao đẳng, đại học; phù hợp bạn thích thực hành, muốn sớm tự lập. Học sinh đối chiếu với năng lực, sở thích, điều kiện gia đình để chọn và lập luận.']
 ]);
 add(M,9,'Phát triển bản thân',[
  [1,'Khi định hướng theo nhóm nghề kĩ thuật, công nghệ, môn học nào cần được ưu tiên rèn luyện ở lớp 9?','Toán, Khoa học tự nhiên (Vật lí), Công nghệ, Tin học','Chỉ Âm nhạc và Mĩ thuật','Chỉ Giáo dục thể chất','Không cần ưu tiên môn nào'],
  [2,'Việc đăng ảnh, bình luận trên mạng xã hội ảnh hưởng đến hình ảnh bản thân của học sinh lớp 9 như thế nào?','Thầy cô, bạn bè và cả nhà tuyển sinh, nhà tuyển dụng sau này có thể đánh giá em qua những gì em đăng','Không ảnh hưởng gì vì là không gian riêng','Chỉ ảnh hưởng đến bạn bè cùng lớp','Chỉ ảnh hưởng khi đăng ảnh đẹp'],
  [2,'Bạn Trang mơ ước làm bác sĩ nhưng điểm môn Khoa học tự nhiên còn thấp và sợ máu. Cách ứng xử tích cực nhất là gì?','Tìm hiểu thêm các nghề gần trong lĩnh vực y tế, đồng thời lập kế hoạch cải thiện môn học và rèn luyện bản thân trước khi quyết định','Từ bỏ ngay mọi mơ ước liên quan đến y tế','Giữ nguyên mơ ước mà không thay đổi gì','Chọn đại một nghề khác theo bạn thân'],
  [3,'Em hãy xây dựng kế hoạch học tập và rèn luyện theo định hướng nghề nghiệp cho năm lớp 9 gồm: nghề định hướng, môn học trọng tâm, kĩ năng cần rèn, hoạt động trải nghiệm nghề, mốc đánh giá.','Gợi ý: nghề – ví dụ kĩ sư công nghệ thông tin; môn trọng tâm – Toán, Tin học, Tiếng Anh; kĩ năng – tư duy lô-gic, tự học, làm việc nhóm, thuyết trình; trải nghiệm – tham gia câu lạc bộ lập trình, tham quan công ty phần mềm, trò chuyện với người làm nghề, làm sản phẩm nhỏ; mốc đánh giá – cuối mỗi tháng xem điểm, sản phẩm, nhận xét của thầy cô; điều chỉnh kế hoạch nếu chưa phù hợp.']
 ]);
 add(M,9,'Trách nhiệm cộng đồng và hướng nghiệp',[
  [1,'Khi truyền thông quảng bá hình ảnh đẹp của địa phương (danh lam, lễ hội, đặc sản), học sinh lớp 9 có thể dùng cách nào?','Làm video, bài viết, tập ảnh giới thiệu và chia sẻ trên trang của trường, địa phương với nội dung chính xác, tôn trọng','Bịa thêm thông tin cho hấp dẫn','Chỉ nói miệng với bạn bè','Chép lại bài viết của người khác'],
  [2,'Thị trường lao động hiện nay có xu hướng cần nhiều lao động như thế nào?','Có kĩ năng số, ngoại ngữ, khả năng học tập suốt đời và thích ứng với công nghệ mới','Chỉ cần sức khỏe, không cần kĩ năng','Chỉ làm một công việc cả đời không đổi','Không cần tốt nghiệp bất kì cấp học nào'],
  [2,'Khi phát hiện nhóm bạn rủ nhau sử dụng chất gây nghiện ở khu dân cư, hành vi thể hiện trách nhiệm với cộng đồng là gì?','Kiên quyết từ chối, khuyên bạn và báo với người lớn, cơ quan chức năng khi cần','Tham gia một lần rồi thôi','Lờ đi vì không liên quan','Quay video đăng mạng để câu lượt xem'],
  [3,'Em hãy phân tích vai trò của thông tin về thị trường lao động địa phương (ngành đang thiếu nhân lực, mức thu nhập, yêu cầu trình độ) đối với quyết định chọn nghề của học sinh lớp 9 và nêu các nguồn tin đáng tin cậy.','Gợi ý: thông tin thị trường lao động cho biết nghề nào xã hội đang cần, cơ hội việc làm, thu nhập, yêu cầu trình độ – giúp học sinh đối chiếu với sở thích, năng lực để chọn nghề có triển vọng, tránh học xong không có việc; biết yêu cầu trình độ để chọn hướng học phù hợp. Nguồn đáng tin: cổng thông tin của cơ quan quản lí lao động – việc làm ở địa phương, trung tâm dịch vụ việc làm, thông tin tuyển sinh của trường nghề, báo chí chính thống, người làm nghề, cán bộ tư vấn hướng nghiệp của trường.']
 ]);
 add(M,9,'(Bổ sung) Kĩ năng sống',[
  [1,'Theo quy định của pháp luật, người từ đủ 16 tuổi trở lên mới được điều khiển loại xe nào sau đây?','Xe máy điện, xe gắn máy dưới 50 phân khối','Xe mô tô trên 50 phân khối','Ô tô cá nhân','Xe tải nhỏ'],
  [2,'Trong giai đoạn ôn thi vào lớp 10, bạn Phúc thường thức đến 2 giờ sáng, bỏ bữa sáng và ít nói chuyện với mọi người. Cách hỗ trợ bạn phù hợp là gì?','Lắng nghe, khuyên bạn sắp xếp lại lịch học – nghỉ, và báo cho thầy cô, gia đình nếu bạn có dấu hiệu kiệt sức kéo dài','Rủ bạn thức khuya học cùng cho vui','Chê bạn yếu đuối','Không quan tâm vì ai cũng áp lực'],
  [2,'Khi nhận tin nhắn "việc nhẹ lương cao, chỉ cần tải ứng dụng và nạp tiền để nhận nhiệm vụ", dấu hiệu nào cho thấy đây là lừa đảo?','Yêu cầu nạp tiền trước, hứa thu nhập cao bất thường, không có công ty rõ ràng','Có đầy đủ địa chỉ công ty, hợp đồng và không yêu cầu nộp tiền','Thông tin được đăng trên trang của nhà trường','Do thầy cô giới thiệu trực tiếp'],
  [3,'Em hãy vận dụng các bước ra quyết định có trách nhiệm để giải quyết tình huống: em được mời làm cộng tác viên bán hàng trực tuyến trong thời gian ôn thi, hứa hẹn thu nhập 3 triệu đồng mỗi tháng.','Gợi ý: bước 1 – xác định vấn đề: có nhận việc không khi đang ôn thi; bước 2 – thu thập thông tin: công việc cụ thể là gì, đơn vị tuyển có đáng tin không, có yêu cầu đặt cọc/nộp phí/cung cấp tài khoản không, mất bao nhiêu giờ mỗi ngày; bước 3 – liệt kê phương án: nhận, từ chối, hoãn đến sau kì thi, hoặc nhận với thời lượng rất ít; bước 4 – cân nhắc hậu quả: ảnh hưởng học tập, dấu hiệu lừa đảo (bắt chuyển tiền trước), quy định pháp luật về lao động chưa thành niên (dưới 15 tuổi chỉ được làm một số công việc nhẹ có người giám hộ đồng ý; từ đủ 15 đến dưới 18 tuổi có giới hạn giờ làm và loại việc); bước 5 – ra quyết định sau khi tham khảo ý kiến cha mẹ/người giám hộ; bước 6 – đánh giá lại sau khi thực hiện. Chấm theo lập luận và khả năng nhận diện rủi ro; không bắt buộc một kết luận duy nhất, miễn là ưu tiên việc học và không chuyển tiền/đưa thông tin cá nhân cho bên chưa xác minh.']
 ]);
})();
