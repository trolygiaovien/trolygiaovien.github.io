/* NGÂN HÀNG TIẾNG ANH – LỚP 1–9 — bổ sung đủ chuẩn. Câu hỏi nguyên bản, bám SGK Tiếng Anh Global Success (Kết nối tri thức). */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Tiếng Anh';

 /* ===================== LỚP 1 ===================== */
 add(M,1,'Greetings & Colours',[
  [1,'"Hi" nghĩa là gì?','xin chào','tạm biệt','cảm ơn','xin lỗi'],
  [1,'"Black" là màu gì?','màu đen','màu trắng','màu đỏ','màu vàng'],
  [1,'Chọn từ chỉ màu sắc trong các từ sau:','pink','cat','ball','six'],
  [2,'Chọn câu hỏi về màu sắc:','What colour is it?','What is your name?','How are you?','How old are you?'],
  [2,'Hoàn thành: "What colour is it?" – "It\'s ___." (màu trắng)','white','red','green','blue'],
  [2,'Chọn lời đáp đúng khi bạn nói "Hello!":','Hello!','Three.','Blue.','A cat.'],
  [2,'Chọn câu đúng để nói "Tạm biệt":','Bye-bye!','Hello!','Thanks!','Yes.'],
  [3,'Viết tên 3 màu sắc bằng tiếng Anh.','Ví dụ: red, blue, yellow, green, pink, black, white.'],
  [3,'Viết câu chào buổi sáng bằng tiếng Anh.','Good morning!'],
  [3,'Hoàn thành câu: "It\'s a ___ ball." (màu đỏ)','It\'s a red ball.'],
  [4,'Viết 2 câu: chào bạn và nói màu của chiếc bút của em.','Ví dụ: Hello! My pen is blue. / Hi! It\'s a blue pen.']
 ]);
 add(M,1,'Numbers & Animals',[
  [1,'Số "seven" là số mấy?','7','6','8','9'],
  [1,'"Duck" là con gì?','con vịt','con gà','con chó','con mèo'],
  [1,'"Bird" nghĩa là gì?','con chim','con cá','con bò','con lợn'],
  [2,'Chọn từ chỉ số:','eight','egg','ant','blue'],
  [2,'Hoàn thành: "I have ___ dogs." (hai)','two','one','a','an'],
  [2,'Chọn câu đúng:','It\'s a cat.','It a cat.','It\'s cat.','Is a cat it.'],
  [2,'2 + 2 = ? (bằng tiếng Anh)','four','three','five','six'],
  [3,'Viết các số từ 1 đến 5 bằng tiếng Anh.','one, two, three, four, five'],
  [3,'Hoàn thành câu: "I like ___." (con cá)','I like fish.'],
  [3,'Viết một câu nói em có một con vật (dùng "I have a ...").','Ví dụ: I have a dog. / I have a cat.'],
  [4,'Viết 2 câu nói về con vật em thích: tên con vật và số lượng (dùng "I like ..." và "I have ...").','Ví dụ: I like cats. I have two cats.']
 ]);

 /* ===================== LỚP 2 ===================== */
 add(M,2,'School & Family',[
  [1,'"Brother" nghĩa là ai?','anh/em trai','chị/em gái','bố','ông'],
  [1,'"School bag" nghĩa là gì?','cái cặp sách','quyển vở','cái bút chì','cái ghế'],
  [1,'"Grandfather" nghĩa là ai?','ông','bà','bố','anh trai'],
  [2,'Chọn từ chỉ người trong gia đình:','sister','ruler','desk','pen'],
  [2,'Hoàn thành: "This is my ___." (chị gái)','sister','brother','mother','father'],
  [2,'Chọn câu đúng để giới thiệu quyển sách:','This is a book.','This a book.','This is book a.','Is this book.'],
  [3,'Viết tên 3 người trong gia đình bằng tiếng Anh.','Ví dụ: father, mother, brother, sister, grandfather, grandmother.'],
  [3,'Hoàn thành câu: "This is my ___." (mẹ)','This is my mother.'],
  [3,'Viết một câu giới thiệu một đồ dùng học tập của em (dùng "This is my ...").','Ví dụ: This is my pencil. / This is my book.'],
  [4,'Viết 2 câu: giới thiệu bố của em và một đồ dùng học tập của em.','Ví dụ: This is my father. This is my ruler.']
 ]);
 add(M,2,'Food & Toys',[
  [1,'"Apple" là quả gì?','quả táo','quả chuối','quả cam','quả lê'],
  [1,'"Doll" nghĩa là gì?','con búp bê','quả bóng','con diều','ô tô đồ chơi'],
  [1,'"Milk" nghĩa là gì?','sữa','nước','bánh mì','cơm'],
  [2,'Chọn từ chỉ đồ chơi:','kite','rice','cake','fish'],
  [2,'Hoàn thành: "I like ___." (bánh ngọt)','cakes','cakes is','a cakes','cake like'],
  [2,'Chọn câu đúng:','I have a kite.','I have kite a.','I has a kite.','I a kite have.'],
  [3,'Viết tên 3 món ăn hoặc đồ uống bằng tiếng Anh.','Ví dụ: rice, bread, cake, milk, juice, egg.'],
  [3,'Hoàn thành câu: "I like ___." (quả chuối)','I like bananas.'],
  [3,'Viết một câu nói em có một con búp bê.','I have a doll.'],
  [4,'Viết 2 câu: một câu về món ăn em thích và một câu về đồ chơi em có.','Ví dụ: I like apples. I have a ball.']
 ]);
 add(M,2,'Places & Actions',[
  [1,'"Zoo" nghĩa là gì?','vườn thú','công viên','trường học','siêu thị'],
  [1,'"Swim" nghĩa là gì?','bơi','chạy','hát','vẽ'],
  [1,'"Sing" nghĩa là gì?','hát','nhảy','đọc','viết'],
  [2,'Chọn từ chỉ địa điểm:','school','jump','red','doll'],
  [2,'Hoàn thành: "I can ___." (nhảy)','jump','jumps','jumping','to jump'],
  [2,'Chọn câu đúng:','I can dance.','I can dances.','I dance can.','Can dance I.'],
  [3,'Viết tên 2 địa điểm bằng tiếng Anh.','Ví dụ: park, zoo, school, shop.'],
  [3,'Hoàn thành câu: "I can ___." (đọc)','I can read.'],
  [3,'Viết câu hỏi và câu trả lời: "Can you swim?"','Can you swim? – Yes, I can. / No, I can\'t.'],
  [4,'Viết 2 câu: một việc em có thể làm và một việc em không thể làm (dùng "can" và "can\'t").','Ví dụ: I can run. I can\'t swim.']
 ]);

 /* ===================== LỚP 3 ===================== */
 add(M,3,'Hello – Friends – Body',[
  [1,'"Nose" là bộ phận nào?','mũi','tai','mắt','tay'],
  [1,'"Hand" nghĩa là gì?','bàn tay','bàn chân','cái đầu','cái miệng'],
  [1,'Chọn lời chào buổi chiều:','Good afternoon.','Good night.','Goodbye.','Thank you.'],
  [2,'Hoàn thành: "Nice to meet ___."','you','your','me','I'],
  [2,'Chọn câu trả lời đúng: "Is this Linda?" – "___"','Yes, it is.','Yes, she are.','Yes, it are.','Yes, this are.'],
  [2,'Hoàn thành: "___ are my friends, Mai and Nam."','These','This','That','It'],
  [2,'Chọn câu đúng:','Touch your nose.','Touch you nose.','Touch nose your.','Touches your nose.'],
  [3,'Viết câu hỏi tên của bạn và câu trả lời.','What\'s your name? – My name is Nam.'],
  [3,'Sắp xếp từ thành câu đúng: "friend / is / my / This / Peter."','This is my friend Peter.'],
  [3,'Viết tên 4 bộ phận trên cơ thể bằng tiếng Anh.','Ví dụ: head, hand, foot, eye, ear, nose, mouth, arm, leg.'],
  [4,'Viết 3 câu: chào bạn, giới thiệu tên và tuổi của em.','Ví dụ: Hello! My name is Hoa. I\'m eight years old.']
 ]);
 add(M,3,'School – Classroom',[
  [1,'"Gym" nghĩa là gì?','phòng thể chất','thư viện','phòng học','căng tin'],
  [1,'"Playground" nghĩa là gì?','sân chơi','phòng học','thư viện','cổng trường'],
  [1,'"Sit down, please!" nghĩa là gì?','Mời ngồi xuống!','Mời đứng lên!','Mở sách ra!','Im lặng!'],
  [2,'Hoàn thành: "May I go out?" – "___"','Yes, you can.','Yes, I can.','Yes, it is.','Yes, I am.'],
  [2,'Chọn câu trả lời đúng: "What colour is your pencil?"','It\'s yellow.','It\'s a pencil.','Yes, it is.','It\'s big.'],
  [2,'Hoàn thành: "Open ___ book, please."','your','you','yours','me'],
  [2,'Chọn câu trả lời đúng: "Where is the library?" – "___"','It\'s over there.','Yes, it is.','It\'s a library.','It\'s nine o\'clock.'],
  [3,'Sắp xếp từ thành câu đúng: "your / Is / pen / this ?"','Is this your pen?'],
  [3,'Viết câu xin phép được vào lớp bằng tiếng Anh.','May I come in?'],
  [3,'Viết tên 3 phòng hoặc địa điểm trong trường học bằng tiếng Anh.','Ví dụ: classroom, library, gym, playground, computer room.'],
  [4,'Viết 3 câu nói về lớp học của em (dùng "This is ..." và "It\'s ...").','Ví dụ: This is my classroom. It\'s big. My desk is brown.']
 ]);
 add(M,3,'Family – House – Pets',[
  [1,'"Sister" nghĩa là ai?','chị/em gái','anh/em trai','mẹ','bà'],
  [1,'"Bathroom" là phòng nào?','phòng tắm','phòng ngủ','phòng bếp','phòng khách'],
  [1,'"Goldfish" là con gì?','cá vàng','con vẹt','con thỏ','con chó'],
  [2,'Chọn câu trả lời đúng: "How many rooms are there in your house?"','There are four.','It\'s four.','There is four.','Four rooms is.'],
  [2,'Hoàn thành: "There ___ a sofa in the living room."','is','are','am','be'],
  [2,'Chọn câu trả lời đúng: "Do you have any pets?"','Yes, I do.','Yes, I have.','Yes, I am.','Yes, it is.'],
  [2,'Hoàn thành: "Where\'s the cat?" – "It\'s ___ the table."','under','to','of','from'],
  [3,'Sắp xếp từ thành câu đúng: "is / my / That / grandmother."','That is my grandmother.'],
  [3,'Viết câu hỏi và câu trả lời về số lượng con mèo em có (2 con).','How many cats do you have? – I have two cats.'],
  [3,'Viết câu nói có một cái giường trong phòng ngủ của em (dùng "There is").','There is a bed in my bedroom.'],
  [4,'Viết 3 câu nói về ngôi nhà của em (dùng "There is / There are").','Ví dụ: My house is big. There are three bedrooms. There is a garden in front of the house.']
 ]);

 /* ===================== LỚP 4 ===================== */
 add(M,4,'Friends – Time – Daily routines',[
  [1,'"Wednesday" là thứ mấy?','thứ Tư','thứ Năm','thứ Hai','thứ Bảy'],
  [1,'Chọn câu trả lời đúng: "What nationality are you?"','I\'m Vietnamese.','I\'m Viet Nam.','I\'m from Vietnamese.','Viet Nam I am.'],
  [2,'Hoàn thành: "She ___ breakfast at seven."','has','have','haves','having'],
  [2,'Hoàn thành: "I go to bed ___ night."','at','in','on','to'],
  [2,'Chọn câu trả lời đúng: "What do you do in the morning?"','I brush my teeth.','I\'m from Japan.','It\'s Tuesday.','It\'s seven o\'clock.'],
  [2,'"It\'s half past six." là mấy giờ?','6 giờ 30','6 giờ','5 giờ 30','7 giờ 30'],
  [2,'Hoàn thành: "What day is it today?" – "___ Friday."','It\'s','They\'re','I\'m','There\'s'],
  [3,'Sắp xếp từ thành câu đúng: "do / What / you / time / get up ?"','What time do you get up?'],
  [3,'Viết câu hỏi về quốc tịch của bạn và câu trả lời.','What nationality are you? – I\'m Vietnamese.'],
  [3,'Viết tên 7 ngày trong tuần bằng tiếng Anh.','Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday'],
  [4,'Viết đoạn 3–4 câu kể về một ngày của em (có ít nhất 2 mốc giờ).','Ví dụ: I get up at six o\'clock. I go to school at seven o\'clock. I have lunch at eleven thirty. In the evening, I do my homework.']
 ]);
 add(M,4,'Birthday – Abilities – Subjects',[
  [1,'"March" là tháng mấy?','tháng Ba','tháng Năm','tháng Tư','tháng Mười'],
  [1,'"Music" là môn học nào?','Âm nhạc','Mĩ thuật','Thể dục','Khoa học'],
  [1,'"Happy birthday!" nghĩa là gì?','Chúc mừng sinh nhật!','Chúc ngủ ngon!','Chúc mừng năm mới!','Chúc may mắn!'],
  [2,'Hoàn thành: "My birthday is ___ the fifth of June."','on','in','at','to'],
  [2,'Chọn câu trả lời đúng: "Can she play the piano?"','No, she can\'t.','No, she doesn\'t.','No, she isn\'t.','No, she can.'],
  [2,'Hoàn thành: "We have P.E. ___ Tuesdays and Thursdays."','on','in','at','of'],
  [2,'Chọn câu trả lời đúng: "What can you do?"','I can ride a bike.','I like Maths.','It\'s on Monday.','Yes, I can.'],
  [3,'Sắp xếp từ thành câu đúng: "subjects / do / What / have / you / today ?"','What subjects do you have today?'],
  [3,'Viết câu hỏi về ngày sinh nhật của bạn và câu trả lời.','When\'s your birthday? – It\'s in October. / It\'s on the second of October.'],
  [3,'Viết tên 4 môn học bằng tiếng Anh.','Ví dụ: Maths, English, Science, Music, Art, P.E., Vietnamese, IT.'],
  [4,'Viết đoạn 3–4 câu về bạn thân của em: khả năng của bạn và môn học bạn thích.','Ví dụ: My best friend is Minh. He can swim and play football. He can\'t sing. His favourite subject is Maths.']
 ]);
 add(M,4,'Home – Jobs – Weekend',[
  [1,'"Driver" là nghề gì?','tài xế','y tá','bác sĩ','giáo viên'],
  [1,'"Worker" là nghề gì?','công nhân','nông dân','học sinh','ca sĩ'],
  [1,'"Living room" là phòng nào?','phòng khách','phòng ngủ','phòng bếp','phòng tắm'],
  [2,'Chọn câu trả lời đúng: "What does your mother do?"','She\'s a nurse.','She\'s thirty.','She\'s in the kitchen.','She\'s tall.'],
  [2,'Hoàn thành: "Where does your father work?" – "He works ___ a hospital."','in','on','to','of'],
  [2,'Hoàn thành: "What do you do at the weekend?" – "I ___ my grandparents."','visit','visits','visiting','to visit'],
  [2,'Chọn câu trả lời đúng: "Where\'s the bathroom?"','It\'s next to the bedroom.','It\'s a bathroom.','It\'s nine o\'clock.','Yes, it is.'],
  [3,'Sắp xếp từ thành câu đúng: "your / What / does / do / father ?"','What does your father do?'],
  [3,'Viết câu nói bố em là một nông dân.','My father is a farmer.'],
  [3,'Viết 2 câu nói về việc em thường làm vào cuối tuần.','Ví dụ: I play football with my friends at the weekend. I watch TV in the evening.'],
  [4,'Viết đoạn 3–4 câu về một người trong gia đình em: nghề nghiệp, nơi làm việc và việc người đó làm vào cuối tuần.','Ví dụ: My mother is a teacher. She works at a primary school. At the weekend, she cooks and reads books. She likes her job very much.']
 ]);

 /* ===================== LỚP 5 ===================== */
 add(M,5,'About me – Home – Friends',[
  [1,'"Hometown" nghĩa là gì?','quê hương','thành phố','thị trấn','căn hộ'],
  [1,'"Nationality" nghĩa là gì?','quốc tịch','địa chỉ','tên','tuổi'],
  [1,'Chọn câu trả lời đúng: "Where do you live?"','I live in Ha Noi.','I\'m eleven.','I live Ha Noi in.','It\'s a city.'],
  [2,'Hoàn thành: "What ___ your friend like?" – "She\'s kind and friendly."','is','does','do','are'],
  [2,'Hoàn thành: "My brother is ___ than me."','taller','tall','more tall','tallest'],
  [2,'Chọn câu trả lời đúng: "What\'s your hometown like?"','It\'s quiet and beautiful.','It\'s in Hai Phong.','I like it very.','Yes, it is.'],
  [2,'Hoàn thành: "Who do you live ___?" – "I live with my parents."','with','in','at','on'],
  [3,'Sắp xếp từ thành câu đúng: "do / Where / live / you ?"','Where do you live?'],
  [3,'Viết câu so sánh hơn: "Nam is 140 cm tall. Minh is 150 cm tall." (Minh / tall)','Minh is taller than Nam.'],
  [3,'Viết câu nói về tính cách của bạn thân em (dùng 2 tính từ).','Ví dụ: My best friend is friendly and funny.'],
  [4,'Viết đoạn 3–4 câu giới thiệu bản thân: tên, quốc tịch, nơi ở và một sở thích.','Ví dụ: My name is Lan. I\'m Vietnamese. I live in a small village in Hai Phong. In my free time, I like reading comic books.']
 ]);
 add(M,5,'Future job – School activities',[
  [1,'"Writer" là nghề gì?','nhà văn','ca sĩ','họa sĩ','bác sĩ'],
  [1,'"Firefighter" là nghề gì?','lính cứu hỏa','cảnh sát','phi công','thợ xây'],
  [1,'"Science" là môn học nào?','Khoa học','Toán','Tin học','Lịch sử'],
  [2,'Hoàn thành: "I\'d like to be a doctor because I\'d like to ___ people."','help','helps','helping','helped'],
  [2,'Hoàn thành: "How often do you have Music?" – "___ a week."','Twice','Two','Second','Twice time'],
  [2,'Chọn câu trả lời đúng: "What are you doing?"','I\'m doing my homework.','I do my homework.','I did my homework.','I\'m a student.'],
  [2,'Hoàn thành: "She ___ to be a pilot in the future."','would like','would likes','like','is like'],
  [3,'Sắp xếp từ thành câu đúng: "would / What / like / to / you / be ?"','What would you like to be?'],
  [3,'Viết câu hỏi về số lần học môn Tiếng Anh trong một tuần và câu trả lời.','How often do you have English? – I have it four times a week.'],
  [3,'Viết câu nói về việc em đang làm lúc này (dùng thì hiện tại tiếp diễn).','Ví dụ: I\'m reading a book now. / I\'m doing my English exercises.'],
  [4,'Viết đoạn 3–4 câu về nghề em muốn làm trong tương lai: nghề gì, vì sao, em cần làm gì để đạt được.','Ví dụ: I\'d like to be a teacher in the future. I\'d like to teach children. I love working with kids. I will study hard to become a good teacher.']
 ]);
 add(M,5,'Holidays – Health – Weather',[
  [1,'"Windy" nghĩa là trời thế nào?','có gió','có mưa','có nắng','có tuyết'],
  [1,'"Toothache" nghĩa là gì?','đau răng','đau đầu','đau bụng','sốt'],
  [2,'Chọn câu trả lời đúng: "What\'s the weather like today?"','It\'s cloudy.','It\'s Monday.','It\'s a headache.','I\'m fine.'],
  [2,'Hoàn thành: "You shouldn\'t ___ too many sweets."','eat','eats','eating','to eat'],
  [2,'Hoàn thành: "Where ___ you go last summer?" – "I went to Da Nang."','did','do','are','were'],
  [2,'Thì quá khứ của "have" là gì?','had','haved','has','having'],
  [2,'Hoàn thành: "We ___ a lot of photos at the beach last week."','took','take','takes','taking'],
  [3,'Sắp xếp từ thành câu đúng: "matter / the / with / What\'s / you ?"','What\'s the matter with you?'],
  [3,'Viết lời khuyên cho bạn bị đau đầu (dùng "should").','Ví dụ: You should take a rest. / You should see a doctor.'],
  [3,'Viết lại câu ở thì quá khứ đơn: "I visit my grandparents." (thêm "last Sunday")','I visited my grandparents last Sunday.'],
  [4,'Viết đoạn 3–4 câu kể về một ngày nghỉ của em: thời tiết, nơi em đến, em đã làm gì và cảm xúc.','Ví dụ: Last Sunday, it was sunny. My family went to the beach. We swam and built sandcastles. We had a great time.']
 ]);
 add(M,5,'Transport – Places',[
  [1,'"By train" nghĩa là gì?','bằng tàu hỏa','bằng xe buýt','bằng xe đạp','bằng thuyền'],
  [1,'"Post office" nghĩa là gì?','bưu điện','hiệu thuốc','siêu thị','rạp chiếu phim'],
  [1,'"Island" nghĩa là gì?','hòn đảo','bãi biển','ngọn núi','dòng sông'],
  [2,'Chọn câu trả lời đúng: "How do you go to school?"','I go to school by bike.','I go to school at seven.','I like my school.','It\'s next to my house.'],
  [2,'Hoàn thành: "Excuse me, where\'s the cinema?" – "Go straight. It\'s ___ your left."','on','in','at','to'],
  [2,'Chọn câu đúng:','I walk to school every day.','I go to school by walk.','I go to school on foot by.','I walk school every day.'],
  [2,'Hoàn thành: "How ___ is it from here to the market?" – "It\'s about one kilometre."','far','long','much','many'],
  [3,'Sắp xếp từ thành câu đúng: "get / How / I / the / to / can / zoo ?"','How can I get to the zoo?'],
  [3,'Viết câu nói em đi học bằng xe buýt.','I go to school by bus.'],
  [3,'Viết câu chỉ đường: bưu điện ở bên phải (dùng "Turn ...").','Ví dụ: Turn right. The post office is on your right.'],
  [4,'Viết đoạn 3–4 câu kể về một chuyến đi của em: đến đâu, đi bằng gì, em đã thấy hoặc làm gì ở đó.','Ví dụ: Last summer, I went to Sa Pa with my family. We went there by coach. We saw beautiful mountains and visited Cat Cat Village. It was cold but wonderful.']
 ]);

 /* ===================== LỚP 6 ===================== */
 add(M,6,'(Bổ sung) Vocabulary & grammar',[
  [1,'Chọn từ đúng: My sister ___ her homework every evening.','does','do','is doing','done'],
  [1,'Chọn từ đúng: Look! The children ___ in the garden.','are playing','play','plays','played'],
  [1,'"Neighbourhood" nghĩa là gì?','khu dân cư, vùng lân cận','thành phố lớn','bãi biển','hòn đảo'],
  [1,'Chọn từ không cùng nhóm với các từ còn lại:','cinema','volleyball','badminton','karate'],
  [2,'Chọn từ đúng: There ___ some milk in the fridge.','is','are','have','has'],
  [2,'Chọn từ đúng: Is there ___ cheese left?','any','some','a','many'],
  [2,'Chọn từ đúng: Ha Noi is ___ than my hometown.','bigger','more big','biggest','big'],
  [2,'Chọn từ đúng: Students ___ wear uniforms at my school. It is a rule.','must','mustn\'t','can\'t','might'],
  [2,'Chọn từ đúng: Mount Everest is ___ mountain in the world.','the highest','the higher','higher','highest'],
  [2,'Chọn từ đúng: This is my book. It is ___.','mine','my','me','I'],
  [3,'Viết lại câu ở dạng phủ định: "My brother watches cartoons every afternoon."','My brother doesn\'t watch cartoons every afternoon.'],
  [3,'Sắp xếp từ thành câu đúng: "there / in / Are / any / your / posters / bedroom ?"','Are there any posters in your bedroom?'],
  [3,'Hoàn thành câu với dạng so sánh hơn của từ trong ngoặc: "Life in the countryside is ___ (peaceful) than life in the city."','Life in the countryside is more peaceful than life in the city.'],
  [3,'Viết câu hỏi cho câu trả lời sau: "She is reading a book in the library."','What is she doing in the library? / Where is she reading a book?'],
  [4,'Viết đoạn 3–4 câu miêu tả ngôi nhà mơ ước của em trong tương lai (dùng "will" và "might").','Ví dụ: My dream house will be by the sea. It will have a big garden and a swimming pool. There might be a robot to help me do the housework. I will live there with my family.']
 ]);

 /* ===================== LỚP 7 ===================== */
 add(M,7,'(Bổ sung) Tenses & vocabulary',[
  [1,'Chọn từ đúng: My father ___ to work by bus every day, but today he ___ a taxi.','goes – is taking','is going – takes','goes – takes','go – is taking'],
  [1,'Chọn từ đúng: We ___ a lot of old clothes to the poor last month.','donated','donate','will donate','are donating'],
  [1,'"Volunteer" nghĩa là gì?','tình nguyện viên','du khách','bác sĩ','nhạc sĩ'],
  [1,'"Vegetarian" nghĩa là gì?','người ăn chay','người đầu bếp','người bán hàng','người thích ăn thịt'],
  [2,'Chọn từ đúng: I think people ___ electric cars in the future.','will drive','drive','drove','are driving'],
  [2,'Chọn từ đúng: My sister enjoys ___ comic books in her free time.','reading','read','to read','reads'],
  [2,'Chọn từ đúng: ___ a boring film!','What','How','Which','Where'],
  [2,'Chọn từ đúng: Pho is ___ from bun cha.','different','same','similar','as'],
  [2,'Chọn từ đúng: Watching too much TV is bad for your eyes, ___ you shouldn\'t do it.','so','although','because','or'],
  [2,'Chọn từ đúng: It ___ me about twenty minutes to get to school.','takes','spends','has','gets'],
  [3,'Chia động từ trong ngoặc: "Last weekend, we (visit) ___ an old people\'s home and (sing) ___ songs for them."','visited – sang'],
  [3,'Viết lại câu dùng "as ... as": "Mai is 1.5 m tall. Lan is also 1.5 m tall."','Mai is as tall as Lan.'],
  [3,'Sắp xếp từ thành câu đúng: "sports / What / does / brother / your / play ?"','What sports does your brother play?'],
  [3,'Viết một câu khuyên bạn em nên làm gì để khỏe mạnh (dùng "should").','Ví dụ: You should eat more vegetables and do exercise every day.'],
  [4,'Viết đoạn 3–4 câu về sở thích của em: sở thích gì, bắt đầu từ khi nào, vì sao em thích (dùng đúng thì hiện tại đơn và quá khứ đơn).','Ví dụ: My hobby is collecting stamps. I started it two years ago when my uncle gave me some old stamps. I like it because it helps me learn about different countries. I will keep collecting stamps in the future.']
 ]);

 /* ===================== LỚP 8 ===================== */
 add(M,8,'(Bổ sung) Grammar & reading',[
  [1,'Chọn từ đúng: My brother hates ___ up early in the morning.','getting','get','got','gets'],
  [1,'Chọn từ đúng: In the countryside, people live ___ than in the city.','more slowly','slowlier','more slow','slowly'],
  [1,'"Volcano" nghĩa là gì?','núi lửa','lũ lụt','bão','hạn hán'],
  [2,'Chọn từ đúng: ___ it was raining heavily, the farmers kept working in the fields.','Although','Because','So','If'],
  [2,'Chọn từ đúng: While I ___ my homework, the lights went out.','was doing','did','am doing','do'],
  [2,'Chọn từ đúng: By this time next year, robots ___ the housework for us.','will be doing','are doing','did','do'],
  [2,'Chọn từ đúng: Nam said that he ___ a new laptop the day before.','had bought','buys','has bought','buy'],
  [2,'Chọn từ đúng: If we ___ more trees, the air will be cleaner.','plant','planted','will plant','planting'],
  [2,'Đọc đoạn văn và chọn câu trả lời đúng: "Mai lives in a small village near the mountains. Every morning, she helps her mother feed the chickens before going to school. At the weekend, she often goes fishing with her grandfather at the river." – Where does Mai live?','In a small village near the mountains.','In a big city.','Near the sea.','On a farm in the city.'],
  [2,'Đọc đoạn văn và chọn câu trả lời đúng: "Last Saturday, a strong storm hit Tam\'s town. The wind blew the roofs off several houses, and many trees fell down. Luckily, nobody was hurt because people had moved to a safe place." – Why was nobody hurt?','Because people had moved to a safe place.','Because the storm was weak.','Because no trees fell down.','Because the houses had strong roofs.'],
  [3,'Viết lại câu dùng dạng so sánh hơn của trạng từ: "Lan speaks English fluently. Hoa doesn\'t speak English very fluently." (Lan / Hoa)','Lan speaks English more fluently than Hoa.'],
  [3,'Chuyển sang câu tường thuật: Mai said, "I am learning to play the guitar."','Mai said (that) she was learning to play the guitar.'],
  [3,'Nối hai câu thành một câu phức dùng "because": "We stayed at home. The storm was very strong."','We stayed at home because the storm was very strong.'],
  [3,'Chia động từ trong ngoặc: "When the earthquake (happen) ___, we (have) ___ dinner."','happened – were having'],
  [4,'Viết đoạn 3–4 câu về việc em làm để bảo vệ môi trường, có dùng một câu điều kiện loại 1 và một câu phức với "although" hoặc "because".','Ví dụ: I always bring a cloth bag when I go shopping because plastic bags pollute the environment. Although it takes more time, I sort the rubbish at home. If everyone recycles more, our planet will be cleaner. I also turn off the lights when I leave a room.']
 ]);

 /* ===================== LỚP 9 ===================== */
 add(M,9,'(Bổ sung) Grammar & communication',[
  [1,'Chọn từ đúng: Linh didn\'t know ___ to do when she got lost in the old town.','what','which','where','how much'],
  [1,'Chọn từ đúng: Lots of traditional houses in my village ___ out of bamboo.','are made','make','made','making'],
  [1,'"Craft village" nghĩa là gì?','làng nghề','thành phố','khu chợ','bảo tàng'],
  [2,'Chọn từ đúng: By the time we got to the station, the train ___.','had already left','already left','has already left','already leaves'],
  [2,'Chọn từ đúng: The woman ___ lives next door is a famous singer.','who','which','whom','whose'],
  [2,'Chọn từ đúng: If I had more free time, I ___ volunteer work at the local hospital.','would do','will do','do','did'],
  [2,'Chọn từ đúng: I wish I ___ speak Japanese fluently.','could','can','will','am able'],
  [2,'Chọn từ đúng: Our teacher asked us ___ the project the following week.','whether we could finish','can we finish','if we can finished','whether could we finish'],
  [2,'Chọn lời đáp phù hợp: "I think we should visit the craft village this weekend." – "___"','That sounds like a good idea.','You\'re welcome.','Yes, please. I\'d love some.','No, I don\'t think I am.'],
  [2,'Chọn từ đúng: Please turn ___ the lights when you leave the classroom.','off','up','on','after'],
  [3,'Chuyển sang câu bị động: "People in my hometown make beautiful conical hats."','Beautiful conical hats are made by people in my hometown.'],
  [3,'Viết lại câu dùng mệnh đề quan hệ: "This is the book. My uncle gave it to me on my birthday."','This is the book which (that) my uncle gave to me on my birthday.'],
  [3,'Viết lại câu với "wish": "I can\'t play the piano."','I wish I could play the piano.'],
  [3,'Chuyển sang câu tường thuật: The teacher asked, "Have you finished your homework, Nam?"','The teacher asked Nam if (whether) he had finished his homework.'],
  [4,'Viết đoạn 3–4 câu nêu ý kiến của em về việc học sinh nên tham gia hoạt động tình nguyện, có dùng một câu điều kiện loại 2 và một mệnh đề quan hệ.','Ví dụ: In my opinion, students should take part in voluntary activities. If I had more free time, I would help elderly people who live alone in my neighbourhood. Volunteering is an activity that teaches us to care about others. It also helps us develop useful skills.']
 ]);
})();
