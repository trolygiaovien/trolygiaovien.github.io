/* NGÂN HÀNG KHOA HỌC TỰ NHIÊN – LỚP 8 — bổ sung đủ chuẩn. Câu hỏi nguyên bản, bám SGK Kết nối tri thức. */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Khoa học tự nhiên';

 /* ===================== CHỦ ĐỀ TỔNG HỢP ===================== */
 add(M,8,'Phản ứng hóa học',[
  [1,'Quá trình biến đổi từ chất này thành chất khác được gọi là gì?','Phản ứng hóa học','Biến đổi vật lí','Sự bay hơi','Sự hòa tan'],
  [1,'Trong phản ứng hóa học, chất ban đầu bị biến đổi được gọi là gì?','Chất đầu (chất phản ứng)','Sản phẩm','Chất xúc tác','Dung môi'],
  [2,'Phản ứng giải phóng năng lượng dưới dạng nhiệt ra môi trường được gọi là gì?','Phản ứng tỏa nhiệt','Phản ứng thu nhiệt','Phản ứng trao đổi','Phản ứng phân hủy'],
  [2,'Khối lượng mol của khí carbon dioxide (CO2) là bao nhiêu? (C = 12, O = 16)','44 g/mol','28 g/mol','32 g/mol','22 g/mol'],
  [2,'Dung dịch có pH = 3 thuộc loại nào?','Dung dịch acid','Dung dịch base','Dung dịch trung tính','Dung dịch kiềm mạnh'],
  [3,'Nêu các dấu hiệu thường gặp để nhận biết có phản ứng hóa học xảy ra.','Có chất mới tạo thành thể hiện qua: thay đổi màu sắc, xuất hiện chất khí (sủi bọt), tạo chất kết tủa (chất không tan), tỏa nhiệt hoặc phát sáng. Có trường hợp phải dùng thuốc thử để nhận ra.'],
  [3,'Tính số mol có trong 8 gam khí oxygen (O2), biết O = 16.','Khối lượng mol O2 = 2 × 16 = 32 g/mol. Số mol n = m/M = 8 : 32 = 0,25 mol.'],
  [4,'Vì sao trong một phản ứng hóa học, tổng khối lượng các chất sản phẩm luôn bằng tổng khối lượng các chất tham gia?','Trong phản ứng hóa học chỉ có liên kết giữa các nguyên tử thay đổi, làm phân tử này biến thành phân tử khác; số nguyên tử của mỗi nguyên tố được giữ nguyên, khối lượng mỗi nguyên tử không đổi. Do đó tổng khối lượng các chất được bảo toàn (định luật bảo toàn khối lượng).']
 ]);
 add(M,8,'Khối lượng riêng, áp suất',[
  [1,'Khối lượng riêng của một chất được xác định bằng công thức nào?','D = m/V','D = m.V','D = V/m','D = F/S'],
  [1,'Đơn vị đo áp suất trong hệ SI là gì?','Pascal (Pa)','Newton (N)','Joule (J)','Kilôgam (kg)'],
  [2,'Khối lượng riêng của nước ở điều kiện thường xấp xỉ bao nhiêu?','1000 kg/m3','100 kg/m3','1 kg/m3','7800 kg/m3'],
  [2,'Áp suất chất lỏng tại một điểm phụ thuộc vào yếu tố nào sau đây?','Độ sâu của điểm đó so với mặt thoáng và loại chất lỏng','Hình dạng của bình chứa','Màu sắc của chất lỏng','Diện tích đáy bình'],
  [2,'Lực đẩy Archimedes tác dụng lên vật nhúng trong chất lỏng có phương, chiều như thế nào?','Phương thẳng đứng, chiều từ dưới lên','Phương thẳng đứng, chiều từ trên xuống','Phương nằm ngang','Cùng chiều trọng lực'],
  [3,'Một vật có khối lượng 2 kg, thể tích 0,0005 m3. Tính khối lượng riêng của chất làm vật.','D = m/V = 2 : 0,0005 = 4000 kg/m3.'],
  [3,'Một người đứng trên sàn, tổng diện tích tiếp xúc của hai bàn chân là 0,04 m2, trọng lượng người là 500 N. Tính áp suất người đó tác dụng lên sàn.','Áp lực F = P = 500 N. Áp suất p = F/S = 500 : 0,04 = 12 500 Pa.'],
  [4,'Vì sao xe tăng rất nặng nhưng có thể đi được trên nền đất mềm, trong khi ô tô nhẹ hơn lại dễ bị lún?','Áp suất p = F/S. Xe tăng dùng bản xích có diện tích tiếp xúc với mặt đất rất lớn nên áp suất lên nền đất nhỏ, đất không bị lún nhiều. Ô tô tiếp xúc với đất chỉ bằng diện tích nhỏ của các bánh xe nên áp suất lớn hơn, dễ lún dù trọng lượng nhỏ hơn.']
 ]);
 add(M,8,'Điện, nhiệt',[
  [1,'Dòng điện là gì?','Dòng chuyển dời có hướng của các hạt mang điện','Sự chuyển động hỗn loạn của các phân tử','Dòng chảy của chất lỏng trong ống','Sự truyền nhiệt trong kim loại'],
  [1,'Đơn vị đo cường độ dòng điện là gì?','Ampe (A)','Vôn (V)','Oát (W)','Ôm (Ω)'],
  [2,'Dụng cụ nào dùng để đo hiệu điện thế giữa hai đầu một bóng đèn?','Vôn kế mắc song song với bóng đèn','Ampe kế mắc nối tiếp với bóng đèn','Nhiệt kế','Lực kế'],
  [2,'Hình thức truyền nhiệt chủ yếu của chất lỏng và chất khí là gì?','Đối lưu','Dẫn nhiệt','Bức xạ nhiệt','Nhiễm điện'],
  [2,'Khi nhiệt độ của một vật tăng thì đại lượng nào sau đây của vật tăng?','Nhiệt năng của vật','Khối lượng của vật','Trọng lượng của vật','Số phân tử của vật'],
  [3,'Nêu các tác dụng của dòng điện và cho một ví dụ về mỗi tác dụng.','Tác dụng nhiệt (bàn là, bếp điện nóng lên); tác dụng phát sáng (đèn LED, bóng đèn sáng); tác dụng hóa học (mạ điện, điện phân dung dịch); tác dụng sinh lí (dòng điện qua cơ thể gây co giật, dùng trong máy kích tim).'],
  [3,'Trình bày ba hình thức truyền nhiệt và môi trường truyền nhiệt chủ yếu của mỗi hình thức.','Dẫn nhiệt: truyền nhiệt từ phần này sang phần khác của vật hoặc giữa các vật tiếp xúc, chủ yếu ở chất rắn. Đối lưu: truyền nhiệt bằng các dòng chất lỏng hoặc chất khí, chủ yếu ở chất lỏng và chất khí. Bức xạ nhiệt: truyền nhiệt bằng các tia nhiệt, truyền được cả trong chân không.'],
  [4,'Vì sao vào mùa hè nên mặc quần áo sáng màu, còn mùa đông nên mặc quần áo tối màu?','Vật có màu tối hấp thụ bức xạ nhiệt tốt hơn vật sáng màu. Mùa hè mặc áo sáng màu để hấp thụ ít tia nhiệt từ Mặt Trời, cơ thể mát hơn; mùa đông mặc áo tối màu để hấp thụ nhiều bức xạ nhiệt, giữ cơ thể ấm hơn.']
 ]);
 add(M,8,'Sinh học cơ thể người, môi trường',[
  [1,'Cấp độ tổ chức nào sau đây là đơn vị cấu tạo và chức năng cơ bản của cơ thể người?','Tế bào','Mô','Cơ quan','Hệ cơ quan'],
  [1,'Cơ quan nào thực hiện chức năng lọc máu, tạo thành nước tiểu ở người?','Thận','Gan','Phổi','Dạ dày'],
  [2,'Tập hợp các cá thể cùng loài, cùng sống trong một khoảng không gian và thời gian xác định, có khả năng sinh sản tạo ra thế hệ mới được gọi là gì?','Quần thể sinh vật','Quần xã sinh vật','Hệ sinh thái','Sinh quyển'],
  [2,'Nhóm máu nào có thể truyền được cho người thuộc tất cả các nhóm máu khác trong hệ nhóm máu ABO?','Nhóm máu O','Nhóm máu A','Nhóm máu B','Nhóm máu AB'],
  [2,'Thành phần nào của máu có vai trò vận chuyển khí oxygen và carbon dioxide?','Hồng cầu','Bạch cầu','Tiểu cầu','Huyết tương'],
  [3,'Phân biệt nhân tố sinh thái vô sinh và nhân tố sinh thái hữu sinh, cho ví dụ.','Nhân tố vô sinh là các yếu tố không sống của môi trường như ánh sáng, nhiệt độ, nước, độ ẩm, đất, không khí. Nhân tố hữu sinh là các yếu tố sống như thực vật, động vật, vi sinh vật và con người, có ảnh hưởng đến sinh vật khác.'],
  [3,'Nêu các biện pháp bảo vệ hệ hô hấp mà em có thể thực hiện hằng ngày.','Không hút thuốc lá, tránh khói thuốc; đeo khẩu trang khi ra đường hoặc nơi nhiều bụi; giữ vệ sinh nơi ở, trồng nhiều cây xanh; tập thể dục, luyện thở đều đặn; giữ ấm cơ thể khi trời lạnh; tiêm phòng các bệnh về đường hô hấp.'],
  [4,'Vì sao ruột non được xem là nơi hấp thụ chất dinh dưỡng chủ yếu của cơ thể?','Ruột non rất dài, lớp niêm mạc có nhiều nếp gấp với các lông ruột và lông cực nhỏ nên diện tích bề mặt hấp thụ rất lớn. Thức ăn đến ruột non đã được tiêu hóa thành các chất đơn giản nhờ dịch tụy, dịch mật, dịch ruột; lớp niêm mạc có mạng mao mạch máu và mạch bạch huyết dày đặc giúp chất dinh dưỡng được hấp thụ nhanh và vận chuyển đi khắp cơ thể.']
 ]);
 add(M,8,'(Bổ sung) Phản ứng hóa học, điện, cơ thể người',[
  [1,'Theo quy ước, chiều dòng điện trong mạch điện là chiều nào?','Từ cực dương qua dây dẫn và các thiết bị điện tới cực âm của nguồn','Từ cực âm qua dây dẫn tới cực dương của nguồn','Chiều chuyển động của electron','Không có quy ước'],
  [1,'Hệ cơ quan nào có chức năng vận chuyển máu đi khắp cơ thể?','Hệ tuần hoàn','Hệ hô hấp','Hệ tiêu hóa','Hệ bài tiết'],
  [2,'Ở 25 °C và 1 bar, thể tích của 1 mol bất kì chất khí nào cũng xấp xỉ bao nhiêu?','24,79 lít','22,4 lít','1 lít','44 lít'],
  [2,'Chất nào sau đây là base?','NaOH','HCl','NaCl','CO2'],
  [2,'Tuyến nội tiết nào tiết hormone insulin giúp điều hòa lượng đường trong máu?','Tuyến tụy','Tuyến giáp','Tuyến yên','Tuyến trên thận'],
  [3,'Nêu các yếu tố ảnh hưởng đến tốc độ phản ứng hóa học.','Nồng độ chất phản ứng (nồng độ tăng, tốc độ tăng); nhiệt độ (nhiệt độ tăng, tốc độ tăng); diện tích tiếp xúc (chất rắn càng nhỏ, tốc độ càng tăng); chất xúc tác (làm tăng tốc độ nhưng không bị biến đổi sau phản ứng).'],
  [3,'Hãy vẽ sơ đồ bằng lời một mạch điện đơn giản gồm một nguồn điện, một công tắc và một bóng đèn; cho biết vai trò của từng bộ phận.','Mạch gồm: nguồn điện (pin) cung cấp năng lượng điện; dây dẫn nối các bộ phận thành mạch kín; công tắc để đóng, ngắt dòng điện; bóng đèn là thiết bị tiêu thụ điện, sáng khi mạch kín. Nối cực dương của pin với công tắc, công tắc với bóng đèn, bóng đèn về cực âm của pin.'],
  [4,'Vì sao người bị bệnh suy thận nặng phải chạy thận nhân tạo định kì?','Thận có chức năng lọc máu, loại bỏ chất thải, chất độc và cân bằng nước, muối khoáng. Khi suy thận nặng, thận không còn lọc được, chất độc như urea tích tụ trong máu gây nguy hiểm tính mạng. Chạy thận nhân tạo dùng máy lọc thay chức năng của thận, phải thực hiện định kì vì chất thải liên tục được sinh ra.']
 ]);

 /* ===================== CHƯƠNG I: PHẢN ỨNG HÓA HỌC ===================== */
 add(M,8,'Bài 1: Sử dụng một số hóa chất, thiết bị cơ bản trong phòng thí nghiệm',[
  [1,'Khi làm việc với hóa chất trong phòng thí nghiệm, việc nào sau đây là đúng?','Đọc kĩ nhãn hóa chất trước khi sử dụng','Nếm thử để xác định hóa chất','Ngửi trực tiếp miệng lọ hóa chất','Dùng tay lấy hóa chất rắn'],
  [1,'Khi đun nóng ống nghiệm chứa hóa chất, cần kẹp ống nghiệm ở vị trí nào?','Khoảng 1/3 ống nghiệm tính từ miệng ống','Ở đáy ống nghiệm','Ở chính giữa ống nghiệm','Ở sát miệng ống'],
  [2,'Thiết bị nào dùng để đo cường độ dòng điện trong mạch điện?','Ampe kế','Vôn kế','Joulemeter','Biến trở'],
  [2,'Khi đun nóng hóa chất trong ống nghiệm, cần hướng miệng ống nghiệm như thế nào?','Hướng về phía không có người','Hướng về phía mình để quan sát','Hướng thẳng lên trần','Hướng về phía bạn bên cạnh'],
  [2,'Hóa chất dùng xong còn dư thì xử lí thế nào?','Không đổ lại vào lọ đựng ban đầu, để vào nơi quy định','Đổ lại vào lọ đựng ban đầu','Đổ xuống bồn rửa','Mang về nhà'],
  [3,'Nêu một số quy tắc sử dụng hóa chất an toàn trong phòng thí nghiệm.','Đọc kĩ nhãn hóa chất; không dùng hóa chất không có nhãn; không nếm, không ngửi trực tiếp; lấy hóa chất bằng thìa, ống hút nhỏ giọt; lấy đủ lượng cần dùng, không đổ hóa chất thừa trở lại lọ; rửa tay sau khi làm thí nghiệm; hóa chất thải để đúng nơi quy định.'],
  [3,'Kể tên một số thiết bị điện cơ bản thường dùng trong phòng thí nghiệm và chức năng của chúng.','Pin, nguồn điện: cung cấp điện; công tắc: đóng ngắt mạch; bóng đèn, điốt phát quang: thiết bị tiêu thụ; biến trở: điều chỉnh cường độ dòng điện; ampe kế đo cường độ dòng điện; vôn kế đo hiệu điện thế; joulemeter đo năng lượng điện.'],
  [4,'Vì sao khi pha loãng acid sulfuric đặc người ta phải rót từ từ acid vào nước mà không làm ngược lại?','Khi acid sulfuric đặc hòa vào nước tỏa rất nhiều nhiệt. Rót acid từ từ vào nước, lượng nước lớn hấp thụ nhiệt nên dung dịch nóng lên từ từ, an toàn. Nếu rót nước vào acid, nước nhẹ hơn nổi trên bề mặt acid, nhiệt tỏa ra tập trung làm nước sôi đột ngột, bắn acid ra ngoài gây bỏng nguy hiểm.']
 ]);
 add(M,8,'Bài 2: Phản ứng hóa học',[
  [1,'Hiện tượng nào sau đây là biến đổi vật lí?','Nước đá tan thành nước lỏng','Sắt bị gỉ','Đốt cháy than','Thức ăn bị ôi thiu'],
  [1,'Trong phản ứng hóa học, chất mới được tạo thành gọi là gì?','Sản phẩm','Chất đầu','Chất phản ứng','Chất xúc tác'],
  [2,'Hiện tượng nào sau đây là biến đổi hóa học?','Đốt cháy khí methane tạo ra khí carbon dioxide và nước','Hòa tan đường vào nước','Nước sôi bốc hơi','Cắt tờ giấy thành nhiều mảnh'],
  [2,'Trong phản ứng hóa học, yếu tố nào được giữ nguyên?','Số lượng nguyên tử của mỗi nguyên tố','Số phân tử','Loại phân tử','Liên kết giữa các nguyên tử'],
  [2,'Phản ứng nào sau đây là phản ứng thu nhiệt?','Phân hủy đá vôi (CaCO3) khi nung ở nhiệt độ cao','Đốt cháy than','Đốt cháy cồn','Phản ứng của vôi sống với nước'],
  [3,'Phân biệt biến đổi vật lí và biến đổi hóa học, cho ví dụ.','Biến đổi vật lí: chất chỉ thay đổi trạng thái, hình dạng, kích thước nhưng vẫn giữ nguyên là chất ban đầu (nước đá tan, hòa tan muối). Biến đổi hóa học: chất biến đổi tạo ra chất khác (đốt cháy gỗ, sắt bị gỉ, đường cháy thành than).'],
  [3,'Mô tả diễn biến của phản ứng hóa học ở mức độ phân tử khi khí hydrogen cháy trong khí oxygen tạo thành nước.','Trước phản ứng: các nguyên tử H liên kết với nhau thành phân tử H2, các nguyên tử O liên kết thành phân tử O2. Trong phản ứng: các liên kết trong H2 và O2 bị phá vỡ, hình thành liên kết mới giữa H và O. Sau phản ứng: tạo thành các phân tử nước H2O; số nguyên tử H và O không thay đổi.'],
  [4,'Vì sao việc đốt cháy nhiên liệu được ứng dụng rộng rãi trong đời sống? Nêu một biện pháp sử dụng nhiên liệu tiết kiệm, hiệu quả.','Đốt cháy nhiên liệu (than, gas, xăng dầu) là phản ứng tỏa nhiệt, giải phóng nhiều năng lượng dùng để đun nấu, sưởi ấm, chạy máy móc, sản xuất điện. Để tiết kiệm cần cung cấp đủ oxygen cho cháy hoàn toàn, điều chỉnh lượng nhiên liệu vừa đủ, tắt bếp khi không dùng, tận dụng nhiệt thừa.']
 ]);
 add(M,8,'Bài 3: Mol và tỉ khối chất khí',[
  [1,'Một mol chứa bao nhiêu nguyên tử hoặc phân tử của chất đó?','6,022 × 10^23 hạt','6,022 × 10^22 hạt','1000 hạt','24,79 hạt'],
  [1,'Khối lượng mol của một chất có đơn vị là gì?','g/mol','g','mol','L/mol'],
  [2,'Khối lượng mol của nước (H2O) là bao nhiêu? (H = 1, O = 16)','18 g/mol','17 g/mol','34 g/mol','16 g/mol'],
  [2,'Tỉ khối của khí oxygen (O2) so với khí hydrogen (H2) là bao nhiêu?','16','2','32','0,5'],
  [2,'Khí nào sau đây nhẹ hơn không khí?','Khí hydrogen (H2)','Khí carbon dioxide (CO2)','Khí oxygen (O2)','Khí sulfur dioxide (SO2)'],
  [3,'Tính khối lượng của 0,5 mol khí carbon dioxide (CO2), biết C = 12, O = 16.','M(CO2) = 12 + 2 × 16 = 44 g/mol. Khối lượng m = n × M = 0,5 × 44 = 22 gam.'],
  [3,'Tính thể tích của 0,2 mol khí nitrogen (N2) ở 25 °C và 1 bar.','Ở 25 °C, 1 bar, 1 mol khí chiếm 24,79 lít. Thể tích V = n × 24,79 = 0,2 × 24,79 = 4,958 lít.'],
  [4,'Vì sao khí carbon dioxide thường tích tụ ở đáy giếng sâu hoặc hầm kín, gây nguy hiểm cho người xuống đó?','Tỉ khối của CO2 so với không khí là 44/29 ≈ 1,52, tức CO2 nặng hơn không khí khoảng 1,5 lần. Vì vậy CO2 sinh ra từ sự phân hủy chất hữu cơ hoặc hô hấp lắng xuống đáy giếng, hầm kín, chiếm chỗ của không khí. Người xuống đó thiếu oxygen, có thể ngạt thở; cần thông khí hoặc thử bằng ngọn lửa trước khi xuống.']
 ]);
 add(M,8,'Bài 4: Dung dịch và nồng độ',[
  [1,'Trong dung dịch nước đường, chất nào là dung môi?','Nước','Đường','Cả nước và đường','Không khí'],
  [1,'Đơn vị của nồng độ mol là gì?','mol/L (M)','g/mol','%','g/L'],
  [2,'Hòa tan 20 gam muối vào 80 gam nước. Nồng độ phần trăm của dung dịch là bao nhiêu?','20%','25%','80%','40%'],
  [2,'Dung dịch chưa hòa tan thêm được chất tan ở một nhiệt độ xác định gọi là gì?','Dung dịch bão hòa','Dung dịch chưa bão hòa','Dung dịch loãng','Dung môi'],
  [2,'Hòa tan 0,5 mol NaOH vào nước được 2 lít dung dịch. Nồng độ mol của dung dịch là bao nhiêu?','0,25 M','1 M','0,5 M','4 M'],
  [3,'Ở 20 °C, độ tan của muối ăn (NaCl) trong nước là khoảng 36 gam. Điều đó có nghĩa gì?','Có nghĩa là ở 20 °C, 100 gam nước hòa tan được tối đa 36 gam NaCl để tạo thành dung dịch bão hòa; nếu cho thêm NaCl, muối sẽ không tan nữa.'],
  [3,'Cần lấy bao nhiêu gam đường để pha được 200 gam dung dịch đường nồng độ 15%?','Khối lượng chất tan m = C% × m(dd) / 100% = 15 × 200 / 100 = 30 gam đường. Cần thêm 170 gam nước.'],
  [4,'Vì sao khi pha nước đường, dùng nước nóng thì đường tan nhanh và tan được nhiều hơn so với nước lạnh?','Độ tan của phần lớn chất rắn (như đường) trong nước tăng khi nhiệt độ tăng, nên nước nóng hòa tan được nhiều đường hơn. Ngoài ra ở nhiệt độ cao các phân tử nước chuyển động nhanh hơn, va chạm và tách các phân tử đường ra khỏi tinh thể nhanh hơn, nên đường tan nhanh hơn.']
 ]);
 add(M,8,'Bài 5: Định luật bảo toàn khối lượng và phương trình hóa học',[
  [1,'Định luật bảo toàn khối lượng phát biểu như thế nào?','Trong một phản ứng hóa học, tổng khối lượng các chất sản phẩm bằng tổng khối lượng các chất tham gia','Khối lượng sản phẩm luôn lớn hơn khối lượng chất tham gia','Khối lượng sản phẩm luôn nhỏ hơn khối lượng chất tham gia','Khối lượng các chất không liên quan nhau'],
  [1,'Phương trình hóa học biểu diễn điều gì?','Ngắn gọn một phản ứng hóa học bằng công thức hóa học','Khối lượng của một chất','Tính chất vật lí của chất','Màu sắc của sản phẩm'],
  [2,'Đốt cháy hoàn toàn 12 gam carbon trong 32 gam oxygen thu được khí carbon dioxide. Khối lượng carbon dioxide tạo thành là bao nhiêu?','44 gam','20 gam','32 gam','12 gam'],
  [2,'Hệ số thích hợp để cân bằng phương trình: ?H2 + O2 → ?H2O là gì?','2H2 + O2 → 2H2O','H2 + O2 → H2O','H2 + O2 → 2H2O','2H2 + 2O2 → 2H2O'],
  [2,'Phương trình hóa học 2Mg + O2 → 2MgO cho biết tỉ lệ số phân tử O2 và số phân tử MgO là bao nhiêu?','1 : 2','2 : 1','1 : 1','2 : 2'],
  [3,'Nêu các bước lập phương trình hóa học.','Bước 1: Viết sơ đồ phản ứng gồm công thức hóa học của các chất tham gia và sản phẩm. Bước 2: So sánh số nguyên tử của mỗi nguyên tố ở hai vế, đặt hệ số thích hợp để số nguyên tử mỗi nguyên tố hai vế bằng nhau. Bước 3: Viết phương trình hóa học hoàn chỉnh.'],
  [3,'Lập phương trình hóa học của phản ứng giữa nhôm (Al) và khí oxygen (O2) tạo thành aluminium oxide (Al2O3).','Sơ đồ: Al + O2 → Al2O3. Cân bằng: 4Al + 3O2 → 2Al2O3. Tỉ lệ số nguyên tử Al : số phân tử O2 : số phân tử Al2O3 = 4 : 3 : 2.'],
  [4,'Khi nung đá vôi (CaCO3) thành vôi sống, khối lượng chất rắn thu được nhỏ hơn khối lượng đá vôi ban đầu. Điều này có mâu thuẫn với định luật bảo toàn khối lượng không? Giải thích.','Không mâu thuẫn. Phản ứng CaCO3 → CaO + CO2 tạo ra khí CO2 thoát ra ngoài không khí, nên khối lượng chất rắn (CaO) còn lại nhỏ hơn. Nếu tính cả khối lượng khí CO2 thoát ra thì tổng khối lượng CaO và CO2 vẫn bằng khối lượng CaCO3 đã phân hủy, đúng với định luật bảo toàn khối lượng.']
 ]);
 add(M,8,'Bài 6: Tính theo phương trình hóa học',[
  [1,'Để tính khối lượng chất tham gia hoặc sản phẩm theo phương trình hóa học, trước hết cần làm gì?','Viết và cân bằng phương trình hóa học','Đo nhiệt độ phản ứng','Xác định màu sắc sản phẩm','Đo thể tích dung môi'],
  [1,'Hiệu suất phản ứng được tính bằng công thức nào?','H = (lượng sản phẩm thực tế : lượng sản phẩm lí thuyết) × 100%','H = lượng thực tế × lượng lí thuyết','H = (lượng lí thuyết : lượng thực tế) × 100%','H = lượng thực tế − lượng lí thuyết'],
  [2,'Cho phản ứng 2H2 + O2 → 2H2O. Đốt cháy 2 mol H2 cần bao nhiêu mol O2?','1 mol','2 mol','4 mol','0,5 mol'],
  [2,'Theo lí thuyết thu được 10 gam sản phẩm nhưng thực tế chỉ thu được 8 gam. Hiệu suất phản ứng là bao nhiêu?','80%','125%','20%','8%'],
  [2,'Cho phản ứng Zn + 2HCl → ZnCl2 + H2. Để tạo ra 0,3 mol H2 cần bao nhiêu mol HCl?','0,6 mol','0,3 mol','0,15 mol','1,2 mol'],
  [3,'Đốt cháy hoàn toàn 4,8 gam magnesium (Mg) trong khí oxygen. Tính khối lượng magnesium oxide (MgO) tạo thành. (Mg = 24, O = 16)','n(Mg) = 4,8 : 24 = 0,2 mol. Phương trình: 2Mg + O2 → 2MgO, nên n(MgO) = n(Mg) = 0,2 mol. M(MgO) = 40 g/mol. Khối lượng MgO = 0,2 × 40 = 8 gam.'],
  [3,'Cho 6,5 gam zinc (Zn) tác dụng hết với dung dịch HCl. Tính thể tích khí hydrogen thu được ở 25 °C, 1 bar. (Zn = 65)','n(Zn) = 6,5 : 65 = 0,1 mol. Phương trình: Zn + 2HCl → ZnCl2 + H2, nên n(H2) = n(Zn) = 0,1 mol. V(H2) = 0,1 × 24,79 = 2,479 lít.'],
  [4,'Vì sao trong thực tế sản xuất, lượng sản phẩm thu được thường nhỏ hơn lượng tính theo phương trình hóa học?','Vì phản ứng thường không xảy ra hoàn toàn, một phần chất tham gia còn dư; có thể xảy ra phản ứng phụ tạo sản phẩm khác; sản phẩm bị mất mát khi thu hồi, tách, tinh chế. Do đó hiệu suất thực tế thường nhỏ hơn 100%, người ta phải tính và tìm cách nâng cao hiệu suất.']
 ]);
 add(M,8,'Bài 7: Tốc độ phản ứng và chất xúc tác',[
  [1,'Tốc độ phản ứng là đại lượng chỉ điều gì?','Mức độ nhanh hay chậm của một phản ứng hóa học','Khối lượng sản phẩm tạo thành','Nhiệt lượng tỏa ra của phản ứng','Thể tích chất khí thoát ra'],
  [1,'Chất xúc tác có đặc điểm gì?','Làm tăng tốc độ phản ứng nhưng không bị biến đổi về chất và lượng sau phản ứng','Bị tiêu hao hết sau phản ứng','Làm phản ứng ngừng lại','Biến thành sản phẩm'],
  [2,'Vì sao thức ăn bảo quản trong tủ lạnh lâu bị hỏng hơn?','Nhiệt độ thấp làm giảm tốc độ các phản ứng phân hủy','Tủ lạnh không có không khí','Tủ lạnh làm thức ăn không chứa chất hữu cơ','Nhiệt độ thấp làm vi khuẩn sinh sôi nhanh'],
  [2,'Khi đốt củi, chẻ củi nhỏ sẽ cháy nhanh hơn củi to vì yếu tố nào?','Diện tích tiếp xúc giữa củi và oxygen tăng','Nồng độ oxygen trong không khí tăng','Có chất xúc tác','Nhiệt độ môi trường giảm'],
  [2,'Yếu tố nào sau đây làm giảm tốc độ phản ứng?','Giảm nhiệt độ của phản ứng','Tăng nồng độ chất phản ứng','Nghiền nhỏ chất rắn','Thêm chất xúc tác thích hợp'],
  [3,'Nêu các yếu tố ảnh hưởng đến tốc độ phản ứng và cho ví dụ ứng dụng trong đời sống.','Nhiệt độ: tăng nhiệt độ làm phản ứng nhanh hơn (nấu thức ăn trên lửa lớn). Nồng độ: nồng độ tăng, tốc độ tăng (thổi không khí vào lò than). Diện tích tiếp xúc: chất rắn chia nhỏ phản ứng nhanh hơn (đập nhỏ than). Chất xúc tác: tăng tốc độ phản ứng (men trong làm bánh, enzyme trong tiêu hóa).'],
  [3,'Giải thích vì sao viên zinc tác dụng với dung dịch HCl 2 M lại nhanh hơn với dung dịch HCl 0,5 M.','Dung dịch HCl 2 M có nồng độ lớn hơn, số phân tử HCl trong một đơn vị thể tích nhiều hơn, va chạm với bề mặt zinc nhiều hơn trong cùng một thời gian. Vì vậy tốc độ phản ứng với dung dịch HCl 2 M lớn hơn, khí hydrogen thoát ra nhanh hơn.'],
  [4,'Vì sao enzyme trong cơ thể được coi là chất xúc tác sinh học và có vai trò quan trọng với sự sống?','Enzyme làm tăng tốc độ các phản ứng hóa học trong cơ thể lên rất nhiều lần ở nhiệt độ cơ thể (khoảng 37 °C) mà bản thân không bị biến đổi sau phản ứng, giống chất xúc tác. Không có enzyme, các phản ứng tiêu hóa, hô hấp tế bào diễn ra quá chậm, không đủ cung cấp năng lượng và chất cần thiết cho sự sống.']
 ]);
 add(M,8,'Bài 8: Acid',[
  [1,'Acid là những hợp chất trong phân tử có đặc điểm gì?','Có nguyên tử hydrogen liên kết với gốc acid, khi tan trong nước tạo ra ion H+','Có nhóm OH liên kết với kim loại','Có kim loại liên kết với gốc acid','Chỉ có hai nguyên tố, một là oxygen'],
  [1,'Dung dịch acid làm giấy quỳ tím chuyển sang màu gì?','Màu đỏ','Màu xanh','Màu vàng','Không đổi màu'],
  [2,'Acid nào có trong giấm ăn?','Acetic acid (CH3COOH)','Hydrochloric acid (HCl)','Sulfuric acid (H2SO4)','Nitric acid (HNO3)'],
  [2,'Phương trình hóa học nào biểu diễn đúng phản ứng của magnesium với dung dịch hydrochloric acid?','Mg + 2HCl → MgCl2 + H2','Mg + HCl → MgCl + H','Mg + 2HCl → MgH2 + Cl2','2Mg + HCl → Mg2Cl + H2'],
  [2,'Acid nào được dùng nhiều trong sản xuất phân bón, ắc quy, chất tẩy rửa?','Sulfuric acid (H2SO4)','Acetic acid (CH3COOH)','Carbonic acid (H2CO3)','Citric acid'],
  [3,'Nêu tính chất hóa học của acid đã học và viết một phương trình hóa học minh họa.','Dung dịch acid làm quỳ tím chuyển đỏ. Acid tác dụng với nhiều kim loại (Mg, Zn, Fe...) tạo thành muối và khí hydrogen. Ví dụ: Fe + H2SO4 (loãng) → FeSO4 + H2.'],
  [3,'Nêu ứng dụng của hydrochloric acid và acetic acid.','Hydrochloric acid dùng để tẩy gỉ kim loại, sản xuất chất tẩy rửa, chế biến thực phẩm, dược phẩm; có trong dịch vị dạ dày. Acetic acid dùng làm giấm ăn, sản xuất tơ sợi, chất dẻo, dược phẩm, phẩm nhuộm.'],
  [4,'Vì sao không nên dùng các đồ đựng bằng kim loại như nhôm, sắt để muối dưa, cà hoặc chứa giấm lâu ngày?','Dưa, cà muối và giấm chứa acid (lactic acid, acetic acid). Acid tác dụng với kim loại như nhôm, sắt tạo thành muối tan và khí hydrogen, làm đồ đựng bị ăn mòn, hỏng dần; đồng thời các ion kim loại tan vào thức ăn gây hại cho sức khỏe. Nên dùng đồ sành, sứ, thủy tinh.']
 ]);
 add(M,8,'Bài 9: Base - thang pH',[
  [1,'Base là những hợp chất trong phân tử có đặc điểm gì?','Có nguyên tử kim loại liên kết với nhóm hydroxide (OH)','Có nguyên tử hydrogen liên kết với gốc acid','Chỉ gồm kim loại và oxygen','Có kim loại liên kết với gốc acid'],
  [1,'Dung dịch base làm giấy quỳ tím chuyển sang màu gì?','Màu xanh','Màu đỏ','Màu vàng','Không đổi màu'],
  [2,'Base nào sau đây là kiềm (tan được trong nước)?','NaOH','Cu(OH)2','Fe(OH)3','Mg(OH)2'],
  [2,'Dung dịch có pH = 7 là dung dịch như thế nào?','Trung tính','Có tính acid','Có tính base','Có tính kiềm mạnh'],
  [2,'Phương trình hóa học nào biểu diễn đúng phản ứng của NaOH với HCl?','NaOH + HCl → NaCl + H2O','NaOH + HCl → NaH + ClOH','2NaOH + HCl → Na2Cl + 2H2O','NaOH + 2HCl → NaCl2 + H2O'],
  [3,'Nêu tính chất hóa học của base và viết một phương trình hóa học minh họa.','Dung dịch base làm quỳ tím chuyển xanh, phenolphthalein không màu chuyển hồng. Base tác dụng với acid tạo thành muối và nước (phản ứng trung hòa). Ví dụ: Ca(OH)2 + 2HCl → CaCl2 + 2H2O.'],
  [3,'Trình bày ý nghĩa của thang pH và cách sử dụng giấy pH để xác định pH của một dung dịch.','Thang pH thường có giá trị từ 1 đến 14, cho biết độ acid hay base của dung dịch: pH nhỏ hơn 7 là acid, pH càng nhỏ tính acid càng mạnh; pH bằng 7 là trung tính; pH lớn hơn 7 là base, pH càng lớn tính base càng mạnh. Dùng giấy pH: nhúng giấy vào dung dịch rồi so màu với bảng màu chuẩn để đọc giá trị pH.'],
  [4,'Vì sao người bị thừa acid trong dạ dày (ợ chua, đau dạ dày) thường được dùng thuốc có chứa magnesium hydroxide hoặc aluminium hydroxide?','Dịch vị dạ dày chứa hydrochloric acid; khi thừa acid gây ợ chua, đau rát. Mg(OH)2, Al(OH)3 là các base, tác dụng với HCl theo phản ứng trung hòa tạo muối và nước, ví dụ Mg(OH)2 + 2HCl → MgCl2 + 2H2O, làm giảm lượng acid dư. Các base này ít tan, không gây kiềm mạnh nên an toàn với cơ thể.']
 ]);
 add(M,8,'Bài 10: Oxide',[
  [1,'Oxide là gì?','Hợp chất của hai nguyên tố, trong đó có một nguyên tố là oxygen','Hợp chất gồm kim loại và gốc acid','Hợp chất có nhóm hydroxide','Hợp chất của hydrogen với gốc acid'],
  [1,'Chất nào sau đây là oxide?','CaO','NaOH','HCl','NaCl'],
  [2,'Oxide nào sau đây là oxide acid?','SO2','Na2O','CaO','Fe2O3'],
  [2,'Oxide nào sau đây là oxide base?','CuO','CO2','SO3','P2O5'],
  [2,'Oxide nào sau đây là oxide trung tính (không tác dụng với acid và base)?','CO','CO2','CaO','Al2O3'],
  [3,'Phân loại oxide dựa trên tính chất hóa học, cho ví dụ mỗi loại.','Oxide acid: tác dụng với dung dịch base tạo muối và nước (CO2, SO2, P2O5). Oxide base: tác dụng với dung dịch acid tạo muối và nước (CaO, CuO, Fe2O3). Oxide lưỡng tính: tác dụng được với cả acid và base (Al2O3, ZnO). Oxide trung tính: không tác dụng với acid và base (CO, NO).'],
  [3,'Viết phương trình hóa học của phản ứng giữa carbon dioxide với dung dịch calcium hydroxide và phản ứng giữa copper(II) oxide với dung dịch hydrochloric acid.','CO2 + Ca(OH)2 → CaCO3 + H2O (oxide acid tác dụng với base). CuO + 2HCl → CuCl2 + H2O (oxide base tác dụng với acid).'],
  [4,'Vì sao khi để nước vôi trong ngoài không khí một thời gian, trên mặt nước xuất hiện lớp màng trắng?','Không khí có chứa khí carbon dioxide là một oxide acid. CO2 tác dụng với calcium hydroxide trong nước vôi trong tạo thành calcium carbonate không tan: CO2 + Ca(OH)2 → CaCO3 + H2O. CaCO3 màu trắng nổi lên tạo lớp màng mỏng trên mặt nước, chứng tỏ oxide acid phản ứng với dung dịch base.']
 ]);
 add(M,8,'Bài 11: Muối',[
  [1,'Muối là hợp chất được tạo thành từ những phần nào?','Cation kim loại (hoặc ammonium) và anion gốc acid','Kim loại và nhóm hydroxide','Hydrogen và gốc acid','Hai nguyên tố, một là oxygen'],
  [1,'Tên gọi của muối NaCl là gì?','Sodium chloride','Sodium chlorate','Sodium sulfate','Sodium carbonate'],
  [2,'Muối nào sau đây tan tốt trong nước?','NaNO3','BaSO4','AgCl','CaCO3'],
  [2,'Phản ứng nào sau đây tạo ra muối?','Zn + H2SO4 (loãng) → ZnSO4 + H2','2H2 + O2 → 2H2O','CaCO3 → CaO + CO2','C + O2 → CO2'],
  [2,'Khi cho dung dịch BaCl2 vào dung dịch Na2SO4, hiện tượng quan sát được là gì?','Xuất hiện kết tủa trắng BaSO4','Có khí không màu thoát ra','Dung dịch chuyển màu xanh','Không có hiện tượng gì'],
  [3,'Nêu các cách điều chế muối đã học và viết phương trình hóa học minh họa cho hai cách.','Các cách: acid tác dụng với kim loại; acid tác dụng với base; acid tác dụng với oxide base; acid tác dụng với muối; base tác dụng với muối; muối tác dụng với muối. Ví dụ: Mg + 2HCl → MgCl2 + H2; NaOH + HCl → NaCl + H2O.'],
  [3,'Nêu tính chất hóa học của muối và viết phương trình hóa học minh họa.','Muối tác dụng với kim loại mạnh hơn (Fe + CuSO4 → FeSO4 + Cu); tác dụng với acid (CaCO3 + 2HCl → CaCl2 + CO2 + H2O); tác dụng với dung dịch base (CuSO4 + 2NaOH → Cu(OH)2 + Na2SO4); tác dụng với dung dịch muối khác (BaCl2 + Na2SO4 → BaSO4 + 2NaCl). Các phản ứng trao đổi xảy ra khi tạo chất khí, chất kết tủa hoặc nước.'],
  [4,'Vì sao có thể dùng baking soda (NaHCO3) để làm bánh nở xốp và để khử mùi tanh của cá?','Khi nướng, NaHCO3 bị phân hủy bởi nhiệt và tác dụng với các acid trong bột tạo ra khí CO2; khí này tạo các lỗ xốp làm bánh nở. Mùi tanh của cá chủ yếu do các chất có tính base yếu, tuy nhiên NaHCO3 có khả năng trung hòa, hấp thụ mùi và còn phản ứng với acid; dung dịch của nó hòa tan, rửa trôi các chất gây mùi trên bề mặt cá.']
 ]);
 add(M,8,'Bài 12: Phân bón hóa học',[
  [1,'Ba nguyên tố dinh dưỡng chính mà cây trồng cần với lượng lớn là gì?','Nitrogen (N), phosphorus (P), potassium (K)','Carbon, hydrogen, oxygen','Iron, copper, zinc','Calcium, magnesium, sulfur'],
  [1,'Phân bón nào sau đây là phân đạm?','Urea (NH2)2CO','KCl','Ca(H2PO4)2','K2SO4'],
  [2,'Phân bón NPK là loại phân gì?','Phân hỗn hợp chứa cả ba nguyên tố N, P, K','Phân chỉ chứa nitrogen','Phân vi lượng','Phân chỉ chứa potassium'],
  [2,'Phân lân cung cấp nguyên tố nào cho cây trồng?','Phosphorus (P)','Nitrogen (N)','Potassium (K)','Iron (Fe)'],
  [2,'Phân đạm có tác dụng chủ yếu gì đối với cây trồng?','Kích thích cây sinh trưởng mạnh, phát triển lá và thân','Giúp cây ra hoa, kết quả, cứng cây','Tăng khả năng chịu hạn, chịu rét','Chỉ làm tăng độ chua của đất'],
  [3,'Nêu vai trò của phân đạm, phân lân, phân kali đối với cây trồng.','Phân đạm (cung cấp N) kích thích sinh trưởng, phát triển cành lá, tăng năng suất. Phân lân (cung cấp P) kích thích phát triển bộ rễ, ra hoa, tạo quả, hạt. Phân kali (cung cấp K) giúp tăng cường tổng hợp chất đường bột, tăng khả năng chống bệnh, chịu hạn, chịu rét.'],
  [3,'Vì sao cần bón phân đúng loại, đúng lượng, đúng lúc, đúng cách?','Bón đúng giúp cây hấp thụ tối đa chất dinh dưỡng, cho năng suất cao, tiết kiệm chi phí. Bón thừa gây lãng phí, dư lượng trong nông sản ảnh hưởng sức khỏe người dùng; phân dư thừa trôi ra sông hồ gây ô nhiễm nước, làm đất bị chua, chai cứng; bón sai thời điểm cây không hấp thụ được.'],
  [4,'Phân urea có công thức (NH2)2CO. Tính phần trăm khối lượng nitrogen trong urea và giải thích vì sao urea được dùng phổ biến làm phân đạm. (N = 14, H = 1, C = 12, O = 16)','M(urea) = 2 × 14 + 4 × 1 + 12 + 16 = 60 g/mol. %N = (28 : 60) × 100% ≈ 46,7%. Urea có hàm lượng nitrogen rất cao so với các phân đạm khác, dễ tan trong nước, cây dễ hấp thụ, không làm chua đất, nên được dùng phổ biến.']
 ]);

 /* ===================== CHƯƠNG II: KHỐI LƯỢNG RIÊNG VÀ ÁP SUẤT ===================== */
 add(M,8,'Bài 13: Khối lượng riêng',[
  [1,'Khối lượng riêng của một chất cho biết điều gì?','Khối lượng của một đơn vị thể tích chất đó','Thể tích của một đơn vị khối lượng','Trọng lượng của vật','Độ cứng của chất'],
  [1,'Đơn vị nào sau đây là đơn vị của khối lượng riêng?','kg/m3','kg','m3','N/m2'],
  [2,'1 g/cm3 bằng bao nhiêu kg/m3?','1000 kg/m3','1 kg/m3','100 kg/m3','0,001 kg/m3'],
  [2,'Hai vật có cùng thể tích, vật nào có khối lượng riêng lớn hơn thì có đặc điểm gì?','Có khối lượng lớn hơn','Có khối lượng nhỏ hơn','Có cùng khối lượng','Có thể tích lớn hơn'],
  [2,'Một khối sắt có khối lượng riêng 7800 kg/m3, thể tích 0,002 m3. Khối lượng của khối sắt là bao nhiêu?','15,6 kg','3,9 kg','39 kg','7,8 kg'],
  [3,'Một bình chứa 2 lít dầu ăn có khối lượng 1,6 kg. Tính khối lượng riêng của dầu ăn.','V = 2 lít = 0,002 m3. D = m/V = 1,6 : 0,002 = 800 kg/m3 (tức 0,8 g/cm3).'],
  [3,'Một vật bằng nhôm có khối lượng 540 g. Biết khối lượng riêng của nhôm là 2,7 g/cm3. Tính thể tích của vật.','V = m/D = 540 : 2,7 = 200 cm3.'],
  [4,'Vì sao dầu ăn nổi trên mặt nước còn bi sắt lại chìm xuống nước? Giải thích dựa vào khối lượng riêng.','Khối lượng riêng của dầu ăn (khoảng 800 kg/m3) nhỏ hơn của nước (1000 kg/m3) nên cùng một thể tích, dầu nhẹ hơn nước, dầu nổi lên trên. Khối lượng riêng của sắt (7800 kg/m3) lớn hơn nhiều so với nước nên bi sắt nặng hơn lượng nước cùng thể tích, bị chìm xuống.']
 ]);
 add(M,8,'Bài 14: Thực hành xác định khối lượng riêng',[
  [1,'Để xác định khối lượng riêng của một vật, cần đo những đại lượng nào?','Khối lượng và thể tích của vật','Trọng lượng và chiều dài của vật','Nhiệt độ và thể tích của vật','Khối lượng và chiều cao của vật'],
  [1,'Dụng cụ nào dùng để đo khối lượng của vật trong bài thực hành?','Cân','Bình chia độ','Thước','Lực kế'],
  [2,'Để đo thể tích của một vật rắn không thấm nước có hình dạng bất kì, người ta dùng cách nào?','Thả vật vào bình chia độ chứa nước, thể tích vật bằng phần nước dâng lên','Đo chiều dài rồi tính','Cân vật rồi chia cho 1000','Dùng thước đo đường kính'],
  [2,'Để xác định khối lượng riêng của một khối hộp chữ nhật, thể tích của khối hộp được tính bằng cách nào?','Đo ba kích thước dài, rộng, cao rồi nhân với nhau','Thả vào nước rồi đo phần nước tràn','Chia khối lượng cho chiều dài','Đo chu vi đáy'],
  [2,'Khi đo thể tích chất lỏng bằng bình chia độ, phải đặt mắt nhìn như thế nào?','Ngang với mặt thoáng của chất lỏng','Từ trên cao xuống','Từ dưới lên','Nhìn nghiêng'],
  [3,'Trình bày các bước xác định khối lượng riêng của một viên đá nhỏ.','Bước 1: Dùng cân đo khối lượng m của viên đá. Bước 2: Đổ nước vào bình chia độ, ghi thể tích V1; thả viên đá chìm hoàn toàn, ghi thể tích V2; thể tích đá V = V2 − V1. Bước 3: Tính D = m/V. Lặp lại vài lần và lấy giá trị trung bình.'],
  [3,'Trình bày cách xác định khối lượng riêng của một chất lỏng (ví dụ nước muối) bằng cân và ống đong.','Cân ống đong rỗng được khối lượng m1. Đổ một lượng chất lỏng vào ống đong, đọc thể tích V. Cân ống đong có chất lỏng được m2. Khối lượng chất lỏng m = m2 − m1. Khối lượng riêng D = m/V.'],
  [4,'Vì sao khi làm thực hành xác định khối lượng riêng, cần đo nhiều lần và lấy giá trị trung bình? Nêu một nguyên nhân gây sai số khi đo.','Mỗi lần đo đều có sai số do dụng cụ và cách đọc; đo nhiều lần rồi lấy trung bình giúp giảm sai số ngẫu nhiên, kết quả gần giá trị thực hơn. Nguyên nhân sai số: đọc vạch chia không đúng tầm mắt, vật còn dính nước làm tăng khối lượng, bọt khí bám vào vật làm thể tích đo lớn hơn thực, cân chưa được hiệu chỉnh.']
 ]);
 add(M,8,'Bài 15: Áp suất trên một bề mặt',[
  [1,'Áp lực là gì?','Lực ép có phương vuông góc với mặt bị ép','Lực kéo theo phương ngang','Lực đẩy của chất lỏng','Lực ma sát'],
  [1,'Áp suất được tính bằng công thức nào?','p = F/S','p = F.S','p = S/F','p = m/V'],
  [2,'1 Pa bằng bao nhiêu?','1 N/m2','1 N/cm2','1 kg/m3','1 N.m'],
  [2,'Muốn tăng áp suất của một vật lên mặt sàn, ta có thể làm gì?','Tăng áp lực hoặc giảm diện tích bị ép','Giảm áp lực','Tăng diện tích bị ép','Giảm cả áp lực và tăng diện tích'],
  [2,'Vì sao đầu đinh được làm nhọn?','Để giảm diện tích bị ép, tăng áp suất, đinh dễ xuyên vào gỗ','Để tăng diện tích bị ép','Để đinh nhẹ hơn','Để giảm áp suất lên gỗ'],
  [3,'Một thùng hàng có trọng lượng 1200 N đặt trên mặt sàn, diện tích tiếp xúc là 0,6 m2. Tính áp suất của thùng hàng lên mặt sàn.','Áp lực F = 1200 N. Áp suất p = F/S = 1200 : 0,6 = 2000 Pa.'],
  [3,'Nêu hai ví dụ trong đời sống về việc làm tăng áp suất và hai ví dụ về việc làm giảm áp suất.','Tăng áp suất: mài dao sắc (giảm diện tích lưỡi dao), đầu kim, đầu đinh làm nhọn. Giảm áp suất: móng nhà xây rộng, bánh xe tải có nhiều bánh và lớn, xe tăng có bản xích rộng, đi giày đế rộng trên tuyết.'],
  [4,'Vì sao khi đi trên bãi cát hoặc bùn lầy, nằm sấp hoặc đi bằng ván rộng lại ít bị lún hơn đứng thẳng?','Trọng lượng cơ thể (áp lực) không đổi nhưng khi nằm sấp hoặc dùng ván rộng, diện tích tiếp xúc với bề mặt tăng lên nhiều lần. Theo công thức p = F/S, áp suất lên cát hoặc bùn giảm, nên ít bị lún. Đứng thẳng chỉ tiếp xúc bằng hai bàn chân nhỏ, áp suất lớn, dễ lún.']
 ]);
 add(M,8,'Bài 16: Áp suất chất lỏng. Áp suất khí quyển',[
  [1,'Chất lỏng gây áp suất theo phương nào?','Theo mọi phương lên đáy bình, thành bình và các vật trong lòng nó','Chỉ theo phương thẳng đứng xuống đáy bình','Chỉ theo phương ngang lên thành bình','Không gây áp suất'],
  [1,'Trong cùng một chất lỏng đứng yên, áp suất tại các điểm có cùng độ sâu có đặc điểm gì?','Bằng nhau','Khác nhau tùy vị trí','Lớn hơn ở gần thành bình','Nhỏ hơn ở giữa bình'],
  [2,'Trong bình thông nhau chứa cùng một chất lỏng đứng yên, mực chất lỏng ở các nhánh như thế nào?','Luôn ở cùng một độ cao','Nhánh to cao hơn','Nhánh nhỏ cao hơn','Phụ thuộc hình dạng nhánh'],
  [2,'Áp suất khí quyển thay đổi thế nào khi lên cao?','Giảm dần','Tăng dần','Không thay đổi','Tăng rồi giảm'],
  [2,'Khi hút hết không khí trong hộp sữa bằng ống hút, hộp bị bẹp vào. Hiện tượng này do đâu?','Áp suất khí quyển bên ngoài lớn hơn áp suất bên trong hộp','Hộp bị nóng lên','Sữa trong hộp bị hút hết','Lực hút của ống hút'],
  [3,'Nêu một số ví dụ chứng tỏ sự tồn tại của áp suất khí quyển.','Hút hết không khí trong hộp sữa thì hộp bị bẹp; úp cốc nước có tấm bìa lại, nước không chảy ra; giác mút dính chặt vào tường; dùng ống hút uống nước; nắp chai bằng cao su dính chặt khi hút chân không.'],
  [3,'Vì sao người thợ lặn khi lặn sâu phải mặc áo lặn chịu được áp suất lớn?','Áp suất chất lỏng tăng theo độ sâu. Càng lặn sâu, áp suất của nước tác dụng lên cơ thể càng lớn, có thể gây tổn thương tai, phổi, mạch máu. Áo lặn chịu áp suất giúp bảo vệ cơ thể khỏi áp suất lớn của nước.'],
  [4,'Vì sao khi lên vùng núi cao, nhiều người bị ù tai, chóng mặt, khó thở?','Khi lên cao, áp suất khí quyển giảm. Áp suất không khí trong tai giữa chưa kịp cân bằng với áp suất bên ngoài nên màng nhĩ bị đẩy, gây ù tai. Đồng thời không khí loãng hơn, lượng oxygen trong mỗi lần hít vào ít hơn, cơ thể thiếu oxygen gây chóng mặt, khó thở.']
 ]);
 add(M,8,'Bài 17: Lực đẩy Archimedes',[
  [1,'Lực đẩy Archimedes xuất hiện khi nào?','Khi một vật được nhúng trong chất lỏng (hoặc chất khí)','Khi vật đặt trên mặt bàn','Khi vật được kéo trên mặt sàn','Khi vật rơi trong chân không'],
  [1,'Độ lớn của lực đẩy Archimedes phụ thuộc vào những yếu tố nào?','Trọng lượng riêng của chất lỏng và thể tích phần chất lỏng bị vật chiếm chỗ','Khối lượng của vật và độ sâu','Hình dạng của vật','Màu sắc của chất lỏng'],
  [2,'Công thức tính lực đẩy Archimedes là gì? (d là trọng lượng riêng của chất lỏng, V là thể tích phần chất lỏng bị vật chiếm chỗ)','FA = d.V','FA = d/V','FA = m.V','FA = P.V'],
  [2,'Một vật nhúng trong chất lỏng sẽ nổi lên khi nào?','Lực đẩy Archimedes lớn hơn trọng lượng của vật','Lực đẩy Archimedes nhỏ hơn trọng lượng của vật','Lực đẩy Archimedes bằng trọng lượng của vật','Trọng lượng vật bằng không'],
  [2,'Khi kéo một gàu nước từ dưới giếng lên, ta thấy gàu nhẹ hơn khi còn chìm trong nước. Vì sao?','Khi còn trong nước, gàu chịu lực đẩy Archimedes hướng lên','Nước trong gàu ít hơn','Trọng lực giảm trong nước','Gàu bị co lại'],
  [3,'Một vật có thể tích 0,003 m3 nhúng hoàn toàn trong nước. Trọng lượng riêng của nước là 10 000 N/m3. Tính lực đẩy Archimedes tác dụng lên vật.','FA = d.V = 10 000 × 0,003 = 30 N.'],
  [3,'Nêu điều kiện để một vật nhúng trong chất lỏng bị chìm, lơ lửng hoặc nổi lên.','Gọi P là trọng lượng vật, FA là lực đẩy Archimedes. Vật chìm xuống khi P > FA (trọng lượng riêng của vật lớn hơn của chất lỏng). Vật lơ lửng khi P = FA. Vật nổi lên khi P < FA (trọng lượng riêng của vật nhỏ hơn của chất lỏng).'],
  [4,'Vì sao tàu thủy làm bằng thép nặng hàng nghìn tấn vẫn nổi được trên mặt nước, trong khi một viên bi thép nhỏ lại chìm?','Tàu thủy được thiết kế có khoang rộng chứa không khí, nên thể tích phần tàu chiếm chỗ trong nước rất lớn; lực đẩy Archimedes FA = d.V đủ lớn để cân bằng với trọng lượng tàu, nên tàu nổi. Viên bi thép đặc có thể tích nhỏ, lực đẩy Archimedes nhỏ hơn trọng lượng của nó nên chìm.']
 ]);
 add(M,8,'Bài 18: Tác dụng làm quay của lực. Moment lực',[
  [1,'Lực có tác dụng làm quay một vật khi nào?','Khi lực tác dụng vào vật có trục quay cố định và giá của lực không đi qua trục quay','Khi giá của lực đi qua trục quay','Khi lực tác dụng vào vật không có trục quay','Khi lực song song với trục quay'],
  [1,'Đại lượng đặc trưng cho tác dụng làm quay của lực được gọi là gì?','Moment lực','Áp suất','Công suất','Trọng lượng'],
  [2,'Tác dụng làm quay của lực lên vật phụ thuộc vào những yếu tố nào?','Độ lớn của lực và khoảng cách từ trục quay đến giá của lực','Chỉ độ lớn của lực','Màu sắc và khối lượng của vật','Thời gian tác dụng lực'],
  [2,'Để mở một cánh cửa dễ dàng, ta nên tác dụng lực ở đâu?','Ở mép cửa, xa trục quay (bản lề)','Ở sát bản lề','Ở chính giữa cửa','Vị trí nào cũng như nhau'],
  [2,'Khi lực tác dụng có giá đi qua trục quay thì tác dụng làm quay của lực như thế nào?','Bằng không, vật không quay','Lớn nhất','Bằng trọng lượng của vật','Phụ thuộc độ lớn lực'],
  [3,'Nêu ví dụ trong đời sống về tác dụng làm quay của lực và cho biết trục quay trong mỗi ví dụ.','Mở cửa: trục quay là bản lề. Vặn vòi nước: trục quay là trục của vòi. Dùng cờ lê vặn đai ốc: trục quay là tâm đai ốc. Đạp xe đạp: trục quay là trục giữa bàn đạp. Quay tay nắm cửa, quay vô lăng xe.'],
  [3,'Vì sao cờ lê có cán dài giúp vặn đai ốc bị siết chặt dễ hơn cờ lê cán ngắn?','Tác dụng làm quay của lực (moment lực) càng lớn khi khoảng cách từ trục quay đến giá của lực càng lớn. Cờ lê cán dài cho khoảng cách này lớn, nên với cùng một lực tay, moment lực tác dụng lên đai ốc lớn hơn, dễ vặn hơn.'],
  [4,'Vì sao tay nắm cửa luôn được lắp ở mép cửa xa bản lề, và khi đẩy cửa ở gần bản lề ta phải dùng lực lớn hơn nhiều?','Cửa quay quanh trục là bản lề. Tác dụng làm quay phụ thuộc vào độ lớn lực và khoảng cách từ trục quay đến giá của lực. Lắp tay nắm xa bản lề giúp khoảng cách này lớn nhất, chỉ cần lực nhỏ đã tạo moment đủ để quay cửa. Đẩy gần bản lề, khoảng cách nhỏ nên phải tăng lực lên nhiều mới tạo được moment tương đương.']
 ]);
 add(M,8,'Bài 19: Đòn bẩy và ứng dụng',[
  [1,'Đòn bẩy là gì?','Một thanh cứng có thể quay quanh một điểm tựa cố định','Một sợi dây mềm','Một bánh xe có rãnh','Một mặt phẳng nghiêng'],
  [1,'Điểm mà đòn bẩy quay quanh được gọi là gì?','Điểm tựa','Điểm đặt lực','Trọng tâm','Điểm cân bằng'],
  [2,'Đòn bẩy cho lợi về lực khi nào?','Khoảng cách từ điểm tựa đến điểm đặt lực tác dụng lớn hơn khoảng cách từ điểm tựa đến điểm đặt vật','Khoảng cách từ điểm tựa đến điểm đặt lực nhỏ hơn khoảng cách đến vật','Hai khoảng cách bằng nhau','Điểm tựa đặt ở đầu đòn bẩy, phía lực'],
  [2,'Dụng cụ nào sau đây hoạt động dựa trên nguyên tắc đòn bẩy?','Kéo cắt giấy','Ròng rọc','Mặt phẳng nghiêng','Lò xo'],
  [2,'Loại đòn bẩy có điểm tựa nằm giữa điểm đặt lực và điểm đặt vật là loại nào? Ví dụ.','Đòn bẩy loại 1, ví dụ cái kéo, bập bênh','Đòn bẩy loại 2, ví dụ xe cút kít','Đòn bẩy loại 3, ví dụ cần câu','Không phải đòn bẩy'],
  [3,'Nêu ba loại đòn bẩy và cho ví dụ về mỗi loại.','Loại 1: điểm tựa ở giữa lực tác dụng và vật (kéo, kìm, bập bênh, cái bẩy). Loại 2: điểm tựa ở một đầu, vật ở giữa, lực ở đầu kia, cho lợi về lực (xe cút kít, cái bấm móng tay, dụng cụ mở nắp chai). Loại 3: điểm tựa ở một đầu, lực ở giữa, vật ở đầu kia, không cho lợi về lực nhưng lợi về đường đi (cần câu, cánh tay người, cái kẹp gắp).'],
  [3,'Mô tả cách dùng một thanh cứng để nâng một tảng đá nặng và giải thích vì sao có lợi về lực.','Đặt một đầu thanh dưới tảng đá, kê một vật cứng (điểm tựa) gần tảng đá, ấn vào đầu thanh phía xa. Vì khoảng cách từ điểm tựa đến tay ấn lớn hơn nhiều khoảng cách từ điểm tựa đến tảng đá, nên lực cần dùng nhỏ hơn trọng lượng tảng đá; đổi lại tay phải di chuyển một đoạn dài hơn.'],
  [4,'Cánh tay người là một đòn bẩy: khớp khuỷu tay là điểm tựa, cơ nhị đầu kéo xương cẳng tay ở gần khuỷu. Hãy phân tích loại đòn bẩy này và lợi ích của nó với cơ thể.','Cánh tay là đòn bẩy loại 3: điểm tựa (khuỷu) ở một đầu, lực của cơ tác dụng ở giữa gần khuỷu, vật cầm ở bàn tay ở đầu kia. Loại này không lợi về lực, cơ phải tạo lực lớn hơn trọng lượng vật, nhưng lợi về đường đi và tốc độ: cơ chỉ co một đoạn ngắn mà bàn tay di chuyển được xa và nhanh, giúp cử động linh hoạt, ném, với lấy đồ vật dễ dàng.']
 ]);

 /* ===================== CHƯƠNG III: ĐIỆN ===================== */
 add(M,8,'Bài 20: Hiện tượng nhiễm điện do cọ xát',[
  [1,'Có thể làm một vật nhiễm điện bằng cách nào?','Cọ xát vật với vật khác','Đun nóng vật','Làm lạnh vật','Nhúng vật vào nước'],
  [1,'Có bao nhiêu loại điện tích?','Hai loại: điện tích dương và điện tích âm','Một loại','Ba loại','Bốn loại'],
  [2,'Hai vật nhiễm điện cùng loại đặt gần nhau sẽ như thế nào?','Đẩy nhau','Hút nhau','Không tương tác','Vừa hút vừa đẩy'],
  [2,'Thanh nhựa sau khi cọ xát vào vải khô có thể hút được các mẩu giấy vụn. Điều này chứng tỏ gì?','Thanh nhựa đã bị nhiễm điện','Thanh nhựa bị nóng lên','Giấy vụn có từ tính','Thanh nhựa trở thành nam châm'],
  [2,'Khi cọ xát thanh thủy tinh vào lụa, thanh thủy tinh nhiễm điện dương vì sao?','Thanh thủy tinh mất bớt electron','Thanh thủy tinh nhận thêm electron','Thanh thủy tinh mất proton','Thanh thủy tinh nhận thêm proton'],
  [3,'Giải thích vì sao vào những ngày hanh khô, khi chải tóc bằng lược nhựa, tóc thường bị lược hút và dựng lên.','Khi chải, lược nhựa cọ xát với tóc làm cả lược và tóc bị nhiễm điện. Lược và tóc nhiễm điện khác loại nên hút nhau, tóc bị lược kéo theo. Các sợi tóc nhiễm điện cùng loại nên đẩy nhau, làm tóc dựng lên. Ngày hanh khô không khí ít ẩm nên điện tích không bị trung hòa nhanh.'],
  [3,'Trình bày cách giải thích sự nhiễm điện do cọ xát dựa vào cấu tạo nguyên tử.','Nguyên tử gồm hạt nhân mang điện dương và các electron mang điện âm; bình thường vật trung hòa về điện. Khi cọ xát hai vật, electron có thể dịch chuyển từ vật này sang vật kia. Vật nhận thêm electron nhiễm điện âm, vật mất electron nhiễm điện dương.'],
  [4,'Vì sao các xe chở xăng dầu thường có một đoạn dây xích kim loại thả xuống mặt đường?','Khi xe chạy, xăng dầu cọ xát với thành bồn và thành bồn cọ xát với không khí làm bồn chứa bị nhiễm điện, tích điện ngày càng nhiều. Điện tích lớn có thể gây tia lửa điện làm cháy nổ xăng dầu. Dây xích kim loại chạm đất giúp dẫn điện tích xuống đất liên tục, bồn không tích điện, bảo đảm an toàn.']
 ]);
 add(M,8,'Bài 21: Dòng điện, nguồn điện',[
  [1,'Dòng điện là gì?','Dòng chuyển dời có hướng của các hạt mang điện','Dòng chuyển động hỗn loạn của các electron','Sự dịch chuyển của các nguyên tử','Sự truyền nhiệt trong dây dẫn'],
  [1,'Nguồn điện có đặc điểm gì?','Có hai cực là cực dương (+) và cực âm (−)','Chỉ có một cực','Có ba cực','Không có cực'],
  [2,'Thiết bị nào sau đây là nguồn điện?','Pin','Bóng đèn','Công tắc','Dây dẫn'],
  [2,'Vật nào sau đây là vật dẫn điện?','Dây đồng','Thanh nhựa','Thanh thủy tinh','Miếng gỗ khô'],
  [2,'Vật nào sau đây là vật cách điện?','Vỏ nhựa của dây điện','Lõi đồng của dây điện','Thanh nhôm','Dung dịch muối'],
  [3,'Nguồn điện có vai trò gì? Kể tên một số nguồn điện thường dùng.','Nguồn điện cung cấp năng lượng điện để duy trì dòng điện lâu dài trong mạch, giúp các thiết bị điện hoạt động. Một số nguồn điện: pin (pin tiểu, pin cúc áo), ắc quy, máy phát điện, pin mặt trời, ổ lấy điện trong nhà.'],
  [3,'Phân biệt vật dẫn điện và vật cách điện, nêu ví dụ và ứng dụng của mỗi loại.','Vật dẫn điện là vật cho dòng điện đi qua (kim loại như đồng, nhôm; dung dịch muối, acid), dùng làm lõi dây dẫn, tiếp điểm. Vật cách điện là vật không cho dòng điện đi qua (nhựa, cao su, thủy tinh, sứ, gỗ khô), dùng làm vỏ dây điện, vỏ phích cắm, tay cầm dụng cụ điện để bảo đảm an toàn.'],
  [4,'Vì sao khi tay ướt không nên chạm vào các thiết bị điện, dù vỏ thiết bị được làm bằng nhựa cách điện?','Nước thường (có hòa tan muối, khoáng chất) là chất dẫn điện. Tay ướt làm giảm khả năng cách điện giữa cơ thể và các bộ phận mang điện; nước có thể chảy vào các khe hở, tiếp điểm dẫn điện ra ngoài vỏ. Khi đó dòng điện dễ truyền qua cơ thể xuống đất gây điện giật nguy hiểm.']
 ]);
 add(M,8,'Bài 22: Mạch điện đơn giản',[
  [1,'Mạch điện đơn giản gồm những bộ phận cơ bản nào?','Nguồn điện, dây dẫn, công tắc và thiết bị tiêu thụ điện','Chỉ nguồn điện và dây dẫn','Chỉ bóng đèn và công tắc','Nguồn điện và nhiệt kế'],
  [1,'Theo quy ước, chiều dòng điện trong mạch là chiều nào?','Từ cực dương qua dây dẫn và thiết bị điện đến cực âm của nguồn','Từ cực âm đến cực dương của nguồn','Chiều chuyển động của electron','Không có chiều xác định'],
  [2,'Công tắc trong mạch điện có vai trò gì?','Đóng, ngắt dòng điện trong mạch','Cung cấp năng lượng điện','Tiêu thụ điện','Đo cường độ dòng điện'],
  [2,'Dòng điện chỉ chạy trong mạch khi nào?','Mạch điện kín','Mạch điện hở','Không có nguồn điện','Công tắc mở'],
  [2,'Sơ đồ mạch điện là gì?','Hình vẽ biểu diễn mạch điện bằng các kí hiệu của các bộ phận','Ảnh chụp mạch điện','Bản mô tả bằng lời','Bảng giá các thiết bị'],
  [3,'Nêu các kí hiệu thường dùng để vẽ sơ đồ mạch điện cho các bộ phận: nguồn điện, bóng đèn, công tắc, dây dẫn.','Nguồn điện (pin): hai gạch song song, gạch dài là cực dương, gạch ngắn là cực âm. Bóng đèn: vòng tròn có dấu gạch chéo bên trong. Công tắc: đoạn thẳng gấp khúc có thể đóng, mở. Dây dẫn: đoạn thẳng nối các bộ phận. Ngoài ra còn kí hiệu ampe kế (A trong vòng tròn), vôn kế (V trong vòng tròn), biến trở, điốt.'],
  [3,'Vì sao cần vẽ sơ đồ mạch điện trước khi lắp mạch thật?','Sơ đồ giúp hình dung rõ cách nối các bộ phận, kiểm tra mạch có kín, có đúng chiều không trước khi lắp, tránh nối sai gây hỏng thiết bị hoặc ngắn mạch nguy hiểm; giúp người khác dễ hiểu, dễ sửa chữa và trao đổi vì kí hiệu được quy ước chung.'],
  [4,'Bóng đèn trong mạch không sáng dù đã đóng công tắc. Hãy nêu các nguyên nhân có thể và cách kiểm tra.','Nguyên nhân có thể: pin hết điện hoặc lắp ngược cực; dây dẫn bị đứt, mối nối lỏng làm mạch hở; bóng đèn bị cháy dây tóc; công tắc hỏng không tiếp điện. Cách kiểm tra: thay pin khác, kiểm tra từng mối nối, lắp bóng đèn vào mạch khác xem có sáng không, dùng dây nối tắt công tắc để kiểm tra. Nguyên tắc chung: mạch phải kín thì dòng điện mới chạy qua.']
 ]);
 add(M,8,'Bài 23: Tác dụng của dòng điện',[
  [1,'Khi dòng điện chạy qua, dây tóc bóng đèn nóng tới nhiệt độ cao và phát sáng. Đây là tác dụng gì của dòng điện?','Tác dụng nhiệt và tác dụng phát sáng','Tác dụng hóa học','Tác dụng sinh lí','Tác dụng từ'],
  [1,'Dòng điện đi qua cơ thể người gây co giật cơ, ngừng thở. Đây là tác dụng gì?','Tác dụng sinh lí','Tác dụng nhiệt','Tác dụng hóa học','Tác dụng phát sáng'],
  [2,'Thiết bị nào hoạt động chủ yếu dựa trên tác dụng nhiệt của dòng điện?','Bàn là điện','Đèn LED','Bình điện phân','Chuông điện'],
  [2,'Khi cho dòng điện chạy qua dung dịch copper(II) sulfate, thỏi than nối với cực âm được phủ một lớp đồng. Đây là tác dụng gì?','Tác dụng hóa học','Tác dụng nhiệt','Tác dụng sinh lí','Tác dụng phát sáng'],
  [2,'Đèn LED (điốt phát quang) phát sáng là do tác dụng nào của dòng điện?','Tác dụng phát sáng','Tác dụng nhiệt','Tác dụng hóa học','Tác dụng sinh lí'],
  [3,'Nêu các tác dụng của dòng điện và ứng dụng của mỗi tác dụng.','Tác dụng nhiệt: bếp điện, nồi cơm điện, bàn là, máy sấy. Tác dụng phát sáng: bóng đèn, đèn LED, đèn ống. Tác dụng hóa học: mạ điện, điện phân, nạp ắc quy. Tác dụng sinh lí: dùng trong y học như châm cứu điện, máy kích tim, máy trợ thính.'],
  [3,'Vì sao cần hết sức cẩn thận khi sử dụng điện trong gia đình? Nêu một số quy tắc an toàn điện.','Dòng điện qua cơ thể gây tác dụng sinh lí nguy hiểm: co giật, tim ngừng đập, bỏng, tử vong. Quy tắc: không chạm vào dây điện hở, không dùng điện khi tay ướt, không cắm nhiều thiết bị vào một ổ, ngắt điện trước khi sửa chữa, không chơi gần trạm điện, dây điện cao thế.'],
  [4,'Vì sao tác dụng nhiệt của dòng điện vừa có ích vừa có hại? Nêu cách hạn chế mặt có hại.','Có ích vì được dùng để đun nấu, sưởi, sấy khô, làm bóng đèn sợi đốt sáng. Có hại vì làm dây dẫn và thiết bị nóng lên gây hao phí điện năng, làm cháy vỏ dây, cháy nổ khi quá tải hoặc ngắn mạch. Hạn chế: dùng dây dẫn đủ lớn, có cầu chì hoặc aptomat tự ngắt khi quá tải, không dùng quá nhiều thiết bị cùng lúc, dùng thiết bị tiết kiệm điện như đèn LED.']
 ]);
 add(M,8,'Bài 24: Cường độ dòng điện và hiệu điện thế',[
  [1,'Cường độ dòng điện cho biết điều gì?','Độ mạnh, yếu của dòng điện','Chiều của dòng điện','Nhiệt độ của dây dẫn','Khả năng sinh công của nguồn'],
  [1,'Đơn vị đo hiệu điện thế là gì?','Vôn (V)','Ampe (A)','Oát (W)','Jun (J)'],
  [2,'1 A bằng bao nhiêu mA?','1000 mA','100 mA','10 mA','0,001 mA'],
  [2,'Hiệu điện thế giữa hai cực của nguồn điện khi chưa mắc vào mạch là bao nhiêu đối với một pin tròn thông thường?','1,5 V','220 V','12 V','0 V'],
  [2,'Đại lượng nào đặc trưng cho khả năng sinh ra dòng điện của nguồn điện?','Hiệu điện thế giữa hai cực của nguồn','Cường độ dòng điện','Nhiệt lượng tỏa ra','Khối lượng của nguồn'],
  [3,'Đổi các đơn vị sau: 0,25 A = ? mA; 1500 mA = ? A; 2,5 kV = ? V; 300 mV = ? V.','0,25 A = 250 mA; 1500 mA = 1,5 A; 2,5 kV = 2500 V; 300 mV = 0,3 V.'],
  [3,'Phân biệt cường độ dòng điện và hiệu điện thế về ý nghĩa, kí hiệu, đơn vị và dụng cụ đo.','Cường độ dòng điện (I) cho biết độ mạnh yếu của dòng điện, đơn vị ampe (A), đo bằng ampe kế. Hiệu điện thế (U) đặc trưng cho khả năng sinh ra dòng điện giữa hai điểm hoặc hai cực nguồn, đơn vị vôn (V), đo bằng vôn kế. Nguồn có hiệu điện thế thì mới tạo được dòng điện trong mạch kín.'],
  [4,'Vì sao mạng điện trong gia đình (220 V) rất nguy hiểm nhưng chạm vào hai cực của pin 1,5 V lại không gây điện giật?','Hiệu điện thế càng lớn thì dòng điện qua cơ thể càng lớn. Với 220 V, dòng điện qua cơ thể đủ lớn để gây tác dụng sinh lí nghiêm trọng: co giật, ngừng tim. Pin 1,5 V có hiệu điện thế rất nhỏ, dòng điện tạo ra qua cơ thể (có điện trở lớn) quá bé, không đủ gây cảm giác hay nguy hiểm.']
 ]);
 add(M,8,'Bài 25: Thực hành đo cường độ dòng điện và hiệu điện thế',[
  [1,'Để đo cường độ dòng điện qua bóng đèn, ampe kế phải được mắc như thế nào?','Nối tiếp với bóng đèn','Song song với bóng đèn','Song song với nguồn điện','Nối tiếp với vôn kế'],
  [1,'Để đo hiệu điện thế giữa hai đầu bóng đèn, vôn kế phải được mắc như thế nào?','Song song với bóng đèn','Nối tiếp với bóng đèn','Nối tiếp với nguồn','Nối tiếp với công tắc'],
  [2,'Khi mắc ampe kế hoặc vôn kế vào mạch, cần chú ý điều gì về các chốt?','Chốt dương (+) nối về phía cực dương của nguồn, chốt âm (−) về phía cực âm','Nối chốt nào cũng được','Chốt dương nối với cực âm của nguồn','Chỉ nối một chốt'],
  [2,'Trước khi đo, cần chọn ampe kế có giới hạn đo như thế nào?','Lớn hơn và gần với giá trị cần đo','Nhỏ hơn giá trị cần đo','Càng lớn càng tốt','Không cần quan tâm'],
  [2,'Trước khi đo, kim của ampe kế hoặc vôn kế phải ở vị trí nào?','Chỉ đúng vạch số 0','Chỉ vạch lớn nhất','Ở giữa thang đo','Vị trí bất kì'],
  [3,'Trình bày các bước đo hiệu điện thế giữa hai đầu một bóng đèn trong mạch điện.','Chọn vôn kế có giới hạn đo phù hợp, chỉnh kim về số 0. Mắc vôn kế song song với bóng đèn: chốt (+) nối với đầu đèn phía cực dương của nguồn, chốt (−) nối với đầu đèn phía cực âm. Đóng công tắc, đọc số chỉ của vôn kế theo đúng thang đo. Ghi kết quả và ngắt mạch.'],
  [3,'Nêu một số lưu ý để bảo đảm an toàn và đo chính xác khi sử dụng ampe kế và vôn kế.','Không mắc ampe kế trực tiếp vào hai cực nguồn điện vì gây đoản mạch làm hỏng ampe kế. Mắc đúng chốt dương, âm. Chọn thang đo phù hợp, nếu không biết thì chọn thang lớn trước. Chỉnh kim về 0 trước khi đo. Chỉ đóng công tắc khi đã kiểm tra mạch, đọc kết quả xong thì ngắt mạch.'],
  [4,'Vì sao ampe kế phải mắc nối tiếp còn vôn kế phải mắc song song với thiết bị cần đo? Nếu mắc ngược lại thì điều gì xảy ra?','Ampe kế đo cường độ dòng điện chạy qua thiết bị, nên phải mắc nối tiếp để toàn bộ dòng điện qua thiết bị cũng đi qua ampe kế. Vôn kế đo hiệu điện thế giữa hai đầu thiết bị nên phải mắc song song vào hai đầu đó. Nếu mắc ampe kế song song với nguồn hoặc thiết bị, dòng điện rất lớn chạy qua ampe kế gây hỏng dụng cụ; nếu mắc vôn kế nối tiếp, dòng điện trong mạch gần như bằng không, đèn không sáng và kết quả đo không đúng.']
 ]);

 /* ===================== CHƯƠNG IV: NHIỆT ===================== */
 add(M,8,'Bài 26: Năng lượng nhiệt và nhiệt năng',[
  [1,'Nhiệt năng của một vật là gì?','Tổng động năng của các phân tử cấu tạo nên vật','Tổng thế năng của vật so với mặt đất','Năng lượng do dòng điện tạo ra','Năng lượng ánh sáng vật nhận được'],
  [1,'Khi nhiệt độ của vật tăng, các phân tử cấu tạo nên vật chuyển động như thế nào?','Chuyển động nhanh hơn','Chuyển động chậm hơn','Ngừng chuyển động','Không thay đổi'],
  [2,'Phần năng lượng nhiệt mà vật nhận thêm hay mất đi trong quá trình truyền nhiệt được gọi là gì?','Nhiệt lượng','Nhiệt độ','Công suất','Động năng'],
  [2,'Đơn vị đo nhiệt lượng là gì?','Jun (J)','Độ C (°C)','Oát (W)','Kelvin (K)'],
  [2,'Cách nào sau đây làm tăng nhiệt năng của một miếng đồng?','Cọ xát miếng đồng lên mặt bàn hoặc đặt vào nước nóng','Đặt miếng đồng lên cao','Để miếng đồng trong tủ lạnh','Giữ nguyên miếng đồng ở nhiệt độ phòng'],
  [3,'Nội năng của vật là gì? Nội năng và nhiệt năng liên hệ với nhau như thế nào?','Nội năng là tổng động năng và thế năng của các phân tử cấu tạo nên vật. Nhiệt năng là phần nội năng do chuyển động của các phân tử (tổng động năng phân tử). Khi vật nhận nhiệt lượng, các phân tử chuyển động nhanh hơn, nhiệt năng và nội năng của vật tăng, nhiệt độ vật tăng.'],
  [3,'Nêu hai cách làm thay đổi nhiệt năng của một vật và cho ví dụ.','Thực hiện công: cọ xát hai bàn tay vào nhau tay nóng lên; dùng búa đập nhiều lần lên miếng kim loại, miếng kim loại nóng lên. Truyền nhiệt: thả thìa kim loại vào cốc nước nóng, thìa nóng lên; đặt cốc nước ra ngoài nắng, nước nóng lên.'],
  [4,'Vì sao khi bơm xe đạp nhanh và liên tục, thân bơm nóng lên? Giải thích dựa vào nhiệt năng.','Khi bơm, pit-tông cọ xát với thành ống bơm và nén không khí trong bơm, tức là ta thực hiện công lên không khí và ống bơm. Năng lượng đó chuyển thành nhiệt năng: các phân tử không khí và kim loại chuyển động nhanh hơn, nhiệt năng tăng, nhiệt độ tăng nên thân bơm nóng lên. Bơm càng nhanh, công thực hiện trong một thời gian càng nhiều, bơm càng nóng.']
 ]);
 add(M,8,'Bài 27: Thực hành đo năng lượng nhiệt bằng Joulemeter',[
  [1,'Joulemeter là dụng cụ dùng để đo đại lượng nào?','Năng lượng điện mà thiết bị tiêu thụ (tính bằng jun)','Nhiệt độ của nước','Khối lượng của vật','Cường độ dòng điện'],
  [1,'Trong thí nghiệm đo năng lượng nhiệt, dụng cụ nào dùng để đo nhiệt độ của nước?','Nhiệt kế','Joulemeter','Ampe kế','Cân'],
  [2,'Trong thí nghiệm, nước trong bình được làm nóng nhờ bộ phận nào?','Dây đốt (điện trở) nhúng trong nước, nối với nguồn điện qua joulemeter','Ánh sáng Mặt Trời','Ngọn lửa đèn cồn','Ma sát của que khuấy'],
  [2,'Vì sao khi làm thí nghiệm phải khuấy đều nước trong bình?','Để nhiệt độ nước trong bình đồng đều, đo chính xác hơn','Để nước nóng nhanh hơn','Để nước bay hơi','Để joulemeter hoạt động'],
  [2,'Kết quả thí nghiệm cho thấy nhiệt lượng nước nhận được để nóng lên có quan hệ thế nào với năng lượng điện do joulemeter đo?','Gần bằng nhau, phần chênh lệch là do mất mát nhiệt ra môi trường','Luôn lớn hơn nhiều','Không liên quan','Bằng nhau tuyệt đối'],
  [3,'Trình bày các bước tiến hành thí nghiệm đo năng lượng nhiệt cần để làm nóng một lượng nước bằng joulemeter.','Đổ một lượng nước xác định (đã cân) vào bình nhiệt lượng kế, đo nhiệt độ ban đầu. Nối dây đốt với nguồn điện qua joulemeter, điều chỉnh joulemeter về số 0. Đóng công tắc, khuấy đều nước; khi nhiệt độ nước tăng đến giá trị định trước thì ngắt mạch. Ghi số đo năng lượng trên joulemeter, nhiệt độ cuối; lặp lại với lượng nước hoặc độ tăng nhiệt độ khác.'],
  [3,'Thí nghiệm cho thấy nhiệt lượng cần để làm nóng nước phụ thuộc vào yếu tố nào? Nêu nhận xét.','Nhiệt lượng cần cung cấp tỉ lệ với khối lượng nước (lượng nước càng nhiều, năng lượng cần càng lớn) và tỉ lệ với độ tăng nhiệt độ (muốn nước nóng thêm nhiều độ hơn thì cần năng lượng nhiều hơn). Cùng khối lượng và độ tăng nhiệt độ, các chất khác nhau cần nhiệt lượng khác nhau.'],
  [4,'Vì sao kết quả đo được bằng joulemeter thường lớn hơn nhiệt lượng thực sự làm nóng nước? Nêu cách làm giảm sai lệch đó.','Một phần năng lượng điện chuyển thành nhiệt làm nóng dây đốt, bình chứa, nhiệt kế và que khuấy; một phần nhiệt truyền ra môi trường bên ngoài qua thành bình và mặt thoáng. Vì vậy năng lượng joulemeter đo được lớn hơn nhiệt lượng nước nhận. Để giảm sai lệch: dùng bình cách nhiệt tốt có nắp, làm thí nghiệm nhanh, khuấy đều, không đun quá nóng so với nhiệt độ phòng.']
 ]);
 add(M,8,'Bài 28: Sự truyền nhiệt',[
  [1,'Dẫn nhiệt là hình thức truyền nhiệt chủ yếu của chất nào?','Chất rắn','Chất lỏng','Chất khí','Chân không'],
  [1,'Hình thức truyền nhiệt nào có thể xảy ra trong chân không?','Bức xạ nhiệt','Dẫn nhiệt','Đối lưu','Cả dẫn nhiệt và đối lưu'],
  [2,'Khi đun nước, lớp nước ở dưới nóng lên, nở ra, nhẹ đi và chuyển lên trên, lớp nước lạnh ở trên chìm xuống. Đây là hình thức truyền nhiệt nào?','Đối lưu','Dẫn nhiệt','Bức xạ nhiệt','Nhiễm điện'],
  [2,'Chất nào sau đây dẫn nhiệt tốt nhất?','Đồng','Gỗ','Không khí','Nước'],
  [2,'Năng lượng từ Mặt Trời truyền xuống Trái Đất bằng hình thức nào?','Bức xạ nhiệt','Dẫn nhiệt','Đối lưu','Dẫn điện'],
  [3,'Giải thích vì sao nồi, xoong thường làm bằng kim loại còn quai và cán thường làm bằng nhựa hoặc gỗ.','Kim loại dẫn nhiệt tốt nên nồi, xoong bằng kim loại truyền nhiệt nhanh từ bếp vào thức ăn, nấu nhanh và tiết kiệm. Nhựa, gỗ dẫn nhiệt kém nên quai, cán bằng nhựa hoặc gỗ ít nóng, cầm được mà không bị bỏng.'],
  [3,'Vì sao vào mùa đông, chim thường đứng xù lông còn người thì mặc nhiều lớp áo mỏng ấm hơn một áo dày?','Giữa các lớp lông xù hoặc các lớp áo có các lớp không khí. Không khí dẫn nhiệt rất kém nên hạn chế nhiệt từ cơ thể truyền ra môi trường, giữ ấm tốt hơn. Nhiều lớp áo mỏng tạo ra nhiều lớp không khí cách nhiệt hơn một áo dày.'],
  [4,'Vì sao ở các nước nóng, nhà thường được sơn màu sáng và có mái cách nhiệt, trong khi tấm thu năng lượng Mặt Trời lại được sơn màu đen?','Vật màu sáng hấp thụ bức xạ nhiệt ít và phản xạ nhiều, nên nhà sơn sáng hấp thụ ít nhiệt từ Mặt Trời, trong nhà mát hơn; mái cách nhiệt hạn chế dẫn nhiệt từ mái xuống phòng. Ngược lại, vật màu đen hấp thụ bức xạ nhiệt rất tốt, nên tấm thu năng lượng Mặt Trời sơn đen để hấp thụ tối đa năng lượng, đun nóng nước nhanh.']
 ]);
 add(M,8,'Bài 29: Sự nở vì nhiệt',[
  [1,'Khi nhiệt độ tăng, các chất rắn, lỏng, khí có đặc điểm gì chung?','Đều nở ra (thể tích tăng)','Đều co lại','Không thay đổi thể tích','Chỉ chất khí nở ra'],
  [1,'Trong ba thể rắn, lỏng, khí, chất nào nở vì nhiệt nhiều nhất?','Chất khí','Chất rắn','Chất lỏng','Nở như nhau'],
  [2,'Các chất rắn khác nhau (đồng, sắt, nhôm) khi tăng cùng một nhiệt độ thì nở vì nhiệt như thế nào?','Khác nhau','Giống nhau hoàn toàn','Không nở','Chỉ nhôm nở'],
  [2,'Vì sao giữa các thanh ray đường tàu người ta để một khe hở?','Để thanh ray nở ra khi nóng không bị cong, gãy','Để tiết kiệm vật liệu','Để tàu chạy êm hơn','Để thoát nước mưa'],
  [2,'Băng kép (gồm hai thanh kim loại khác nhau tán chặt vào nhau) khi bị đốt nóng sẽ như thế nào?','Cong về phía thanh kim loại nở ít hơn','Cong về phía thanh kim loại nở nhiều hơn','Vẫn thẳng','Co ngắn lại'],
  [3,'Giải thích vì sao khi đun nước không nên đổ nước đầy ấm.','Khi đun, nước nóng lên và nở ra, thể tích tăng. Nếu đổ đầy, nước nở ra sẽ tràn ra ngoài, có thể làm tắt bếp hoặc gây bỏng. Nước (chất lỏng) nở vì nhiệt nhiều hơn ấm (chất rắn) nên phần nước dư sẽ tràn.'],
  [3,'Nêu một số ứng dụng của sự nở vì nhiệt trong đời sống và kĩ thuật.','Nhiệt kế chất lỏng (rượu, thủy ngân) dựa trên sự nở của chất lỏng; băng kép dùng trong bàn là, ấm điện để tự động ngắt điện; khe hở giữa các thanh ray, các nhịp cầu; ống kim loại dẫn hơi nóng có đoạn uốn cong; tháo nắp chai kim loại bị chặt bằng cách hơ nóng nắp.'],
  [4,'Vì sao khi rót nước sôi vào cốc thủy tinh dày, cốc dễ bị nứt hơn cốc thủy tinh mỏng?','Khi rót nước sôi, lớp thủy tinh bên trong tiếp xúc với nước nóng lên và nở ra trước, lớp bên ngoài còn lạnh chưa nở. Với cốc dày, sự chênh lệch nhiệt độ giữa lớp trong và lớp ngoài lớn và kéo dài, lớp trong nở nhiều bị lớp ngoài cản lại, tạo lực lớn làm cốc nứt. Cốc mỏng nóng lên gần đồng thời cả hai mặt nên nở đều, ít bị nứt.']
 ]);

 /* ===================== CHƯƠNG VII: SINH HỌC CƠ THỂ NGƯỜI ===================== */
 add(M,8,'Bài 30: Khái quát về cơ thể người',[
  [1,'Các cấp độ tổ chức trong cơ thể người được sắp xếp từ thấp đến cao như thế nào?','Tế bào → mô → cơ quan → hệ cơ quan → cơ thể','Cơ thể → hệ cơ quan → cơ quan → mô → tế bào','Mô → tế bào → cơ quan → cơ thể','Cơ quan → mô → tế bào → hệ cơ quan'],
  [1,'Cơ thể người được chia thành những phần nào?','Đầu, cổ, thân, tay và chân','Đầu và thân','Thân và tứ chi','Đầu, ngực, bụng'],
  [2,'Hệ cơ quan nào có chức năng biến đổi thức ăn thành chất dinh dưỡng mà cơ thể hấp thụ được?','Hệ tiêu hóa','Hệ hô hấp','Hệ bài tiết','Hệ nội tiết'],
  [2,'Hệ cơ quan nào có chức năng điều khiển, điều hòa và phối hợp hoạt động của các cơ quan trong cơ thể?','Hệ thần kinh','Hệ vận động','Hệ tuần hoàn','Hệ tiêu hóa'],
  [2,'Khoang ngực và khoang bụng được ngăn cách với nhau bởi bộ phận nào?','Cơ hoành','Cột sống','Xương sườn','Dạ dày'],
  [3,'Kể tên các hệ cơ quan chính trong cơ thể người và chức năng của ba hệ trong số đó.','Các hệ cơ quan: vận động, tiêu hóa, tuần hoàn, hô hấp, bài tiết, thần kinh, nội tiết, sinh dục. Ví dụ: hệ hô hấp trao đổi khí oxygen và carbon dioxide giữa cơ thể và môi trường; hệ tuần hoàn vận chuyển máu mang chất dinh dưỡng, khí và chất thải; hệ bài tiết lọc và thải các chất cặn bã, chất dư thừa ra khỏi cơ thể.'],
  [3,'Vì sao nói các hệ cơ quan trong cơ thể người có mối quan hệ chặt chẽ với nhau?','Các hệ cơ quan hoạt động phối hợp để cơ thể là một thể thống nhất: hệ tiêu hóa cung cấp chất dinh dưỡng, hệ hô hấp cung cấp oxygen, hệ tuần hoàn vận chuyển chúng tới mọi tế bào và mang chất thải đến hệ bài tiết; hệ thần kinh và nội tiết điều khiển, điều hòa tất cả. Khi một hệ hoạt động kém sẽ ảnh hưởng tới các hệ khác.'],
  [4,'Khi một người chạy nhanh, nhịp tim và nhịp thở đều tăng. Phân tích sự phối hợp giữa các hệ cơ quan trong hiện tượng này.','Khi chạy, hệ vận động (cơ, xương) hoạt động mạnh, cần nhiều năng lượng nên tế bào cơ cần nhiều oxygen và glucose, thải nhiều carbon dioxide. Hệ thần kinh điều khiển tăng nhịp thở để hệ hô hấp lấy nhiều oxygen hơn, tăng nhịp tim để hệ tuần hoàn vận chuyển oxygen, chất dinh dưỡng nhanh hơn và thải CO2 kịp thời. Da tiết mồ hôi để hạ nhiệt. Điều này cho thấy các hệ cơ quan phối hợp thống nhất.']
 ]);
 add(M,8,'Bài 31: Hệ vận động ở người',[
  [1,'Hệ vận động ở người gồm những thành phần nào?','Bộ xương và hệ cơ','Chỉ bộ xương','Chỉ hệ cơ','Xương và da'],
  [1,'Bộ xương người được chia thành những phần nào?','Xương đầu, xương thân và xương chi','Xương tay và xương chân','Xương dài và xương ngắn','Xương sườn và xương sống'],
  [2,'Thành phần hóa học nào giúp xương có tính cứng chắc?','Chất vô cơ (chủ yếu là muối calcium)','Chất hữu cơ (chất cốt giao)','Nước','Chất béo'],
  [2,'Cơ bám vào xương và khi co lại sẽ gây ra điều gì?','Làm xương chuyển động, tạo sự vận động của cơ thể','Làm xương dài ra','Làm xương mềm hơn','Không gây tác dụng gì'],
  [2,'Bệnh loãng xương thường do nguyên nhân chính nào?','Thiếu calcium và vitamin D, tuổi cao','Ăn quá nhiều rau xanh','Tập thể dục thường xuyên','Uống nhiều nước'],
  [3,'Nêu những biện pháp bảo vệ hệ vận động và phòng chống cong vẹo cột sống.','Ngồi học đúng tư thế, không mang vác vật nặng lệch một bên; bàn ghế phù hợp chiều cao; ăn đủ chất, nhất là calcium, vitamin D (sữa, cá, trứng, rau xanh); tắm nắng hợp lí; tập thể dục, thể thao đều đặn; tránh chấn thương; không hút thuốc, uống rượu bia.'],
  [3,'Nêu các bước sơ cứu khi gặp người bị gãy xương cẳng tay.','Giữ nạn nhân nằm hoặc ngồi yên, không cố nắn xương; dùng nẹp (gỗ, bìa cứng) đặt hai bên cẳng tay, lót vải mềm; buộc cố định nẹp ở trên và dưới chỗ gãy, không buộc trực tiếp vào chỗ gãy; dùng băng hoặc khăn treo tay trước ngực; đưa đến cơ sở y tế.'],
  [4,'Vì sao xương của người già thường giòn, dễ gãy và khi gãy lâu lành hơn xương của trẻ em?','Xương gồm chất hữu cơ (cốt giao) tạo tính mềm dẻo và chất vô cơ tạo tính cứng chắc. Ở người già, tỉ lệ chất hữu cơ giảm, chất vô cơ chiếm phần lớn, xương kém dẻo nên giòn, dễ gãy; đồng thời quá trình trao đổi chất và tái tạo tế bào xương chậm, mật độ xương giảm nên khi gãy lâu lành. Ở trẻ em, chất hữu cơ nhiều, xương dẻo dai và tế bào xương phân chia nhanh nên dễ liền.']
 ]);
 add(M,8,'Bài 32: Dinh dưỡng và tiêu hóa ở người',[
  [1,'Hệ tiêu hóa ở người gồm những phần chính nào?','Ống tiêu hóa và các tuyến tiêu hóa','Chỉ dạ dày và ruột','Miệng và thực quản','Gan và tụy'],
  [1,'Cơ quan nào của ống tiêu hóa là nơi hấp thụ chất dinh dưỡng chủ yếu?','Ruột non','Dạ dày','Thực quản','Ruột già'],
  [2,'Cơ quan nào sau đây là tuyến tiêu hóa?','Gan','Dạ dày','Thực quản','Ruột già'],
  [2,'Dạ dày thực hiện chức năng tiêu hóa nào?','Co bóp nhào trộn thức ăn và tiết dịch vị tiêu hóa một phần protein','Hấp thụ toàn bộ chất dinh dưỡng','Tiết dịch mật','Thải phân'],
  [2,'Nhóm chất dinh dưỡng nào cung cấp năng lượng chủ yếu cho cơ thể?','Carbohydrate (chất bột đường)','Vitamin','Chất khoáng','Nước'],
  [3,'Trình bày quá trình tiêu hóa thức ăn ở các cơ quan của ống tiêu hóa.','Miệng: răng nghiền, nước bọt chứa enzyme amylase bắt đầu biến đổi tinh bột. Thực quản: đẩy thức ăn xuống dạ dày. Dạ dày: co bóp nhào trộn, dịch vị tiêu hóa một phần protein. Ruột non: dịch tụy, dịch mật, dịch ruột biến đổi hoàn toàn thức ăn thành chất đơn giản và hấp thụ vào máu. Ruột già: hấp thụ nước, tạo và thải phân.'],
  [3,'Thế nào là chế độ dinh dưỡng hợp lí? Nêu một số nguyên tắc xây dựng khẩu phần ăn hợp lí.','Chế độ dinh dưỡng hợp lí cung cấp đủ năng lượng và các nhóm chất (carbohydrate, protein, lipid, vitamin, chất khoáng, nước) phù hợp với tuổi, giới tính, mức hoạt động. Nguyên tắc: ăn đa dạng, cân đối các nhóm chất; đủ lượng không thừa, không thiếu; ăn đúng giờ; hạn chế đường, muối, chất béo xấu; bảo đảm an toàn vệ sinh thực phẩm.'],
  [4,'Vì sao ăn chậm, nhai kĩ lại tốt cho tiêu hóa và sức khỏe?','Nhai kĩ làm thức ăn được nghiền nhỏ, trộn đều với nước bọt nên enzyme amylase biến đổi tinh bột hiệu quả hơn; thức ăn nhỏ tăng diện tích tiếp xúc với dịch tiêu hóa ở dạ dày, ruột, nên tiêu hóa và hấp thụ tốt hơn, dạ dày không phải co bóp quá sức. Ăn chậm còn giúp cơ thể kịp báo cảm giác no, tránh ăn quá nhiều gây béo phì.']
 ]);
 add(M,8,'Bài 33: Máu và hệ tuần hoàn của cơ thể người',[
  [1,'Máu gồm những thành phần nào?','Huyết tương và các tế bào máu (hồng cầu, bạch cầu, tiểu cầu)','Chỉ hồng cầu và nước','Huyết tương và bạch huyết','Chỉ huyết tương'],
  [1,'Tế bào máu nào có vai trò tham gia bảo vệ cơ thể chống lại vi khuẩn, virus?','Bạch cầu','Hồng cầu','Tiểu cầu','Huyết tương'],
  [2,'Tiểu cầu có chức năng gì?','Tham gia vào quá trình đông máu','Vận chuyển oxygen','Tiêu diệt vi khuẩn','Vận chuyển chất dinh dưỡng'],
  [2,'Tim người có bao nhiêu ngăn?','4 ngăn: 2 tâm nhĩ và 2 tâm thất','2 ngăn','3 ngăn','1 ngăn'],
  [2,'Người có nhóm máu AB có thể nhận máu từ những nhóm máu nào trong hệ ABO?','Tất cả các nhóm A, B, AB, O','Chỉ nhóm AB','Chỉ nhóm O','Chỉ nhóm A và B'],
  [3,'Trình bày đường đi của máu trong vòng tuần hoàn lớn và vòng tuần hoàn nhỏ.','Vòng tuần hoàn nhỏ: máu đỏ thẫm từ tâm thất phải theo động mạch phổi lên phổi, trao đổi khí trở thành máu đỏ tươi, theo tĩnh mạch phổi về tâm nhĩ trái. Vòng tuần hoàn lớn: máu đỏ tươi từ tâm thất trái theo động mạch chủ đi tới các cơ quan, trao đổi chất thành máu đỏ thẫm, theo tĩnh mạch chủ về tâm nhĩ phải.'],
  [3,'Thế nào là miễn dịch? Vì sao tiêm vaccine giúp phòng bệnh?','Miễn dịch là khả năng cơ thể chống lại các tác nhân gây bệnh nhờ hệ thống bạch cầu và kháng thể. Vaccine chứa tác nhân gây bệnh đã làm yếu, bất hoạt hoặc một phần của chúng; khi tiêm vào, cơ thể tạo kháng thể và ghi nhớ. Khi tác nhân gây bệnh thật xâm nhập, cơ thể nhanh chóng sản sinh kháng thể tiêu diệt, nên không mắc bệnh hoặc bệnh nhẹ.'],
  [4,'Vì sao khi truyền máu phải xét nghiệm nhóm máu của người cho và người nhận? Người nhóm máu O cho được mọi nhóm nhưng chỉ nhận được nhóm O, giải thích.','Nếu truyền nhầm nhóm máu, kháng nguyên trên hồng cầu người cho gặp kháng thể tương ứng trong huyết tương người nhận sẽ gây kết dính hồng cầu, tắc mạch, có thể tử vong. Hồng cầu nhóm O không có kháng nguyên A và B nên không bị kết dính bởi kháng thể của bất kì người nhận nào; nhưng huyết tương người nhóm O có cả kháng thể chống A và chống B nên chỉ nhận được máu nhóm O.']
 ]);
 add(M,8,'Bài 34: Hệ hô hấp ở người',[
  [1,'Hệ hô hấp ở người gồm những phần nào?','Đường dẫn khí (mũi, hầu, thanh quản, khí quản, phế quản) và hai lá phổi','Chỉ hai lá phổi','Mũi và miệng','Khí quản và tim'],
  [1,'Sự trao đổi khí giữa phổi và máu diễn ra ở đâu?','Các phế nang','Khí quản','Thanh quản','Mũi'],
  [2,'Khi hít vào, cơ hoành và các cơ liên sườn hoạt động như thế nào?','Co lại làm thể tích lồng ngực tăng, không khí tràn vào phổi','Dãn ra làm thể tích lồng ngực giảm','Không hoạt động','Co lại làm lồng ngực nhỏ đi'],
  [2,'Khí nào được máu lấy từ phế nang khi trao đổi khí ở phổi?','Oxygen','Carbon dioxide','Nitrogen','Hơi nước'],
  [2,'Mũi có vai trò gì đối với không khí hít vào?','Làm ấm, làm ẩm và lọc bụi, vi khuẩn trong không khí','Trao đổi khí với máu','Chỉ dẫn khí','Tạo tiếng nói'],
  [3,'Trình bày quá trình trao đổi khí ở phổi và ở tế bào.','Ở phổi: oxygen trong không khí phế nang khuếch tán vào máu, carbon dioxide từ máu khuếch tán ra phế nang rồi được thở ra ngoài. Ở tế bào: oxygen từ máu khuếch tán vào tế bào để thực hiện hô hấp tế bào tạo năng lượng; carbon dioxide do tế bào tạo ra khuếch tán vào máu để đưa về phổi.'],
  [3,'Nêu tác hại của khói thuốc lá đối với hệ hô hấp và biện pháp phòng tránh.','Khói thuốc chứa nicotine, carbon monoxide, chất gây ung thư; làm tê liệt lớp lông rung, tổn thương phế nang, gây viêm phế quản, khí phế thũng, ung thư phổi; carbon monoxide chiếm chỗ oxygen trong hồng cầu gây thiếu oxygen. Biện pháp: không hút thuốc, tránh xa khói thuốc, tuyên truyền cho người thân bỏ thuốc.'],
  [4,'Vì sao phế nang có cấu tạo phù hợp với chức năng trao đổi khí? Phân tích.','Phổi có hàng trăm triệu phế nang nhỏ tạo tổng diện tích trao đổi khí rất lớn. Thành phế nang rất mỏng, chỉ gồm một lớp tế bào, bao quanh là mạng mao mạch dày đặc, nên khí khuếch tán nhanh giữa phế nang và máu. Bề mặt phế nang luôn ẩm giúp khí dễ hòa tan và khuếch tán. Cấu tạo đó giúp trao đổi khí hiệu quả, đáp ứng nhu cầu oxygen của cơ thể.']
 ]);
 add(M,8,'Bài 35: Hệ bài tiết ở người',[
  [1,'Cơ quan bài tiết quan trọng nhất của cơ thể người là gì?','Thận','Phổi','Da','Gan'],
  [1,'Hệ bài tiết nước tiểu gồm những cơ quan nào?','Hai quả thận, ống dẫn nước tiểu, bóng đái và ống đái','Thận và gan','Thận và ruột già','Bóng đái và da'],
  [2,'Đơn vị chức năng của thận là gì?','Đơn vị thận (nephron)','Phế nang','Nơron','Tiểu cầu'],
  [2,'Sản phẩm bài tiết chủ yếu của phổi là gì?','Khí carbon dioxide','Nước tiểu','Mồ hôi','Phân'],
  [2,'Bệnh nào sau đây là bệnh của hệ bài tiết nước tiểu?','Sỏi thận','Viêm phổi','Loãng xương','Đau mắt đỏ'],
  [3,'Nêu các biện pháp bảo vệ hệ bài tiết nước tiểu.','Uống đủ nước (khoảng 1,5 – 2 lít mỗi ngày); không nhịn tiểu; ăn uống hợp lí, hạn chế ăn mặn, hạn chế thức ăn nhiều đạm, chất tạo sỏi; giữ vệ sinh cơ thể; không tự ý dùng thuốc; tránh các chất độc hại như rượu bia; khám sức khỏe định kì.'],
  [3,'Trình bày vai trò của hệ bài tiết đối với cơ thể.','Hệ bài tiết lọc và loại bỏ các chất thải, chất độc, chất dư thừa (urea, uric acid, muối, nước dư) ra khỏi cơ thể qua nước tiểu, mồ hôi, khí carbon dioxide; nhờ đó duy trì ổn định thành phần, nồng độ các chất trong môi trường trong cơ thể, giúp các cơ quan hoạt động bình thường.'],
  [4,'Vì sao thói quen nhịn tiểu và uống ít nước có thể dẫn đến bệnh sỏi thận?','Uống ít nước làm nước tiểu đậm đặc, các muối khoáng (calcium, oxalate, urate) dễ kết tinh. Nhịn tiểu khiến nước tiểu lưu lại lâu trong thận và bóng đái, các tinh thể có thời gian lắng, kết dính thành sỏi và tạo điều kiện cho vi khuẩn phát triển gây viêm. Sỏi gây đau, tắc đường tiểu, tổn thương thận. Vì vậy cần uống đủ nước, đi tiểu khi có nhu cầu.']
 ]);
 add(M,8,'Bài 36: Điều hòa môi trường trong của cơ thể người',[
  [1,'Môi trường trong của cơ thể người bao gồm những thành phần nào?','Máu, nước mô và bạch huyết','Nước uống và không khí','Dịch tiêu hóa và nước tiểu','Chỉ có máu'],
  [1,'Cân bằng môi trường trong là gì?','Sự duy trì ổn định các điều kiện lí, hóa của môi trường trong cơ thể','Sự thay đổi liên tục của các chất trong máu','Sự cân bằng giữa ăn và uống','Sự cân bằng của cơ thể khi đứng'],
  [2,'Cơ quan nào có vai trò chính trong việc điều hòa nồng độ các chất trong máu bằng cách lọc máu?','Thận','Dạ dày','Xương','Phổi'],
  [2,'Nồng độ glucose trong máu được điều hòa chủ yếu nhờ hormone nào?','Insulin và glucagon do tuyến tụy tiết ra','Adrenaline','Thyroxine','Hormone sinh trưởng'],
  [2,'Khi môi trường trong bị mất cân bằng kéo dài, cơ thể sẽ như thế nào?','Có thể gây rối loạn, bệnh tật, nguy hiểm đến sức khỏe','Khỏe mạnh hơn','Không có ảnh hưởng gì','Chỉ tăng chiều cao'],
  [3,'Vì sao cần duy trì cân bằng môi trường trong của cơ thể?','Các tế bào chỉ hoạt động bình thường khi các điều kiện của môi trường trong (nồng độ glucose, muối khoáng, pH, nhiệt độ, áp suất thẩm thấu...) ổn định. Nếu mất cân bằng, tế bào bị rối loạn hoạt động, dẫn đến bệnh tật như đái tháo đường, suy thận, rối loạn chuyển hóa.'],
  [3,'Ý nghĩa của việc xét nghiệm máu và nước tiểu định kì là gì?','Kết quả xét nghiệm cho biết các chỉ số như nồng độ glucose, uric acid, urea, cholesterol, protein trong nước tiểu... So với chỉ số bình thường, có thể phát hiện sớm tình trạng mất cân bằng môi trường trong và các bệnh như đái tháo đường, bệnh gout, bệnh thận để điều chỉnh ăn uống, điều trị kịp thời.'],
  [4,'Phân tích cơ chế điều hòa nồng độ glucose trong máu sau khi ăn và khi đói.','Sau khi ăn, glucose trong máu tăng, tuyến tụy tiết insulin kích thích tế bào hấp thụ glucose và gan chuyển glucose thành glycogen dự trữ, nồng độ glucose giảm về mức bình thường. Khi đói, glucose giảm, tuyến tụy tiết glucagon kích thích gan phân giải glycogen thành glucose đưa vào máu, nồng độ tăng trở lại. Hai hormone tác động ngược chiều giúp giữ nồng độ glucose ổn định.']
 ]);
 add(M,8,'Bài 37: Hệ thần kinh và các giác quan ở người',[
  [1,'Hệ thần kinh ở người gồm những bộ phận nào?','Bộ phận trung ương (não, tủy sống) và bộ phận ngoại biên (dây thần kinh, hạch thần kinh)','Chỉ có não','Não và tim','Tủy sống và các cơ'],
  [1,'Cơ quan thị giác là cơ quan nào?','Mắt','Tai','Mũi','Lưỡi'],
  [2,'Bộ phận nào của mắt tiếp nhận ánh sáng và chứa các tế bào thụ cảm?','Màng lưới (võng mạc)','Giác mạc','Thể thủy tinh','Lòng đen'],
  [2,'Người bị tật cận thị có đặc điểm gì?','Chỉ nhìn rõ vật ở gần, không nhìn rõ vật ở xa','Chỉ nhìn rõ vật ở xa','Không phân biệt được màu sắc','Không nhìn thấy trong tối'],
  [2,'Chất nào sau đây là chất gây nghiện, có hại cho hệ thần kinh?','Rượu, thuốc lá, ma túy','Nước lọc','Rau xanh','Sữa'],
  [3,'Nêu chức năng của hệ thần kinh và các biện pháp bảo vệ hệ thần kinh.','Hệ thần kinh điều khiển, điều hòa và phối hợp hoạt động của các cơ quan, giúp cơ thể thích nghi với môi trường. Bảo vệ: ngủ đủ giấc, đúng giờ; làm việc, học tập và nghỉ ngơi hợp lí; tránh căng thẳng; ăn uống đủ chất; không dùng chất kích thích, chất gây nghiện; tập thể dục đều đặn.'],
  [3,'Nêu cách phòng tránh tật cận thị ở học sinh.','Ngồi học đúng tư thế, giữ khoảng cách mắt với sách khoảng 25 – 30 cm; học nơi đủ ánh sáng; không đọc sách khi nằm hoặc trên xe; hạn chế dùng điện thoại, máy tính, cho mắt nghỉ sau mỗi 30 – 45 phút; ăn thực phẩm giàu vitamin A; khám mắt định kì.'],
  [4,'Vì sao sử dụng chất gây nghiện (ma túy, rượu) lại rất nguy hiểm cho hệ thần kinh và sức khỏe con người?','Chất gây nghiện tác động trực tiếp lên hệ thần kinh trung ương, làm rối loạn hoạt động của nơron và chất truyền tin, gây ảo giác, mất kiểm soát hành vi, suy giảm trí nhớ. Dùng lâu dài làm tổn thương não không hồi phục, gây lệ thuộc (nghiện), người dùng không thể tự dừng; sức khỏe suy sụp, dễ mắc bệnh, ảnh hưởng gia đình và xã hội.']
 ]);
 add(M,8,'Bài 38: Hệ nội tiết ở người',[
  [1,'Tuyến nội tiết là tuyến như thế nào?','Tiết hormone trực tiếp vào máu để điều hòa hoạt động của cơ thể','Tiết chất theo ống dẫn ra ngoài','Tiết dịch tiêu hóa vào ruột','Tiết mồ hôi ra da'],
  [1,'Tuyến nào sau đây là tuyến nội tiết?','Tuyến giáp','Tuyến nước bọt','Tuyến mồ hôi','Tuyến lệ'],
  [2,'Thiếu iodine trong khẩu phần ăn kéo dài có thể gây bệnh gì?','Bướu cổ','Đái tháo đường','Loãng xương','Cận thị'],
  [2,'Bệnh đái tháo đường liên quan đến sự thiếu hoặc rối loạn hoạt động của hormone nào?','Insulin','Thyroxine','Adrenaline','Hormone sinh trưởng'],
  [2,'Tuyến nội tiết nào tiết hormone sinh trưởng (GH), ảnh hưởng đến chiều cao của cơ thể?','Tuyến yên','Tuyến tụy','Tuyến trên thận','Tuyến giáp'],
  [3,'Kể tên một số tuyến nội tiết ở người và chức năng của chúng.','Tuyến yên: tiết hormone sinh trưởng và điều khiển các tuyến nội tiết khác. Tuyến giáp: tiết thyroxine điều hòa trao đổi chất. Tuyến tụy: tiết insulin, glucagon điều hòa glucose máu. Tuyến trên thận: tiết adrenaline điều hòa nhịp tim, huyết áp khi căng thẳng. Tuyến sinh dục: tiết hormone sinh dục quyết định đặc điểm giới tính.'],
  [3,'Nêu các biện pháp bảo vệ hệ nội tiết và phòng bệnh đái tháo đường.','Ăn uống cân đối, hạn chế đường, chất béo, dùng muối iodine; tập thể dục đều đặn, duy trì cân nặng hợp lí; ngủ đủ, giảm căng thẳng; không dùng thuốc, nhất là thuốc có hormone, khi chưa có chỉ định; khám sức khỏe và xét nghiệm đường máu định kì.'],
  [4,'Vì sao người bị bướu cổ do thiếu iodine thì tuyến giáp lại phình to ra? Giải thích.','Iodine là thành phần tạo nên hormone thyroxine của tuyến giáp. Khi thiếu iodine, tuyến giáp không tạo đủ thyroxine; tuyến yên liên tục tiết hormone kích thích tuyến giáp hoạt động mạnh hơn. Tuyến giáp phải tăng kích thước, tăng số tế bào để cố sản xuất hormone, lâu ngày phình to thành bướu cổ. Phòng bệnh bằng cách dùng muối iodine, ăn hải sản.']
 ]);
 add(M,8,'Bài 39: Da và điều hòa thân nhiệt ở người',[
  [1,'Da người có cấu tạo gồm những lớp nào?','Lớp biểu bì, lớp bì và lớp mỡ dưới da','Chỉ có lớp biểu bì','Lớp bì và lớp cơ','Lớp sừng và lớp xương'],
  [1,'Thân nhiệt bình thường của người khoảng bao nhiêu?','37 °C','35 °C','40 °C','30 °C'],
  [2,'Khi trời nóng, cơ thể điều hòa thân nhiệt bằng cách nào?','Mao mạch dưới da dãn, tăng tiết mồ hôi để tỏa nhiệt','Mao mạch dưới da co lại','Run cơ để sinh nhiệt','Dựng lông'],
  [2,'Khi trời lạnh, hiện tượng "nổi da gà" và run xảy ra có tác dụng gì?','Giảm thoát nhiệt và tăng sinh nhiệt để giữ ấm cơ thể','Tăng tỏa nhiệt ra môi trường','Làm cơ thể mát hơn','Không có tác dụng'],
  [2,'Bộ phận nào của da có vai trò chủ yếu trong việc tiết mồ hôi để điều hòa thân nhiệt?','Tuyến mồ hôi','Tuyến nhờn','Lớp sừng','Lông và bao lông'],
  [3,'Nêu các chức năng của da.','Bảo vệ cơ thể khỏi tác động cơ học, vi khuẩn, tia tử ngoại; điều hòa thân nhiệt nhờ tuyến mồ hôi, mao mạch và lớp mỡ; bài tiết mồ hôi; tiếp nhận kích thích từ môi trường nhờ các thụ quan (nóng, lạnh, đau, áp lực); tổng hợp vitamin D dưới ánh nắng.'],
  [3,'Nêu các biện pháp chăm sóc, bảo vệ da và phòng chống bệnh về da.','Tắm rửa, thay quần áo thường xuyên; giữ da sạch, khô; không dùng chung khăn, quần áo; tránh tiếp xúc hóa chất, ánh nắng gắt (đội mũ, bôi kem chống nắng); ăn đủ rau quả, uống đủ nước; không tự nặn mụn, gãi trầy xước; khám khi da có dấu hiệu bất thường.'],
  [4,'Vì sao vào ngày hè nóng bức, sau khi vận động mạnh ta không nên tắm nước lạnh ngay?','Khi vận động mạnh trời nóng, mao mạch dưới da dãn rộng, mồ hôi tiết nhiều để tỏa nhiệt. Tắm nước lạnh đột ngột làm mao mạch da co mạnh, nhiệt trong cơ thể không thoát ra được, thân nhiệt điều hòa rối loạn, mạch máu và tim bị kích thích mạnh, có thể gây choáng, cảm lạnh, nguy hiểm đến tim mạch. Nên nghỉ cho ráo mồ hôi, hạ nhịp tim rồi tắm nước mát vừa.']
 ]);
 add(M,8,'Bài 40: Sinh sản ở người',[
  [1,'Cơ quan sản sinh ra tinh trùng ở nam giới là gì?','Tinh hoàn','Tuyến tiền liệt','Ống dẫn tinh','Túi tinh'],
  [1,'Cơ quan sản sinh ra trứng ở nữ giới là gì?','Buồng trứng','Tử cung','Ống dẫn trứng','Âm đạo'],
  [2,'Sự thụ tinh ở người thường diễn ra ở đâu?','Ống dẫn trứng','Tử cung','Buồng trứng','Âm đạo'],
  [2,'Phôi làm tổ và phát triển thành thai ở cơ quan nào?','Tử cung','Buồng trứng','Ống dẫn trứng','Bóng đái'],
  [2,'Hiện tượng kinh nguyệt ở nữ giới xảy ra khi nào?','Khi trứng không được thụ tinh, lớp niêm mạc tử cung bong ra','Khi trứng được thụ tinh','Khi mang thai','Khi cơ thể thiếu nước'],
  [3,'Thế nào là thụ tinh và thụ thai?','Thụ tinh là quá trình tinh trùng kết hợp với trứng tạo thành hợp tử, thường xảy ra ở ống dẫn trứng. Thụ thai là quá trình hợp tử phân chia thành phôi di chuyển xuống và bám vào lớp niêm mạc tử cung (làm tổ) để phát triển thành thai.'],
  [3,'Nêu một số bệnh lây truyền qua đường sinh dục và cách phòng tránh.','Một số bệnh: lậu, giang mai, HIV/AIDS, viêm gan B, sùi mào gà. Phòng tránh: sống chung thủy, không quan hệ tình dục bừa bãi; sử dụng bao cao su; không dùng chung kim tiêm, dao cạo; tiêm vaccine (viêm gan B, HPV); giữ vệ sinh cơ quan sinh dục; khám và điều trị kịp thời.'],
  [4,'Vì sao mang thai ở tuổi vị thành niên lại gây nhiều hậu quả xấu đối với sức khỏe và tương lai của các em gái?','Ở tuổi vị thành niên cơ thể chưa phát triển hoàn thiện, tử cung và khung chậu còn nhỏ nên dễ sảy thai, sinh non, khó sinh, tỉ lệ tử vong mẹ và con cao; cơ thể thiếu chất dinh dưỡng cho cả mẹ và thai. Về tinh thần, xã hội: phải nghỉ học, mất cơ hội học tập, việc làm; tâm lí lo lắng, bị kì thị; gia đình gặp khó khăn. Vì vậy cần có kiến thức về sức khỏe sinh sản để tự bảo vệ.']
 ]);

 /* ===================== CHƯƠNG VIII: SINH VẬT VÀ MÔI TRƯỜNG ===================== */
 add(M,8,'Bài 41: Môi trường và các nhân tố sinh thái',[
  [1,'Môi trường sống của sinh vật là gì?','Nơi sinh sống của sinh vật, bao gồm tất cả các yếu tố bao quanh có ảnh hưởng đến sinh vật','Chỉ là nơi sinh vật kiếm ăn','Chỉ bao gồm các yếu tố khí hậu','Chỉ là đất và nước'],
  [1,'Có bao nhiêu loại môi trường sống chủ yếu của sinh vật?','Bốn loại: môi trường trong đất, môi trường nước, môi trường trên mặt đất – không khí và môi trường sinh vật','Hai loại: nước và đất','Ba loại: nước, đất, không khí','Một loại duy nhất'],
  [2,'Nhân tố nào sau đây là nhân tố sinh thái vô sinh?','Ánh sáng','Cây cỏ','Sâu bọ','Con người'],
  [2,'Giới hạn sinh thái là gì?','Khoảng giá trị của một nhân tố sinh thái mà trong đó sinh vật có thể tồn tại và phát triển','Nơi sinh vật sống','Số lượng cá thể tối đa của loài','Khoảng không gian phân bố của loài'],
  [2,'Cá rô phi ở Việt Nam sống được trong khoảng nhiệt độ từ 5,6 °C đến 42 °C. Khoảng này gọi là gì?','Giới hạn sinh thái về nhiệt độ của cá rô phi','Điểm cực thuận','Môi trường sống','Nhân tố hữu sinh'],
  [3,'Phân biệt nhóm nhân tố sinh thái vô sinh và hữu sinh. Vì sao con người được xếp vào nhân tố hữu sinh đặc biệt?','Nhân tố vô sinh: các yếu tố không sống như nhiệt độ, ánh sáng, nước, độ ẩm, đất, gió. Nhân tố hữu sinh: các sinh vật khác và con người. Con người là nhân tố đặc biệt vì có trí tuệ, lao động, tác động mạnh và rộng đến môi trường và sinh vật, có thể làm biến đổi môi trường theo cả hai hướng tích cực và tiêu cực.'],
  [3,'Nêu ví dụ về sinh vật sống ở mỗi loại môi trường: trong đất, nước, trên mặt đất – không khí, sinh vật.','Môi trường trong đất: giun đất, dế, chuột chũi. Môi trường nước: cá, tôm, rong, san hô. Môi trường trên mặt đất – không khí: hổ, trâu, chim, cây bàng. Môi trường sinh vật: giun đũa, sán lá gan sống trong cơ thể người và động vật, bọ chét trên da chó.'],
  [4,'Dựa vào khái niệm giới hạn sinh thái, giải thích vì sao cây cao su và cây cà phê được trồng chủ yếu ở Tây Nguyên, Đông Nam Bộ mà ít trồng ở vùng núi phía Bắc.','Mỗi loài có giới hạn sinh thái về nhiệt độ, độ ẩm riêng. Cao su, cà phê là cây nhiệt đới, sinh trưởng tốt trong khoảng nhiệt độ cao, ổn định, không chịu được rét, sương muối. Tây Nguyên, Đông Nam Bộ có khí hậu nóng quanh năm, đất đỏ phù hợp, nằm trong khoảng thuận lợi; vùng núi phía Bắc có mùa đông lạnh, nhiệt độ xuống dưới giới hạn dưới của cây nên cây sinh trưởng kém hoặc chết.']
 ]);
 add(M,8,'Bài 42: Quần thể sinh vật',[
  [1,'Quần thể sinh vật là gì?','Tập hợp các cá thể cùng loài, sống trong một khoảng không gian và thời gian xác định, có khả năng sinh sản tạo thế hệ mới','Tập hợp các cá thể khác loài sống cùng nơi','Tập hợp tất cả sinh vật trên Trái Đất','Một cá thể sinh vật'],
  [1,'Tập hợp nào sau đây là một quần thể sinh vật?','Các cây thông trong một rừng thông ở Đà Lạt','Các con cá trong một ao','Các loài chim trong một khu rừng','Các cây trong một vườn hoa'],
  [2,'Mật độ cá thể của quần thể là gì?','Số lượng cá thể trên một đơn vị diện tích hoặc thể tích','Tổng số cá thể của quần thể','Tỉ lệ đực cái','Số cá thể sinh ra trong một năm'],
  [2,'Đặc trưng nào sau đây không phải đặc trưng cơ bản của quần thể?','Độ đa dạng về loài','Tỉ lệ giới tính','Thành phần nhóm tuổi','Kiểu phân bố cá thể'],
  [2,'Quần thể có tỉ lệ nhóm tuổi trước sinh sản lớn hơn nhóm tuổi sinh sản và sau sinh sản là quần thể gì?','Quần thể đang phát triển','Quần thể ổn định','Quần thể suy thoái','Quần thể biến mất'],
  [3,'Nêu các đặc trưng cơ bản của quần thể sinh vật.','Kích thước quần thể (số lượng cá thể); mật độ cá thể; tỉ lệ giới tính (tỉ lệ đực/cái); thành phần nhóm tuổi (trước sinh sản, sinh sản, sau sinh sản); kiểu phân bố cá thể (theo nhóm, đồng đều, ngẫu nhiên).'],
  [3,'Nêu một số biện pháp bảo vệ quần thể sinh vật.','Bảo vệ môi trường sống của quần thể; cấm săn bắt, khai thác quá mức, nhất là với các loài quý hiếm; thành lập khu bảo tồn, vườn quốc gia; kiểm soát sự phát triển của các loài ngoại lai xâm hại; nhân nuôi, gây trồng phục hồi quần thể có nguy cơ tuyệt chủng; tuyên truyền nâng cao ý thức cộng đồng.'],
  [4,'Vì sao khi mật độ cá thể của quần thể tăng quá cao thì số lượng cá thể sau đó lại thường giảm xuống?','Mật độ quá cao làm nguồn sống (thức ăn, nơi ở, ánh sáng) trở nên khan hiếm, cạnh tranh giữa các cá thể gay gắt, chất thải tích tụ gây ô nhiễm, dịch bệnh dễ lan truyền, kẻ thù dễ tấn công. Kết quả là tỉ lệ tử vong tăng, tỉ lệ sinh sản giảm, một số cá thể di cư, làm số lượng cá thể giảm về mức phù hợp với khả năng cung cấp của môi trường. Đó là cơ chế tự điều chỉnh của quần thể.']
 ]);
 add(M,8,'Bài 43: Quần xã sinh vật',[
  [1,'Quần xã sinh vật là gì?','Tập hợp các quần thể sinh vật thuộc nhiều loài khác nhau, cùng sống trong một không gian và thời gian nhất định','Tập hợp các cá thể cùng loài','Một cá thể và môi trường của nó','Tập hợp các nhân tố vô sinh'],
  [1,'Tập hợp nào sau đây là một quần xã sinh vật?','Tất cả các sinh vật sống trong một hồ nước','Đàn cá chép trong hồ','Các cây lúa trên một cánh đồng','Những con ong trong một tổ'],
  [2,'Loài đóng vai trò quan trọng trong quần xã do số lượng cá thể nhiều, hoạt động mạnh được gọi là gì?','Loài ưu thế','Loài đặc trưng','Loài ngẫu nhiên','Loài ngoại lai'],
  [2,'Loài chỉ có ở một quần xã nào đó hoặc có số lượng nhiều hơn hẳn các loài khác được gọi là gì?','Loài đặc trưng','Loài ưu thế','Loài thứ yếu','Loài kí sinh'],
  [2,'Độ đa dạng của quần xã được thể hiện bằng điều gì?','Số lượng loài và số lượng cá thể của mỗi loài trong quần xã','Diện tích phân bố của quần xã','Số lượng nhân tố vô sinh','Chiều cao của thực vật'],
  [3,'Nêu các đặc trưng cơ bản của quần xã sinh vật và cho ví dụ.','Độ đa dạng: quần xã rừng mưa nhiệt đới có độ đa dạng cao hơn quần xã sa mạc. Thành phần loài: loài ưu thế (cây tràm trong rừng tràm), loài đặc trưng (cá cóc Tam Đảo ở vùng núi Tam Đảo, cây cọ ở vùng đồi Phú Thọ).'],
  [3,'Nêu một số biện pháp bảo vệ quần xã sinh vật.','Bảo vệ và phục hồi môi trường sống (rừng, đất ngập nước, rạn san hô); không khai thác quá mức, không săn bắt động vật hoang dã; kiểm soát sinh vật ngoại lai xâm hại; xây dựng khu bảo tồn thiên nhiên, vườn quốc gia; giảm ô nhiễm; tuyên truyền, giáo dục ý thức bảo vệ đa dạng sinh học.'],
  [4,'Vì sao quần xã có độ đa dạng cao thường ổn định hơn quần xã có độ đa dạng thấp?','Quần xã đa dạng có nhiều loài với các mối quan hệ dinh dưỡng phức tạp, lưới thức ăn có nhiều mắt xích. Khi một loài bị suy giảm, các loài khác có thể thay thế vai trò, nên quần xã ít bị xáo trộn. Quần xã ít loài có lưới thức ăn đơn giản; mất một loài có thể làm sụp đổ cả chuỗi thức ăn, dễ bị dịch bệnh và biến động mạnh.']
 ]);
 add(M,8,'Bài 44: Hệ sinh thái',[
  [1,'Hệ sinh thái bao gồm những thành phần nào?','Quần xã sinh vật và môi trường sống của quần xã (sinh cảnh)','Chỉ các loài động vật','Chỉ các nhân tố vô sinh','Chỉ các loài thực vật'],
  [1,'Trong hệ sinh thái, sinh vật nào là sinh vật sản xuất?','Thực vật và một số sinh vật có khả năng quang hợp','Động vật ăn cỏ','Động vật ăn thịt','Vi khuẩn phân giải'],
  [2,'Chuỗi thức ăn nào sau đây được viết đúng?','Cỏ → Thỏ → Cáo → Vi sinh vật phân giải','Thỏ → Cỏ → Cáo','Cáo → Thỏ → Cỏ','Cỏ → Cáo → Thỏ'],
  [2,'Vi khuẩn và nấm trong hệ sinh thái thuộc nhóm sinh vật nào?','Sinh vật phân giải','Sinh vật sản xuất','Sinh vật tiêu thụ bậc 1','Sinh vật tiêu thụ bậc 2'],
  [2,'Hệ sinh thái nào sau đây là hệ sinh thái nhân tạo?','Đồng ruộng','Rừng mưa nhiệt đới','Rạn san hô','Sa mạc'],
  [3,'Phân biệt chuỗi thức ăn và lưới thức ăn.','Chuỗi thức ăn là một dãy nhiều loài sinh vật có quan hệ dinh dưỡng với nhau, mỗi loài là một mắt xích, vừa ăn mắt xích trước vừa bị mắt xích sau ăn. Lưới thức ăn gồm nhiều chuỗi thức ăn có các mắt xích chung; một loài có thể tham gia vào nhiều chuỗi thức ăn khác nhau trong quần xã.'],
  [3,'Trình bày quá trình trao đổi chất và chuyển hóa năng lượng trong hệ sinh thái.','Năng lượng ánh sáng Mặt Trời được sinh vật sản xuất (thực vật) chuyển thành năng lượng hóa học trong chất hữu cơ qua quang hợp; chất hữu cơ và năng lượng truyền qua các bậc dinh dưỡng của sinh vật tiêu thụ; sinh vật phân giải biến xác, chất thải thành chất vô cơ trả lại môi trường cho thực vật sử dụng. Vật chất được tuần hoàn, năng lượng truyền theo một chiều và một phần mất đi dưới dạng nhiệt ở mỗi bậc.'],
  [4,'Vì sao trong một chuỗi thức ăn thường chỉ có khoảng 4 – 5 mắt xích và số lượng động vật ăn thịt bậc cao luôn ít hơn nhiều so với động vật ăn cỏ?','Khi năng lượng truyền từ bậc dinh dưỡng thấp lên bậc cao, phần lớn năng lượng bị mất qua hô hấp, tỏa nhiệt, chất thải; chỉ khoảng 10% được tích lũy ở bậc tiếp theo. Càng lên cao, năng lượng còn lại càng ít nên không đủ nuôi nhiều cá thể, số lượng và sinh khối động vật ăn thịt bậc cao rất nhỏ; đến bậc thứ 4 – 5 năng lượng quá ít nên chuỗi thức ăn không kéo dài thêm.']
 ]);
 add(M,8,'Bài 45: Sinh quyển',[
  [1,'Sinh quyển là gì?','Toàn bộ sinh vật sống trên Trái Đất cùng với các nhân tố vô sinh của môi trường','Chỉ các loài động vật trên cạn','Lớp khí quyển bao quanh Trái Đất','Tập hợp các đại dương'],
  [1,'Sinh quyển bao gồm những lớp nào của Trái Đất có sinh vật sống?','Lớp dưới của khí quyển, toàn bộ thủy quyển và lớp trên của thạch quyển (đất, đá)','Chỉ lớp đất bề mặt','Chỉ các đại dương','Toàn bộ lòng Trái Đất'],
  [2,'Các khu sinh học trên Trái Đất được chia thành những nhóm chính nào?','Khu sinh học trên cạn, khu sinh học nước ngọt và khu sinh học biển','Khu sinh học nóng và lạnh','Khu rừng và khu đồng cỏ','Khu sinh học nhân tạo và tự nhiên'],
  [2,'Khu sinh học nào sau đây là khu sinh học trên cạn?','Rừng mưa nhiệt đới','Rạn san hô','Hồ nước ngọt','Vùng biển khơi'],
  [2,'Khu sinh học trên cạn được phân chia chủ yếu dựa vào yếu tố nào?','Đặc điểm khí hậu (nhiệt độ, lượng mưa) và thảm thực vật đặc trưng','Số lượng dân cư','Độ sâu của nước','Màu sắc của đất'],
  [3,'Kể tên một số khu sinh học trên cạn và đặc điểm sinh vật tiêu biểu.','Rừng mưa nhiệt đới: nóng ẩm, mưa nhiều, đa dạng sinh vật nhất. Sa mạc: khô hạn, cây xương rồng, lạc đà, bò sát. Đồng cỏ (thảo nguyên, xa van): cỏ chiếm ưu thế, nhiều động vật ăn cỏ như ngựa vằn, linh dương. Rừng lá kim (taiga): lạnh, cây thông, tùng. Đồng rêu hàn đới: rất lạnh, rêu, địa y, tuần lộc.'],
  [3,'Nêu vai trò của sinh quyển và vì sao cần bảo vệ sinh quyển.','Sinh quyển là nơi sống của tất cả sinh vật, cung cấp oxygen, thức ăn, nước, nguyên liệu; điều hòa khí hậu; duy trì các vòng tuần hoàn vật chất. Cần bảo vệ vì sinh quyển đang bị tác động mạnh bởi con người (phá rừng, ô nhiễm, biến đổi khí hậu), nếu bị phá hủy, các sinh vật kể cả con người không thể tồn tại.'],
  [4,'Vì sao rừng mưa nhiệt đới có độ đa dạng sinh học cao nhất trong các khu sinh học trên cạn?','Rừng mưa nhiệt đới có nhiệt độ cao ổn định quanh năm, lượng mưa và độ ẩm lớn, ánh sáng dồi dào, không có mùa đông khắc nghiệt nên thực vật sinh trưởng liên tục, phân nhiều tầng tán tạo nhiều nơi ở và nguồn thức ăn đa dạng. Điều kiện ổn định lâu dài qua hàng triệu năm giúp nhiều loài tiến hóa, thích nghi và cùng tồn tại, nên số loài rất lớn.']
 ]);
 add(M,8,'Bài 46: Cân bằng tự nhiên',[
  [1,'Cân bằng tự nhiên là gì?','Trạng thái ổn định tự nhiên của các cấp độ tổ chức sống, hướng tới sự thích nghi cao nhất với điều kiện sống','Sự giữ nguyên số lượng mọi loài mãi mãi','Sự cân bằng của cán cân','Trạng thái không có sinh vật nào thay đổi'],
  [1,'Hiện tượng số lượng cá thể của một loài bị khống chế ở mức nhất định do quan hệ với loài khác được gọi là gì?','Khống chế sinh học','Cạnh tranh cùng loài','Di cư','Cộng sinh'],
  [2,'Trong tự nhiên, khi số lượng thỏ tăng nhanh thì số lượng cáo ăn thỏ sẽ thay đổi thế nào sau đó?','Tăng lên, rồi làm số thỏ giảm xuống','Giảm xuống ngay','Không thay đổi','Biến mất hoàn toàn'],
  [2,'Nguyên nhân chủ yếu gây mất cân bằng tự nhiên hiện nay là gì?','Hoạt động của con người như phá rừng, săn bắt, gây ô nhiễm','Sự thay đổi ngày và đêm','Sự di cư của chim theo mùa','Hoạt động của vi sinh vật phân giải'],
  [2,'Ví dụ nào sau đây thể hiện sự tự điều chỉnh số lượng cá thể của quần thể?','Số lượng sâu ăn lá tăng khiến chim sâu phát triển mạnh, sau đó số sâu giảm','Con người phun thuốc trừ sâu diệt hết sâu','Trồng thêm cây trong vườn','Xây hồ chứa nước'],
  [3,'Trình bày các biểu hiện của cân bằng tự nhiên.','Trạng thái cân bằng của quần thể: số lượng cá thể tự điều chỉnh về mức phù hợp với nguồn sống. Khống chế sinh học trong quần xã: số lượng cá thể mỗi loài bị khống chế ở mức nhất định nhờ quan hệ với loài khác (vật ăn thịt – con mồi, kí sinh – vật chủ). Cân bằng tự nhiên trong hệ sinh thái: thành phần loài, chu trình vật chất, dòng năng lượng ổn định.'],
  [3,'Nêu các biện pháp bảo vệ, duy trì cân bằng tự nhiên.','Bảo vệ rừng, trồng rừng, bảo vệ các loài sinh vật hoang dã; khai thác tài nguyên hợp lí, có kế hoạch; hạn chế ô nhiễm môi trường; kiểm soát sinh vật ngoại lai; sử dụng biện pháp sinh học (thiên địch) thay cho hóa chất trong nông nghiệp; xây dựng khu bảo tồn; nâng cao nhận thức cộng đồng.'],
  [4,'Vì sao việc săn bắt quá mức các loài thú ăn thịt như hổ, báo, sói lại có thể gây hại cho rừng và cả các loài động vật ăn cỏ?','Thú ăn thịt khống chế số lượng động vật ăn cỏ ở mức cân bằng. Khi thú ăn thịt bị tiêu diệt, động vật ăn cỏ như hươu, nai tăng nhanh, ăn trụi cây non, cỏ, làm rừng không tái sinh được, đất bị xói mòn. Thiếu thức ăn, đàn động vật ăn cỏ lại suy yếu, dịch bệnh lan rộng, chết hàng loạt. Như vậy mất một mắt xích làm mất cân bằng cả hệ sinh thái.']
 ]);
 add(M,8,'Bài 47: Bảo vệ môi trường',[
  [1,'Trong thời kì nào, con người bắt đầu tác động mạnh mẽ nhất đến môi trường tự nhiên?','Thời kì xã hội công nghiệp','Thời kì nguyên thủy','Thời kì xã hội nông nghiệp','Không thời kì nào'],
  [1,'Ô nhiễm môi trường là gì?','Sự biến đổi tính chất vật lí, hóa học, sinh học của môi trường theo hướng xấu, gây hại cho sinh vật và con người','Sự thay đổi thời tiết theo mùa','Sự di chuyển của sinh vật','Sự gia tăng số lượng cây xanh'],
  [2,'Khí nào sau đây là khí nhà kính chủ yếu góp phần gây biến đổi khí hậu?','Carbon dioxide (CO2)','Oxygen (O2)','Nitrogen (N2)','Hydrogen (H2)'],
  [2,'Biện pháp nào sau đây góp phần bảo vệ môi trường?','Phân loại rác tại nguồn, tái sử dụng và tái chế','Đốt rác thải nhựa ngoài trời','Xả nước thải chưa xử lí ra sông','Chặt phá rừng lấy đất canh tác'],
  [2,'Hậu quả nào sau đây do biến đổi khí hậu gây ra?','Băng tan, mực nước biển dâng, thời tiết cực đoan gia tăng','Số loài sinh vật tăng nhanh','Trái Đất lạnh dần đều','Không khí trong lành hơn'],
  [3,'Trình bày tác động của con người đến môi trường qua các thời kì phát triển xã hội.','Thời kì nguyên thủy: săn bắt, hái lượm, dùng lửa, tác động ít. Xã hội nông nghiệp: chặt phá rừng lấy đất trồng trọt, chăn nuôi, định cư, bắt đầu làm thay đổi môi trường. Xã hội công nghiệp: khai thác tài nguyên quy mô lớn, đô thị hóa, phát thải khí, chất thải công nghiệp, gây ô nhiễm, suy giảm đa dạng sinh học, biến đổi khí hậu; đồng thời cũng có công nghệ để khắc phục.'],
  [3,'Là học sinh, em có thể làm gì để góp phần bảo vệ môi trường?','Tiết kiệm điện, nước; hạn chế dùng túi nilon, đồ nhựa một lần; phân loại và bỏ rác đúng nơi; tái sử dụng, tái chế; trồng và chăm sóc cây xanh; đi bộ, đi xe đạp khi có thể; không xả rác nơi công cộng; tuyên truyền cho gia đình, bạn bè cùng bảo vệ môi trường.'],
  [4,'Vì sao trồng rừng và bảo vệ rừng được coi là biện pháp quan trọng để ứng phó với biến đổi khí hậu và bảo vệ môi trường?','Rừng hấp thụ khí CO2 (khí nhà kính chủ yếu) qua quang hợp và thải oxygen, giúp giảm hiệu ứng nhà kính, điều hòa khí hậu. Rừng giữ nước, chống xói mòn, hạn chế lũ lụt, hạn hán; là nơi sống của nhiều loài, bảo tồn đa dạng sinh học; cung cấp lâm sản bền vững. Mất rừng vừa giải phóng CO2 vừa mất khả năng hấp thụ, làm biến đổi khí hậu trầm trọng hơn.']
 ]);
})();
