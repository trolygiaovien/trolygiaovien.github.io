/* ============================================================
   NGÂN HÀNG BỔ SUNG 2 — thêm câu cho các chủ đề còn thiếu
   (mỗi chủ đề đủ ≥6 câu + CÓ câu nâng cao mức 4 cho HS giỏi)
   Soạn theo Chương trình GDPT 2018 – bộ SGK Kết nối tri thức.
   ĐỢT 1: Tiểu học — Đạo đức, Tự nhiên & Xã hội, Khoa học,
          Lịch sử & Địa lí, Tiếng Việt.
   Định dạng: TN [mức,'câu','ĐÁP ÁN ĐÚNG','sai','sai','sai']
              TL [mức,'câu','đáp án/gợi ý chấm']
   Mức: 1 nhận biết · 2 hiểu · 3 vận dụng · 4 nâng cao (HSG)
   ============================================================ */
(function(){
 if(typeof NH==='undefined')return;
 /* Thêm câu vào chủ đề CÓ SẴN (khớp theo tên cd); nếu chưa có thì tạo mới.
    Tránh trùng: bỏ qua câu đã tồn tại (so theo nội dung câu hỏi). */
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){
   var tr=String(q[1]||'').trim();
   if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);
  });
 }

 /* ===================== ĐẠO ĐỨC ===================== */
 add('Đạo đức',1,'Tự chăm sóc bản thân',[
  [1,'Buổi sáng thức dậy, việc nên làm đầu tiên để giữ vệ sinh răng miệng là gì?','Đánh răng','Xem ti vi','Ăn kẹo','Đi ngủ tiếp'],
  [2,'Vì sao em cần rửa tay trước khi ăn?','Để loại bỏ vi khuẩn, giữ gìn sức khỏe','Để tay ướt cho mát','Để không phải ăn cơm','Để tay đẹp hơn'],
  [4,'Em đi học về, quần áo bị ướt mưa. Em nên làm gì và vì sao? Hãy nêu cách tự chăm sóc bản thân trong trường hợp này.','Thay ngay quần áo khô, lau người cho ấm để không bị cảm lạnh; biết tự chăm sóc giúp cơ thể khỏe mạnh.']
 ]);
 add('Đạo đức',1,'An toàn',[
  [2,'Khi gặp người lạ cho quà và rủ đi chơi, em nên làm gì?','Từ chối và báo cho bố mẹ, thầy cô','Đi theo ngay','Nhận quà rồi đi','Giấu bố mẹ']
 ]);
 add('Đạo đức',2,'Quý trọng thời gian, nhận lỗi',[
  [1,'Khi làm sai, việc nên làm là gì?','Nhận lỗi và sửa lỗi','Đổ lỗi cho bạn','Giấu đi','Khóc lóc'],
  [4,'Em hẹn bạn 7 giờ đi học nhóm nhưng em ngủ dậy muộn. Em nên làm gì để quý trọng thời gian và giữ lời hứa với bạn?','Xin lỗi bạn, nhanh chóng chuẩn bị để đến đúng hẹn sớm nhất; lần sau đặt báo thức, chuẩn bị trước để không trễ hẹn.']
 ]);
 add('Đạo đức',2,'Cảm xúc và nơi công cộng',[
  [2,'Ở nơi công cộng như thư viện, em nên giữ thái độ như thế nào?','Giữ trật tự, nói nhỏ','Chạy nhảy, nói to','Giành chỗ của người khác','Xả rác bừa bãi'],
  [4,'Khi tức giận vì bị bạn trêu, em nên làm gì để kiểm soát cảm xúc của mình?','Hít thở sâu, bình tĩnh nói với bạn cảm giác của mình hoặc báo thầy cô; không đánh bạn, không la hét.']
 ]);
 add('Đạo đức',3,'Tổ quốc, hàng xóm',[
  [1,'Lá cờ Tổ quốc Việt Nam có nền màu gì và ngôi sao màu gì?','Nền đỏ, sao vàng','Nền vàng, sao đỏ','Nền xanh, sao trắng','Nền trắng, sao xanh'],
  [4,'Nhà hàng xóm có người ốm, buổi tối cần yên tĩnh. Em và các bạn nên cư xử thế nào để thể hiện tình làng nghĩa xóm?','Giữ trật tự, không nô đùa ồn ào; hỏi thăm, giúp đỡ việc vừa sức như lấy giúp đồ, trông nhà hộ.']
 ]);
 add('Đạo đức',3,'An toàn giao thông, xử lí bất hòa',[
  [1,'Khi đi bộ trên đường có vỉa hè, em phải đi ở đâu?','Trên vỉa hè, sát lề phải','Giữa lòng đường','Chỗ nào cũng được','Dưới lòng đường'],
  [2,'Đèn tín hiệu giao thông màu đỏ báo hiệu điều gì?','Dừng lại','Được đi','Đi chậm','Rẽ phải'],
  [4,'Em và bạn tranh cãi vì cả hai cùng muốn mượn một quyển truyện. Em nên xử lí bất hòa này như thế nào?','Bình tĩnh nói chuyện, thỏa thuận thay nhau đọc hoặc đọc chung; nhường nhịn, không cãi nhau hay giành giật.']
 ]);
 add('Đạo đức',4,'Biết ơn người lao động',[
  [1,'Người trồng ra hạt lúa, hạt gạo cho chúng ta ăn là ai?','Người nông dân','Bác sĩ','Giáo viên','Công an'],
  [2,'Vì sao em cần biết ơn người lao động?','Vì họ làm ra của cải, phục vụ cuộc sống của mọi người','Vì họ giàu có','Vì họ ở gần nhà em','Vì họ cho em quà'],
  [4,'Hãy kể 3 việc làm cụ thể thể hiện lòng biết ơn người lao động mà em có thể làm hằng ngày.','Ví dụ: quý trọng, không lãng phí thức ăn/đồ dùng; lễ phép chào hỏi, cảm ơn; giữ gìn vệ sinh chung để đỡ vất vả cho lao công; học tập chăm chỉ.']
 ]);
 add('Đạo đức',4,'Cảm thông, giúp đỡ người gặp khó khăn',[
  [1,'Thấy một bạn bị ngã ở sân trường, em nên làm gì?','Đỡ bạn dậy và hỏi thăm','Cười chê bạn','Bỏ đi','Trêu chọc bạn'],
  [2,'Việc làm nào thể hiện sự cảm thông, giúp đỡ người gặp khó khăn?','Ủng hộ sách vở, quần áo cho bạn vùng lũ','Chê bạn nghèo','Không quan tâm','Tranh đồ của bạn'],
  [4,'Trong lớp có bạn khuyết tật đi lại khó khăn. Em và các bạn nên làm gì để giúp đỡ bạn hòa nhập?','Giúp bạn lấy đồ, di chuyển; rủ bạn cùng chơi, học nhóm; động viên, không trêu chọc; đối xử bình đẳng, tôn trọng bạn.']
 ]);
 add('Đạo đức',4,'Quyền và bổn phận trẻ em',[
  [1,'Được đi học, được chăm sóc là gì của trẻ em?','Quyền của trẻ em','Bổn phận của trẻ em','Việc làm thêm','Phần thưởng'],
  [2,'Đâu là bổn phận của trẻ em đối với gia đình?','Yêu quý, kính trọng, giúp đỡ ông bà cha mẹ','Đòi hỏi quà','Không làm việc nhà','Chỉ chơi game'],
  [4,'Theo em, quyền và bổn phận của trẻ em có mối quan hệ với nhau như thế nào? Cho ví dụ.','Trẻ em vừa được hưởng quyền (được học, được chăm sóc, vui chơi) vừa phải làm tròn bổn phận (chăm học, lễ phép, giúp đỡ gia đình). Ví dụ: được đi học là quyền, chăm chỉ học tập là bổn phận.']
 ]);
 add('Đạo đức',5,'Biết ơn người có công',[
  [1,'Ngày 27/7 hằng năm là ngày gì?','Ngày Thương binh – Liệt sĩ','Ngày Nhà giáo Việt Nam','Ngày Quốc khánh','Ngày Quốc tế Thiếu nhi'],
  [2,'Việc làm nào thể hiện lòng biết ơn các anh hùng liệt sĩ?','Thăm viếng, chăm sóc nghĩa trang liệt sĩ','Chê bai lịch sử','Phá hoại tượng đài','Quên đi quá khứ'],
  [4,'Vì sao thế hệ trẻ hôm nay cần biết ơn các anh hùng, liệt sĩ đã hi sinh vì Tổ quốc? Em sẽ làm gì để tỏ lòng biết ơn?','Vì nhờ sự hi sinh của họ, đất nước mới có độc lập, hòa bình. Em sẽ chăm học, rèn luyện, giữ gìn truyền thống, tham gia việc đền ơn đáp nghĩa.']
 ]);
 add('Đạo đức',5,'Tôn trọng sự khác biệt, bảo vệ cái đúng',[
  [1,'Khi bạn trong lớp có hoàn cảnh, sở thích khác mình, em nên có thái độ nào?','Tôn trọng sự khác biệt của bạn','Chê cười bạn','Xa lánh bạn','Bắt bạn giống mình'],
  [2,'"Bảo vệ cái đúng" nghĩa là gì?','Dám nói và làm theo lẽ phải, bênh vực điều đúng','Theo số đông để yên thân','Im lặng khi thấy sai','Hùa theo cái sai'],
  [4,'Em chứng kiến một bạn bị cả nhóm trêu chọc vì nói giọng địa phương. Em nên làm gì để tôn trọng sự khác biệt và bảo vệ cái đúng?','Can ngăn, nói rõ trêu chọc bạn là sai; an ủi, bênh vực bạn; báo thầy cô nếu cần. Tôn trọng giọng nói, nét riêng của mỗi vùng miền.']
 ]);
 add('Đạo đức',5,'Phòng tránh xâm hại, sử dụng tiền hợp lí',[
  [2,'Khi có người lạ cố ý động chạm vào cơ thể khiến em khó chịu, em cần làm gì?','Kiên quyết từ chối, tránh xa và kể ngay với người tin cậy','Im lặng chịu đựng','Giữ bí mật','Làm theo lời họ'],
  [4,'Em được mừng tuổi 200 000 đồng. Hãy lập kế hoạch sử dụng số tiền này một cách hợp lí và giải thích.','Ví dụ: để dành một phần tiết kiệm, một phần mua đồ dùng học tập cần thiết, một phần giúp đỡ/ủng hộ; tránh tiêu hết vào quà vặt, đồ chơi. Biết chi tiêu có kế hoạch, ưu tiên việc cần thiết.']
 ]);

 /* =============== TỰ NHIÊN VÀ XÃ HỘI =============== */
 add('Tự nhiên và Xã hội',1,'Gia đình và trường học',[
  [1,'Những người thường sống chung trong một gia đình gồm có ai?','Ông bà, bố mẹ, con cái','Chỉ có bạn bè','Chỉ có thầy cô','Người lạ'],
  [4,'Hãy kể những việc em có thể làm để giúp đỡ bố mẹ và giữ cho ngôi nhà sạch đẹp.','Ví dụ: quét nhà, gấp quần áo, cất dọn đồ chơi, tưới cây, sắp xếp góc học tập gọn gàng.']
 ]);
 add('Tự nhiên và Xã hội',1,'Thực vật và động vật',[
  [4,'Cây xanh có lợi ích gì cho con người và môi trường? Hãy kể ít nhất 3 lợi ích.','Cho bóng mát, cho quả/rau để ăn, cho gỗ; làm không khí trong lành (nhả khí ô-xi); làm đẹp cảnh quan, chống xói mòn đất.']
 ]);
 add('Tự nhiên và Xã hội',1,'Cộng đồng địa phương',[
  [1,'Nơi em cùng mọi người mua bán hàng hóa hằng ngày gọi là gì?','Chợ (hoặc cửa hàng, siêu thị)','Bệnh viện','Trường học','Công viên'],
  [2,'Khi tham gia giao thông cùng bố mẹ, ngồi trên xe máy em cần làm gì để an toàn?','Đội mũ bảo hiểm','Thò tay ra ngoài','Đứng lên xe','Không bám vào người lớn'],
  [4,'Hãy kể một số công việc của những người xung quanh (bác sĩ, cô giáo, chú công an...) và ích lợi của công việc đó với cộng đồng.','Ví dụ: bác sĩ khám chữa bệnh giúp mọi người khỏe mạnh; cô giáo dạy học; chú công an giữ gìn trật tự an toàn; bác nông dân trồng lúa cho gạo.']
 ]);
 add('Tự nhiên và Xã hội',2,'Gia đình và trường học',[
  [1,'Phòng nào trong trường là nơi em học tập hằng ngày cùng thầy cô và các bạn?','Lớp học','Nhà bếp','Phòng y tế','Nhà để xe'],
  [4,'Để giữ gìn trường lớp sạch đẹp, em và các bạn nên làm những việc gì?','Vứt rác đúng nơi quy định, lau bàn ghế, chăm sóc cây, không vẽ bậy lên tường, giữ vệ sinh nhà vệ sinh chung.']
 ]);
 add('Tự nhiên và Xã hội',2,'Cộng đồng địa phương',[
  [4,'Hãy nêu một số nghề truyền thống hoặc hoạt động sản xuất ở địa phương em và sản phẩm của nghề đó.','Tùy địa phương, ví dụ: trồng lúa (gạo), làm gốm (bát đĩa), đánh bắt cá (hải sản), dệt vải (quần áo), làm mộc (bàn ghế).']
 ]);
 add('Tự nhiên và Xã hội',2,'Trái Đất và bầu trời',[
  [1,'Ban ngày, bầu trời sáng là nhờ có gì?','Mặt Trời','Mặt Trăng','Ngôi sao','Đèn điện'],
  [2,'Một tuần lễ có bao nhiêu ngày?','7 ngày','5 ngày','10 ngày','12 ngày'],
  [4,'Vì sao ở nơi em sống có lúc nắng, lúc mưa? Khi trời nắng to và khi trời mưa, em cần làm gì để bảo vệ sức khỏe?','Thời tiết thay đổi theo ngày, theo mùa. Trời nắng to: đội mũ, che ô, uống đủ nước, tránh nắng gắt. Trời mưa: mặc áo mưa, che ô, giữ ấm, không trú dưới cây to khi có sấm sét.']
 ]);
 add('Tự nhiên và Xã hội',3,'Gia đình và trường học',[
  [1,'Những người có cùng ông bà sinh ra bố (hoặc mẹ) là họ hàng bên nào?','Họ nội (bên bố) / họ ngoại (bên mẹ)','Người lạ','Hàng xóm','Bạn bè'],
  [4,'Hãy vẽ (hoặc kể) sơ đồ các thế hệ trong gia đình em và nêu cách xưng hô với từng người.','Gợi ý: ông bà → bố mẹ → các con. Xưng hô: ông, bà, bố/ba, mẹ, bác, cô, chú, dì, cậu, anh, chị, em... đúng vai vế.']
 ]);
 add('Tự nhiên và Xã hội',3,'Thực vật và động vật',[
  [4,'Nêu các bộ phận chính của một cây xanh và chức năng của rễ, thân, lá.','Cây gồm rễ, thân, lá, hoa, quả. Rễ hút nước và chất dinh dưỡng, giữ cây; thân vận chuyển và nâng đỡ; lá quang hợp tạo chất nuôi cây.']
 ]);
 add('Tự nhiên và Xã hội',3,'Trái Đất và bầu trời',[
  [4,'Một năm có mấy mùa (ở miền Bắc nước ta)? Kể tên và nêu đặc điểm thời tiết nổi bật của mỗi mùa.','Miền Bắc có 4 mùa: xuân (ấm áp, mưa phùn), hạ (nóng, mưa nhiều), thu (mát mẻ), đông (lạnh, khô). Miền Nam chủ yếu 2 mùa: mưa và khô.']
 ]);

 /* ===================== KHOA HỌC ===================== */
 add('Khoa học',4,'Con người và sức khỏe',[
  [4,'Để phòng tránh bệnh béo phì và suy dinh dưỡng, em cần ăn uống và sinh hoạt như thế nào?','Ăn đủ chất, cân đối 4 nhóm thức ăn; không ăn quá nhiều đồ ngọt, đồ chiên rán; ăn nhiều rau quả; uống đủ nước; tập thể dục, vận động hằng ngày; ngủ đủ giấc.']
 ]);
 add('Khoa học',5,'Con người và sức khỏe',[
  [1,'Giai đoạn phát triển của con người từ khi sinh ra đến tuổi dậy thì gồm những thời kì nào?','Tuổi ấu thơ, tuổi nhi đồng rồi đến tuổi dậy thì','Chỉ có tuổi già','Chỉ có tuổi trưởng thành','Không thay đổi'],
  [4,'Tuổi dậy thì có vai trò quan trọng như thế nào đối với cuộc đời mỗi người? Em cần làm gì để cơ thể phát triển khỏe mạnh ở giai đoạn này?','Tuổi dậy thì cơ thể lớn nhanh, có nhiều biến đổi về thể chất và tinh thần, chuẩn bị cho tuổi trưởng thành. Cần ăn đủ chất, giữ vệ sinh cơ thể, tập thể dục, ngủ đủ, học tập điều độ, giữ tinh thần vui vẻ.']
 ]);

 /* ================ LỊCH SỬ VÀ ĐỊA LÍ ================ */
 add('Lịch sử và Địa lí',4,'Địa phương em',[
  [1,'Cơ quan hành chính cấp xã (phường) nơi em ở có tên gọi chung là gì?','Ủy ban nhân dân xã (phường)','Bệnh viện','Nhà máy','Trường học'],
  [2,'Để tìm hiểu về lịch sử, văn hóa địa phương, em có thể đến nơi nào?','Bảo tàng, di tích, nhà truyền thống của địa phương','Chợ','Bến xe','Sân vận động'],
  [4,'Hãy giới thiệu ngắn gọn về một nét nổi bật (danh lam thắng cảnh, nghề truyền thống hoặc lễ hội) ở địa phương em và nêu cách em góp phần giữ gìn.','Gợi ý: nêu tên và đặc điểm của cảnh đẹp/nghề/lễ hội; cách giữ gìn: giữ vệ sinh, bảo vệ di tích, giới thiệu với mọi người, tự hào về quê hương.']
 ]);
 add('Lịch sử và Địa lí',4,'Tây Nguyên',[
  [4,'Vì sao Tây Nguyên trồng được nhiều cây công nghiệp lâu năm như cà phê, cao su, hồ tiêu?','Vì Tây Nguyên có đất badan màu mỡ, tầng dày và khí hậu nóng, phân hai mùa mưa – khô rõ rệt, thích hợp với cây công nghiệp lâu năm.']
 ]);
 add('Lịch sử và Địa lí',5,'Những quốc gia đầu tiên',[
  [1,'Nhà nước đầu tiên của nước ta có tên là gì?','Nhà nước Văn Lang','Nhà nước Đại Việt','Nhà nước Đại Cồ Việt','Nhà nước Âu Lạc'],
  [4,'Nhà nước Âu Lạc do ai lập ra và có thành tựu nổi bật nào về quân sự? Thành tựu đó cho thấy điều gì về người Việt cổ?','An Dương Vương (Thục Phán) lập nước Âu Lạc, xây thành Cổ Loa và chế tạo nỏ (nỏ Liên Châu/nỏ thần bắn nhiều mũi tên). Cho thấy người Việt cổ có kĩ thuật và tài năng quân sự, biết tổ chức phòng thủ đất nước.']
 ]);

 /* ===================== TIẾNG VIỆT ===================== */
 add('Tiếng Việt',1,'Từ và câu',[
  [4,'Hãy đặt một câu có từ "mẹ" và một câu có từ "trường" nói về điều em yêu thích.','Gợi ý: "Mẹ nấu cơm rất ngon." / "Em yêu ngôi trường của em." (câu đủ ý, đầu câu viết hoa, cuối câu có dấu chấm).']
 ]);
 add('Tiếng Việt',2,'Chính tả',[
  [4,'Tìm và sửa lỗi chính tả trong câu sau: "Em nge cô giáo giảng bài rất chăm chú."','Sửa "nge" thành "nghe". Câu đúng: "Em nghe cô giáo giảng bài rất chăm chú."']
 ]);
 add('Tiếng Việt',2,'Viết đoạn',[
  [2,'Khi viết một đoạn văn ngắn, câu đầu đoạn cần được viết như thế nào?','Viết lùi vào đầu dòng và viết hoa chữ cái đầu','Viết sát lề, không viết hoa','Viết hoa cả câu','Không cần dấu câu'],
  [3,'Viết 2–3 câu giới thiệu về một người bạn thân của em.','HS viết được đoạn 2–3 câu: tên bạn, điều em quý ở bạn, một kỉ niệm/hoạt động cùng bạn; câu đúng ngữ pháp, có dấu câu.'],
  [4,'Viết đoạn văn 4–5 câu kể về một việc tốt em đã làm, trong đó có dùng một từ chỉ cảm xúc (vui, hạnh phúc, tự hào...).','HS viết đoạn 4–5 câu có mở – thân – kết ý; kể rõ việc tốt (giúp đỡ ai, làm gì), nêu được cảm xúc của mình; dùng đúng từ chỉ cảm xúc; diễn đạt mạch lạc.']
 ]);
 add('Tiếng Việt',3,'Câu và dấu câu',[
  [4,'Đặt một câu kể, một câu hỏi và một câu cảm về cùng chủ đề "mùa xuân".','Gợi ý: Câu kể "Mùa xuân, hoa đào nở rộ." · Câu hỏi "Mùa xuân có đẹp không?" · Câu cảm "Mùa xuân đẹp quá!" (đúng loại câu, đúng dấu câu).']
 ]);
 add('Tiếng Việt',3,'Viết đoạn văn',[
  [2,'Một đoạn văn thường có mấy phần cơ bản?','Có câu mở đầu, các câu phát triển và câu kết','Chỉ có một câu','Không có mở đầu','Chỉ có kết thúc'],
  [3,'Viết đoạn văn 4–5 câu tả một đồ vật em yêu thích.','HS viết đoạn 4–5 câu: giới thiệu đồ vật, tả hình dáng/màu sắc/công dụng, nêu tình cảm; câu đúng ngữ pháp, có dấu câu.'],
  [4,'Viết đoạn văn 5–6 câu tả cảnh sân trường em vào giờ ra chơi, có sử dụng biện pháp so sánh.','HS viết đoạn 5–6 câu, tả được không khí nhộn nhịp, hoạt động của các bạn; dùng ít nhất một hình ảnh so sánh (VD: "tiếng cười như chim hót"); diễn đạt sinh động, mạch lạc.']
 ]);
 add('Tiếng Việt',4,'Viết bài văn',[
  [2,'Một bài văn hoàn chỉnh gồm mấy phần?','Ba phần: mở bài, thân bài, kết bài','Một phần','Hai phần','Bốn phần'],
  [3,'Viết mở bài cho bài văn tả một cây bóng mát ở sân trường em.','HS viết mở bài giới thiệu được cây định tả (tên cây, vị trí, ấn tượng chung); 2–3 câu, dẫn dắt tự nhiên.'],
  [4,'Viết bài văn ngắn (khoảng 10–12 câu) tả một con vật nuôi mà em yêu thích, có đủ ba phần và dùng biện pháp nhân hóa.','HS viết đủ mở – thân – kết; tả hình dáng, hoạt động, thói quen của con vật; dùng biện pháp nhân hóa (gọi con vật như người, tả hành động như người); nêu tình cảm; diễn đạt mạch lạc, ít lỗi.']
 ]);
 add('Tiếng Việt',5,'Viết bài văn',[
  [2,'Phần thân bài của bài văn tả cảnh thường làm nhiệm vụ gì?','Tả chi tiết các đặc điểm của cảnh theo một trình tự hợp lí','Giới thiệu cảnh','Nêu cảm nghĩ kết thúc','Ghi tên tác giả'],
  [3,'Viết kết bài mở rộng cho bài văn tả cảnh một buổi sáng trên quê hương em.','HS viết kết bài nêu cảm nghĩ, tình cảm với cảnh và liên hệ (yêu quê hương, mong giữ gìn cảnh đẹp...); 2–3 câu.'],
  [4,'Viết bài văn (khoảng 12–15 câu) tả một người thân mà em yêu quý, biết kết hợp tả ngoại hình với tả hoạt động, tính cách và nêu tình cảm của em.','HS viết đủ ba phần; tả chọn lọc ngoại hình tiêu biểu, kết hợp hoạt động và tính cách; thể hiện tình cảm chân thật; dùng từ ngữ gợi tả, có hình ảnh so sánh/nhân hóa; bố cục rõ, diễn đạt trôi chảy.']
 ]);

 /* ---- Bù thêm cho đủ ≥6 câu/chủ đề ---- */
 add('Đạo đức',1,'An toàn',[
  [1,'Khi ở nhà một mình, thấy có khói và mùi khét, em nên làm gì?','Bình tĩnh ra ngoài nơi an toàn và gọi người lớn giúp đỡ','Trốn vào gầm giường','Tiếp tục chơi','Mở thêm bếp ga']
 ]);
 add('Đạo đức',4,'Cảm thông, giúp đỡ người gặp khó khăn',[
  [3,'Trên đường đi học, em thấy một cụ già muốn qua đường đông xe. Em nên làm gì?','Giúp cụ qua đường an toàn hoặc nhờ người lớn giúp','Giả vờ không thấy','Đi thật nhanh qua','Đứng nhìn rồi bỏ đi']
 ]);
 add('Tự nhiên và Xã hội',1,'Con người và sức khỏe',[
  [2,'Để giữ gìn sức khỏe, mỗi ngày em cần làm gì?','Ăn đủ bữa, ngủ đủ giấc, tập thể dục, giữ vệ sinh','Thức khuya xem ti vi','Ăn nhiều kẹo','Lười vận động']
 ]);
 add('Tự nhiên và Xã hội',1,'Trái Đất và bầu trời',[
  [1,'Vào ban đêm, trên bầu trời em thường nhìn thấy gì?','Mặt Trăng và các ngôi sao','Mặt Trời','Cầu vồng','Máy bay'],
  [2,'Khi trời sắp mưa, bầu trời thường có dấu hiệu nào?','Mây đen kéo đến, trời tối sầm','Nắng chói chang','Bầu trời trong xanh','Có cầu vồng rực rỡ']
 ]);
 add('Tự nhiên và Xã hội',2,'Thực vật và động vật',[
  [2,'Con vật nào dưới đây có ích cho con người?','Con trâu giúp kéo cày','Con muỗi truyền bệnh','Con chuột phá lúa','Con gián bẩn']
 ]);
 add('Tự nhiên và Xã hội',3,'Cộng đồng địa phương',[
  [1,'Khi bị lạc đường ở nơi đông người, em nên tìm đến ai để nhờ giúp đỡ?','Chú công an, bảo vệ hoặc người lớn đáng tin cậy','Người lạ bất kì','Tự đi tìm một mình','Ngồi khóc một chỗ'],
  [2,'Việc làm nào góp phần giữ gìn cảnh quan nơi em ở sạch đẹp?','Bỏ rác đúng nơi quy định, trồng và chăm sóc cây','Vứt rác ra đường','Bẻ cành, hái hoa nơi công cộng','Vẽ bậy lên tường']
 ]);
 add('Tự nhiên và Xã hội',3,'Con người và sức khỏe',[
  [2,'Cơ quan nào giúp cơ thể hít thở, trao đổi khí?','Cơ quan hô hấp (mũi, khí quản, phổi)','Cơ quan tiêu hóa','Cơ quan bài tiết','Cơ quan vận động']
 ]);
 add('Khoa học',4,'Sinh vật và môi trường',[
  [2,'Chuỗi thức ăn nào dưới đây là đúng?','Cây lúa → chuột → rắn','Rắn → chuột → cây lúa','Chuột → cây lúa → rắn','Rắn → cây lúa → chuột']
 ]);

 /* ============================================================
    ĐỢT 1B — nâng mỗi chủ đề đạt ≥6 trắc nghiệm + ≥4 tự luận
    (để một chủ đề tạo được đề chuẩn 6 TN + 4 TL)
    ============================================================ */

 /* ---------- ĐẠO ĐỨC ---------- */
 add('Đạo đức',1,'Tự chăm sóc bản thân',[
  [2,'Để giữ cơ thể sạch sẽ, mỗi ngày em cần làm gì?','Tắm rửa, thay quần áo sạch','Để nguyên quần áo bẩn','Không tắm','Chỉ rửa mặt khi đi ngủ'],
  [2,'Kể những việc em tự làm hằng ngày để chăm sóc bản thân.','Đánh răng, rửa mặt, tắm gội, mặc quần áo, chải tóc, ăn đủ bữa, đi ngủ đúng giờ.'],
  [3,'Khi bị đứt tay chảy ít máu, em nên làm gì?','Rửa sạch vết thương, dán băng hoặc báo người lớn; giữ vết thương sạch.']
 ]);
 add('Đạo đức',1,'Gia đình và nhà trường',[
  [1,'Ở trường, người dạy em học hằng ngày là ai?','Thầy giáo, cô giáo','Bác bảo vệ','Người lạ','Bạn hàng xóm'],
  [2,'Em làm gì để thể hiện lễ phép với ông bà, cha mẹ, thầy cô?','Chào hỏi, vâng lời, giúp đỡ việc vừa sức, chăm học.']
 ]);
 add('Đạo đức',1,'An toàn',[
  [1,'Khi qua đường, em cần làm gì cho an toàn?','Quan sát và đi cùng người lớn, đi đúng vạch kẻ đường','Chạy nhanh qua','Vừa đi vừa chơi','Đi một mình giữa đường'],
  [2,'Vật nào dưới đây nguy hiểm, em không được tự ý chơi?','Ổ điện, dao, bật lửa','Quả bóng','Bút màu','Gấu bông'],
  [3,'Khi ở nhà một mình có người lạ gõ cửa, em nên làm gì?','Không mở cửa cho người lạ, gọi điện hoặc báo bố mẹ, hàng xóm tin cậy.'],
  [2,'Vì sao không nên chơi gần ao, hồ, sông, suối một mình?','Dễ trượt ngã, đuối nước rất nguy hiểm; cần có người lớn, biết bơi và mặc áo phao.']
 ]);
 add('Đạo đức',2,'Quê hương, thầy cô, bạn bè',[
  [2,'Việc làm nào thể hiện tình yêu quê hương?','Giữ vệ sinh, bảo vệ cảnh đẹp quê mình','Vứt rác bừa bãi','Chê quê mình','Phá cây cối'],
  [2,'Em làm gì để thể hiện lòng kính trọng, biết ơn thầy cô?','Chào hỏi lễ phép, chăm học, vâng lời, chúc mừng thầy cô ngày 20/11.'],
  [3,'Bạn mới chuyển đến lớp còn rụt rè. Em nên làm gì?','Chủ động làm quen, rủ bạn cùng chơi, giúp bạn hòa nhập với lớp.']
 ]);
 add('Đạo đức',2,'Quý trọng thời gian, nhận lỗi',[
  [1,'Người biết quý trọng thời gian thường làm gì?','Học tập, làm việc đúng giờ, không trì hoãn','Để việc đến mai','Ham chơi quên học','Ngủ nướng'],
  [2,'Khi mắc lỗi với bạn, em nên nói gì?','Xin lỗi bạn và sửa lỗi','Đổ cho người khác','Im lặng bỏ qua','Cãi lại'],
  [2,'Vì sao cần biết nhận lỗi khi làm sai?','Để sửa sai, tiến bộ hơn và được mọi người tin yêu, tôn trọng.'],
  [3,'Lập thời gian biểu một buổi tối hợp lí của em.','Gợi ý: học bài, giúp việc nhà, ăn tối, nghỉ ngơi ngắn, đi ngủ đúng giờ.']
 ]);
 add('Đạo đức',2,'Cảm xúc và nơi công cộng',[
  [1,'Nơi công cộng là nơi như thế nào?','Nơi nhiều người cùng sử dụng như công viên, bến xe, thư viện','Phòng ngủ của em','Tủ quần áo','Ngăn bàn'],
  [2,'Vui, buồn, tức giận... được gọi chung là gì của con người?','Cảm xúc','Đồ vật','Thức ăn','Quần áo'],
  [2,'Nêu việc nên và không nên làm ở nơi công cộng.','Nên: giữ trật tự, xếp hàng, bỏ rác đúng chỗ. Không nên: chen lấn, nói to, xả rác, hái hoa bẻ cành.'],
  [3,'Khi buồn vì bị điểm kém, em nên làm gì để vượt qua?','Bình tĩnh tìm nguyên nhân, cố gắng học lại, nhờ thầy cô và bạn giúp; không nản lòng.']
 ]);
 add('Đạo đức',3,'Tổ quốc, hàng xóm',[
  [1,'Thủ đô của nước Việt Nam là thành phố nào?','Hà Nội','Thành phố Hồ Chí Minh','Đà Nẵng','Hải Phòng'],
  [2,'Em làm gì để thể hiện tình yêu Tổ quốc?','Chăm học, giữ gìn môi trường, tôn trọng Quốc kì – Quốc ca, tự hào về đất nước.'],
  [3,'Hàng xóm đi vắng nhờ em trông nhà giúp. Em nên làm gì?','Vui vẻ nhận lời nếu phù hợp, trông nom cẩn thận, báo ngay khi có việc bất thường.']
 ]);
 add('Đạo đức',3,'Ham học hỏi, giữ lời hứa',[
  [2,'Biểu hiện của người ham học hỏi là gì?','Chăm đọc sách, hay đặt câu hỏi, tìm tòi cái mới','Ngại học','Giấu dốt','Chép bài bạn'],
  [2,'Vì sao cần giữ lời hứa?','Giữ lời hứa thể hiện sự trung thực, trách nhiệm, được mọi người tin tưởng.'],
  [3,'Em hứa học xong bài mới xem ti vi nhưng lại xem trước. Em nên làm gì?','Nhận lỗi, tắt ti vi học bài ngay; lần sau thực hiện đúng lời hứa.']
 ]);
 add('Đạo đức',3,'An toàn giao thông, xử lí bất hòa',[
  [1,'Khi ngồi sau xe máy, em bắt buộc phải làm gì?','Đội mũ bảo hiểm cài quai đúng cách','Không cần mũ','Đứng trên xe','Thò chân ra ngoài'],
  [2,'Nêu việc cần làm để đi bộ đến trường an toàn.','Đi trên vỉa hè hoặc sát lề phải, qua đường đúng vạch, quan sát, không đùa nghịch dưới lòng đường.'],
  [3,'Hai bạn trong nhóm giận nhau không chịu làm bài chung. Là nhóm trưởng, em làm gì?','Lắng nghe cả hai, tìm điểm chung, phân công công việc công bằng, khuyên các bạn hòa giải vì việc chung.']
 ]);
 add('Đạo đức',4,'Biết ơn người lao động',[
  [1,'Nghề nào tạo ra lương thực nuôi sống con người?','Nông dân','Ca sĩ','Họa sĩ','Cầu thủ'],
  [2,'Thái độ đúng với người lao động là gì?','Tôn trọng, biết ơn, quý trọng thành quả lao động','Coi thường','Chê bai','Lãng phí'],
  [2,'Kể một số nghề và ích lợi của nghề đó.','VD: giáo viên dạy học; bác sĩ chữa bệnh; thợ xây xây nhà; nông dân làm ra gạo; công nhân làm đồ dùng.'],
  [3,'Em làm gì để quý trọng công sức của bác lao công ở trường?','Bỏ rác đúng nơi, giữ vệ sinh lớp và sân trường, chào hỏi lễ phép, không bày bừa.']
 ]);
 add('Đạo đức',4,'Cảm thông, giúp đỡ người gặp khó khăn',[
  [1,'Hành động nào thể hiện sự cảm thông?','An ủi, chia sẻ với người đang buồn, khó khăn','Chế giễu','Thờ ơ','Trêu chọc'],
  [2,'Khi trường quyên góp giúp bạn vùng lũ, em nên làm gì?','Tự nguyện góp sách vở, quần áo, đồ dùng trong khả năng','Làm ngơ','Chê bạn nghèo','Ngăn các bạn góp'],
  [2,'Vì sao cần giúp đỡ người gặp khó khăn?','Thể hiện lòng nhân ái, giúp họ vượt qua khó khăn, làm cuộc sống tốt đẹp hơn.'],
  [3,'Trong xóm có cụ già neo đơn. Em và các bạn có thể làm gì giúp cụ?','Thăm hỏi, giúp việc nhẹ (xách nước, quét sân), trò chuyện cho cụ vui, báo người lớn khi cụ cần.']
 ]);
 add('Đạo đức',4,'Yêu lao động, tôn trọng tài sản',[
  [2,'Biểu hiện của người yêu lao động là gì?','Chăm làm, tự giác làm việc nhà và việc trường','Lười biếng','Ỷ lại người khác','Trốn việc'],
  [2,'Vì sao phải tôn trọng tài sản của người khác và của công?','Vì đó là công sức của mọi người; giữ gìn thể hiện trung thực, trách nhiệm; không được lấy hay phá.'],
  [3,'Em mượn đồ dùng của bạn thì cần cư xử thế nào?','Hỏi mượn lịch sự, dùng cẩn thận, trả đúng hẹn và cảm ơn; nếu làm hỏng phải xin lỗi, đền.']
 ]);
 add('Đạo đức',4,'Quyền và bổn phận trẻ em',[
  [1,'Việc nào là quyền được bảo vệ của trẻ em?','Được chăm sóc sức khỏe, không bị đánh đập, ngược đãi','Phải làm việc nặng','Bị bỏ đói','Không được khám bệnh'],
  [2,'Đâu là bổn phận của trẻ em ở trường?','Chăm học, thực hiện nội quy, kính thầy, yêu bạn','Bỏ học','Đánh bạn','Vô lễ'],
  [2,'Kể một số quyền cơ bản của trẻ em.','Quyền được sống, được học tập, được chăm sóc sức khỏe, được vui chơi, được bảo vệ, được bày tỏ ý kiến.'],
  [3,'Vì sao trẻ em cần thực hiện tốt bổn phận của mình?','Để trở thành con ngoan, trò giỏi, công dân có ích; xứng đáng với sự quan tâm của gia đình và xã hội.']
 ]);
 add('Đạo đức',5,'Biết ơn người có công',[
  [1,'"Uống nước nhớ nguồn" khuyên ta điều gì?','Biết ơn những người đã tạo ra thành quả cho mình hưởng','Quên quá khứ','Chỉ nghĩ cho bản thân','Không cần biết ơn'],
  [2,'Việc làm nào thể hiện biết ơn người có công với đất nước?','Chăm sóc nghĩa trang liệt sĩ, giúp đỡ gia đình thương binh','Phá di tích','Quên ngày lễ','Chê lịch sử'],
  [2,'Kể vài ngày lễ, việc làm thể hiện đạo lí "Uống nước nhớ nguồn".','VD: 27/7 Thương binh – Liệt sĩ; 20/11 nhớ ơn thầy cô; Giỗ Tổ Hùng Vương 10/3; thăm hỏi, đền ơn đáp nghĩa.'],
  [3,'Trường tổ chức thăm Mẹ Việt Nam Anh hùng. Em chuẩn bị và cư xử thế nào?','Chuẩn bị quà hoặc tiết mục, ăn mặc lịch sự; lễ phép thăm hỏi, lắng nghe, bày tỏ lòng biết ơn.']
 ]);
 add('Đạo đức',5,'Tôn trọng sự khác biệt, bảo vệ cái đúng',[
  [1,'Mỗi người có điều gì riêng khiến ta nên tôn trọng?','Ngoại hình, sở thích, hoàn cảnh, năng lực khác nhau','Giống hệt nhau','Không có gì riêng','Phải giống số đông'],
  [2,'Khi bạn làm việc đúng nhưng bị số đông phản đối, em nên?','Ủng hộ, bảo vệ việc làm đúng của bạn','Hùa theo số đông','Im lặng','Chê bạn'],
  [2,'Vì sao cần tôn trọng sự khác biệt của mỗi người?','Vì mỗi người là một cá thể riêng; tôn trọng khác biệt giúp mọi người sống hòa hợp, đoàn kết, không kì thị.'],
  [3,'Thấy nhóm bạn chế nhạo bạn khuyết tật, em làm gì để bảo vệ cái đúng?','Can ngăn, nói rõ hành động đó là sai; bênh vực, động viên bạn; báo thầy cô; đối xử tôn trọng, bình đẳng.']
 ]);
 add('Đạo đức',5,'Bảo vệ môi trường, kế hoạch cá nhân',[
  [1,'Việc làm nào bảo vệ môi trường?','Bỏ rác đúng nơi, trồng cây, tiết kiệm điện nước','Xả rác bừa bãi','Chặt phá cây','Lãng phí nước'],
  [2,'Lập kế hoạch cá nhân giúp em điều gì?','Sắp xếp công việc hợp lí, dùng thời gian hiệu quả','Thêm rối việc','Lãng phí thời gian','Quên việc'],
  [2,'Nêu 3 việc em làm hằng ngày để bảo vệ môi trường.','VD: tắt điện khi không dùng, khóa vòi nước, bỏ rác đúng nơi, hạn chế túi ni-lông, trồng và chăm cây.'],
  [3,'Lập kế hoạch học tập và sinh hoạt cho một ngày cuối tuần của em.','Gợi ý có khung giờ: học bài, giúp việc nhà, thể dục, đọc sách, vui chơi, nghỉ ngơi hợp lí.']
 ]);
 add('Đạo đức',5,'Phòng tránh xâm hại, sử dụng tiền hợp lí',[
  [1,'Quy tắc về vùng riêng tư nhắc em điều gì?','Không để người khác chạm vào vùng kín, biết nói "Không" và kể lại','Cho người lạ chạm vào','Giữ bí mật mọi chuyện','Nghe theo người lạ'],
  [2,'Chi tiêu hợp lí nghĩa là gì?','Mua thứ cần thiết trước, biết tiết kiệm','Tiêu hết vào quà vặt','Mua theo đòi hỏi','Vay mượn để mua đồ chơi'],
  [2,'Nếu bị người khác đe dọa, dụ dỗ đụng chạm cơ thể, em cần làm gì?','Kiên quyết từ chối, bỏ chạy đến nơi đông người, kể ngay với bố mẹ, thầy cô; không giữ bí mật.'],
  [3,'Em có 100 000 đồng tiêu vặt trong tuần. Nêu cách chi tiêu hợp lí.','Gợi ý: để dành một phần, dành cho đồ dùng và ăn sáng cần thiết, phần nhỏ cho giải trí; ghi lại khoản chi, không tiêu hết ngay.']
 ]);

 /* ---------- TỰ NHIÊN VÀ XÃ HỘI ---------- */
 add('Tự nhiên và Xã hội',1,'Gia đình và trường học',[
  [1,'Ở trường, ngoài lớp học còn có nơi nào?','Thư viện, phòng y tế, sân chơi','Phòng ngủ của em','Bếp nhà em','Ga ra ô tô'],
  [2,'Trong gia đình, em cần cư xử thế nào với ông bà, cha mẹ?','Yêu thương, lễ phép, vâng lời','Cãi lại','Đòi hỏi','Không chào hỏi'],
  [2,'Kể các thành viên trong gia đình em và công việc của mỗi người.','HS kể: ông bà, bố mẹ, anh chị em và công việc (đi làm, nội trợ, đi học...).'],
  [2,'Em cần làm gì để giữ an toàn khi ở trường?','Không chạy nhảy xô đẩy, không leo trèo, đi cầu thang cẩn thận, nghe lời thầy cô.']
 ]);
 add('Tự nhiên và Xã hội',1,'Thực vật và động vật',[
  [1,'Con vật nào dưới đây biết bơi dưới nước?','Con cá','Con gà','Con mèo','Con chim sẻ'],
  [2,'Nêu ích lợi của một số con vật nuôi trong nhà.','VD: chó giữ nhà; mèo bắt chuột; gà cho trứng, thịt; trâu bò cho sức kéo.']
 ]);
 add('Tự nhiên và Xã hội',1,'Con người và sức khỏe',[
  [1,'Giác quan nào giúp em nhìn thấy mọi vật?','Mắt','Tai','Mũi','Lưỡi'],
  [2,'Để răng chắc khỏe, em nên làm gì?','Đánh răng ngày 2 lần, hạn chế ăn kẹo ngọt','Ăn nhiều kẹo','Không đánh răng','Cắn vật cứng'],
  [2,'Kể tên 5 giác quan và chức năng của mỗi giác quan.','Mắt – nhìn; tai – nghe; mũi – ngửi; lưỡi – nếm; da – cảm nhận nóng lạnh, sờ.'],
  [3,'Nêu việc em làm hằng ngày để giữ vệ sinh cơ thể.','Rửa mặt, đánh răng, rửa tay, tắm gội, cắt móng tay, mặc quần áo sạch.']
 ]);
 add('Tự nhiên và Xã hội',1,'Trái Đất và bầu trời',[
  [1,'Ban đêm, vật nào chiếu sáng dịu trên bầu trời?','Mặt Trăng','Mặt Trời','Bóng đèn đường','Ngọn nến'],
  [2,'Buổi sáng Mặt Trời mọc ở hướng nào?','Hướng đông','Hướng tây','Hướng bắc','Hướng nam'],
  [2,'Kể tên các buổi trong ngày và hoạt động thường làm.','Sáng – đi học; trưa – ăn, nghỉ; chiều – học hoặc chơi; tối – học bài, nghỉ ngơi, đi ngủ.'],
  [2,'Nêu một số hiện tượng thời tiết em biết.','Nắng, mưa, gió, nóng, lạnh, sấm chớp, sương mù, cầu vồng.']
 ]);
 add('Tự nhiên và Xã hội',1,'Cộng đồng địa phương',[
  [1,'Nơi khám và chữa bệnh cho mọi người gọi là gì?','Trạm y tế hoặc bệnh viện','Trường học','Chợ','Công viên'],
  [2,'Gặp đèn đỏ, người đi bộ phải làm gì?','Dừng lại chờ đèn xanh','Cứ đi','Chạy thật nhanh','Đi giữa đường'],
  [2,'Kể một số nơi công cộng ở địa phương và ích lợi.','VD: trường học để học; trạm y tế để khám bệnh; chợ để mua bán; công viên để vui chơi; bưu điện để gửi thư.'],
  [2,'Em cần làm gì để an toàn khi tham gia giao thông?','Đi bên phải, đội mũ bảo hiểm, qua đường đúng vạch, quan sát, không đùa nghịch dưới lòng đường.']
 ]);
 add('Tự nhiên và Xã hội',2,'Gia đình và trường học',[
  [1,'Người giữ gìn an ninh, trật tự ở trường là ai?','Bác bảo vệ','Đầu bếp','Tài xế','Nông dân'],
  [2,'Để phòng tránh ngã ở trường, em nên làm gì?','Không chạy đuổi, không leo trèo lan can','Chạy nhảy cầu thang','Leo cửa sổ','Xô đẩy bạn'],
  [2,'Kể các phòng, khu vực trong trường em và công dụng.','VD: lớp học để học; thư viện để đọc sách; phòng y tế để sơ cứu; sân trường để chơi, chào cờ.'],
  [2,'Em làm những việc gì để giúp đỡ gia đình?','Quét nhà, gấp quần áo, trông em, tưới cây, sắp xếp đồ dùng.']
 ]);
 add('Tự nhiên và Xã hội',2,'Cộng đồng địa phương',[
  [1,'Phương tiện nào là phương tiện giao thông đường bộ?','Xe máy, ô tô','Tàu thủy','Máy bay','Thuyền buồm'],
  [2,'Khi bị lạc ở nơi công cộng, em nên tìm ai để nhờ giúp?','Chú công an, bảo vệ, người lớn đáng tin','Người lạ rủ đi','Tự đi tìm một mình','Người lái xe lạ'],
  [2,'Kể một số phương tiện giao thông và nơi chúng đi.','Đường bộ: xe đạp, xe máy, ô tô; đường thủy: thuyền, tàu; hàng không: máy bay; đường sắt: tàu hỏa.'],
  [2,'Nêu việc nên làm để giữ vệ sinh nơi công cộng.','Bỏ rác đúng nơi, không khạc nhổ, không vẽ bậy, giữ trật tự, bảo vệ cây xanh.']
 ]);
 add('Tự nhiên và Xã hội',2,'Thực vật và động vật',[
  [1,'Cây nào dưới đây là cây lương thực?','Cây lúa','Cây hoa hồng','Cây bàng','Cây tùng'],
  [2,'Bộ phận nào của cây thường dùng để trồng thành cây mới?','Hạt','Lá khô','Bông hoa đã tàn','Vỏ cây'],
  [2,'Nêu các bộ phận chính của cây và kể một cây ăn quả em biết.','Cây có rễ, thân, lá, hoa, quả. VD cây ăn quả: xoài, cam, ổi, chuối...'],
  [3,'Chúng ta cần làm gì để chăm sóc và bảo vệ cây xanh?','Tưới nước, bón phân, nhổ cỏ, không bẻ cành hái lá, trồng thêm cây.']
 ]);
 add('Tự nhiên và Xã hội',2,'Con người và sức khỏe',[
  [1,'Cơ quan vận động của cơ thể gồm những gì?','Xương và cơ','Tim và phổi','Dạ dày và ruột','Mắt và tai'],
  [3,'Nêu việc nên làm để xương và cơ phát triển tốt.','Ăn đủ chất (nhất là can-xi), tập thể dục, ngồi học đúng tư thế, mang vác vừa sức.']
 ]);
 add('Tự nhiên và Xã hội',2,'Trái Đất và bầu trời',[
  [1,'Ban đêm, vật nào chiếu sáng dịu trên bầu trời?','Mặt Trăng','Mặt Trời','Bóng đèn đường','Ngọn nến'],
  [2,'Buổi chiều, Mặt Trời lặn ở hướng nào?','Hướng tây','Hướng đông','Hướng bắc','Hướng nam'],
  [2,'Kể một số hiện tượng thời tiết và cách ăn mặc phù hợp.','Trời nắng – mặc thoáng, đội mũ; trời mưa – mặc áo mưa; trời lạnh – mặc ấm.'],
  [2,'Vì sao ban ngày trời sáng, ban đêm trời tối?','Ban ngày có Mặt Trời chiếu sáng; ban đêm không có Mặt Trời nên trời tối.']
 ]);
 add('Tự nhiên và Xã hội',3,'Gia đình và trường học',[
  [1,'Những người cùng ông bà, bố mẹ là gì của nhau?','Họ hàng ruột thịt','Người lạ','Hàng xóm','Bạn bè'],
  [2,'Để phòng cháy khi ở nhà, em nên làm gì?','Không nghịch lửa, bật lửa, ổ điện; tắt bếp sau khi dùng','Nghịch diêm','Cắm nhiều thiết bị một ổ','Để đồ gần bếp lửa'],
  [2,'Vẽ hoặc kể sơ đồ các thế hệ trong gia đình em.','Gợi ý: ông bà (thế hệ 1) → bố mẹ (thế hệ 2) → các con (thế hệ 3).'],
  [3,'Nêu việc cần làm để phòng tránh tai nạn ở nhà.','Không nghịch điện, lửa, dao kéo; không leo trèo; cất thuốc, hóa chất xa tầm tay; đi lại cẩn thận.']
 ]);
 add('Tự nhiên và Xã hội',3,'Cộng đồng địa phương',[
  [1,'Hoạt động sản xuất nào thuộc nông nghiệp?','Trồng lúa, nuôi gà','Dệt vải trong nhà máy','Bán hàng ở siêu thị','Sửa xe máy'],
  [2,'Sản phẩm thủ công được làm chủ yếu bằng gì?','Bàn tay và dụng cụ của người thợ','Hoàn toàn bằng máy lớn','Tự nhiên có sẵn','Nhập từ nước ngoài'],
  [2,'Kể một số hoạt động sản xuất ở địa phương em.','VD: trồng trọt, chăn nuôi, nuôi và đánh bắt thủy sản, nghề thủ công, buôn bán, dịch vụ.'],
  [3,'Vì sao cần giữ gìn di tích, cảnh quan ở địa phương?','Vì đó là tài sản chung, nét đẹp văn hóa – lịch sử; giữ gìn để truyền cho đời sau và phát triển du lịch.']
 ]);
 add('Tự nhiên và Xã hội',3,'Con người và sức khỏe',[
  [1,'Cơ quan tiêu hóa giúp cơ thể làm gì?','Biến thức ăn thành chất nuôi cơ thể','Giúp thở','Bơm máu','Giúp nghe'],
  [2,'Để cơ quan hô hấp khỏe mạnh, em nên làm gì?','Giữ ấm, tránh khói bụi, tập thể dục, ở nơi thoáng sạch','Hít khói thuốc','Ở nơi bụi bẩn','Không vận động'],
  [2,'Kể tên vài cơ quan trong cơ thể và chức năng chính.','Hô hấp – thở; tuần hoàn – vận chuyển máu; tiêu hóa – tiêu hóa thức ăn; bài tiết – thải chất thừa.'],
  [3,'Nêu việc nên làm để bảo vệ cơ quan tuần hoàn (tim mạch).','Ăn uống điều độ, tập thể dục, ngủ đủ, giữ tinh thần vui vẻ, không dùng chất kích thích.']
 ]);
 add('Tự nhiên và Xã hội',3,'Thực vật và động vật',[
  [3,'Vì sao cần bảo vệ các loài động vật hoang dã?','Giữ cân bằng tự nhiên, bảo vệ đa dạng sinh học; nhiều loài có ích và quý hiếm cần được bảo vệ.']
 ]);
 add('Tự nhiên và Xã hội',3,'Trái Đất và bầu trời',[
  [2,'Nêu việc nên làm để an toàn khi trời mưa giông, sấm sét.','Không trú dưới cây to, cột điện; vào nhà hoặc nơi an toàn; tránh dùng điện; không ra đồng trống.']
 ]);

 /* ---------- KHOA HỌC ---------- */
 add('Khoa học',4,'Thực vật, động vật và nấm',[
  [2,'Nấm khác cây xanh ở điểm nào?','Nấm không có lá và không tự tạo chất dinh dưỡng bằng quang hợp như cây xanh.']
 ]);
 add('Khoa học',4,'Con người và sức khỏe',[
  [2,'Kể tên 4 nhóm chất dinh dưỡng cần thiết cho cơ thể.','Chất bột đường, chất đạm, chất béo, vi-ta-min và chất khoáng (cùng nước và chất xơ).']
 ]);
 add('Khoa học',4,'Sinh vật và môi trường',[
  [1,'Môi trường sống cung cấp cho sinh vật những gì?','Thức ăn, nước, không khí, nơi ở','Chỉ có ánh sáng','Chỉ có đất','Không có gì'],
  [2,'Trong chuỗi thức ăn, cây xanh đóng vai trò gì?','Là nguồn thức ăn đầu tiên cho động vật ăn cỏ','Là động vật ăn thịt','Là vi khuẩn','Không có vai trò'],
  [2,'Chuỗi thức ăn là gì? Cho một ví dụ.','Là dãy sinh vật nối nhau bởi quan hệ thức ăn. VD: cây lúa → châu chấu → ếch → rắn.'],
  [3,'Nêu việc con người cần làm để bảo vệ môi trường sống của sinh vật.','Trồng và bảo vệ rừng, không săn bắt bừa bãi, xử lí rác và nước thải, giữ sạch nguồn nước.']
 ]);
 add('Khoa học',5,'Chất',[
  [2,'Nêu ba thể của chất và cho ví dụ mỗi thể.','Thể rắn (viên đá, sắt), thể lỏng (nước, dầu), thể khí (không khí, hơi nước).']
 ]);
 add('Khoa học',5,'Năng lượng',[
  [2,'Kể một số nguồn năng lượng và ích lợi của chúng.','Mặt Trời (chiếu sáng, sưởi ấm, pin mặt trời), gió (quay tua bin), nước (thủy điện), điện (thắp sáng, chạy máy).']
 ]);
 add('Khoa học',5,'Thực vật và động vật',[
  [2,'Nêu các giai đoạn trong vòng đời của cây có hoa.','Hạt → nảy mầm → cây con → cây trưởng thành → ra hoa → kết quả, tạo hạt.'],
  [3,'Vì sao nói hoa là cơ quan sinh sản của cây có hoa?','Hoa có nhị và nhụy; sau thụ phấn, thụ tinh sẽ tạo thành quả và hạt để sinh ra cây mới.']
 ]);
 add('Khoa học',5,'Vi khuẩn',[
  [1,'Vi khuẩn có kích thước như thế nào?','Rất nhỏ, không nhìn thấy bằng mắt thường','Rất to','Bằng con kiến','Bằng hạt gạo'],
  [2,'Vi khuẩn có ích được dùng để làm gì?','Làm sữa chua, muối dưa cà','Làm hỏng mọi thức ăn','Chỉ gây bệnh','Không có tác dụng gì'],
  [2,'Nêu một số ích lợi và tác hại của vi khuẩn.','Có ích: làm sữa chua, dưa muối, phân hủy xác sinh vật. Tác hại: gây bệnh, làm ôi thiu thức ăn.'],
  [3,'Nêu cách phòng tránh bệnh do vi khuẩn gây ra.','Rửa tay sạch, ăn chín uống sôi, giữ vệ sinh môi trường, bảo quản thức ăn đúng cách.']
 ]);
 add('Khoa học',5,'Con người và sức khỏe',[
  [1,'Con người cần làm gì để có sức khỏe tốt?','Ăn đủ chất, vận động, ngủ đủ, giữ vệ sinh','Thức khuya','Lười vận động','Ăn uống thất thường'],
  [2,'Để phòng bệnh lây qua đường hô hấp, em nên làm gì?','Đeo khẩu trang, che miệng khi ho, giữ ấm, rửa tay','Không che miệng khi ho','Đến chỗ đông khi ốm','Dùng chung khăn'],
  [2,'Nêu việc nên làm để bảo vệ sức khỏe tuổi học sinh.','Ăn đủ 4 nhóm chất, uống đủ nước, tập thể dục, ngủ đủ, học tập điều độ, giữ vệ sinh cá nhân.'],
  [3,'Vì sao cần giữ vệ sinh trong ăn uống?','Để phòng bệnh đường tiêu hóa do vi khuẩn, giun sán; cần ăn chín, uống sôi, rửa tay trước khi ăn.']
 ]);
 add('Khoa học',5,'Sinh vật và môi trường',[
  [1,'Môi trường cung cấp cho con người những gì?','Thức ăn, nước, không khí, nơi ở, nguyên liệu','Chỉ tiếng ồn','Chỉ rác thải','Không gì cả'],
  [2,'Việc làm nào gây ô nhiễm môi trường?','Xả rác, nước thải bừa bãi','Trồng cây','Dùng lại túi vải','Tiết kiệm điện'],
  [2,'Để bảo vệ rừng, chúng ta nên làm gì?','Trồng cây, không chặt phá, không đốt rừng','Chặt cây bừa bãi','Đốt rừng làm nương','Săn bắt thú'],
  [3,'Nêu hậu quả của việc rừng bị tàn phá.','Lũ lụt, sạt lở, hạn hán, xói mòn đất, mất nơi ở của động vật, không khí ô nhiễm.']
 ]);

 /* ---------- LỊCH SỬ VÀ ĐỊA LÍ ---------- */
 add('Lịch sử và Địa lí',4,'Địa phương em',[
  [1,'Bản đồ hành chính giúp em biết điều gì về địa phương?','Vị trí, ranh giới, tên các đơn vị hành chính','Món ăn ngon','Giá cả hàng hóa','Thời tiết ngày mai'],
  [2,'Để tìm hiểu nghề truyền thống ở địa phương, em nên làm gì?','Hỏi người lớn, tham quan làng nghề, tìm tài liệu','Đoán bừa','Không cần tìm hiểu','Chép trên mạng không kiểm chứng'],
  [2,'Giới thiệu vị trí và vài đặc điểm tự nhiên của địa phương em.','HS nêu: tỉnh/thành, giáp ranh, địa hình (đồng bằng, đồi núi, ven biển), sông ngòi, khí hậu.'],
  [3,'Em làm gì để góp phần xây dựng quê hương ngày càng đẹp?','Chăm học, giữ vệ sinh, bảo vệ môi trường và di tích, tuyên truyền nét đẹp quê hương.']
 ]);
 add('Lịch sử và Địa lí',4,'Trung du và miền núi Bắc Bộ',[
  [2,'Kể một số dân tộc và nét văn hóa tiêu biểu ở Trung du và miền núi Bắc Bộ.','Nhiều dân tộc: Tày, Nùng, Thái, Mông, Dao...; nét văn hóa: chợ phiên, lễ hội, nhà sàn, ruộng bậc thang, múa xòe.'],
  [3,'Vì sao vùng này phát triển được thủy điện?','Có nhiều sông lớn, địa hình dốc, nước chảy mạnh nên xây được nhà máy thủy điện (VD: Hòa Bình, Sơn La).']
 ]);
 add('Lịch sử và Địa lí',4,'Đồng bằng Bắc Bộ',[
  [2,'Vì sao Đồng bằng Bắc Bộ trồng được nhiều lúa nước?','Đất phù sa màu mỡ do sông Hồng, sông Thái Bình bồi đắp; nguồn nước dồi dào; người dân có kinh nghiệm trồng lúa.']
 ]);
 add('Lịch sử và Địa lí',4,'Duyên hải miền Trung',[
  [2,'Nêu một số thế mạnh kinh tế biển của vùng Duyên hải miền Trung.','Đánh bắt và nuôi trồng hải sản, làm muối, du lịch biển, giao thông cảng biển.'],
  [3,'Vì sao vùng Duyên hải miền Trung hay chịu bão, lũ?','Giáp biển, địa hình hẹp và dốc từ núi ra biển, mưa bão nhiều nên dễ bị bão, lũ lụt, hạn hán.']
 ]);
 add('Lịch sử và Địa lí',4,'Tây Nguyên',[
  [1,'Cây công nghiệp nào được trồng nhiều nhất ở Tây Nguyên?','Cà phê','Cây lúa nước','Cây chè vùng đồng bằng','Cây táo']
 ]);
 add('Lịch sử và Địa lí',4,'Nam Bộ',[
  [2,'Vì sao Đồng bằng Nam Bộ là vựa lúa, vựa trái cây lớn nhất nước ta?','Đất phù sa màu mỡ, sông ngòi kênh rạch chằng chịt, khí hậu nóng ẩm quanh năm nên trồng lúa, cây ăn quả tốt.'],
  [3,'Kể một số nét văn hóa tiêu biểu của người dân Nam Bộ.','Chợ nổi, đờn ca tài tử, nhà ở ven sông, nhiều lễ hội; tính cách phóng khoáng, hiếu khách.']
 ]);
 add('Lịch sử và Địa lí',5,'Đất nước và con người Việt Nam',[
  [2,'Nước Việt Nam giáp những quốc gia nào trên đất liền?','Phía bắc giáp Trung Quốc; phía tây giáp Lào và Cam-pu-chia.'],
  [3,'Vì sao nói Việt Nam là quốc gia có nhiều dân tộc?','Việt Nam có 54 dân tộc anh em cùng chung sống, mỗi dân tộc có bản sắc riêng, đoàn kết xây dựng đất nước.']
 ]);
 add('Lịch sử và Địa lí',5,'Những quốc gia đầu tiên',[
  [1,'Nhà nước Văn Lang do ai đứng đầu?','Các vua Hùng','An Dương Vương','Hai Bà Trưng','Ngô Quyền'],
  [2,'Kinh đô của nước Âu Lạc đặt ở đâu?','Cổ Loa (Đông Anh, Hà Nội ngày nay)','Phong Châu','Hoa Lư','Thăng Long'],
  [2,'Kể tên hai nhà nước đầu tiên của nước ta và người đứng đầu.','Văn Lang – các vua Hùng; Âu Lạc – An Dương Vương (Thục Phán).'],
  [3,'Truyền thuyết nào gắn với thành Cổ Loa và nước Âu Lạc? Nêu ý nghĩa.','Truyền thuyết An Dương Vương xây thành Cổ Loa và nỏ thần; nhắc nhở phải cảnh giác giữ nước, không chủ quan.']
 ]);
 add('Lịch sử và Địa lí',5,'Xây dựng và bảo vệ đất nước',[
  [3,'Nêu một số triều đại trong lịch sử dựng nước và giữ nước của dân tộc ta.','VD: thời Hùng Vương dựng nước; các triều Ngô, Đinh, Tiền Lê, Lý, Trần, Lê, Nguyễn cùng nhiều cuộc kháng chiến chống ngoại xâm.']
 ]);
 add('Lịch sử và Địa lí',5,'Các nước láng giềng và thế giới',[
  [2,'Kể tên các nước láng giềng của Việt Nam và một hiểu biết về một nước.','Trung Quốc, Lào, Cam-pu-chia. VD: Lào không giáp biển, nhiều chùa; Cam-pu-chia có đền Ăng-co Vát nổi tiếng.'],
  [3,'Vì sao các nước trong khu vực cần hợp tác, hữu nghị với nhau?','Để cùng phát triển kinh tế, giữ hòa bình, giúp đỡ nhau và giải quyết các vấn đề chung như môi trường, thiên tai.']
 ]);

 /* ---------- TIẾNG VIỆT ---------- */
 add('Tiếng Việt',1,'Âm, vần, chữ cái',[
  [3,'Tìm 3 tiếng có vần "an" (ví dụ: bàn) và đặt câu với một tiếng.','VD tiếng: bàn, lan, than, chan... Đặt câu đủ ý, VD: "Hoa lan nở rất đẹp."']
 ]);
 add('Tiếng Việt',1,'Từ và câu',[
  [1,'Từ nào dưới đây chỉ con vật?','con mèo','cái bàn','quyển sách','bông hoa'],
  [1,'Từ nào dưới đây chỉ đồ vật?','cái bút','con gà','cây chuối','bạn Lan'],
  [2,'Câu nào dưới đây được viết đúng?','Em đi học.','em đi học.','Em đi học','em đi học']
 ]);
 add('Tiếng Việt',1,'Đọc hiểu',[
  [3,'Sau khi đọc một câu chuyện, hãy nói nhân vật em thích và vì sao.','HS nêu được tên nhân vật và lí do (tốt bụng, chăm chỉ, dũng cảm...).']
 ]);
 add('Tiếng Việt',2,'Chính tả',[
  [2,'Điền vào chỗ trống l hoặc n: "…o lắng", "…àng xóm".','lo lắng; làng xóm.'],
  [3,'Tìm và sửa lỗi chính tả: "Bé ngồi học bài dưới ánh đèn sáng chưng."','Sửa "sáng chưng" thành "sáng trưng". Câu đúng: "Bé ngồi học bài dưới ánh đèn sáng trưng."']
 ]);
 add('Tiếng Việt',2,'Từ chỉ sự vật, hoạt động, đặc điểm',[
  [3,'Tìm 2 từ chỉ hoạt động và 2 từ chỉ đặc điểm, đặt 1 câu có dùng chúng.','VD hoạt động: chạy, đọc; đặc điểm: cao, xanh. Câu: "Cây cao có tán lá xanh."']
 ]);
 add('Tiếng Việt',2,'Câu và dấu câu',[
  [2,'Cuối câu hỏi, ta dùng dấu câu nào?','Dấu chấm hỏi (?)','Dấu chấm (.)','Dấu phẩy (,)','Dấu chấm than (!)']
 ]);
 add('Tiếng Việt',2,'Viết đoạn',[
  [1,'Câu đầu tiên của đoạn văn cần viết thế nào?','Lùi vào đầu dòng, viết hoa chữ đầu','Viết sát lề','Viết thường','Không cần dấu câu'],
  [2,'Đoạn văn kể về gia đình thường nói đến điều gì?','Các thành viên và tình cảm gia đình','Giá đồ chơi','Thời tiết nước ngoài','Cách nấu ăn khó'],
  [2,'Để đoạn văn hay hơn, em nên dùng từ ngữ thế nào?','Từ ngữ gợi tả, chân thật, đúng ý','Từ ngữ khó hiểu','Nói sai sự thật','Lặp lại một từ nhiều lần'],
  [1,'Cuối mỗi câu trong đoạn văn cần có gì?','Dấu câu (dấu chấm...)','Không có gì','Số thứ tự','Dấu gạch ngang'],
  [2,'Trước khi viết đoạn, em nên làm gì?','Nghĩ ý sẽ viết (viết về ai, điều gì)','Viết ngay không nghĩ','Chép của bạn','Bỏ trống']
 ]);
 add('Tiếng Việt',3,'Từ chỉ sự vật, hoạt động, đặc điểm',[
  [3,'Đặt câu có một từ chỉ sự vật và một từ chỉ đặc điểm.','VD: "Bông hoa (sự vật) đỏ thắm (đặc điểm)." Câu đủ ý, đúng yêu cầu.']
 ]);
 add('Tiếng Việt',3,'Biện pháp so sánh',[
  [2,'Trong câu "Mặt trời đỏ như quả cầu lửa", sự vật nào được so sánh với quả cầu lửa?','Mặt trời','Quả cầu','Bầu trời','Đám mây'],
  [3,'Đặt một câu có hình ảnh so sánh về trăng hoặc biển.','VD: "Trăng tròn như chiếc đĩa bạc." / "Mặt biển xanh như tấm thảm khổng lồ." (có từ so sánh: như, là...).']
 ]);
 add('Tiếng Việt',3,'Đọc hiểu',[
  [2,'Để hiểu nội dung bài đọc, trước hết em cần làm gì?','Đọc kĩ toàn bài','Chỉ đọc nhan đề','Đoán nội dung','Bỏ qua các câu khó'],
  [2,'Nhan đề (tên bài) thường cho em biết điều gì?','Nội dung chính của bài','Tên nhà in','Số trang','Giá quyển sách'],
  [3,'Sau khi đọc bài, hãy nêu bài học hoặc ý nghĩa em rút ra.','HS nêu ý nghĩa phù hợp nội dung bài đọc (lòng tốt, chăm chỉ, yêu thương...).']
 ]);
 add('Tiếng Việt',3,'Viết đoạn văn',[
  [1,'Một đoạn văn gồm những phần nào?','Câu mở đầu, các câu phát triển, câu kết','Chỉ một câu','Không có mở đầu','Chỉ có kết'],
  [2,'Câu mở đầu đoạn văn tả đồ vật thường làm gì?','Giới thiệu đồ vật định tả','Nêu cảm nghĩ cuối cùng','Ghi tên tác giả','Kết thúc đoạn'],
  [2,'Khi tả một con vật, em nên tả theo trình tự nào?','Từ hình dáng chung đến đặc điểm, hoạt động','Lộn xộn','Chỉ tả màu sắc','Chỉ nói tên'],
  [1,'Để đoạn văn mạch lạc, các câu cần sắp xếp thế nào?','Theo trình tự hợp lí, liên kết với nhau','Ngẫu nhiên','Đảo lộn','Rời rạc'],
  [2,'Dùng hình ảnh so sánh trong đoạn văn có tác dụng gì?','Làm câu văn sinh động, gợi hình','Làm bài dài hơn','Gây khó hiểu','Không có tác dụng']
 ]);
 add('Tiếng Việt',4,'Biện pháp nhân hóa',[
  [1,'Nhân hóa là gọi hoặc tả con vật, cây cối, đồ vật bằng cách nào?','Như gọi, tả con người','Bằng con số','Bằng công thức','Bằng tiếng nước ngoài'],
  [2,'Câu nào dưới đây có dùng biện pháp nhân hóa?','Ông mặt trời thức dậy sau rặng tre.','Mặt trời mọc ở hướng đông.','Trời hôm nay nắng.','Buổi sáng trời có nắng.'],
  [3,'Đặt một câu có dùng biện pháp nhân hóa tả cây cối.','VD: "Hàng cây đứng trầm ngâm bên đường." / "Cây bàng vươn tay đón nắng."'],
  [4,'Chỉ ra biện pháp nhân hóa trong câu "Chị gió dạo chơi khắp cánh đồng" và nêu tác dụng.','Nhân hóa: gọi gió là "chị", gió biết "dạo chơi" như người. Tác dụng: câu văn sinh động, gần gũi, cảnh vật có hồn.']
 ]);
 add('Tiếng Việt',4,'Câu: chủ ngữ, vị ngữ, trạng ngữ',[
  [3,'Thêm trạng ngữ cho câu "Hoa phượng nở đỏ rực" và cho biết trạng ngữ chỉ gì.','VD: "Mùa hè, hoa phượng nở đỏ rực." – trạng ngữ "Mùa hè" chỉ thời gian (có thể chỉ nơi chốn, nguyên nhân...).']
 ]);
 add('Tiếng Việt',4,'Đọc hiểu',[
  [2,'Để trả lời đúng câu hỏi đọc hiểu, em cần dựa vào đâu?','Nội dung trong bài đọc','Suy đoán vô căn cứ','Ý kiến bạn bên cạnh','Bìa sách'],
  [2,'Ý chính của một đoạn văn thường nằm ở đâu?','Ở câu mở đầu hoặc câu kết đoạn','Luôn ở giữa đoạn','Không có','Ở nhan đề sách'],
  [1,'"Nhân vật chính" trong câu chuyện là gì?','Người (vật) được nói đến nhiều nhất, xuyên suốt','Người xuất hiện một lần','Tác giả','Người đọc truyện'],
  [3,'Đọc một đoạn văn trong SGK và nêu nội dung chính của đoạn.','HS nêu đúng, ngắn gọn nội dung chính của đoạn đã đọc.']
 ]);
 add('Tiếng Việt',4,'Viết bài văn',[
  [1,'Bài văn gồm mấy phần?','Ba phần: mở bài, thân bài, kết bài','Một phần','Hai phần','Năm phần'],
  [2,'Mở bài có nhiệm vụ gì?','Giới thiệu đối tượng được tả hoặc kể','Tả chi tiết','Nêu cảm nghĩ kết thúc','Ghi tên sách'],
  [2,'Thân bài của bài văn tả cây cối thường tả gì?','Tả các bộ phận, đặc điểm của cây theo trình tự','Giới thiệu cây','Nêu cảm nghĩ cuối','Ghi ngày tháng'],
  [1,'Kết bài thường làm gì?','Nêu cảm nghĩ, tình cảm với đối tượng','Giới thiệu mở đầu','Tả chi tiết','Liệt kê số liệu'],
  [2,'Để bài văn hay, nên dùng biện pháp nghệ thuật nào?','So sánh, nhân hóa','Chỉ liệt kê','Dùng từ khó hiểu','Viết sai ngữ pháp']
 ]);
 add('Tiếng Việt',5,'Từ đồng nghĩa, từ đa nghĩa',[
  [3,'Tìm 2 từ đồng nghĩa với từ "chăm chỉ" và đặt câu với một từ.','VD: siêng năng, cần cù. Câu: "Bạn Lan rất siêng năng học tập."']
 ]);
 add('Tiếng Việt',5,'Đại từ, kết từ',[
  [2,'Đại từ dùng để làm gì? Cho ví dụ.','Dùng để xưng hô hoặc thay thế cho danh từ đã nói đến. VD: tôi, chúng ta, nó, họ...'],
  [3,'Đặt một câu có dùng kết từ (và, nhưng, vì... nên...).','VD: "Trời mưa to nhưng em vẫn đi học đúng giờ."']
 ]);
 add('Tiếng Việt',5,'Câu ghép và liên kết câu',[
  [1,'Câu ghép là câu như thế nào?','Câu do hai hay nhiều vế câu ghép lại','Câu chỉ có một vế','Câu hỏi','Câu cảm ngắn'],
  [3,'Đặt một câu ghép nói về thời tiết và hoạt động của em.','VD: "Trời đã tối nên em vào nhà học bài." (có từ nối, hai vế câu).']
 ]);
 add('Tiếng Việt',5,'Đọc hiểu',[
  [2,'Để nắm nội dung bài đọc, em nên đọc như thế nào?','Đọc kĩ, có suy nghĩ','Đọc lướt qua','Chỉ đọc câu đầu','Đoán nội dung'],
  [2,'Chi tiết trong bài đọc dùng để làm gì?','Làm rõ nội dung, ý nghĩa của bài','Trang trí','Tăng số trang','Không có tác dụng'],
  [1,'Thông điệp (bài học) của văn bản là gì?','Điều tác giả muốn gửi gắm đến người đọc','Số lượng câu','Tên nhà xuất bản','Giá sách'],
  [3,'Đọc một bài trong SGK, nêu bài học em tâm đắc nhất.','HS nêu bài học phù hợp với văn bản, có lí giải ngắn.']
 ]);
 add('Tiếng Việt',5,'Viết bài văn',[
  [1,'Bài văn tả người thường tả những gì?','Ngoại hình, hoạt động, tính cách','Chỉ tả quần áo','Chỉ nói tên','Chỉ tả nơi ở'],
  [2,'Trình tự hợp lí khi tả cảnh là gì?','Theo không gian hoặc thời gian','Lộn xộn','Chỉ tả một chi tiết','Ngẫu nhiên'],
  [2,'Kết bài mở rộng khác kết bài không mở rộng ở chỗ nào?','Có thêm liên hệ, cảm nghĩ sâu hơn','Ngắn hơn','Không có cảm nghĩ','Chỉ ghi tên'],
  [1,'Để bài văn mạch lạc, các đoạn cần có gì?','Liên kết, chuyển ý hợp lí','Rời rạc','Đảo lộn','Trùng lặp'],
  [2,'Yếu tố nào làm bài văn tả người sinh động?','Chi tiết tiêu biểu kết hợp hình ảnh so sánh','Liệt kê khô khan','Sao chép','Viết chung chung']
 ]);

 /* ---- Bù lẻ cho đủ chuẩn 6 TN + 4 TL ---- */
 add('Đạo đức',2,'Quê hương, thầy cô, bạn bè',[
  [3,'Nêu một việc em có thể làm để giúp đỡ bạn bè trong học tập.','VD: giảng lại bài bạn chưa hiểu, cùng ôn bài, cho bạn mượn đồ dùng, động viên bạn cố gắng.']
 ]);
 add('Đạo đức',3,'Ham học hỏi, giữ lời hứa',[
  [2,'Vì sao ham học hỏi giúp em tiến bộ?','Nhờ tìm tòi, hỏi han mà em hiểu biết nhiều hơn, học giỏi hơn và tự tin hơn.']
 ]);
 add('Đạo đức',5,'Bảo vệ môi trường, kế hoạch cá nhân',[
  [2,'Việc làm nào góp phần giảm rác thải nhựa?','Dùng bình nước, túi vải nhiều lần','Dùng nhiều túi ni-lông','Vứt chai nhựa bừa bãi','Mua đồ gói nhiều lớp nhựa']
 ]);
 add('Khoa học',5,'Vi khuẩn',[
  [2,'Thức ăn để lâu ngoài không khí dễ bị ôi thiu là do đâu?','Do vi khuẩn phát triển làm hỏng thức ăn','Do thức ăn tự biến mất','Do ánh sáng Mặt Trời','Do thức ăn nở ra']
 ]);
 add('Lịch sử và Địa lí',4,'Tây Nguyên',[
  [2,'Nêu một số dân tộc và nét văn hóa tiêu biểu ở Tây Nguyên.','Các dân tộc: Gia-rai, Ê-đê, Ba-na, Xơ-đăng...; nét văn hóa: nhà rông, cồng chiêng, lễ hội, trang phục thổ cẩm.']
 ]);

})();
