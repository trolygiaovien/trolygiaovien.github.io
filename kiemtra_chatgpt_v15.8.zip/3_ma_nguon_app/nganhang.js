/* NGÂN HÀNG CÂU HỎI
   Cấu trúc: NH[môn][lớp] = [ {cd:'Chủ đề', q:[ câu, … ]}, … ]
   Câu trắc nghiệm: [mức, 'câu hỏi', 'ĐÁP ÁN ĐÚNG', 'sai 1', 'sai 2', 'sai 3']  (2–4 phương án, phương án đầu là đúng, máy tự xáo trộn)
   Câu tự luận:     [mức, 'câu hỏi', 'đáp án / gợi ý chấm']
   Mức: 1 = nhận biết, 2 = kết nối/hiểu, 3 = vận dụng (Thông tư 27/2020/TT-BGDĐT)
   Giáo viên có thể tự thêm câu theo đúng mẫu trên. */
const NH={};

/* ======================= TIẾNG VIỆT ======================= */
NH['Tiếng Việt']={
1:[
 {cd:'Âm, vần, chữ cái',q:[
  [1,'Chữ nào ghép với "a" để được tiếng "ba"?','b','d','đ','p'],
  [1,'Tiếng "mèo" có vần gì?','eo','ao','e','ơ'],
  [1,'Tiếng nào có vần "an"?','bàn','bông','bút','bé'],
  [2,'Điền c hay k: …ì cọ','k','c'],
  [2,'Điền g hay gh: …ế gỗ','gh','g'],
  [2,'Điền ng hay ngh: …ỉ hè','ngh','ng'],
  [1,'Tiếng "hoa" có mấy chữ cái?','3 chữ cái','2 chữ cái','4 chữ cái','5 chữ cái'],
  [3,'Viết 2 tiếng có vần "ương".','Ví dụ: vườn, đường, gương, hương…'],
 ]},
 {cd:'Từ và câu',q:[
  [1,'Từ nào chỉ con vật?','con gà','cái bàn','quả cam','bông hoa'],
  [1,'Từ nào chỉ đồ dùng học tập?','bút chì','con mèo','cây bàng','quả na'],
  [2,'Sắp xếp các từ thành câu: "đi học / Bé / vui vẻ"','Bé đi học vui vẻ.'],
  [2,'Cuối câu kể em thường đặt dấu gì?','dấu chấm','dấu phẩy','dấu hai chấm'],
  [3,'Viết một câu nói về cô giáo của em.','Ví dụ: Cô giáo em rất hiền.'],
  [3,'Viết một câu nói về con vật em yêu thích.','Ví dụ: Em rất thích con mèo nhà em.'],
 ]},
 {cd:'Đọc hiểu',q:[
  [1,'"Mẹ mua cho bé một chiếc cặp mới." Mẹ mua cho bé cái gì?','chiếc cặp mới','quyển vở','đôi giày','cái bút'],
  [2,'"Gà mẹ dẫn đàn con đi kiếm mồi." Ai dẫn đàn con đi kiếm mồi?','gà mẹ','vịt mẹ','mèo mẹ','chó mẹ'],
  [2,'"Sáng sớm, ông mặt trời đỏ rực." Câu này tả cảnh vào lúc nào?','sáng sớm','buổi trưa','buổi chiều','ban đêm'],
  [3,'Em sẽ làm gì để giúp đỡ bố mẹ ở nhà?','Ví dụ: quét nhà, tưới cây, xếp dép gọn gàng…'],
 ]}],
2:[
 {cd:'Chính tả',q:[
  [1,'Từ nào viết đúng chính tả?','sạch sẽ','xạch sẽ','sạch xẽ','xạch xẽ'],
  [1,'Điền l hay n: …o lắng','l','n'],
  [2,'Điền tr hay ch: cây …e','tr','ch'],
  [2,'Điền r, d hay gi: …a đình','gi','d','r'],
  [2,'Từ nào viết sai chính tả?','chuyện chò','trò chuyện','câu chuyện','trò chơi'],
 ]},
 {cd:'Từ chỉ sự vật, hoạt động, đặc điểm',q:[
  [1,'Từ nào là từ chỉ hoạt động?','chạy','cao','bàn ghế','xanh'],
  [1,'Từ nào là từ chỉ đặc điểm?','chăm chỉ','học bài','cái thước','con chim'],
  [1,'Từ nào là từ chỉ sự vật?','ngôi nhà','nhảy dây','đỏ tươi','vui vẻ'],
  [2,'Tìm 3 từ chỉ đặc điểm của bông hoa.','Ví dụ: thơm, đẹp, tươi, rực rỡ…'],
  [2,'Từ nào cùng nghĩa với "siêng năng"?','chăm chỉ','lười biếng','nhanh nhẹn','hiền lành'],
  [2,'Từ nào trái nghĩa với "cao"?','thấp','dài','to','béo'],
 ]},
 {cd:'Câu và dấu câu',q:[
  [1,'Câu "Em là học sinh lớp 2." thuộc kiểu câu nào?','Câu giới thiệu (Ai là gì?)','Câu nêu hoạt động','Câu nêu đặc điểm'],
  [2,'Câu "Bạn Lan đang tưới cây." là câu nêu gì?','nêu hoạt động','nêu đặc điểm','giới thiệu'],
  [2,'Dấu câu nào phù hợp: "Bạn tên là gì…"','dấu chấm hỏi','dấu chấm','dấu chấm than','dấu phẩy'],
  [2,'Đặt dấu phẩy đúng chỗ: "Em mua bút thước vở."','Em mua bút, thước, vở.'],
  [3,'Đặt một câu nêu đặc điểm của chiếc cặp sách.','Ví dụ: Chiếc cặp của em màu xanh, rất bền.'],
 ]},
 {cd:'Viết đoạn',q:[
  [3,'Viết 3–4 câu kể về một việc em đã làm ở nhà.','Nêu được việc gì, làm thế nào, cảm nghĩ; câu đúng ngữ pháp, có dấu câu.'],
  [3,'Viết 3–4 câu giới thiệu về một đồ chơi em thích.','Nêu tên đồ chơi, hình dáng, màu sắc, cách chơi, tình cảm của em.'],
  [3,'Viết 3–4 câu tả con vật nuôi trong nhà em.','Nêu tên con vật, đặc điểm nổi bật, hoạt động, tình cảm của em.'],
 ]}],
3:[
 {cd:'Từ chỉ sự vật, hoạt động, đặc điểm',q:[
  [1,'Từ nào chỉ hoạt động?','đọc sách','thông minh','quyển truyện','xanh mướt'],
  [1,'Từ nào chỉ đặc điểm?','vàng óng','múa hát','mặt trời','dòng sông'],
  [2,'Tìm từ trái nghĩa với "chăm chỉ".','lười biếng'],
  [2,'Từ nào cùng nghĩa với "to lớn"?','khổng lồ','bé nhỏ','tí hon','xinh xắn'],
  [2,'Nhóm từ nào gồm toàn từ chỉ hoạt động?','chạy, nhảy, hát','cao, thấp, gầy','bàn, ghế, tủ','đẹp, xấu, hiền'],
 ]},
 {cd:'Biện pháp so sánh',q:[
  [1,'Câu nào có hình ảnh so sánh?','Trăng tròn như quả bóng.','Trăng rất sáng.','Em ngắm trăng.','Trăng lên cao.'],
  [2,'Trong câu "Mắt bé tròn như hạt nhãn.", sự vật nào được so sánh với nhau?','mắt bé – hạt nhãn','bé – hạt nhãn','mắt – tròn','tròn – hạt nhãn'],
  [2,'Từ nào thường dùng để so sánh?','như','và','nhưng','rất'],
  [3,'Đặt một câu có hình ảnh so sánh để tả ông mặt trời.','Ví dụ: Ông mặt trời đỏ rực như một quả cầu lửa.'],
 ]},
 {cd:'Câu và dấu câu',q:[
  [1,'Câu "Ôi, bông hoa đẹp quá!" là câu gì?','câu cảm','câu kể','câu hỏi','câu khiến'],
  [1,'Câu "Bạn hãy đóng cửa lại." là câu gì?','câu khiến','câu kể','câu hỏi','câu cảm'],
  [2,'Dấu hai chấm trong câu "Mẹ mua nhiều thứ: rau, thịt, cá." dùng để làm gì?','báo hiệu phần liệt kê','kết thúc câu','ngăn cách hai vế','báo hiệu lời nói'],
  [2,'Chuyển câu kể "Lan học bài." thành câu hỏi.','Lan có học bài không? / Lan đang làm gì?'],
  [3,'Viết một câu khiến để nhắc bạn giữ trật tự.','Ví dụ: Bạn hãy giữ trật tự trong giờ học nhé!'],
 ]},
 {cd:'Đọc hiểu',q:[
  [2,'"Bác nông dân dậy từ sớm, ra đồng cày cấy." Từ nào chỉ hoạt động của bác nông dân?','cày cấy','nông dân','sớm','đồng'],
  [2,'"Cánh đồng lúa chín vàng như một tấm thảm khổng lồ." Cánh đồng được so sánh với gì?','tấm thảm khổng lồ','lúa chín','màu vàng','bầu trời'],
  [3,'Em học được điều gì từ câu chuyện "Có công mài sắt, có ngày nên kim"?','Kiên trì, nhẫn nại thì làm việc gì cũng thành công.'],
 ]},
 {cd:'Viết đoạn văn',q:[
  [3,'Viết đoạn văn (5–7 câu) kể về một người hàng xóm mà em quý mến.','Giới thiệu người đó; đặc điểm hình dáng, tính tình; việc làm đáng nhớ; tình cảm của em.'],
  [3,'Viết đoạn văn (5–7 câu) tả một đồ vật em yêu thích.','Giới thiệu đồ vật; tả đặc điểm nổi bật; công dụng; cách giữ gìn; tình cảm của em.'],
  [3,'Viết đoạn văn (5–7 câu) nêu tình cảm của em với thầy cô giáo.','Giới thiệu thầy cô; việc làm, kỉ niệm; tình cảm, mong muốn của em.'],
 ]}],
4:[
 {cd:'Danh từ, động từ, tính từ',q:[
  [1,'Từ nào là danh từ?','học sinh','chạy nhảy','xinh đẹp','vui vẻ'],
  [1,'Từ nào là động từ?','suy nghĩ','bàn tay','thông minh','cánh đồng'],
  [1,'Từ nào là tính từ?','chăm chỉ','đọc sách','quyển vở','trường học'],
  [2,'Tìm danh từ riêng trong câu: "Em sống ở Hải Phòng."','Hải Phòng'],
  [2,'Danh từ riêng phải viết như thế nào?','Viết hoa chữ cái đầu của mỗi tiếng','Viết thường toàn bộ','Chỉ viết hoa chữ đầu câu','Viết hoa tất cả các chữ'],
  [2,'Nhóm từ nào gồm toàn tính từ?','xanh, cao, ngoan','ăn, ngủ, chơi','bút, vở, sách','mưa, gió, nắng'],
  [3,'Đặt một câu có sử dụng một động từ và một tính từ. Gạch chân các từ đó.','Ví dụ: Bạn Mai chạy rất nhanh. (chạy: động từ; nhanh: tính từ)'],
 ]},
 {cd:'Biện pháp nhân hóa',q:[
  [1,'Câu nào có sử dụng biện pháp nhân hóa?','Chị gió đang hát ru cây lá.','Gió thổi mạnh.','Trời có gió.','Cây lá rung rinh.'],
  [2,'Trong câu "Bác chim sẻ chăm chỉ làm tổ.", sự vật nào được nhân hóa?','chim sẻ','cái tổ','bác','làm tổ'],
  [3,'Viết một câu có dùng biện pháp nhân hóa để tả cây bàng sân trường.','Ví dụ: Cây bàng dang rộng cánh tay che mát cho chúng em.'],
 ]},
 {cd:'Câu: chủ ngữ, vị ngữ, trạng ngữ',q:[
  [1,'Chủ ngữ trong câu "Đàn chim bay về tổ." là gì?','Đàn chim','bay về tổ','về tổ','chim'],
  [2,'Vị ngữ trong câu "Bạn Hoa rất chăm học." là gì?','rất chăm học','Bạn Hoa','chăm học','rất'],
  [2,'Trạng ngữ trong câu "Sáng nay, lớp em đi tham quan." là gì?','Sáng nay','lớp em','đi tham quan','tham quan'],
  [2,'Trạng ngữ "Vì trời mưa" trong câu "Vì trời mưa, đường rất trơn." chỉ gì?','nguyên nhân','thời gian','nơi chốn','mục đích'],
  [3,'Thêm trạng ngữ chỉ thời gian cho câu: "Em giúp mẹ quét nhà."','Ví dụ: Chiều nay, em giúp mẹ quét nhà.'],
 ]},
 {cd:'Đọc hiểu',q:[
  [2,'"Những bông hoa phượng đỏ rực báo hiệu mùa hè đã đến." Hoa phượng báo hiệu điều gì?','mùa hè đã đến','mùa thu đến','năm học mới','trời sắp mưa'],
  [2,'"Ông em tuy đã già nhưng vẫn ngày ngày chăm sóc vườn cây." Câu văn cho thấy ông em là người thế nào?','chăm chỉ, yêu lao động','khó tính','vui tính','ít nói'],
  [3,'Theo em, vì sao chúng ta cần biết ơn những người lao động?','Vì họ làm ra của cải, phục vụ cuộc sống của mọi người; HS nêu ý kiến hợp lí.'],
 ]},
 {cd:'Viết bài văn',q:[
  [3,'Viết bài văn tả một cây bóng mát ở trường em.','Mở bài giới thiệu cây; thân bài tả bao quát, tả từng bộ phận, lợi ích; kết bài nêu tình cảm.'],
  [3,'Viết bài văn tả con vật mà em yêu thích.','Mở bài giới thiệu; thân bài tả hình dáng, hoạt động, thói quen; kết bài nêu tình cảm, cách chăm sóc.'],
  [3,'Viết đoạn văn nêu ý kiến về một câu chuyện em đã đọc.','Nêu tên câu chuyện; ý kiến của em và lí do; dẫn chứng từ câu chuyện.'],
 ]}],
5:[
 {cd:'Từ đồng nghĩa, từ đa nghĩa',q:[
  [1,'Từ nào đồng nghĩa với "Tổ quốc"?','đất nước','quê hương nhỏ','làng xóm','gia đình'],
  [1,'Từ nào đồng nghĩa với "xinh đẹp"?','xinh xắn','xấu xí','to lớn','chăm chỉ'],
  [2,'Trong câu "Bạn Nam đứng ở chân cầu thang.", từ "chân" được dùng với nghĩa nào?','nghĩa chuyển','nghĩa gốc'],
  [2,'Từ "ăn" trong câu nào mang nghĩa gốc?','Em ăn cơm.','Xe ăn xăng.','Da ăn nắng.','Tàu ăn hàng.'],
  [3,'Đặt hai câu để phân biệt nghĩa gốc và nghĩa chuyển của từ "mắt".','Ví dụ: Mắt em bé rất sáng. (gốc) / Quả na đã mở mắt. (chuyển)'],
 ]},
 {cd:'Đại từ, kết từ',q:[
  [1,'Từ nào là đại từ?','tôi','và','nhưng','của'],
  [1,'Từ nào là kết từ?','nhưng','bàn','đẹp','chúng tôi'],
  [2,'Cặp kết từ nào phù hợp: "… trời mưa … chúng em vẫn đi học đúng giờ."','Tuy … nhưng','Vì … nên','Nếu … thì','Không những … mà'],
  [2,'Đại từ "nó" trong câu "Con mèo nhà em rất ngoan, nó hay nằm sưởi nắng." thay cho từ nào?','con mèo','em','nắng','nhà em'],
  [3,'Đặt một câu ghép có dùng cặp kết từ "Vì … nên …".','Ví dụ: Vì em chăm học nên em đạt kết quả tốt.'],
 ]},
 {cd:'Câu ghép và liên kết câu',q:[
  [1,'Câu nào là câu ghép?','Trời mưa to, đường ngập nước.','Em đi học.','Hôm nay trời đẹp.','Bạn Lan hát hay.'],
  [2,'Hai vế của câu ghép "Mẹ nấu cơm, chị quét nhà." được nối bằng cách nào?','bằng dấu phẩy','bằng kết từ "và"','bằng cặp từ hô ứng','bằng dấu chấm'],
  [2,'Trong đoạn "Lan rất chăm học. Bạn ấy luôn làm bài đầy đủ.", từ "Bạn ấy" dùng để làm gì?','liên kết câu bằng cách thay thế từ ngữ','liên kết bằng cách lặp từ','nối hai vế câu ghép','chỉ thời gian'],
  [3,'Viết 2 câu có liên kết với nhau bằng cách lặp từ ngữ.','Ví dụ: Quê em có dòng sông. Dòng sông quanh năm xanh mát.'],
 ]},
 {cd:'Đọc hiểu',q:[
  [2,'"Cả làng chung tay dọn dẹp con đường sau trận lũ." Câu văn nói lên điều gì?','tinh thần đoàn kết của người dân','trận lũ rất to','con đường rất dài','người dân rất buồn'],
  [2,'Câu tục ngữ "Uống nước nhớ nguồn" khuyên chúng ta điều gì?','biết ơn những người đi trước','uống nước sạch','bảo vệ nguồn nước','tiết kiệm nước'],
  [3,'Em hãy nêu 2 việc làm thể hiện lòng biết ơn thầy cô giáo.','Ví dụ: chăm học, lễ phép, thăm hỏi thầy cô nhân ngày 20/11…'],
 ]},
 {cd:'Viết bài văn',q:[
  [3,'Viết bài văn tả một người thân trong gia đình em.','Mở bài giới thiệu; thân bài tả ngoại hình, tính tình, hoạt động, kỉ niệm; kết bài nêu tình cảm.'],
  [3,'Viết bài văn tả cảnh quê hương em vào một buổi sáng.','Mở bài giới thiệu cảnh; thân bài tả theo trình tự thời gian/không gian, dùng so sánh, nhân hóa; kết bài nêu cảm nghĩ.'],
  [3,'Viết đoạn văn nêu ý kiến tán thành hoặc phản đối việc học sinh dùng điện thoại quá nhiều.','Nêu rõ ý kiến; 2–3 lí do, dẫn chứng; lời khuyên, kết luận.'],
 ]}]
};

/* ======================= TOÁN (bổ sung câu không phải tính toán) ======================= */
NH['Toán']={
1:[{cd:'Hình học và đo lường',q:[
  [1,'Hình nào có 3 cạnh?','hình tam giác','hình vuông','hình tròn','hình chữ nhật'],
  [1,'Một tuần lễ có mấy ngày?','7 ngày','5 ngày','6 ngày','10 ngày'],
  [2,'Hôm nay là thứ Hai. Ngày mai là thứ mấy?','thứ Ba','Chủ nhật','thứ Tư','thứ Bảy'],
  [2,'Đồng hồ chỉ kim ngắn vào số 8, kim dài vào số 12. Đồng hồ chỉ mấy giờ?','8 giờ','12 giờ','7 giờ','9 giờ'],
  [3,'Kể tên 2 đồ vật trong lớp có dạng hình chữ nhật.','Ví dụ: bảng lớp, quyển sách, mặt bàn…'],
 ]}],
2:[{cd:'Hình học và đo lường',q:[
  [1,'1 giờ bằng bao nhiêu phút?','60 phút','100 phút','30 phút','24 phút'],
  [1,'Đơn vị nào dùng để đo khối lượng?','ki-lô-gam','mét','lít','giờ'],
  [2,'Một ngày có bao nhiêu giờ?','24 giờ','12 giờ','60 giờ','7 giờ'],
  [2,'Hình tứ giác có mấy cạnh?','4 cạnh','3 cạnh','5 cạnh','6 cạnh'],
  [3,'Bình đựng 5 l nước, rót ra 2 l. Hỏi bình còn bao nhiêu lít nước?','5 – 2 = 3 (l)'],
 ]}],
3:[{cd:'Hình học và đo lường',q:[
  [1,'Hình tròn tâm O, đoạn thẳng nối tâm O với một điểm trên đường tròn gọi là gì?','bán kính','đường kính','dây cung','cạnh'],
  [1,'Góc vuông được kiểm tra bằng dụng cụ nào?','ê ke','compa','thước dây','cân'],
  [2,'Tháng nào có 28 hoặc 29 ngày?','tháng Hai','tháng Tư','tháng Sáu','tháng Chín'],
  [2,'1 km bằng bao nhiêu mét?','1 000 m','100 m','10 m','10 000 m'],
  [3,'Đường kính hình tròn dài 8 cm. Bán kính dài bao nhiêu xăng-ti-mét?','8 : 2 = 4 (cm)'],
 ]}],
4:[
 {cd:'Hai đường thẳng vuông góc, song song',q:[
  [1,'Hai đường thẳng song song thì như thế nào?','không bao giờ cắt nhau','cắt nhau tạo 4 góc vuông','cắt nhau tại một điểm','trùng nhau'],
  [1,'Dụng cụ dùng để vẽ và kiểm tra hai đường thẳng vuông góc là gì?','ê ke','compa','thước đo độ dài','bút chì'],
  [2,'Trong hình chữ nhật ABCD, cạnh AB song song với cạnh nào?','cạnh DC','cạnh AD','cạnh BC','cạnh AC'],
  [2,'Trong hình chữ nhật ABCD, cạnh AB vuông góc với những cạnh nào?','AD và BC','DC và AD','DC và BC','chỉ cạnh DC'],
  [2,'Lúc 6 giờ đúng, kim giờ và kim phút có vuông góc với nhau không?','Không','Có'],
  [2,'Hai mép đối diện của trang vở là hai đoạn thẳng như thế nào?','song song','vuông góc','cắt nhau','trùng nhau'],
  [3,'Kể tên 2 hình ảnh trong lớp học cho ta hình ảnh hai đường thẳng vuông góc và 2 hình ảnh hai đường thẳng song song.','Vuông góc: hai mép kề nhau của bảng, của mặt bàn… Song song: hai mép đối diện của bảng, các thanh song cửa sổ…'],
  [3,'Vẽ đường thẳng AB và điểm M ở ngoài AB. Vẽ đường thẳng qua M vuông góc với AB và đường thẳng qua M song song với AB.','HS dùng ê ke và thước vẽ đúng; kiểm tra góc vuông bằng ê ke.'],
 ]},
 {cd:'Hình bình hành, hình thoi',q:[
  [1,'Hình bình hành có đặc điểm gì?','có hai cặp cạnh đối diện song song và bằng nhau','có bốn cạnh bằng nhau và bốn góc vuông','có ba cạnh','chỉ có một cặp cạnh song song'],
  [1,'Hình thoi có đặc điểm gì?','hai cặp cạnh đối diện song song và bốn cạnh bằng nhau','bốn góc đều là góc tù','chỉ có hai cạnh bằng nhau','không có cạnh nào song song'],
  [2,'Hình bình hành ABCD có AB = 8 cm. Cạnh CD dài bao nhiêu?','8 cm','4 cm','16 cm','không biết được'],
  [2,'Một hình thoi có chu vi 36 cm. Cạnh hình thoi dài bao nhiêu?','9 cm','12 cm','18 cm','6 cm'],
  [3,'Lan dùng sợi dây dài 48 cm uốn thành một hình thoi vừa hết. Tính độ dài mỗi cạnh của hình thoi.','48 : 4 = 12 (cm)'],
  [3,'Một mảnh vườn hình bình hành có chu vi 96 m, cạnh dài hơn cạnh ngắn 12 m. Tính độ dài mỗi cạnh.','Nửa chu vi 48 m; cạnh dài (48 + 12) : 2 = 30 m; cạnh ngắn 18 m.'],
 ]},
 {cd:'Hình học và đo lường',q:[
  [1,'Hai đường thẳng vuông góc tạo thành mấy góc vuông?','4 góc vuông','2 góc vuông','1 góc vuông','3 góc vuông'],
  [1,'Góc nào lớn hơn góc vuông?','góc tù','góc nhọn','góc vuông','không có góc nào'],
  [2,'1 thế kỉ bằng bao nhiêu năm?','100 năm','10 năm','1 000 năm','50 năm'],
  [2,'Hình nào có hai cặp cạnh đối diện song song và bốn cạnh bằng nhau?','hình thoi','hình bình hành','hình tam giác','hình thang'],
  [3,'Năm 2026 thuộc thế kỉ thứ mấy?','Thế kỉ XXI (thế kỉ 21)'],
 ]}],
5:[{cd:'Hình học và đo lường',q:[
  [1,'1 m² bằng bao nhiêu dm²?','100 dm²','10 dm²','1 000 dm²','10 000 dm²'],
  [1,'Hình hộp chữ nhật có mấy mặt?','6 mặt','4 mặt','8 mặt','12 mặt'],
  [2,'1 ha bằng bao nhiêu mét vuông?','10 000 m²','1 000 m²','100 m²','100 000 m²'],
  [2,'Chu vi hình tròn được tính bằng cách nào?','đường kính × 3,14','bán kính × bán kính × 3,14','đường kính × 2','bán kính × 3,14'],
  [3,'Tính chu vi hình tròn có đường kính 10 cm.','10 × 3,14 = 31,4 (cm)'],
  [3,'Một hình lập phương có cạnh 3 cm. Tính thể tích hình lập phương đó.','3 × 3 × 3 = 27 (cm³)'],
 ]}]
};

/* ======================= ĐẠO ĐỨC ======================= */
NH['Đạo đức']={
1:[
 {cd:'Tự chăm sóc bản thân',q:[
  [1,'Em nên rửa tay vào lúc nào?','trước khi ăn và sau khi đi vệ sinh','chỉ khi tay bẩn nhiều','một tuần một lần','không cần rửa'],
  [1,'Việc làm nào giúp em gọn gàng, ngăn nắp?','cất đồ dùng đúng chỗ sau khi dùng','vứt sách vở lung tung','để giày dép giữa nhà','để quần áo trên giường'],
  [2,'Em nên đánh răng mỗi ngày ít nhất mấy lần?','2 lần (sáng và tối)','1 lần một tuần','không cần đánh răng','chỉ khi đau răng'],
  [3,'Kể 2 việc em tự làm được để chăm sóc bản thân.','Ví dụ: tự đánh răng, rửa mặt, mặc quần áo, chải tóc…'],
 ]},
 {cd:'Gia đình và nhà trường',q:[
  [1,'Khi ông bà đi xa về, em nên làm gì?','chào hỏi lễ phép','không để ý','chạy đi chơi','chỉ chào khi được nhắc'],
  [2,'Bạn Nam làm vỡ cốc nhưng không ai thấy. Nam nên làm gì?','nhận lỗi với mẹ','giấu đi','đổ lỗi cho em','im lặng'],
  [2,'Tự giác học tập là gì?','tự học bài, làm bài mà không cần ai nhắc','chỉ học khi bị nhắc','chép bài của bạn','học xong mới chơi khi có người kiểm tra'],
  [3,'Em sẽ làm gì để thể hiện tình yêu thương với gia đình?','Ví dụ: vâng lời, giúp việc nhà, hỏi thăm khi người thân ốm…'],
 ]},
 {cd:'An toàn',q:[
  [1,'Việc nào có thể gây nguy hiểm cho em?','nghịch ổ cắm điện','đọc truyện','tưới cây','xếp đồ chơi'],
  [2,'Khi thấy bạn chơi gần ao hồ, em nên làm gì?','nhắc bạn tránh xa và báo người lớn','rủ bạn cùng xuống','đứng xem','bỏ đi'],
  [3,'Kể 2 việc em cần làm để phòng tránh bị bỏng.','Ví dụ: không chơi gần bếp, không chạm vào nồi nóng, phích nước…'],
 ]}],
2:[
 {cd:'Quê hương, thầy cô, bạn bè',q:[
  [1,'Việc nào thể hiện tình yêu quê hương?','giữ gìn cảnh quan sạch đẹp nơi em ở','vứt rác bừa bãi','bẻ cây xanh','vẽ bậy lên tường'],
  [1,'Khi gặp thầy cô giáo, em nên làm gì?','chào hỏi lễ phép','quay đi chỗ khác','giả vờ không thấy','gọi to tên thầy cô'],
  [2,'Bạn bị ngã trong giờ ra chơi, em nên làm gì?','đỡ bạn dậy và báo thầy cô','cười bạn','đứng xem','chạy đi chơi tiếp'],
  [3,'Em sẽ làm gì để thể hiện sự yêu quý bạn bè?','Ví dụ: giúp đỡ bạn học, chia sẻ đồ dùng, không trêu chọc bạn…'],
 ]},
 {cd:'Quý trọng thời gian, nhận lỗi',q:[
  [1,'Biểu hiện nào là quý trọng thời gian?','làm việc theo thời gian biểu','ngủ dậy muộn','xem ti vi quá lâu','để bài tập đến sát giờ mới làm'],
  [2,'Khi làm sai, em nên làm gì?','nhận lỗi và sửa lỗi','đổ lỗi cho người khác','giấu lỗi','khóc thật to'],
  [2,'Bảo quản đồ dùng cá nhân là việc làm như thế nào?','giữ gìn, sử dụng cẩn thận và cất đúng nơi','vẽ bậy lên sách vở','cho bạn mượn rồi quên','vứt bỏ khi còn dùng được'],
  [3,'Lập thời gian biểu buổi tối của em (từ 18 giờ đến 21 giờ).','HS nêu hợp lí các việc: ăn tối, học bài, chuẩn bị sách vở, vệ sinh cá nhân, đi ngủ đúng giờ.'],
 ]},
 {cd:'Cảm xúc và nơi công cộng',q:[
  [1,'Hành vi nào đúng khi ở nơi công cộng?','xếp hàng, giữ trật tự','nói to, chạy nhảy','chen lấn','vứt rác xuống đất'],
  [2,'Khi buồn hoặc lo lắng, em có thể làm gì?','chia sẻ với bố mẹ, thầy cô','đập phá đồ đạc','la hét với bạn','giữ kín mãi không nói'],
  [2,'Khi bị lạc ở nơi đông người, em nên làm gì?','đứng yên và nhờ chú bảo vệ, công an giúp đỡ','đi theo người lạ','chạy lung tung','ngồi khóc một chỗ'],
  [3,'Nêu 2 việc em nên làm khi đi xe buýt hoặc ở công viên.','Ví dụ: xếp hàng, nhường chỗ người già, không xả rác, nói nhỏ…'],
 ]}],
3:[
 {cd:'Tổ quốc, hàng xóm',q:[
  [1,'Quốc kì Việt Nam có hình gì?','nền đỏ, ngôi sao vàng năm cánh ở giữa','nền xanh, ngôi sao trắng','nền vàng, sao đỏ','nền đỏ, hai ngôi sao vàng'],
  [1,'Quốc ca Việt Nam là bài hát nào?','Tiến quân ca','Như có Bác Hồ trong ngày vui đại thắng','Kết đoàn','Mùa xuân trên thành phố Hồ Chí Minh'],
  [2,'Khi chào cờ, em cần có thái độ như thế nào?','đứng nghiêm, mắt hướng về Quốc kì','nói chuyện riêng','quay ngang quay ngửa','ngồi xuống'],
  [2,'Nhà bác hàng xóm có người ốm, em nên làm gì?','hỏi thăm và giúp đỡ việc vừa sức','nô đùa ồn ào','không quan tâm','bật nhạc to'],
  [3,'Nêu 2 việc em làm để thể hiện sự quan tâm hàng xóm.','Ví dụ: chào hỏi, giữ yên lặng giờ nghỉ trưa, giúp trông em bé, chia sẻ quà…'],
 ]},
 {cd:'Ham học hỏi, giữ lời hứa',q:[
  [1,'Biểu hiện nào là ham học hỏi?','hỏi thầy cô khi chưa hiểu bài','không chú ý nghe giảng','chép bài của bạn','ngại phát biểu'],
  [2,'Em đã hứa cho bạn mượn truyện nhưng quên mang. Em nên làm gì?','xin lỗi bạn và hẹn mang vào hôm sau','im lặng','nói dối là bị mất','trách bạn'],
  [2,'Vì sao cần giữ lời hứa?','để mọi người tin tưởng và quý trọng mình','để được khen thưởng','để bạn sợ mình','không cần giữ lời hứa'],
  [3,'Kể một lần em đã giữ đúng lời hứa và cảm xúc của em khi đó.','HS kể việc cụ thể; nêu cảm xúc vui, tự hào; thể hiện ý thức giữ chữ tín.'],
 ]},
 {cd:'An toàn giao thông, xử lí bất hòa',q:[
  [1,'Đèn tín hiệu giao thông màu đỏ có nghĩa là gì?','dừng lại','đi tiếp','đi chậm lại','rẽ phải'],
  [1,'Khi ngồi sau xe máy, em phải làm gì?','đội mũ bảo hiểm và ngồi ngay ngắn','đứng lên yên xe','đùa nghịch','không cần đội mũ'],
  [2,'Khi bất hòa với bạn, em nên làm gì?','bình tĩnh nói chuyện, cùng tìm cách giải quyết','đánh nhau','nói xấu bạn','giận bạn mãi'],
  [3,'Trên đường đi học, em thấy bạn đi xe đạp dàn hàng ba. Em sẽ khuyên bạn thế nào?','Khuyên bạn đi hàng một, sát lề đường bên phải để an toàn.'],
 ]}],
4:[
 {cd:'Biết ơn người lao động',q:[
  [1,'Việc làm nào thể hiện lòng biết ơn người lao động?','giữ gìn sản phẩm lao động, không lãng phí','vứt bỏ cơm thừa','bẻ cây ở công viên','vẽ bậy lên tường'],
  [2,'Khi thấy cô lao công đang quét đường, em nên làm gì?','chào cô và không xả rác','đi qua không để ý','vứt rác ngay chỗ vừa quét','trêu chọc cô'],
  [3,'Viết 2–3 câu bày tỏ lòng biết ơn với một người lao động em biết.','HS nêu tên nghề, công việc, lời cảm ơn chân thành.'],
 ]},
 {cd:'Cảm thông, giúp đỡ người gặp khó khăn',q:[
  [1,'Việc làm nào thể hiện sự cảm thông, giúp đỡ người gặp khó khăn?','quyên góp sách vở cho bạn vùng lũ','chê bai bạn nghèo','không quan tâm','trêu chọc người khuyết tật'],
  [2,'Bạn trong lớp bị ốm phải nghỉ học nhiều ngày. Em có thể giúp bạn bằng cách nào?','chép bài, giảng lại bài cho bạn','không liên lạc với bạn','kể với cả lớp để chê bạn','mượn bạn đồ dùng'],
  [3,'Lập kế hoạch một việc làm nhỏ giúp đỡ người gặp khó khăn ở nơi em sống.','HS nêu việc làm, thời gian, cách thực hiện, người cùng tham gia.'],
 ]},
 {cd:'Yêu lao động, tôn trọng tài sản',q:[
  [1,'Biểu hiện nào là yêu lao động?','tích cực tham gia công việc vừa sức ở nhà, ở trường','trốn trực nhật','làm qua loa','nhờ bạn làm hộ'],
  [2,'Nhặt được ví tiền của người khác, em nên làm gì?','tìm cách trả lại người mất hoặc nhờ người lớn, công an giúp','giữ lại tiêu','vứt đi','chia cho bạn'],
  [2,'Việc làm nào là bảo vệ của công?','không viết, vẽ lên bàn ghế, tường lớp','bẻ cành cây ở sân trường','giẫm lên bồn hoa','làm hỏng vòi nước'],
  [3,'Em thấy một bạn dùng bút vẽ lên bàn học. Em sẽ làm gì?','Nhắc nhở nhẹ nhàng, khuyên bạn lau sạch và giữ gìn tài sản chung.'],
 ]},
 {cd:'Quyền và bổn phận trẻ em',q:[
  [1,'Trẻ em có quyền nào sau đây?','được học tập','phải đi làm kiếm tiền','không được vui chơi','không được bày tỏ ý kiến'],
  [2,'Bổn phận của trẻ em đối với gia đình là gì?','kính trọng, lễ phép, giúp đỡ ông bà, cha mẹ','đòi hỏi mọi thứ','không cần nghe lời','chỉ lo chơi'],
  [3,'Nêu 2 quyền và 2 bổn phận của trẻ em mà em biết.','Quyền: được học tập, vui chơi, chăm sóc sức khỏe… Bổn phận: học tập chăm chỉ, kính trọng ông bà cha mẹ, giữ gìn vệ sinh…'],
 ]}],
5:[
 {cd:'Biết ơn người có công',q:[
  [1,'Ngày 27 tháng 7 hằng năm là ngày gì?','Ngày Thương binh – Liệt sĩ','Ngày Nhà giáo Việt Nam','Ngày Quốc khánh','Ngày Quốc tế Thiếu nhi'],
  [2,'Việc làm nào thể hiện lòng biết ơn người có công với quê hương, đất nước?','thăm hỏi gia đình thương binh, liệt sĩ','vẽ bậy lên bia tưởng niệm','không quan tâm','chạy nhảy ở nghĩa trang liệt sĩ'],
  [3,'Kể tên một người có công với quê hương em và việc em có thể làm để tỏ lòng biết ơn.','HS nêu tên/sự kiện ở địa phương; việc làm phù hợp: dâng hương, chăm sóc đài tưởng niệm, tìm hiểu…'],
 ]},
 {cd:'Tôn trọng sự khác biệt, bảo vệ cái đúng',q:[
  [1,'Tôn trọng sự khác biệt là gì?','chấp nhận và không chê bai người khác về ngoại hình, sở thích, hoàn cảnh','chê bạn khác mình','chỉ chơi với bạn giống mình','bắt bạn phải giống mình'],
  [2,'Thấy bạn bị nói xấu trên mạng, em nên làm gì?','không chia sẻ tiếp và báo thầy cô, bố mẹ','chia sẻ thêm','bình luận chê bạn','im lặng xem tiếp'],
  [3,'Nêu một tình huống em đã dũng cảm bảo vệ điều đúng.','HS kể tình huống cụ thể, cách xử lí phù hợp, kết quả.'],
 ]},
 {cd:'Bảo vệ môi trường, kế hoạch cá nhân',q:[
  [1,'Việc làm nào góp phần bảo vệ môi trường?','phân loại rác và hạn chế dùng túi ni lông','đốt rác thải nhựa','xả rác xuống sông','chặt phá cây xanh'],
  [2,'Lập kế hoạch cá nhân giúp em điều gì?','sắp xếp công việc hợp lí, hoàn thành mục tiêu','làm việc tùy hứng','có nhiều thời gian chơi game','không cần học'],
  [3,'Lập kế hoạch tuần tiết kiệm tiền để mua một quyển sách.','HS nêu mục tiêu, số tiền, cách tiết kiệm mỗi ngày, thời gian hoàn thành.'],
 ]},
 {cd:'Phòng tránh xâm hại, sử dụng tiền hợp lí',q:[
  [1,'Khi có người lạ rủ đi chơi và cho quà, em nên làm gì?','từ chối và báo ngay cho bố mẹ, thầy cô','đi theo','nhận quà rồi đi','giữ bí mật'],
  [2,'Khi có người chạm vào vùng riêng tư trên cơ thể khiến em sợ hãi, em cần làm gì?','nói "Không", tránh xa và kể ngay với người lớn tin cậy','giữ bí mật','im lặng chịu đựng','tự xử lí một mình'],
  [2,'Sử dụng tiền hợp lí là như thế nào?','chi tiêu cho những thứ cần thiết và biết tiết kiệm','mua mọi thứ mình thích','tiêu hết tiền ngay','vay tiền bạn để mua đồ chơi'],
  [3,'Kể tên 3 người em tin cậy có thể nhờ giúp đỡ khi gặp nguy hiểm.','Ví dụ: bố mẹ, ông bà, thầy cô giáo, công an…; gọi 111 – Tổng đài quốc gia bảo vệ trẻ em.'],
 ]}]
};

/* ======================= TỰ NHIÊN VÀ XÃ HỘI (lớp 1–3) ======================= */
NH['Tự nhiên và Xã hội']={
1:[
 {cd:'Gia đình và trường học',q:[
  [1,'Phòng nào trong nhà thường dùng để nấu ăn?','phòng bếp','phòng ngủ','phòng khách','phòng tắm'],
  [1,'Ai là người dạy em học ở trường?','thầy cô giáo','bác sĩ','chú công an','bác nông dân'],
  [2,'Để giữ an toàn khi ở nhà, em không nên làm gì?','chơi với dao, kéo sắc','xếp gọn đồ chơi','ngồi học ngay ngắn','tưới cây'],
  [3,'Kể tên các thành viên trong gia đình em.','HS kể đúng các thành viên: ông, bà, bố, mẹ, anh, chị, em…'],
 ]},
 {cd:'Thực vật và động vật',q:[
  [1,'Bộ phận nào của cây hút nước từ đất?','rễ','lá','hoa','quả'],
  [1,'Con vật nào sống dưới nước?','con cá','con gà','con mèo','con chim'],
  [2,'Cây cần gì để sống?','nước, ánh sáng, không khí','chỉ cần đất','chỉ cần bóng tối','không cần gì'],
  [3,'Kể tên 2 con vật có ích và lợi ích của chúng.','Ví dụ: con gà cho trứng, thịt; con mèo bắt chuột…'],
 ]},
 {cd:'Con người và sức khỏe',q:[
  [1,'Em dùng bộ phận nào để nhìn?','mắt','tai','mũi','lưỡi'],
  [1,'Em dùng bộ phận nào để nghe?','tai','mắt','tay','chân'],
  [2,'Để bảo vệ mắt, em nên làm gì?','ngồi học đủ ánh sáng, không xem ti vi quá gần','dụi mắt bằng tay bẩn','đọc sách nơi tối','nhìn thẳng vào mặt trời'],
  [3,'Kể 2 việc em làm hằng ngày để giữ vệ sinh cơ thể.','Ví dụ: tắm rửa, đánh răng, rửa tay, cắt móng tay…'],
 ]},
 {cd:'Trái Đất và bầu trời',q:[
  [1,'Ban ngày, trên bầu trời ta thường thấy gì?','Mặt Trời','nhiều ngôi sao','Mặt Trăng tròn sáng','không thấy gì'],
  [2,'Khi trời nắng to, em cần làm gì khi ra ngoài?','đội mũ nón','không cần đội mũ','đi chân đất','mặc áo mỏng không mũ'],
  [3,'Khi trời có giông, sét, em nên làm gì?','Vào nhà, tránh đứng dưới gốc cây to, không ra đồng trống.'],
 ]}],
2:[
 {cd:'Gia đình và trường học',q:[
  [1,'Họ hàng bên nội là họ hàng của ai?','bên bố','bên mẹ','hàng xóm','bạn bè'],
  [2,'Việc làm nào giúp phòng tránh ngộ độc khi ở nhà?','ăn thức ăn sạch, còn hạn sử dụng','ăn thức ăn ôi thiu','uống thuốc tùy ý','ăn quả chưa rửa'],
  [2,'Hoạt động nào là hoạt động ở trường?','chào cờ, học tập, vui chơi giờ ra chơi','nấu cơm','đi chợ','ngủ trưa ở nhà'],
  [3,'Nêu 2 việc em làm để giữ vệ sinh trường lớp.','Ví dụ: trực nhật, bỏ rác vào thùng, không vẽ bậy lên tường…'],
 ]},
 {cd:'Cộng đồng địa phương',q:[
  [1,'Người làm nghề gì chữa bệnh cho mọi người?','bác sĩ','thợ may','đầu bếp','thợ xây'],
  [2,'Khi đi bộ trên đường phố, em phải đi ở đâu?','trên vỉa hè hoặc sát lề đường bên phải','giữa lòng đường','dưới lòng đường bên trái','nơi nào cũng được'],
  [3,'Kể tên một nghề ở nơi em sống và lợi ích của nghề đó.','HS kể nghề và lợi ích phù hợp.'],
 ]},
 {cd:'Thực vật và động vật',q:[
  [1,'Cây nào sống dưới nước?','cây sen','cây xoài','cây bàng','cây xương rồng'],
  [1,'Con vật nào sống trên cạn?','con hổ','con cá','con tôm','con mực'],
  [2,'Vì sao cần bảo vệ môi trường sống của thực vật và động vật?','vì đó là nơi chúng sống, kiếm ăn và sinh sản','vì để chúng biến mất','vì không có lí do','vì để săn bắt'],
  [3,'Nêu 2 việc em làm để bảo vệ cây xanh.','Ví dụ: tưới cây, không bẻ cành, không hái hoa nơi công cộng…'],
 ]},
 {cd:'Con người và sức khỏe',q:[
  [1,'Cơ quan nào giúp chúng ta thở?','cơ quan hô hấp','cơ quan vận động','cơ quan bài tiết nước tiểu','cơ quan tiêu hóa'],
  [2,'Để bảo vệ cơ quan hô hấp, em nên làm gì?','đeo khẩu trang nơi bụi bẩn, tập thể dục','chơi nơi khói bụi','hít khói thuốc lá','ngủ trong phòng kín khói'],
  [2,'Ăn uống như thế nào là hợp lí?','ăn đủ chất, uống đủ nước, ăn đúng bữa','chỉ ăn bánh kẹo','bỏ bữa sáng','ăn thật nhiều đồ chiên rán'],
  [3,'Nêu 2 việc em làm để có xương chắc khỏe.','Ví dụ: ngồi học đúng tư thế, tập thể dục, uống sữa, ăn đủ chất…'],
 ]},
 {cd:'Trái Đất và bầu trời',q:[
  [1,'Phương nào là phương Mặt Trời mọc?','phương Đông','phương Tây','phương Nam','phương Bắc'],
  [2,'Hiện tượng thiên tai nào hay xảy ra ở nước ta?','bão, lũ lụt','động đất rất mạnh thường xuyên','núi lửa phun hằng năm','tuyết rơi khắp nơi'],
  [3,'Khi có bão, gia đình em cần chuẩn bị những gì?','Ví dụ: chằng chống nhà cửa, dự trữ nước, thức ăn, đèn pin; nghe thông tin dự báo.'],
 ]}],
3:[
 {cd:'Gia đình và trường học',q:[
  [1,'Hỏa hoạn ở nhà có thể xảy ra do đâu?','để vật dễ cháy gần lửa, chập điện','tưới cây','đọc sách','ăn cơm'],
  [2,'Khi có cháy, em cần gọi số điện thoại nào?','114','113','115','111'],
  [2,'Số điện thoại gọi cấp cứu y tế là số nào?','115','114','113','116'],
  [3,'Nêu cách thoát hiểm khi có cháy trong nhà.','Bình tĩnh, kêu cứu, che mũi miệng bằng khăn ướt, cúi thấp người, thoát theo lối an toàn, gọi 114.'],
 ]},
 {cd:'Cộng đồng địa phương',q:[
  [1,'Hoạt động sản xuất nông nghiệp gồm những gì?','trồng trọt, chăn nuôi','dệt may, cơ khí','bán hàng','vận tải'],
  [2,'Hoạt động nào là sản xuất công nghiệp?','sản xuất xi măng, may mặc','trồng lúa','nuôi gà','đánh bắt cá'],
  [3,'Kể tên một sản phẩm nổi tiếng ở địa phương em.','HS nêu sản phẩm phù hợp với địa phương.'],
 ]},
 {cd:'Thực vật và động vật',q:[
  [1,'Bộ phận nào của cây làm nhiệm vụ quang hợp (chế tạo chất dinh dưỡng)?','lá','rễ','thân','hoa'],
  [1,'Động vật nào có xương sống?','con cá','con giun','con ốc sên','con tôm'],
  [2,'Thân cây có chức năng gì?','vận chuyển nước, chất dinh dưỡng và nâng đỡ cây','hút nước từ đất','tạo ra hạt','chỉ để làm đẹp'],
  [2,'Con vật nào thuộc nhóm động vật có vú?','con mèo','con gà','con cá chép','con ếch'],
  [3,'Nêu 2 lợi ích của thực vật đối với con người.','Ví dụ: cho thức ăn, gỗ, thuốc chữa bệnh; tạo bóng mát, làm sạch không khí…'],
 ]},
 {cd:'Con người và sức khỏe',q:[
  [1,'Cơ quan nào giúp tiêu hóa thức ăn?','cơ quan tiêu hóa','cơ quan hô hấp','cơ quan tuần hoàn','cơ quan thần kinh'],
  [1,'Tim thuộc cơ quan nào?','cơ quan tuần hoàn','cơ quan tiêu hóa','cơ quan hô hấp','cơ quan thần kinh'],
  [2,'Để bảo vệ cơ quan thần kinh, em nên làm gì?','ngủ đủ giấc, học tập vui chơi hợp lí','thức khuya chơi game','lo lắng thường xuyên','dùng chất kích thích'],
  [3,'Nêu 3 việc làm giúp bảo vệ cơ quan tiêu hóa.','Ví dụ: ăn chín uống sôi, rửa tay trước khi ăn, ăn chậm nhai kĩ, không ăn quá no…'],
 ]},
 {cd:'Trái Đất và bầu trời',q:[
  [1,'Trái Đất có hình gì?','hình cầu','hình vuông','hình tam giác','hình phẳng'],
  [1,'Trên Trái Đất có mấy đới khí hậu?','5 đới khí hậu','2 đới khí hậu','3 đới khí hậu','7 đới khí hậu'],
  [2,'Trái Đất tự quay quanh mình nó sinh ra hiện tượng gì?','ngày và đêm','các mùa trong năm','mưa và nắng','động đất'],
  [2,'Mặt Trăng là gì của Trái Đất?','vệ tinh tự nhiên','hành tinh','ngôi sao','thiên thạch'],
  [3,'Vì sao có ngày và đêm trên Trái Đất?','Vì Trái Đất hình cầu và tự quay quanh mình nên có nửa được Mặt Trời chiếu sáng (ngày), nửa kia không được chiếu sáng (đêm).'],
 ]}]
};

/* ======================= KHOA HỌC (lớp 4–5) ======================= */
NH['Khoa học']={
4:[
 {cd:'Chất: nước và không khí',q:[
  [1,'Nước tồn tại ở những thể nào?','rắn, lỏng, khí','chỉ thể lỏng','lỏng và khí','rắn và lỏng'],
  [1,'Thành phần chính của không khí gồm những khí nào?','khí ni-tơ và khí ô-xi','khí các-bô-níc và hơi nước','chỉ có khí ô-xi','khí hi-đrô'],
  [2,'Hiện tượng nước biến thành hơi nước gọi là gì?','sự bay hơi','sự đông đặc','sự ngưng tụ','sự nóng chảy'],
  [2,'Vì sao phải đun sôi nước trước khi uống?','để diệt vi khuẩn gây bệnh','để nước có màu','để nước ngọt hơn','để nước nhiều hơn'],
  [2,'Không khí có tính chất nào?','không màu, không mùi, không vị','có màu xanh','có mùi thơm','có vị mặn'],
  [3,'Nêu 3 việc làm để bảo vệ nguồn nước.','Ví dụ: không xả rác xuống ao hồ, xử lí nước thải, tiết kiệm nước…'],
  [3,'Vì sao khi úp cốc lên ngọn nến đang cháy, nến sẽ tắt sau một lúc?','Vì khi hết khí ô-xi trong cốc thì nến không cháy được nữa.'],
 ]},
 {cd:'Năng lượng: ánh sáng, âm thanh, nhiệt',q:[
  [1,'Vật nào tự phát ra ánh sáng?','Mặt Trời','Mặt Trăng','cái gương','tờ giấy'],
  [1,'Âm thanh truyền được qua những môi trường nào?','chất rắn, chất lỏng, chất khí','chỉ qua không khí','chỉ qua nước','chân không'],
  [2,'Ta nhìn thấy vật khi nào?','khi có ánh sáng từ vật truyền vào mắt','khi nhắm mắt','khi ở trong bóng tối hoàn toàn','khi vật ở rất xa'],
  [2,'Vật nào dẫn nhiệt tốt?','thìa kim loại','thìa nhựa','đũa tre','găng tay vải'],
  [2,'Tiếng ồn gây hại gì cho con người?','ảnh hưởng đến thính giác, gây mệt mỏi','giúp ngủ ngon','làm tăng chiều cao','không có hại'],
  [3,'Nêu 2 cách phòng chống tiếng ồn ở trường học.','Ví dụ: trồng cây xanh, không nói to trong lớp, đóng cửa khi có tiếng ồn bên ngoài…'],
  [3,'Vì sao vào mùa đông ta nên mặc áo bông, áo len?','Vì áo bông, len là vật cách nhiệt, giữ cho cơ thể ấm.'],
 ]},
 {cd:'Thực vật, động vật và nấm',q:[
  [1,'Thực vật cần gì để sống và phát triển?','nước, chất khoáng, ánh sáng, không khí','chỉ cần nước','chỉ cần ánh sáng','chỉ cần đất'],
  [1,'Nấm nào sau đây ăn được?','nấm rơm','nấm độc đen','nấm lạ mọc ở bãi rác','nấm có màu sặc sỡ lạ'],
  [2,'Thực vật lấy vào khí gì và thải ra khí gì khi quang hợp?','lấy khí các-bô-níc, thải khí ô-xi','lấy khí ô-xi, thải khí các-bô-níc','lấy hơi nước, thải khí ni-tơ','không trao đổi khí'],
  [2,'Vì sao không nên ăn thức ăn bị mốc?','vì nấm mốc có thể gây ngộ độc','vì có vị ngọt','vì quá cứng','vì có nhiều vitamin'],
  [3,'Nêu 2 cách bảo quản thức ăn để tránh bị nấm mốc.','Ví dụ: để tủ lạnh, phơi khô, đóng hộp, ướp muối…'],
 ]},
 {cd:'Con người và sức khỏe',q:[
  [1,'Nhóm chất nào cung cấp năng lượng chủ yếu cho cơ thể?','chất bột đường','vitamin','chất khoáng','chất xơ'],
  [2,'Muốn phòng bệnh béo phì, em cần làm gì?','ăn uống hợp lí, vận động thường xuyên','ăn nhiều đồ ngọt','ngồi xem ti vi nhiều','bỏ bữa sáng'],
  [2,'Việc làm nào giúp phòng tránh đuối nước?','chỉ bơi khi có người lớn giám sát, ở nơi an toàn','chơi đùa gần ao hồ một mình','tắm sông khi trời lũ','lội qua suối khi nước chảy xiết'],
  [3,'Xây dựng thực đơn một ngày cân đối cho em.','Thực đơn đủ 4 nhóm chất (bột đường, đạm, béo, vitamin và khoáng), có rau quả, uống đủ nước.'],
 ]},
 {cd:'Sinh vật và môi trường',q:[
  [1,'Trong chuỗi thức ăn "Cỏ → Thỏ → Cáo", sinh vật nào là thức ăn của thỏ?','cỏ','cáo','không có','thỏ'],
  [2,'Vì sao cần bảo vệ sự cân bằng trong chuỗi thức ăn?','để các sinh vật cùng tồn tại và phát triển','để sinh vật biến mất','để có nhiều thức ăn cho con người','không cần bảo vệ'],
  [3,'Vẽ sơ đồ một chuỗi thức ăn có 3 sinh vật mà em biết.','Ví dụ: Lúa → Chuột → Rắn; Cỏ → Bò → Người.'],
 ]}],
5:[
 {cd:'Chất',q:[
  [1,'Đất có vai trò gì đối với cây trồng?','cung cấp nước, chất khoáng và giữ cho cây đứng vững','chỉ làm cây đẹp','không có vai trò gì','làm cây héo'],
  [1,'Nước muối là hỗn hợp hay dung dịch?','dung dịch','không phải hỗn hợp','chất tinh khiết','chất rắn'],
  [2,'Hiện tượng nào là sự biến đổi hóa học?','đốt cháy tờ giấy','xé nhỏ tờ giấy','nước đá tan thành nước','hòa tan đường vào nước'],
  [2,'Muốn tách cát ra khỏi hỗn hợp cát và nước, ta làm thế nào?','lọc hoặc để lắng','đun sôi','khuấy đều','cho thêm cát'],
  [3,'Nêu 2 việc làm chống xói mòn đất.','Ví dụ: trồng cây gây rừng, làm ruộng bậc thang, không chặt phá rừng…'],
 ]},
 {cd:'Năng lượng',q:[
  [1,'Vật nào cho dòng điện chạy qua (vật dẫn điện)?','dây đồng','miếng nhựa','thanh gỗ khô','cục tẩy'],
  [1,'Nguồn năng lượng nào là năng lượng sạch?','năng lượng mặt trời','than đá','dầu mỏ','khí đốt'],
  [2,'Một mạch điện thắp sáng đơn giản gồm những bộ phận nào?','pin, dây dẫn, bóng đèn (công tắc)','chỉ có bóng đèn','pin và giấy','dây dẫn và nước'],
  [2,'Việc làm nào giúp tiết kiệm điện?','tắt đèn, quạt khi ra khỏi phòng','bật điều hòa cả ngày','mở tủ lạnh liên tục','để ti vi chạy khi không xem'],
  [3,'Nêu 2 quy tắc an toàn khi sử dụng điện ở nhà.','Ví dụ: không chạm tay ướt vào ổ điện, không chơi gần trạm biến áp, không tự sửa đồ điện…'],
 ]},
 {cd:'Thực vật và động vật',q:[
  [1,'Cơ quan sinh sản của cây có hoa là gì?','hoa','rễ','thân','lá'],
  [1,'Con vật nào đẻ con?','con mèo','con gà','con rùa','con cá chép'],
  [2,'Cây con có thể mọc lên từ bộ phận nào của cây mẹ?','thân, rễ hoặc lá (ví dụ: mía, khoai lang, sắn)','chỉ từ hoa','chỉ từ quả chín','không thể mọc'],
  [2,'Vòng đời của ếch gồm các giai đoạn nào?','trứng → nòng nọc → ếch con → ếch trưởng thành','trứng → sâu → nhộng → ếch','ếch con → trứng → ếch','nòng nọc → trứng → ếch'],
  [3,'Nêu vòng đời của con bướm.','Trứng → sâu → nhộng → bướm.'],
 ]},
 {cd:'Vi khuẩn',q:[
  [1,'Vi khuẩn có kích thước như thế nào?','rất nhỏ, phải dùng kính hiển vi mới thấy','to bằng hạt gạo','to bằng quả cam','nhìn rõ bằng mắt thường'],
  [2,'Vi khuẩn nào có ích cho con người?','vi khuẩn dùng làm sữa chua, muối dưa','vi khuẩn gây bệnh tả','vi khuẩn gây bệnh lao','vi khuẩn gây ngộ độc'],
  [3,'Nêu 3 việc làm phòng bệnh do vi khuẩn gây ra.','Ví dụ: rửa tay bằng xà phòng, ăn chín uống sôi, giữ vệ sinh nhà ở, tiêm phòng…'],
 ]},
 {cd:'Con người và sức khỏe',q:[
  [1,'Tuổi dậy thì ở con gái thường bắt đầu vào khoảng nào?','từ 10 đến 15 tuổi','từ 3 đến 5 tuổi','từ 20 đến 25 tuổi','từ 6 đến 8 tuổi'],
  [2,'Ở tuổi dậy thì, em cần làm gì để giữ gìn sức khỏe?','vệ sinh cá nhân sạch sẽ, ăn uống đủ chất, vận động hợp lí','thức khuya','bỏ bữa','không tắm rửa thường xuyên'],
  [2,'Các giai đoạn phát triển của con người là gì?','tuổi ấu thơ → tuổi dậy thì → tuổi trưởng thành → tuổi già','tuổi già → tuổi trưởng thành','chỉ có tuổi trưởng thành','tuổi dậy thì → tuổi ấu thơ'],
  [3,'Nêu 2 việc em có thể làm để bảo vệ bản thân khỏi bị xâm hại.','Ví dụ: không đi một mình nơi vắng, không nhận quà của người lạ, kể ngay với người tin cậy khi thấy bất an…'],
 ]},
 {cd:'Sinh vật và môi trường',q:[
  [1,'Hoạt động nào gây ô nhiễm môi trường?','xả rác, nước thải bừa bãi','trồng cây xanh','phân loại rác','tiết kiệm nước'],
  [2,'Rừng có vai trò gì?','điều hòa khí hậu, chống lũ lụt, là nơi sống của nhiều loài','không có vai trò','gây lũ lụt','làm nóng Trái Đất'],
  [3,'Đề xuất 3 việc học sinh có thể làm để bảo vệ môi trường ở trường.','Ví dụ: phân loại rác, chăm sóc cây xanh, dùng bình nước cá nhân thay chai nhựa…'],
 ]}]
};

/* ======================= LỊCH SỬ VÀ ĐỊA LÍ (lớp 4–5) ======================= */
NH['Lịch sử và Địa lí']={
4:[
 {cd:'Địa phương em',q:[
  [1,'Bản đồ dùng để làm gì?','thể hiện vị trí, hình dạng các đối tượng địa lí','để trang trí','để đo nhiệt độ','để tính tiền'],
  [2,'Trên bản đồ, hướng Bắc thường ở phía nào?','phía trên','phía dưới','bên trái','bên phải'],
  [3,'Giới thiệu một di tích lịch sử hoặc danh lam thắng cảnh ở địa phương em.','HS nêu tên, vị trí, đặc điểm nổi bật, ý nghĩa, việc làm để giữ gìn.'],
 ]},
 {cd:'Trung du và miền núi Bắc Bộ',q:[
  [1,'Đỉnh núi cao nhất Việt Nam là đỉnh nào?','Phan-xi-păng','Bà Đen','Ngọc Linh','Tây Côn Lĩnh'],
  [1,'Đền Hùng nằm ở tỉnh nào?','Phú Thọ','Hà Giang','Lào Cai','Thái Nguyên'],
  [2,'Giỗ Tổ Hùng Vương được tổ chức vào ngày nào (âm lịch)?','ngày 10 tháng 3','ngày 1 tháng 1','ngày 15 tháng 8','ngày 5 tháng 5'],
  [2,'Ruộng bậc thang thường được làm ở đâu?','sườn đồi, núi','đồng bằng ven biển','trên cao nguyên bằng phẳng','ven sông lớn'],
  [3,'Vì sao người dân miền núi làm ruộng bậc thang?','Để giữ nước, chống xói mòn đất và có đất trồng trọt trên sườn núi dốc.'],
 ]},
 {cd:'Đồng bằng Bắc Bộ',q:[
  [1,'Đồng bằng Bắc Bộ do phù sa của những sông nào bồi đắp?','sông Hồng và sông Thái Bình','sông Tiền và sông Hậu','sông Đà và sông Mã','sông Cả'],
  [1,'Văn Miếu – Quốc Tử Giám ở thành phố nào?','Hà Nội','Huế','Đà Nẵng','Hải Phòng'],
  [2,'Văn Miếu – Quốc Tử Giám được xây dựng dưới triều đại nào?','nhà Lý','nhà Trần','nhà Hồ','nhà Nguyễn'],
  [2,'Vì sao người dân đồng bằng Bắc Bộ đắp đê ven sông?','để ngăn lũ lụt','để làm đường đi chơi','để trồng hoa','để nuôi cá'],
  [3,'Nêu 2 việc em có thể làm để giữ gìn các di tích lịch sử.','Ví dụ: không viết vẽ bậy, không xả rác, tìm hiểu và giới thiệu di tích…'],
 ]},
 {cd:'Duyên hải miền Trung',q:[
  [1,'Cố đô Huế thuộc vùng nào?','Duyên hải miền Trung','Tây Nguyên','Nam Bộ','Đồng bằng Bắc Bộ'],
  [1,'Phố cổ Hội An thuộc vùng nào?','Duyên hải miền Trung','Tây Nguyên','Nam Bộ','Trung du và miền núi Bắc Bộ'],
  [2,'Thiên tai nào thường xảy ra ở vùng Duyên hải miền Trung?','bão, lũ lụt, hạn hán','tuyết rơi','núi lửa','băng giá quanh năm'],
  [3,'Kể tên 2 bãi biển nổi tiếng ở Duyên hải miền Trung.','Ví dụ: Mỹ Khê (Đà Nẵng), Nha Trang, Sầm Sơn, Cửa Lò…'],
 ]},
 {cd:'Tây Nguyên',q:[
  [1,'Tây Nguyên là vùng có địa hình như thế nào?','các cao nguyên xếp tầng','đồng bằng rộng lớn','toàn núi đá vôi','bãi biển dài'],
  [1,'Cây công nghiệp nào được trồng nhiều ở Tây Nguyên?','cà phê','lúa nước','cói','mía'],
  [2,'Không gian văn hóa nào ở Tây Nguyên được UNESCO ghi danh?','Không gian văn hóa Cồng chiêng Tây Nguyên','Nhã nhạc cung đình Huế','Ca trù','Hát xoan'],
  [3,'Vì sao cần bảo vệ rừng ở Tây Nguyên?','Rừng giữ nước, chống xói mòn, điều hòa khí hậu, là nơi sống của nhiều loài động vật.'],
 ]},
 {cd:'Nam Bộ',q:[
  [1,'Đồng bằng Nam Bộ do phù sa của sông nào bồi đắp chủ yếu?','sông Mê Công và sông Đồng Nai','sông Hồng','sông Thái Bình','sông Đà'],
  [1,'Địa đạo Củ Chi thuộc địa phương nào?','Thành phố Hồ Chí Minh','Cần Thơ','Tây Ninh','Đồng Nai'],
  [2,'Đồng bằng sông Cửu Long là vùng sản xuất gì lớn nhất cả nước?','lúa gạo, trái cây và thủy sản','cà phê','chè','than đá'],
  [3,'Kể tên một nét văn hóa đặc trưng của người dân Nam Bộ.','Ví dụ: chợ nổi, đờn ca tài tử, nhà ven kênh rạch, đi lại bằng xuồng ghe…'],
 ]}],
5:[
 {cd:'Đất nước và con người Việt Nam',q:[
  [1,'Lãnh thổ phần đất liền của Việt Nam có hình dạng như thế nào?','hẹp ngang, kéo dài theo chiều bắc – nam, hình chữ S','hình tròn','hình vuông','hình tam giác'],
  [1,'Hai quần đảo xa bờ của Việt Nam là gì?','Hoàng Sa và Trường Sa','Côn Đảo và Phú Quốc','Cát Bà và Cô Tô','Lý Sơn và Phú Quý'],
  [1,'Việt Nam có bao nhiêu dân tộc?','54 dân tộc','50 dân tộc','64 dân tộc','45 dân tộc'],
  [2,'Khí hậu Việt Nam thuộc loại khí hậu nào?','nhiệt đới gió mùa','hàn đới','ôn đới lục địa','hoang mạc'],
  [2,'Địa hình phần đất liền nước ta chủ yếu là gì?','đồi núi (khoảng 3/4 diện tích)','đồng bằng','sa mạc','băng tuyết'],
  [3,'Nêu 2 việc học sinh có thể làm để góp phần bảo vệ biển đảo quê hương.','Ví dụ: không xả rác ra biển, tìm hiểu và tuyên truyền về chủ quyền biển đảo, ủng hộ chiến sĩ hải quân…'],
 ]},
 {cd:'Những quốc gia đầu tiên',q:[
  [1,'Nhà nước đầu tiên của nước ta là nhà nước nào?','Văn Lang','Âu Lạc','Đại Việt','Đại Cồ Việt'],
  [1,'Thành Cổ Loa gắn với nhà nước nào?','Âu Lạc','Văn Lang','Phù Nam','Chăm-pa'],
  [2,'Vương quốc Chăm-pa để lại công trình kiến trúc nổi tiếng nào?','Thánh địa Mỹ Sơn','Văn Miếu','Hoàng thành Thăng Long','Chùa Một Cột'],
  [3,'Kể lại ngắn gọn truyền thuyết về sự ra đời của nhà nước Văn Lang hoặc thành Cổ Loa.','HS kể đúng ý chính (Lạc Long Quân – Âu Cơ, Hùng Vương; hoặc An Dương Vương xây thành Cổ Loa).'],
 ]},
 {cd:'Xây dựng và bảo vệ đất nước',q:[
  [1,'Chiến thắng Bạch Đằng năm 938 gắn với tên tuổi của ai?','Ngô Quyền','Lý Thường Kiệt','Trần Hưng Đạo','Lê Lợi'],
  [1,'Ai lãnh đạo nhân dân ba lần đánh thắng quân Mông – Nguyên thế kỉ XIII?','Trần Hưng Đạo (Trần Quốc Tuấn)','Ngô Quyền','Quang Trung','Lê Lợi'],
  [1,'Khởi nghĩa Lam Sơn do ai lãnh đạo?','Lê Lợi','Quang Trung','Lý Thái Tổ','Đinh Bộ Lĩnh'],
  [2,'Vua Quang Trung đại phá quân Thanh vào năm nào?','1789','1288','938','1945'],
  [2,'Chủ tịch Hồ Chí Minh đọc bản Tuyên ngôn Độc lập vào ngày nào?','2/9/1945','19/8/1945','7/5/1954','30/4/1975'],
  [2,'Chiến thắng Điện Biên Phủ diễn ra năm nào?','1954','1945','1975','1968'],
  [2,'Ngày 30/4/1975 có ý nghĩa gì?','miền Nam hoàn toàn giải phóng, đất nước thống nhất','ngày thành lập Đảng','ngày Bác Hồ ra đi tìm đường cứu nước','ngày Quốc khánh'],
  [3,'Vì sao ngày 2/9 được chọn là ngày Quốc khánh nước Việt Nam?','Vì ngày 2/9/1945, Chủ tịch Hồ Chí Minh đọc Tuyên ngôn Độc lập, khai sinh nước Việt Nam Dân chủ Cộng hòa.'],
 ]},
 {cd:'Các nước láng giềng và thế giới',q:[
  [1,'Những nước nào có chung đường biên giới trên đất liền với Việt Nam?','Trung Quốc, Lào, Cam-pu-chia','Thái Lan, Mi-an-ma','Nhật Bản, Hàn Quốc','Ấn Độ, Lào'],
  [1,'Trên Trái Đất có mấy châu lục?','6 châu lục','4 châu lục','5 châu lục','8 châu lục'],
  [2,'Đại dương nào lớn nhất thế giới?','Thái Bình Dương','Đại Tây Dương','Ấn Độ Dương','Bắc Băng Dương'],
  [2,'Việt Nam là thành viên của tổ chức nào trong khu vực Đông Nam Á?','ASEAN','EU','NATO','OPEC'],
  [3,'Nêu một việc làm thể hiện tình hữu nghị giữa Việt Nam với nước láng giềng.','Ví dụ: hợp tác kinh tế, giao lưu văn hóa, giúp đỡ khi thiên tai…'],
 ]}]
};

/* ======================= TIẾNG ANH ======================= */
NH['Tiếng Anh']={
1:[
 {cd:'Greetings & Colours',q:[
  [1,'Chọn lời chào đúng: "…, I am Nam."','Hello','Goodbye','Thank you','Sorry'],
  [1,'"Red" nghĩa là màu gì?','màu đỏ','màu xanh lá','màu vàng','màu trắng'],
  [1,'"Yellow" nghĩa là màu gì?','màu vàng','màu đen','màu hồng','màu xanh dương'],
  [2,'Chọn từ chỉ màu sắc:','blue','cat','book','one'],
  [3,'Nói (viết) câu giới thiệu tên của em bằng tiếng Anh.','Hello. I am … / My name is …'],
 ]},
 {cd:'Numbers & Animals',q:[
  [1,'Số "three" là số mấy?','3','2','4','5'],
  [1,'"Dog" là con gì?','con chó','con mèo','con gà','con cá'],
  [2,'Chọn từ chỉ con vật:','fish','pen','red','ten'],
  [2,'1 + 1 = ? (bằng tiếng Anh)','two','one','three','four'],
  [3,'Viết tên 2 con vật bằng tiếng Anh mà em biết.','Ví dụ: cat, dog, bird, fish, duck…'],
 ]}],
2:[
 {cd:'School & Family',q:[
  [1,'"Pencil" nghĩa là gì?','bút chì','cái cặp','quyển sách','cái thước'],
  [1,'"Mother" nghĩa là ai?','mẹ','bố','ông','chị gái'],
  [2,'Chọn từ chỉ đồ dùng học tập:','ruler','apple','sun','bird'],
  [2,'Hoàn thành: "This is my …" (bố)','father','teacher','sister','friend'],
  [3,'Viết tên 3 đồ dùng học tập bằng tiếng Anh.','Ví dụ: pen, pencil, book, ruler, bag, rubber…'],
 ]},
 {cd:'Food & Toys',q:[
  [1,'"Banana" là quả gì?','quả chuối','quả táo','quả cam','quả nho'],
  [1,'"Ball" nghĩa là gì?','quả bóng','con búp bê','ô tô đồ chơi','con diều'],
  [2,'Chọn câu đúng để nói "Tôi thích táo":','I like apples.','I am apples.','I has apples.','I like apple is.'],
  [3,'Viết một câu nói về món đồ chơi em thích bằng tiếng Anh.','Ví dụ: I like my ball. / I have a doll.'],
 ]},
 {cd:'Places & Actions',q:[
  [1,'"Park" nghĩa là gì?','công viên','trường học','bệnh viện','chợ'],
  [1,'"Run" nghĩa là gì?','chạy','nhảy','bơi','hát'],
  [2,'Chọn câu đúng: "Tôi có thể bơi."','I can swim.','I swim can.','I can swims.','Can I swim.'],
  [2,'Chọn từ chỉ hành động:','jump','yellow','table','five'],
  [3,'Viết 2 hành động em có thể làm bằng tiếng Anh.','Ví dụ: I can run. I can sing.'],
 ]}],
3:[
 {cd:'Hello – Friends – Body',q:[
  [1,'Chọn câu trả lời đúng: "How are you?"','I\'m fine, thank you.','I\'m eight.','My name is Lan.','Goodbye.'],
  [1,'"Ear" là bộ phận nào?','tai','mắt','mũi','miệng'],
  [2,'Hoàn thành câu: "What\'s … name?" – "My name is Mai."','your','you','my','he'],
  [2,'Chọn câu trả lời đúng: "How old are you?"','I\'m eight years old.','I\'m fine.','I\'m Nam.','Yes, I am.'],
  [2,'Hoàn thành: "This … my friend Ben."','is','are','am','be'],
  [3,'Viết 2 câu giới thiệu bản thân (tên và tuổi) bằng tiếng Anh.','My name is … I\'m … years old.'],
 ]},
 {cd:'School – Classroom',q:[
  [1,'"Library" nghĩa là gì?','thư viện','phòng học','sân trường','phòng máy tính'],
  [1,'"Stand up, please!" nghĩa là gì?','Mời đứng lên!','Mời ngồi xuống!','Mở sách ra!','Đóng sách lại!'],
  [2,'Hoàn thành: "May I … in?"','come','go','sit','open'],
  [2,'Chọn câu trả lời đúng: "Is this your pen?"','Yes, it is.','Yes, I am.','No, I\'m not.','It\'s a pen yes.'],
  [3,'Viết câu hỏi và trả lời về màu của chiếc cặp.','What colour is your school bag? – It\'s blue.'],
 ]},
 {cd:'Family – House – Pets',q:[
  [1,'"Grandmother" nghĩa là ai?','bà','ông','mẹ','cô giáo'],
  [1,'"Kitchen" là phòng nào?','phòng bếp','phòng ngủ','phòng khách','phòng tắm'],
  [2,'Chọn câu trả lời đúng: "Who\'s that?"','It\'s my brother.','It\'s a book.','I\'m fine.','It\'s red.'],
  [2,'Hoàn thành: "I have two …" (con mèo)','cats','cat','a cats','cates'],
  [3,'Viết 2 câu nói về con vật nuôi của em.','Ví dụ: I have a dog. It is brown.'],
 ]}],
4:[
 {cd:'Friends – Time – Daily routines',q:[
  [1,'Chọn câu trả lời đúng: "Where are you from?"','I\'m from Viet Nam.','I\'m nine.','I\'m Vietnamese food.','It\'s seven o\'clock.'],
  [1,'"Monday" là thứ mấy?','thứ Hai','thứ Ba','Chủ nhật','thứ Sáu'],
  [2,'Chọn câu trả lời đúng: "What time is it?"','It\'s nine o\'clock.','It\'s Monday.','It\'s sunny.','It\'s my book.'],
  [2,'Hoàn thành: "I get up … six o\'clock."','at','in','on','to'],
  [2,'Hoàn thành: "We have English … Monday."','on','at','in','to'],
  [3,'Viết 2 câu kể về việc em làm vào buổi sáng (có giờ).','Ví dụ: I get up at six o\'clock. I go to school at seven o\'clock.'],
 ]},
 {cd:'Birthday – Abilities – Subjects',q:[
  [1,'"Can you swim?" – "Yes, I …"','can','am','do','is'],
  [1,'"Maths" là môn học nào?','Toán','Tiếng Việt','Khoa học','Âm nhạc'],
  [2,'Chọn câu trả lời đúng: "When\'s your birthday?"','It\'s in May.','I\'m ten.','It\'s a cake.','Yes, it is.'],
  [2,'Chọn câu trả lời đúng: "What\'s your favourite subject?"','It\'s Science.','It\'s Tuesday.','I like cats.','It\'s at eight.'],
  [3,'Viết 2 câu nói về điều em có thể làm và không thể làm.','Ví dụ: I can ride a bike. I can\'t play the piano.'],
 ]},
 {cd:'Home – Jobs – Weekend',q:[
  [1,'"Farmer" là nghề gì?','nông dân','giáo viên','bác sĩ','công nhân'],
  [2,'Chọn câu trả lời đúng: "What does your father do?"','He\'s a doctor.','He\'s tall.','He\'s at home now yes.','He\'s ten.'],
  [2,'Hoàn thành: "My mother … a teacher."','is','are','am','be'],
  [2,'Chọn câu đúng nói "Tôi xem ti vi vào cuối tuần":','I watch TV at the weekend.','I watching TV at weekend.','I watches TV the weekend.','I watch at TV weekend.'],
  [3,'Viết 2–3 câu nói về ngôi nhà của em.','Ví dụ: My house is big. It has a living room and two bedrooms.'],
 ]}],
5:[
 {cd:'About me – Home – Friends',q:[
  [1,'Chọn câu trả lời đúng: "What\'s your address?"','It\'s 25 Le Loi Street.','I\'m eleven.','It\'s my house is.','I live yes.'],
  [1,'"Flat" (apartment) nghĩa là gì?','căn hộ','biệt thự','ngôi làng','thị trấn'],
  [2,'Chọn câu trả lời đúng: "What nationality is she?"','She\'s Japanese.','She\'s Japan.','She\'s from Japanese.','She Japan.'],
  [2,'Hoàn thành: "I like … badminton in my free time."','playing','play to','plays','played to'],
  [3,'Viết 2–3 câu giới thiệu về một người bạn của em.','Ví dụ: This is my friend Linh. She is eleven. She likes reading books.'],
 ]},
 {cd:'Future job – School activities',q:[
  [1,'"Pilot" là nghề gì?','phi công','cảnh sát','y tá','nông dân'],
  [2,'Chọn câu trả lời đúng: "What would you like to be in the future?"','I\'d like to be a doctor.','I like doctor.','I\'m a doctor now yes.','I\'d like doctors.'],
  [2,'Hoàn thành: "Why would you like to be a teacher? – Because I\'d like to … children."','teach','teaches','teaching','taught'],
  [3,'Viết 2 câu nói về nghề em muốn làm trong tương lai và lí do.','Ví dụ: I\'d like to be a nurse. I\'d like to help sick people.'],
 ]},
 {cd:'Holidays – Health – Weather',q:[
  [1,'"Tet" là dịp gì?','Tết Nguyên đán','Giáng sinh','Trung thu','sinh nhật'],
  [1,'"Rainy" nghĩa là trời thế nào?','có mưa','có nắng','có gió','có tuyết'],
  [2,'Chọn câu trả lời đúng: "What\'s the matter with you?"','I have a headache.','I\'m Mary.','It\'s sunny.','I\'d like a cake.'],
  [2,'Hoàn thành: "You should … to the dentist."','go','goes','going','went'],
  [2,'Thì quá khứ của "go" là gì?','went','goed','gone','going'],
  [3,'Viết 2–3 câu kể về kì nghỉ hè vừa qua của em (dùng thì quá khứ).','Ví dụ: Last summer, I went to Ha Long Bay. I swam in the sea. It was great.'],
 ]},
 {cd:'Transport – Places',q:[
  [1,'"By bus" nghĩa là gì?','bằng xe buýt','bằng tàu hỏa','bằng máy bay','đi bộ'],
  [2,'Chọn câu trả lời đúng: "How can I get to the museum?"','You can go by taxi.','It\'s a big museum.','I like museums.','At seven o\'clock.'],
  [2,'Chọn câu trả lời đúng: "Where did you go last weekend?"','I went to the zoo.','I go to the zoo.','I going to zoo.','I will to the zoo.'],
  [3,'Viết 2 câu giới thiệu một địa điểm du lịch ở Việt Nam.','Ví dụ: Ha Long Bay is in Quang Ninh. It is very beautiful.'],
 ]}]
};

/* ======================= TIN HỌC (lớp 3–5) ======================= */
NH['Tin học']={
3:[
 {cd:'Máy tính và em',q:[
  [1,'Bộ phận nào dùng để gõ chữ vào máy tính?','bàn phím','chuột','màn hình','loa'],
  [1,'Bộ phận nào hiển thị hình ảnh, chữ viết?','màn hình','bàn phím','chuột','thân máy'],
  [2,'Khi ngồi máy tính, em cần ngồi thế nào?','lưng thẳng, mắt cách màn hình khoảng 50–80 cm','cúi sát màn hình','nằm trên ghế','vừa ăn vừa dùng máy'],
  [2,'Hàng phím cơ sở là hàng phím nào?','hàng có phím F và J','hàng phím số','hàng phím dưới cùng','hàng phím trên cùng'],
  [3,'Nêu 2 việc cần làm để sử dụng máy tính an toàn, không hại sức khỏe.','Ví dụ: ngồi đúng tư thế, không dùng quá lâu, nghỉ mắt sau 30–45 phút, không chạm tay ướt…'],
 ]},
 {cd:'Thông tin và xử lí thông tin',q:[
  [1,'Thông tin có thể ở dạng nào?','chữ, hình ảnh, âm thanh','chỉ có chữ','chỉ có âm thanh','chỉ có số'],
  [2,'Đèn giao thông chuyển sang màu đỏ cho ta thông tin gì?','phải dừng lại','được đi tiếp','đi nhanh lên','rẽ trái'],
  [3,'Nêu một ví dụ về thông tin em nhận được hằng ngày và em xử lí nó thế nào.','Ví dụ: nghe trống trường báo giờ ra chơi → em ra sân chơi.'],
 ]},
 {cd:'Đạo đức và an toàn trên mạng',q:[
  [1,'Khi dùng Internet, em không nên làm gì?','cung cấp thông tin cá nhân cho người lạ','hỏi ý kiến bố mẹ','xem trang web học tập','tắt máy đúng giờ'],
  [2,'Khi thấy thông tin xấu, đáng sợ trên mạng, em nên làm gì?','tắt đi và báo ngay cho người lớn','chia sẻ cho bạn','xem tiếp','bình luận'],
  [3,'Nêu 2 quy tắc khi sử dụng Internet an toàn.','Ví dụ: không chia sẻ mật khẩu, địa chỉ nhà; không gặp người quen qua mạng; có người lớn hướng dẫn…'],
 ]}],
4:[
 {cd:'Phần cứng và phần mềm',q:[
  [1,'Chuột, bàn phím, màn hình thuộc loại nào?','phần cứng','phần mềm','dữ liệu','mạng'],
  [1,'Phần mềm soạn thảo văn bản là gì?','Word (phần mềm soạn thảo văn bản)','chuột máy tính','loa','máy in'],
  [2,'Phần mềm là gì?','các chương trình giúp máy tính hoạt động và làm việc','các thiết bị có thể cầm được','dây điện của máy tính','màn hình'],
  [3,'Kể tên 2 thiết bị phần cứng và 2 phần mềm em biết.','Phần cứng: bàn phím, chuột, màn hình… Phần mềm: Word, PowerPoint, Scratch, trình duyệt web…'],
 ]},
 {cd:'Soạn thảo văn bản và trình chiếu',q:[
  [1,'Tổ hợp phím Ctrl + C dùng để làm gì?','sao chép','dán','cắt','xóa'],
  [1,'Tổ hợp phím Ctrl + V dùng để làm gì?','dán','sao chép','in đậm','lưu'],
  [2,'Muốn chữ in đậm, em dùng tổ hợp phím nào?','Ctrl + B','Ctrl + I','Ctrl + U','Ctrl + S'],
  [2,'Phần mềm nào dùng để tạo bài trình chiếu?','PowerPoint','Paint','Calculator','Notepad'],
  [3,'Nêu các bước chèn một hình ảnh vào bài trình chiếu.','Chọn trang chiếu → Insert → Picture → chọn ảnh → Insert; chỉnh vị trí, kích thước.'],
 ]},
 {cd:'Lập trình Scratch',q:[
  [1,'Trong Scratch, nhân vật được gọi là gì?','Sprite (nhân vật)','Stage (sân khấu)','Block (khối lệnh)','Costume'],
  [2,'Khối lệnh "when green flag clicked" dùng để làm gì?','bắt đầu chạy chương trình khi nháy lá cờ xanh','dừng chương trình','đổi màu nhân vật','xóa nhân vật'],
  [2,'Khối lệnh "repeat 10" có ý nghĩa gì?','lặp lại các lệnh bên trong 10 lần','chờ 10 giây','di chuyển 10 bước','xoay 10 độ'],
  [3,'Viết các bước để nhân vật mèo đi 10 bước rồi nói "Xin chào!".','when green flag clicked → move 10 steps → say "Xin chào!"'],
 ]}],
5:[
 {cd:'Tìm kiếm thông tin, thư mục',q:[
  [1,'Để tìm kiếm thông tin trên Internet, em dùng gì?','máy tìm kiếm (ví dụ Google)','phần mềm vẽ','máy tính bỏ túi','phần mềm gõ phím'],
  [2,'Thư mục trong máy tính dùng để làm gì?','sắp xếp, lưu trữ các tệp một cách có tổ chức','tăng tốc máy tính','vẽ tranh','kết nối Internet'],
  [2,'Khi dùng thông tin trên Internet cho bài làm, em cần làm gì?','ghi rõ nguồn và chọn thông tin đáng tin cậy','chép nguyên văn không ghi nguồn','tin mọi thông tin','dùng thông tin của trang lạ'],
  [3,'Nêu cách đặt tên thư mục để dễ tìm lại bài tập môn Toán.','Ví dụ: tạo thư mục "Toan_Lop5", bên trong chia theo chủ đề/tuần, đặt tên tệp rõ ràng.'],
 ]},
 {cd:'Lập trình Scratch nâng cao',q:[
  [1,'Khối lệnh "if … then" dùng để làm gì?','thực hiện lệnh khi điều kiện đúng','lặp mãi mãi','dừng chương trình','đổi phông nền'],
  [2,'Biến (variable) trong Scratch dùng để làm gì?','lưu trữ giá trị, ví dụ điểm số','vẽ hình','phát âm thanh','đổi trang phục'],
  [2,'Khối lệnh "forever" có tác dụng gì?','lặp lại các lệnh bên trong mãi mãi','chạy một lần','chờ 1 giây','ẩn nhân vật'],
  [3,'Mô tả chương trình: khi mèo chạm vào chuột thì cộng 1 điểm.','forever → if touching "chuột" then → change điểm by 1 (và đưa chuột đến vị trí mới).'],
 ]},
 {cd:'Đạo đức, an toàn số',q:[
  [1,'Mật khẩu mạnh là mật khẩu như thế nào?','có chữ hoa, chữ thường, số và kí hiệu','là ngày sinh của em','là tên của em','là 123456'],
  [2,'Bản quyền phần mềm là gì?','quyền của tác giả đối với sản phẩm, cần tôn trọng','được sao chép tùy ý','không quan trọng','chỉ dành cho người lớn'],
  [3,'Nêu 2 cách bảo vệ tài khoản trực tuyến của em.','Ví dụ: không chia sẻ mật khẩu, đăng xuất sau khi dùng máy chung, dùng mật khẩu mạnh…'],
 ]}]
};

/* ======================= CÔNG NGHỆ (lớp 3–5) ======================= */
NH['Công nghệ']={
3:[
 {cd:'Tự nhiên và công nghệ',q:[
  [1,'Đối tượng nào là sản phẩm công nghệ?','quạt điện','cây xanh','dòng sông','con chim'],
  [1,'Đối tượng nào thuộc về tự nhiên?','ngọn núi','ti vi','xe đạp','đèn học'],
  [2,'Vì sao cần giữ gìn sản phẩm công nghệ trong gia đình?','để dùng được lâu, tiết kiệm và an toàn','để vứt đi','để mua cái mới','không cần giữ gìn'],
  [3,'Kể tên 3 sản phẩm công nghệ trong gia đình em và công dụng của chúng.','Ví dụ: tủ lạnh – bảo quản thực phẩm; quạt – làm mát; nồi cơm điện – nấu cơm…'],
 ]},
 {cd:'Sử dụng đèn học, quạt điện, ti vi',q:[
  [1,'Đèn học có tác dụng gì?','chiếu sáng khi học bài','làm mát','nghe nhạc','sưởi ấm'],
  [2,'Khi sử dụng quạt điện, em cần lưu ý gì?','không cho tay, que vào cánh quạt đang quay','đứng sát quạt','tự tháo quạt khi đang chạy','dùng tay ướt bật quạt'],
  [2,'Xem ti vi như thế nào là hợp lí?','ngồi cách xa màn hình, xem trong thời gian vừa phải','ngồi sát màn hình','xem suốt ngày','vừa ăn vừa xem đến khuya'],
  [3,'Nêu 2 việc cần làm khi sử dụng đèn học an toàn.','Ví dụ: đặt đèn chắc chắn, không chạm vào bóng đang nóng, tắt đèn khi không dùng…'],
 ]},
 {cd:'Thủ công kĩ thuật',q:[
  [1,'Dụng cụ nào dùng để cắt giấy?','kéo','thước','bút chì','keo dán'],
  [2,'Khi dùng kéo, em cần chú ý điều gì?','cầm kéo đúng cách, không chĩa mũi kéo vào bạn','đùa nghịch với kéo','vừa đi vừa cắt','cắt gần tay bạn'],
  [3,'Nêu các bước làm một biển báo giao thông bằng giấy bìa.','Chọn biển báo → vẽ hình trên bìa → cắt → tô màu → dán vào que/giá đỡ.'],
 ]}],
4:[
 {cd:'Hoa và cây cảnh',q:[
  [1,'Cây nào thường được trồng làm cảnh?','cây vạn tuế','cây lúa','cây ngô','cây mía'],
  [1,'Dụng cụ nào dùng để xới đất trồng hoa?','cái xẻng nhỏ (bay)','cái kéo giấy','cái thước','cái compa'],
  [2,'Cây hoa trồng trong chậu cần được chăm sóc thế nào?','tưới nước, bón phân, để nơi có ánh sáng phù hợp','không tưới nước','để trong phòng tối','tưới thật nhiều nước mỗi giờ'],
  [3,'Nêu các bước gieo hạt trong chậu.','Chuẩn bị chậu, đất → gieo hạt → phủ lớp đất mỏng → tưới nước nhẹ → đặt nơi thoáng mát.'],
 ]},
 {cd:'Lắp ghép mô hình kĩ thuật',q:[
  [1,'Dụng cụ nào dùng để vặn ốc vít khi lắp ghép mô hình?','tua vít và cờ lê','kéo','bút chì','tẩy'],
  [2,'Khi lắp ghép mô hình, em cần làm gì đầu tiên?','đọc kĩ hướng dẫn và chọn đủ chi tiết','lắp ngay không cần xem','vứt bớt chi tiết','dùng búa đóng'],
  [3,'Nêu các bước lắp ghép mô hình cái đu (hoặc rô-bốt) đơn giản.','Chọn chi tiết → lắp từng bộ phận → ghép các bộ phận → kiểm tra sản phẩm → tháo và cất gọn.'],
 ]},
 {cd:'Đồ chơi dân gian',q:[
  [1,'Đồ chơi nào là đồ chơi dân gian?','chong chóng','xe điều khiển từ xa','rô-bốt điện tử','máy chơi game'],
  [2,'Khi chơi đồ chơi dân gian, em cần chú ý gì?','chơi đúng cách, an toàn và giữ gìn đồ chơi','chơi ở lòng đường','tranh giành với bạn','phá hỏng đồ chơi'],
  [3,'Nêu các bước làm một chiếc chong chóng bằng giấy.','Cắt giấy hình vuông → cắt từ 4 góc vào gần tâm → gập các đầu vào tâm → ghim vào que.'],
 ]}],
5:[
 {cd:'Công nghệ và đời sống',q:[
  [1,'Vai trò của công nghệ trong đời sống là gì?','giúp cuộc sống tiện nghi, an toàn hơn','làm cuộc sống khó khăn','không có vai trò gì','chỉ dùng để giải trí'],
  [1,'Sáng chế là gì?','tạo ra sản phẩm hoặc giải pháp mới, có ích','sao chép sản phẩm của người khác','mua đồ mới','sửa đồ cũ'],
  [2,'Thiết kế sản phẩm gồm những bước nào?','hình thành ý tưởng → vẽ phác thảo → làm sản phẩm mẫu → đánh giá, hoàn thiện','làm ngay không cần nghĩ','chỉ cần vẽ đẹp','mua sản phẩm có sẵn'],
  [3,'Đề xuất ý tưởng một sản phẩm giúp em học tập tốt hơn.','HS nêu tên sản phẩm, công dụng, vật liệu, cách làm sơ lược.'],
 ]},
 {cd:'Sử dụng điện thoại, tủ lạnh',q:[
  [1,'Số điện thoại khẩn cấp gọi công an là số nào?','113','114','115','111'],
  [2,'Khi sử dụng tủ lạnh, em cần chú ý gì?','đóng kín cửa tủ, không để thức ăn nóng vào tủ','mở cửa tủ lâu','để thức ăn đang nóng vào','để tủ sát bếp lửa'],
  [3,'Nêu 2 quy tắc sử dụng điện thoại an toàn, lịch sự.','Ví dụ: không dùng khi đang đi đường, nói nhỏ nơi công cộng, không gọi đùa số khẩn cấp…'],
 ]},
 {cd:'Mô hình điện',q:[
  [1,'Bộ phận nào cung cấp điện cho mô hình xe điện chạy pin?','pin','bánh xe','khung xe','dây buộc'],
  [2,'Mô hình máy phát điện gió hoạt động nhờ gì?','gió làm quay cánh quạt, tạo ra điện','ánh sáng đèn','nước nóng','pin sạc'],
  [3,'Nêu các bước lắp mô hình xe điện chạy pin.','Lắp khung → lắp bánh xe, trục → lắp động cơ, pin → nối dây, công tắc → kiểm tra cho xe chạy.'],
 ]}]
};

/* ======================= GIÁO DỤC THỂ CHẤT ======================= */
const GDTC_CHUNG=[
 {cd:'Đội hình đội ngũ',q:[
  [1,'Khi nghe khẩu lệnh "Nghiêm!", em phải làm gì?','đứng thẳng, hai gót chân sát nhau, tay để dọc thân người','ngồi xuống','chạy về chỗ','giơ tay lên cao'],
  [1,'Khẩu lệnh "Thành một hàng dọc – tập hợp!" yêu cầu em làm gì?','nhanh chóng đứng thành một hàng dọc theo đúng vị trí','đứng thành vòng tròn','ngồi xuống','tự do đi lại'],
  [2,'Khi điểm số từ 1 đến hết, em cần làm gì?','quay đầu sang bên, đọc to rõ số của mình','im lặng','đọc số của bạn','đọc to tên mình'],
  [3,'Nêu các khẩu lệnh đội hình đội ngũ em đã học.','Ví dụ: Tập hợp, Nghiêm, Nghỉ, Điểm số, Quay phải/trái, Giải tán…'],
 ]},
 {cd:'Vệ sinh và an toàn trong tập luyện',q:[
  [1,'Trước khi tập luyện, em cần làm gì?','khởi động kĩ các khớp','ăn thật no','ngủ một giấc','uống nhiều nước ngọt có ga'],
  [2,'Trang phục khi tập thể dục nên như thế nào?','gọn gàng, thoáng mát, đi giày thể thao','mặc váy dài','đi dép cao gót','mặc áo khoác dày khi trời nóng'],
  [2,'Sau khi tập luyện ra nhiều mồ hôi, em nên làm gì?','lau mồ hôi, nghỉ ngơi rồi uống nước từ từ','tắm nước lạnh ngay','uống thật nhiều nước đá','ngồi trước quạt mạnh ngay'],
  [3,'Nêu 2 lợi ích của việc tập thể dục thể thao thường xuyên.','Ví dụ: cơ thể khỏe mạnh, phát triển chiều cao, tinh thần sảng khoái, phòng bệnh…'],
 ]},
 {cd:'Vận động cơ bản và trò chơi',q:[
  [1,'Khi chạy, mắt em cần nhìn về đâu?','nhìn thẳng về phía trước','nhìn xuống chân','nhắm mắt','nhìn ra sau'],
  [2,'Khi tham gia trò chơi vận động, em cần làm gì?','chơi đúng luật, đoàn kết, an toàn','xô đẩy bạn','gian lận để thắng','bỏ dở giữa chừng'],
  [3,'Kể tên một trò chơi vận động em thích và nêu cách chơi.','HS nêu tên trò chơi (Mèo đuổi chuột, Kéo co, Nhảy dây…) và cách chơi ngắn gọn.'],
 ]}];
NH['Giáo dục thể chất']={1:GDTC_CHUNG,2:GDTC_CHUNG,
3:GDTC_CHUNG.concat([{cd:'Thể thao tự chọn',q:[
  [1,'Trong môn bóng đá, cầu thủ nào được dùng tay chơi bóng trong vòng cấm?','thủ môn','tiền đạo','hậu vệ','tiền vệ'],
  [2,'Để đá bóng chính xác, em dùng phần nào của bàn chân khi chuyền bóng ngắn?','má trong bàn chân','gót chân','mũi chân thật mạnh','đầu gối'],
  [3,'Nêu 2 điều cần chú ý để tập môn thể thao em chọn an toàn.','Ví dụ: khởi động kĩ, dùng đúng dụng cụ, tập nơi an toàn, nghe hướng dẫn của thầy cô.'],
 ]}]),
4:GDTC_CHUNG.concat([{cd:'Thể thao tự chọn',q:[
  [1,'Môn bơi giúp em điều gì?','phòng tránh đuối nước, rèn luyện sức khỏe','làm mỏi mắt','không có lợi ích','gây béo phì'],
  [2,'Trong bóng rổ, muốn ghi điểm em phải làm gì?','ném bóng vào rổ của đối phương','đá bóng vào lưới','đánh bóng qua lưới','ôm bóng chạy về sân nhà'],
  [3,'Lập kế hoạch tự tập thể dục buổi sáng trong một tuần.','HS nêu thời gian, nội dung (khởi động, bài thể dục, chạy nhẹ, nhảy dây), số lần/ngày, thả lỏng.'],
 ]}]),
5:GDTC_CHUNG.concat([{cd:'Thể thao tự chọn',q:[
  [1,'Môn cầu lông dùng dụng cụ gì?','vợt và quả cầu lông','gậy và bóng','chân và quả bóng','găng tay'],
  [2,'Vì sao phải thả lỏng cơ thể sau khi tập luyện?','để cơ thể hồi phục, giảm mỏi cơ','để mệt hơn','để tăng nhịp tim','không cần thiết'],
  [3,'Nêu cách xử lí khi bạn bị chuột rút trong lúc tập.','Cho bạn dừng tập, kéo duỗi nhẹ cơ bị chuột rút, xoa bóp, báo thầy cô.'],
 ]}])};

/* ======================= ÂM NHẠC ======================= */
const AN_12=[
 {cd:'Nghe và cảm nhận âm thanh',q:[
  [1,'Âm thanh nào là âm thanh của thiên nhiên?','tiếng chim hót','tiếng còi xe','tiếng chuông điện thoại','tiếng ti vi'],
  [1,'Tiếng nào phát ra to hơn?','tiếng trống cái','tiếng thì thầm','tiếng lá rơi','tiếng kim đồng hồ'],
  [2,'Khi nghe bạn hát, em cần có thái độ thế nào?','chú ý lắng nghe và cổ vũ bạn','nói chuyện riêng','cười chê bạn','bịt tai lại'],
  [2,'Bài hát vui tươi thường có nhịp độ thế nào?','nhanh, rộn ràng','rất chậm, buồn','không có nhịp','im lặng'],
  [3,'Vỗ tay theo nhịp một bài hát em đã học.','HS vỗ tay đều, đúng nhịp bài hát.'],
  [3,'Kể tên 2 âm thanh em nghe thấy trên đường đi học.','Ví dụ: tiếng còi xe, tiếng chim hót, tiếng trống trường…'],
 ]},
 {cd:'Hát và nghe nhạc',q:[
  [1,'Khi hát, em cần ngồi (đứng) như thế nào?','ngay ngắn, lưng thẳng','nằm xuống','cúi gập người','quay ngang'],
  [2,'Hát đúng là hát như thế nào?','đúng cao độ, trường độ và lời ca','hát thật to','hát thật nhanh','hát sai lời cũng được'],
  [3,'Kể tên một bài hát thiếu nhi em thích và hát một đoạn.','HS kể tên bài hát và hát đúng giai điệu, lời ca.'],
 ]},
 {cd:'Nhạc cụ gõ',q:[
  [1,'Nhạc cụ nào là nhạc cụ gõ?','thanh phách','đàn ghi-ta','sáo','kèn'],
  [1,'Nhạc cụ nào dùng để giữ nhịp khi hát?','trống nhỏ','đàn bầu','đàn tranh','piano lớn'],
  [3,'Dùng thanh phách gõ đệm theo phách cho một bài hát em đã học.','HS gõ đều, đúng phách, khớp với lời hát.'],
 ]}];
const AN_35=[
 {cd:'Lí thuyết âm nhạc',q:[
  [1,'Có bao nhiêu nốt nhạc cơ bản?','7 nốt (Đô, Rê, Mi, Pha, Son, La, Si)','5 nốt','6 nốt','8 nốt'],
  [1,'Khuông nhạc có mấy dòng kẻ?','5 dòng kẻ','4 dòng kẻ','6 dòng kẻ','3 dòng kẻ'],
  [2,'Một nốt trắng có trường độ bằng mấy nốt đen?','2 nốt đen','1 nốt đen','3 nốt đen','4 nốt đen'],
  [2,'Một nốt đen có trường độ bằng mấy nốt móc đơn?','2 nốt móc đơn','1 nốt móc đơn','3 nốt móc đơn','4 nốt móc đơn'],
  [2,'Trong nhịp 2/4, mỗi ô nhịp có mấy phách?','2 phách','3 phách','4 phách','1 phách'],
  [3,'Đọc tên các nốt nhạc theo thứ tự từ thấp đến cao.','Đô – Rê – Mi – Pha – Son – La – Si.'],
 ]},
 {cd:'Nhạc cụ',q:[
  [1,'Đàn bầu là nhạc cụ có mấy dây?','1 dây','2 dây','4 dây','6 dây'],
  [1,'Nhạc cụ nào là nhạc cụ dân tộc Việt Nam?','đàn tranh','đàn vi-ô-lông','kèn sắc-xô-phôn','đàn ghi-ta điện'],
  [2,'Khi thổi kèn phím (sáo recorder), em cần chú ý gì?','thổi hơi đều, nhẹ; ngón tay bấm kín lỗ','thổi thật mạnh','bấm hờ các lỗ','vừa thổi vừa nói chuyện'],
  [3,'Kể tên 2 nhạc cụ gõ và 2 nhạc cụ thổi mà em biết.','Gõ: trống, thanh phách, song loan, tem-bơ-rin… Thổi: sáo trúc, kèn phím, recorder…'],
 ]},
 {cd:'Hát và thường thức âm nhạc',q:[
  [1,'Tác giả bài Quốc ca Việt Nam (Tiến quân ca) là ai?','nhạc sĩ Văn Cao','nhạc sĩ Phạm Tuyên','nhạc sĩ Hoàng Vân','nhạc sĩ Trịnh Công Sơn'],
  [2,'Bài hát "Như có Bác Hồ trong ngày vui đại thắng" là của nhạc sĩ nào?','Phạm Tuyên','Văn Cao','Lưu Hữu Phước','Hoàng Long'],
  [2,'Khi biểu diễn bài hát, em cần thể hiện điều gì?','hát đúng, rõ lời và thể hiện cảm xúc phù hợp','hát thật to át bạn','đứng quay lưng','hát thật nhanh cho xong'],
  [3,'Trình bày một bài hát đã học có kết hợp gõ đệm hoặc vận động phụ họa.','HS hát đúng giai điệu, lời ca; gõ đệm/vận động khớp nhịp.'],
 ]}];
NH['Âm nhạc']={1:AN_12,2:AN_12,3:AN_35,4:AN_35,5:AN_35};

/* ======================= MĨ THUẬT ======================= */
const MT_12=[
 {cd:'Đồ dùng và sản phẩm mĩ thuật',q:[
  [1,'Dụng cụ nào dùng để tô màu?','bút sáp màu','thước kẻ','compa','tẩy'],
  [1,'Đất nặn dùng để làm gì?','nặn thành hình con vật, đồ vật','viết chữ','đo độ dài','gọt bút chì'],
  [2,'Sau khi vẽ xong, em cần làm gì với đồ dùng?','cất gọn gàng, giữ sạch sẽ','để bừa bãi','vứt đi','bẻ gãy bút màu'],
  [2,'Khi tô màu, em nên tô như thế nào?','tô đều tay, không chờm ra ngoài hình','tô thật nhanh ra ngoài','chỉ tô một nửa','không cần tô'],
  [3,'Nặn một con vật em yêu thích bằng đất nặn.','HS nặn được hình dáng con vật, có các bộ phận chính.'],
  [3,'Giới thiệu bức tranh của em với các bạn.','HS nêu tên tranh, hình ảnh, màu sắc em dùng.'],
 ]},
 {cd:'Màu sắc',q:[
  [1,'Ba màu cơ bản là những màu nào?','đỏ, vàng, lam','đỏ, xanh lá, tím','cam, tím, hồng','đen, trắng, xám'],
  [1,'Lá cây thường có màu gì?','màu xanh lá','màu tím','màu đen','màu hồng'],
  [2,'Pha màu đỏ với màu vàng được màu gì?','màu cam','màu tím','màu xanh lá','màu nâu'],
  [3,'Vẽ và tô màu một bông hoa em thích.','HS vẽ được hình bông hoa, tô màu tươi sáng, gọn gàng.'],
 ]},
 {cd:'Chấm, nét, hình, mảng',q:[
  [1,'Nét nào sau đây là nét cong?','nét vẽ hình cầu vồng','nét kẻ bằng thước','nét gấp khúc','nét thẳng đứng'],
  [2,'Mặt trời thường được vẽ bằng hình gì?','hình tròn','hình vuông','hình tam giác','hình chữ nhật'],
  [3,'Dùng các chấm màu để trang trí một chiếc khăn.','HS sắp xếp chấm màu có nhịp điệu, hài hòa.'],
 ]}];
const MT_35=[
 {cd:'Màu sắc và đậm nhạt',q:[
  [1,'Màu nào là màu nóng?','màu đỏ, màu cam','màu lam','màu tím','màu xanh lục'],
  [1,'Màu nào là màu lạnh?','màu xanh lam','màu đỏ','màu cam','màu vàng'],
  [2,'Pha màu vàng với màu lam được màu gì?','màu xanh lục (xanh lá)','màu cam','màu tím','màu nâu'],
  [2,'Pha màu đỏ với màu lam được màu gì?','màu tím','màu cam','màu xanh lá','màu vàng'],
  [3,'Vẽ một bức tranh phong cảnh có sử dụng đậm nhạt để tạo xa – gần.','HS vẽ cảnh có vật ở gần (đậm, rõ) và vật ở xa (nhạt, nhỏ), bố cục hợp lí.'],
 ]},
 {cd:'Mĩ thuật dân gian và thường thức',q:[
  [1,'Tranh dân gian Đông Hồ có nguồn gốc ở tỉnh nào?','Bắc Ninh','Hà Nội','Huế','Cần Thơ'],
  [2,'Tranh Đông Hồ thường được in trên loại giấy gì?','giấy dó quét điệp','giấy báo','giấy bóng kính','giấy than'],
  [2,'Bố cục bức tranh là gì?','cách sắp xếp hình ảnh chính, phụ trong tranh','màu nền của tranh','khung tranh','tên của bức tranh'],
  [3,'Giới thiệu một bức tranh hoặc sản phẩm mĩ thuật em đã làm.','HS nêu tên sản phẩm, chất liệu, nội dung, màu sắc, cảm nhận.'],
 ]},
 {cd:'Tạo hình và thủ công',q:[
  [1,'Vật liệu nào có thể tái chế để làm sản phẩm mĩ thuật?','vỏ hộp, chai nhựa, giấy báo cũ','thức ăn thừa','thủy tinh vỡ','pin cũ'],
  [2,'Khối hộp, khối cầu, khối trụ là gì?','các khối cơ bản trong mĩ thuật','các loại màu','các loại nét','các loại tranh'],
  [3,'Làm một sản phẩm đồ chơi từ vật liệu tái chế và mô tả cách làm.','HS nêu vật liệu, các bước làm, trang trí; sản phẩm chắc chắn, sáng tạo.'],
 ]}];
NH['Mĩ thuật']={1:MT_12,2:MT_12,3:MT_35,4:MT_35,5:MT_35};

/* ======================= HOẠT ĐỘNG TRẢI NGHIỆM ======================= */
const HD=(lop)=>[
 {cd:'Khám phá bản thân',q:[
  [1,'Việc nào thể hiện em biết tự chăm sóc bản thân?','tự vệ sinh cá nhân hằng ngày','chờ người khác làm hộ','không tắm rửa','ăn uống thất thường'],
  [2,'Khi gặp việc khó, em nên làm gì?','bình tĩnh suy nghĩ, nhờ người tin cậy giúp đỡ','bỏ cuộc ngay','nổi cáu','đổ lỗi cho người khác'],
  [3,lop<3?'Kể một điều em thích và một việc em làm tốt.':'Giới thiệu về sở thích và điểm mạnh của em.','HS nêu được sở thích, điểm mạnh/việc làm tốt một cách tự tin.'],
 ]},
 {cd:'Gia đình, trường lớp',q:[
  [1,'Việc nào em có thể làm để giúp đỡ gia đình?','quét nhà, rửa bát, gấp quần áo','chơi game cả ngày','đòi mua đồ chơi','làm bừa bộn nhà cửa'],
  [1,'Truyền thống tốt đẹp của nhà trường em cần làm gì?','tìm hiểu và giữ gìn, phát huy','không quan tâm','chê bai','làm mất trật tự'],
  [2,'Để xây dựng tình bạn đẹp, em cần làm gì?','chân thành, giúp đỡ, chia sẻ với bạn','nói xấu bạn','tranh giành đồ của bạn','trêu chọc bạn'],
  [3,lop<3?'Kể một việc em đã làm cùng gia đình vào ngày nghỉ.':'Lập kế hoạch một hoạt động chung của gia đình vào cuối tuần.','HS nêu hoạt động, thời gian, người tham gia, việc của em.'],
 ]},
 {cd:'Cộng đồng và môi trường',q:[
  [1,'Việc làm nào góp phần giữ gìn cảnh quan quê hương?','trồng và chăm sóc cây xanh','vứt rác bừa bãi','bẻ cành cây','viết bậy lên tường'],
  [2,'Khi tham gia hoạt động tình nguyện, em có thể làm gì?','quyên góp sách vở, quần áo cho bạn khó khăn','không tham gia','chỉ đứng xem','lấy đồ quyên góp về nhà'],
  [3,'Đề xuất một việc làm cụ thể để bảo vệ môi trường ở lớp em.','Ví dụ: phân loại rác, dùng bình nước cá nhân, chăm bồn hoa lớp…'],
 ]},
 {cd:'Nghề nghiệp',q:[
  [1,'Nghề nào chăm sóc sức khỏe cho mọi người?','bác sĩ, y tá','thợ may','lái xe','thợ mộc'],
  [2,'Vì sao chúng ta cần tôn trọng mọi nghề nghiệp?','vì mỗi nghề đều có ích cho xã hội','vì nghề nào cũng dễ','vì để được cho tiền','không cần tôn trọng'],
  [3,lop<4?'Kể về nghề nghiệp của một người thân trong gia đình em.':'Giới thiệu nghề em mơ ước và những điều em cần chuẩn bị từ bây giờ.','HS nêu tên nghề, công việc, phẩm chất cần có / việc cần chuẩn bị.'],
 ]}];
NH['Hoạt động trải nghiệm']={1:HD(1),2:HD(2),3:HD(3),4:HD(4),5:HD(5)};

/* =====================================================================
   BỔ SUNG v1.4 – thêm câu theo chủ đề, có mức 4 = NÂNG CAO (bồi dưỡng)
   Mức 4 không thuộc 3 mức của TT27; khi đưa vào đề sẽ tính là Mức 3.
   ===================================================================== */
(function(){for(const m in NH)for(const l in NH[m])NH[m][l]=NH[m][l].map(t=>({cd:t.cd,q:t.q.slice()}))})();
function them(mon,lop,cd,arr){NH[mon]=NH[mon]||{};NH[mon][lop]=NH[mon][lop]||[];let t=NH[mon][lop].find(x=>x.cd===cd);if(!t){t={cd,q:[]};NH[mon][lop].push(t)}t.q.push(...arr)}

/* ---------- TIẾNG VIỆT ---------- */
them('Tiếng Việt',1,'Âm, vần, chữ cái',[
 [1,'Tiếng "cá" có âm đầu là gì?','c','a','k','q'],
 [1,'Tiếng nào có vần "ơi"?','bơi','bai','bôi','bui'],
 [1,'Tiếng nào có thanh huyền?','bà','bá','bả','bạ'],
 [2,'Điền ng hay ngh: …ôi nhà','ng','ngh'],
 [2,'Điền c, k hay q: …uả na','q','c','k'],
 [2,'Điền ch hay tr: quả …anh','ch','tr'],
 [3,'Tìm 2 tiếng có vần "anh".','Ví dụ: xanh, chanh, bánh, cành…'],
 [4,'Ghép âm "b" với vần "ăng" và thanh huyền ta được tiếng gì? Đặt một câu có tiếng đó.','bằng – Ví dụ: Bạn Mai cao bằng bạn Lan.'],
]);
them('Tiếng Việt',1,'Đọc hiểu',[
 [1,'"Bé Hà nhặt lá rơi bỏ vào thùng rác." Bé Hà đã làm gì?','nhặt lá bỏ vào thùng rác','quét nhà','tưới cây','đọc sách'],
 [2,'"Trời mưa. Ếch con nhảy ra ao tắm." Ếch con nhảy ra đâu?','ra ao','ra vườn','lên cây','vào nhà'],
 [2,'"Cô giáo khen Nam viết chữ đẹp." Vì sao Nam được khen?','vì Nam viết chữ đẹp','vì Nam hát hay','vì Nam chạy nhanh','vì Nam đến sớm'],
 [3,'Em thích con vật nào nhất? Vì sao?','HS nêu tên con vật và lí do bằng 1–2 câu.'],
 [4,'"Gà trống gáy ò ó o. Cả nhà thức dậy." Vì sao cả nhà thức dậy?','Vì gà trống gáy báo trời sáng.'],
]);
them('Tiếng Việt',2,'Chính tả',[
 [1,'Từ nào viết đúng?','quyển vở','quyển vỡ','quiển vở','quyểng vở'],
 [2,'Điền s hay x: …ân trường','s','x'],
 [2,'Điền iu hay ưu: cây l…','ựu (cây lựu)','ịu (cây lịu)'],
 [2,'Điền ao hay au: con s…','sáo (con sáo)','sáu (con sáu)'],
 [3,'Viết lại cho đúng chính tả: "Em đi học sớm. bạn lan đi cùng em."','Em đi học sớm. Bạn Lan đi cùng em.'],
]);
them('Tiếng Việt',2,'Từ chỉ sự vật, hoạt động, đặc điểm',[
 [1,'Từ nào chỉ người?','bác sĩ','bàn ghế','chạy nhảy','xanh tươi'],
 [2,'Từ nào trái nghĩa với "nhanh"?','chậm','to','khỏe','vui'],
 [2,'Nhóm từ nào chỉ tình cảm gia đình?','yêu thương, quan tâm, chăm sóc','chạy, nhảy, bơi','xanh, đỏ, vàng','bàn, ghế, tủ'],
 [3,'Tìm 3 từ chỉ hoạt động của em ở trường.','Ví dụ: học bài, viết, đọc, chơi, múa hát…'],
 [4,'Tìm từ chỉ đặc điểm trong câu: "Mái tóc của bà bạc trắng như cước." và cho biết nó tả gì.','bạc trắng – tả màu mái tóc của bà.'],
]);
them('Tiếng Việt',2,'Câu và dấu câu',[
 [1,'Câu nào là câu hỏi?','Bạn có thích đọc truyện không?','Em thích đọc truyện.','Hãy đọc truyện đi!','Truyện hay quá!'],
 [2,'Trong câu "Trên cành cây, chú chim đang hót.", bộ phận "Trên cành cây" trả lời câu hỏi nào?','Ở đâu?','Khi nào?','Vì sao?','Là gì?'],
 [3,'Đặt một câu hỏi để hỏi bạn về món ăn bạn thích.','Ví dụ: Bạn thích ăn món gì nhất?'],
 [4,'Viết 2 câu: một câu nêu hoạt động, một câu nêu đặc điểm về chú mèo nhà em.','Ví dụ: Chú mèo đang bắt chuột. Bộ lông của chú mềm mượt.'],
]);
them('Tiếng Việt',3,'Từ chỉ sự vật, hoạt động, đặc điểm',[
 [1,'Từ nào chỉ đặc điểm của hoa?','thơm ngát','hái hoa','cánh hoa','vườn hoa'],
 [2,'Từ nào cùng nghĩa với "đất nước"?','Tổ quốc','làng xóm','gia đình','trường học'],
 [2,'Từ nào không cùng nhóm với các từ còn lại: thầy giáo, học sinh, bảng đen, cô giáo?','bảng đen','thầy giáo','học sinh','cô giáo'],
 [3,'Tìm 3 từ ngữ chỉ phẩm chất tốt của người học sinh.','Ví dụ: chăm chỉ, ngoan ngoãn, thật thà, đoàn kết…'],
 [4,'Tìm các từ chỉ đặc điểm trong câu: "Dòng sông quê em trong xanh, hiền hòa và mát rượi."','trong xanh, hiền hòa, mát rượi'],
]);
them('Tiếng Việt',3,'Biện pháp so sánh',[
 [2,'Câu "Bà em hiền như bụt." so sánh bà với ai?','bụt','mẹ','cô tiên','ông'],
 [2,'Câu nào sau đây có sử dụng hình ảnh so sánh?','Lá cờ đỏ tươi như ngọn lửa.','Lá cờ bay phấp phới.','Em chào cờ.','Lá cờ có màu đỏ.'],
 [3,'Viết tiếp để có hình ảnh so sánh: "Những ngôi sao lấp lánh như …"','Ví dụ: … những viên kim cương / những ngọn đèn nhỏ.'],
 [4,'Trong câu "Tiếng suối trong như tiếng hát xa", tiếng suối được so sánh với gì? Cách so sánh này giúp em cảm nhận được điều gì?','So sánh với tiếng hát xa; giúp cảm nhận tiếng suối trong trẻo, êm dịu, du dương.'],
]);
them('Tiếng Việt',3,'Câu và dấu câu',[
 [1,'Câu "Em đang làm bài tập." là câu gì?','câu kể','câu hỏi','câu cảm','câu khiến'],
 [2,'Dấu phẩy trong câu "Sáng nay, em dậy sớm." dùng để làm gì?','ngăn cách bộ phận chỉ thời gian với phần còn lại','kết thúc câu','báo hiệu lời nói','liệt kê'],
 [2,'Câu nào dùng đúng dấu câu?','Ôi, cảnh đẹp quá!','Ôi cảnh đẹp quá?','Ôi, cảnh đẹp quá.','Ôi. cảnh đẹp quá!'],
 [3,'Đặt một câu cảm thể hiện niềm vui khi được điểm tốt.','Ví dụ: Ôi, em vui quá!'],
]);
them('Tiếng Việt',3,'Đọc hiểu',[
 [2,'"Mùa thu, bầu trời xanh ngắt, gió heo may se se lạnh." Câu văn tả cảnh mùa nào?','mùa thu','mùa xuân','mùa hạ','mùa đông'],
 [2,'"Bạn Minh nhường chiếc bánh cuối cùng cho em." Bạn Minh là người thế nào?','biết nhường nhịn, yêu thương em','tham ăn','ích kỉ','nóng tính'],
 [3,'Nếu là bạn nhỏ trong câu chuyện "Bàn tay cô giáo", em sẽ nói gì để cảm ơn cô?','HS nêu lời cảm ơn chân thành, phù hợp.'],
 [4,'Đọc câu: "Ông mặt trời vươn vai thức dậy, rải nắng vàng khắp xóm." Em thấy hình ảnh này có gì hay?','Mặt trời được tả như con người (vươn vai, thức dậy, rải nắng) làm cảnh buổi sáng sinh động, gần gũi.'],
]);
them('Tiếng Việt',4,'Danh từ, động từ, tính từ',[
 [1,'Từ nào là danh từ chỉ hiện tượng tự nhiên?','cơn mưa','chạy','đẹp','vui'],
 [2,'Trong câu "Bầy chim ríu rít hót trên cành.", động từ là từ nào?','hót','bầy chim','ríu rít','cành'],
 [2,'Từ nào là tính từ chỉ màu sắc?','xanh biếc','cánh đồng','gặt lúa','nông dân'],
 [3,'Tìm 2 danh từ, 2 động từ, 2 tính từ trong câu: "Các bạn học sinh chăm chỉ tưới những bồn hoa đỏ thắm."','Danh từ: học sinh, bồn hoa; động từ: tưới; tính từ: chăm chỉ, đỏ thắm (HS nêu đúng các từ có trong câu).'],
 [4,'Từ "vàng" trong hai câu sau thuộc từ loại gì? (a) Lúa chín vàng. (b) Mẹ mua một chiếc nhẫn vàng.','(a) tính từ chỉ màu sắc; (b) danh từ chỉ chất liệu (kim loại vàng) – HS giải thích hợp lí.'],
]);
them('Tiếng Việt',4,'Câu: chủ ngữ, vị ngữ, trạng ngữ',[
 [2,'Chủ ngữ trong câu "Tiếng trống trường vang lên rộn rã." là gì?','Tiếng trống trường','vang lên','rộn rã','trống'],
 [2,'Trạng ngữ "Để có sức khỏe tốt" chỉ gì?','mục đích','thời gian','nơi chốn','nguyên nhân'],
 [3,'Thêm trạng ngữ chỉ nơi chốn cho câu: "Các bạn đang chơi đá cầu."','Ví dụ: Trên sân trường, các bạn đang chơi đá cầu.'],
 [4,'Câu "Mùa xuân, trăm hoa đua nở, chim chóc hót vang." có mấy chủ ngữ, mấy vị ngữ? Chỉ ra.','Hai cụm chủ – vị: trăm hoa / đua nở; chim chóc / hót vang; "Mùa xuân" là trạng ngữ.'],
]);
them('Tiếng Việt',4,'Biện pháp nhân hóa',[
 [2,'Câu nào có biện pháp nhân hóa?','Ông mặt trời mỉm cười với em.','Mặt trời mọc ở phía đông.','Trời nắng to.','Em đội mũ khi đi nắng.'],
 [2,'Từ ngữ nào trong câu "Cô mây xinh đẹp dạo chơi trên trời." cho thấy mây được nhân hóa?','cô, xinh đẹp, dạo chơi','trên trời','mây','trời'],
 [4,'Viết 2–3 câu tả cơn mưa, trong đó có dùng biện pháp nhân hóa.','HS dùng từ chỉ người/hoạt động của người cho cơn mưa (ví dụ: chị mưa nhảy múa trên mái nhà…).'],
]);
them('Tiếng Việt',4,'Đọc hiểu',[
 [2,'"Dù trời mưa to, chú bộ đội vẫn đứng gác nghiêm trang." Câu văn ca ngợi điều gì?','tinh thần trách nhiệm của chú bộ đội','trời mưa to','bộ quân phục','tiếng mưa'],
 [3,'Câu tục ngữ "Có công mài sắt, có ngày nên kim" khuyên em điều gì? Nêu một việc em sẽ làm theo lời khuyên đó.','Kiên trì, nhẫn nại sẽ thành công; HS nêu việc cụ thể (luyện viết chữ đẹp mỗi ngày…).'],
 [4,'Em hiểu thế nào về câu: "Học thầy không tày học bạn"?','Học hỏi từ bạn bè cũng rất quan trọng, có khi học được nhiều điều bổ ích.'],
]);
them('Tiếng Việt',5,'Từ đồng nghĩa, từ đa nghĩa',[
 [1,'Từ nào trái nghĩa với "dũng cảm"?','hèn nhát','gan dạ','anh hùng','can đảm'],
 [2,'Từ "chạy" trong câu nào mang nghĩa chuyển?','Đồng hồ chạy đúng giờ.','Em chạy ra sân.','Bạn Nam chạy rất nhanh.','Con ngựa chạy phi nước đại.'],
 [2,'Nhóm từ nào gồm các từ đồng nghĩa?','siêng năng, chăm chỉ, cần cù','đẹp, xấu, cao','to, nhỏ, dài','vui, buồn, giận'],
 [3,'Đặt câu có cặp từ trái nghĩa "lên – xuống".','Ví dụ: Thủy triều lên xuống mỗi ngày.'],
 [4,'Phân biệt nghĩa của từ "đầu" trong: (a) Em đội mũ lên đầu. (b) Nhà em ở đầu làng.','(a) nghĩa gốc: bộ phận cơ thể; (b) nghĩa chuyển: phần trước, vị trí bắt đầu của làng.'],
]);
them('Tiếng Việt',5,'Câu ghép và liên kết câu',[
 [2,'Cặp quan hệ từ "Nếu … thì …" biểu thị quan hệ gì?','điều kiện – kết quả','nguyên nhân – kết quả','tương phản','tăng tiến'],
 [2,'Câu ghép "Vì trời mưa to nên trận đấu bị hoãn." có quan hệ gì giữa hai vế?','nguyên nhân – kết quả','tương phản','điều kiện – kết quả','tăng tiến'],
 [3,'Đặt một câu ghép có cặp quan hệ từ "Không những … mà còn …".','Ví dụ: Lan không những học giỏi mà còn hát hay.'],
 [4,'Viết đoạn văn 3–4 câu về chủ đề "Bảo vệ môi trường", trong đó có ít nhất một câu ghép và chỉ ra câu ghép đó.','Đoạn văn đúng chủ đề; có câu ghép đúng ngữ pháp và được gạch chân.'],
]);
them('Tiếng Việt',5,'Đọc hiểu',[
 [2,'Câu tục ngữ "Lá lành đùm lá rách" khuyên chúng ta điều gì?','đùm bọc, giúp đỡ người gặp khó khăn','giữ gìn lá cây','tiết kiệm','chăm chỉ học tập'],
 [3,'Theo em, người học sinh cần làm gì để xứng đáng là "chủ nhân tương lai của đất nước"?','HS nêu ý: học tập tốt, rèn luyện đạo đức, sức khỏe, yêu quê hương, bảo vệ môi trường…'],
 [4,'Viết 3–4 câu nêu suy nghĩ của em về ý nghĩa của việc đọc sách mỗi ngày.','Nêu được ý kiến rõ ràng, có lí lẽ (mở mang hiểu biết, rèn chữ, nuôi dưỡng tâm hồn) và ví dụ.'],
]);
them('Tiếng Việt',5,'Đại từ, kết từ',[
 [2,'Đại từ xưng hô nào dùng để chỉ người nói?','tôi, chúng tôi','bạn, các bạn','nó, họ','ông ấy'],
 [2,'Từ "của" trong câu "Đây là chiếc cặp của em." là gì?','kết từ (quan hệ từ)','danh từ','động từ','tính từ'],
 [4,'Thay từ ngữ "Con mèo" ở câu thứ hai bằng một đại từ thích hợp: "Con mèo nhà em rất lười. Con mèo suốt ngày nằm sưởi nắng."','Nó suốt ngày nằm sưởi nắng.'],
]);

/* ---------- TOÁN (câu thực tế, hình học, đo lường) ---------- */
them('Toán',1,'Hình học và đo lường',[
 [1,'Quả bóng có dạng hình gì?','khối cầu (hình tròn)','khối hộp','hình tam giác','hình vuông'],
 [2,'Bút chì dài hơn cục tẩy hay ngắn hơn?','dài hơn','ngắn hơn','bằng nhau'],
 [2,'Một tuần em đi học từ thứ Hai đến thứ Sáu. Em đi học mấy ngày?','5 ngày','7 ngày','6 ngày','4 ngày'],
 [4,'Hình vuông có 4 cạnh. Hai hình vuông rời nhau có tất cả bao nhiêu cạnh?','8 cạnh','4 cạnh','6 cạnh','10 cạnh'],
]);
them('Toán',2,'Hình học và đo lường',[
 [1,'Đường gấp khúc gồm 3 đoạn thẳng, mỗi đoạn dài 5 cm. Đường gấp khúc dài bao nhiêu?','15 cm','8 cm','10 cm','20 cm'],
 [2,'Lúc 7 giờ sáng em đến trường, 11 giờ trưa em về. Em ở trường bao nhiêu giờ?','4 giờ','3 giờ','5 giờ','18 giờ'],
 [2,'Một con gà nặng 2 kg, một con vịt nặng 3 kg. Cả hai con nặng bao nhiêu?','5 kg','1 kg','6 kg','23 kg'],
 [4,'Hôm nay là thứ Tư ngày 10. Thứ Tư tuần sau là ngày bao nhiêu?','ngày 17','ngày 11','ngày 16','ngày 20'],
]);
them('Toán',3,'Hình học và đo lường',[
 [1,'Hình vuông có mấy góc vuông?','4 góc vuông','2 góc vuông','3 góc vuông','không có'],
 [2,'Một năm có mấy tháng có 31 ngày?','7 tháng','6 tháng','5 tháng','12 tháng'],
 [2,'Lan uống 250 ml sữa buổi sáng và 250 ml buổi tối. Lan uống tất cả bao nhiêu mi-li-lít sữa?','500 ml','250 ml','1 000 ml','400 ml'],
 [3,'Một cái sân hình vuông có cạnh 9 m. Tính chu vi cái sân.','9 × 4 = 36 (m)'],
 [4,'Một hình chữ nhật có chiều dài 8 cm, chiều rộng bằng nửa chiều dài. Tính diện tích hình chữ nhật.','Chiều rộng 4 cm; diện tích 8 × 4 = 32 (cm²)'],
]);
them('Toán',4,'Hình học và đo lường',[
 [1,'Góc tù lớn hơn góc vuông và bé hơn góc nào?','góc bẹt','góc nhọn','góc vuông','không có'],
 [2,'Năm 2026 thuộc thế kỉ XXI. Năm 1999 thuộc thế kỉ nào?','thế kỉ XX','thế kỉ XIX','thế kỉ XXI','thế kỉ XVIII'],
 [2,'Một xe tải chở 3 tấn gạo, đã dỡ xuống 1 200 kg. Hỏi trên xe còn bao nhiêu ki-lô-gam gạo?','1 800 kg','2 800 kg','1 200 kg','4 200 kg'],
 [4,'Lớp em lát nền bằng gạch hình vuông cạnh 5 dm. Nền lớp hình chữ nhật dài 8 m, rộng 6 m. Cần bao nhiêu viên gạch?','Diện tích nền 48 m² = 4 800 dm²; mỗi viên 25 dm²; cần 4 800 : 25 = 192 viên.'],
]);
them('Toán',5,'Hình học và đo lường',[
 [1,'Hình thang có mấy cặp cạnh đối diện song song?','1 cặp','2 cặp','không có','3 cặp'],
 [2,'1 tấn bằng bao nhiêu tạ?','10 tạ','100 tạ','1 000 tạ','5 tạ'],
 [2,'Thể tích của một bể nước dạng hình hộp chữ nhật dài 2 m, rộng 1 m, cao 1 m là bao nhiêu?','2 m³','3 m³','4 m³','1 m³'],
 [3,'Bánh xe đạp có đường kính 0,6 m. Khi bánh xe lăn được 1 vòng thì xe đi được bao nhiêu mét?','0,6 × 3,14 = 1,884 (m)'],
 [4,'Một bể cá hình hộp chữ nhật dài 80 cm, rộng 50 cm, cao 40 cm. Mực nước bằng 3/4 chiều cao bể. Tính thể tích nước trong bể (lít).','Chiều cao nước 30 cm; thể tích 80 × 50 × 30 = 120 000 cm³ = 120 lít.'],
]);

/* ---------- TIẾNG ANH ---------- */
them('Tiếng Anh',1,'Greetings & Colours',[
 [1,'"Goodbye" nghĩa là gì?','tạm biệt','xin chào','cảm ơn','xin lỗi'],
 [1,'"Green" là màu gì?','màu xanh lá','màu đỏ','màu tím','màu nâu'],
 [2,'Chọn câu đáp lại khi bạn nói "Thank you.":','You\'re welcome.','Hello.','I\'m six.','Red.'],
]);
them('Tiếng Anh',1,'Numbers & Animals',[
 [1,'Số "five" là số mấy?','5','4','6','9'],
 [1,'"Bird" là con gì?','con chim','con cá','con chó','con mèo'],
 [2,'Có bao nhiêu con mèo: "two cats"?','2','1','3','4'],
]);
them('Tiếng Anh',2,'School & Family',[
 [1,'"Book" nghĩa là gì?','quyển sách','cái bút','cái bàn','cái ghế'],
 [1,'"Sister" nghĩa là ai?','chị/em gái','anh/em trai','bố','ông'],
 [2,'Hoàn thành: "This is my … " (cặp sách)','school bag','school','bag school','schools bag'],
 [3,'Viết 2 câu giới thiệu thành viên gia đình em bằng tiếng Anh.','Ví dụ: This is my mother. This is my brother.'],
]);
them('Tiếng Anh',2,'Food & Toys',[
 [1,'"Milk" là gì?','sữa','nước','cơm','bánh'],
 [2,'Chọn câu đúng nói "Tôi có một con búp bê":','I have a doll.','I has a doll.','I have doll a.','I a doll have.'],
]);
them('Tiếng Anh',3,'Hello – Friends – Body',[
 [1,'"Hand" là bộ phận nào?','bàn tay','bàn chân','cái đầu','cái mũi'],
 [1,'"Nice to meet you." nghĩa là gì?','Rất vui được gặp bạn.','Hẹn gặp lại.','Bạn khỏe không?','Cảm ơn bạn.'],
 [2,'Hoàn thành: "… is your name?"','What','Who','How','Where'],
 [2,'Chọn câu đúng: "Touch your …!" (mũi)','nose','nosy','noses is','a nose is'],
 [4,'Sắp xếp thành câu đúng: "is / friend / This / my / Mai"','This is my friend Mai.'],
]);
them('Tiếng Anh',3,'School – Classroom',[
 [1,'"Eraser / rubber" nghĩa là gì?','cục tẩy','thước kẻ','gọt bút chì','hộp bút'],
 [2,'Chọn câu trả lời đúng: "What are these?"','They\'re pencils.','It\'s a pencil.','Yes, they are pencil.','This is pencils.'],
 [2,'Hoàn thành: "Let\'s … football." ','play','plays','playing','to play'],
 [3,'Viết câu hỏi và trả lời về đồ dùng học tập: "Bạn có thước kẻ không?"','Do you have a ruler? – Yes, I do. / No, I don\'t.'],
 [4,'Chọn từ khác loại: pen, ruler, cat, book','cat','pen','ruler','book'],
]);
them('Tiếng Anh',3,'Family – House – Pets',[
 [1,'"Bedroom" là phòng nào?','phòng ngủ','phòng bếp','phòng tắm','phòng khách'],
 [2,'Chọn câu trả lời đúng: "How old is your sister?"','She\'s seven.','She\'s my sister.','He\'s seven.','I\'m seven.'],
 [2,'Hoàn thành: "Where is the cat? – It\'s … the table." (ở dưới)','under','in','on','at'],
 [4,'Viết 3 câu tả căn phòng của em bằng tiếng Anh.','Ví dụ: This is my bedroom. There is a bed. There are two chairs.'],
]);
them('Tiếng Anh',4,'Friends – Time – Daily routines',[
 [1,'"Seven o\'clock" là mấy giờ?','7 giờ','7 giờ 30','11 giờ','17 giờ'],
 [2,'Chọn câu trả lời đúng: "What day is it today?"','It\'s Friday.','It\'s ten o\'clock.','It\'s sunny.','It\'s in May.'],
 [2,'Hoàn thành: "She … breakfast at six thirty."','has','have','having','to have'],
 [3,'Viết 2 câu nói về các ngày em học tiếng Anh.','Ví dụ: I have English on Monday and Thursday.'],
 [4,'Tìm lỗi sai và sửa: "He get up at six o\'clock."','get → gets (He gets up at six o\'clock.)'],
]);
them('Tiếng Anh',4,'Birthday – Abilities – Subjects',[
 [1,'"Art" là môn học nào?','Mĩ thuật','Âm nhạc','Thể dục','Tin học'],
 [2,'Hoàn thành: "My birthday is … June."','in','on','at','to'],
 [2,'Chọn câu trả lời đúng: "Can she dance?"','Yes, she can.','Yes, she does.','Yes, she is.','Yes, she dance.'],
 [4,'Tìm lỗi sai và sửa: "I can swims very well."','swims → swim (I can swim very well.)'],
]);
them('Tiếng Anh',4,'Home – Jobs – Weekend',[
 [1,'"Nurse" là nghề gì?','y tá','phi công','đầu bếp','ca sĩ'],
 [2,'Chọn câu trả lời đúng: "Where does your mother work?"','She works in a hospital.','She is a nurse work.','She works hospital in.','She work at a hospital.'],
 [2,'Hoàn thành: "What do you do at the weekend? – I … my grandparents."','visit','visits','visiting','to visit'],
 [4,'Viết 3 câu kể về việc em thường làm vào cuối tuần.','Ví dụ: At the weekend, I help my mother. I play football. I read books.'],
]);
them('Tiếng Anh',5,'About me – Home – Friends',[
 [1,'"Village" nghĩa là gì?','làng quê','thành phố','thị trấn','đường phố'],
 [2,'Chọn câu trả lời đúng: "What\'s your village like?"','It\'s quiet and beautiful.','It\'s in Hai Phong.','I like it.','It\'s my house.'],
 [2,'Hoàn thành: "Mai is from Viet Nam. She is …"','Vietnamese','Viet Nam','Vietnam\'s','a Vietnamese is'],
 [4,'Tìm lỗi sai và sửa: "My friend live in a big city."','live → lives'],
]);
them('Tiếng Anh',5,'Future job – School activities',[
 [1,'"Engineer" là nghề gì?','kĩ sư','nông dân','bác sĩ','họa sĩ'],
 [2,'Hoàn thành: "What subject do you like best? – I like … best."','Maths','play','teacher','Monday'],
 [2,'Chọn câu trả lời đúng: "How often do you have English?"','Four times a week.','At seven o\'clock.','On the table.','By bus.'],
 [4,'Viết 3 câu giới thiệu nghề em mơ ước và lí do (dùng "I\'d like to be…", "because…").','Ví dụ: I\'d like to be a teacher because I want to teach children.'],
]);
them('Tiếng Anh',5,'Holidays – Health – Weather',[
 [1,'"Cold" nghĩa là gì?','lạnh','nóng','mưa','gió'],
 [2,'Thì quá khứ của "eat" là gì?','ate','eated','eaten','eating'],
 [2,'Hoàn thành: "You shouldn\'t … too many sweets."','eat','eats','eating','ate'],
 [2,'Chọn câu trả lời đúng: "What\'s the weather like in winter?"','It\'s cold.','It\'s my winter.','I like winter.','In December.'],
 [4,'Tìm lỗi sai và sửa: "Yesterday I go to the park with my family."','go → went'],
]);
them('Tiếng Anh',5,'Transport – Places',[
 [1,'"Train" là phương tiện gì?','tàu hỏa','máy bay','xe đạp','thuyền'],
 [2,'Chọn câu trả lời đúng: "How did you get there?"','I went by plane.','I go to there.','It was fun.','Yesterday.'],
 [4,'Viết 3 câu kể về chuyến đi gần đây của em (nơi đến, phương tiện, cảm nhận).','Ví dụ: Last month, I went to Da Lat by coach. It was beautiful. I liked the flowers.'],
]);

/* ---------- KHOA HỌC ---------- */
them('Khoa học',4,'Chất: nước và không khí',[
 [1,'Ở điều kiện bình thường, nước sôi ở bao nhiêu độ C?','100 °C','0 °C','50 °C','37 °C'],
 [1,'Nước đông đặc thành nước đá ở bao nhiêu độ C?','0 °C','100 °C','10 °C','37 °C'],
 [2,'Hiện tượng hơi nước gặp lạnh biến thành những giọt nước nhỏ gọi là gì?','sự ngưng tụ','sự bay hơi','sự đông đặc','sự nóng chảy'],
 [2,'Vì sao quạt điện làm ta thấy mát?','vì làm không khí chuyển động, mồ hôi bay hơi nhanh hơn','vì quạt tạo ra hơi lạnh','vì quạt hút hết nhiệt','vì quạt phun nước'],
 [3,'Kể 3 việc làm tiết kiệm nước ở trường và ở nhà.','Ví dụ: khóa vòi khi không dùng, dùng nước vo gạo tưới cây, báo sửa vòi rò rỉ…'],
 [4,'Vì sao vào mùa đông, cửa kính trong nhà thường bị mờ hơi nước ở mặt trong?','Hơi nước trong không khí ấm trong phòng gặp mặt kính lạnh nên ngưng tụ thành các giọt nước nhỏ.'],
]);
them('Khoa học',4,'Năng lượng: ánh sáng, âm thanh, nhiệt',[
 [1,'Âm thanh được tạo ra từ đâu?','từ các vật đang rung động','từ ánh sáng','từ bóng tối','từ nhiệt độ'],
 [2,'Bóng của vật xuất hiện khi nào?','khi vật cản ánh sáng chiếu tới','khi không có ánh sáng','khi vật trong suốt','khi trời mưa'],
 [2,'Vì sao cán xoong, nồi thường làm bằng nhựa hoặc gỗ?','vì nhựa, gỗ dẫn nhiệt kém, cầm không bị nóng','vì nhựa, gỗ đẹp hơn','vì nhựa, gỗ nặng hơn','vì nhựa, gỗ dẫn nhiệt tốt'],
 [3,'Nêu 2 việc nên làm để bảo vệ đôi mắt khi đọc sách, xem ti vi.','Ví dụ: đọc nơi đủ ánh sáng, ngồi cách màn hình xa, nghỉ mắt sau 30–45 phút, không nhìn thẳng vào Mặt Trời…'],
 [4,'Tại sao ta thấy tia chớp trước rồi mới nghe tiếng sấm?','Vì ánh sáng truyền đi nhanh hơn âm thanh rất nhiều.'],
]);
them('Khoa học',4,'Thực vật, động vật và nấm',[
 [1,'Động vật cần gì để sống?','thức ăn, nước, không khí, ánh sáng, nhiệt độ thích hợp','chỉ cần nước','chỉ cần ánh sáng','không cần gì'],
 [2,'Nấm men được dùng để làm gì?','làm bánh mì, lên men','làm thuốc diệt cỏ','làm phân bón hóa học','làm giấy'],
 [2,'Vì sao cây trồng trong bóng tối lâu ngày sẽ yếu và vàng lá?','vì thiếu ánh sáng để quang hợp','vì thừa nước','vì thừa ánh sáng','vì đất quá tốt'],
 [3,'Nêu 2 việc em làm để chăm sóc vật nuôi trong gia đình.','Ví dụ: cho ăn uống đủ, giữ chuồng sạch, tiêm phòng, cho vận động…'],
 [4,'Thiết kế thí nghiệm đơn giản chứng minh cây cần ánh sáng để sống.','Trồng 2 cây giống nhau, chăm sóc như nhau; một cây để nơi có ánh sáng, một cây để trong hộp kín tối; sau 1–2 tuần so sánh.'],
]);
them('Khoa học',4,'Con người và sức khỏe',[
 [1,'Nhóm thức ăn nào chứa nhiều chất đạm?','thịt, cá, trứng, đậu','gạo, bánh mì','rau xanh','dầu ăn'],
 [2,'Vì sao cần ăn nhiều loại thức ăn khác nhau?','để cơ thể được cung cấp đủ các chất dinh dưỡng','để ăn ngon hơn','để no lâu','để tiết kiệm tiền'],
 [2,'Dấu hiệu nào cho thấy thực phẩm không an toàn?','có mùi lạ, đổi màu, quá hạn sử dụng','còn tươi, có nguồn gốc rõ ràng','được bảo quản lạnh','được nấu chín'],
 [3,'Nêu 3 điều cần làm để phòng tránh đuối nước.','Không chơi gần ao hồ, sông suối; chỉ bơi khi có người lớn giám sát; học bơi; mặc áo phao khi đi thuyền…'],
]);
them('Khoa học',4,'Sinh vật và môi trường',[
 [2,'Trong chuỗi thức ăn "Lá rau → Sâu → Chim sâu", nếu chim sâu bị săn bắt hết thì điều gì xảy ra?','sâu sẽ phát triển nhiều, phá hại rau','rau sẽ tốt hơn','sâu sẽ hết','không có gì thay đổi'],
 [4,'Vì sao không nên dùng quá nhiều thuốc trừ sâu trên đồng ruộng?','Gây ô nhiễm đất, nước, giết cả sinh vật có ích, ảnh hưởng sức khỏe con người qua chuỗi thức ăn.'],
]);
them('Khoa học',5,'Chất',[
 [1,'Trường hợp nào sau đây là sự biến đổi hóa học?','đinh sắt để lâu ngoài không khí bị gỉ','nước đá tan','xé giấy','hòa tan muối vào nước'],
 [2,'Khi hòa tan đường vào nước, ta được gì?','dung dịch nước đường','hỗn hợp không tan','chất rắn mới','nước tinh khiết'],
 [2,'Để tách muối ra khỏi dung dịch nước muối, ta làm thế nào?','đun cho nước bay hơi hết (hoặc phơi nắng)','lọc qua giấy','để lắng','khuấy đều'],
 [3,'Kể 2 nguyên nhân làm đất bị ô nhiễm và cách khắc phục.','Ví dụ: rác thải nhựa, thuốc trừ sâu quá mức; phân loại rác, dùng phân hữu cơ…'],
 [4,'Vì sao người ta sơn lên cửa sắt, hàng rào sắt?','Để ngăn sắt tiếp xúc với không khí và hơi nước, chống gỉ.'],
]);
them('Khoa học',5,'Năng lượng',[
 [1,'Vật nào không dẫn điện (vật cách điện)?','chiếc thìa nhựa','dây đồng','đinh sắt','giấy bạc nhôm'],
 [2,'Pin mặt trời biến năng lượng mặt trời thành dạng năng lượng nào?','năng lượng điện','năng lượng âm thanh','chất đốt','năng lượng gió'],
 [2,'Trong mạch điện, công tắc dùng để làm gì?','đóng, ngắt dòng điện','tạo ra điện','làm sáng đèn mạnh hơn','đo dòng điện'],
 [3,'Nêu 3 việc học sinh có thể làm để tiết kiệm điện.','Ví dụ: tắt đèn, quạt khi ra khỏi phòng; tận dụng ánh sáng tự nhiên; rút sạc khi không dùng…'],
 [4,'Vì sao nên dùng bóng đèn LED thay cho bóng đèn sợi đốt?','Đèn LED tiêu thụ ít điện năng hơn, ít tỏa nhiệt, bền hơn nên tiết kiệm điện.'],
]);
them('Khoa học',5,'Thực vật và động vật',[
 [1,'Bộ phận nào của hoa sẽ phát triển thành quả?','bầu nhụy','cánh hoa','đài hoa','cuống hoa'],
 [2,'Con vật nào giúp hoa thụ phấn?','con ong','con mèo','con cá','con gà'],
 [2,'Cây nào thường được trồng bằng cách giâm cành?','cây sắn (khoai mì)','cây lúa','cây ngô','cây đậu'],
 [4,'Vì sao cần bảo vệ các loài ong?','Ong giúp hoa thụ phấn để cây ra quả, hạt; góp phần duy trì sự sống của nhiều loài và cung cấp mật.'],
]);
them('Khoa học',5,'Vi khuẩn',[
 [1,'Bệnh nào do vi khuẩn gây ra?','bệnh lao','bệnh cận thị','bệnh béo phì','bệnh bướu cổ do thiếu i-ốt'],
 [2,'Vì sao cần rửa tay bằng xà phòng trước khi ăn?','để loại bỏ vi khuẩn gây bệnh','để tay thơm','để tay mềm','để tay trắng hơn'],
 [4,'Vì sao thức ăn để lâu ngoài không khí dễ bị ôi thiu?','Vì vi khuẩn phát triển trong thức ăn, làm thức ăn bị hỏng.'],
]);
them('Khoa học',5,'Sinh vật và môi trường',[
 [2,'Việc làm nào góp phần giảm rác thải nhựa?','dùng túi vải, bình nước cá nhân','dùng ống hút nhựa mỗi ngày','đốt túi ni lông','vứt chai nhựa xuống sông'],
 [3,'Nêu 2 tác hại của việc phá rừng.','Ví dụ: lũ lụt, sạt lở đất, mất nơi sống của động vật, khí hậu thay đổi…'],
 [4,'Lập kế hoạch một tuần "Lớp học xanh" của lớp em.','Nêu mục tiêu, các việc làm cụ thể theo ngày (phân loại rác, chăm cây, tiết kiệm điện nước), người phụ trách, cách đánh giá.'],
]);

/* ---------- LỊCH SỬ VÀ ĐỊA LÍ ---------- */
them('Lịch sử và Địa lí',4,'Trung du và miền núi Bắc Bộ',[
 [1,'Dãy núi cao nhất nước ta là dãy núi nào?','Hoàng Liên Sơn','Trường Sơn','Bạch Mã','Ngân Sơn'],
 [2,'Cây công nghiệp nào được trồng nhiều ở vùng trung du Bắc Bộ?','chè','cà phê','cao su','hồ tiêu'],
 [2,'Lễ hội Đền Hùng nhằm tưởng nhớ ai?','các Vua Hùng – những người có công dựng nước','Hai Bà Trưng','Lý Thái Tổ','Quang Trung'],
 [4,'Câu "Dù ai đi ngược về xuôi, nhớ ngày giỗ Tổ mùng mười tháng ba" nhắc nhở chúng ta điều gì?','Luôn nhớ về cội nguồn, biết ơn các Vua Hùng đã có công dựng nước.'],
]);
them('Lịch sử và Địa lí',4,'Đồng bằng Bắc Bộ',[
 [1,'Năm 1010, vua Lý Thái Tổ dời đô ra đâu?','Thăng Long','Hoa Lư','Cổ Loa','Phú Xuân'],
 [2,'Hoàng thành Thăng Long được UNESCO công nhận là gì?','Di sản văn hóa thế giới','Di sản thiên nhiên thế giới','Khu dự trữ sinh quyển','Công viên địa chất'],
 [2,'Đồng bằng Bắc Bộ có đặc điểm địa hình như thế nào?','khá bằng phẳng, có nhiều sông ngòi','nhiều núi cao','toàn cao nguyên','nhiều cồn cát'],
 [3,'Nêu 2 nghề thủ công truyền thống ở đồng bằng Bắc Bộ.','Ví dụ: làm gốm (Bát Tràng), dệt lụa (Vạn Phúc), làm tranh Đông Hồ…'],
 [4,'Vì sao vua Lý Thái Tổ chọn Thăng Long làm kinh đô?','Vùng đất rộng, bằng phẳng, ở trung tâm đất nước, giao thông thuận lợi, dân cư đông đúc (HS nêu ý hợp lí).'],
]);
them('Lịch sử và Địa lí',4,'Duyên hải miền Trung',[
 [1,'Đèo nào nổi tiếng nằm giữa thành phố Huế và thành phố Đà Nẵng?','đèo Hải Vân','đèo Ngang','đèo Pha Đin','đèo Cả'],
 [2,'Nghề nào phát triển ở các vùng ven biển miền Trung?','đánh bắt hải sản, làm muối','trồng chè','trồng cà phê','khai thác than'],
 [2,'Kinh thành Huế là kinh đô của triều đại nào?','nhà Nguyễn','nhà Lý','nhà Trần','nhà Lê'],
 [4,'Người dân miền Trung đã làm gì để thích ứng với bão, lũ?','Trồng rừng phòng hộ, xây nhà kiên cố, chằng chống nhà cửa, theo dõi dự báo thời tiết, di dời đến nơi an toàn…'],
]);
them('Lịch sử và Địa lí',4,'Tây Nguyên',[
 [1,'Đà Lạt nằm trên cao nguyên nào?','Lâm Viên','Kon Tum','Pleiku','Đắk Lắk'],
 [2,'Nhà rông ở Tây Nguyên dùng để làm gì?','sinh hoạt cộng đồng, tổ chức lễ hội','để ở riêng từng gia đình','để chăn nuôi','để buôn bán'],
 [3,'Nêu 2 việc cần làm để giữ gìn Không gian văn hóa Cồng chiêng Tây Nguyên.','Ví dụ: truyền dạy cho thế hệ trẻ, tổ chức lễ hội, giới thiệu với du khách…'],
]);
them('Lịch sử và Địa lí',4,'Nam Bộ',[
 [1,'Chợ nổi Cái Răng nằm ở thành phố nào?','Cần Thơ','Hà Nội','Đà Nẵng','Huế'],
 [2,'Bến Nhà Rồng (Thành phố Hồ Chí Minh) gắn với sự kiện nào?','Bác Hồ ra đi tìm đường cứu nước năm 1911','Bác Hồ đọc Tuyên ngôn Độc lập','Chiến thắng Điện Biên Phủ','Thành lập Đảng'],
 [2,'Vì sao đồng bằng sông Cửu Long trồng được nhiều lúa và cây ăn quả?','đất phù sa màu mỡ, khí hậu nóng ẩm, nhiều sông ngòi','đất đỏ ba-dan','khí hậu lạnh','nhiều núi cao'],
 [4,'Vì sao Thành phố Hồ Chí Minh là trung tâm kinh tế lớn nhất cả nước?','Vị trí thuận lợi, giao thông phát triển (cảng, sân bay), dân cư đông, nhiều nhà máy, trung tâm thương mại…'],
]);
them('Lịch sử và Địa lí',5,'Đất nước và con người Việt Nam',[
 [1,'Thủ đô của nước Cộng hòa xã hội chủ nghĩa Việt Nam là thành phố nào?','Hà Nội','Thành phố Hồ Chí Minh','Huế','Đà Nẵng'],
 [1,'Biển nước ta là một phần của biển nào?','Biển Đông','Biển Đỏ','Biển Đen','Biển Bắc'],
 [2,'Dân tộc nào có số dân đông nhất nước ta?','dân tộc Kinh','dân tộc Tày','dân tộc Thái','dân tộc Mường'],
 [2,'Dân cư nước ta tập trung đông đúc ở đâu?','các đồng bằng và thành phố lớn','vùng núi cao','hải đảo xa','cao nguyên'],
 [4,'Vì sao nói Việt Nam có vị trí thuận lợi để giao lưu với các nước?','Nằm ở Đông Nam Á, có đường bờ biển dài, giáp Biển Đông, nằm trên đường giao thông biển, hàng không quốc tế quan trọng.'],
]);
them('Lịch sử và Địa lí',5,'Xây dựng và bảo vệ đất nước',[
 [1,'Hai Bà Trưng khởi nghĩa vào năm nào?','năm 40','năm 938','năm 1010','năm 1288'],
 [1,'Ai là tác giả "Bình Ngô đại cáo"?','Nguyễn Trãi','Lý Thường Kiệt','Trần Hưng Đạo','Ngô Quyền'],
 [2,'Lý Thường Kiệt chỉ huy trận chiến trên sông Như Nguyệt chống quân xâm lược nào?','quân Tống','quân Nguyên','quân Minh','quân Thanh'],
 [2,'Đảng Cộng sản Việt Nam được thành lập vào ngày nào?','3/2/1930','2/9/1945','19/5/1890','30/4/1975'],
 [2,'Công cuộc Đổi mới ở nước ta bắt đầu từ năm nào?','1986','1975','1954','2000'],
 [3,'Kể tên 3 anh hùng dân tộc em biết và một việc làm nổi bật của mỗi người.','Ví dụ: Ngô Quyền – chiến thắng Bạch Đằng 938; Trần Hưng Đạo – đánh thắng quân Mông – Nguyên; Quang Trung – đại phá quân Thanh 1789…'],
 [4,'Vì sao Ngô Quyền cho cắm cọc gỗ dưới lòng sông Bạch Đằng?','Lợi dụng thủy triều: khi nước lên che lấp cọc, nhử thuyền giặc vào; khi nước rút, thuyền giặc mắc cọc, bị đánh tan.'],
]);
them('Lịch sử và Địa lí',5,'Các nước láng giềng và thế giới',[
 [1,'Thủ đô của nước Lào là thành phố nào?','Viêng Chăn','Phnôm Pênh','Băng Cốc','Bắc Kinh'],
 [1,'Công trình kiến trúc nổi tiếng Ăng-co Vát thuộc nước nào?','Cam-pu-chia','Lào','Thái Lan','Trung Quốc'],
 [2,'Việt Nam gia nhập ASEAN vào năm nào?','1995','1967','1986','2007'],
 [2,'Châu lục nào lớn nhất thế giới?','châu Á','châu Phi','châu Âu','châu Đại Dương'],
 [4,'Là học sinh, em có thể làm gì để góp phần xây dựng "thế giới xanh – sạch – đẹp"?','Tiết kiệm điện nước, trồng cây, phân loại rác, hạn chế đồ nhựa, tuyên truyền cho người thân…'],
]);

/* ---------- ĐẠO ĐỨC ---------- */
them('Đạo đức',1,'Gia đình và nhà trường',[
 [1,'Khi được người khác cho quà, em nên làm gì?','nhận bằng hai tay và nói lời cảm ơn','giật lấy','không nói gì','chê quà'],
 [2,'Bạn quên mang bút, em có thể làm gì?','cho bạn mượn bút','cười bạn','mách cô ngay','không quan tâm'],
 [3,'Kể một việc em đã tự giác làm mà không cần ai nhắc.','HS kể việc cụ thể: tự soạn sách vở, tự gấp chăn…'],
]);
them('Đạo đức',2,'Quê hương, thầy cô, bạn bè',[
 [1,'Ngày 20 tháng 11 là ngày gì?','Ngày Nhà giáo Việt Nam','Ngày Quốc khánh','Ngày Tết Trung thu','Ngày Quốc tế Thiếu nhi'],
 [2,'Bạn mới chuyển đến lớp còn rụt rè. Em nên làm gì?','làm quen, rủ bạn cùng chơi','không chơi với bạn','trêu bạn','đứng nhìn'],
 [4,'Nếu thấy bạn lấy bút của bạn khác, em sẽ xử lí thế nào cho phù hợp?','Nhẹ nhàng khuyên bạn trả lại và xin lỗi; nếu bạn không nghe thì báo thầy cô.'],
]);
them('Đạo đức',3,'Ham học hỏi, giữ lời hứa',[
 [1,'Biểu hiện nào là tích cực hoàn thành nhiệm vụ?','làm xong trực nhật đúng giờ, sạch sẽ','làm qua loa','để bạn làm hộ','bỏ dở giữa chừng'],
 [2,'Khám phá bản thân giúp em điều gì?','biết điểm mạnh, điểm yếu để cố gắng hơn','để khoe với bạn','để chê bạn','không có ích'],
 [4,'Lập kế hoạch rèn luyện một điểm yếu của em trong một tháng.','HS nêu điểm yếu, mục tiêu, việc làm hằng tuần, người hỗ trợ, cách tự đánh giá.'],
]);
them('Đạo đức',4,'Yêu lao động, tôn trọng tài sản',[
 [1,'Câu tục ngữ nào nói về yêu lao động?','Có làm thì mới có ăn','Ăn quả nhớ kẻ trồng cây','Uống nước nhớ nguồn','Lá lành đùm lá rách'],
 [2,'Mượn đồ của bạn mà làm hỏng, em nên làm gì?','xin lỗi và tìm cách sửa hoặc đền','giấu đi','nói dối là đồ tự hỏng','trả lại im lặng'],
 [4,'Em có ý kiến gì về việc một số bạn viết, vẽ lên tường nhà vệ sinh của trường?','Không đồng tình vì làm hỏng tài sản chung, mất vệ sinh; cần nhắc nhở và cùng giữ gìn.'],
]);
them('Đạo đức',5,'Bảo vệ môi trường, kế hoạch cá nhân',[
 [1,'Vượt qua khó khăn là biểu hiện của đức tính nào?','kiên trì, ý chí','lười biếng','ỷ lại','nhút nhát'],
 [2,'Bạn em gặp bài khó và định bỏ cuộc. Em nên khuyên bạn điều gì?','bình tĩnh, chia nhỏ bài, hỏi thầy cô hoặc cùng nhau thảo luận','chép bài của người khác','bỏ không làm','khóc'],
 [4,'Nêu một tình huống cần "bảo vệ cái đúng" ở trường và cách em xử lí.','HS nêu tình huống cụ thể, cách ứng xử dũng cảm, lịch sự, an toàn, có nhờ người lớn khi cần.'],
]);

/* ---------- TỰ NHIÊN VÀ XÃ HỘI ---------- */
them('Tự nhiên và Xã hội',1,'Cộng đồng địa phương',[
 [1,'Khi đi bộ qua đường, em cần làm gì?','đi trên vạch kẻ cho người đi bộ, có người lớn dắt','chạy qua thật nhanh','vừa đi vừa chơi','đi ở giữa đường'],
 [2,'Ai giúp giữ gìn an ninh, trật tự nơi em sống?','chú công an','bác bán hàng','bác lái xe','cô thợ may'],
 [3,'Kể tên một nơi vui chơi công cộng gần nhà em và việc em làm để giữ nơi đó sạch đẹp.','HS nêu tên nơi (sân chơi, công viên…) và việc làm (bỏ rác đúng chỗ…).'],
]);
them('Tự nhiên và Xã hội',1,'Thực vật và động vật',[
 [1,'Cây nào cho quả ăn được?','cây cam','cây xương rồng cảnh','cây hoa hồng','cây thông'],
 [2,'Con vật nào có cánh và biết bay?','con chim','con chó','con cá','con lợn'],
 [3,'Khi chơi với chó, mèo, em cần chú ý điều gì?','Không trêu chọc, không chơi với con vật lạ, rửa tay sau khi chơi.'],
]);
them('Tự nhiên và Xã hội',2,'Con người và sức khỏe',[
 [1,'Cơ quan nào giúp cơ thể cử động được?','cơ quan vận động (xương và cơ)','cơ quan hô hấp','cơ quan tiêu hóa','mắt và tai'],
 [2,'Vì sao cần ngồi học đúng tư thế?','để không bị cong vẹo cột sống, cận thị','để ngồi lâu hơn','để đẹp hơn','không cần thiết'],
 [3,'Nêu 2 việc em làm để giữ vệ sinh cơ quan bài tiết nước tiểu.','Uống đủ nước, không nhịn tiểu, giữ vệ sinh cá nhân sạch sẽ…'],
]);
them('Tự nhiên và Xã hội',2,'Cộng đồng địa phương',[
 [1,'Biển báo nào báo hiệu "Đường dành cho người đi bộ"?','biển hình tròn màu xanh có hình người đi bộ','biển tam giác vàng','biển cấm đỗ xe','biển chỉ dẫn bến xe'],
 [2,'Khi mua hàng ở chợ hoặc siêu thị, em cần làm gì?','xếp hàng, trả tiền và cảm ơn người bán','chen lấn','tự lấy đồ không trả tiền','la hét'],
]);
them('Tự nhiên và Xã hội',3,'Thực vật và động vật',[
 [1,'Rễ cây có chức năng gì?','hút nước, muối khoáng và giữ cho cây đứng vững','chế tạo chất dinh dưỡng','tạo ra hoa','làm cây đẹp'],
 [2,'Con vật nào thuộc nhóm côn trùng?','con ong','con cá','con mèo','con rắn'],
 [3,'Phân loại các con vật sau thành 2 nhóm có xương sống và không có xương sống: gà, giun, cá, ốc, mèo, tôm.','Có xương sống: gà, cá, mèo; không có xương sống: giun, ốc, tôm.'],
]);
them('Tự nhiên và Xã hội',3,'Trái Đất và bầu trời',[
 [1,'Trái Đất quay quanh gì?','Mặt Trời','Mặt Trăng','sao Hỏa','sao Kim'],
 [2,'Có mấy phương chính?','4 phương: Đông, Tây, Nam, Bắc','2 phương','3 phương','8 phương chính'],
 [3,'Buổi sáng, em đứng giơ tay phải về phía Mặt Trời mọc. Hãy cho biết phía trước mặt em là phương nào.','Tay phải chỉ phương Đông thì trước mặt là phương Bắc.'],
]);

/* ---------- TIN HỌC ---------- */
them('Tin học',3,'Máy tính và em',[
 [1,'Thiết bị nào dùng để di chuyển con trỏ trên màn hình?','chuột','loa','máy in','tai nghe'],
 [2,'Nháy đúp chuột là gì?','nhấn nhanh hai lần nút trái chuột','nhấn nút phải chuột','giữ và kéo chuột','lăn bánh xe chuột'],
 [2,'Phím nào dùng để gõ chữ hoa?','Shift (hoặc Caps Lock)','Enter','Space','Delete'],
 [3,'Nêu các bước tắt máy tính đúng cách.','Đóng các chương trình → Start → Shut down → chờ máy tắt hẳn (tắt màn hình nếu cần).'],
]);
them('Tin học',4,'Soạn thảo văn bản và trình chiếu',[
 [1,'Tổ hợp phím Ctrl + S dùng để làm gì?','lưu tệp','in tệp','mở tệp mới','đóng tệp'],
 [2,'Muốn căn giữa một dòng chữ, em dùng tổ hợp phím nào?','Ctrl + E','Ctrl + L','Ctrl + R','Ctrl + J'],
 [3,'Nêu các bước tạo một bài trình chiếu giới thiệu về gia đình em (3 trang).','Mở PowerPoint → trang tiêu đề → thêm trang, nhập nội dung → chèn ảnh → chọn hiệu ứng → lưu.'],
]);
them('Tin học',5,'Tìm kiếm thông tin, thư mục',[
 [1,'Từ khóa tìm kiếm là gì?','những từ ngắn gọn, chính xác mô tả điều cần tìm','tên của máy tính','mật khẩu','địa chỉ nhà'],
 [2,'Muốn tìm thông tin về "Vịnh Hạ Long", từ khóa nào phù hợp nhất?','Vịnh Hạ Long','vịnh','đi chơi','biển đẹp nhất'],
 [3,'Nêu các bước tạo một thư mục mới trên màn hình nền.','Nháy chuột phải → New → Folder → gõ tên → nhấn Enter.'],
]);

/* ---------- CÔNG NGHỆ ---------- */
them('Công nghệ',3,'Sử dụng đèn học, quạt điện, ti vi',[
 [1,'Máy thu thanh (radio) dùng để làm gì?','nghe tin tức, ca nhạc','xem phim','gọi điện','giặt quần áo'],
 [2,'Khi đèn học bị chập điện, em nên làm gì?','không chạm vào, báo ngay cho người lớn','tự sửa','dùng tay ướt rút phích','bỏ mặc'],
]);
them('Công nghệ',4,'Hoa và cây cảnh',[
 [1,'Loại hoa nào thường dùng trong dịp Tết?','hoa đào, hoa mai','hoa súng','hoa bìm bìm','hoa dại ven đường'],
 [2,'Vì sao chậu trồng cây cần có lỗ thoát nước?','để cây không bị úng rễ','để chậu nhẹ hơn','để đẹp hơn','để giữ nước lâu'],
 [3,'Nêu các bước trồng một cây con vào chậu.','Chuẩn bị chậu, đất → tạo hố → đặt cây → lấp đất, ấn nhẹ → tưới nước.'],
]);
them('Công nghệ',5,'Công nghệ và đời sống',[
 [1,'Ai là người phát minh ra bóng đèn điện được nhiều người biết đến?','Thomas Edison','Newton','Galileo','Einstein'],
 [2,'Sản phẩm công nghệ nào giúp liên lạc từ xa?','điện thoại','nồi cơm điện','quạt điện','bàn là'],
 [4,'Đề xuất ý tưởng một sản phẩm công nghệ đơn giản giúp tiết kiệm nước ở trường.','Ví dụ: vòi nước tự ngắt, bình tưới nhỏ giọt từ chai nhựa…; nêu vật liệu, cách hoạt động.'],
]);

/* ---------- GIÁO DỤC THỂ CHẤT, ÂM NHẠC, MĨ THUẬT, HĐTN ---------- */
for(const l of [1,2,3,4,5]){
 them('Giáo dục thể chất',l,'Thói quen vận động hằng ngày',[
  [1,'Em nên tập thể dục buổi sáng vào lúc nào?','sau khi ngủ dậy, trước khi ăn sáng một lúc','ngay sau khi ăn no','lúc nửa đêm','khi đang ốm'],
  [2,'Khi đang chạy mà thấy mệt, chóng mặt, em cần làm gì?','dừng lại, nghỉ ngơi và báo thầy cô','cố chạy tiếp','ngồi xuống ngay giữa đường chạy','uống thật nhiều nước đá'],
  [3,'Kể tên 3 trò chơi vận động giúp em khỏe mạnh.','Ví dụ: nhảy dây, kéo co, đá cầu, bịt mắt bắt dê…'],
 ]);
 them('Âm nhạc',l,'Thói quen nghe và biểu diễn',[
  [1,'Khi nghe bạn biểu diễn, em nên làm gì?','lắng nghe và vỗ tay cổ vũ','nói chuyện riêng','bỏ đi','cười chê'],
  [2,'Hát to quá sức có hại gì?','làm đau họng, hỏng giọng','giúp giọng hay hơn','không có hại','giúp nhớ lời'],
  [3,'Kể tên một bài hát về thầy cô hoặc mái trường mà em biết.','HS kể tên bài hát phù hợp chủ đề.'],
 ]);
 them('Mĩ thuật',l,'Quan sát và cảm nhận',[
  [1,'Màu trắng pha với màu đỏ được màu gì?','màu hồng','màu tím','màu cam','màu nâu'],
  [2,'Khi vẽ tranh về "Trường em", hình ảnh chính nên là gì?','ngôi trường, thầy cô, các bạn học sinh','ngọn núi lửa','tàu vũ trụ','biển cả'],
  [3,'Em sẽ dùng những màu nào để vẽ cảnh mùa thu? Vì sao?','Ví dụ: vàng, cam, nâu – màu của lá vàng, lúa chín, nắng thu…'],
 ]);
 them('Hoạt động trải nghiệm',l,'An toàn và kĩ năng sống',[
  [1,'Khi bị chảy máu cam, em nên làm gì?','ngồi thẳng, hơi cúi đầu về trước, bóp nhẹ cánh mũi và báo người lớn','ngửa cổ ra sau thật lâu','chạy nhảy','nằm ngửa'],
  [2,'Khi ở nhà một mình có người lạ gõ cửa, em nên làm gì?','không mở cửa, gọi điện cho bố mẹ','mở cửa ngay','nói cho người lạ biết bố mẹ đi vắng','cho người lạ vào nhà'],
  [3,'Kể 3 việc em có thể tự làm để chăm sóc bản thân mỗi ngày.','Ví dụ: tự vệ sinh cá nhân, chuẩn bị sách vở, ăn uống đúng giờ, ngủ đủ giấc…'],
 ]);
}

/* ---------- câu NÂNG CAO cho các môn còn thiếu ---------- */
them('Đạo đức',1,'An toàn',[[4,'Em đang chơi ở sân thì thấy một chiếc bật lửa rơi dưới đất. Em sẽ làm gì? Vì sao?','Không nhặt lên chơi, báo ngay cho thầy cô/người lớn vì có thể gây bỏng, cháy.']]);
them('Đạo đức',1,'Gia đình và nhà trường',[[4,'Bạn Na đi học muộn và nói dối cô là do xe hỏng. Theo em, bạn Na nên làm gì?','Nói thật với cô, xin lỗi và hứa đi học đúng giờ.']]);
them('Tự nhiên và Xã hội',1,'Con người và sức khỏe',[[4,'Vì sao không nên dùng chung khăn mặt, bàn chải đánh răng với người khác?','Vì dễ lây bệnh qua vi khuẩn, nấm ở khăn, bàn chải.']]);
them('Tự nhiên và Xã hội',1,'Trái Đất và bầu trời',[[4,'Vì sao buổi trưa trời nóng hơn buổi sáng sớm?','Vì buổi trưa Mặt Trời chiếu nắng mạnh nhất (ở cao trên đầu).']]);
them('Tự nhiên và Xã hội',2,'Thực vật và động vật',[[4,'Nếu chặt hết cây xanh ở một khu rừng thì các con vật sống ở đó sẽ ra sao?','Mất nơi ở, nguồn thức ăn; nhiều con vật sẽ phải bỏ đi hoặc chết.']]);
them('Tự nhiên và Xã hội',2,'Con người và sức khỏe',[[4,'Vì sao khi chạy nhanh, em thở gấp hơn?','Vì cơ thể cần nhiều khí ô-xi hơn khi vận động mạnh.']]);
them('Tự nhiên và Xã hội',3,'Con người và sức khỏe',[[4,'Vì sao khi bị thương chảy máu ở tay, ta cần rửa sạch vết thương và băng lại?','Để ngăn vi khuẩn xâm nhập gây nhiễm trùng và giúp cầm máu.']]);
them('Tự nhiên và Xã hội',3,'Cộng đồng địa phương',[[4,'Đề xuất 2 cách giúp người dân địa phương em giảm rác thải nhựa.','Ví dụ: dùng túi vải khi đi chợ, phân loại rác tại nhà, tổ chức đổi chai nhựa lấy cây xanh…']]);
them('Tiếng Anh',1,'Numbers & Animals',[[4,'Đếm và viết bằng tiếng Anh: 2 + 3 = ?','five']]);
them('Tiếng Anh',2,'Places & Actions',[[4,'Sắp xếp thành câu đúng: "can / I / jump"','I can jump.']]);
them('Tin học',3,'Đạo đức và an toàn trên mạng',[[4,'Một người lạ trên mạng xin số điện thoại và địa chỉ nhà em để tặng quà. Em sẽ làm gì?','Không cung cấp thông tin, không trả lời tiếp và báo ngay cho bố mẹ/thầy cô.']]);
them('Tin học',4,'Lập trình Scratch',[[4,'Viết chương trình Scratch cho mèo vẽ hình vuông cạnh 100 bước.','when green flag clicked → pen down → repeat 4 [move 100 steps, turn 90 degrees].']]);
them('Tin học',5,'Lập trình Scratch nâng cao',[[4,'Mô tả chương trình đếm điểm: mỗi lần nháy vào nhân vật thì điểm tăng 1, đủ 10 điểm thì nhân vật nói "Chiến thắng!".','Tạo biến Điểm = 0; when this sprite clicked → change Điểm by 1 → if Điểm = 10 then say "Chiến thắng!".']]);
them('Công nghệ',3,'Thủ công kĩ thuật',[[4,'Thiết kế một chiếc ống đựng bút từ vỏ hộp sữa. Nêu vật liệu và các bước làm.','Vật liệu: vỏ hộp sữa, giấy màu, kéo, keo; các bước: cắt hộp, rửa sạch, dán giấy trang trí, hoàn thiện.']]);
them('Công nghệ',4,'Lắp ghép mô hình kĩ thuật',[[4,'Mô hình xe đẩy em lắp bị lệch, chạy không thẳng. Theo em nguyên nhân có thể là gì và cách sửa?','Bánh xe lắp lệch, trục cong hoặc ốc lỏng; kiểm tra, lắp lại bánh, siết ốc đều hai bên.']]);
for(const l of [1,2,3,4,5]){
 them('Giáo dục thể chất',l,'Thói quen vận động hằng ngày',[[4,'Lập thời gian biểu vận động 15 phút mỗi ngày trong một tuần cho em.','HS nêu thời gian, bài tập (khởi động, nhảy dây, chạy nhẹ, thả lỏng), số lần; hợp lí, an toàn.']]);
 them('Âm nhạc',l,'Thói quen nghe và biểu diễn',[[4,'Sáng tạo động tác minh họa cho một bài hát em đã học và biểu diễn cùng nhóm.','Động tác phù hợp lời ca, nhịp điệu; nhóm biểu diễn tự tin, đều nhau.']]);
 them('Mĩ thuật',l,'Quan sát và cảm nhận',[[4,'Thiết kế một tấm thiệp chúc mừng thầy cô nhân ngày 20/11 và giới thiệu ý tưởng của em.','Thiệp có hình ảnh, màu sắc hài hòa, lời chúc; HS giới thiệu được ý tưởng.']]);
 them('Hoạt động trải nghiệm',l,'An toàn và kĩ năng sống',[[4,'Lập kế hoạch một việc làm tốt cho cộng đồng mà lớp em có thể thực hiện trong tháng này.','Nêu tên việc, mục đích, thời gian, phân công, cách thực hiện và đánh giá.']]);
}

/* =============================================================
   NGÂN HÀNG CÂU HỎI THCS (lớp 6-9) — Kết nối tri thức
   ============================================================= */

/* ================= KHOA HỌC TỰ NHIÊN (THCS, lớp 6-9) ================= */
NH['Khoa học tự nhiên']={
6:[
 {cd:'Mở đầu về Khoa học tự nhiên',q:[
  [1,'Khoa học tự nhiên nghiên cứu về điều gì?','các sự vật, hiện tượng của thế giới tự nhiên','chỉ nghiên cứu con người','chỉ nghiên cứu máy móc','lịch sử loài người'],
  [1,'Dụng cụ nào dùng để quan sát các vật rất nhỏ như tế bào?','kính hiển vi','kính lúp','kính râm','ống nhòm'],
  [1,'Đơn vị đo chiều dài trong hệ SI là gì?','mét (m)','ki-lô-gam','giây','độ C'],
  [2,'Để đo nhiệt độ cơ thể, ta thường dùng dụng cụ nào?','nhiệt kế','cân','thước','đồng hồ'],
  [2,'Khi làm thí nghiệm trong phòng thực hành, việc nào sau đây là an toàn?','đọc kĩ hướng dẫn trước khi làm','nếm thử hóa chất','đùa nghịch với dụng cụ','tự ý trộn các hóa chất'],
  [3,'Kể tên 2 lĩnh vực chủ yếu của Khoa học tự nhiên.','Vật lí, Hóa học, Sinh học, Khoa học Trái Đất và Thiên văn học (nêu 2 trong số đó).'],
 ]},
 {cd:'Chất và sự biến đổi của chất',q:[
  [1,'Chất có thể tồn tại ở những thể (trạng thái) nào?','rắn, lỏng, khí','chỉ rắn','chỉ lỏng','chỉ khí'],
  [1,'Khí nào cần cho sự hô hấp và sự cháy?','oxygen','nitrogen','carbon dioxide','hơi nước'],
  [2,'Quá trình nước đá tan thành nước lỏng là sự chuyển thể nào?','nóng chảy','đông đặc','bay hơi','ngưng tụ'],
  [2,'Hỗn hợp nào sau đây là dung dịch?','nước đường','nước và dầu ăn','nước và cát','bột mì và nước'],
  [3,'Nêu một cách tách muối ra khỏi dung dịch nước muối.','Cô cạn (đun cho nước bay hơi hết, còn lại muối).'],
 ]},
 {cd:'Tế bào và cơ thể sống',q:[
  [1,'Đơn vị cơ bản cấu tạo nên cơ thể sống là gì?','tế bào','mô','cơ quan','hệ cơ quan'],
  [1,'Thành phần nào có ở tế bào thực vật mà tế bào động vật không có?','thành tế bào và lục lạp','nhân','màng tế bào','chất tế bào'],
  [2,'Sắp xếp đúng thứ tự tổ chức cơ thể đa bào từ nhỏ đến lớn?','tế bào → mô → cơ quan → hệ cơ quan → cơ thể','cơ thể → tế bào → mô','mô → tế bào → cơ quan','cơ quan → tế bào → mô'],
  [2,'Vi khuẩn thuộc nhóm sinh vật có cấu tạo tế bào như thế nào?','nhân sơ','nhân thực','đa bào phức tạp','không có tế bào'],
  [3,'Vì sao nói tế bào là đơn vị cơ bản của sự sống?','Vì mọi cơ thể sống đều được cấu tạo từ tế bào và mọi hoạt động sống đều diễn ra trong tế bào.'],
 ]},
 {cd:'Lực và năng lượng',q:[
  [1,'Dụng cụ nào dùng để đo lực?','lực kế','cân đồng hồ','nhiệt kế','thước'],
  [1,'Đơn vị đo lực là gì?','niutơn (N)','ki-lô-gam','mét','jun'],
  [2,'Lực hút của Trái Đất tác dụng lên vật gọi là gì?','trọng lực','lực ma sát','lực đàn hồi','lực đẩy'],
  [2,'Dạng năng lượng nào được dự trữ trong thức ăn, pin, xăng dầu?','hóa năng','quang năng','điện năng','nhiệt năng'],
  [3,'Nêu một ví dụ về lực ma sát có ích trong đời sống.','Ví dụ: ma sát giúp ta cầm nắm đồ vật, giúp xe phanh lại, giúp đi lại không trơn trượt…'],
 ]},
 {cd:'Trái Đất và bầu trời',q:[
  [1,'Trái Đất là hành tinh thứ mấy tính từ Mặt Trời?','thứ ba','thứ nhất','thứ năm','thứ tám'],
  [2,'Hiện tượng ngày và đêm trên Trái Đất là do đâu?','Trái Đất tự quay quanh trục','Mặt Trời quay quanh Trái Đất','Mặt Trăng che Mặt Trời','gió thổi'],
  [2,'Mặt Trăng là gì của Trái Đất?','vệ tinh tự nhiên','một ngôi sao','một hành tinh','Mặt Trời thứ hai'],
  [3,'Vì sao ta nhìn thấy Mặt Trăng sáng?','Vì Mặt Trăng phản chiếu ánh sáng từ Mặt Trời (Mặt Trăng không tự phát sáng).'],
 ]}],
7:[
 {cd:'Nguyên tử, phân tử, bảng tuần hoàn',q:[
  [1,'Hạt nào mang điện tích âm trong nguyên tử?','electron','proton','neutron','hạt nhân'],
  [1,'Hạt nhân nguyên tử gồm những loại hạt nào?','proton và neutron','electron và proton','chỉ electron','chỉ neutron'],
  [2,'Trong bảng tuần hoàn, các nguyên tố được sắp xếp theo chiều tăng dần của đại lượng nào?','điện tích hạt nhân','khối lượng riêng','nhiệt độ sôi','màu sắc'],
  [2,'Phân tử nước có công thức hóa học là gì?','H₂O','CO₂','O₂','NaCl'],
  [3,'Nguyên tử trung hòa về điện. Giải thích vì sao.','Vì số proton (điện tích +) bằng số electron (điện tích –) nên tổng điện tích bằng 0.'],
 ]},
 {cd:'Tốc độ, âm thanh, ánh sáng',q:[
  [1,'Công thức tính tốc độ là gì?','v = s : t','v = s × t','v = t : s','v = s + t'],
  [1,'Âm thanh được tạo ra khi vật như thế nào?','dao động','đứng yên','nóng lên','phát sáng'],
  [2,'Một xe đi 60 km trong 2 giờ. Tốc độ của xe là bao nhiêu?','30 km/h','120 km/h','62 km/h','58 km/h'],
  [2,'Ánh sáng truyền đi theo đường nào trong môi trường trong suốt và đồng tính?','đường thẳng','đường cong','đường gấp khúc','đường tròn'],
  [3,'Vì sao khi có sấm sét, ta thường thấy chớp trước rồi mới nghe tiếng sấm?','Vì tốc độ ánh sáng lớn hơn rất nhiều so với tốc độ âm thanh nên ánh sáng truyền đến mắt trước.'],
 ]},
 {cd:'Trao đổi chất và chuyển hóa năng lượng ở sinh vật',q:[
  [1,'Quá trình quang hợp ở cây xanh diễn ra chủ yếu ở bộ phận nào?','lá','rễ','hoa','quả'],
  [1,'Khí nào cây xanh thải ra trong quá trình quang hợp?','oxygen','carbon dioxide','nitrogen','hơi nước'],
  [2,'Nguyên liệu của quá trình quang hợp là gì?','nước và khí carbon dioxide','oxygen và glucose','chỉ nước','chỉ ánh sáng'],
  [2,'Hô hấp tế bào tạo ra dạng năng lượng dùng cho hoạt động sống, chủ yếu từ chất nào?','glucose','nước','muối khoáng','oxygen'],
  [3,'Nêu vai trò của quang hợp đối với sự sống trên Trái Đất.','Tạo ra chất hữu cơ nuôi sinh vật và cung cấp khí oxygen cho hô hấp.'],
 ]},
 {cd:'Cảm ứng, sinh trưởng và sinh sản ở sinh vật',q:[
  [1,'Hiện tượng cây mọc hướng về phía ánh sáng gọi là gì?','tính hướng sáng','tính hướng nước','tính hướng đất','hướng hóa'],
  [2,'Sinh sản vô tính tạo ra cơ thể con có đặc điểm di truyền như thế nào so với cơ thể mẹ?','giống hệt cơ thể mẹ','khác hoàn toàn mẹ','giống bố','khác cả bố và mẹ'],
  [2,'Hiện tượng nào sau đây là cảm ứng ở động vật?','trời lạnh, mèo cuộn tròn người lại','cây rụng lá','nước bốc hơi','đá tan'],
  [3,'Nêu một ví dụ ứng dụng sinh sản vô tính trong trồng trọt.','Ví dụ: giâm cành, chiết cành, ghép cây, nuôi cấy mô…'],
 ]}],
8:[
 {cd:'Phản ứng hóa học',q:[
  [1,'Trong phản ứng hóa học, chất ban đầu gọi là gì?','chất phản ứng (chất tham gia)','sản phẩm','chất xúc tác','dung môi'],
  [1,'Định luật bảo toàn khối lượng do nhà khoa học nào phát biểu?','Lavoisier','Newton','Einstein','Mendeleev'],
  [2,'Theo định luật bảo toàn khối lượng, tổng khối lượng các chất sản phẩm so với tổng khối lượng các chất tham gia thì như thế nào?','bằng nhau','lớn hơn','nhỏ hơn','không xác định'],
  [2,'Dấu hiệu nào cho biết có phản ứng hóa học xảy ra?','tạo chất mới (đổi màu, sủi bọt, kết tủa…)','vật chỉ đổi chỗ','nước nóng lên một chút','không có gì thay đổi'],
  [3,'Đốt cháy 3 g carbon cần 8 g oxygen tạo ra khí carbon dioxide. Tính khối lượng khí carbon dioxide tạo thành.','Theo bảo toàn khối lượng: 3 + 8 = 11 (g).'],
 ]},
 {cd:'Khối lượng riêng, áp suất',q:[
  [1,'Công thức tính khối lượng riêng là gì?','D = m : V','D = m × V','D = V : m','D = m + V'],
  [2,'Một vật có khối lượng 300 g và thể tích 100 cm³. Khối lượng riêng của vật là bao nhiêu?','3 g/cm³','30 g/cm³','0,3 g/cm³','300 g/cm³'],
  [2,'Áp suất phụ thuộc vào những yếu tố nào?','độ lớn áp lực và diện tích bị ép','chỉ khối lượng','chỉ thể tích','màu sắc của vật'],
  [3,'Vì sao xe tăng, máy kéo có bản xích to bản?','Để tăng diện tích tiếp xúc, giảm áp suất lên mặt đất, tránh bị lún.'],
 ]},
 {cd:'Điện, nhiệt',q:[
  [1,'Dòng điện là gì?','dòng chuyển dời có hướng của các hạt mang điện','sự đứng yên của electron','ánh sáng phát ra','nhiệt độ của vật'],
  [1,'Đơn vị đo cường độ dòng điện là gì?','ampe (A)','vôn (V)','oát (W)','ôm (Ω)'],
  [2,'Vật liệu nào sau đây dẫn điện tốt?','đồng','nhựa','gỗ khô','thủy tinh'],
  [2,'Nhiệt truyền từ vật có nhiệt độ cao sang vật có nhiệt độ thấp cho đến khi nào?','nhiệt độ hai vật bằng nhau','vật nóng nguội hẳn','vật lạnh nóng hơn','mãi mãi'],
  [3,'Nêu một biện pháp an toàn khi sử dụng điện trong gia đình.','Ví dụ: không chạm tay ướt vào thiết bị điện, không dùng dây điện hở, ngắt điện khi sửa chữa…'],
 ]},
 {cd:'Sinh học cơ thể người, môi trường',q:[
  [1,'Cơ quan nào thực hiện chức năng trao đổi khí ở người?','phổi','dạ dày','gan','thận'],
  [1,'Máu trong cơ thể người được bơm đi nhờ cơ quan nào?','tim','phổi','gan','não'],
  [2,'Hệ cơ quan nào giúp cơ thể tiêu hóa và hấp thụ chất dinh dưỡng?','hệ tiêu hóa','hệ hô hấp','hệ bài tiết','hệ thần kinh'],
  [2,'Quần xã sinh vật và môi trường sống của nó tạo thành một đơn vị gọi là gì?','hệ sinh thái','quần thể','cá thể','sinh quyển'],
  [3,'Nêu 2 việc em có thể làm để bảo vệ môi trường.','Ví dụ: không xả rác bừa bãi, trồng cây xanh, tiết kiệm điện nước, phân loại rác…'],
 ]}],
9:[
 {cd:'Năng lượng cơ học, điện, điện từ',q:[
  [1,'Đơn vị đo công và năng lượng là gì?','jun (J)','niutơn','oát','ampe'],
  [1,'Công thức tính công cơ học là gì?','A = F × s','A = F : s','A = F + s','A = s : F'],
  [2,'Định luật Ohm cho đoạn mạch có biểu thức nào?','I = U : R','I = U × R','I = R : U','I = U + R'],
  [2,'Đặt vào hai đầu điện trở 10 Ω một hiệu điện thế 20 V. Cường độ dòng điện qua điện trở là bao nhiêu?','2 A','200 A','0,5 A','30 A'],
  [3,'Nêu một ứng dụng của hiện tượng cảm ứng điện từ.','Ví dụ: máy phát điện, máy biến áp, động cơ điện…'],
 ]},
 {cd:'Kim loại và hợp chất',q:[
  [1,'Kim loại nào sau đây nhẹ và được dùng nhiều trong hàng không?','nhôm (aluminium)','sắt','chì','vàng'],
  [2,'Tính chất hóa học đặc trưng của kim loại là gì?','dễ nhường electron (tính khử)','dễ nhận electron','không phản ứng','luôn ở thể khí'],
  [2,'Gang và thép là hợp kim của kim loại nào là chính?','sắt','nhôm','đồng','kẽm'],
  [3,'Nêu một biện pháp chống ăn mòn kim loại.','Ví dụ: sơn, mạ, bôi dầu mỡ, tạo hợp kim không gỉ (inox)…'],
 ]},
 {cd:'Hợp chất hữu cơ',q:[
  [1,'Hợp chất hữu cơ nhất thiết phải chứa nguyên tố nào?','carbon','oxygen','nitrogen','sắt'],
  [1,'Khí methane (CH₄) là thành phần chính của loại nhiên liệu nào?','khí thiên nhiên (khí biogas)','xăng','than đá','dầu hỏa'],
  [2,'Ethylic alcohol (rượu etylic) có công thức nào?','C₂H₅OH','CH₄','CH₃COOH','C₆H₁₂O₆'],
  [2,'Chất nào sau đây thuộc nhóm carbohydrate?','tinh bột','protein','chất béo','muối ăn'],
  [3,'Nêu một ứng dụng của ethylic alcohol trong đời sống.','Ví dụ: làm nhiên liệu, dung môi, sát khuẩn (cồn y tế)…'],
 ]},
 {cd:'Di truyền và tiến hóa',q:[
  [1,'Vật chất mang thông tin di truyền ở cấp độ phân tử là gì?','DNA (ADN)','protein','tinh bột','nước'],
  [1,'Người đặt nền móng cho di truyền học qua thí nghiệm trên cây đậu Hà Lan là ai?','Mendel','Darwin','Newton','Lavoisier'],
  [2,'Bộ nhiễm sắc thể của loài người bình thường có bao nhiêu chiếc?','46','23','24','48'],
  [2,'Học thuyết tiến hóa bằng chọn lọc tự nhiên do ai đề xuất?','Darwin','Mendel','Lamac (Lamarck) là người trước đó','Mendeleev'],
  [3,'Nêu một ví dụ về ứng dụng di truyền học trong chọn giống.','Ví dụ: lai tạo giống cây trồng, vật nuôi năng suất cao; chọn giống kháng bệnh…'],
 ]}]};

/* ================= TIẾNG ANH (THCS, lớp 6-9 — Global Success) ================= */
NH['Tiếng Anh'][6]=[
 {cd:'Vocabulary — School, House, Friends',q:[
  [1,'Chọn từ đúng: My school has a large ___ where we play sports.','playground','kitchen','bedroom','garden'],
  [1,'"Bảng" (viết phấn) trong lớp học tiếng Anh là gì?','board','door','window','desk'],
  [1,'Which word means "phòng khách"?','living room','bathroom','kitchen','bedroom'],
  [2,'Choose the odd one out:','sofa','table','pencil','wardrobe'],
  [2,'My best friend is very ___. She always helps others.','kind','lazy','boring','ugly'],
  [3,'Write one sentence to describe your classroom.','Example: My classroom is big and clean. / There are many desks in my classroom.'],
 ]},
 {cd:'Grammar — Present simple, This/That/These/Those',q:[
  [1,'She ___ to school every day.','goes','go','going','gone'],
  [1,'___ are my books. (ở xa, số nhiều)','Those','This','That','It'],
  [2,'Choose the correct sentence:','He doesn\'t like coffee.','He don\'t likes coffee.','He not like coffee.','He no like coffee.'],
  [2,'There ___ a book and two pens on the desk.','is','are','be','am'],
  [3,'Make a sentence with "every morning".','Example: I get up at six every morning.'],
 ]},
 {cd:'Pronunciation',q:[
  [1,'Which word has a different "th" sound from the others?','Thursday','this','they','mother'],
  [2,'Choose the word with the sound /iː/:','meet','sit','big','ship'],
 ]}];
NH['Tiếng Anh'][7]=[
 {cd:'Vocabulary — Hobbies, Health, Community',q:[
  [1,'"Sở thích" in English is:','hobby','homework','hospital','holiday'],
  [1,'Which activity is a hobby?','collecting stamps','being ill','feeling tired','having a headache'],
  [2,'To keep fit, you should eat more ___ and vegetables.','fruit','sweets','fast food','sugar'],
  [2,'A person who helps the community without pay is a ___.','volunteer','customer','patient','tourist'],
  [3,'Write one sentence about your favourite hobby.','Example: My favourite hobby is reading books.'],
 ]},
 {cd:'Grammar — Past simple, Comparatives',q:[
  [1,'Yesterday, we ___ to the museum.','went','go','goes','going'],
  [1,'This box is ___ than that one.','heavier','heavy','heaviest','more heavy'],
  [2,'She ___ her homework last night.','did','does','do','done'],
  [2,'Choose the correct comparative: "good" →','better','gooder','more good','best'],
  [3,'Make a comparative sentence about two cities.','Example: Ha Noi is bigger than Ha Long. / Da Nang is more beautiful than...'],
 ]},
 {cd:'Pronunciation',q:[
  [1,'Choose the word with a different stress pattern:','relax','hobby','music','healthy'],
  [2,'The "-ed" in "played" is pronounced as:','/d/','/t/','/ɪd/','/s/'],
 ]}];
NH['Tiếng Anh'][8]=[
 {cd:'Vocabulary — Leisure, Customs, Environment',q:[
  [1,'"Thời gian rảnh rỗi" in English is:','leisure time','working time','bedtime','exam time'],
  [1,'Which word relates to the environment?','pollution','breakfast','birthday','furniture'],
  [2,'In Viet Nam, it is a custom to ___ older people to show respect.','greet','ignore','laugh at','push'],
  [2,'We should ___ water and electricity to protect the environment.','save','waste','pour','throw'],
  [3,'Write one thing you do to protect the environment.','Example: I recycle paper and plastic bottles.'],
 ]},
 {cd:'Grammar — Present perfect, Reported speech (basic)',q:[
  [1,'I ___ never ___ to Da Nang.','have / been','has / been','am / been','was / been'],
  [1,'She has lived here ___ 2015.','since','for','in','at'],
  [2,'Choose the correct sentence:','They have just finished dinner.','They have just finish dinner.','They has just finished dinner.','They just have finish dinner.'],
  [2,'"I am tired," she said. → She said that she ___ tired.','was','is','are','were'],
  [3,'Make a sentence using "already".','Example: I have already done my homework.'],
 ]},
 {cd:'Pronunciation',q:[
  [1,'Choose the word with the sound /ʃ/:','sure','sun','see','song'],
  [2,'Which word has three syllables?','pollution','leisure','custom','habit'],
 ]}];
NH['Tiếng Anh'][9]=[
 {cd:'Vocabulary — Community, City life, Tourism',q:[
  [1,'A traditional craft village is a place that makes ___ products by hand.','handicraft','electronic','digital','plastic'],
  [1,'"Du lịch" in English is:','tourism','teaching','trading','training'],
  [2,'City life can be ___ because of traffic and noise.','stressful','peaceful','empty','silent'],
  [2,'A place of interest that tourists often visit is called a ___.','attraction','factory','office','prison'],
  [3,'Write one advantage of living in a big city.','Example: There are many job opportunities and good schools.'],
 ]},
 {cd:'Grammar — Conditional sentences, Passive, Relative clauses',q:[
  [1,'If it rains tomorrow, we ___ at home.','will stay','stay','stayed','would stay'],
  [1,'The letter ___ by Nam yesterday.','was written','wrote','writes','is writing'],
  [2,'This is the man ___ helped me.','who','which','where','whose'],
  [2,'If I ___ rich, I would travel around the world. (câu điều kiện loại 2)','were','am','will be','was being'],
  [3,'Write a sentence using a relative clause with "which".','Example: This is the book which I bought yesterday.'],
 ]},
 {cd:'Pronunciation',q:[
  [1,'Choose the word with the main stress on the second syllable:','attract','city','tourist','local'],
  [2,'Which word has the sound /aʊ/?','town','though','thought','through'],
 ]}];

/* ================= TIN HỌC (THCS, lớp 6-9) ================= */
NH['Tin học'][6]=[
 {cd:'Thông tin và dữ liệu, máy tính',q:[
  [1,'Thông tin sau khi được đưa vào máy tính và biểu diễn để xử lí được gọi là gì?','dữ liệu','phần mềm','phần cứng','mạng'],
  [1,'Đơn vị cơ bản đo dung lượng thông tin là gì?','byte','mét','gam','giây'],
  [2,'Thiết bị nào vừa là thiết bị vào vừa là thiết bị ra?','màn hình cảm ứng','bàn phím','chuột','loa'],
  [2,'1 KB (ki-lô-bai) bằng bao nhiêu byte?','1024 byte','1000 byte','10 byte','100 byte'],
  [3,'Kể tên 2 thiết bị vào của máy tính.','Ví dụ: bàn phím, chuột, micro, máy quét, webcam…'],
 ]},
 {cd:'Mạng máy tính và Internet',q:[
  [1,'Mạng kết nối hàng tỉ máy tính trên toàn thế giới gọi là gì?','Internet','LAN','Bluetooth','USB'],
  [2,'WWW (World Wide Web) là gì?','hệ thống các trang web liên kết với nhau','một loại máy in','một phần cứng','một loại virus'],
  [2,'Để tìm kiếm thông tin trên Internet, ta thường dùng công cụ nào?','máy tìm kiếm (search engine)','máy photocopy','máy chiếu','máy quét'],
  [3,'Nêu 2 lợi ích của Internet trong học tập.','Ví dụ: tra cứu tài liệu, học trực tuyến, trao đổi với thầy cô bạn bè…'],
 ]},
 {cd:'An toàn thông tin, soạn thảo',q:[
  [1,'Khi gặp thông tin xấu trên mạng, em nên làm gì?','không chia sẻ và báo người lớn','chia sẻ ngay','bình luận cổ vũ','tải về máy'],
  [2,'Để định dạng chữ đậm trong văn bản thường dùng nút nào?','B (Bold)','I (Italic)','U (Underline)','A'],
  [3,'Nêu 2 việc nên làm để bảo vệ tài khoản cá nhân trên mạng.','Ví dụ: đặt mật khẩu mạnh, không chia sẻ mật khẩu, đăng xuất khi dùng máy công cộng…'],
 ]}];
NH['Tin học'][7]=[
 {cd:'Bảng tính điện tử',q:[
  [1,'Trong phần mềm bảng tính, giao của một hàng và một cột gọi là gì?','ô (cell)','trang','tệp','thư mục'],
  [1,'Địa chỉ ô ở cột A, hàng 1 được viết là gì?','A1','1A','AA','A-1'],
  [2,'Công thức trong bảng tính thường bắt đầu bằng dấu gì?','dấu bằng (=)','dấu cộng','dấu chấm','dấu hỏi'],
  [2,'Hàm nào dùng để tính tổng trong bảng tính?','SUM','AVERAGE','MAX','COUNT'],
  [3,'Nêu một lợi ích của việc dùng công thức, hàm trong bảng tính.','Tự động tính toán, khi thay đổi số liệu kết quả cập nhật ngay, giảm sai sót.'],
 ]},
 {cd:'Mạng xã hội, thuật toán',q:[
  [1,'Khi dùng mạng xã hội, em nên ứng xử thế nào?','văn minh, lịch sự, tôn trọng người khác','nói xấu người khác','đăng tin sai sự thật','lừa đảo'],
  [2,'Thuật toán là gì?','một dãy các bước (hữu hạn) để giải quyết một công việc','một loại virus','một thiết bị','một trang web'],
  [3,'Nêu một ví dụ về thuật toán trong đời sống.','Ví dụ: các bước pha một cốc nước chanh; các bước giải một bài toán…'],
 ]}];
NH['Tin học'][8]=[
 {cd:'Sơ đồ, biểu đồ, xử lí dữ liệu',q:[
  [1,'Để trình bày dữ liệu dạng trực quan dễ so sánh, ta thường dùng gì?','biểu đồ','mật khẩu','ổ cứng','chuột'],
  [2,'Biểu đồ hình tròn thường dùng để biểu diễn điều gì?','tỉ lệ phần trăm của các thành phần','sự thay đổi theo thời gian dài','tốc độ mạng','dung lượng ổ đĩa'],
  [3,'Nêu một tình huống nên dùng biểu đồ cột.','So sánh số lượng giữa các nhóm, ví dụ: số học sinh giỏi của các lớp.'],
 ]},
 {cd:'Thuật toán, lập trình trực quan',q:[
  [1,'Cấu trúc nào thực hiện lặp đi lặp lại một công việc?','cấu trúc lặp','cấu trúc tuần tự','cấu trúc rẽ nhánh','biến'],
  [2,'Cấu trúc rẽ nhánh (nếu… thì…) dùng để làm gì?','lựa chọn thực hiện công việc theo điều kiện','lặp mãi mãi','in ra màn hình','lưu tệp'],
  [3,'Biến trong lập trình dùng để làm gì?','Dùng để lưu trữ dữ liệu và có thể thay đổi giá trị trong quá trình chạy chương trình.'],
 ]}];
NH['Tin học'][9]=[
 {cd:'Mạng và ứng dụng, đạo đức số',q:[
  [1,'Hành vi nào sau đây vi phạm đạo đức khi dùng công nghệ?','sao chép sản phẩm của người khác rồi nhận là của mình','trích dẫn nguồn khi dùng tài liệu','xin phép trước khi dùng','tôn trọng bản quyền'],
  [2,'Thông tin nào KHÔNG nên chia sẻ công khai trên mạng?','số căn cước, mật khẩu, địa chỉ nhà','tên môn học yêu thích','ảnh phong cảnh','bài viết học tập'],
  [3,'Nêu 2 quy tắc ứng xử văn minh trên không gian mạng.','Ví dụ: tôn trọng người khác, không lan truyền tin giả, kiểm chứng thông tin, giữ gìn hình ảnh cá nhân…'],
 ]},
 {cd:'Giải quyết vấn đề với máy tính',q:[
  [1,'Bước đầu tiên khi giải quyết một vấn đề bằng máy tính là gì?','xác định bài toán (đầu vào, đầu ra)','viết chương trình ngay','in kết quả','tắt máy'],
  [2,'Một chương trình tốt cần đảm bảo điều gì?','cho kết quả đúng với mọi dữ liệu hợp lệ','chạy càng chậm càng tốt','dùng nhiều biến vô ích','khó hiểu'],
  [3,'Nêu các bước cơ bản để giải quyết một bài toán bằng máy tính.','Xác định bài toán → xây dựng thuật toán → viết chương trình → kiểm thử và hoàn thiện.'],
 ]}];

/* ================= CÔNG NGHỆ (THCS, lớp 6-9) ================= */
NH['Công nghệ'][6]=[
 {cd:'Nhà ở, đồ dùng trong gia đình',q:[
  [1,'Nhà ở có vai trò chính nào đối với con người?','nơi trú ngụ, bảo vệ và đáp ứng nhu cầu sinh hoạt','chỉ để trang trí','chỉ để chứa đồ','không có vai trò'],
  [2,'Để tiết kiệm điện, khi ra khỏi phòng em nên làm gì?','tắt đèn và quạt','bật thêm đèn','mở cửa sổ','bật điều hòa'],
  [2,'Nhóm thực phẩm nào cung cấp nhiều chất đạm?','thịt, cá, trứng','gạo, khoai','rau xanh','đường'],
  [3,'Nêu 2 việc nên làm để giữ nhà ở sạch sẽ, ngăn nắp.','Ví dụ: quét dọn thường xuyên, sắp xếp đồ đúng chỗ, bỏ rác đúng nơi…'],
 ]},
 {cd:'An toàn điện, trang phục',q:[
  [1,'Khi thấy dây điện bị hở, em nên làm gì?','tránh xa và báo người lớn','dùng tay sờ thử','dùng kéo cắt','nối lại ngay'],
  [2,'Trang phục có chức năng chính nào?','bảo vệ cơ thể và làm đẹp','chỉ để khoe','không có tác dụng','để nặng thêm'],
  [3,'Nêu một nguyên tắc chọn trang phục phù hợp.','Ví dụ: phù hợp vóc dáng, lứa tuổi, thời tiết, hoàn cảnh…'],
 ]}];
NH['Công nghệ'][7]=[
 {cd:'Trồng trọt, chăn nuôi',q:[
  [1,'Vai trò chính của trồng trọt là gì?','cung cấp lương thực, thực phẩm, nguyên liệu','chỉ làm cảnh','gây ô nhiễm','không có vai trò'],
  [2,'Biện pháp nào giúp phòng trừ sâu bệnh an toàn, thân thiện môi trường?','biện pháp sinh học','phun thật nhiều thuốc hóa học','đốt cả ruộng','bỏ mặc'],
  [2,'Chăn nuôi cung cấp sản phẩm chính nào cho con người?','thịt, trứng, sữa','gỗ','than','xi măng'],
  [3,'Nêu 2 việc cần làm để chăm sóc cây trồng.','Ví dụ: tưới nước, bón phân, làm cỏ, phòng trừ sâu bệnh…'],
 ]},
 {cd:'Lâm nghiệp, thủy sản',q:[
  [1,'Trồng rừng có lợi ích gì?','chống xói mòn, điều hòa khí hậu, cung cấp gỗ','gây lũ lụt','làm đất bạc màu','không có lợi'],
  [2,'Nuôi thủy sản là nuôi các loài sống ở đâu?','dưới nước','trên cạn','trên cây','trong hang đá'],
  [3,'Nêu một biện pháp bảo vệ nguồn lợi thủy sản.','Ví dụ: không đánh bắt bằng chất nổ, điện; không khai thác cá nhỏ; bảo vệ môi trường nước…'],
 ]}];
NH['Công nghệ'][8]=[
 {cd:'Vẽ kĩ thuật, cơ khí',q:[
  [1,'Bản vẽ kĩ thuật dùng để làm gì?','trình bày thông tin kĩ thuật của sản phẩm bằng hình vẽ','để trang trí','để viết văn','để vẽ tranh nghệ thuật'],
  [2,'Vật liệu nào sau đây là kim loại?','thép','gỗ','nhựa','cao su'],
  [3,'Nêu một dụng cụ cơ khí cầm tay thường dùng.','Ví dụ: cờ-lê, mỏ lết, kìm, tua vít, búa…'],
 ]},
 {cd:'Kĩ thuật điện, an toàn điện',q:[
  [1,'Đồ dùng điện nào biến điện năng thành nhiệt năng?','bàn là (bàn ủi)','quạt điện','máy bơm','động cơ'],
  [2,'Khi sử dụng điện, để an toàn ta KHÔNG nên làm gì?','chạm tay ướt vào thiết bị điện','rút phích cắm khi không dùng','dùng dây điện còn tốt','ngắt điện khi sửa'],
  [3,'Nêu một biện pháp tiết kiệm điện trong gia đình.','Ví dụ: tắt thiết bị khi không dùng, dùng đèn LED, tận dụng ánh sáng tự nhiên…'],
 ]}];
NH['Công nghệ'][9]=[
 {cd:'Định hướng nghề nghiệp',q:[
  [1,'Trong lĩnh vực kĩ thuật và công nghệ, người lao động cần phẩm chất nào?','cẩn thận, kỉ luật, ham học hỏi','lười biếng','cẩu thả','thiếu trung thực'],
  [2,'Việc chọn nghề phù hợp nên dựa vào yếu tố nào?','sở thích, năng lực bản thân và nhu cầu xã hội','chỉ chọn theo bạn bè','chọn đại','theo người khác bắt buộc'],
  [3,'Nêu 2 việc em có thể làm từ bây giờ để chuẩn bị cho nghề nghiệp tương lai.','Ví dụ: học tập tốt, tìm hiểu các ngành nghề, rèn kĩ năng, khám phá sở thích và năng lực…'],
 ]},
 {cd:'Mô-đun công nghệ (trồng trọt/lắp đặt điện/chế biến…)',q:[
  [1,'Trước khi lắp đặt mạng điện trong nhà, bước quan trọng nhất là gì?','ngắt nguồn điện và đảm bảo an toàn','bật tất cả thiết bị','làm nhanh cho xong','không cần chuẩn bị'],
  [2,'Để bảo quản thực phẩm tươi lâu, phương pháp phổ biến là gì?','làm lạnh/đông lạnh','để ngoài nắng','để nơi ẩm thấp','phơi mưa'],
  [3,'Nêu một nguyên tắc an toàn lao động khi thực hành.','Ví dụ: sử dụng đúng dụng cụ, mang đồ bảo hộ, tuân thủ quy trình, giữ nơi làm việc gọn gàng…'],
 ]}];

/* ================= LỊCH SỬ VÀ ĐỊA LÍ (THCS, lớp 6-9) ================= */
NH['Lịch sử và Địa lí'][6]=[
 {cd:'Lịch sử: Vì sao học lịch sử, xã hội cổ đại',q:[
  [1,'Học lịch sử giúp chúng ta hiểu điều gì?','quá khứ, cội nguồn của dân tộc và nhân loại','chỉ hiểu tương lai','cách nấu ăn','cách chơi game'],
  [1,'Nhà nước đầu tiên của người Việt là nhà nước nào?','Văn Lang','Âu Lạc','Đại Cồ Việt','Đại Việt'],
  [2,'Hai nền văn minh lớn gắn với các dòng sông ở phương Đông cổ đại là?','Ai Cập (sông Nin) và Lưỡng Hà','Hy Lạp và La Mã','Anh và Pháp','Nga và Mỹ'],
  [3,'Nêu một nguồn tư liệu giúp chúng ta tìm hiểu lịch sử.','Ví dụ: tư liệu hiện vật, tư liệu chữ viết, tư liệu truyền miệng…'],
 ]},
 {cd:'Địa lí: Bản đồ, Trái Đất',q:[
  [1,'Trái Đất có dạng hình gì?','hình cầu (gần tròn)','hình vuông','hình phẳng','hình trụ'],
  [1,'Đường kinh tuyến gốc (0°) đi qua đài thiên văn nào?','Greenwich','Hà Nội','Bắc Kinh','Paris'],
  [2,'Trái Đất tự quay quanh trục sinh ra hiện tượng gì?','ngày và đêm luân phiên','bốn mùa','thủy triều','nhật thực'],
  [3,'Nêu tác dụng của bản đồ.','Ví dụ: xác định vị trí, phương hướng, tìm đường đi, biết đặc điểm một vùng…'],
 ]}];
NH['Lịch sử và Địa lí'][7]=[
 {cd:'Lịch sử: Việt Nam thời Lý – Trần – Lê sơ',q:[
  [1,'Chiến thắng nào của nhà Trần đánh bại quân Mông – Nguyên trên sông Bạch Đằng năm 1288?','trận Bạch Đằng','trận Chi Lăng','trận Đống Đa','trận Rạch Gầm'],
  [1,'Bộ luật thành văn đầu tiên của nước ta thời Lý có tên là gì?','Hình thư','Hồng Đức','Gia Long','Hồng Bàng'],
  [2,'Ai là người lãnh đạo khởi nghĩa Lam Sơn chống quân Minh thắng lợi?','Lê Lợi','Trần Hưng Đạo','Lý Thường Kiệt','Quang Trung'],
  [3,'Nêu một thành tựu văn hóa thời Lý – Trần.','Ví dụ: xây Văn Miếu – Quốc Tử Giám, chùa Một Cột, chữ Nôm, Hịch tướng sĩ…'],
 ]},
 {cd:'Địa lí: Các châu lục',q:[
  [1,'Châu lục nào có diện tích lớn nhất thế giới?','châu Á','châu Âu','châu Phi','châu Đại Dương'],
  [1,'Hoang mạc Sahara rộng lớn nằm ở châu lục nào?','châu Phi','châu Á','châu Âu','châu Mỹ'],
  [2,'Châu lục nào lạnh nhất và hầu như không có người ở thường xuyên?','châu Nam Cực','châu Phi','châu Á','châu Âu'],
  [3,'Nêu một đặc điểm nổi bật của châu Âu.','Ví dụ: khí hậu ôn hòa, kinh tế phát triển, nhiều quốc gia, dân số già…'],
 ]}];
NH['Lịch sử và Địa lí'][8]=[
 {cd:'Lịch sử: Việt Nam thế kỉ XVI – XIX',q:[
  [1,'Phong trào nông dân Tây Sơn do ai lãnh đạo nổi bật nhất?','Nguyễn Huệ (Quang Trung)','Nguyễn Ánh','Lê Lợi','Trịnh Kiểm'],
  [1,'Năm 1789, Quang Trung đại phá quân xâm lược nào ở Ngọc Hồi – Đống Đa?','quân Thanh','quân Minh','quân Nguyên','quân Pháp'],
  [2,'Triều đại phong kiến cuối cùng của Việt Nam là triều nào?','nhà Nguyễn','nhà Lê','nhà Trần','nhà Lý'],
  [3,'Nêu một thành tựu của phong trào Tây Sơn.','Ví dụ: lật đổ các chính quyền phong kiến, đánh tan quân Xiêm và quân Thanh, thống nhất đất nước…'],
 ]},
 {cd:'Địa lí: Tự nhiên Việt Nam',q:[
  [1,'Phần lớn địa hình nước ta là dạng nào?','đồi núi','đồng bằng','cao nguyên băng','hoang mạc'],
  [1,'Nước ta có khí hậu đặc trưng nào?','nhiệt đới ẩm gió mùa','ôn đới lạnh','hàn đới','hoang mạc khô'],
  [2,'Hai đồng bằng châu thổ lớn nhất nước ta là?','đồng bằng sông Hồng và đồng bằng sông Cửu Long','đồng bằng Thanh – Nghệ','cao nguyên và trung du','Tây Nguyên'],
  [3,'Nêu một biện pháp bảo vệ tài nguyên thiên nhiên nước ta.','Ví dụ: trồng và bảo vệ rừng, chống ô nhiễm, khai thác hợp lí…'],
 ]}];
NH['Lịch sử và Địa lí'][9]=[
 {cd:'Lịch sử: Việt Nam và thế giới thế kỉ XX',q:[
  [1,'Đảng Cộng sản Việt Nam được thành lập vào năm nào?','1930','1945','1954','1975'],
  [1,'Cách mạng tháng Tám thành công, nước Việt Nam Dân chủ Cộng hòa ra đời năm nào?','1945','1930','1954','1975'],
  [2,'Chiến thắng Điện Biên Phủ (1954) kết thúc cuộc kháng chiến chống thực dân nào?','thực dân Pháp','phát xít Nhật','đế quốc Mỹ','quân Thanh'],
  [2,'Đất nước Việt Nam thống nhất vào năm nào?','1975','1945','1954','1986'],
  [3,'Nêu ý nghĩa của Cách mạng tháng Tám năm 1945.','Lật đổ ách thống trị của thực dân – phong kiến, giành độc lập, lập ra nước Việt Nam Dân chủ Cộng hòa.'],
 ]},
 {cd:'Địa lí: Dân cư và kinh tế Việt Nam',q:[
  [1,'Việt Nam là quốc gia có bao nhiêu dân tộc anh em?','54','45','64','30'],
  [2,'Ngành kinh tế nào cung cấp lương thực, thực phẩm chính?','nông nghiệp','khai khoáng','du lịch','ngân hàng'],
  [2,'Vùng kinh tế nào là vựa lúa lớn nhất nước ta?','Đồng bằng sông Cửu Long','Tây Nguyên','Đông Nam Bộ','Trung du miền núi Bắc Bộ'],
  [3,'Nêu một thế mạnh kinh tế của vùng em đang sống (hoặc một vùng em biết).','Ví dụ: du lịch biển ở Hạ Long – Quảng Ninh; trồng cà phê ở Tây Nguyên; công nghiệp ở Đông Nam Bộ…'],
 ]}];

/* ================= GIÁO DỤC CÔNG DÂN (THCS, lớp 6-9) ================= */
NH['Giáo dục công dân']={
6:[
 {cd:'Phẩm chất đạo đức',q:[
  [1,'Tự hào về truyền thống gia đình, dòng họ thể hiện điều gì?','biết ơn và giữ gìn giá trị tốt đẹp của gia đình','khoe khoang','coi thường người khác','ỷ lại'],
  [1,'Hành vi nào thể hiện tính tự lập?','tự làm bài tập của mình','chép bài bạn','nhờ người khác làm hộ','trốn việc'],
  [2,'Khi bạn gặp khó khăn, việc làm nào thể hiện sự yêu thương con người?','động viên, giúp đỡ bạn','chế giễu bạn','làm ngơ','nói xấu bạn'],
  [2,'Siêng năng, kiên trì giúp con người điều gì?','đạt được mục tiêu, thành công','lười biếng hơn','mất thời gian','thất bại'],
  [3,'Nêu một việc em đã làm thể hiện sự tự lập.','Ví dụ: tự dậy sớm đi học, tự chuẩn bị sách vở, tự giặt quần áo…'],
 ]},
 {cd:'Pháp luật và quyền công dân',q:[
  [1,'Công dân nước Cộng hòa xã hội chủ nghĩa Việt Nam là người có quốc tịch nào?','quốc tịch Việt Nam','bất kì quốc tịch nào','không cần quốc tịch','quốc tịch nước ngoài'],
  [2,'Khi gặp tình huống nguy hiểm (cháy, đuối nước…), em nên làm gì?','bình tĩnh, tìm cách thoát và gọi người lớn/cứu hộ','hoảng loạn la hét vô ích','giấu đi','mặc kệ'],
  [3,'Nêu một quyền cơ bản của trẻ em.','Ví dụ: quyền được học tập, được chăm sóc, được vui chơi, được bảo vệ…'],
 ]}],
7:[
 {cd:'Giá trị sống và kĩ năng',q:[
  [1,'Giữ chữ tín nghĩa là gì?','coi trọng lòng tin, giữ đúng lời hứa','hứa cho qua chuyện','nói dối','thất hứa'],
  [1,'Hành vi nào thể hiện quan tâm, cảm thông, chia sẻ?','an ủi, giúp đỡ người gặp khó khăn','thờ ơ','trêu chọc','xa lánh'],
  [2,'Khi bị căng thẳng (áp lực học tập), cách ứng phó tích cực là gì?','nghỉ ngơi hợp lí, chia sẻ với người tin cậy','bỏ học','cáu gắt với mọi người','thức rất khuya'],
  [2,'Bảo tồn di sản văn hóa là trách nhiệm của ai?','của mọi công dân','chỉ của nhà nước','chỉ của người già','không của ai'],
  [3,'Nêu một việc em làm để quản lí tiền hợp lí.','Ví dụ: tiết kiệm, chi tiêu có kế hoạch, không mua đồ không cần thiết…'],
 ]},
 {cd:'Phòng chống tệ nạn, bạo lực',q:[
  [1,'Khi bị bạo lực học đường, em nên làm gì?','báo cho thầy cô, cha mẹ, người lớn tin cậy','im lặng chịu đựng','đánh lại để trả thù','bỏ học'],
  [2,'Tệ nạn xã hội nào sau đây cần phòng tránh?','ma túy, cờ bạc','học nhóm','đọc sách','tập thể dục'],
  [3,'Nêu 2 việc em làm để phòng tránh tệ nạn xã hội.','Ví dụ: không tò mò thử chất cấm, chọn bạn tốt, tham gia hoạt động lành mạnh, báo người lớn khi bị rủ rê…'],
 ]}],
8:[
 {cd:'Đạo đức và lối sống',q:[
  [1,'Tôn trọng sự đa dạng của các dân tộc thể hiện qua thái độ nào?','học hỏi, tôn trọng sự khác biệt về văn hóa','kì thị','coi thường','chê bai'],
  [1,'Lao động cần cù, sáng tạo đem lại điều gì?','hiệu quả công việc cao, của cải cho xã hội','lãng phí','thất bại','nghèo đói'],
  [2,'Bảo vệ lẽ phải là hành động nào?','bênh vực điều đúng, phê phán điều sai','theo số đông bất kể đúng sai','im lặng trước cái sai','làm theo cái sai'],
  [3,'Nêu một truyền thống tốt đẹp của dân tộc Việt Nam.','Ví dụ: yêu nước, đoàn kết, hiếu học, tôn sư trọng đạo, uống nước nhớ nguồn…'],
 ]},
 {cd:'Pháp luật, kinh tế',q:[
  [1,'Phòng ngừa tai nạn vũ khí, cháy nổ, chất độc hại là trách nhiệm của ai?','của mọi người','chỉ công an','chỉ người lớn','không của ai'],
  [2,'Lập kế hoạch chi tiêu hợp lí giúp em điều gì?','quản lí tiền tốt, tránh lãng phí','tiêu hết tiền nhanh','mua nhiều đồ vô ích','mắc nợ'],
  [3,'Nêu một việc thể hiện em tôn trọng pháp luật.','Ví dụ: chấp hành luật giao thông, không vứt rác bừa bãi, nộp bài đúng hạn…'],
 ]}],
9:[
 {cd:'Công dân với đạo đức và pháp luật',q:[
  [1,'Sống có lí tưởng là gì?','xác định mục đích cao đẹp và phấn đấu thực hiện','sống không mục tiêu','chỉ lo hưởng thụ','buông thả'],
  [1,'Khoan dung là gì?','rộng lòng tha thứ cho người khác','cố chấp','thù hằn','ích kỉ'],
  [2,'Tích cực tham gia hoạt động cộng đồng thể hiện điều gì?','trách nhiệm của công dân với xã hội','sự rảnh rỗi vô ích','làm màu','ép buộc'],
  [2,'Vi phạm pháp luật là hành vi như thế nào?','trái pháp luật, có lỗi, do người có năng lực trách nhiệm thực hiện','đúng pháp luật','được khuyến khích','không liên quan pháp luật'],
  [3,'Nêu một việc làm thể hiện trách nhiệm của học sinh trong việc bảo vệ Tổ quốc.','Ví dụ: học tập tốt, rèn luyện sức khỏe, giữ gìn an ninh trật tự, tuyên truyền pháp luật…'],
 ]},
 {cd:'Quản lí bản thân, hướng nghiệp',q:[
  [1,'Quản lí thời gian hiệu quả giúp em điều gì?','học tập và sinh hoạt cân đối, đạt kết quả tốt','lãng phí thời gian','mệt mỏi','trì hoãn'],
  [2,'Khi chọn nghề, yếu tố quan trọng cần cân nhắc là gì?','sở thích, năng lực và nhu cầu xã hội','chọn theo bạn','chọn ngẫu nhiên','nghe lời xúi giục'],
  [3,'Nêu một mục tiêu học tập của em trong năm học này và cách thực hiện.','Ví dụ: đạt học sinh giỏi → lập thời gian biểu, chăm học, hỏi thầy cô khi chưa hiểu…'],
 ]}]};

/* ================= NGỮ VĂN (THCS, lớp 6-9) ================= */
NH['Ngữ văn']={
6:[
 {cd:'Tiếng Việt: từ loại, biện pháp tu từ',q:[
  [1,'Từ "chạy nhảy" thuộc loại từ nào xét về cấu tạo?','từ ghép','từ đơn','từ láy','số từ'],
  [1,'Từ nào sau đây là từ láy?','long lanh','bàn ghế','sách vở','cây cối'],
  [2,'Câu "Mặt trời xuống biển như hòn lửa" sử dụng biện pháp tu từ nào?','so sánh','nhân hóa','ẩn dụ','điệp ngữ'],
  [2,'Biện pháp tu từ gọi vật như gọi người ("Ông mặt trời") là gì?','nhân hóa','so sánh','hoán dụ','nói quá'],
  [3,'Đặt một câu có sử dụng biện pháp so sánh.','Ví dụ: Cô giáo hiền như mẹ hiền. / Trường em đẹp như một bức tranh.'],
 ]},
 {cd:'Đọc – hiểu và kiến thức văn học',q:[
  [1,'Truyện "Thánh Gióng", "Sơn Tinh, Thủy Tinh" thuộc thể loại nào?','truyền thuyết','truyện cười','truyện ngắn hiện đại','kí'],
  [1,'Truyện "Thạch Sanh", "Cây khế" thuộc thể loại nào?','truyện cổ tích','thần thoại','tiểu thuyết','thơ'],
  [2,'Yếu tố thường có trong truyền thuyết là gì?','yếu tố kì ảo và cốt lõi lịch sử','số liệu khoa học','biểu đồ','công thức'],
  [3,'Nêu bài học em rút ra từ một truyện cổ tích em đã học.','Ví dụ: ở hiền gặp lành, cái thiện thắng cái ác (truyện Thạch Sanh, Cây khế…).'],
 ]},
 {cd:'Viết',q:[
  [3,'Viết mở đoạn (2–3 câu) kể lại một trải nghiệm đáng nhớ của em.','Gợi ý: giới thiệu trải nghiệm (thời gian, địa điểm, sự việc chính) rồi dẫn vào câu chuyện.'],
  [3,'Nêu dàn ý 3 phần của bài văn kể lại một trải nghiệm.','Mở bài: giới thiệu trải nghiệm. Thân bài: kể diễn biến theo trình tự. Kết bài: cảm nghĩ, bài học.'],
 ]}],
7:[
 {cd:'Tiếng Việt: từ, cụm từ, dấu câu',q:[
  [1,'Từ "xe đạp" là loại từ nào?','từ ghép','từ láy','từ đơn','thán từ'],
  [1,'Trạng ngữ trong câu "Sáng nay, em đi học" chỉ gì?','thời gian','nơi chốn','nguyên nhân','mục đích'],
  [2,'Thành ngữ "Chậm như rùa" sử dụng biện pháp gì?','so sánh','nhân hóa','ẩn dụ','điệp từ'],
  [2,'Số từ trong câu "Nhà em có ba người" là từ nào?','ba','nhà','người','có'],
  [3,'Đặt một câu có trạng ngữ chỉ nơi chốn.','Ví dụ: Trên sân trường, các bạn đang chơi đùa.'],
 ]},
 {cd:'Đọc – hiểu và kiến thức văn học',q:[
  [1,'Thơ bốn chữ, năm chữ thường có đặc điểm gì?','mỗi dòng có 4 hoặc 5 tiếng, giàu nhạc điệu','mỗi dòng 8 tiếng','không vần','văn xuôi'],
  [1,'"Tục ngữ" là gì?','câu nói dân gian ngắn gọn đúc kết kinh nghiệm','bài thơ dài','truyện cổ tích','tiểu thuyết'],
  [2,'Truyện ngụ ngôn thường nhằm mục đích gì?','nêu bài học, lời khuyên qua câu chuyện','ghi chép lịch sử','miêu tả khoa học','quảng cáo'],
  [3,'Giải thích ý nghĩa câu tục ngữ "Có công mài sắt, có ngày nên kim".','Kiên trì, chịu khó thì việc khó đến đâu cũng thành công.'],
 ]},
 {cd:'Viết',q:[
  [3,'Nêu dàn ý bài văn biểu cảm về một người thân.','Mở bài: giới thiệu người thân. Thân bài: nêu đặc điểm, kỉ niệm, tình cảm. Kết bài: khẳng định tình cảm.'],
  [3,'Viết 2–3 câu nêu cảm nghĩ của em về một bài thơ em thích.','Gợi ý: nêu tên bài thơ, điều em thích (hình ảnh, cảm xúc) và lí do.'],
 ]}],
8:[
 {cd:'Tiếng Việt: câu, biện pháp tu từ',q:[
  [1,'Câu "Ôi, đẹp quá!" là kiểu câu gì xét theo mục đích nói?','câu cảm thán','câu cầu khiến','câu nghi vấn','câu trần thuật'],
  [1,'Biện pháp "nói quá" (phóng đại) nhằm mục đích gì?','nhấn mạnh, gây ấn tượng','nói giảm','liệt kê','so sánh ngang bằng'],
  [2,'Câu "Bạn có thể giúp mình không?" là kiểu câu gì?','câu nghi vấn','câu cảm thán','câu cầu khiến','câu kể'],
  [2,'Từ Hán Việt "giang sơn" có nghĩa gần với từ thuần Việt nào?','sông núi (đất nước)','biển cả','rừng cây','bầu trời'],
  [3,'Đặt một câu có sử dụng biện pháp nói giảm, nói tránh.','Ví dụ: Ông em đã đi xa (thay cho "đã mất").'],
 ]},
 {cd:'Đọc – hiểu và kiến thức văn học',q:[
  [1,'Thơ thất ngôn bát cú Đường luật có mấy câu, mỗi câu mấy chữ?','8 câu, mỗi câu 7 chữ','4 câu, 7 chữ','8 câu, 8 chữ','6 câu, 8 chữ'],
  [2,'Thơ trào phúng chủ yếu nhằm mục đích gì?','châm biếm, phê phán cái xấu bằng tiếng cười','ca ngợi thiên nhiên','kể chuyện lịch sử','miêu tả khoa học'],
  [2,'Văn bản nghị luận dùng để làm gì?','bàn luận, thuyết phục người đọc về một vấn đề','kể chuyện','miêu tả','biểu cảm'],
  [3,'Nêu các yếu tố cơ bản của một bài văn nghị luận.','Luận điểm, lí lẽ và bằng chứng (dẫn chứng).'],
 ]},
 {cd:'Viết',q:[
  [3,'Nêu dàn ý bài văn nghị luận về một vấn đề đời sống.','Mở bài: nêu vấn đề. Thân bài: nêu luận điểm, lí lẽ, bằng chứng. Kết bài: khẳng định, liên hệ.'],
  [3,'Viết câu nêu luận điểm cho đề: "Lợi ích của việc đọc sách".','Ví dụ: Đọc sách mang lại nhiều lợi ích: mở mang hiểu biết, nuôi dưỡng tâm hồn và rèn luyện tư duy.'],
 ]}],
9:[
 {cd:'Tiếng Việt: nghĩa của từ, cách dẫn',q:[
  [1,'Cách dẫn lại nguyên văn lời nói, đặt trong dấu ngoặc kép gọi là gì?','dẫn trực tiếp','dẫn gián tiếp','ẩn dụ','hoán dụ'],
  [1,'Từ "xuân" trong "tuổi xuân" được dùng theo nghĩa nào?','nghĩa chuyển (tuổi trẻ)','nghĩa gốc (mùa xuân)','từ đồng âm','từ trái nghĩa'],
  [2,'Biện pháp tu từ trong "Thuyền về có nhớ bến chăng" là gì?','ẩn dụ (thuyền – bến chỉ người)','so sánh','liệt kê','nói quá'],
  [3,'Chuyển câu sau sang lời dẫn gián tiếp: Lan nói: "Tôi sẽ đến."','Lan nói rằng Lan sẽ đến. (bỏ ngoặc kép, đổi ngôi phù hợp)'],
 ]},
 {cd:'Đọc – hiểu và kiến thức văn học',q:[
  [1,'"Truyện Kiều" là tác phẩm của tác giả nào?','Nguyễn Du','Nguyễn Trãi','Hồ Xuân Hương','Nguyễn Khuyến'],
  [1,'"Truyện Kiều" được viết bằng thể thơ nào?','lục bát','thất ngôn bát cú','song thất lục bát','tự do'],
  [2,'Văn bản nghị luận xã hội bàn về vấn đề gì?','các vấn đề của đời sống xã hội, con người','chỉ về tác phẩm văn học','công thức toán','lịch sử'],
  [3,'Nêu một giá trị nội dung của "Truyện Kiều".','Ví dụ: giá trị hiện thực (tố cáo xã hội) và giá trị nhân đạo (thương xót, đề cao con người).'],
 ]},
 {cd:'Viết',q:[
  [3,'Nêu dàn ý bài văn nghị luận về một vấn đề cần giải quyết trong đời sống.','Mở bài: nêu vấn đề. Thân bài: phân tích thực trạng, nguyên nhân, đề xuất giải pháp. Kết bài: khẳng định.'],
  [3,'Viết câu nêu vấn đề nghị luận cho đề: "Sử dụng mạng xã hội của học sinh hiện nay".','Ví dụ: Việc sử dụng mạng xã hội đang ảnh hưởng lớn đến học tập và lối sống của học sinh, cần được nhìn nhận đúng đắn.'],
 ]}]};


/* ================= ÂM NHẠC / MĨ THUẬT / GDTC / HĐTN (THCS, lớp 6-9) ================= */
/* --- ÂM NHẠC --- */
const _AN=l=>[
 {cd:'Lí thuyết âm nhạc',q:[
  [1,'Khuông nhạc gồm bao nhiêu dòng kẻ?','5 dòng','4 dòng','6 dòng','7 dòng'],
  [1,'Có bao nhiêu nốt nhạc cơ bản?','7 nốt (Đô Rê Mi Pha Son La Si)','5 nốt','8 nốt','10 nốt'],
  [2,'Dấu lặng trong bản nhạc biểu thị điều gì?','thời gian nghỉ (ngừng âm thanh)','hát to lên','hát nhanh lên','kết bài'],
  [3,'Nhịp 2/4 cho biết điều gì?','mỗi ô nhịp có 2 phách, mỗi phách bằng một nốt đen','có 4 phách','hát tự do','không có phách'],
 ]},
 {cd:'Thường thức âm nhạc',q:[
  [1,'Hát kết hợp vận động giúp ích gì?','cảm nhận nhịp điệu, tự tin biểu diễn','mệt mỏi','mất tập trung','không có lợi'],
  [2,'Nhạc cụ nào sau đây là nhạc cụ dân tộc Việt Nam?','đàn bầu','piano','violin','guitar điện'],
  [3,'Nêu một việc nên làm để hát đúng và hay hơn.','Ví dụ: lấy hơi đúng cách, hát rõ lời, đúng cao độ – trường độ, luyện tập thường xuyên…'],
 ]}];
NH['Âm nhạc'][6]=_AN(6);NH['Âm nhạc'][7]=_AN(7);NH['Âm nhạc'][8]=_AN(8);NH['Âm nhạc'][9]=_AN(9);

/* --- MĨ THUẬT --- */
const _MT=l=>[
 {cd:'Kiến thức tạo hình',q:[
  [1,'Ba màu cơ bản trong hội họa là gì?','đỏ, vàng, lam','đen, trắng, xám','xanh lá, cam, tím','nâu, hồng, be'],
  [1,'Trộn màu vàng với màu lam (xanh dương) được màu gì?','xanh lá','cam','tím','nâu'],
  [2,'Yếu tố nào tạo nên hình khối, chiều sâu trong tranh?','đậm nhạt (sáng – tối)','chỉ đường nét','chỉ chữ viết','âm thanh'],
  [3,'Nêu các bước cơ bản để vẽ một bức tranh theo đề tài.','Tìm ý tưởng → phác bố cục (mảng chính, phụ) → vẽ hình → vẽ màu → hoàn thiện.'],
 ]},
 {cd:'Thường thức mĩ thuật',q:[
  [1,'Mĩ thuật ứng dụng là gì?','mĩ thuật phục vụ đời sống (thiết kế đồ vật, trang trí…)','chỉ vẽ tranh treo tường','không có thật','chỉ dùng trong bảo tàng'],
  [3,'Nêu một ví dụ về sản phẩm mĩ thuật ứng dụng trong đời sống.','Ví dụ: thiết kế bìa sách, logo, trang trí đồ dùng, thời trang, bao bì sản phẩm…'],
 ]}];
NH['Mĩ thuật'][6]=_MT(6);NH['Mĩ thuật'][7]=_MT(7);NH['Mĩ thuật'][8]=_MT(8);NH['Mĩ thuật'][9]=_MT(9);

/* --- GIÁO DỤC THỂ CHẤT --- */
const _TC=l=>[
 {cd:'Kiến thức chung về thể dục thể thao',q:[
  [1,'Tập luyện thể dục thể thao thường xuyên mang lại lợi ích gì?','nâng cao sức khỏe, phát triển thể lực','gây mệt mỏi lâu dài','có hại cho tim','làm chậm phát triển'],
  [1,'Trước khi vận động mạnh, cần làm gì để tránh chấn thương?','khởi động kĩ','ăn thật no','ngồi nghỉ','uống nhiều nước ngọt'],
  [2,'Khi bị chuột rút trong lúc tập, nên làm gì?','dừng lại, kéo giãn nhẹ cơ và nghỉ ngơi','cố chạy tiếp','nhịn đau tập mạnh hơn','bỏ chạy'],
  [3,'Nêu 2 môn thể thao em yêu thích và lợi ích của chúng.','Ví dụ: bóng đá, cầu lông, bơi, bóng rổ… giúp rèn sức bền, sự nhanh nhẹn, tinh thần đồng đội.'],
 ]},
 {cd:'Kĩ thuật và luật cơ bản',q:[
  [1,'Trong chạy cự li ngắn, giai đoạn nào quyết định tốc độ ban đầu?','xuất phát','về đích','đi bộ','nghỉ giữa'],
  [2,'Trong bóng đá, cầu thủ (trừ thủ môn) không được dùng bộ phận nào chơi bóng?','tay','chân','đầu','ngực'],
  [3,'Nêu một nguyên tắc để tập luyện thể thao an toàn.','Ví dụ: khởi động trước, tập vừa sức, đúng kĩ thuật, trang phục phù hợp, nghỉ khi mệt…'],
 ]}];
NH['Giáo dục thể chất'][6]=_TC(6);NH['Giáo dục thể chất'][7]=_TC(7);NH['Giáo dục thể chất'][8]=_TC(8);NH['Giáo dục thể chất'][9]=_TC(9);

/* --- HOẠT ĐỘNG TRẢI NGHIỆM, HƯỚNG NGHIỆP --- */
const _HD=l=>[
 {cd:'Kĩ năng sống, bản thân',q:[
  [1,'Để quản lí thời gian tốt, em nên làm gì?','lập thời gian biểu và thực hiện','làm việc tùy hứng','trì hoãn','thức khuya chơi'],
  [2,'Khi gặp mâu thuẫn với bạn, cách ứng xử phù hợp là gì?','bình tĩnh trao đổi, lắng nghe nhau','cãi nhau to','giận dỗi bỏ đi','rủ người đánh bạn'],
  [2,'Đức tính nào giúp em hoàn thành công việc dù khó khăn?','kiên trì','lười biếng','nóng vội','bỏ cuộc'],
  [3,'Nêu một mục tiêu rèn luyện bản thân của em và cách thực hiện.','Ví dụ: rèn thói quen dậy sớm → đặt báo thức, đi ngủ đúng giờ, kiên trì mỗi ngày…'],
 ]},
 {cd:'Trách nhiệm với gia đình, cộng đồng và hướng nghiệp',q:[
  [1,'Việc làm nào thể hiện trách nhiệm với gia đình?','giúp đỡ việc nhà phù hợp','ỷ lại bố mẹ','đòi hỏi','vô tâm'],
  [2,'Tham gia hoạt động thiện nguyện ở cộng đồng giúp em điều gì?','biết chia sẻ, sống có ích','mất thời gian vô ích','không có lợi','bị thiệt'],
  [3,'Để chọn nghề phù hợp trong tương lai, em cần tìm hiểu những gì?','Sở thích, năng lực của bản thân và nhu cầu, đặc điểm của các ngành nghề trong xã hội.'],
 ]}];
NH['Hoạt động trải nghiệm'][6]=_HD(6);NH['Hoạt động trải nghiệm'][7]=_HD(7);NH['Hoạt động trải nghiệm'][8]=_HD(8);NH['Hoạt động trải nghiệm'][9]=_HD(9);

/* ########## MỞ RỘNG NGÂN HÀNG THCS (v5.5) ########## */
/* ============================================================
   MỞ RỘNG NGÂN HÀNG CÂU HỎI THCS (bổ sung, giữ nguyên câu cũ)
   Nhóm 1: Lịch sử & Địa lí, GDCD, Công nghệ, Tin học
   Định dạng: TN [mức,'câu','ĐÚNG','sai','sai','sai'] ; TL [mức,'câu','đáp án']
   ============================================================ */

/* ---------- LỊCH SỬ VÀ ĐỊA LÍ ---------- */
NH['Lịch sử và Địa lí'][6].push(
 {cd:'Lịch sử: Việt Nam thời nguyên thủy – Văn Lang, Âu Lạc',q:[
  [1,'Công cụ lao động đầu tiên của người nguyên thủy chủ yếu làm bằng gì?','đá','sắt','nhựa','nhôm'],
  [1,'Kinh đô của nhà nước Âu Lạc đặt ở đâu?','Cổ Loa','Phong Châu','Hoa Lư','Thăng Long'],
  [2,'Thành Cổ Loa gắn với tên tuổi vị vua nào?','An Dương Vương','Hùng Vương','Lý Thái Tổ','Ngô Quyền'],
  [2,'Nghề sản xuất chính của cư dân Văn Lang – Âu Lạc là gì?','trồng lúa nước','buôn bán đường biển','khai thác dầu mỏ','làm công nghiệp'],
  [3,'Nêu một thành tựu tiêu biểu của cư dân Văn Lang – Âu Lạc.','Ví dụ: trống đồng Đông Sơn, kĩ thuật luyện kim (đúc đồng), trồng lúa nước, xây thành Cổ Loa…'],
 ]},
 {cd:'Địa lí: Khí hậu, nước và đất',q:[
  [1,'Lớp không khí bao quanh Trái Đất gọi là gì?','khí quyển','thạch quyển','thủy quyển','sinh quyển'],
  [1,'Nước trên Trái Đất tồn tại chủ yếu ở đại dương, chiếm khoảng bao nhiêu?','hơn 97% là nước mặn','90% là nước ngọt','một nửa là băng','rất ít nước'],
  [2,'Gió Mậu dịch (Tín phong) thổi từ đâu về Xích đạo?','từ khoảng vĩ độ 30° về Xích đạo','từ cực về Xích đạo','từ Xích đạo lên cực','từ biển vào đất liền ban ngày'],
  [3,'Nêu một biện pháp sử dụng tiết kiệm nguồn nước ngọt.','Ví dụ: khóa vòi khi không dùng, tái sử dụng nước, chống ô nhiễm nguồn nước, tưới tiết kiệm…'],
 ]}
);
NH['Lịch sử và Địa lí'][7].push(
 {cd:'Lịch sử: Thế giới và khu vực thời trung đại',q:[
  [1,'Các cuộc phát kiến địa lí thế kỉ XV–XVI do các nước nào đi đầu?','Bồ Đào Nha và Tây Ban Nha','Anh và Pháp','Trung Quốc và Ấn Độ','Nga và Đức'],
  [1,'Vương quốc Cam-pu-chia phát triển rực rỡ nhất gắn với công trình nào?','Ăng-co (Angkor)','Vạn Lí Trường Thành','Taj Mahal','đền Pác-tê-nông'],
  [2,'Phong trào Văn hóa Phục hưng ở châu Âu đề cao điều gì?','giá trị con người và tri thức khoa học','chế độ phong kiến','thần quyền tuyệt đối','chiến tranh'],
  [3,'Nêu một hệ quả của các cuộc phát kiến địa lí.','Ví dụ: tìm ra những vùng đất mới, thúc đẩy giao thương, nhưng cũng dẫn tới xâm chiếm thuộc địa…'],
 ]},
 {cd:'Địa lí: Thiên nhiên các châu lục',q:[
  [1,'Châu Phi có đường nào đi qua gần giữa châu lục?','đường Xích đạo','chí tuyến Bắc duy nhất','vòng cực Bắc','kinh tuyến gốc duy nhất'],
  [2,'Khí hậu đặc trưng của phần lớn châu Phi là gì?','nóng và khô','lạnh quanh năm','ôn hòa, mưa đều','băng giá'],
  [2,'Dãy núi trẻ cao đồ sộ nhất châu Á là dãy nào?','Hi-ma-lay-a','U-ran','An-pơ','A-pa-lat'],
  [3,'Nêu một đặc điểm dân cư của châu Á.','Ví dụ: đông dân nhất thế giới, nhiều chủng tộc, tập trung ở đồng bằng và ven biển…'],
 ]}
);
NH['Lịch sử và Địa lí'][8].push(
 {cd:'Lịch sử: Thế giới cận đại và Việt Nam',q:[
  [1,'Cách mạng công nghiệp bắt đầu sớm nhất ở nước nào?','nước Anh','nước Pháp','nước Mỹ','nước Nhật'],
  [1,'Thực dân Pháp nổ súng xâm lược Việt Nam đầu tiên tại đâu (1858)?','Đà Nẵng','Hà Nội','Gia Định','Huế'],
  [2,'Cuộc Cách mạng tư sản Pháp 1789 có khẩu hiệu nổi tiếng nào?','Tự do – Bình đẳng – Bác ái','Độc lập – Tự do','Đất đai cho dân cày','Hòa bình – Ruộng đất'],
  [3,'Nêu một tác động của cách mạng công nghiệp.','Ví dụ: máy móc thay lao động thủ công, sản xuất tăng mạnh, hình thành giai cấp công nhân, đô thị phát triển…'],
 ]},
 {cd:'Địa lí: Khí hậu, sông ngòi, đất và sinh vật Việt Nam',q:[
  [1,'Sông ngòi nước ta có đặc điểm nổi bật nào?','nhiều nước, giàu phù sa','rất ít nước','đóng băng mùa đông','không có phù sa'],
  [2,'Khí hậu nước ta phân hóa rõ theo yếu tố nào?','theo mùa và theo chiều Bắc – Nam, theo độ cao','không phân hóa','chỉ theo giờ','theo ngày chẵn lẻ'],
  [2,'Hệ sinh thái rừng nào đặc trưng ở vùng ven biển ngập mặn nước ta?','rừng ngập mặn','rừng lá kim','rừng ôn đới','rừng taiga'],
  [3,'Nêu một giá trị của sông ngòi đối với đời sống và sản xuất.','Ví dụ: cung cấp nước tưới, thủy sản, giao thông, thủy điện, bồi đắp phù sa…'],
 ]}
);
NH['Lịch sử và Địa lí'][9].push(
 {cd:'Lịch sử: Việt Nam và thế giới sau 1945',q:[
  [1,'Chiến dịch lịch sử kết thúc kháng chiến chống Mĩ, giải phóng miền Nam năm 1975 tên là gì?','Chiến dịch Hồ Chí Minh','Chiến dịch Điện Biên Phủ','Chiến dịch Biên giới','Chiến dịch Việt Bắc'],
  [1,'Công cuộc Đổi mới của nước ta bắt đầu từ năm nào?','1986','1975','1954','1945'],
  [2,'Tổ chức Liên hợp quốc (UN) được thành lập nhằm mục đích chính nào?','duy trì hòa bình và an ninh thế giới','gây chiến tranh','chia lại thuộc địa','cạnh tranh kinh tế'],
  [3,'Nêu một thành tựu của công cuộc Đổi mới ở nước ta.','Ví dụ: kinh tế tăng trưởng, đời sống nâng cao, hội nhập quốc tế, xóa đói giảm nghèo…'],
 ]},
 {cd:'Địa lí: Các vùng kinh tế và biển đảo',q:[
  [1,'Vùng nào là trung tâm công nghiệp và dịch vụ lớn nhất phía Nam?','Đông Nam Bộ','Tây Nguyên','Bắc Trung Bộ','Trung du miền núi Bắc Bộ'],
  [2,'Vùng Tây Nguyên có thế mạnh nổi bật về cây công nghiệp nào?','cà phê','lúa nước','chè vùng cao duy nhất','cao su chỉ ở miền Bắc'],
  [2,'Hai quần đảo xa bờ thuộc chủ quyền Việt Nam trên Biển Đông là?','Hoàng Sa và Trường Sa','Cát Bà và Cô Tô','Phú Quốc và Côn Đảo','Lý Sơn và Cái Bầu'],
  [3,'Nêu một việc học sinh có thể làm để góp phần bảo vệ chủ quyền biển đảo.','Ví dụ: tìm hiểu và tuyên truyền về biển đảo, giữ gìn môi trường biển, tự hào và ủng hộ lực lượng bảo vệ biển đảo…'],
 ]}
);

/* ---------- GIÁO DỤC CÔNG DÂN ---------- */
NH['Giáo dục công dân'][6].push(
 {cd:'Ứng xử và kĩ năng sống',q:[
  [1,'Người biết ứng phó với tình huống nguy hiểm là người thế nào?','bình tĩnh, biết tự bảo vệ và tìm sự giúp đỡ','hoảng loạn','liều lĩnh','thờ ơ'],
  [1,'Tiết kiệm là biết sử dụng hợp lí thứ gì?','của cải, thời gian, sức lực','chỉ tiền của người khác','mọi thứ một cách keo kiệt','không dùng gì cả'],
  [2,'Hành vi nào thể hiện tôn trọng sự thật?','nói đúng sự thật, dám nhận lỗi','bao che cái sai','nói dối để có lợi','đổ lỗi cho người khác'],
  [3,'Nêu một việc em làm thể hiện sự tiết kiệm trong sinh hoạt hằng ngày.','Ví dụ: tắt điện khi không dùng, giữ gìn đồ dùng học tập, không lãng phí thức ăn…'],
 ]}
);
NH['Giáo dục công dân'][7].push(
 {cd:'Quyền và nghĩa vụ công dân',q:[
  [1,'Phòng chống bạo lực học đường là trách nhiệm của ai?','của nhà trường, gia đình và mỗi học sinh','chỉ của thầy cô','chỉ của công an','không của ai'],
  [1,'Học tập tự giác, tích cực đem lại điều gì?','kết quả tốt và sự tiến bộ của bản thân','mệt mỏi vô ích','điểm kém','lãng phí'],
  [2,'Khi phát hiện bạn có dấu hiệu bị lôi kéo vào tệ nạn, em nên làm gì?','khuyên bạn và báo người lớn tin cậy','giấu đi','cùng tham gia','xa lánh bạn'],
  [3,'Nêu một biểu hiện của việc giữ chữ tín trong học tập.','Ví dụ: nộp bài đúng hẹn, thực hiện đúng cam kết với thầy cô và bạn bè, không gian lận…'],
 ]}
);
NH['Giáo dục công dân'][8].push(
 {cd:'Trách nhiệm và kĩ năng công dân',q:[
  [1,'Tôn trọng sự thật giúp con người và xã hội điều gì?','trở nên tốt đẹp, đáng tin cậy hơn','chia rẽ','gian dối hơn','mất đoàn kết'],
  [1,'Xác định mục tiêu cá nhân cần bảo đảm yêu cầu nào?','cụ thể, phù hợp, có thời hạn','mơ hồ','không thể thực hiện','sao chép của người khác'],
  [2,'Khi tham gia hoạt động cộng đồng, thái độ đúng đắn là gì?','tự nguyện, nhiệt tình, có trách nhiệm','làm cho có','trốn tránh','đòi trả công mới làm'],
  [3,'Nêu một mục tiêu cá nhân của em và một việc làm để đạt được nó.','Ví dụ: nói tiếng Anh tốt hơn → mỗi ngày học 10 từ mới và luyện nghe 15 phút…'],
 ]}
);
NH['Giáo dục công dân'][9].push(
 {cd:'Công dân với kinh tế và cộng đồng',q:[
  [1,'Tiêu dùng thông minh là tiêu dùng như thế nào?','có kế hoạch, phù hợp nhu cầu và khả năng','mua theo cảm hứng','chạy theo mốt','vay mượn để tiêu'],
  [1,'Khách quan, công bằng thể hiện qua việc gì?','nhìn nhận, đánh giá sự việc đúng bản chất, không thiên vị','bênh người thân bất kể đúng sai','theo số đông','vì lợi ích riêng'],
  [2,'Tích cực tham gia hoạt động vì cộng đồng giúp em rèn luyện điều gì?','tinh thần trách nhiệm, biết chia sẻ','tính ích kỉ','sự lười biếng','thói vô cảm'],
  [3,'Nêu một việc làm thể hiện em là người tiêu dùng thông minh.','Ví dụ: so sánh giá, chọn hàng cần thiết và có nguồn gốc rõ ràng, lập danh sách trước khi mua…'],
 ]}
);

/* ---------- CÔNG NGHỆ ---------- */
NH['Công nghệ'][6].push(
 {cd:'Thực phẩm và bảo quản, chế biến',q:[
  [1,'Nhóm thực phẩm nào cung cấp nhiều vitamin và chất xơ?','rau, củ, quả','thịt mỡ','đường, bánh kẹo','dầu ăn'],
  [1,'Để bảo quản thực phẩm tươi trong thời gian ngắn, ta thường dùng cách nào?','để trong tủ lạnh','để ngoài nắng','để nơi ẩm thấp','để gần bếp lửa'],
  [2,'Ăn uống hợp lí cần bảo đảm yêu cầu nào?','đủ chất, cân đối và an toàn vệ sinh','chỉ ăn thịt','ăn thật nhiều đường','bỏ bữa sáng'],
  [3,'Nêu một việc cần làm để giữ an toàn vệ sinh thực phẩm khi chế biến.','Ví dụ: rửa tay và dụng cụ sạch, rửa kĩ thực phẩm, nấu chín, để riêng đồ sống – chín…'],
 ]}
);
NH['Công nghệ'][7].push(
 {cd:'Rừng và thủy sản – kĩ thuật',q:[
  [1,'Thời vụ trồng rừng ở miền Bắc nước ta thường vào mùa nào?','mùa xuân','giữa mùa đông giá rét','mùa khô hạn nhất','ban đêm'],
  [1,'Thức ăn cho tôm, cá nuôi cần bảo đảm yêu cầu nào?','đủ dinh dưỡng, sạch, không ôi mốc','càng rẻ càng tốt dù hỏng','cho ăn thật nhiều một lúc','không cần quan tâm'],
  [2,'Để nuôi thủy sản đạt hiệu quả, cần quản lí tốt yếu tố nào của ao nuôi?','chất lượng nước (sạch, đủ oxy)','màu sơn bờ ao','số cây xung quanh','hướng gió ban đêm'],
  [3,'Nêu một biện pháp chăm sóc rừng sau khi trồng.','Ví dụ: làm cỏ, vun gốc, tưới nước, trồng dặm cây chết, phòng chống cháy rừng…'],
 ]}
);
NH['Công nghệ'][8].push(
 {cd:'Thiết kế kĩ thuật và an toàn lao động',q:[
  [1,'Khi đọc bản vẽ kĩ thuật, hình chiếu đứng nhìn vật thể từ hướng nào?','từ trước tới','từ dưới lên','từ sau tới','từ trong ra'],
  [1,'Trước khi sửa chữa đồ dùng điện trong nhà, việc đầu tiên cần làm là gì?','ngắt nguồn điện','bật công tắc lên','dùng tay ướt kiểm tra','gọi bạn tới xem'],
  [2,'Thiết kế kĩ thuật thường bắt đầu từ bước nào?','xác định nhu cầu, vấn đề cần giải quyết','sản xuất hàng loạt ngay','bỏ qua khâu ý tưởng','làm xong rồi mới nghĩ'],
  [3,'Nêu một dụng cụ bảo hộ lao động khi thực hành cơ khí và tác dụng của nó.','Ví dụ: kính bảo hộ (bảo vệ mắt), găng tay (bảo vệ tay), giày bảo hộ (bảo vệ chân)…'],
 ]}
);
NH['Công nghệ'][9].push(
 {cd:'Dinh dưỡng, chế biến và nghề nghiệp',q:[
  [1,'Phương pháp chế biến nào không dùng nhiệt?','trộn (nộm/gỏi)','luộc','rán','nướng'],
  [1,'Nghề đầu bếp thuộc lĩnh vực nào?','chế biến thực phẩm, dịch vụ ăn uống','xây dựng','may mặc','khai khoáng'],
  [2,'Để bữa ăn hợp lí, cần phối hợp các nhóm thực phẩm như thế nào?','đa dạng, cân đối giữa các nhóm chất','chỉ một nhóm duy nhất','toàn đồ chiên rán','bỏ rau xanh'],
  [3,'Nêu một yếu tố em cần cân nhắc khi lựa chọn nghề nghiệp tương lai.','Ví dụ: sở thích, năng lực bản thân, nhu cầu xã hội, điều kiện gia đình, cơ hội phát triển…'],
 ]}
);

/* ---------- TIN HỌC ---------- */
NH['Tin học'][6].push(
 {cd:'Sơ đồ tư duy, trình bày thông tin',q:[
  [1,'Sơ đồ tư duy giúp ích gì cho việc học?','tóm tắt, hệ thống hóa kiến thức trực quan','làm bài chậm hơn','gây rối thông tin','không có tác dụng'],
  [2,'Phần mềm soạn thảo văn bản dùng để làm gì?','tạo, chỉnh sửa và trình bày văn bản','nghe nhạc','tính toán bảng tính','vẽ mạch điện'],
  [3,'Nêu một ưu điểm của việc trình bày thông tin bằng bảng.','Ví dụ: dữ liệu rõ ràng, dễ so sánh, gọn gàng, dễ tìm kiếm…'],
 ]}
);
NH['Tin học'][7].push(
 {cd:'Phần mềm trình chiếu và bảng tính nâng cao',q:[
  [1,'Phần mềm trình chiếu dùng để làm gì?','tạo bài trình bày gồm các trang chiếu','gửi thư điện tử','diệt virus','nén tệp'],
  [1,'Trong bảng tính, hàm AVERAGE dùng để làm gì?','tính trung bình cộng','đếm số ô','tìm giá trị lớn nhất','nối chuỗi'],
  [2,'Khi tạo bài trình chiếu, nên trình bày nội dung như thế nào?','ngắn gọn, rõ ý, hình ảnh minh họa phù hợp','viết thật nhiều chữ','dùng quá nhiều màu lòe loẹt','đọc nguyên văn sách'],
  [3,'Nêu một việc nên làm để bài trình chiếu hấp dẫn, dễ hiểu.','Ví dụ: bố cục rõ ràng, cỡ chữ đủ lớn, dùng hình ảnh/biểu đồ, hạn chế chữ trên mỗi trang…'],
 ]}
);
NH['Tin học'][8].push(
 {cd:'Bảng tính và xử lí dữ liệu',q:[
  [1,'Trong bảng tính, để sắp xếp dữ liệu tăng/giảm ta dùng chức năng nào?','Sort (sắp xếp)','Delete','Print','Save'],
  [1,'Hàm nào đếm số ô có chứa số trong một vùng?','COUNT','SUM','IF','AND'],
  [2,'Chức năng Filter (lọc) trong bảng tính dùng để làm gì?','hiển thị những dòng thỏa mãn điều kiện','xóa toàn bộ dữ liệu','đổi màu nền','in tài liệu'],
  [2,'Địa chỉ tuyệt đối trong bảng tính (ví dụ $A$1) có đặc điểm gì?','không thay đổi khi sao chép công thức','luôn thay đổi theo ô','chỉ dùng cho chữ','không dùng được'],
  [3,'Nêu một tình huống thực tế nên dùng bảng tính để quản lí.','Ví dụ: quản lí điểm của lớp, thu – chi cá nhân, danh sách và thống kê số liệu…'],
 ]}
);
NH['Tin học'][9].push(
 {cd:'Thuật toán, lập trình và dữ liệu',q:[
  [1,'Trong lập trình, cấu trúc lặp với số lần biết trước thường dùng câu lệnh nào?','lặp với biến đếm (ví dụ for)','lệnh nhập dữ liệu','lệnh in','lệnh gán đơn giản'],
  [1,'Phần mềm mô phỏng giúp ích gì trong học tập?','quan sát, thử nghiệm hiện tượng khó thực hiện thực tế','thay thế hoàn toàn việc học','làm hỏng máy tính','không có ích'],
  [2,'Khi một thuật toán cho kết quả sai, việc cần làm là gì?','kiểm tra lại các bước và dữ liệu, sửa lỗi','bỏ luôn không làm','đổ lỗi cho máy','in ra kết quả sai'],
  [2,'Dữ liệu lớn (big data) được hiểu là gì?','khối lượng dữ liệu rất lớn, cần công cụ để xử lí','một tệp nhỏ','một con virus','một loại chuột'],
  [3,'Nêu các bước cơ bản để xây dựng một chương trình giải bài toán.','Xác định bài toán → thiết kế thuật toán → viết chương trình → kiểm thử, sửa lỗi và hoàn thiện.'],
 ]}
);

/* ============================================================
   MỞ RỘNG NGÂN HÀNG THCS – Nhóm 2: Âm nhạc, Mĩ thuật, GDTC, HĐTN
   (môn đánh giá Đạt/Chưa đạt; câu mang tính kiến thức chung, chọn theo khối)
   ============================================================ */
const _CLONE=a=>JSON.parse(JSON.stringify(a));

/* --- ÂM NHẠC: thêm cho mỗi khối --- */
const _AN_MORE=[
 {cd:'Nhạc lí và kí hiệu',q:[
  [1,'Dấu hóa nào làm nốt nhạc tăng lên nửa cung?','dấu thăng (#)','dấu giáng (♭)','dấu bình (♮)','dấu lặng'],
  [1,'Nhịp 4/4 (nhịp C) mỗi ô nhịp có mấy phách?','4 phách','2 phách','3 phách','6 phách'],
  [2,'Trường độ nốt trắng bằng mấy nốt đen?','2 nốt đen','1 nốt đen','4 nốt đen','nửa nốt đen'],
  [2,'Khi hát bè hoặc hát đuổi, điều quan trọng nhất là gì?','hòa giọng, giữ đúng nhịp với các bạn','hát thật to át người khác','hát nhanh hơn người khác','hát sai cũng được'],
  [3,'Nêu các bước chuẩn bị để hát tốt một bài hát mới.','Ví dụ: đọc lời, tìm hiểu nội dung, khởi động giọng, tập giai điệu từng câu, ghép cả bài, thể hiện sắc thái.'],
 ]},
 {cd:'Thường thức và biểu diễn',q:[
  [1,'Đàn nào sau đây là nhạc cụ phương Tây?','piano','đàn tranh','đàn nhị','sáo trúc'],
  [2,'Dân ca là gì?','những bài hát do nhân dân sáng tác, lưu truyền trong dân gian','bài hát của một nhạc sĩ nổi tiếng','nhạc nước ngoài','nhạc không lời'],
  [3,'Nêu một việc nên làm để giữ gìn, phát huy dân ca Việt Nam.','Ví dụ: tập hát dân ca, biểu diễn trong lớp/trường, giới thiệu cho bạn bè, trân trọng nghệ nhân…'],
 ]}
];
NH['Âm nhạc'][6].push(..._CLONE(_AN_MORE));NH['Âm nhạc'][7].push(..._CLONE(_AN_MORE));
NH['Âm nhạc'][8].push(..._CLONE(_AN_MORE));NH['Âm nhạc'][9].push(..._CLONE(_AN_MORE));

/* --- MĨ THUẬT: thêm cho mỗi khối --- */
const _MT_MORE=[
 {cd:'Yếu tố và nguyên lí tạo hình',q:[
  [1,'Màu nào sau đây là màu nóng?','đỏ','xanh lam','tím','xám'],
  [1,'Hòa sắc tương phản là sự kết hợp các màu như thế nào?','khác biệt rõ rệt, nổi bật bên nhau','gần giống nhau','chỉ một màu','toàn màu xám'],
  [2,'Trong bố cục tranh, mảng chính thường được đặt ở đâu?','vị trí trọng tâm, thu hút mắt nhìn','sát mép tranh','khuất góc','ngoài khung tranh'],
  [2,'Đường nét trong tranh có vai trò gì?','tạo hình dáng, diễn tả sự vật và cảm xúc','chỉ để lấp chỗ trống','không có vai trò','làm bẩn tranh'],
  [3,'Nêu các bước cơ bản để trang trí một sản phẩm (ví dụ: thiệp, bìa sách).','Ví dụ: chọn chủ đề → phác bố cục → vẽ họa tiết chính – phụ → tô màu hài hòa → hoàn thiện.'],
 ]},
 {cd:'Thưởng thức và ứng dụng',q:[
  [1,'Tranh dân gian Đông Hồ là di sản mĩ thuật của vùng nào?','Bắc Ninh (Việt Nam)','Nhật Bản','Pháp','Trung Quốc'],
  [2,'Thiết kế đồ họa (logo, bao bì) thuộc loại hình mĩ thuật nào?','mĩ thuật ứng dụng','điêu khắc tượng đài','hội họa giá vẽ','kiến trúc cổ'],
  [3,'Nêu một cách tái sử dụng vật liệu bỏ đi để làm sản phẩm mĩ thuật.','Ví dụ: dùng chai nhựa, bìa carton, vải vụn… để làm đồ trang trí, đồ dùng học tập, mô hình…'],
 ]}
];
NH['Mĩ thuật'][6].push(..._CLONE(_MT_MORE));NH['Mĩ thuật'][7].push(..._CLONE(_MT_MORE));
NH['Mĩ thuật'][8].push(..._CLONE(_MT_MORE));NH['Mĩ thuật'][9].push(..._CLONE(_MT_MORE));

/* --- GIÁO DỤC THỂ CHẤT: thêm cho mỗi khối --- */
const _TC_MORE=[
 {cd:'Sức khỏe và vận động',q:[
  [1,'Khởi động trước khi tập luyện nhằm mục đích gì?','làm nóng cơ thể, phòng tránh chấn thương','làm cơ thể mệt trước','để mất thời gian','không cần thiết'],
  [1,'Sau khi vận động mạnh, nên làm gì để cơ thể hồi phục?','thả lỏng, hít thở sâu, nghỉ hợp lí','ngồi/nằm ngay lập tức','uống thật nhiều nước đá','ăn thật no ngay'],
  [2,'Để phát triển sức bền, nên tập luyện như thế nào?','tập đều đặn, tăng dần mức độ','tập thật nặng một buổi rồi nghỉ dài','chỉ tập khi thích','nhịn ăn để tập'],
  [2,'Tư thế ngồi học đúng giúp phòng tránh bệnh nào?','cong vẹo cột sống','cảm cúm','đau răng','đau mắt đỏ'],
  [3,'Nêu một chế độ sinh hoạt giúp nâng cao sức khỏe.','Ví dụ: ăn uống đủ chất, ngủ đủ giấc, tập thể dục đều đặn, giữ vệ sinh, hạn chế thiết bị điện tử…'],
 ]},
 {cd:'Kĩ thuật và luật thi đấu',q:[
  [1,'Trong chạy bền, cách thở hợp lí là gì?','thở đều theo nhịp bước chân','nín thở khi chạy','thở càng gấp càng tốt','chỉ thở bằng miệng thật mạnh'],
  [2,'Trong bóng chuyền, mỗi đội trên sân thường có mấy người?','6 người','5 người','11 người','7 người'],
  [3,'Nêu một nguyên tắc để thi đấu thể thao trung thực, cao thượng.','Ví dụ: tôn trọng luật, tôn trọng đối thủ và trọng tài, không gian lận, thắng không kiêu – thua không nản…'],
 ]}
];
NH['Giáo dục thể chất'][6].push(..._CLONE(_TC_MORE));NH['Giáo dục thể chất'][7].push(..._CLONE(_TC_MORE));
NH['Giáo dục thể chất'][8].push(..._CLONE(_TC_MORE));NH['Giáo dục thể chất'][9].push(..._CLONE(_TC_MORE));

/* --- HOẠT ĐỘNG TRẢI NGHIỆM, HƯỚNG NGHIỆP: thêm cho mỗi khối --- */
const _HD_MORE=[
 {cd:'Phát triển bản thân',q:[
  [1,'Lập kế hoạch học tập giúp em điều gì?','chủ động, sắp xếp thời gian hợp lí','học lộn xộn hơn','quên bài nhiều hơn','mất tự tin'],
  [1,'Khi mắc lỗi, thái độ đúng đắn là gì?','nhận lỗi và sửa chữa','đổ lỗi cho người khác','giấu đi','bỏ qua như không có'],
  [2,'Để rèn tính tự chủ, khi bị bạn rủ làm việc xấu em nên làm gì?','từ chối dứt khoát và giải thích','làm theo cho vừa lòng bạn','im lặng làm theo','rủ thêm người cùng làm'],
  [3,'Nêu một thói quen tốt em muốn rèn luyện và cách duy trì nó.','Ví dụ: đọc sách mỗi ngày → đặt giờ cố định, chọn sách yêu thích, ghi lại điều học được…'],
 ]},
 {cd:'Trách nhiệm cộng đồng và hướng nghiệp',q:[
  [1,'Giữ gìn môi trường ở trường, lớp là trách nhiệm của ai?','của mọi học sinh','chỉ của lao công','chỉ của giáo viên','không của ai'],
  [2,'Để tìm hiểu một nghề, em có thể làm gì?','tìm hiểu công việc, yêu cầu và hỏi người làm nghề đó','chỉ nghe tin đồn','chọn đại không tìm hiểu','bỏ qua'],
  [2,'Tham gia hoạt động thiện nguyện thể hiện phẩm chất nào?','nhân ái, trách nhiệm','ích kỉ','vô cảm','lười biếng'],
  [3,'Nêu một nghề ở địa phương em và cho biết nghề đó cần những phẩm chất gì.','Ví dụ: hướng dẫn viên du lịch cần nhanh nhẹn, giao tiếp tốt, hiểu biết; nông dân cần cần cù, chịu khó…'],
 ]}
];
NH['Hoạt động trải nghiệm'][6].push(..._CLONE(_HD_MORE));NH['Hoạt động trải nghiệm'][7].push(..._CLONE(_HD_MORE));
NH['Hoạt động trải nghiệm'][8].push(..._CLONE(_HD_MORE));NH['Hoạt động trải nghiệm'][9].push(..._CLONE(_HD_MORE));

/* ============================================================
   MỞ RỘNG THCS – Nhóm 3: bổ sung thêm GDCD & Công nghệ (cho đồng đều)
   ============================================================ */

/* ---------- GIÁO DỤC CÔNG DÂN (thêm) ---------- */
NH['Giáo dục công dân'][6].push(
 {cd:'Công dân và cuộc sống',q:[
  [1,'Yêu thương con người được thể hiện qua hành động nào?','quan tâm, giúp đỡ, sẻ chia với người khác','thờ ơ, vô cảm','ganh ghét','làm hại người khác'],
  [2,'Khi chứng kiến bạn bị bắt nạt, hành động đúng là gì?','can ngăn phù hợp và báo người lớn','cổ vũ','quay video để trêu','làm ngơ'],
  [3,'Nêu một biểu hiện của lòng biết ơn trong cuộc sống.','Ví dụ: kính trọng ông bà cha mẹ, biết ơn thầy cô, tri ân người có công, nói lời cảm ơn…'],
 ]}
);
NH['Giáo dục công dân'][7].push(
 {cd:'Ứng xử văn minh',q:[
  [1,'Tôn trọng người khác trước hết là tôn trọng điều gì của họ?','danh dự, nhân phẩm và sự khác biệt','tài sản để chiếm đoạt','chỉ địa vị','chỉ tiền bạc'],
  [2,'Để học tập hiệu quả, cách quản lí thời gian nào là hợp lí?','lập thời gian biểu, ưu tiên việc quan trọng','để nước đến chân mới nhảy','làm nhiều việc cùng lúc qua loa','trì hoãn'],
  [3,'Nêu một cách ứng xử văn minh khi tham gia mạng xã hội.','Ví dụ: lịch sự, không bình luận xúc phạm, không chia sẻ tin chưa kiểm chứng, tôn trọng quyền riêng tư…'],
 ]}
);
NH['Giáo dục công dân'][8].push(
 {cd:'Quyền và bổn phận',q:[
  [1,'Bảo vệ môi trường và tài nguyên thiên nhiên là trách nhiệm của ai?','của mọi công dân','chỉ của nhà nước','chỉ của người lớn','không của ai'],
  [2,'Khi tham gia giao thông, học sinh cần thực hiện điều gì?','chấp hành luật giao thông, đội mũ bảo hiểm khi đi xe máy/xe đạp điện','đi hàng ba, hàng bốn','vượt đèn đỏ khi vắng','đùa nghịch trên đường'],
  [3,'Nêu một việc em làm thể hiện trách nhiệm với gia đình.','Ví dụ: giúp đỡ việc nhà, chăm em, quan tâm ông bà cha mẹ, học tập tốt để bố mẹ yên tâm…'],
 ]}
);
NH['Giáo dục công dân'][9].push(
 {cd:'Trách nhiệm của công dân trẻ',q:[
  [1,'Sống có trách nhiệm là như thế nào?','làm tròn bổn phận và dám chịu trách nhiệm về việc mình làm','đùn đẩy cho người khác','chỉ hưởng quyền lợi','né tránh'],
  [2,'Khi có ý kiến khác với tập thể, cách ứng xử phù hợp là gì?','trình bày quan điểm một cách tôn trọng, lắng nghe và cùng thống nhất','áp đặt ý mình','im lặng bất mãn','gây mâu thuẫn'],
  [3,'Nêu một việc học sinh có thể làm để góp phần xây dựng quê hương, đất nước.','Ví dụ: học tập tốt, giữ gìn môi trường, tham gia hoạt động cộng đồng, giữ gìn bản sắc văn hóa…'],
 ]}
);

/* ---------- CÔNG NGHỆ (thêm) ---------- */
NH['Công nghệ'][6].push(
 {cd:'Đồ dùng điện và sử dụng an toàn',q:[
  [1,'Đồ dùng điện nào dưới đây dùng để chiếu sáng?','đèn điện','nồi cơm điện','quạt điện','tủ lạnh'],
  [2,'Khi rút phích cắm điện, ta nên cầm vào đâu?','cầm thân phích cắm','cầm và kéo dây điện','dùng tay ướt','dùng răng'],
  [3,'Nêu một việc nên làm để sử dụng đồ dùng điện trong nhà được bền lâu.','Ví dụ: dùng đúng hướng dẫn, lau chùi bảo dưỡng định kì, không để quá tải, rút điện khi không dùng…'],
 ]}
);
NH['Công nghệ'][7].push(
 {cd:'Trồng và chăm sóc cây trồng',q:[
  [1,'Bón phân cho cây trồng nhằm mục đích chính nào?','cung cấp chất dinh dưỡng cho cây','làm cỏ','tưới nước','diệt chuột'],
  [2,'Luân canh (trồng đổi loại cây theo mùa vụ) có lợi ích gì?','hạn chế sâu bệnh, giữ độ phì cho đất','làm đất bạc màu nhanh','tăng sâu bệnh','không có lợi'],
  [3,'Nêu một việc cần làm để trồng rau an toàn.','Ví dụ: chọn giống tốt, dùng phân hữu cơ, hạn chế thuốc hóa học, tưới nước sạch, thu hoạch đúng thời điểm…'],
 ]}
);
NH['Công nghệ'][8].push(
 {cd:'Kĩ thuật điện trong gia đình',q:[
  [1,'Thiết bị nào dùng để đóng, cắt mạch điện và bảo vệ khi quá tải?','cầu dao/aptomat','bóng đèn','dây dẫn','ổ cắm'],
  [2,'Để tiết kiệm điện năng, nên chọn đồ dùng điện có đặc điểm gì?','có nhãn tiết kiệm năng lượng, hiệu suất cao','công suất càng lớn càng tốt','cũ, hỏng vẫn dùng','không quan tâm'],
  [3,'Nêu một dấu hiệu cho thấy đồ dùng điện có thể mất an toàn, cần kiểm tra.','Ví dụ: dây bị nứt/hở, phích cắm nóng bất thường, có mùi khét, rò điện gây tê tay…'],
 ]}
);
NH['Công nghệ'][9].push(
 {cd:'Chế biến thực phẩm và an toàn',q:[
  [1,'Để giữ được nhiều vitamin khi chế biến rau, nên làm gì?','rửa rồi mới cắt, nấu nhanh vừa chín','ngâm rất lâu sau khi cắt','nấu thật kĩ, thật lâu','cắt nhỏ ngâm nước qua đêm'],
  [2,'Nguyên tắc nào giúp phòng ngộ độc thực phẩm?','ăn chín, uống sôi, giữ vệ sinh','ăn đồ ôi thiu cho đỡ phí','để lẫn đồ sống và chín','không rửa tay'],
  [3,'Nêu một bước trong quy trình chế biến một món ăn đơn giản mà em biết.','Ví dụ (món rau luộc): sơ chế rau → đun sôi nước, cho chút muối → luộc vừa chín → vớt ra, trình bày.'],
 ]}
);
