/* NGÂN HÀNG ÂM NHẠC – LỚP 2–9 — bù câu đặc thù theo lớp. Câu hỏi nguyên bản, bám SGK Kết nối tri thức (nhạc lí, kí hiệu, nhạc cụ, thường thức; không trích lời bài hát). */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Âm nhạc';
 /* Bảo đảm chủ đề tồn tại đúng tên trước khi add (tránh khớp mờ theo chuỗi con với chủ đề "(Bổ sung) …") */
 function pre(lop,cd){
  if(!NH[M])NH[M]={};
  if(!Array.isArray(NH[M][lop]))NH[M][lop]=[];
  if(!NH[M][lop].some(function(x){return x.cd===cd;}))NH[M][lop].push({cd:cd,q:[]});
 }
 [7,8,9].forEach(function(l){
  pre(l,'Lí thuyết âm nhạc');pre(l,'Thường thức âm nhạc');pre(l,'Nhạc lí và kí hiệu');pre(l,'Thường thức và biểu diễn');pre(l,'(Bổ sung) Nhạc lí và thường thức');
 });

 /* ===== LỚP 2 ===== */
 add(M,2,'Nghe và cảm nhận âm thanh',[
  [1,'Kí hiệu bàn tay dùng khi đọc nhạc ở lớp 2 giúp em nhận biết điều gì?','Cao độ (tên) của nốt nhạc','Tên bài hát','Tốc độ của bài hát','Tên tác giả bài hát'],
  [2,'Khi đọc nhạc theo kí hiệu bàn tay, bàn tay của giáo viên nâng dần lên cao thì các nốt nhạc em đọc thay đổi như thế nào?','Cao dần lên','Thấp dần xuống','To dần lên','Nhanh dần lên'],
  [3,'Em hãy nêu cách phân biệt âm thanh dài và âm thanh ngắn, cho một ví dụ mỗi loại từ nhạc cụ gõ ở lớp.','Âm thanh dài là âm còn ngân vang lâu sau khi gõ (ví dụ tiếng trai-en-gô); âm thanh ngắn là âm dứt ngay sau khi gõ (ví dụ tiếng thanh phách, song loan). Để phân biệt, em lắng nghe xem tiếng còn vang tiếp hay tắt ngay sau khi gõ.']
 ]);
 add(M,2,'Hát và nghe nhạc',[
  [1,'Vận động cơ thể theo nhịp điệu bài hát ở lớp 2 thường dùng những động tác nào?','Vỗ tay, búng tay, giậm chân, vỗ đùi','Chạy vòng quanh lớp','Nhảy dây','Vẽ tranh theo bài hát'],
  [2,'Khi hát một bài có hai câu hát giống nhau về giai điệu, em nhận ra điều đó nhờ dấu hiệu nào?','Hai câu có đường đi lên xuống của âm thanh giống nhau','Hai câu có số chữ bằng nhau','Hai câu đều được hát to','Hai câu đều do một bạn hát'],
  [3,'Hãy mô tả cách hát kết hợp vận động cơ thể (vỗ tay – vỗ đùi) theo nhịp cho một bài hát lớp 2 em đã học.','Xác định nhịp của bài; chọn hai động tác luân phiên: phách mạnh vỗ tay, phách nhẹ vỗ đùi (hoặc búng tay); tập vận động không hát trước, sau đó hát kết hợp vận động đều, giữ đúng tốc độ và không để động tác làm lạc giọng hát.']
 ]);
 add(M,2,'Nhạc cụ gõ',[
  [1,'Tiếng của song loan khi gõ có đặc điểm gì?','Gọn, chắc, dứt ngay sau khi gõ','Ngân vang rất lâu','Rè và kéo dài','Trầm như tiếng trống lớn'],
  [2,'Khi dùng tem-bơ-rin gõ đệm theo nhịp một bài hát, em nên gõ vào lúc nào?','Vào phách mạnh ở đầu mỗi ô nhịp','Vào tất cả các chữ của lời ca','Chỉ gõ ở cuối bài','Gõ bất kì lúc nào em thích'],
  [3,'Em hãy nêu cách cầm và gõ trai-en-gô để tiếng kêu đẹp.','Cầm vào dây treo (quai) của trai-en-gô bằng một tay để thanh kim loại treo tự do, không chạm vào tay; tay kia cầm que gõ nhẹ vào cạnh ngoài hoặc cạnh dưới; sau khi gõ không chạm tay vào thanh kim loại để tiếng ngân vang.']
 ]);
 add(M,2,'Thói quen nghe và biểu diễn',[
  [1,'Khi nghe một bản nhạc có tiếng của nhiều nhạc cụ, em nên làm gì để nhận ra từng loại nhạc cụ?','Lắng nghe và chú ý âm sắc riêng của mỗi nhạc cụ','Nói chuyện để hỏi bạn ngồi cạnh','Chỉ nghe tiếng to nhất','Nhắm mắt và ngủ'],
  [2,'Khi biểu diễn bài hát kết hợp nhạc cụ gõ, bạn gõ đệm cần chú ý điều gì nhất?','Gõ đều, vừa đủ nghe để không át tiếng hát','Gõ càng to càng tốt','Gõ nhanh hơn người hát','Ngừng gõ mỗi khi bạn hát'],
  [3,'Em hãy nêu ba việc nên làm khi chuẩn bị biểu diễn một bài hát lớp 2 cùng nhóm trước lớp.','Thuộc lời và tập hát đúng giai điệu; thống nhất động tác vận động hoặc cách gõ đệm và tập đều cùng nhau; chuẩn bị nhạc cụ gõ, vị trí đứng và cách chào khi lên, xuống sân khấu.']
 ]);

 /* ===== LỚP 3 ===== */
 add(M,3,'Thói quen nghe và biểu diễn',[
  [1,'Khi biểu diễn tốp ca ở lớp 3, các bạn thường xếp đội hình như thế nào?','Thành hàng ngang hoặc hình vòng cung, không che khuất nhau','Thành hàng dọc, bạn này đứng sau bạn kia','Mỗi bạn đứng một góc lớp','Quay lưng về phía khán giả'],
  [2,'Khi nghe bạn thổi ri-coóc-đơ trước lớp, nếu bạn thổi sai một nốt, em nên làm gì?','Giữ im lặng nghe đến hết rồi góp ý nhẹ nhàng','Cười to để bạn biết là sai','Hô tên nốt đúng ngay lúc đó','Bỏ ra ngoài lớp'],
  [3,'Em hãy phân công cho một tiết mục song ca có một bạn gõ đệm và một bạn giới thiệu, nêu rõ việc mỗi bạn cần chuẩn bị.','Hai bạn hát: thuộc lời, tập hòa giọng, thống nhất chỗ lấy hơi; bạn gõ đệm: chọn nhạc cụ (thanh phách hoặc song loan), tập gõ đúng nhịp với người hát; bạn giới thiệu: chuẩn bị lời giới thiệu tên bài, tác giả, hình thức biểu diễn; cả nhóm tập chung ít nhất hai lần và thống nhất cách chào.']
 ]);

 /* ===== LỚP 4 ===== */
 add(M,4,'Lí thuyết âm nhạc',[
  [1,'Hình nốt móc kép có độ dài bằng mấy phần của nốt đen?','Một phần tư nốt đen','Một nửa nốt đen','Bằng nốt đen','Gấp đôi nốt đen'],
  [2,'Nốt nhạc nằm ở khe thứ nhất (tính từ dưới lên) của khuông nhạc có khóa Son là nốt gì?','Pha','Mi','Son','La'],
  [3,'Em hãy viết một ô nhịp 2/4 gồm một nốt đen và hai nốt móc đơn, rồi giải thích vì sao ô nhịp đó đủ hai phách.','Ô nhịp: nốt đen – móc đơn – móc đơn (hoặc hai móc đơn trước, nốt đen sau). Nốt đen bằng 1 phách; hai nốt móc đơn mỗi nốt bằng nửa phách, cộng lại bằng 1 phách; tổng 1 + 1 = 2 phách, đúng với số chỉ nhịp 2/4.']
 ]);
 add(M,4,'Nhạc cụ',[
  [1,'Trên ri-coóc-đơ, để thổi nốt Si em bấm những ngón nào?','Ngón cái tay trái bịt lỗ phía sau và ngón trỏ tay trái bịt lỗ thứ nhất phía trước','Bịt kín tất cả các lỗ','Không bịt lỗ nào','Chỉ dùng tay phải bịt ba lỗ phía dưới'],
  [2,'Khi chơi kèn phím, hai tay của em được sử dụng như thế nào?','Tay phải bấm phím, tay trái giữ thân kèn','Hai tay cùng bấm phím như đàn pi-a-nô','Tay trái bấm phím, tay phải bịt lỗ thổi','Không dùng tay, chỉ cần thổi'],
  [3,'Em hãy nêu các bước luyện tập để thổi được một câu nhạc gồm các nốt Si – La – Son trên ri-coóc-đơ.','Tập đặt ngón đúng cho từng nốt Si, La, Son và thổi từng nốt riêng với hơi nhẹ, đều; đọc tên nốt theo nhịp trước khi thổi; tập chuyển ngón chậm giữa các nốt rồi tăng dần tốc độ; cuối cùng thổi cả câu theo nhịp gõ của giáo viên, chú ý lấy hơi đúng chỗ.']
 ]);
 add(M,4,'Hát và thường thức âm nhạc',[
  [1,'Nhạc sĩ Lưu Hữu Phước (1921–1989) quê ở tỉnh, thành nào?','Cần Thơ','Hà Nội','Nghệ An','Thừa Thiên Huế'],
  [2,'Trong bản nhạc bài hát ở lớp 4, kí hiệu nào thường được dùng để đánh dấu chỗ lấy hơi?','Dấu phẩy nhỏ hoặc dấu "v" ghi phía trên khuông nhạc','Dấu chấm dôi sau nốt nhạc','Dấu lặng đen ở cuối bài','Khóa Son ở đầu khuông'],
  [3,'Em hãy nêu cách thể hiện sắc thái khi hát một bài hát có đoạn đầu nhẹ nhàng và đoạn sau sôi nổi.','Đoạn đầu hát nhẹ, âm lượng vừa, giọng mềm, lấy hơi sâu để giữ câu hát dài; chuyển sang đoạn sôi nổi thì hát rõ lời, âm lượng tăng dần, nhấn vào phách mạnh, nét mặt tươi và động tác linh hoạt hơn; chú ý không gào to để giữ đúng cao độ.']
 ]);
 add(M,4,'Thói quen nghe và biểu diễn',[
  [1,'Khi biểu diễn bài hát có ri-coóc-đơ hoặc kèn phím đệm theo, nhóm nhạc cụ nên đứng ở vị trí nào?','Phía bên hoặc phía sau nhóm hát để không che người hát','Đứng trước người hát','Đứng lẫn với khán giả','Quay lưng về phía người hát'],
  [2,'Khi nghe một bản nhạc không lời do dàn nhạc biểu diễn, cách nghe nào giúp em cảm nhận tốt hơn?','Chú ý sự thay đổi nhanh – chậm, to – nhỏ và tiếng của các nhạc cụ','Vừa nghe vừa làm bài tập khác','Chỉ chờ đến đoạn kết','Bịt tai khi nhạc to lên'],
  [3,'Em hãy viết ba tiêu chí để nhận xét một tiết mục hát kết hợp nhạc cụ của nhóm bạn ở lớp 4.','Hát đúng giai điệu, rõ lời, đúng sắc thái; nhạc cụ đệm đúng nhịp, âm lượng vừa phải, hòa với tiếng hát; phong cách biểu diễn tự tin, động tác phối hợp đều, có chào mở đầu và kết thúc.']
 ]);

 /* ===== LỚP 5 ===== */
 add(M,5,'Lí thuyết âm nhạc',[
  [1,'Nốt Đô cao (Đô 2) trên khuông nhạc có khóa Son được ghi ở vị trí nào?','Khe thứ ba (tính từ dưới lên)','Dòng kẻ thứ nhất','Khe thứ nhất','Dòng kẻ phụ phía dưới khuông'],
  [2,'Trong nhịp 3/4, một ô nhịp gồm một nốt trắng và một nốt đen là đúng hay cần sửa?','Đúng, vì 2 phách + 1 phách = 3 phách','Sai, vì thừa một phách','Sai, vì thiếu một phách','Sai, vì nhịp 3/4 chỉ dùng nốt đen'],
  [3,'Em hãy nêu cách đánh nhịp 3/4 bằng tay và chỉ ra phách nào đánh mạnh.','Đánh nhịp 3/4 theo ba động tác: phách 1 tay đưa xuống (mạnh), phách 2 tay đưa ngang ra ngoài (nhẹ), phách 3 tay đưa lên về vị trí ban đầu (nhẹ); phách 1 là phách mạnh nên động tác dứt khoát, rõ hơn hai phách còn lại.']
 ]);
 add(M,5,'Nhạc cụ',[
  [1,'Cồng chiêng của các dân tộc Tây Nguyên được làm bằng chất liệu gì?','Hợp kim đồng','Gỗ','Tre, nứa','Đá'],
  [2,'Khi chơi ri-coóc-đơ, để thổi các nốt thấp em cần điều chỉnh hơi thổi và ngón bấm như thế nào?','Thổi hơi nhẹ, đều và bịt kín tất cả các lỗ cần bấm','Thổi thật mạnh cho nốt kêu to','Chỉ bịt lỗ phía sau bằng ngón cái','Mở hết các lỗ rồi thổi'],
  [3,'Em hãy so sánh đàn t\'rưng và cồng chiêng về chất liệu, cách chơi và vai trò trong đời sống người Tây Nguyên.','Đàn t\'rưng làm bằng các ống tre, nứa dài ngắn khác nhau, chơi bằng cách gõ dùi vào ống; cồng chiêng làm bằng hợp kim đồng, chơi bằng cách gõ dùi hoặc đấm bằng tay. Cả hai đều là nhạc cụ gõ của Tây Nguyên, dùng trong lễ hội, sinh hoạt cộng đồng; cồng chiêng còn gắn với nghi lễ và đã được UNESCO ghi danh.']
 ]);
 add(M,5,'Hát và thường thức âm nhạc',[
  [1,'Bài hát "Em yêu trường em" của nhạc sĩ Hoàng Vân có tính chất âm nhạc như thế nào?','Vui tươi, trong sáng, tình cảm','Hùng tráng như hành khúc','Buồn, chậm rãi','Êm ái như hát ru'],
  [2,'Nhạc sĩ Phong Nhã được biết đến chủ yếu với các bài hát dành cho đối tượng nào?','Thiếu nhi, thiếu niên','Người cao tuổi','Bộ đội hải quân','Công nhân vùng mỏ'],
  [3,'Em hãy phân biệt hai cách hát hòa giọng và hát đối đáp, cho ví dụ cách sử dụng trong một bài hát ở lớp 5.','Hòa giọng là cả nhóm hoặc cả lớp cùng hát một giai điệu, một lời; hát đối đáp là hai nhóm (hoặc hai người) thay phiên hát từng câu như hỏi – đáp. Ví dụ: các câu đầu nhóm A và nhóm B hát đối đáp, câu kết cả lớp cùng hòa giọng.']
 ]);
 add(M,5,'Thói quen nghe và biểu diễn',[
  [1,'Trong tiết mục có lĩnh xướng, khi bạn lĩnh xướng đang hát thì các bạn còn lại làm gì?','Giữ im lặng, lắng nghe và chuẩn bị vào đúng câu hòa giọng','Hát theo thật to','Nói chuyện với nhau','Rời khỏi vị trí đứng'],
  [2,'Lớp 5 tổ chức liên hoan văn nghệ chào mừng ngày 20/11, tiết mục nào sau đây phù hợp nhất về nội dung?','Bài hát về thầy cô, mái trường','Bài hát ru em bé','Bài hát về Tết Trung thu','Bài hát về mùa gặt'],
  [3,'Em hãy lập kế hoạch tập luyện trong một tuần cho tiết mục hát có lĩnh xướng và hòa giọng của tổ em.','Ngày 1–2: chọn bài, phân công người lĩnh xướng, nhóm hòa giọng, người gõ đệm; nghe mẫu và học thuộc lời. Ngày 3–4: tập từng phần (lĩnh xướng riêng, hòa giọng riêng), chỉnh cao độ và chỗ lấy hơi. Ngày 5–6: ghép toàn bài với gõ đệm, tập động tác và đội hình. Ngày 7: tổng duyệt, tự nhận xét và sửa lỗi.']
 ]);

 /* ===== LỚP 7 ===== */
 add(M,7,'Lí thuyết âm nhạc',[
  [1,'Nốt móc đơn có dấu chấm dôi có độ dài bằng mấy nốt móc kép?','3 nốt móc kép','2 nốt móc kép','4 nốt móc kép','1 nốt móc kép'],
  [2,'Trong nhịp 4/4, một nốt trắng nối với một nốt đen cùng cao độ bằng dấu nối sẽ ngân bao nhiêu phách?','3 phách','2 phách','4 phách','1,5 phách'],
  [3,'Em hãy giải thích cách đọc đoạn nhạc có nốt đen chấm dôi đi liền với một nốt móc đơn trong nhịp 2/4 và cách gõ phách tương ứng.','Nốt đen chấm dôi dài 1,5 phách, nốt móc đơn dài 0,5 phách, cộng lại đủ 2 phách của ô nhịp. Khi đọc, nốt đầu ngân hết phách 1 và nửa đầu phách 2, nốt móc đơn rơi vào nửa sau phách 2; gõ phách đều hai cái, nốt thứ hai đọc vào khoảng giữa cái gõ thứ hai và cái gõ đầu ô nhịp sau.']
 ]);
 add(M,7,'Thường thức âm nhạc',[
  [1,'Bản giao hưởng "Quê hương" của nhạc sĩ Hoàng Việt được hoàn thành vào khoảng thời gian nào?','Giữa những năm 1960 (hoàn thành năm 1965)','Năm 1945','Những năm 1990','Năm 2010'],
  [2,'Bản giao hưởng số 9 của Bét-tô-ven có điểm đặc biệt gì so với các bản giao hưởng trước đó?','Có phần hợp xướng (giọng hát) ở chương cuối','Chỉ dùng một nhạc cụ độc tấu','Không có bộ dây','Chỉ dài khoảng 5 phút'],
  [3,'Em hãy nêu ba thể loại tác phẩm tiêu biểu của Bét-tô-ven và một ví dụ cho mỗi thể loại.','Giao hưởng (ví dụ Giao hưởng số 5, số 9); xô-nát cho pi-a-nô (ví dụ xô-nát "Ánh trăng"); công-xéc-tô (ví dụ Công-xéc-tô pi-a-nô số 5 "Hoàng đế"). Ngoài ra ông còn viết nhiều tác phẩm thính phòng và ca khúc.']
 ]);
 add(M,7,'Nhạc lí và kí hiệu',[
  [1,'Hai dấu chấm đặt bên trong vạch nhịp kép (một vạch đậm, một vạch mảnh) là kí hiệu gì?','Dấu nhắc lại','Dấu chấm dôi','Dấu lặng','Dấu hóa'],
  [2,'Khi đọc một bản nhạc có cả dấu nhắc lại và dấu quay lại (dấu hồi), việc nên làm trước khi hát là gì?','Đọc lướt toàn bài để xác định trình tự các đoạn sẽ hát','Hát ngay từ đầu, không cần xem trước','Chỉ hát đoạn đầu rồi dừng','Bỏ qua các kí hiệu đó'],
  [3,'Em hãy viết trình tự biểu diễn của một bài hát có cấu trúc: đoạn A, đoạn B có dấu nhắc lại kèm khung thay đổi 1 và 2, rồi giải thích.','Trình tự: A – B (kết bằng khung 1) – quay lại đầu đoạn B – B (kết bằng khung 2). Vì dấu nhắc lại bao quanh đoạn B nên B được hát hai lần; lần một kết theo khung 1, lần hai bỏ khung 1 và hát khung 2 để kết bài.']
 ]);
 add(M,7,'Thường thức và biểu diễn',[
  [1,'Nhạc cụ nào sau đây thuộc bộ gõ của dàn nhạc giao hưởng?','Trống định âm (tim-pa-ni)','Vi-ô-lông-xen','Kèn ô-boa','Kèn cor'],
  [2,'Nhạc cụ nào có âm vực thấp nhất trong bộ dây của dàn nhạc giao hưởng?','Công-tơ-bát (contrabass)','Vi-ô-lông','Vi-ô-la','Vi-ô-lông-xen'],
  [3,'Em hãy mô tả cách sắp xếp các bộ nhạc cụ trên sân khấu của dàn nhạc giao hưởng và giải thích lí do.','Bộ dây xếp phía trước, gần nhạc trưởng (vi-ô-lông bên trái, vi-ô-lông-xen và công-tơ-bát bên phải); bộ gỗ ở giữa, phía sau bộ dây; bộ đồng sau bộ gỗ; bộ gõ ở hàng sau cùng. Lí do: nhạc cụ có âm lượng nhỏ xếp trước, nhạc cụ âm lượng lớn xếp sau để âm thanh cân bằng khi đến người nghe.']
 ]);
 add(M,7,'(Bổ sung) Nhạc lí và thường thức',[
  [1,'Nốt trắng có dấu chấm dôi trong nhịp 3/4 chiếm mấy phách?','3 phách (trọn một ô nhịp)','2 phách','1 phách','4 phách'],
  [2,'Bét-tô-ven được xem là nhạc sĩ chuyển tiếp giữa hai thời kì âm nhạc nào?','Cổ điển và Lãng mạn','Phục hưng và Ba-rốc','Lãng mạn và Hiện đại','Ba-rốc và Cổ điển'],
  [3,'Em hãy nêu các bước xác định tổng số phách của một ô nhịp khi trong ô nhịp có cả dấu chấm dôi và dấu nối.','Bước 1: xem số chỉ nhịp để biết giá trị một phách; bước 2: tính độ dài từng nốt, nốt có chấm dôi được cộng thêm nửa giá trị của nó; bước 3: với dấu nối, cộng độ dài các nốt được nối thành một âm ngân liền; bước 4: cộng tất cả và so với số phách quy định của ô nhịp.']
 ]);

 /* ===== LỚP 8 ===== */
 add(M,8,'Lí thuyết âm nhạc',[
  [1,'Trong gam La thứ tự nhiên, các cặp bậc nào cách nhau nửa cung?','Bậc II–III và bậc V–VI','Bậc III–IV và bậc VII–I','Bậc I–II và bậc IV–V','Bậc VI–VII và bậc II–III'],
  [2,'So với giọng thứ, giọng trưởng thường mang tính chất âm nhạc như thế nào?','Sáng, khỏe, vui hơn','Tối, buồn hơn','Luôn chậm hơn','Luôn ở nhịp 3/4'],
  [3,'Em hãy chọn một bài hát đã học ở lớp 8, nêu giọng của bài và nhận xét tính chất của bài có phù hợp với giọng trưởng hay thứ đó không.','Nêu tên bài; xác định giọng qua hóa biểu và nốt kết (ví dụ không có dấu hóa, kết ở Đô là Đô trưởng; kết ở La là La thứ); nhận xét tính chất (vui, khỏe với giọng trưởng; mềm mại, tâm tình với giọng thứ) và chỉ ra chi tiết trong giai điệu, lời ca thể hiện tính chất đó.']
 ]);
 add(M,8,'Thường thức âm nhạc',[
  [1,'Nhạc sĩ Sô-panh (1810–1849) được mệnh danh là gì?','Nhà thơ của cây đàn pi-a-nô','Vua nhạc van','Cha đẻ của giao hưởng','Thần đồng âm nhạc nước Áo'],
  [2,'Thể loại nào sau đây bắt nguồn từ điệu nhảy dân gian Ba Lan và được Sô-panh phát triển thành tác phẩm pi-a-nô nổi tiếng?','Ma-duốc-ca (mazurka) và pô-lô-ne (polonaise)','Tan-gô (tango)','Phla-men-cô (flamenco)','Sam-ba (samba)'],
  [3,'Em hãy nêu ngắn gọn những nét chính về nhạc sĩ Trịnh Công Sơn và đặc điểm ca khúc của ông.','Trịnh Công Sơn (1939–2001) là nhạc sĩ nổi tiếng với hàng trăm ca khúc về tình yêu, quê hương, thân phận con người và một số bài cho thiếu nhi (ví dụ "Em là bông hồng nhỏ", "Tuổi đời mênh mông"); ca khúc của ông có giai điệu giản dị, dễ hát, lời ca giàu chất thơ và triết lí.']
 ]);
 add(M,8,'Nhạc lí và kí hiệu',[
  [1,'Hợp âm Pha trưởng gồm các nốt nào?','Pha – La – Đô','Pha – Son – La','Pha – La – Rê','Pha – Si – Rê'],
  [2,'Trong nhịp 6/8, một ô nhịp gồm hai nốt đen chấm dôi là đúng hay sai?','Đúng, mỗi nốt đen chấm dôi bằng ba móc đơn, hai nốt đủ sáu phách','Sai, vì thừa phách','Sai, vì thiếu phách','Sai, vì nhịp 6/8 không dùng dấu chấm dôi'],
  [3,'Em hãy nêu cách gõ đệm cho một bài hát ở nhịp 6/8 sao cho thể hiện đúng tính chất nhịp nhàng, đung đưa của nhịp này.','Nhịp 6/8 gồm hai nhóm, mỗi nhóm ba phách móc đơn: gõ mạnh ở phách 1, gõ nhẹ hơn ở phách 4 (trọng âm phụ), các phách còn lại gõ nhẹ hoặc không gõ; mỗi nhóm ba phách tạo cảm giác đung đưa; có thể kết hợp đưa người hoặc lắc nhẹ theo từng nhóm ba phách để thể hiện tính chất nhịp nhàng của nhịp 6/8.']
 ]);
 add(M,8,'Thường thức và biểu diễn',[
  [1,'Không gian văn hóa Cồng chiêng Tây Nguyên được UNESCO ghi danh vào năm nào?','2005','1993','2010','2017'],
  [2,'Dàn cồng chiêng Tây Nguyên thường được biểu diễn trong dịp nào?','Các lễ hội cộng đồng như mừng lúa mới, lễ bỏ mả','Chỉ trong giờ học ở trường','Các cuộc thi đấu thể thao','Chủ yếu trên sân khấu ca nhạc hiện đại'],
  [3,'Em hãy nêu các bước tổ chức một buổi giới thiệu di sản âm nhạc Tây Nguyên (cồng chiêng, đàn đá, đàn t\'rưng) cho các bạn trong lớp.','Phân công các nhóm tìm hiểu từng nhạc cụ (chất liệu, cách chơi, vùng, ý nghĩa); chuẩn bị hình ảnh và đoạn nhạc minh họa; sắp xếp thứ tự trình bày, mỗi nhóm thuyết trình ngắn kèm phần nghe nhạc; kết thúc bằng phần hỏi – đáp và cả lớp nêu cảm nhận.']
 ]);
 add(M,8,'(Bổ sung) Nhạc lí và thường thức',[
  [1,'Gam Đô trưởng và gam La thứ có chung đặc điểm gì?','Dùng chung bảy nốt, không có dấu hóa ở đầu khuông','Cùng có âm chủ là Đô','Đều có một dấu thăng ở hóa biểu','Đều bắt đầu từ nốt La'],
  [2,'Hợp âm ba xây trên bậc V của giọng Đô trưởng là hợp âm nào?','Son trưởng (Son – Si – Rê)','Pha trưởng (Pha – La – Đô)','La thứ (La – Đô – Mi)','Rê thứ (Rê – Pha – La)'],
  [3,'Em hãy viết hợp âm ba xây trên bậc I, IV, V của giọng La thứ và nhận xét tính chất trưởng hay thứ của mỗi hợp âm.','Bậc I: La – Đô – Mi (La thứ); bậc IV: Rê – Pha – La (Rê thứ); bậc V: Mi – Son – Si (Mi thứ, theo gam thứ tự nhiên). Cả ba đều là hợp âm thứ nên phần đệm ở giọng La thứ có màu sắc trầm, mềm hơn so với Đô trưởng.']
 ]);

 /* ===== LỚP 9 ===== */
 add(M,9,'Lí thuyết âm nhạc',[
  [1,'Quãng 3 từ Đô đến Mi có 2 cung được gọi là quãng gì?','Quãng 3 trưởng','Quãng 3 thứ','Quãng 3 đúng','Quãng 3 tăng'],
  [2,'Quãng từ nốt Son lên nốt Rê liền trên (đi lên) là quãng mấy?','Quãng 5','Quãng 4','Quãng 6','Quãng 3'],
  [3,'Em hãy xác định tên quãng, số cung của các quãng Rê – Pha, Mi – Son, Pha – La rồi phân loại trưởng hay thứ.','Rê – Pha: quãng 3 có 1,5 cung → quãng 3 thứ; Mi – Son: quãng 3 có 1,5 cung → quãng 3 thứ; Pha – La: quãng 3 có 2 cung → quãng 3 trưởng. Cùng là quãng 3 nhưng khác số cung nên tính chất khác nhau.']
 ]);
 add(M,9,'Thường thức âm nhạc',[
  [1,'Ba vở vũ kịch (ba-lê) nổi tiếng nào sau đây đều là tác phẩm của Trai-cốp-xki?','Hồ thiên nga, Kẹp hạt dẻ, Người đẹp ngủ trong rừng','Cây sáo thần, Đám cưới Phi-ga-rô, Đông Gioăng','Các-men, Tu-ran-đốt, Ai-đa','Tiến quân ca, Quê hương, Nhạc rừng'],
  [2,'Vở "Hồ thiên nga" của Trai-cốp-xki thuộc thể loại nghệ thuật nào?','Ba-lê (vũ kịch) – kể chuyện bằng múa kết hợp âm nhạc','Ô-pê-ra – kể chuyện bằng hát','Giao hưởng không lời','Hợp xướng tôn giáo'],
  [3,'Em hãy nêu các bước tìm hiểu một ca khúc mang âm hưởng dân ca và chỉ ra dấu hiệu nhận biết chất liệu dân ca trong bài.','Bước 1: tìm tên bài, tác giả, vùng dân ca được khai thác; bước 2: nghe và chú ý thang âm (thường là năm âm), cách luyến láy, tiếng đệm, tiết tấu; bước 3: so sánh với một bài dân ca gốc của vùng đó. Dấu hiệu: giai điệu nhiều nốt luyến, dùng thang năm âm, lời ca có từ địa phương hoặc hư từ như "ơi", "hò", "ơ".']
 ]);
 add(M,9,'Nhạc lí và kí hiệu',[
  [1,'Giọng Mi thứ có hóa biểu gồm dấu hóa nào?','Một dấu thăng (Pha thăng)','Một dấu giáng (Si giáng)','Hai dấu thăng','Không có dấu hóa'],
  [2,'Giọng Rê thứ có âm chủ là nốt nào và hóa biểu gồm dấu hóa nào?','Âm chủ Rê, hóa biểu một dấu giáng (Si giáng)','Âm chủ Rê, không có dấu hóa','Âm chủ Rê, hóa biểu một dấu thăng','Âm chủ Pha, hóa biểu một dấu giáng'],
  [3,'Một bài hát viết ở giọng Pha trưởng có nốt cao nhất là Đô 2 khiến nhiều bạn hát với tới khó. Em hãy đề xuất cách dịch giọng xuống, ghi giọng mới và nốt cao nhất mới.','Ví dụ: dịch xuống quãng 4 sang giọng Đô trưởng (không có dấu hóa), nốt cao nhất Đô 2 trở thành Son 1; hoặc dịch xuống quãng 2 sang giọng Mi giáng trưởng (ba dấu giáng), nốt cao nhất thành Si giáng. Giai điệu và tiết tấu giữ nguyên, chỉ toàn bộ cao độ hạ xuống cùng một khoảng để phù hợp tầm cữ giọng hát. HS chọn được một giọng mới hợp lí, ghi đúng hóa biểu và nốt cao nhất mới là đạt.']
 ]);
 add(M,9,'Thường thức và biểu diễn',[
  [1,'Dàn nhạc Nhã nhạc cung đình Huế thường gồm những nhạc cụ nào?','Trống, kèn bầu, đàn nhị, đàn nguyệt, đàn tì bà, sáo, sênh tiền','Pi-a-nô, vi-ô-lông, ghi-ta điện','Cồng chiêng, đàn t\'rưng, đàn đá','Trống cái, kèn trôm-pét, tim-pa-ni'],
  [2,'Hát xoan là di sản âm nhạc truyền thống của tỉnh nào?','Phú Thọ','Thừa Thiên Huế','Bắc Ninh','Nghệ An'],
  [3,'Em hãy nêu ba vai trò trong nhóm dàn dựng tiết mục hợp xướng của lớp 9 (chỉ huy, bè trưởng, người đệm nhạc) và nhiệm vụ của từng vai trò.','Chỉ huy: bắt nhịp, điều khiển tốc độ, sắc thái, ra hiệu vào – kết cho các bè; bè trưởng: tập riêng cho bè mình, giữ cao độ và nhịp của bè, nhắc chỗ lấy hơi; người đệm nhạc: đệm đúng giọng, đúng tốc độ, chơi phần dạo đầu và giữ nhịp ổn định cho cả nhóm.']
 ]);
 add(M,9,'(Bổ sung) Nhạc lí và thường thức',[
  [1,'Quãng từ nốt Mi lên nốt Si (đi lên) là quãng mấy?','Quãng 5','Quãng 4','Quãng 6','Quãng 7'],
  [2,'Bài hát có hóa biểu một dấu giáng và kết ở nốt Rê thường được viết ở giọng nào?','Rê thứ','Pha trưởng','Son trưởng','Mi thứ'],
  [3,'Em hãy so sánh hai giọng Son trưởng và Mi thứ về hóa biểu, âm chủ, tính chất và cho biết quan hệ giữa chúng.','Cả hai cùng hóa biểu một dấu thăng (Pha thăng); Son trưởng có âm chủ Son, tính chất sáng, khỏe; Mi thứ có âm chủ Mi, tính chất mềm, trầm hơn. Hai giọng này là hai giọng song song vì cùng hóa biểu và âm chủ cách nhau một quãng 3 thứ.']
 ]);
})();
