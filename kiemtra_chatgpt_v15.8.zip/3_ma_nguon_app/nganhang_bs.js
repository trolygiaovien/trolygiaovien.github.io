/* ============================================================
   NGÂN HÀNG CÂU HỎI BỔ SUNG (câu mở rộng) – THCS lớp 6–9
   Các nhóm đều gắn _bs:true. Ở mỗi phần (Đề, Phiếu, Phụ đạo, Bồi dưỡng)
   có ô "Dùng ngân hàng bổ sung" để bật/tắt dùng các câu này.
   Định dạng: TN [mức,'câu','ĐÚNG','sai','sai','sai'] ; TL [mức,'câu','đáp án']
   ============================================================ */
(function(){
 const push=(mon,lop,cd,q)=>{if(!NH[mon])NH[mon]={};if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];NH[mon][lop].push({cd:cd,q:q,_bs:true});};

 /* ---------- KHOA HỌC TỰ NHIÊN ---------- */
 push('Khoa học tự nhiên',6,'(Bổ sung) Chất, tế bào và cơ thể sống',[
  [1,'Dụng cụ nào dùng để đo nhiệt độ?','nhiệt kế','cân','thước','ống đong'],
  [1,'Vật nào sau đây là vật sống?','cây đậu','hòn đá','cái bàn','chiếc xe'],
  [2,'Quá trình quang hợp của cây xanh thải ra khí gì?','khí ô-xi','khí các-bô-níc','khí ni-tơ','hơi nước'],
  [2,'Đơn vị cấu tạo nên cơ thể sinh vật là gì?','tế bào','nguyên tử','phân tử','mô'],
  [3,'Nêu một cách để tách muối ra khỏi nước muối.','Đun (cô cạn) cho nước bay hơi, còn lại muối.'],
 ]);
 push('Khoa học tự nhiên',7,'(Bổ sung) Nguyên tử, tốc độ, trao đổi chất',[
  [1,'Đơn vị đo tốc độ thường dùng là gì?','m/s hoặc km/h','kg','lít','giây'],
  [2,'Công thức tính tốc độ là gì?','v = s : t','v = s × t','v = t : s','v = s + t'],
  [2,'Nguyên tố hóa học được đặc trưng bởi yếu tố nào?','số proton trong hạt nhân','màu sắc','khối lượng mẫu vật','trạng thái'],
  [3,'Một xe đi 90 km trong 2 giờ. Tính tốc độ.','Tốc độ = 90 : 2 = 45 km/h.'],
 ]);
 push('Khoa học tự nhiên',8,'(Bổ sung) Phản ứng hóa học, điện, cơ thể người',[
  [1,'Trong phản ứng hóa học, cái gì được bảo toàn?','khối lượng các chất','màu sắc','thể tích','nhiệt độ'],
  [2,'Dòng điện là gì?','dòng chuyển dời có hướng của các hạt mang điện','dòng nước','dòng không khí','ánh sáng'],
  [2,'Cơ quan nào điều khiển mọi hoạt động của cơ thể người?','hệ thần kinh','dạ dày','gan','da'],
  [3,'Nêu một việc nên làm để bảo vệ hệ hô hấp.','Ví dụ: đeo khẩu trang nơi bụi, không hút thuốc, giữ không khí sạch, tập thể dục…'],
 ]);
 push('Khoa học tự nhiên',9,'(Bổ sung) Năng lượng, kim loại, di truyền',[
  [1,'Dạng năng lượng của vật đang chuyển động gọi là gì?','động năng','thế năng','hóa năng','quang năng'],
  [2,'Kim loại nào dẫn điện tốt và thường dùng làm dây dẫn?','đồng','chì','thủy ngân','sắt gỉ'],
  [2,'Vật chất mang thông tin di truyền trong tế bào là gì?','ADN','nước','muối khoáng','vitamin'],
  [3,'Nêu một nguồn năng lượng tái tạo.','Ví dụ: năng lượng mặt trời, gió, nước (thủy điện), sinh khối…'],
 ]);

 /* ---------- LỊCH SỬ VÀ ĐỊA LÍ ---------- */
 push('Lịch sử và Địa lí',6,'(Bổ sung) Thời nguyên thủy và bản đồ',[
  [1,'Con người tính thời gian theo đơn vị lớn nào trong lịch sử?','thập kỉ, thế kỉ, thiên niên kỉ','phút, giây','tuần','buổi'],
  [2,'Tỉ lệ bản đồ cho biết điều gì?','mức độ thu nhỏ của bản đồ so với thực tế','màu của bản đồ','tên bản đồ','hướng bắc'],
  [3,'Kể tên một tư liệu hiện vật của lịch sử.','Ví dụ: trống đồng, rìu đá, đồ gốm, tiền cổ, bia đá…'],
 ]);
 push('Lịch sử và Địa lí',7,'(Bổ sung) Trung đại và môi trường',[
  [1,'Nhà Trần ba lần đánh thắng quân xâm lược nào?','Mông – Nguyên','Minh','Thanh','Pháp'],
  [2,'Đới khí hậu nào nóng ẩm, mưa nhiều quanh năm?','đới nóng (nhiệt đới)','đới lạnh','đới ôn hòa','hàn đới'],
  [3,'Nêu một thành tựu văn hóa của Ấn Độ thời phong kiến.','Ví dụ: chữ Phạn, đạo Phật, đạo Hin-đu, kiến trúc đền tháp…'],
 ]);
 push('Lịch sử và Địa lí',8,'(Bổ sung) Cận đại và tự nhiên Việt Nam',[
  [1,'Khởi nghĩa Tây Sơn lật đổ các tập đoàn phong kiến nào?','Nguyễn, Trịnh, Lê','Lý, Trần','Ngô, Đinh','Tiền Lê'],
  [2,'Khoáng sản nào nước ta có trữ lượng lớn ở Quảng Ninh?','than đá','vàng','kim cương','bạc'],
  [3,'Nêu một hậu quả của việc phá rừng.','Ví dụ: lũ lụt, xói mòn đất, mất môi trường sống của sinh vật, biến đổi khí hậu…'],
 ]);
 push('Lịch sử và Địa lí',9,'(Bổ sung) Hiện đại và kinh tế Việt Nam',[
  [1,'Nước Việt Nam Dân chủ Cộng hòa ra đời sau sự kiện nào?','Cách mạng tháng Tám 1945','Điện Biên Phủ 1954','Đổi mới 1986','Thống nhất 1975'],
  [2,'Vùng nào trồng nhiều lúa nhất cả nước?','Đồng bằng sông Cửu Long','Tây Nguyên','Đông Nam Bộ','Trung du Bắc Bộ'],
  [3,'Nêu một ngành kinh tế biển của nước ta.','Ví dụ: đánh bắt – nuôi trồng thủy sản, du lịch biển, giao thông hàng hải, khai thác dầu khí…'],
 ]);

 /* ---------- NGỮ VĂN ---------- */
 push('Ngữ văn',6,'(Bổ sung) Tiếng Việt và đọc hiểu',[
  [1,'Từ "xanh xanh" thuộc loại từ nào?','từ láy','từ ghép','từ đơn','số từ'],
  [2,'Biện pháp tu từ trong câu "Trường em như ngôi nhà thứ hai" là gì?','so sánh','nhân hóa','ẩn dụ','nói quá'],
  [3,'Đặt một câu có hình ảnh nhân hóa.','Ví dụ: Ông mặt trời thức dậy, mỉm cười với vạn vật.'],
 ]);
 push('Ngữ văn',7,'(Bổ sung) Thơ, nghị luận và viết',[
  [1,'Tục ngữ về thiên nhiên, lao động thường ngắn gọn và có đặc điểm gì?','đúc kết kinh nghiệm, có vần, dễ nhớ','dài dòng','không vần','kể chuyện'],
  [2,'Văn bản nghị luận cần có yếu tố nào để thuyết phục?','lí lẽ và bằng chứng','chỉ cảm xúc','chỉ hình ảnh','chỉ miêu tả'],
  [3,'Giải thích ngắn gọn câu tục ngữ "Ăn quả nhớ kẻ trồng cây".','Nhắc nhở lòng biết ơn với người đã tạo ra thành quả mà ta hưởng.'],
 ]);
 push('Ngữ văn',8,'(Bổ sung) Câu, tu từ và nghị luận',[
  [1,'Câu "Hãy giữ gìn vệ sinh chung!" là kiểu câu gì?','câu cầu khiến','câu nghi vấn','câu cảm thán','câu kể'],
  [2,'Biện pháp nói giảm, nói tránh nhằm mục đích gì?','tránh gây cảm giác nặng nề, thô tục','phóng đại','liệt kê','so sánh'],
  [3,'Nêu các phần của một bài văn nghị luận.','Mở bài (nêu vấn đề) – Thân bài (luận điểm, lí lẽ, bằng chứng) – Kết bài (khẳng định).'],
 ]);
 push('Ngữ văn',9,'(Bổ sung) Đọc hiểu và nghị luận',[
  [1,'"Truyện Kiều" thuộc thể loại nào?','truyện thơ Nôm','tiểu thuyết','kịch','tùy bút'],
  [2,'Lời dẫn trực tiếp được đặt trong dấu gì?','dấu ngoặc kép','dấu ngoặc đơn','dấu gạch ngang','dấu chấm'],
  [3,'Nêu một luận điểm cho đề: "Tác hại của việc lạm dụng điện thoại".','Ví dụ: Lạm dụng điện thoại làm giảm sức khỏe, sao nhãng học tập và hạn chế giao tiếp thực.'],
 ]);

 /* ---------- GIÁO DỤC CÔNG DÂN ---------- */
 push('Giáo dục công dân',6,'(Bổ sung) Đạo đức và pháp luật',[
  [1,'Hành vi nào thể hiện lòng yêu thương con người?','giúp đỡ người gặp khó khăn','chế giễu người khác','thờ ơ','ích kỉ'],
  [2,'Khi gặp người bị nạn trên đường, em nên làm gì?','gọi người lớn/cấp cứu giúp đỡ','bỏ đi','quay phim rồi đăng mạng','trêu chọc'],
  [3,'Nêu một quyền cơ bản của trẻ em.','Ví dụ: quyền được học tập, vui chơi, chăm sóc, bảo vệ, có ý kiến…'],
 ]);
 push('Giáo dục công dân',7,'(Bổ sung) Kĩ năng và giá trị',[
  [1,'Giữ chữ tín là biểu hiện của phẩm chất nào?','trung thực, đáng tin cậy','khôn lanh','ích kỉ','nóng vội'],
  [2,'Cách ứng phó tích cực khi căng thẳng là gì?','chia sẻ, nghỉ ngơi, suy nghĩ tích cực','thức khuya','cáu gắt','bỏ học'],
  [3,'Nêu một việc làm bảo tồn di sản văn hóa.','Ví dụ: giữ gìn di tích sạch đẹp, tìm hiểu – giới thiệu, không viết vẽ bậy, ủng hộ lễ hội truyền thống…'],
 ]);
 push('Giáo dục công dân',8,'(Bổ sung) Lối sống và pháp luật',[
  [1,'Tôn trọng sự đa dạng của các dân tộc thể hiện thái độ nào?','học hỏi, không kì thị','coi thường','chê bai','xa lánh'],
  [2,'Lập kế hoạch chi tiêu hợp lí giúp em điều gì?','tránh lãng phí, chủ động tiền bạc','tiêu hết nhanh','mắc nợ','mua đồ thừa'],
  [3,'Nêu một truyền thống tốt đẹp của dân tộc.','Ví dụ: yêu nước, hiếu học, đoàn kết, tôn sư trọng đạo, uống nước nhớ nguồn…'],
 ]);
 push('Giáo dục công dân',9,'(Bổ sung) Công dân và xã hội',[
  [1,'Sống có lí tưởng là gì?','có mục đích cao đẹp và phấn đấu thực hiện','sống buông thả','chỉ hưởng thụ','không mục tiêu'],
  [2,'Tiêu dùng thông minh là tiêu dùng như thế nào?','có kế hoạch, phù hợp nhu cầu và khả năng','theo cảm hứng','chạy theo mốt','vay để tiêu'],
  [3,'Nêu một việc thể hiện trách nhiệm của công dân với cộng đồng.','Ví dụ: giữ gìn vệ sinh chung, tham gia thiện nguyện, chấp hành pháp luật, bảo vệ môi trường…'],
 ]);

 /* ---------- TIN HỌC ---------- */
 push('Tin học',6,'(Bổ sung) Thông tin và Internet',[
  [1,'Thiết bị nào dùng để nhập văn bản vào máy tính?','bàn phím','màn hình','loa','máy in'],
  [2,'Để tìm thông tin trên Internet em dùng gì?','máy tìm kiếm (trình duyệt)','máy in','máy quét','máy chiếu'],
  [3,'Nêu một việc nên làm để an toàn khi dùng Internet.','Ví dụ: không cho người lạ thông tin cá nhân, đặt mật khẩu mạnh, báo người lớn khi gặp nội dung xấu…'],
 ]);
 push('Tin học',7,'(Bổ sung) Bảng tính và mạng xã hội',[
  [1,'Trong bảng tính, công thức bắt đầu bằng dấu gì?','dấu bằng (=)','dấu cộng','dấu chấm','dấu hỏi'],
  [2,'Hàm tính tổng trong bảng tính là hàm nào?','SUM','MAX','COUNT','IF'],
  [3,'Nêu một quy tắc ứng xử văn minh trên mạng xã hội.','Ví dụ: lịch sự, không nói xấu, không chia sẻ tin giả, tôn trọng người khác…'],
 ]);
 push('Tin học',8,'(Bổ sung) Sơ đồ, thuật toán',[
  [1,'Biểu đồ hình cột thường dùng để làm gì?','so sánh số lượng giữa các nhóm','ghi âm','vẽ tranh','soạn nhạc'],
  [2,'Cấu trúc rẽ nhánh dùng để làm gì?','chọn việc thực hiện theo điều kiện','lặp mãi','in ra màn hình','lưu tệp'],
  [3,'Nêu một ví dụ về thuật toán trong đời sống.','Ví dụ: các bước pha nước chanh; các bước giải một bài toán…'],
 ]);
 push('Tin học',9,'(Bổ sung) Lập trình và đạo đức số',[
  [1,'Cấu trúc lặp dùng để làm gì?','thực hiện lặp lại một công việc','chỉ in một lần','xóa tệp','tắt máy'],
  [2,'Thông tin nào KHÔNG nên chia sẻ công khai?','mật khẩu, số căn cước','môn học yêu thích','ảnh phong cảnh','bài học'],
  [3,'Nêu các bước giải quyết một bài toán bằng máy tính.','Xác định bài toán → thiết kế thuật toán → viết chương trình → kiểm thử, hoàn thiện.'],
 ]);

 /* ---------- CÔNG NGHỆ ---------- */
 push('Công nghệ',6,'(Bổ sung) Nhà ở và thực phẩm',[
  [1,'Để tiết kiệm điện khi ra khỏi phòng, em nên làm gì?','tắt đèn, quạt','bật thêm đèn','mở điều hòa','để nguyên'],
  [2,'Nhóm thực phẩm nào giàu chất đạm?','thịt, cá, trứng','gạo, khoai','rau xanh','đường'],
  [3,'Nêu một việc giữ an toàn vệ sinh thực phẩm.','Ví dụ: rửa tay, rửa sạch thực phẩm, nấu chín, để riêng đồ sống – chín…'],
 ]);
 push('Công nghệ',7,'(Bổ sung) Trồng trọt, chăn nuôi',[
  [1,'Vai trò chính của trồng trọt là gì?','cung cấp lương thực, thực phẩm','gây ô nhiễm','làm cảnh','không có vai trò'],
  [2,'Biện pháp phòng trừ sâu bệnh thân thiện môi trường là gì?','biện pháp sinh học','phun nhiều thuốc hóa học','đốt ruộng','bỏ mặc'],
  [3,'Nêu một việc chăm sóc vật nuôi.','Ví dụ: cho ăn đủ chất, giữ chuồng sạch, tiêm phòng, cho uống nước sạch…'],
 ]);
 push('Công nghệ',8,'(Bổ sung) Cơ khí và an toàn điện',[
  [1,'Vật liệu nào sau đây là kim loại?','thép','gỗ','nhựa','cao su'],
  [2,'Khi tay ướt, em có nên chạm vào thiết bị điện không?','không, rất nguy hiểm','có, bình thường','tùy thích','chỉ ban ngày'],
  [3,'Nêu một dụng cụ bảo hộ khi thực hành và tác dụng.','Ví dụ: kính bảo hộ bảo vệ mắt; găng tay bảo vệ tay; giày bảo hộ bảo vệ chân…'],
 ]);
 push('Công nghệ',9,'(Bổ sung) Nghề nghiệp và chế biến',[
  [1,'Chọn nghề phù hợp nên dựa vào yếu tố nào?','sở thích, năng lực và nhu cầu xã hội','chọn theo bạn','chọn đại','người khác ép'],
  [2,'Phương pháp chế biến nào không dùng nhiệt?','trộn (nộm/gỏi)','luộc','rán','nướng'],
  [3,'Nêu một việc em làm từ bây giờ để chuẩn bị nghề nghiệp.','Ví dụ: học tốt, rèn kĩ năng, tìm hiểu các nghề, khám phá sở thích – năng lực…'],
 ]);

 /* ---------- TIẾNG ANH ---------- */
 push('Tiếng Anh',6,'(Bổ sung) Vocabulary & grammar',[
  [1,'Chọn đáp án đúng: She ___ a student.','is','am','are','be'],
  [1,'"Book" nghĩa là gì?','quyển sách','cái bút','cái bàn','cái ghế'],
  [2,'Chọn đáp án đúng: They ___ football every Sunday.','play','plays','playing','to play'],
  [3,'Viết một câu giới thiệu tên em bằng tiếng Anh.','Ví dụ: My name is Lan. / I am Lan.'],
 ]);
 push('Tiếng Anh',7,'(Bổ sung) Tenses & vocabulary',[
  [1,'Chọn đáp án đúng: He ___ to school yesterday.','went','go','goes','going'],
  [2,'Chọn đáp án đúng: I ___ TV now.','am watching','watch','watched','watches'],
  [2,'"Hospital" nghĩa là gì?','bệnh viện','trường học','chợ','công viên'],
  [3,'Viết một câu về sở thích của em bằng tiếng Anh.','Ví dụ: I like reading books. / I love playing badminton.'],
 ]);
 push('Tiếng Anh',8,'(Bổ sung) Grammar & reading',[
  [1,'Chọn đáp án đúng: If it ___ tomorrow, we will stay at home.','rains','rain','rained','raining'],
  [2,'Dạng so sánh hơn của "big" là gì?','bigger','biger','more big','biggest'],
  [2,'Chọn đáp án đúng: This book is ___ than that one.','more interesting','interesting','most interesting','interestinger'],
  [3,'Viết một câu dùng thì hiện tại hoàn thành.','Ví dụ: I have finished my homework. / She has visited Ha Noi.'],
 ]);
 push('Tiếng Anh',9,'(Bổ sung) Grammar & communication',[
  [1,'Chọn đáp án đúng: The letter ___ by Nam yesterday.','was written','wrote','written','writes'],
  [2,'Chọn câu tường thuật đúng: He said, "I am tired." → He said that he ___ tired.','was','is','are','be'],
  [2,'"Environment" nghĩa là gì?','môi trường','chính phủ','giáo dục','giao thông'],
  [3,'Viết một câu đề nghị giúp đỡ bằng tiếng Anh.','Ví dụ: Can I help you? / Shall I open the door?'],
 ]);

 /* ---------- NGHỆ THUẬT / GDTC / HĐTN (dùng chung mọi khối, clone) ---------- */
 const CL=a=>JSON.parse(JSON.stringify(a));
 const AN=[ {cd:'(Bổ sung) Nhạc lí và thường thức',q:[
  [1,'Theo hệ thống chữ cái La-tinh, nốt Son được kí hiệu bằng chữ nào?','G','S','C','E'],
  [2,'Dấu lặng trong bản nhạc biểu thị điều gì?','thời gian nghỉ (ngừng âm thanh)','hát to','hát nhanh','kết bài'],
  [3,'Nêu một việc nên làm để hát hay hơn.','Ví dụ: lấy hơi đúng, hát rõ lời, đúng cao độ – trường độ, luyện tập đều…'],
 ],_bs:true} ];
 const MT=[ {cd:'(Bổ sung) Màu sắc và bố cục',q:[
  [1,'Trên vòng thuần sắc, màu cam nằm giữa hai màu cơ bản nào?','đỏ và vàng','vàng và lam','đỏ và lam','lam và lục'],
  [2,'Yếu tố nào tạo chiều sâu, khối trong tranh?','đậm nhạt (sáng – tối)','chỉ đường nét','chữ viết','âm thanh'],
  [3,'Nêu các bước vẽ một bức tranh đề tài.','Tìm ý tưởng → phác bố cục → vẽ hình → vẽ màu → hoàn thiện.'],
 ],_bs:true} ];
 const TC=[ {cd:'(Bổ sung) Sức khỏe và vận động',q:[
  [1,'Trước khi vận động mạnh cần làm gì?','khởi động kĩ','ăn thật no','ngồi nghỉ','uống nước ngọt'],
  [2,'Khi bị chuột rút nên làm gì?','dừng lại, kéo giãn nhẹ và nghỉ','cố chạy tiếp','nhịn đau tập mạnh','bỏ chạy'],
  [3,'Nêu 2 môn thể thao và lợi ích.','Ví dụ: bơi, cầu lông… rèn sức bền, nhanh nhẹn, khỏe mạnh.'],
 ],_bs:true} ];
 const HD=[ {cd:'(Bổ sung) Kĩ năng sống',q:[
  [1,'Để quản lí thời gian tốt, em nên làm gì?','lập thời gian biểu và thực hiện','làm tùy hứng','trì hoãn','thức khuya chơi'],
  [2,'Khi mâu thuẫn với bạn, cách ứng xử phù hợp là gì?','bình tĩnh trao đổi, lắng nghe','cãi to','giận dỗi bỏ đi','rủ người đánh bạn'],
  [3,'Nêu một mục tiêu rèn luyện bản thân và cách thực hiện.','Ví dụ: dậy sớm → đặt báo thức, ngủ đúng giờ, kiên trì mỗi ngày…'],
 ],_bs:true} ];
 [6,7,8,9].forEach(l=>{
  if(NH['Âm nhạc'])NH['Âm nhạc'][l]=(NH['Âm nhạc'][l]||[]).concat(CL(AN));
  if(NH['Mĩ thuật'])NH['Mĩ thuật'][l]=(NH['Mĩ thuật'][l]||[]).concat(CL(MT));
  if(NH['Giáo dục thể chất'])NH['Giáo dục thể chất'][l]=(NH['Giáo dục thể chất'][l]||[]).concat(CL(TC));
  if(NH['Hoạt động trải nghiệm'])NH['Hoạt động trải nghiệm'][l]=(NH['Hoạt động trải nghiệm'][l]||[]).concat(CL(HD));
 });
})();
