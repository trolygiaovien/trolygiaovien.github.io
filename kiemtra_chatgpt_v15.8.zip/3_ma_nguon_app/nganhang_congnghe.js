/* ============================================================
   NGÂN HÀNG CÔNG NGHỆ (THCS) — bổ sung cho đủ chuẩn
   Mỗi mục: ≥6 trắc nghiệm + ≥4 tự luận + có câu nâng cao (mức 4).
   Nguyên bản, bám SGK Kết nối tri thức. Lượt này: LỚP 6.
   TN [mức,'câu','ĐÚNG','sai','sai','sai'] · TL [mức,'câu','đáp án']
   ============================================================ */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Công nghệ';

 /* ===================== LỚP 6 ===================== */
 add(M,6,'Bài 1: Khái quát về nhà ở',[
  [1,'Vai trò chính của nhà ở đối với con người là gì?','Bảo vệ con người trước thời tiết, là nơi sinh hoạt, nghỉ ngơi','Chỉ để trưng bày','Chỉ để nấu ăn','Không có vai trò'],
  [1,'Nhà ở gồm những khu vực chức năng chính nào?','Nơi thờ cúng, tiếp khách, ngủ nghỉ, nấu ăn, vệ sinh','Chỉ có một phòng','Chỉ có sân','Chỉ có bếp'],
  [2,'Vì sao nhà ở của mỗi vùng miền lại có đặc điểm khác nhau?','Do khí hậu, địa hình, vật liệu sẵn có và phong tục từng vùng','Do ngẫu nhiên','Do giống hệt nhau','Không có lí do'],
  [2,'Nhà sàn thường xuất hiện ở vùng nào?','Vùng miền núi','Vùng đồng bằng đô thị','Vùng ven biển cát','Giữa thành phố'],
  [2,'Kiến trúc nhà ở nổi (nhà bè) phù hợp với vùng nào?','Vùng sông nước','Vùng núi cao','Vùng sa mạc','Vùng băng tuyết'],
  [3,'Nêu vai trò của nhà ở đối với đời sống con người.','Bảo vệ con người khỏi tác động của thời tiết, thiên nhiên; là nơi sinh hoạt, nghỉ ngơi, học tập, gắn kết các thành viên gia đình; đáp ứng nhu cầu vật chất và tinh thần.'],
  [3,'Kể một số kiểu nhà ở đặc trưng ở các vùng miền nước ta.','Nhà sàn (miền núi), nhà ba gian ở nông thôn đồng bằng, nhà nổi/nhà bè (vùng sông nước), nhà chung cư/nhà phố (đô thị).'],
  [4,'Vì sao đặc điểm nhà ở lại phản ánh điều kiện tự nhiên và văn hóa của mỗi vùng?','Con người xây nhà phù hợp với khí hậu, địa hình, vật liệu sẵn có để thuận tiện và an toàn (nhà sàn tránh thú, ẩm; nhà nổi hợp sông nước); đồng thời kiểu dáng, cách bố trí thể hiện phong tục, nếp sống nên nhà ở phản ánh cả tự nhiên và văn hóa vùng miền.']
 ]);
 add(M,6,'Bài 2: Xây dựng nhà ở',[
  [1,'Các bước chính để xây dựng một ngôi nhà gồm những gì?','Chuẩn bị, thi công, hoàn thiện','Chỉ quét vôi','Chỉ lợp mái','Chỉ đổ móng'],
  [1,'Bộ phận nào chịu lực, đỡ toàn bộ ngôi nhà?','Móng nhà','Mái nhà','Cửa sổ','Tường trang trí'],
  [2,'Vật liệu nào thường dùng để xây tường nhà?','Gạch, xi măng, cát','Lá cây khô','Giấy','Vải'],
  [2,'Giai đoạn hoàn thiện nhà ở gồm công việc nào?','Trát tường, lát nền, sơn, lắp cửa','Đào móng','Dựng cột','Đổ bê tông móng'],
  [2,'Khi xây nhà, cần chú ý điều gì để bảo đảm an toàn?','Tuân thủ kĩ thuật, an toàn lao động','Làm nhanh bất chấp','Bỏ qua móng','Không cần bảo hộ'],
  [3,'Nêu các bước cơ bản khi xây dựng một ngôi nhà.','Chuẩn bị (thiết kế, mặt bằng, vật liệu); thi công phần thô (móng, cột, tường, mái); hoàn thiện (trát, lát, sơn, lắp cửa, điện nước).'],
  [3,'Kể một số vật liệu xây dựng thông dụng và công dụng.','Gạch, xi măng, cát, đá (xây tường, đổ bê tông); thép (làm khung, cốt); ngói/tôn (lợp mái); gỗ, kính (cửa, nội thất).'],
  [4,'Vì sao phần móng được coi là quan trọng nhất của ngôi nhà?','Móng chịu toàn bộ tải trọng của ngôi nhà và truyền xuống nền đất. Móng không chắc, không đúng kĩ thuật sẽ khiến nhà bị lún, nứt, nghiêng, thậm chí sập; nên móng quyết định độ bền vững và an toàn của ngôi nhà.']
 ]);
 add(M,6,'Bài 3: Ngôi nhà thông minh',[
  [1,'Ngôi nhà thông minh là gì?','Nhà có lắp các thiết bị tự động điều khiển, giám sát giúp tiện nghi, an toàn','Nhà rất to','Nhà cũ','Nhà không có điện'],
  [1,'Đặc điểm nào là của ngôi nhà thông minh?','Tự động hóa, điều khiển từ xa, tiết kiệm năng lượng','Phải làm thủ công tất cả','Không có thiết bị điện','Không an toàn'],
  [2,'Hệ thống nào giúp ngôi nhà thông minh an ninh hơn?','Camera, cảm biến, báo động chống trộm','Không có hệ thống','Chỉ có khóa gỗ','Chỉ có rèm cửa'],
  [2,'Thiết bị cảm biến ánh sáng trong nhà thông minh dùng để làm gì?','Tự động bật/tắt đèn theo ánh sáng','Nấu ăn','Giặt đồ','Tưới cây ngoài trời duy nhất'],
  [2,'Lợi ích của ngôi nhà thông minh là gì?','Tiện nghi, an toàn, tiết kiệm năng lượng','Tốn điện vô ích','Kém an toàn','Bất tiện'],
  [3,'Nêu một số hệ thống thường có trong ngôi nhà thông minh.','Hệ thống chiếu sáng tự động; an ninh (camera, cảm biến, báo động); điều khiển thiết bị từ xa; cảnh báo cháy, rò khí ga; tiết kiệm năng lượng.'],
  [3,'Nêu lợi ích của ngôi nhà thông minh đối với đời sống.','Tiện nghi (điều khiển tự động, từ xa); an toàn (cảnh báo cháy, trộm); tiết kiệm năng lượng; phù hợp với người già, trẻ nhỏ, người bận rộn.'],
  [4,'Vì sao ngôi nhà thông minh góp phần tiết kiệm năng lượng và bảo vệ môi trường?','Nhờ cảm biến và tự động hóa, thiết bị chỉ hoạt động khi cần (đèn tắt khi không có người, điều hòa theo nhiệt độ), tránh lãng phí điện; tiết kiệm năng lượng giúp giảm chi phí và giảm phát thải, góp phần bảo vệ môi trường.']
 ]);
 add(M,6,'Bài 4: Thực phẩm và dinh dưỡng',[
  [1,'Thực phẩm cung cấp cho cơ thể những gì?','Chất dinh dưỡng và năng lượng để sống và hoạt động','Chỉ nước','Chỉ không khí','Không cung cấp gì'],
  [1,'Có mấy nhóm chất dinh dưỡng chính?','Bốn nhóm: chất bột đường, chất đạm, chất béo, vi-ta-min và chất khoáng','Một nhóm','Hai nhóm','Sáu nhóm'],
  [2,'Chất đạm có nhiều trong thực phẩm nào?','Thịt, cá, trứng, sữa, đậu','Đường, bánh kẹo','Dầu mỡ','Nước lọc'],
  [2,'Chất bột đường (tinh bột) có nhiều trong thực phẩm nào?','Gạo, ngô, khoai, bánh mì','Thịt nạc','Dầu ăn','Rau xanh chủ yếu'],
  [2,'Vi-ta-min và chất khoáng có nhiều trong nhóm thực phẩm nào?','Rau xanh và trái cây','Dầu mỡ','Cơm trắng','Đường tinh luyện'],
  [3,'Kể tên 4 nhóm chất dinh dưỡng và vai trò của mỗi nhóm.','Chất bột đường: cung cấp năng lượng chính. Chất đạm: xây dựng, phát triển cơ thể. Chất béo: dự trữ và cung cấp năng lượng. Vi-ta-min và chất khoáng: tăng sức đề kháng, giúp cơ thể hoạt động bình thường.'],
  [3,'Thế nào là bữa ăn hợp lí, đủ chất?','Bữa ăn có đủ và cân đối 4 nhóm chất dinh dưỡng, phù hợp lứa tuổi và nhu cầu; ăn đúng giờ, đủ bữa, đa dạng thực phẩm, có rau quả và đủ nước.'],
  [4,'Vì sao cần ăn phối hợp nhiều loại thực phẩm thay vì chỉ ăn một vài món?','Vì mỗi loại thực phẩm cung cấp chất dinh dưỡng khác nhau; ăn phối hợp giúp cơ thể nhận đủ và cân đối các chất, phát triển khỏe mạnh. Ăn thiếu đa dạng dễ thừa chất này, thiếu chất kia, gây suy dinh dưỡng hoặc béo phì.']
 ]);
 add(M,6,'Bài 5: Phương pháp bảo quản và chế biến thực phẩm',[
  [1,'Bảo quản thực phẩm nhằm mục đích gì?','Giữ thực phẩm tươi, an toàn, lâu hỏng','Làm thực phẩm nhanh hỏng','Làm mất chất','Không có mục đích'],
  [1,'Phương pháp nào dưới đây dùng để bảo quản thực phẩm?','Làm lạnh, phơi khô, ướp muối','Để ngoài nắng nóng cho hỏng','Trộn đất','Ngâm nước bẩn'],
  [2,'Chế biến thực phẩm có sử dụng nhiệt gồm phương pháp nào?','Luộc, kho, rán, hấp','Trộn gỏi','Muối dưa','Ngâm giấm'],
  [2,'Chế biến thực phẩm không sử dụng nhiệt gồm phương pháp nào?','Trộn (nộm/gỏi), muối chua','Luộc','Rán','Nướng'],
  [2,'Vì sao cần ăn chín, uống sôi?','Để tiêu diệt vi khuẩn, phòng tránh ngộ độc và bệnh tật','Để mất chất','Cho đẹp mắt','Không có lí do'],
  [3,'Nêu một số phương pháp bảo quản thực phẩm và ví dụ.','Làm lạnh/đông lạnh (thịt, cá trong tủ lạnh); phơi, sấy khô (cá khô, măng khô); ướp muối, đường (dưa, mứt); đóng hộp, hút chân không.'],
  [3,'Phân biệt chế biến thực phẩm có và không sử dụng nhiệt, cho ví dụ.','Có nhiệt: dùng nhiệt làm chín (luộc, kho, rán, hấp, nướng). Không nhiệt: không dùng nhiệt (trộn gỏi, muối chua, ngâm). Mỗi cách giữ hương vị, chất dinh dưỡng khác nhau.'],
  [4,'Vì sao bảo quản và chế biến thực phẩm đúng cách lại quan trọng đối với sức khỏe?','Bảo quản đúng giúp thực phẩm tươi, không nhiễm khuẩn, giữ được chất dinh dưỡng; chế biến đúng (ăn chín, vệ sinh) tiêu diệt vi khuẩn, phòng ngộ độc. Làm sai cách khiến thực phẩm hỏng, mất chất hoặc gây bệnh, ảnh hưởng sức khỏe.']
 ]);
 add(M,6,'Bài 6: Dự án: Bữa ăn kết nối yêu thương',[
  [1,'Khi xây dựng thực đơn cho bữa ăn gia đình, cần bảo đảm điều gì?','Đủ chất, cân đối dinh dưỡng, phù hợp khẩu vị và chi phí','Chỉ cần ngon miệng','Chỉ cần rẻ','Chỉ cần nhiều món'],
  [1,'Một bữa ăn hợp lí thường gồm những loại món nào?','Món chính (cơm), món mặn (đạm), món rau, canh','Chỉ có cơm','Chỉ có thịt','Chỉ có bánh kẹo'],
  [2,'Để bữa ăn đủ dinh dưỡng, thực đơn cần có đủ nhóm chất nào?','Bột đường, đạm, béo, vi-ta-min và chất khoáng','Chỉ bột đường','Chỉ đạm','Chỉ chất béo'],
  [2,'Vì sao nên có rau xanh và trái cây trong bữa ăn?','Cung cấp vi-ta-min, chất khoáng và chất xơ','Để đẹp mắt','Không cần thiết','Làm no bụng vô ích'],
  [2,'Khi lập thực đơn, cần cân nhắc yếu tố nào về kinh tế?','Phù hợp với chi phí, không lãng phí','Càng đắt càng tốt','Mua thật nhiều','Không quan tâm giá'],
  [3,'Hãy lập một thực đơn bữa cơm gia đình đủ chất cho 4 người.','VD: cơm; cá kho (đạm); rau luộc/xào (vi-ta-min, chất xơ); canh; tráng miệng trái cây. Đủ 4 nhóm chất, cân đối, phù hợp chi phí.'],
  [3,'Nêu các bước thực hiện dự án chuẩn bị một bữa ăn cho gia đình.','Xác định số người, nhu cầu; lập thực đơn đủ chất; lên danh sách và mua thực phẩm; sơ chế, chế biến bảo đảm vệ sinh; trình bày; dọn ăn và thu dọn.'],
  [4,'Vì sao bữa ăn gia đình không chỉ quan trọng về dinh dưỡng mà còn về mặt tình cảm?','Bữa ăn cung cấp dinh dưỡng cho sức khỏe; đồng thời là lúc các thành viên quây quần, trò chuyện, chia sẻ, thể hiện sự quan tâm, yêu thương. Nhờ đó bữa ăn gắn kết tình cảm gia đình, tạo nếp sống ấm áp.']
 ]);
 add(M,6,'Bài 7: Trang phục trong đời sống',[
  [1,'Trang phục có vai trò gì đối với con người?','Bảo vệ cơ thể và làm đẹp cho con người','Chỉ để khoe','Không có vai trò','Chỉ để giữ ấm mùa đông'],
  [1,'Trang phục được phân loại theo tiêu chí nào?','Theo thời tiết, công dụng, giới tính, lứa tuổi','Theo màu nhà','Theo tên người','Theo giá vàng'],
  [2,'Chất liệu vải nào thường mát, thấm mồ hôi tốt, hợp mùa hè?','Vải sợi bông (cotton)','Vải ni-lông dày','Vải da','Vải len dày'],
  [2,'Trang phục mùa đông nên có đặc điểm gì?','Dày, giữ ấm tốt','Mỏng, thoáng mát','Hở nhiều','Chỉ bằng vải mỏng'],
  [2,'Khi chọn trang phục, cần chú ý điều gì?','Phù hợp vóc dáng, lứa tuổi, hoàn cảnh và thời tiết','Chỉ cần đắt tiền','Chỉ chạy theo mốt','Không cần phù hợp'],
  [3,'Nêu vai trò của trang phục trong đời sống.','Bảo vệ cơ thể khỏi thời tiết, bụi bẩn; làm đẹp, tôn dáng; thể hiện cá tính, nghề nghiệp, văn hóa; phù hợp hoàn cảnh giúp con người tự tin, lịch sự.'],
  [3,'Nêu cách chọn trang phục phù hợp với bản thân.','Chọn theo vóc dáng (che khuyết điểm, tôn ưu điểm), lứa tuổi, hoàn cảnh (đi học, lao động, lễ hội), thời tiết và điều kiện kinh tế; màu sắc, kiểu dáng hài hòa.'],
  [4,'Vì sao cách ăn mặc phù hợp lại thể hiện sự tôn trọng bản thân và người khác?','Ăn mặc gọn gàng, lịch sự, phù hợp hoàn cảnh cho thấy ý thức, nề nếp của bản thân và tôn trọng người xung quanh, nơi mình đến (trường học, lễ hội...). Ăn mặc cẩu thả hoặc không phù hợp dễ gây phản cảm, thiếu tôn trọng.']
 ]);
 add(M,6,'Bài 8: Sử dụng và bảo quản trang phục',[
  [1,'Bảo quản trang phục gồm những công việc nào?','Giặt, phơi, là (ủi), cất giữ','Chỉ mặc rồi vứt','Chỉ mua mới','Không làm gì'],
  [1,'Trước khi giặt, nên làm gì với quần áo?','Phân loại theo màu và chất liệu','Giặt lẫn lộn tất cả','Không cần phân loại','Vò thật mạnh mọi loại'],
  [2,'Vì sao cần phân loại quần áo sáng màu và sẫm màu khi giặt?','Tránh quần áo bị lem màu, phai màu','Cho nhanh','Để tốn nước','Không có lí do'],
  [2,'Kí hiệu giặt là trên nhãn quần áo dùng để làm gì?','Hướng dẫn cách giặt, là, bảo quản đúng','Trang trí','Ghi giá tiền','Ghi tên người bán'],
  [2,'Cách phơi quần áo hợp lí là gì?','Phơi nơi thoáng, có nắng nhẹ hoặc gió; lộn trái đồ dễ phai','Phơi nơi ẩm thấp','Vo tròn rồi phơi','Để trong túi kín'],
  [3,'Nêu các bước sử dụng và bảo quản trang phục để bền, đẹp.','Mặc đúng mục đích; giặt (phân loại, đúng cách), phơi nơi thoáng; là (ủi) ở nhiệt độ phù hợp chất liệu; gấp hoặc treo, cất nơi khô ráo, sạch sẽ.'],
  [3,'Vì sao cần đọc kí hiệu trên nhãn trước khi giặt, là quần áo?','Kí hiệu cho biết cách giặt, nhiệt độ là, có được tẩy, sấy không... Làm đúng giúp quần áo bền, không hỏng, không co rút, phai màu; làm sai dễ làm hỏng quần áo.'],
  [4,'Vì sao biết sử dụng và bảo quản trang phục đúng cách vừa tiết kiệm vừa thể hiện nếp sống văn minh?','Bảo quản đúng giúp quần áo bền, đẹp, dùng được lâu nên tiết kiệm chi phí, tránh lãng phí. Người biết giữ gìn, sắp xếp quần áo gọn gàng thể hiện tính ngăn nắp, cẩn thận và nếp sống văn minh, có trách nhiệm.']
 ]);
 add(M,6,'Bài 9: Thời trang',[
  [1,'Thời trang là gì?','Kiểu cách ăn mặc phổ biến, được ưa chuộng trong một thời kì','Quần áo cũ rách','Một loại thực phẩm','Một thiết bị điện'],
  [1,'Phong cách thời trang thể hiện điều gì?','Cá tính, sở thích, gu thẩm mĩ của người mặc','Số tiền trong túi','Điểm học tập','Nghề của bố mẹ'],
  [2,'Khi chạy theo thời trang, học sinh nên chú ý điều gì?','Phù hợp lứa tuổi, hoàn cảnh, điều kiện kinh tế','Mua mọi thứ đang mốt','Bỏ học để mua sắm','Vay tiền mua đồ hiệu'],
  [2,'Phong cách ăn mặc phù hợp với học sinh là gì?','Gọn gàng, lịch sự, phù hợp môi trường học đường','Hở hang, lòe loẹt','Rách rưới cố ý','Theo mốt bất chấp'],
  [2,'Yếu tố nào KHÔNG nên là lí do chính khi chọn theo thời trang?','Đua đòi, chạy theo bạn bè bằng mọi giá','Phù hợp bản thân','Phù hợp hoàn cảnh','Phù hợp kinh tế'],
  [3,'Nêu suy nghĩ của em về việc ăn mặc theo thời trang ở lứa tuổi học sinh.','Có thể cập nhật xu hướng nhưng cần phù hợp lứa tuổi, môi trường học đường (gọn gàng, lịch sự), điều kiện kinh tế gia đình; không đua đòi, lãng phí hay ảnh hưởng học tập.'],
  [3,'Nêu cách lựa chọn trang phục vừa hợp thời trang vừa phù hợp bản thân.','Chọn kiểu dáng, màu sắc hợp vóc dáng, lứa tuổi, hoàn cảnh; cập nhật xu hướng có chọn lọc; ưu tiên gọn gàng, lịch sự, thoải mái và phù hợp kinh tế.'],
  [4,'Vì sao "hợp thời trang" không có nghĩa là phải chạy theo mọi xu hướng mới nhất?','Vì mỗi người có vóc dáng, hoàn cảnh, điều kiện khác nhau; không phải mốt nào cũng hợp với mình. Ăn mặc đẹp là phù hợp bản thân và hoàn cảnh, biết chọn lọc xu hướng; chạy theo mọi mốt gây lãng phí, đua đòi và đôi khi phản cảm.']
 ]);
 add(M,6,'Bài 10: Khái quát về đồ dùng điện trong gia đình',[
  [1,'Đồ dùng điện trong gia đình hoạt động nhờ nguồn năng lượng nào?','Điện năng','Sức gió','Sức nước trực tiếp','Sức người'],
  [1,'Thông số kĩ thuật thường ghi trên đồ dùng điện là gì?','Điện áp định mức và công suất định mức','Màu sắc','Tên người dùng','Giá bán lẻ'],
  [2,'Điện áp định mức của đồ dùng điện trong gia đình ở Việt Nam thường là bao nhiêu?','220V','5V','12V','1000V'],
  [2,'Công suất định mức cho biết điều gì?','Mức tiêu thụ điện năng của thiết bị khi hoạt động','Giá tiền','Khối lượng','Màu sắc'],
  [2,'Vì sao cần dùng đồ dùng điện đúng điện áp định mức?','Để thiết bị hoạt động an toàn, bền; dùng sai điện áp dễ hỏng hoặc cháy','Để tốn điện','Để nhanh hỏng','Không có lí do'],
  [3,'Nêu ý nghĩa của các thông số kĩ thuật ghi trên đồ dùng điện.','Điện áp định mức: hiệu điện thế để thiết bị hoạt động đúng, an toàn. Công suất định mức: mức tiêu thụ điện năng, giúp chọn thiết bị và tính điện năng tiêu thụ.'],
  [3,'Nêu một số đồ dùng điện thông dụng trong gia đình và công dụng.','Đèn điện (chiếu sáng), quạt (làm mát), nồi cơm điện (nấu cơm), tủ lạnh (bảo quản thực phẩm), bàn là (là quần áo), ti vi (giải trí).'],
  [4,'Vì sao hiểu các thông số kĩ thuật giúp sử dụng đồ dùng điện an toàn và tiết kiệm?','Biết điện áp định mức giúp dùng đúng nguồn, tránh hỏng, cháy nổ; biết công suất giúp chọn thiết bị phù hợp, ước tính và tiết kiệm điện năng, chọn dây dẫn, ổ cắm chịu tải đúng — nhờ đó dùng an toàn và tiết kiệm.']
 ]);
 add(M,6,'Bài 11: Đèn điện',[
  [1,'Đèn điện dùng để làm gì?','Chiếu sáng','Nấu ăn','Làm mát','Giặt đồ'],
  [1,'Loại đèn nào tiết kiệm điện và bền hơn?','Đèn LED','Đèn sợi đốt','Nến','Đèn dầu'],
  [2,'Bộ phận phát sáng của đèn sợi đốt là gì?','Dây tóc (sợi đốt)','Vỏ nhựa','Dây dẫn ngoài','Công tắc'],
  [2,'Vì sao nên thay đèn sợi đốt bằng đèn LED?','Đèn LED tiết kiệm điện, bền, ít nóng','Đèn LED tốn điện hơn','Đèn LED nhanh hỏng','Không có lí do'],
  [2,'Khi đèn điện bị hỏng, cần làm gì cho an toàn?','Ngắt điện trước khi kiểm tra, thay thế','Sờ vào khi đang bật điện','Dùng tay ướt chạm vào','Để nguyên không ngắt điện'],
  [3,'So sánh đèn LED và đèn sợi đốt về hiệu quả sử dụng.','Đèn LED: tiêu thụ điện ít, tuổi thọ cao, ít tỏa nhiệt, sáng tốt. Đèn sợi đốt: tốn điện, nhanh hỏng, tỏa nhiều nhiệt. LED hiệu quả và tiết kiệm hơn.'],
  [3,'Nêu cách sử dụng đèn điện an toàn và tiết kiệm.','Tắt đèn khi không dùng; tận dụng ánh sáng tự nhiên; dùng đèn LED; lắp đặt đúng kĩ thuật; không chạm vào đèn/ổ điện khi tay ướt; ngắt điện khi sửa chữa.'],
  [4,'Vì sao sử dụng đèn LED góp phần bảo vệ môi trường?','Đèn LED tiêu thụ ít điện hơn nhiều so với đèn sợi đốt, tuổi thọ cao nên ít phải thay, giảm rác thải; tiết kiệm điện đồng nghĩa giảm nhu cầu sản xuất điện, giảm phát thải — góp phần bảo vệ môi trường.']
 ]);
 add(M,6,'Bài 12: Nồi cơm điện',[
  [1,'Nồi cơm điện dùng để làm gì?','Nấu và giữ ấm cơm','Là quần áo','Làm mát phòng','Chiếu sáng'],
  [1,'Bộ phận nào của nồi cơm điện tiếp xúc trực tiếp và chứa gạo, nước?','Nồi (lòng nồi)','Dây điện','Vỏ ngoài','Công tắc'],
  [2,'Khi dùng nồi cơm điện, cần chú ý điều gì để an toàn?','Lau khô đáy nồi, đặt đúng, không dùng tay ướt chạm phích điện','Cắm điện khi tay ướt','Để nước tràn vào mâm nhiệt','Dùng khi dây điện hở'],
  [2,'Sau khi cơm chín, nồi cơm điện tự chuyển sang chế độ nào?','Giữ ấm','Nấu lại liên tục','Tắt nguồn hoàn toàn','Làm lạnh'],
  [2,'Để nồi cơm điện bền, nên vệ sinh thế nào?','Lau sạch lòng nồi, mâm nhiệt khô ráo sau khi dùng','Ngâm cả nồi vào nước','Để bẩn lâu ngày','Dùng vật cứng cạo lòng nồi'],
  [3,'Nêu cấu tạo cơ bản và nguyên lí hoạt động của nồi cơm điện.','Gồm vỏ, lòng nồi, mâm nhiệt (bộ phận đốt nóng), bộ điều khiển. Khi cắm điện, mâm nhiệt nóng lên nấu chín cơm; cơm chín, nồi tự chuyển sang giữ ấm.'],
  [3,'Nêu các bước sử dụng nồi cơm điện đúng cách.','Vo gạo, cho gạo và nước vào lòng nồi với lượng phù hợp; lau khô đáy nồi, đặt đúng vào mâm nhiệt; đậy nắp, cắm điện, bật nấu; cơm chín chuyển giữ ấm; rút điện và vệ sinh sau khi dùng.'],
  [4,'Vì sao cần lau khô đáy lòng nồi và mâm nhiệt trước khi nấu cơm điện?','Nếu đáy nồi hoặc mâm nhiệt ướt, bẩn thì tiếp xúc nhiệt không đều, dễ làm cơm sống/khê, gây chập, hỏng mâm nhiệt và mất an toàn điện. Lau khô giúp nồi truyền nhiệt tốt, nấu ngon, bền và an toàn.']
 ]);
 add(M,6,'Bài 13: Bếp hồng ngoại',[
  [1,'Bếp hồng ngoại dùng để làm gì?','Đun nấu thức ăn','Chiếu sáng','Giặt đồ','Làm mát'],
  [1,'Bếp hồng ngoại làm nóng bằng cách nào?','Bức xạ nhiệt hồng ngoại làm nóng mặt bếp và nồi','Dùng ga','Dùng củi','Dùng sức gió'],
  [2,'Ưu điểm của bếp hồng ngoại so với bếp ga là gì?','Không dùng khí ga nên an toàn hơn về cháy nổ, sạch','Tốn ga hơn','Gây khói nhiều','Dễ cháy nổ hơn'],
  [2,'Khi bếp hồng ngoại vừa tắt, cần lưu ý điều gì?','Mặt bếp còn rất nóng, không chạm tay vào','Chạm tay vào ngay','Đổ nước lạnh ngay','Để trẻ nhỏ sờ vào'],
  [2,'Loại nồi nào dùng được cho bếp hồng ngoại?','Hầu hết các loại nồi có đáy phẳng (kể cả không nhiễm từ)','Chỉ nồi giấy','Chỉ nồi nhựa','Không dùng nồi nào'],
  [3,'Nêu một số lưu ý để sử dụng bếp hồng ngoại an toàn.','Đặt bếp nơi khô ráo, bằng phẳng; không chạm mặt bếp khi nóng; không để nước, vật dễ cháy gần; rút điện sau khi dùng; để xa tầm trẻ nhỏ; vệ sinh khi bếp nguội.'],
  [3,'So sánh bếp hồng ngoại và bếp ga về mức độ an toàn, vệ sinh.','Bếp hồng ngoại dùng điện, không có khí ga nên ít nguy cơ cháy nổ do rò ga, không khói, sạch. Bếp ga tiện nhưng có nguy cơ rò ga, cháy nổ, cần thông thoáng. Bếp hồng ngoại nhìn chung an toàn và sạch hơn.'],
  [4,'Vì sao sau khi tắt bếp hồng ngoại vẫn phải cẩn thận với mặt bếp?','Vì mặt bếp hấp thụ và giữ nhiệt, sau khi tắt vẫn còn rất nóng trong một thời gian. Chạm vào có thể bị bỏng; cần chờ nguội hoặc dùng khăn, để xa tầm trẻ nhỏ để tránh tai nạn.']
 ]);
 add(M,6,'Bài 14: Dự án: An toàn và tiết kiệm trong gia đình',[
  [1,'Việc làm nào giúp tiết kiệm điện trong gia đình?','Tắt thiết bị điện khi không dùng, dùng đèn LED','Bật mọi thiết bị cả ngày','Mở tủ lạnh lâu','Để điều hòa khi mở cửa'],
  [1,'Việc làm nào bảo đảm an toàn điện trong nhà?','Không dùng tay ướt chạm ổ điện, thiết bị','Cắm nhiều phích một ổ','Dùng dây điện hở','Để trẻ nghịch ổ điện'],
  [2,'Để tiết kiệm nước trong gia đình, nên làm gì?','Khóa vòi khi không dùng, tận dụng nước hợp lí','Để vòi chảy liên tục','Rửa dưới vòi mạnh lâu','Không sửa vòi rò'],
  [2,'Hành vi nào dễ gây tai nạn điện trong gia đình?','Dùng thiết bị điện hỏng, dây hở; tay ướt chạm điện','Ngắt điện khi sửa','Dùng ổ cắm chắc chắn','Để xa tầm trẻ'],
  [2,'Vì sao cần rút phích cắm các thiết bị khi không sử dụng lâu?','Tiết kiệm điện và tăng an toàn, tránh chập cháy','Để tốn điện','Để thiết bị nhanh hỏng','Không có lí do'],
  [3,'Nêu các biện pháp bảo đảm an toàn điện trong gia đình.','Không chạm thiết bị, ổ điện khi tay ướt; không dùng dây, thiết bị điện hỏng/hở; để xa tầm trẻ; ngắt điện khi sửa chữa; dùng ổ cắm, dây dẫn đúng tải; lắp thiết bị chống giật.'],
  [3,'Nêu các việc làm giúp tiết kiệm điện, nước trong gia đình.','Tắt đèn, quạt, thiết bị khi không dùng; dùng đèn LED, thiết bị tiết kiệm điện; tận dụng ánh sáng, gió tự nhiên; khóa vòi nước, sửa chỗ rò; dùng nước, điện hợp lí.'],
  [4,'Vì sao thực hành an toàn và tiết kiệm điện, nước là trách nhiệm của mỗi thành viên trong gia đình?','Vì an toàn điện, nước liên quan tính mạng và tài sản của cả nhà; tiết kiệm giúp giảm chi phí, bảo vệ tài nguyên và môi trường. Mỗi người có ý thức và hành động đúng mới tạo nên gia đình an toàn, tiết kiệm; chỉ một người bất cẩn cũng có thể gây hậu quả cho cả nhà.']
 ]);
 /* Chủ đề tổng hợp L6 */
 add(M,6,'Nhà ở, đồ dùng trong gia đình',[
  [1,'Vai trò chính của nhà ở là gì?','Bảo vệ con người và là nơi sinh hoạt của gia đình','Chỉ để trưng bày','Chỉ để nấu ăn','Không có vai trò'],
  [2,'Ngôi nhà thông minh có đặc điểm gì?','Tự động hóa, an toàn, tiết kiệm năng lượng','Không có điện','Phải làm thủ công tất cả','Kém an toàn'],
  [2,'Bộ phận chịu lực quan trọng nhất của ngôi nhà là gì?','Móng nhà','Rèm cửa','Mái trang trí','Cửa sổ'],
  [3,'Kể một số kiểu nhà ở đặc trưng theo vùng miền nước ta.','Nhà sàn (miền núi), nhà ba gian (nông thôn đồng bằng), nhà nổi/nhà bè (vùng sông nước), nhà phố/chung cư (đô thị).'],
  [4,'Vì sao kiểu nhà ở phản ánh điều kiện tự nhiên và văn hóa vùng miền?','Con người xây nhà phù hợp khí hậu, địa hình, vật liệu sẵn có và phong tục; nên nhà sàn, nhà nổi, nhà ba gian... vừa thích nghi tự nhiên vừa mang nét văn hóa của vùng đó.']
 ]);
 add(M,6,'An toàn điện, trang phục',[
  [1,'Hành vi nào bảo đảm an toàn điện?','Không chạm ổ điện, thiết bị khi tay ướt','Cắm nhiều phích một ổ','Dùng dây điện hở','Để trẻ nghịch điện'],
  [2,'Khi chọn trang phục cần chú ý điều gì?','Phù hợp vóc dáng, lứa tuổi, hoàn cảnh, thời tiết','Chỉ cần đắt','Chỉ chạy theo mốt','Không cần phù hợp'],
  [2,'Vì sao cần phân loại quần áo khi giặt?','Tránh lem màu, phai màu, hỏng vải','Cho nhanh','Để tốn nước','Không có lí do'],
  [3,'Nêu một số biện pháp an toàn khi sử dụng điện trong gia đình.','Không chạm điện khi tay ướt; không dùng dây, thiết bị hỏng/hở; ngắt điện khi sửa; để xa tầm trẻ; dùng ổ cắm, dây dẫn đúng tải.'],
  [4,'Vì sao ăn mặc phù hợp hoàn cảnh thể hiện sự tôn trọng bản thân và người khác?','Trang phục gọn gàng, lịch sự, hợp nơi đến cho thấy ý thức, nề nếp của bản thân và tôn trọng mọi người, không gian chung; ăn mặc tùy tiện dễ gây phản cảm, thiếu tôn trọng.']
 ]);
 add(M,6,'Thực phẩm và bảo quản, chế biến',[
  [1,'Có mấy nhóm chất dinh dưỡng chính?','Bốn nhóm','Một nhóm','Hai nhóm','Sáu nhóm'],
  [2,'Phương pháp nào dùng để bảo quản thực phẩm?','Làm lạnh, phơi khô, ướp muối','Để ngoài nắng cho hỏng','Trộn đất','Ngâm nước bẩn'],
  [2,'Vì sao cần ăn chín, uống sôi?','Để diệt vi khuẩn, phòng ngộ độc','Để mất chất','Cho đẹp mắt','Không có lí do'],
  [3,'Kể 4 nhóm chất dinh dưỡng và vai trò mỗi nhóm.','Bột đường: năng lượng; đạm: xây dựng cơ thể; béo: dự trữ, cung cấp năng lượng; vi-ta-min và khoáng: tăng đề kháng, giúp cơ thể hoạt động bình thường.'],
  [4,'Vì sao bảo quản và chế biến thực phẩm đúng cách quan trọng với sức khỏe?','Bảo quản đúng giữ thực phẩm tươi, không nhiễm khuẩn, giữ chất dinh dưỡng; chế biến đúng (ăn chín, vệ sinh) diệt vi khuẩn, phòng ngộ độc; làm sai gây hỏng, mất chất hoặc bệnh.']
 ]);
 add(M,6,'Đồ dùng điện và sử dụng an toàn',[
  [1,'Điện áp định mức của đồ dùng điện gia đình ở Việt Nam thường là?','220V','5V','12V','1000V'],
  [2,'Loại đèn nào tiết kiệm điện và bền?','Đèn LED','Đèn sợi đốt','Nến','Đèn dầu'],
  [2,'Khi sửa chữa đồ dùng điện, trước hết phải làm gì?','Ngắt nguồn điện','Dùng tay ướt','Vừa sửa vừa cắm điện','Để trẻ làm cùng'],
  [3,'Nêu một số việc làm giúp sử dụng đồ dùng điện an toàn và tiết kiệm.','Dùng đúng điện áp; tắt, rút phích khi không dùng; dùng đèn LED, thiết bị tiết kiệm; không chạm điện khi tay ướt; ngắt điện khi sửa; dùng ổ cắm đúng tải.'],
  [4,'Vì sao hiểu thông số kĩ thuật (điện áp, công suất) giúp dùng điện an toàn và tiết kiệm?','Biết điện áp định mức giúp dùng đúng nguồn, tránh cháy hỏng; biết công suất giúp chọn thiết bị, dây dẫn phù hợp và ước tính, tiết kiệm điện năng; nhờ đó dùng an toàn, hiệu quả.']
 ]);

 /* -------- L6: bù lẻ chủ đề tổng hợp -------- */
 add(M,6,'Nhà ở, đồ dùng trong gia đình',[
  [3,'Nêu lợi ích của ngôi nhà thông minh đối với đời sống.','Tiện nghi (điều khiển tự động, từ xa); an toàn (cảnh báo cháy, trộm); tiết kiệm năng lượng; phù hợp người già, trẻ nhỏ, người bận rộn.']
 ]);
 add(M,6,'An toàn điện, trang phục',[
  [1,'Kí hiệu trên nhãn quần áo dùng để làm gì?','Hướng dẫn cách giặt, là, bảo quản đúng','Trang trí','Ghi giá','Ghi tên người bán'],
  [3,'Nêu cách sử dụng và bảo quản trang phục để bền, đẹp.','Mặc đúng mục đích; giặt phân loại, đúng cách; phơi nơi thoáng; là ở nhiệt độ phù hợp; gấp/treo, cất nơi khô ráo, sạch sẽ.']
 ]);
 add(M,6,'Thực phẩm và bảo quản, chế biến',[
  [3,'Phân biệt chế biến thực phẩm có và không sử dụng nhiệt, cho ví dụ.','Có nhiệt: luộc, kho, rán, hấp, nướng. Không nhiệt: trộn gỏi, muối chua, ngâm. Mỗi cách giữ hương vị và chất dinh dưỡng khác nhau.']
 ]);
 add(M,6,'Đồ dùng điện và sử dụng an toàn',[
  [1,'Công suất định mức của đồ dùng điện cho biết điều gì?','Mức tiêu thụ điện năng khi hoạt động','Giá tiền','Khối lượng','Màu sắc'],
  [3,'Nêu cách sử dụng đèn điện an toàn và tiết kiệm.','Tắt đèn khi không dùng; tận dụng ánh sáng tự nhiên; dùng đèn LED; lắp đặt đúng kĩ thuật; không chạm đèn/ổ điện khi tay ướt; ngắt điện khi sửa.']
 ]);

 /* ===================== LỚP 7 ===================== */
 add(M,7,'Bài 1: Giới thiệu về trồng trọt',[
  [1,'Trồng trọt là gì?','Lĩnh vực sản xuất cung cấp lương thực, thực phẩm từ cây trồng','Nuôi cá','Chăn nuôi gia súc','Khai thác gỗ'],
  [1,'Vai trò của trồng trọt là gì?','Cung cấp lương thực, thực phẩm, nguyên liệu, thức ăn chăn nuôi, xuất khẩu','Chỉ để làm cảnh','Không có vai trò','Chỉ gây ô nhiễm'],
  [2,'Nhóm cây lương thực gồm những cây nào?','Lúa, ngô, khoai, sắn','Hoa hồng, cúc','Cà phê, cao su','Keo, bạch đàn'],
  [2,'Cây công nghiệp gồm những cây nào?','Cà phê, cao su, chè, hồ tiêu','Lúa, ngô','Rau cải','Hoa cúc'],
  [2,'Một số phương thức trồng trọt phổ biến hiện nay là gì?','Trồng ngoài trời và trồng trong nhà có mái che','Chỉ trồng dưới nước','Chỉ trồng trong hang','Không có phương thức nào'],
  [3,'Nêu vai trò của trồng trọt đối với đời sống và nền kinh tế.','Cung cấp lương thực, thực phẩm cho con người; nguyên liệu cho công nghiệp; thức ăn cho chăn nuôi; nông sản xuất khẩu; tạo việc làm và thu nhập.'],
  [3,'Kể tên các nhóm cây trồng chính và ví dụ.','Cây lương thực (lúa, ngô, khoai); cây ăn quả (xoài, cam); cây rau (cải, cà chua); cây công nghiệp (cà phê, cao su); cây hoa, cây cảnh.'],
  [4,'Vì sao trồng trọt được coi là ngành sản xuất quan trọng ở nước ta?','Việt Nam là nước nông nghiệp, trồng trọt cung cấp lương thực bảo đảm an ninh lương thực, nguyên liệu cho công nghiệp, nông sản xuất khẩu đem lại nguồn thu lớn, tạo việc làm cho nhiều người dân — nên có vai trò quan trọng về kinh tế và đời sống.']
 ]);
 add(M,7,'Bài 2: Làm đất trồng cây',[
  [1,'Làm đất trồng cây nhằm mục đích gì?','Làm đất tơi xốp, thoáng khí, sạch cỏ dại, giữ nước và dinh dưỡng','Làm đất chai cứng','Làm mất dinh dưỡng','Không có mục đích'],
  [1,'Các công việc làm đất gồm những gì?','Cày, bừa (hoặc xới), lên luống','Chỉ tưới nước','Chỉ gieo hạt','Chỉ thu hoạch'],
  [2,'Cày đất có tác dụng gì?','Làm đất tơi xốp, lật đất, vùi cỏ dại','Nén chặt đất','Làm đất khô cằn','Không tác dụng'],
  [2,'Lên luống (lên liếp) nhằm mục đích gì?','Dễ chăm sóc, thoát nước, tránh ngập úng cho cây','Làm đất xấu đi','Giữ cỏ dại','Không cần thiết'],
  [2,'Bón lót là bón phân vào thời điểm nào?','Trước khi gieo trồng','Sau khi thu hoạch','Khi cây đã già','Không bao giờ bón'],
  [3,'Nêu các bước làm đất trồng cây và tác dụng.','Cày (làm tơi, lật đất, vùi cỏ); bừa hoặc xới (làm nhỏ, san phẳng đất); lên luống (dễ chăm sóc, thoát nước). Giúp đất tơi xốp, thoáng khí, sạch cỏ, thuận lợi cho cây phát triển.'],
  [3,'Phân biệt bón lót và bón thúc.','Bón lót: bón trước khi gieo trồng để cung cấp dinh dưỡng sẵn cho cây. Bón thúc: bón trong quá trình cây sinh trưởng để kịp thời cung cấp dinh dưỡng cho cây phát triển.'],
  [4,'Vì sao làm đất kĩ trước khi trồng lại giúp cây sinh trưởng tốt hơn?','Đất được cày, bừa, lên luống trở nên tơi xốp, thoáng khí, sạch cỏ dại, giữ và thoát nước tốt, giàu dinh dưỡng; nhờ đó rễ cây dễ phát triển, hút nước và dinh dưỡng thuận lợi, cây khỏe, cho năng suất cao hơn.']
 ]);
 add(M,7,'Bài 3: Gieo trồng, chăm sóc và phòng trừ sâu, bệnh cho cây trồng',[
  [1,'Có những hình thức gieo trồng nào?','Gieo bằng hạt và trồng bằng cây con','Chỉ gieo hạt','Chỉ trồng cây con','Không có hình thức nào'],
  [1,'Công việc chăm sóc cây trồng gồm những gì?','Tưới nước, bón phân, làm cỏ, vun xới, phòng trừ sâu bệnh','Chỉ tưới nước','Chỉ bón phân','Không làm gì'],
  [2,'Mục đích của việc tỉa, dặm cây là gì?','Bảo đảm mật độ cây hợp lí','Làm cây chết','Giữ cỏ dại','Không có mục đích'],
  [2,'Biện pháp phòng trừ sâu bệnh an toàn, thân thiện môi trường là gì?','Biện pháp sinh học (dùng thiên địch), canh tác, thủ công','Phun nhiều thuốc hóa học','Đốt cả ruộng','Bỏ mặc cây'],
  [2,'Vì sao nên hạn chế dùng thuốc hóa học bảo vệ thực vật?','Vì gây ô nhiễm môi trường, hại sức khỏe, tồn dư trong nông sản','Vì thuốc rất rẻ','Vì không có hại','Vì giúp đất tốt hơn'],
  [3,'Nêu các công việc chăm sóc cây trồng.','Tưới, tiêu nước hợp lí; bón phân thúc; làm cỏ, vun xới; tỉa, dặm cây bảo đảm mật độ; phòng trừ sâu, bệnh.'],
  [3,'Nêu các biện pháp phòng trừ sâu, bệnh hại cây trồng.','Biện pháp canh tác (luân canh, vệ sinh đồng ruộng); thủ công (bắt sâu, ngắt lá bệnh); sinh học (dùng thiên địch, chế phẩm sinh học); hóa học (khi cần, đúng cách, an toàn).'],
  [4,'Vì sao nên ưu tiên biện pháp phòng trừ sâu bệnh tổng hợp và sinh học?','Vì vừa hiệu quả vừa an toàn: hạn chế thuốc hóa học nên giảm ô nhiễm môi trường, bảo vệ thiên địch, không tồn dư độc hại trong nông sản, bảo vệ sức khỏe người sản xuất và tiêu dùng, hướng tới nông nghiệp bền vững.']
 ]);
 add(M,7,'Bài 4: Thu hoạch sản phẩm trồng trọt',[
  [1,'Thu hoạch đúng thời điểm nhằm mục đích gì?','Bảo đảm năng suất, chất lượng nông sản tốt nhất','Làm giảm chất lượng','Để nông sản hỏng','Không có mục đích'],
  [1,'Các phương pháp thu hoạch gồm những gì?','Hái, cắt, nhổ, đào tùy loại cây','Chỉ đốt','Chỉ phun thuốc','Chỉ tưới nước'],
  [2,'Thu hoạch củ (khoai, sắn) thường dùng cách nào?','Đào','Hái trên cao','Cắt ngọn','Nhổ lá'],
  [2,'Nếu thu hoạch quá muộn thì nông sản thường thế nào?','Giảm chất lượng, dễ hỏng, hao hụt','Tốt hơn','Không ảnh hưởng','Năng suất cao hơn'],
  [2,'Sau khi thu hoạch, để giữ chất lượng nông sản cần làm gì?','Bảo quản đúng cách (làm khô, làm mát, đóng gói)','Để phơi mưa nắng','Chất đống ẩm ướt','Không cần bảo quản'],
  [3,'Nêu một số phương pháp thu hoạch và ví dụ loại cây.','Hái (quả: cam, xoài); cắt (lúa, rau); nhổ (lạc, rau cải); đào (khoai, sắn, củ). Chọn phương pháp phù hợp để ít hao hụt, giữ chất lượng.'],
  [3,'Vì sao cần thu hoạch nông sản đúng thời điểm (độ chín)?','Thu hoạch đúng độ chín bảo đảm năng suất cao nhất, chất lượng tốt (hương vị, dinh dưỡng), dễ bảo quản. Thu sớm nông sản chưa đạt, thu muộn dễ hỏng, rụng, giảm chất lượng và hao hụt.'],
  [4,'Vì sao bảo quản sau thu hoạch đúng cách lại quan trọng với người nông dân?','Nông sản dễ hư hỏng; bảo quản đúng (làm khô, làm mát, đóng gói) giúp giảm hao hụt, giữ chất lượng, kéo dài thời gian sử dụng và bán được giá tốt hơn, nhờ đó nâng cao thu nhập và tránh lãng phí công sức sản xuất.']
 ]);
 add(M,7,'Bài 5: Nhân giống vô tính cây trồng',[
  [1,'Nhân giống vô tính là gì?','Tạo cây mới từ một bộ phận của cây mẹ (không qua hạt)','Gieo bằng hạt','Trồng bằng củ giống từ hạt','Không tạo được cây mới'],
  [1,'Phương pháp nào là nhân giống vô tính?','Giâm cành, chiết cành, ghép cây','Gieo hạt','Trồng từ hạt','Thụ phấn'],
  [2,'Giâm cành là gì?','Cắt một đoạn cành cắm xuống đất ẩm cho ra rễ thành cây mới','Gieo hạt','Ghép mắt','Thụ phấn chéo'],
  [2,'Ưu điểm của nhân giống vô tính là gì?','Cây con giữ đặc tính tốt của cây mẹ, nhanh cho thu hoạch','Cây con khác hẳn cây mẹ','Lâu cho quả hơn','Luôn yếu hơn'],
  [2,'Chiết cành thường áp dụng cho loại cây nào?','Cây ăn quả (bưởi, nhãn, vải...)','Cây lúa','Cây ngô','Rau cải'],
  [3,'Kể tên các phương pháp nhân giống vô tính và nêu đặc điểm.','Giâm cành (cắm cành cho ra rễ); chiết cành (làm cành ra rễ ngay trên cây mẹ rồi cắt trồng); ghép (ghép mắt/cành của cây này lên gốc cây khác). Đều tạo cây giữ đặc tính cây mẹ.'],
  [3,'Nêu ưu điểm của nhân giống vô tính so với gieo hạt.','Cây con giữ nguyên đặc tính tốt của cây mẹ; nhanh ra hoa, cho quả sớm hơn; tạo được nhiều cây giống đồng đều. Phù hợp để duy trì giống tốt.'],
  [4,'Vì sao nhân giống vô tính giúp giữ được các đặc tính tốt của cây mẹ?','Vì cây con được tạo ra từ một bộ phận (cành, mắt) của cây mẹ, mang nguyên vật chất di truyền của cây mẹ, không qua kết hợp di truyền như gieo hạt; nhờ đó cây con giống hệt cây mẹ về đặc tính (năng suất, chất lượng quả).']
 ]);
 add(M,7,'Bài 6: Dự án trồng rau an toàn',[
  [1,'Rau an toàn là rau như thế nào?','Rau được trồng, chăm sóc bảo đảm vệ sinh, ít hoặc không tồn dư chất độc hại','Rau phun nhiều thuốc hóa học','Rau để lâu ngày','Rau mọc hoang'],
  [1,'Để trồng rau an toàn, cần chú ý điều gì?','Dùng phân bón, thuốc hợp lí, nước tưới sạch, đúng kĩ thuật','Phun thật nhiều thuốc','Tưới nước bẩn','Bón thật nhiều phân hóa học'],
  [2,'Nước tưới cho rau an toàn cần bảo đảm điều gì?','Nước sạch, không ô nhiễm','Nước thải','Nước ao tù bẩn','Nước nhiễm hóa chất'],
  [2,'Khi dùng thuốc bảo vệ thực vật cho rau, cần tuân thủ điều gì?','Đúng loại, đúng liều, bảo đảm thời gian cách li trước khi thu hoạch','Phun tùy ý','Thu hoạch ngay sau khi phun','Dùng thuốc cấm'],
  [2,'Ưu tiên biện pháp nào để rau an toàn, thân thiện môi trường?','Dùng phân hữu cơ, biện pháp sinh học','Chỉ dùng thuốc hóa học','Đốt đồng ruộng','Tưới nước thải'],
  [3,'Nêu các bước thực hiện dự án trồng một loại rau an toàn.','Chọn loại rau và chuẩn bị đất, giống; gieo trồng; chăm sóc (tưới nước sạch, bón phân hữu cơ, làm cỏ, phòng trừ sâu bệnh an toàn); thu hoạch đúng thời điểm, bảo đảm thời gian cách li.'],
  [3,'Nêu một số nguyên tắc để sản xuất rau an toàn.','Đất, nước tưới sạch; dùng phân bón (ưu tiên hữu cơ) và thuốc hợp lí, đúng quy định; bảo đảm thời gian cách li; thu hoạch, sơ chế vệ sinh; ghi chép quá trình.'],
  [4,'Vì sao trồng rau an toàn vừa bảo vệ sức khỏe vừa mang lại lợi ích kinh tế?','Rau an toàn không tồn dư chất độc hại nên bảo vệ sức khỏe người tiêu dùng và người sản xuất; sản phẩm sạch được tin dùng, bán được giá cao hơn, tạo uy tín và thu nhập ổn định; đồng thời giảm ô nhiễm môi trường, phát triển bền vững.']
 ]);
 add(M,7,'Bài 7: Giới thiệu về rừng',[
  [1,'Rừng là gì?','Hệ sinh thái gồm nhiều cây và sinh vật sống cùng nhau trên một vùng đất','Một cái ao','Một cánh đồng lúa','Một khu nhà'],
  [1,'Rừng có vai trò gì đối với môi trường?','Điều hòa khí hậu, giữ đất, giữ nước, cung cấp ô-xi','Gây ô nhiễm','Làm cạn nước','Không có vai trò'],
  [2,'Loại rừng nào trồng để khai thác gỗ, lâm sản?','Rừng sản xuất','Rừng phòng hộ duy nhất','Không có loại nào','Rừng chỉ để ngắm'],
  [2,'Rừng phòng hộ có vai trò chính là gì?','Chống xói mòn, lũ lụt, chắn gió, giữ nguồn nước','Chỉ lấy gỗ','Chỉ làm cảnh','Không có vai trò'],
  [2,'Rừng đặc dụng dùng để làm gì?','Bảo tồn thiên nhiên, nguồn gen, nghiên cứu, du lịch','Chỉ khai thác gỗ','Chỉ chăn thả gia súc','Chỉ làm nương rẫy'],
  [3,'Nêu vai trò của rừng đối với môi trường và đời sống.','Điều hòa khí hậu, cung cấp ô-xi, hấp thụ khí CO2; giữ đất, giữ nước, chống xói mòn, lũ lụt; bảo tồn đa dạng sinh học; cung cấp gỗ, lâm sản; phục vụ du lịch, nghiên cứu.'],
  [3,'Kể tên các loại rừng theo mục đích sử dụng.','Rừng sản xuất (khai thác gỗ, lâm sản); rừng phòng hộ (bảo vệ đất, nước, chắn gió, chống lũ); rừng đặc dụng (bảo tồn thiên nhiên, nguồn gen, nghiên cứu, du lịch).'],
  [4,'Vì sao bảo vệ rừng cũng chính là bảo vệ cuộc sống của con người?','Rừng điều hòa khí hậu, giữ đất, giữ nước, hạn chế lũ lụt, hạn hán, cung cấp ô-xi và tài nguyên; mất rừng gây thiên tai, biến đổi khí hậu, mất đa dạng sinh học, ảnh hưởng trực tiếp đến đời sống. Vì vậy bảo vệ rừng là bảo vệ chính con người.']
 ]);
 add(M,7,'Bài 8: Trồng, chăm sóc và bảo vệ rừng',[
  [1,'Công việc trồng rừng gồm những gì?','Chuẩn bị cây giống, đất, đào hố và trồng cây','Chỉ chặt cây','Chỉ đốt rừng','Không làm gì'],
  [1,'Chăm sóc rừng sau khi trồng gồm những việc nào?','Làm cỏ, vun xới, tưới, trồng dặm, phòng chống cháy','Chặt phá','Bỏ mặc','Đốt rừng'],
  [2,'Biện pháp nào giúp bảo vệ rừng?','Ngăn chặt phá, đốt rừng; phòng chống cháy; tuyên truyền','Chặt phá tự do','Đốt rừng làm nương','Săn bắt thú'],
  [2,'Vì sao phải phòng chống cháy rừng?','Cháy rừng gây mất rừng, thiệt hại lớn về tài nguyên, môi trường, sinh vật','Cháy rừng có lợi','Không ảnh hưởng gì','Giúp đất tốt lên'],
  [2,'Hành vi nào là phá hoại rừng?','Chặt phá, đốt rừng, săn bắt động vật trái phép','Trồng cây','Chăm sóc rừng','Tuyên truyền bảo vệ rừng'],
  [3,'Nêu các công việc chăm sóc rừng sau khi trồng.','Làm cỏ, vun xới quanh gốc; tưới nước khi cần; bón phân; trồng dặm cây chết; tỉa cành; phòng trừ sâu bệnh; phòng chống cháy và bảo vệ cây.'],
  [3,'Nêu các biện pháp bảo vệ rừng.','Trồng và phục hồi rừng; ngăn chặn chặt phá, đốt rừng, lấn chiếm đất rừng; phòng chống cháy rừng; chống săn bắt động vật; tuyên truyền nâng cao ý thức; thực thi pháp luật về bảo vệ rừng.'],
  [4,'Là học sinh, em có thể làm gì để góp phần bảo vệ rừng và cây xanh?','Trồng và chăm sóc cây; không bẻ cành, phá cây; tiết kiệm giấy, gỗ; không tiếp tay mua bán động vật hoang dã; tuyên truyền, nhắc nhở mọi người bảo vệ rừng; tham gia các hoạt động trồng cây, bảo vệ môi trường.']
 ]);
 add(M,7,'Bài 9: Giới thiệu về chăn nuôi',[
  [1,'Chăn nuôi là gì?','Lĩnh vực sản xuất nuôi vật nuôi để lấy sản phẩm (thịt, trứng, sữa...)','Trồng cây','Đánh bắt cá tự nhiên','Khai thác gỗ'],
  [1,'Vai trò của chăn nuôi là gì?','Cung cấp thực phẩm, nguyên liệu, phân bón, sức kéo, xuất khẩu','Chỉ gây ô nhiễm','Không có vai trò','Chỉ để làm cảnh'],
  [2,'Vật nuôi nào cung cấp trứng và thịt?','Gà, vịt','Cây lúa','Con cá rô tự nhiên','Cây ngô'],
  [2,'Vật nuôi nào cung cấp sữa?','Bò sữa','Con gà','Con cá','Con ong'],
  [2,'Phương thức chăn nuôi phổ biến gồm những hình thức nào?','Chăn nuôi nông hộ và chăn nuôi trang trại (công nghiệp)','Chỉ nuôi trong nhà bếp','Chỉ nuôi dưới nước','Không có hình thức nào'],
  [3,'Nêu vai trò của chăn nuôi đối với đời sống và kinh tế.','Cung cấp thực phẩm giàu đạm (thịt, trứng, sữa); nguyên liệu cho công nghiệp (da, lông); phân bón cho trồng trọt; sức kéo; sản phẩm xuất khẩu; tạo việc làm, thu nhập.'],
  [3,'Kể tên một số vật nuôi phổ biến và sản phẩm của chúng.','Gà, vịt (thịt, trứng); lợn, bò (thịt); bò sữa (sữa); ong (mật); trâu, bò (sức kéo, phân bón).'],
  [4,'Vì sao chăn nuôi và trồng trọt có mối quan hệ gắn bó, hỗ trợ nhau?','Trồng trọt cung cấp thức ăn (ngô, cám, rau) cho vật nuôi; chăn nuôi cung cấp phân bón hữu cơ và sức kéo cho trồng trọt. Hai ngành hỗ trợ nhau tạo nên sản xuất nông nghiệp khép kín, hiệu quả và bền vững.']
 ]);
 add(M,7,'Bài 10: Nuôi dưỡng và chăm sóc vật nuôi',[
  [1,'Nuôi dưỡng vật nuôi là gì?','Cho vật nuôi ăn, uống đầy đủ, hợp lí để sinh trưởng, phát triển','Bỏ đói vật nuôi','Chỉ cho uống nước','Không chăm sóc'],
  [1,'Chăm sóc vật nuôi gồm những việc gì?','Vệ sinh chuồng trại, tắm chải, theo dõi sức khỏe','Để chuồng bẩn','Bỏ mặc','Chỉ nhốt lại'],
  [2,'Thức ăn của vật nuôi cần bảo đảm điều gì?','Đủ chất dinh dưỡng, sạch, phù hợp từng loại vật nuôi','Ôi thiu','Thiếu chất','Không cần sạch'],
  [2,'Vì sao cần giữ chuồng trại sạch sẽ, thoáng mát?','Giúp vật nuôi khỏe mạnh, phòng tránh dịch bệnh','Để vật nuôi bệnh','Để tốn công','Không có lí do'],
  [2,'Vật nuôi non (con) cần được chăm sóc như thế nào?','Giữ ấm, cho ăn thức ăn dễ tiêu, đủ dinh dưỡng, phòng bệnh','Để lạnh','Cho ăn thức ăn ôi','Bỏ đói'],
  [3,'Nêu các công việc nuôi dưỡng và chăm sóc vật nuôi.','Cho ăn, uống đủ và hợp lí theo từng giai đoạn; vệ sinh chuồng trại sạch, thoáng; tắm chải, vận động; theo dõi sức khỏe; tiêm phòng, phòng trị bệnh.'],
  [3,'Vì sao cần cho vật nuôi ăn phù hợp với từng giai đoạn phát triển?','Mỗi giai đoạn (non, trưởng thành, sinh sản) có nhu cầu dinh dưỡng khác nhau; cho ăn phù hợp giúp vật nuôi sinh trưởng tốt, khỏe mạnh, cho năng suất cao và tiết kiệm thức ăn, tránh lãng phí.'],
  [4,'Vì sao chăm sóc, nuôi dưỡng tốt lại giúp nâng cao hiệu quả chăn nuôi?','Vật nuôi được ăn đủ chất, chuồng trại sạch, phòng bệnh tốt sẽ khỏe mạnh, lớn nhanh, ít bệnh, cho nhiều thịt, trứng, sữa chất lượng; nhờ đó giảm chi phí thuốc men, hao hụt và tăng năng suất, thu nhập cho người chăn nuôi.']
 ]);
 add(M,7,'Bài 11: Phòng và trị bệnh cho vật nuôi',[
  [1,'Phòng bệnh cho vật nuôi quan trọng như thế nào?','Phòng bệnh hơn chữa bệnh, giúp vật nuôi khỏe, giảm thiệt hại','Không quan trọng','Chỉ cần chữa khi bệnh nặng','Để vật nuôi tự khỏi'],
  [1,'Biện pháp phòng bệnh cho vật nuôi gồm những gì?','Vệ sinh chuồng trại, tiêm phòng, nuôi dưỡng tốt','Để chuồng bẩn','Không tiêm phòng','Cho ăn thức ăn ôi'],
  [2,'Tiêm vắc-xin cho vật nuôi nhằm mục đích gì?','Tạo khả năng miễn dịch, phòng bệnh','Gây bệnh','Làm vật nuôi yếu đi','Không tác dụng'],
  [2,'Khi phát hiện vật nuôi bị bệnh, cần làm gì?','Cách li, báo thú y, điều trị theo hướng dẫn','Để chung đàn','Giấu đi','Bán ngay cho người khác'],
  [2,'Vì sao cần cách li vật nuôi bị bệnh?','Tránh lây lan bệnh sang con khác trong đàn','Để bệnh nặng hơn','Không có lí do','Cho đẹp chuồng'],
  [3,'Nêu các biện pháp phòng bệnh cho vật nuôi.','Vệ sinh, khử trùng chuồng trại; cho ăn uống đủ chất, sạch; tiêm phòng vắc-xin đầy đủ; cách li vật nuôi mới và vật nuôi bệnh; theo dõi sức khỏe thường xuyên.'],
  [3,'Vì sao nói "phòng bệnh hơn chữa bệnh" trong chăn nuôi?','Phòng bệnh giúp vật nuôi khỏe mạnh, không mắc bệnh, không lây lan, tiết kiệm chi phí thuốc men và tránh thiệt hại do chết, giảm năng suất. Khi đã bệnh, chữa trị tốn kém, hiệu quả không chắc chắn và dễ lây cả đàn.'],
  [4,'Vì sao vệ sinh chuồng trại và tiêm phòng là biện pháp phòng bệnh hiệu quả nhất?','Vệ sinh, khử trùng loại bỏ mầm bệnh trong môi trường sống; tiêm phòng tạo miễn dịch chủ động giúp vật nuôi chống lại bệnh nguy hiểm. Kết hợp hai biện pháp giảm tối đa nguy cơ phát sinh và lây lan dịch bệnh, bảo vệ cả đàn.']
 ]);
 add(M,7,'Bài 12: Chăn nuôi gà thịt trong nông hộ',[
  [1,'Nuôi gà thịt trong nông hộ nhằm mục đích gì?','Cung cấp thịt, tăng thu nhập cho gia đình','Chỉ để làm cảnh','Không có mục đích','Để nghe gáy'],
  [1,'Chuồng nuôi gà cần bảo đảm điều gì?','Khô ráo, thoáng mát, sạch sẽ, ấm về mùa đông','Ẩm ướt, bẩn','Kín gió hoàn toàn','Chật chội'],
  [2,'Thức ăn cho gà thịt cần đủ chất gì để nhanh lớn?','Đủ đạm, bột đường, vi-ta-min, chất khoáng','Chỉ nước','Chỉ rau','Thức ăn ôi thiu'],
  [2,'Để gà ít bệnh, cần làm gì?','Vệ sinh chuồng, tiêm phòng, cho ăn sạch','Để chuồng bẩn','Không tiêm phòng','Nuôi quá chật'],
  [2,'Gà con mới nở cần được chăm sóc thế nào?','Giữ ấm (sưởi), cho ăn uống sạch, đủ dinh dưỡng','Để lạnh','Bỏ đói','Nuôi ngoài mưa'],
  [3,'Nêu các công việc chính khi nuôi gà thịt trong nông hộ.','Chuẩn bị chuồng trại sạch, thoáng; chọn giống gà tốt; cho ăn đủ chất theo từng giai đoạn; vệ sinh, tiêm phòng; theo dõi sức khỏe; xuất bán đúng thời điểm.'],
  [3,'Nêu một số lưu ý để nuôi gà thịt đạt hiệu quả.','Chọn giống khỏe; mật độ nuôi hợp lí; chuồng sạch, ấm, thoáng; thức ăn đủ chất, nước sạch; tiêm phòng đầy đủ; phòng bệnh; ghi chép chi phí, theo dõi tăng trọng.'],
  [4,'Vì sao chăn nuôi gà thịt phù hợp và mang lại hiệu quả cho nhiều hộ gia đình nông thôn?','Vì vốn đầu tư không quá lớn, tận dụng được thức ăn sẵn có và lao động gia đình, chuồng trại đơn giản, gà nhanh lớn, quay vòng vốn nhanh, dễ tiêu thụ; nhờ đó tạo thêm thu nhập, cải thiện đời sống cho hộ nông thôn.']
 ]);
 add(M,7,'Bài 13: Thực hành. Lập kế hoạch nuôi vật nuôi trong gia đình',[
  [1,'Lập kế hoạch nuôi vật nuôi giúp ích gì?','Chủ động về giống, thức ăn, chi phí và chăm sóc','Gây lãng phí','Không cần thiết','Làm rối việc'],
  [1,'Khi lập kế hoạch, cần xác định điều gì đầu tiên?','Nuôi con gì, số lượng bao nhiêu, mục đích','Màu chuồng','Tên vật nuôi','Giá vàng'],
  [2,'Yếu tố kinh tế cần tính trong kế hoạch chăn nuôi là gì?','Chi phí giống, thức ăn, thuốc và dự kiến thu nhập','Không cần tính','Chỉ cần nhiều vật nuôi','Mua càng đắt càng tốt'],
  [2,'Để nuôi hiệu quả, nên chọn vật nuôi như thế nào?','Phù hợp điều kiện gia đình (vốn, chuồng, thức ăn, thị trường)','Chọn con đắt nhất','Chọn ngẫu nhiên','Chọn con khó nuôi nhất'],
  [2,'Trong kế hoạch, cần dự kiến công việc chăm sóc nào?','Cho ăn, vệ sinh, tiêm phòng, theo dõi sức khỏe','Chỉ cho ăn một lần','Không chăm sóc','Bỏ mặc'],
  [3,'Nêu các bước lập kế hoạch nuôi một vật nuôi trong gia đình.','Xác định mục đích, chọn con nuôi và số lượng; chuẩn bị chuồng trại, giống, thức ăn; dự kiến chi phí và thu nhập; lên lịch chăm sóc, vệ sinh, tiêm phòng; theo dõi và đánh giá.'],
  [3,'Vì sao cần dự kiến chi phí và thu nhập khi lập kế hoạch chăn nuôi?','Để biết cần bao nhiêu vốn, có lãi hay không, tránh thua lỗ; từ đó quyết định quy mô nuôi hợp lí, chủ động tài chính và nâng cao hiệu quả kinh tế.'],
  [4,'Vì sao lập kế hoạch trước khi nuôi giúp chăn nuôi hiệu quả và tránh rủi ro?','Kế hoạch giúp chuẩn bị đầy đủ giống, chuồng trại, thức ăn, vốn và lịch chăm sóc, phòng bệnh; chủ động ứng phó khó khăn; tính được hiệu quả kinh tế, tránh nuôi tự phát dẫn đến thiếu chuẩn bị, dịch bệnh, thua lỗ.']
 ]);
 add(M,7,'Bài 14: Giới thiệu về thủy sản',[
  [1,'Thủy sản là gì?','Các động, thực vật sống dưới nước được nuôi, khai thác (cá, tôm, cua...)','Cây trồng trên cạn','Gia súc','Gia cầm'],
  [1,'Vai trò của ngành thủy sản là gì?','Cung cấp thực phẩm giàu đạm, nguyên liệu, xuất khẩu, tạo việc làm','Chỉ gây ô nhiễm','Không có vai trò','Chỉ để làm cảnh'],
  [2,'Loài nào là thủy sản nước ngọt?','Cá chép, cá rô, tôm càng xanh','Cá biển','San hô','Cây lúa'],
  [2,'Nước ta có điều kiện thuận lợi gì để phát triển thủy sản?','Nhiều sông, hồ, ao, bờ biển dài','Toàn sa mạc','Không có nước','Khí hậu quá lạnh'],
  [2,'Hình thức nuôi thủy sản phổ biến là gì?','Nuôi trong ao, lồng bè, đầm','Nuôi trên cây','Nuôi trong nhà bếp','Nuôi dưới lòng đất'],
  [3,'Nêu vai trò của ngành thủy sản đối với đời sống và kinh tế.','Cung cấp thực phẩm giàu đạm (cá, tôm, cua); nguyên liệu cho chế biến; sản phẩm xuất khẩu đem lại nguồn thu lớn; tạo việc làm; tận dụng diện tích mặt nước.'],
  [3,'Nêu những điều kiện thuận lợi để nước ta phát triển thủy sản.','Bờ biển dài, vùng biển rộng; nhiều sông, hồ, ao, đầm; khí hậu nhiệt đới phù hợp nhiều loài; nguồn lao động dồi dào; nhu cầu thị trường trong và ngoài nước lớn.'],
  [4,'Vì sao phát triển thủy sản cần đi đôi với bảo vệ môi trường nước và nguồn lợi thủy sản?','Nếu khai thác quá mức, dùng cách hủy diệt hoặc xả thải gây ô nhiễm sẽ làm cạn kiệt nguồn lợi, chết thủy sản, mất cân bằng sinh thái. Phát triển bền vững đòi hỏi nuôi và khai thác hợp lí, bảo vệ môi trường nước để duy trì nguồn lợi lâu dài.']
 ]);
 add(M,7,'Bài 15: Nuôi cá ao',[
  [1,'Ao nuôi cá cần bảo đảm điều gì?','Nguồn nước sạch, đủ, dễ cấp thoát; bờ ao chắc chắn','Nước bẩn, ô nhiễm','Không có nước','Bờ ao sạt lở'],
  [1,'Trước khi thả cá, cần chuẩn bị ao như thế nào?','Tát cạn, vệ sinh, bón vôi, phơi đáy, lấy nước sạch','Thả cá ngay vào ao bẩn','Không chuẩn bị','Đổ rác xuống ao'],
  [2,'Thức ăn cho cá nuôi gồm những loại nào?','Thức ăn tự nhiên và thức ăn bổ sung (cám, thức ăn công nghiệp)','Chỉ đất','Chỉ đá','Rác thải'],
  [2,'Vì sao cần bón vôi và phơi đáy ao trước khi thả cá?','Diệt mầm bệnh, cải tạo đáy ao, ổn định môi trường nước','Làm ao bẩn hơn','Gây bệnh cho cá','Không có lí do'],
  [2,'Khi nuôi cá, cần theo dõi điều gì?','Màu nước, lượng thức ăn, sức khỏe và sự phát triển của cá','Không cần theo dõi','Chỉ nhìn một lần','Bỏ mặc ao'],
  [3,'Nêu các bước chuẩn bị ao và nuôi cá.','Chuẩn bị ao (tát cạn, vệ sinh, bón vôi, phơi đáy, cấp nước sạch); chọn và thả cá giống khỏe, đúng mật độ; cho ăn, chăm sóc, quản lí nước; phòng bệnh; thu hoạch.'],
  [3,'Nêu một số biện pháp để nuôi cá ao đạt năng suất cao.','Cải tạo ao kĩ; chọn giống tốt, thả đúng mật độ; cho ăn đủ, hợp lí; quản lí chất lượng nước (thay nước, kiểm tra); phòng bệnh; ghép nuôi các loài hợp lí.'],
  [4,'Vì sao quản lí tốt chất lượng nước là yếu tố quan trọng khi nuôi cá ao?','Nước là môi trường sống của cá; nước sạch, đủ ô-xi, không ô nhiễm giúp cá khỏe, lớn nhanh, ít bệnh. Nước bẩn, thiếu ô-xi làm cá chậm lớn, dễ bệnh, chết hàng loạt. Vì vậy quản lí nước quyết định thành công của nuôi cá.']
 ]);
 add(M,7,'Bài 16: Thực hành. Lập kế hoạch nuôi cá cảnh',[
  [1,'Nuôi cá cảnh nhằm mục đích gì?','Làm đẹp không gian, thư giãn, giải trí','Lấy thịt','Lấy sức kéo','Lấy trứng bán'],
  [1,'Khi lập kế hoạch nuôi cá cảnh, cần xác định điều gì?','Loại cá, bể/chậu, thức ăn, cách chăm sóc và chi phí','Màu tường nhà','Giá vàng','Tên hàng xóm'],
  [2,'Bể nuôi cá cảnh cần bảo đảm điều gì?','Nước sạch, đủ ô-xi, ánh sáng phù hợp, kích thước hợp số lượng cá','Nước bẩn','Quá chật cá','Không có nước'],
  [2,'Để cá cảnh khỏe, cần chăm sóc thế nào?','Cho ăn vừa đủ, thay nước định kì, giữ bể sạch','Cho ăn thật nhiều','Không thay nước','Để bể bẩn'],
  [2,'Vì sao không nên cho cá cảnh ăn quá nhiều?','Thức ăn thừa làm bẩn nước, cá dễ bệnh','Giúp cá lớn nhanh vô hại','Không ảnh hưởng','Làm nước sạch hơn'],
  [3,'Nêu các bước lập kế hoạch nuôi cá cảnh.','Chọn loại cá cảnh phù hợp; chuẩn bị bể, thiết bị (lọc, sục khí, đèn); dự kiến chi phí; lên lịch cho ăn, thay nước, vệ sinh; theo dõi sức khỏe cá.'],
  [3,'Nêu một số lưu ý để nuôi cá cảnh khỏe, đẹp.','Chọn cá khỏe; mật độ hợp lí; nước sạch, đủ ô-xi; cho ăn vừa đủ; thay nước định kì; giữ nhiệt độ, ánh sáng phù hợp; theo dõi và cách li cá bệnh.'],
  [4,'Vì sao nuôi cá cảnh vừa là thú vui vừa giúp rèn tính kiên nhẫn, trách nhiệm?','Nuôi cá cảnh mang lại thư giãn, làm đẹp không gian; đồng thời đòi hỏi chăm sóc đều đặn (cho ăn, thay nước, theo dõi), quan sát tỉ mỉ; qua đó rèn tính kiên nhẫn, cẩn thận và tinh thần trách nhiệm với sinh vật mình nuôi.']
 ]);
 /* L7: bù lẻ các bài */
 add(M,7,'Bài 12: Chăn nuôi gà thịt trong nông hộ',[
  [3,'Vì sao cần giữ chuồng gà khô ráo, thoáng, sạch?','Giúp gà khỏe mạnh, hạn chế vi khuẩn, kí sinh trùng và dịch bệnh; gà ăn tốt, lớn nhanh, giảm hao hụt.']
 ]);
 add(M,7,'Bài 16: Thực hành. Lập kế hoạch nuôi cá cảnh',[
  [3,'Vì sao cần thay nước định kì cho bể cá cảnh?','Để loại bỏ chất thải, thức ăn thừa làm bẩn nước; giữ nước sạch, đủ ô-xi giúp cá khỏe, đẹp, ít bệnh.']
 ]);

 /* Chủ đề tổng hợp L7 */
 add(M,7,'Trồng trọt, chăn nuôi',[
  [1,'Vai trò của trồng trọt là gì?','Cung cấp lương thực, thực phẩm, nguyên liệu, thức ăn chăn nuôi','Chỉ làm cảnh','Không có vai trò','Chỉ gây hại'],
  [2,'Phương pháp nào là nhân giống vô tính cây trồng?','Giâm, chiết, ghép','Gieo hạt','Thụ phấn','Trồng từ hạt'],
  [2,'Vì sao "phòng bệnh hơn chữa bệnh" trong chăn nuôi?','Phòng bệnh giúp vật nuôi khỏe, tránh thiệt hại, tiết kiệm chi phí','Chữa bệnh luôn tốt hơn','Không cần phòng bệnh','Để vật nuôi tự khỏi'],
  [3,'Nêu mối quan hệ hỗ trợ giữa trồng trọt và chăn nuôi.','Trồng trọt cung cấp thức ăn cho vật nuôi; chăn nuôi cung cấp phân bón hữu cơ và sức kéo cho trồng trọt. Hai ngành gắn bó tạo nên nông nghiệp khép kín, bền vững.'],
  [4,'Vì sao ứng dụng kĩ thuật và phòng bệnh tốt giúp nâng cao hiệu quả sản xuất nông nghiệp?','Kĩ thuật đúng (làm đất, giống tốt, chăm sóc, nhân giống) cho năng suất cao; phòng bệnh cho cây trồng, vật nuôi giảm thiệt hại, hao hụt. Nhờ đó sản lượng, chất lượng tăng, chi phí giảm, nâng cao thu nhập và phát triển bền vững.']
 ]);
 add(M,7,'Lâm nghiệp, thủy sản',[
  [1,'Rừng phòng hộ có vai trò chính là gì?','Chống xói mòn, lũ lụt, chắn gió, giữ nguồn nước','Chỉ lấy gỗ','Chỉ làm cảnh','Không có vai trò'],
  [2,'Loài nào là thủy sản nước ngọt?','Cá chép, cá rô','Cá biển','San hô','Cây lúa'],
  [2,'Hành vi nào phá hoại rừng?','Chặt phá, đốt rừng, săn bắt trái phép','Trồng cây','Chăm sóc rừng','Tuyên truyền bảo vệ rừng'],
  [3,'Nêu vai trò của rừng và của ngành thủy sản.','Rừng: điều hòa khí hậu, giữ đất, giữ nước, chống lũ, cung cấp gỗ, bảo tồn sinh vật. Thủy sản: cung cấp thực phẩm giàu đạm, nguyên liệu, xuất khẩu, tạo việc làm.'],
  [4,'Vì sao phát triển lâm nghiệp và thủy sản cần gắn với bảo vệ môi trường?','Rừng và nguồn nước là tài nguyên có hạn; khai thác quá mức, hủy diệt hoặc gây ô nhiễm sẽ làm cạn kiệt, mất cân bằng sinh thái, gây thiên tai. Phát triển bền vững đòi hỏi khai thác hợp lí đi đôi trồng, nuôi, bảo vệ để duy trì lâu dài.']
 ]);
 add(M,7,'Rừng và thủy sản – kĩ thuật',[
  [1,'Trước khi thả cá, cần chuẩn bị ao thế nào?','Tát cạn, vệ sinh, bón vôi, phơi đáy, lấy nước sạch','Thả cá vào ao bẩn ngay','Không chuẩn bị','Đổ rác xuống ao'],
  [2,'Chăm sóc rừng sau khi trồng gồm việc gì?','Làm cỏ, vun xới, tưới, trồng dặm, phòng chống cháy','Chặt phá','Đốt rừng','Bỏ mặc'],
  [2,'Vì sao cần quản lí tốt chất lượng nước khi nuôi cá?','Nước sạch, đủ ô-xi giúp cá khỏe, lớn nhanh, ít bệnh','Nước bẩn tốt hơn','Không cần quản lí','Để cá tự lo'],
  [3,'Nêu các biện pháp bảo vệ rừng và nguồn lợi thủy sản.','Rừng: trồng, chăm sóc, chống chặt phá, đốt, phòng cháy. Thủy sản: nuôi và khai thác hợp lí, không dùng cách hủy diệt, bảo vệ môi trường nước, không xả thải ô nhiễm.'],
  [4,'Vì sao áp dụng đúng kĩ thuật trong trồng rừng và nuôi thủy sản lại quan trọng?','Kĩ thuật đúng (chuẩn bị đất/ao, chọn giống, chăm sóc, phòng bệnh, quản lí môi trường) giúp cây rừng và thủy sản sinh trưởng tốt, năng suất cao, giảm rủi ro dịch bệnh và thiệt hại; đồng thời bảo vệ môi trường, phát triển bền vững.']
 ]);
 add(M,7,'Trồng và chăm sóc cây trồng',[
  [1,'Làm đất trồng cây nhằm mục đích gì?','Làm đất tơi xốp, thoáng, sạch cỏ, giữ nước và dinh dưỡng','Làm đất chai cứng','Làm mất dinh dưỡng','Không có mục đích'],
  [2,'Công việc chăm sóc cây trồng gồm những gì?','Tưới nước, bón phân, làm cỏ, vun xới, phòng trừ sâu bệnh','Chỉ tưới nước','Chỉ bón phân','Không làm gì'],
  [2,'Vì sao nên hạn chế dùng thuốc hóa học bảo vệ thực vật?','Gây ô nhiễm, hại sức khỏe, tồn dư trong nông sản','Thuốc rẻ','Không có hại','Làm đất tốt hơn'],
  [3,'Nêu các bước làm đất và chăm sóc cây trồng.','Làm đất: cày, bừa/xới, lên luống, bón lót. Chăm sóc: tưới tiêu, bón thúc, làm cỏ, vun xới, tỉa dặm, phòng trừ sâu bệnh (ưu tiên biện pháp an toàn).'],
  [4,'Vì sao áp dụng biện pháp phòng trừ sâu bệnh tổng hợp giúp nông nghiệp bền vững?','Kết hợp canh tác, thủ công, sinh học và chỉ dùng hóa học khi cần, đúng cách; nhờ đó hạn chế thuốc hóa học, giảm ô nhiễm, bảo vệ thiên địch và sức khỏe, nông sản an toàn — vừa hiệu quả vừa thân thiện môi trường, hướng tới sản xuất bền vững.']
 ]);

 /* L7: bù lẻ chủ đề tổng hợp */
 add(M,7,'Trồng trọt, chăn nuôi',[
  [3,'Nêu vai trò của chăn nuôi đối với đời sống và kinh tế.','Cung cấp thực phẩm giàu đạm (thịt, trứng, sữa); nguyên liệu công nghiệp; phân bón cho trồng trọt; sức kéo; sản phẩm xuất khẩu; tạo việc làm, thu nhập.']
 ]);
 add(M,7,'Lâm nghiệp, thủy sản',[
  [1,'Thủy sản là gì?','Các động, thực vật sống dưới nước được nuôi, khai thác (cá, tôm, cua...)','Cây trên cạn','Gia súc','Gia cầm'],
  [3,'Vì sao bảo vệ rừng chính là bảo vệ cuộc sống con người?','Rừng điều hòa khí hậu, giữ đất, giữ nước, hạn chế lũ lụt, hạn hán, cung cấp ô-xi và tài nguyên; mất rừng gây thiên tai, biến đổi khí hậu, ảnh hưởng trực tiếp đến đời sống.']
 ]);
 add(M,7,'Rừng và thủy sản – kĩ thuật',[
  [3,'Vì sao cần bón vôi và phơi đáy ao trước khi thả cá?','Để diệt mầm bệnh, cải tạo đáy ao, ổn định môi trường nước, giúp cá khỏe, ít bệnh.']
 ]);
 add(M,7,'Trồng và chăm sóc cây trồng',[
  [1,'Bón lót là bón phân vào thời điểm nào?','Trước khi gieo trồng','Sau khi thu hoạch','Khi cây đã già','Không bao giờ bón'],
  [3,'Nêu các biện pháp phòng trừ sâu, bệnh hại cây trồng.','Canh tác (luân canh, vệ sinh đồng ruộng); thủ công (bắt sâu, ngắt lá bệnh); sinh học (thiên địch, chế phẩm sinh học); hóa học khi cần, đúng cách, an toàn.']
 ]);

 /* ===================== LỚP 8 ===================== */
 add(M,8,'Bài 1: Một số tiêu chuẩn trình bày bản vẽ kĩ thuật',[
  [1,'Bản vẽ kĩ thuật dùng để làm gì?','Trình bày hình dạng, kích thước, yêu cầu kĩ thuật của sản phẩm','Vẽ tranh nghệ thuật','Ghi nhật kí','Chép bài'],
  [1,'Khổ giấy A4 có kích thước bao nhiêu?','210 x 297 mm','100 x 200 mm','300 x 400 mm','50 x 70 mm'],
  [2,'Nét liền đậm trên bản vẽ dùng để vẽ gì?','Đường bao thấy (cạnh thấy)','Đường khuất','Đường tâm','Đường kích thước nhỏ'],
  [2,'Nét đứt (nét khuất) dùng để thể hiện gì?','Đường bao khuất (không nhìn thấy)','Cạnh thấy','Khung tên','Tiêu đề'],
  [2,'Khung tên trên bản vẽ ghi những thông tin gì?','Tên sản phẩm, vật liệu, tỉ lệ, người vẽ...','Bài hát','Thời tiết','Điểm số'],
  [3,'Nêu một số tiêu chuẩn trình bày bản vẽ kĩ thuật.','Khổ giấy (A0–A4); tỉ lệ; các loại nét vẽ (liền đậm, nét đứt, nét chấm gạch); chữ và số; ghi kích thước; khung bản vẽ và khung tên.'],
  [3,'Nêu công dụng của các loại nét vẽ cơ bản.','Nét liền đậm: đường bao thấy. Nét đứt: đường bao khuất. Nét chấm gạch mảnh: đường tâm, trục đối xứng. Nét liền mảnh: đường kích thước, đường gióng.'],
  [4,'Vì sao bản vẽ kĩ thuật phải tuân theo các tiêu chuẩn thống nhất?','Để mọi người (người thiết kế, người chế tạo, người sử dụng) đều hiểu bản vẽ giống nhau, chính xác; nhờ đó trao đổi thông tin kĩ thuật thuận lợi, sản phẩm được chế tạo đúng yêu cầu. Nếu mỗi người vẽ một kiểu sẽ gây hiểu nhầm, sai sót.']
 ]);
 add(M,8,'Bài 2: Hình chiếu vuông góc',[
  [1,'Phép chiếu vuông góc cho ta hình chiếu như thế nào?','Hình chiếu của vật thể lên mặt phẳng, các tia chiếu vuông góc mặt phẳng','Hình phối cảnh','Ảnh chụp','Hình bóng mờ'],
  [1,'Có mấy hình chiếu vuông góc cơ bản của vật thể?','Ba: hình chiếu đứng, bằng, cạnh','Một','Hai','Năm'],
  [2,'Hình chiếu đứng thể hiện mặt nào của vật thể?','Mặt trước','Mặt trên','Mặt bên','Mặt đáy'],
  [2,'Hình chiếu bằng thể hiện mặt nào của vật thể?','Mặt trên (nhìn từ trên xuống)','Mặt trước','Mặt bên','Mặt sau'],
  [2,'Hình chiếu cạnh thể hiện mặt nào?','Mặt bên (nhìn từ trái sang)','Mặt trước','Mặt trên','Mặt đáy'],
  [3,'Kể tên ba hình chiếu vuông góc và hướng chiếu tương ứng.','Hình chiếu đứng (chiếu từ trước tới); hình chiếu bằng (chiếu từ trên xuống); hình chiếu cạnh (chiếu từ trái sang). Ba hình biểu diễn đầy đủ vật thể.'],
  [3,'Vì sao cần ba hình chiếu để biểu diễn một vật thể?','Một hình chiếu chỉ thể hiện một mặt, không đủ hình dạng, kích thước; ba hình chiếu (đứng, bằng, cạnh) bổ sung cho nhau, giúp thể hiện đầy đủ, chính xác hình dạng vật thể trong không gian.'],
  [4,'Vì sao phương pháp hình chiếu vuông góc được dùng phổ biến trong bản vẽ kĩ thuật?','Vì nó biểu diễn chính xác hình dạng, kích thước thật của vật thể trên mặt phẳng (không bị biến dạng như hình phối cảnh); dễ ghi kích thước và chế tạo theo. Nhờ đó người đọc bản vẽ hiểu và làm ra sản phẩm đúng yêu cầu.']
 ]);
 add(M,8,'Bài 3: Bản vẽ chi tiết',[
  [1,'Bản vẽ chi tiết dùng để làm gì?','Thể hiện hình dạng, kích thước, yêu cầu kĩ thuật của một chi tiết để chế tạo','Vẽ cả ngôi nhà','Ghi nhật kí','Vẽ tranh'],
  [1,'Bản vẽ chi tiết gồm những nội dung chính nào?','Hình biểu diễn, kích thước, yêu cầu kĩ thuật, khung tên','Chỉ có hình','Chỉ có tên','Chỉ có màu'],
  [2,'Kích thước trên bản vẽ chi tiết cho biết gì?','Độ lớn (dài, rộng, cao, đường kính...) của chi tiết','Màu sắc','Giá tiền','Khối lượng người vẽ'],
  [2,'Yêu cầu kĩ thuật trên bản vẽ chi tiết thể hiện gì?','Yêu cầu về gia công, xử lí bề mặt, độ nhẵn...','Tên bài hát','Thời tiết','Điểm số'],
  [2,'Trình tự đọc bản vẽ chi tiết nên bắt đầu từ đâu?','Khung tên, rồi hình biểu diễn, kích thước, yêu cầu kĩ thuật','Đọc ngẫu nhiên','Chỉ đọc màu','Không cần trình tự'],
  [3,'Nêu nội dung của một bản vẽ chi tiết.','Hình biểu diễn (các hình chiếu, mặt cắt nếu có); kích thước; yêu cầu kĩ thuật; khung tên (tên chi tiết, vật liệu, tỉ lệ...).'],
  [3,'Nêu trình tự đọc một bản vẽ chi tiết.','Đọc khung tên (tên, vật liệu, tỉ lệ); đọc hình biểu diễn để hình dung hình dạng; đọc kích thước; đọc yêu cầu kĩ thuật; tổng hợp để hiểu rõ chi tiết.'],
  [4,'Vì sao bản vẽ chi tiết là cơ sở để chế tạo ra sản phẩm đúng yêu cầu?','Bản vẽ chi tiết thể hiện đầy đủ hình dạng, kích thước và yêu cầu kĩ thuật của chi tiết; người thợ dựa vào đó để gia công đúng. Thiếu bản vẽ hoặc bản vẽ sai sẽ chế tạo sai, chi tiết không lắp được hoặc không đạt yêu cầu.']
 ]);
 add(M,8,'Bài 4: Bản vẽ lắp',[
  [1,'Bản vẽ lắp dùng để làm gì?','Thể hiện hình dạng, vị trí tương quan của các chi tiết khi lắp thành sản phẩm','Vẽ một chi tiết riêng','Vẽ tranh','Ghi chép'],
  [1,'Bản vẽ lắp có thêm thành phần nào so với bản vẽ chi tiết?','Bảng kê các chi tiết','Khung tên','Hình biểu diễn','Kích thước'],
  [2,'Bảng kê trong bản vẽ lắp cho biết gì?','Tên, số lượng, vật liệu của các chi tiết','Giá bán','Tên người mua','Thời tiết'],
  [2,'Số vị trí (chữ số chỉ dẫn) trên bản vẽ lắp dùng để làm gì?','Chỉ rõ từng chi tiết tương ứng trong bảng kê','Ghi điểm','Ghi ngày','Trang trí'],
  [2,'Bản vẽ lắp được dùng chủ yếu trong công việc nào?','Lắp ráp và kiểm tra sản phẩm','Nấu ăn','Trồng cây','Chăn nuôi'],
  [3,'Nêu nội dung của một bản vẽ lắp.','Hình biểu diễn thể hiện vị trí các chi tiết; kích thước lắp; bảng kê (tên, số lượng, vật liệu các chi tiết); số vị trí; khung tên.'],
  [3,'Phân biệt bản vẽ chi tiết và bản vẽ lắp.','Bản vẽ chi tiết: thể hiện một chi tiết để chế tạo. Bản vẽ lắp: thể hiện nhiều chi tiết ở vị trí lắp ráp với nhau tạo thành sản phẩm, dùng để lắp ráp và kiểm tra.'],
  [4,'Vì sao bản vẽ lắp cần thiết trong quá trình lắp ráp sản phẩm?','Bản vẽ lắp cho biết các chi tiết ghép với nhau ở vị trí, trình tự nào; nhờ đó người thợ lắp ráp đúng, đầy đủ các chi tiết thành sản phẩm hoàn chỉnh và kiểm tra được. Thiếu nó, việc lắp ráp dễ sai, thiếu hoặc nhầm chi tiết.']
 ]);
 add(M,8,'Bài 5: Bản vẽ nhà',[
  [1,'Bản vẽ nhà dùng để làm gì?','Thể hiện hình dạng, kích thước, cách bố trí của ngôi nhà để xây dựng','Vẽ một chi tiết máy','Vẽ tranh','Ghi nhật kí'],
  [1,'Mặt bằng của bản vẽ nhà thể hiện gì?','Vị trí, kích thước các phòng, tường, cửa nhìn từ trên xuống','Màu sơn','Mái nhà nhìn nghiêng','Nội thất chi tiết'],
  [2,'Mặt đứng của bản vẽ nhà thể hiện gì?','Hình dáng bên ngoài (mặt trước/ bên) của ngôi nhà','Bố trí phòng','Móng nhà','Hệ thống điện nước ẩn'],
  [2,'Kí hiệu cửa đi, cửa sổ trên bản vẽ nhà dùng để làm gì?','Thể hiện vị trí cửa đi, cửa sổ','Ghi điểm','Trang trí','Ghi tên người'],
  [2,'Đọc bản vẽ nhà giúp ích gì?','Hình dung và thi công đúng ngôi nhà theo thiết kế','Nấu ăn','Trồng cây','Không giúp gì'],
  [3,'Nêu các hình biểu diễn chính trong một bản vẽ nhà.','Mặt bằng (bố trí phòng, tường, cửa nhìn từ trên); mặt đứng (hình dáng bên ngoài); mặt cắt (cấu tạo bên trong theo chiều cao). Kèm kích thước và khung tên.'],
  [3,'Mặt bằng và mặt đứng của bản vẽ nhà khác nhau như thế nào?','Mặt bằng: nhìn từ trên xuống, thể hiện cách bố trí, kích thước các phòng, tường, cửa. Mặt đứng: nhìn từ phía trước/ bên, thể hiện hình dáng, kiến trúc bên ngoài của ngôi nhà.'],
  [4,'Vì sao cần có bản vẽ nhà trước khi xây dựng một ngôi nhà?','Bản vẽ nhà thể hiện thiết kế (bố trí, kích thước, hình dáng) để tính vật liệu, chi phí và thi công đúng ý muốn; giúp các bên (chủ nhà, thợ) thống nhất, tránh sai sót, sửa chữa tốn kém. Xây không có bản vẽ dễ lộn xộn, không hợp lí.']
 ]);
 add(M,8,'Bài 6: Vật liệu cơ khí',[
  [1,'Vật liệu cơ khí được chia thành những nhóm chính nào?','Vật liệu kim loại và vật liệu phi kim loại','Chỉ có gỗ','Chỉ có nhựa','Chỉ có giấy'],
  [1,'Kim loại đen gồm những vật liệu nào?','Gang và thép (hợp kim của sắt)','Đồng, nhôm','Nhựa','Cao su'],
  [2,'Kim loại màu gồm những vật liệu nào?','Đồng, nhôm và hợp kim của chúng','Gang, thép','Gỗ','Nhựa'],
  [2,'Vật liệu phi kim loại thường dùng trong cơ khí là gì?','Chất dẻo (nhựa), cao su','Gang','Thép','Sắt'],
  [2,'Tính chất nào quan trọng của vật liệu cơ khí?','Tính cứng, bền, dẻo, khả năng gia công','Màu sắc đẹp','Mùi thơm','Giá rẻ nhất'],
  [3,'Phân loại vật liệu cơ khí và cho ví dụ.','Kim loại: kim loại đen (gang, thép), kim loại màu (đồng, nhôm). Phi kim loại: chất dẻo (nhựa), cao su. Mỗi loại có tính chất và công dụng riêng.'],
  [3,'Nêu một số tính chất của vật liệu cơ khí cần quan tâm khi chọn vật liệu.','Tính chất cơ học (cứng, bền, dẻo, dai); tính chất vật lí (dẫn điện, dẫn nhiệt, khối lượng riêng); tính công nghệ (khả năng gia công: đúc, rèn, cắt gọt); tính chống ăn mòn.'],
  [4,'Vì sao cần chọn vật liệu phù hợp khi chế tạo sản phẩm cơ khí?','Mỗi vật liệu có tính chất khác nhau; chọn đúng (bền, cứng, dễ gia công, chống gỉ, nhẹ...) giúp sản phẩm đạt yêu cầu sử dụng, bền, an toàn và tiết kiệm chi phí. Chọn sai vật liệu khiến sản phẩm nhanh hỏng, kém chất lượng hoặc lãng phí.']
 ]);
 add(M,8,'Bài 7: Truyền và biến đổi chuyển động',[
  [1,'Cơ cấu truyền chuyển động dùng để làm gì?','Truyền chuyển động từ bộ phận này sang bộ phận khác','Dừng máy','Trang trí','Chiếu sáng'],
  [1,'Bộ truyền động đai (dây curoa) gồm những bộ phận chính nào?','Bánh dẫn, bánh bị dẫn và dây đai','Chỉ một bánh răng','Chỉ dây điện','Chỉ ốc vít'],
  [2,'Bộ truyền động bánh răng có ưu điểm gì?','Truyền chính xác, tỉ số truyền ổn định','Dễ trượt','Không chính xác','Không truyền được'],
  [2,'Cơ cấu biến đổi chuyển động dùng để làm gì?','Biến đổi dạng chuyển động (quay thành tịnh tiến và ngược lại)','Giữ nguyên chuyển động','Dừng chuyển động','Không có tác dụng'],
  [2,'Ví dụ nào là biến đổi chuyển động quay thành tịnh tiến?','Cơ cấu tay quay – con trượt','Hai bánh răng ăn khớp','Dây đai và bánh đai','Trục thẳng quay đều'],
  [3,'Nêu một số cơ cấu truyền chuyển động và ví dụ ứng dụng.','Truyền động đai (xe máy, máy may); truyền động bánh răng (hộp số, đồng hồ); truyền động xích (xe đạp). Dùng để truyền chuyển động và thay đổi tốc độ.'],
  [3,'Phân biệt cơ cấu truyền chuyển động và cơ cấu biến đổi chuyển động.','Truyền chuyển động: đưa chuyển động từ bộ phận này sang bộ phận khác (giữ nguyên dạng quay). Biến đổi chuyển động: đổi dạng chuyển động (quay ↔ tịnh tiến) như tay quay – con trượt.'],
  [4,'Vì sao các cơ cấu truyền và biến đổi chuyển động rất quan trọng trong máy móc?','Nhờ chúng, chuyển động và năng lượng từ nguồn (động cơ) được đưa đến các bộ phận làm việc với tốc độ, chiều, dạng phù hợp; giúp máy thực hiện được các thao tác đa dạng (quay, tịnh tiến...). Không có chúng, máy không hoạt động đồng bộ, hiệu quả được.']
 ]);
 add(M,8,'Bài 8: Gia công cơ khí bằng tay',[
  [1,'Gia công cơ khí bằng tay là gì?','Dùng dụng cụ cầm tay để tạo hình, chế tạo chi tiết','Dùng máy tự động hoàn toàn','Chỉ dùng máy tính','Không dùng dụng cụ'],
  [1,'Dụng cụ nào dùng để cưa, cắt kim loại bằng tay?','Cưa tay (cưa sắt)','Bút chì','Thước kẻ giấy','Kéo cắt giấy'],
  [2,'Dũa dùng để làm gì?','Làm nhẵn, phẳng bề mặt kim loại','Cắt đứt','Khoan lỗ','Hàn kim loại'],
  [2,'Khi gia công cơ khí bằng tay, cần chú ý điều gì để an toàn?','Dùng đúng dụng cụ, đeo bảo hộ, cẩn thận','Không cần bảo hộ','Dùng dụng cụ hỏng','Làm vội vàng'],
  [2,'Trước khi cưa, cần làm gì với phôi (vật gia công)?','Kẹp chặt phôi vào ê tô','Để lỏng','Cầm tay','Đặt tự do trên bàn'],
  [3,'Kể tên một số dụng cụ gia công cơ khí bằng tay và công dụng.','Cưa tay (cắt kim loại); dũa (làm nhẵn, phẳng); đục (chặt, tạo rãnh); búa; ê tô (kẹp giữ phôi); thước, mũi vạch (đo, vạch dấu).'],
  [3,'Nêu các bước cơ bản khi gia công một chi tiết đơn giản bằng tay.','Đọc bản vẽ, chuẩn bị vật liệu, dụng cụ; vạch dấu; kẹp phôi; cưa/cắt theo dấu; dũa, làm nhẵn; kiểm tra kích thước; bảo đảm an toàn suốt quá trình.'],
  [4,'Vì sao phải tuân thủ an toàn lao động khi gia công cơ khí bằng tay?','Dụng cụ cơ khí sắc, nặng, có thể gây đứt tay, dập, văng mảnh; làm sai kĩ thuật dễ tai nạn. Tuân thủ an toàn (kẹp chặt phôi, dùng đúng dụng cụ, đeo kính/găng, cẩn thận) giúp bảo vệ bản thân và người xung quanh, bảo đảm chất lượng sản phẩm.']
 ]);
 add(M,8,'Bài 9: Ngành nghề trong lĩnh vực cơ khí',[
  [1,'Ngành cơ khí liên quan đến công việc nào?','Thiết kế, chế tạo, lắp ráp, sửa chữa máy móc, thiết bị','Nấu ăn','Trồng lúa','Dạy nhạc'],
  [1,'Nghề nào thuộc lĩnh vực cơ khí?','Thợ tiện, thợ hàn, kĩ sư cơ khí','Nông dân','Bác sĩ','Ca sĩ'],
  [2,'Để làm nghề cơ khí, cần có phẩm chất nào?','Cẩn thận, kiên trì, khéo tay, có sức khỏe','Lười biếng','Ẩu','Thiếu kỉ luật'],
  [2,'Cơ khí có vai trò gì trong đời sống và sản xuất?','Tạo ra máy móc, công cụ phục vụ sản xuất và đời sống','Không có vai trò','Chỉ gây ô nhiễm','Làm chậm sản xuất'],
  [2,'Kĩ sư cơ khí thường làm công việc gì?','Thiết kế, tính toán, chỉ đạo chế tạo máy móc','Chỉ bán hàng','Chỉ nấu ăn','Chỉ lái xe'],
  [3,'Kể một số ngành nghề trong lĩnh vực cơ khí.','Kĩ sư cơ khí; thợ tiện, phay, bào; thợ hàn; thợ nguội; thợ sửa chữa máy, ô tô; thiết kế cơ khí (CAD); vận hành máy CNC.'],
  [3,'Nêu những yêu cầu đối với người làm nghề cơ khí.','Có kiến thức kĩ thuật, đọc được bản vẽ; khéo tay, cẩn thận, kiên trì; có sức khỏe; tuân thủ an toàn lao động; ham học hỏi, cập nhật công nghệ mới.'],
  [4,'Vì sao ngành cơ khí được coi là ngành quan trọng của nền kinh tế?','Cơ khí chế tạo máy móc, thiết bị, công cụ phục vụ hầu hết các ngành (nông nghiệp, công nghiệp, giao thông, xây dựng...); là nền tảng cho sản xuất, tự động hóa và phát triển kinh tế. Thiếu cơ khí, các ngành khác khó phát triển.']
 ]);
 add(M,8,'Bài 10: Dự án: Gia công chi tiết bằng dụng cụ cầm tay',[
  [1,'Khi thực hiện dự án gia công chi tiết, bước đầu cần làm gì?','Đọc bản vẽ, xác định yêu cầu và chuẩn bị vật liệu, dụng cụ','Làm ngay không chuẩn bị','Bỏ qua bản vẽ','Chỉ tắt máy'],
  [1,'Trong quá trình gia công, cần luôn bảo đảm điều gì?','An toàn lao động','Làm nhanh bất chấp','Không cần bảo hộ','Dùng dụng cụ hỏng'],
  [2,'Vạch dấu trước khi gia công nhằm mục đích gì?','Xác định đúng hình dạng, kích thước cần gia công','Trang trí','Làm bẩn phôi','Không có mục đích'],
  [2,'Sau khi gia công xong, cần làm gì?','Kiểm tra kích thước, chất lượng chi tiết','Vứt đi ngay','Không kiểm tra','Bỏ mặc'],
  [2,'Để chi tiết đạt yêu cầu, trong quá trình làm cần chú ý gì?','Làm đúng bản vẽ, cẩn thận, kiểm tra thường xuyên','Làm tùy ý','Không theo bản vẽ','Vội vàng'],
  [3,'Nêu các bước thực hiện dự án gia công một chi tiết bằng dụng cụ cầm tay.','Đọc bản vẽ, xác định yêu cầu; chuẩn bị vật liệu, dụng cụ; vạch dấu; kẹp phôi và gia công (cưa, dũa...) theo dấu; kiểm tra kích thước; hoàn thiện; bảo đảm an toàn.'],
  [3,'Nêu một số tiêu chí đánh giá sản phẩm gia công.','Đúng hình dạng, kích thước theo bản vẽ; bề mặt nhẵn, phẳng; bảo đảm yêu cầu kĩ thuật; thực hiện an toàn; tiết kiệm vật liệu, thời gian.'],
  [4,'Vì sao quá trình gia công cần kiểm tra kích thước thường xuyên?','Kiểm tra giúp phát hiện sớm sai lệch so với bản vẽ để điều chỉnh kịp thời, tránh gia công hỏng cả chi tiết (cưa, dũa quá tay không sửa lại được). Nhờ đó bảo đảm chi tiết đạt yêu cầu, tiết kiệm vật liệu và công sức.']
 ]);
 add(M,8,'Bài 11: Tai nạn điện',[
  [1,'Tai nạn điện thường xảy ra do nguyên nhân nào?','Chạm vào vật mang điện, dây điện hở, thiết bị rò điện','Do trời đẹp','Do dùng đèn LED','Do ngắt điện'],
  [1,'Hành vi nào dễ gây tai nạn điện?','Dùng tay ướt chạm thiết bị điện, dây hở','Ngắt điện khi sửa','Dùng ổ cắm an toàn','Để xa tầm trẻ'],
  [2,'Khi dây điện rơi xuống đường bị ngập nước, cần làm gì?','Tránh xa, cảnh báo mọi người, báo cơ quan điện','Lội vào xem','Cầm dây lên','Giẫm qua'],
  [2,'Vì sao không được đến gần, chạm vào nơi có điện cao thế?','Điện cao thế rất nguy hiểm, có thể phóng điện gây chết người','Vì không sao','Vì điện yếu','Không có lí do'],
  [2,'Khoảng cách an toàn với đường dây điện cao thế để làm gì?','Tránh bị phóng điện gây tai nạn','Để nhìn cho rõ','Trang trí','Không có tác dụng'],
  [3,'Nêu một số nguyên nhân gây tai nạn điện.','Chạm trực tiếp vào vật mang điện (dây trần, ổ điện); dùng thiết bị, dây điện hư hỏng, rò điện; vi phạm khoảng cách an toàn với điện cao thế; đến gần dây đứt, nơi ẩm ướt có điện.'],
  [3,'Nêu các tình huống nguy hiểm có thể dẫn đến tai nạn điện trong gia đình.','Dùng thiết bị điện khi tay ướt; dây điện, ổ cắm hỏng hở; cắm quá nhiều thiết bị một ổ; trẻ nghịch ổ điện; dùng điện gần nơi ẩm ướt; sửa điện không ngắt nguồn.'],
  [4,'Vì sao hiểu biết về nguyên nhân tai nạn điện giúp phòng tránh hiệu quả?','Biết rõ nguyên nhân (chạm điện, rò điện, vi phạm khoảng cách...) giúp ta chủ động phòng tránh: không chạm vật mang điện, dùng thiết bị an toàn, giữ khoảng cách, ngắt điện khi sửa. Phòng tránh đúng nguyên nhân giúp giảm tối đa nguy cơ tai nạn, bảo vệ tính mạng.']
 ]);
 add(M,8,'Bài 12: Biện pháp an toàn điện',[
  [1,'Biện pháp an toàn điện cơ bản là gì?','Cách li, ngắt nguồn, dùng thiết bị bảo vệ, không chạm điện khi tay ướt','Chạm điện tùy ý','Dùng dây hở','Cắm quá tải'],
  [1,'Trước khi sửa chữa thiết bị điện, phải làm gì?','Ngắt nguồn điện (rút phích, ngắt cầu dao)','Vừa sửa vừa cắm điện','Dùng tay ướt','Để trẻ làm'],
  [2,'Thiết bị nào giúp tự động ngắt điện khi có sự cố, rò điện?','Cầu dao tự động / aptomat, thiết bị chống giật (ELCB)','Bóng đèn','Quạt','Ti vi'],
  [2,'Vì sao cần dùng dây dẫn, ổ cắm đúng tải?','Tránh quá tải gây nóng, chập, cháy nổ','Để tốn điện','Để nhanh hỏng','Không có lí do'],
  [2,'Việc nối đất cho vỏ thiết bị điện có tác dụng gì?','Đưa dòng điện rò xuống đất, bảo vệ người dùng khỏi điện giật','Làm thiết bị đẹp','Tăng điện áp','Không có tác dụng'],
  [3,'Nêu các biện pháp bảo đảm an toàn điện trong gia đình.','Không chạm vật mang điện, không dùng điện khi tay ướt; dùng dây, ổ cắm, thiết bị đúng tiêu chuẩn, đúng tải; ngắt nguồn khi sửa; lắp aptomat, thiết bị chống giật, nối đất; để xa tầm trẻ.'],
  [3,'Vì sao cần lắp thiết bị chống giật (ELCB) cho hệ thống điện gia đình?','Thiết bị chống giật tự động ngắt điện rất nhanh khi phát hiện dòng rò (ví dụ khi người chạm phải), giúp tránh điện giật nguy hiểm đến tính mạng; là biện pháp bảo vệ chủ động, hiệu quả cho người sử dụng.'],
  [4,'Vì sao thực hiện tốt các biện pháp an toàn điện là bảo vệ tính mạng và tài sản?','Điện rất nguy hiểm, tai nạn điện có thể gây chết người, cháy nổ, thiệt hại tài sản. Thực hiện đúng biện pháp an toàn (cách li, ngắt nguồn, thiết bị bảo vệ...) ngăn ngừa sự cố, bảo vệ an toàn cho người và nhà cửa.']
 ]);
 add(M,8,'Bài 13: Sơ cứu người bị tai nạn điện',[
  [1,'Khi thấy người bị điện giật, việc đầu tiên cần làm là gì?','Nhanh chóng ngắt nguồn điện (cầu dao, phích cắm)','Chạm ngay vào nạn nhân','Dội nước','Bỏ chạy'],
  [1,'Vì sao không được dùng tay không kéo người bị điện giật ra khi chưa ngắt điện?','Vì mình cũng sẽ bị điện giật','Vì không cần thiết','Vì sẽ làm nạn nhân đau','Không có lí do'],
  [2,'Nếu chưa ngắt được nguồn, có thể tách nạn nhân khỏi nguồn điện bằng cách nào?','Dùng vật cách điện khô (gậy gỗ, nhựa khô) để gạt dây/ đẩy nạn nhân ra','Dùng tay không','Dùng thanh kim loại','Dùng tay ướt'],
  [2,'Sau khi tách nạn nhân khỏi nguồn điện, cần làm gì?','Kiểm tra, sơ cứu (hô hấp nhân tạo nếu cần) và gọi cấp cứu 115','Để mặc đó','Rời đi','Lắc mạnh nạn nhân'],
  [2,'Số điện thoại cấp cứu y tế ở Việt Nam là số nào?','115','113','114','111'],
  [3,'Nêu các bước sơ cứu người bị tai nạn điện.','Nhanh chóng ngắt nguồn điện; nếu chưa ngắt được, dùng vật cách điện khô tách nạn nhân khỏi nguồn (đứng trên vật khô); kiểm tra hô hấp, sơ cứu (hô hấp nhân tạo, ép tim nếu cần); gọi 115 và đưa đi cấp cứu.'],
  [3,'Vì sao khi cứu người bị điện giật phải bảo đảm an toàn cho bản thân trước?','Nếu vội chạm vào nạn nhân khi chưa ngắt điện, người cứu cũng bị điện giật, dẫn đến có thêm nạn nhân và không ai cứu được. Phải ngắt điện hoặc dùng vật cách điện, đứng nơi khô ráo rồi mới cứu để bảo đảm an toàn cho cả hai.'],
  [4,'Vì sao sơ cứu kịp thời, đúng cách có ý nghĩa quyết định với người bị điện giật?','Điện giật có thể làm ngừng tim, ngừng thở; nếu được tách khỏi nguồn và hô hấp nhân tạo, ép tim kịp thời trong vài phút đầu thì khả năng cứu sống cao. Chậm trễ hoặc làm sai cách khiến nạn nhân nguy kịch hoặc tử vong.']
 ]);
 add(M,8,'Bài 14: Khái quát về mạch điện',[
  [1,'Mạch điện gồm những thành phần cơ bản nào?','Nguồn điện, dây dẫn, thiết bị đóng cắt/bảo vệ và phụ tải (đồ dùng điện)','Chỉ có bóng đèn','Chỉ có dây','Chỉ có pin'],
  [1,'Nguồn điện trong mạch có vai trò gì?','Cung cấp điện năng cho mạch hoạt động','Tiêu thụ điện','Ngắt điện','Trang trí'],
  [2,'Phụ tải (đồ dùng điện) trong mạch có vai trò gì?','Tiêu thụ điện năng, biến thành dạng năng lượng khác (ánh sáng, nhiệt...)','Cung cấp điện','Ngắt mạch','Dẫn điện'],
  [2,'Công tắc trong mạch điện dùng để làm gì?','Đóng, ngắt mạch điện','Cung cấp điện','Tiêu thụ điện','Tăng điện áp'],
  [2,'Sơ đồ mạch điện dùng để làm gì?','Biểu diễn cách nối các phần tử trong mạch bằng kí hiệu','Trang trí','Ghi điểm','Vẽ tranh'],
  [3,'Nêu các thành phần cơ bản của một mạch điện và vai trò.','Nguồn điện (cung cấp điện năng); dây dẫn (dẫn điện); thiết bị đóng cắt, bảo vệ (công tắc, cầu chì – điều khiển, bảo vệ); phụ tải (đồ dùng điện – tiêu thụ điện năng).'],
  [3,'Phân biệt sơ đồ nguyên lí và sơ đồ lắp đặt của mạch điện.','Sơ đồ nguyên lí: thể hiện mối liên hệ điện giữa các phần tử (cách hoạt động), không theo vị trí thực. Sơ đồ lắp đặt: thể hiện vị trí, cách bố trí thực tế để lắp đặt mạch.'],
  [4,'Vì sao cần hiểu sơ đồ mạch điện trước khi lắp đặt hay sửa chữa?','Sơ đồ cho biết các phần tử nối với nhau thế nào, dòng điện đi ra sao; hiểu sơ đồ giúp lắp đúng, tìm và sửa lỗi chính xác, bảo đảm mạch hoạt động đúng và an toàn. Lắp/sửa không theo sơ đồ dễ sai, chập cháy, nguy hiểm.']
 ]);
 add(M,8,'Bài 15: Cảm biến và mô đun cảm biến',[
  [1,'Cảm biến là gì?','Thiết bị nhận biết, phản ứng với các đại lượng vật lí (ánh sáng, nhiệt độ, độ ẩm...)','Thiết bị chiếu sáng','Nguồn điện','Dây dẫn'],
  [1,'Cảm biến ánh sáng phản ứng với đại lượng nào?','Ánh sáng','Nhiệt độ','Âm thanh','Độ ẩm'],
  [2,'Mô đun cảm biến gồm những gì?','Cảm biến cùng mạch xử lí tín hiệu để điều khiển thiết bị','Chỉ một bóng đèn','Chỉ dây điện','Chỉ công tắc cơ'],
  [2,'Cảm biến nhiệt độ được dùng trong thiết bị nào?','Điều hòa, tủ lạnh, nồi cơm điện','Cái bàn','Quyển sách','Cây bút'],
  [2,'Ứng dụng của cảm biến chuyển động là gì?','Tự bật đèn, báo động khi có người','Nấu ăn','Tưới cây bằng tay','Không có ứng dụng'],
  [3,'Kể một số loại cảm biến và ứng dụng.','Cảm biến ánh sáng (tự bật/tắt đèn); cảm biến nhiệt độ (điều hòa, tủ lạnh); cảm biến độ ẩm (tưới cây tự động); cảm biến chuyển động (đèn tự động, báo động).'],
  [3,'Nêu vai trò của cảm biến trong các thiết bị tự động.','Cảm biến "cảm nhận" môi trường (ánh sáng, nhiệt, ẩm, chuyển động...) và gửi tín hiệu để mạch điều khiển bật/tắt thiết bị phù hợp; nhờ đó thiết bị hoạt động tự động, chính xác mà không cần con người thao tác trực tiếp.'],
  [4,'Vì sao cảm biến là bộ phận quan trọng trong các hệ thống tự động, nhà thông minh?','Cảm biến là "giác quan" của hệ thống, thu nhận thông tin về môi trường để hệ thống tự động ra quyết định (bật đèn khi tối, tưới cây khi đất khô, báo động khi có người). Không có cảm biến, hệ thống không thể tự động hóa, giám sát và phản ứng kịp thời.']
 ]);
 add(M,8,'Bài 16: Mạch điện điều khiển sử dụng mô đun cảm biến',[
  [1,'Mạch điện điều khiển dùng mô đun cảm biến hoạt động dựa vào gì?','Tín hiệu từ cảm biến để tự động đóng/ngắt thiết bị','Thao tác tay liên tục','Không cần tín hiệu','Chỉ dựa vào nguồn'],
  [1,'Ví dụ về mạch điều khiển dùng cảm biến ánh sáng là gì?','Đèn tự động bật khi trời tối','Đèn bật bằng tay','Quạt quay liên tục','Bếp đun'],
  [2,'Mạch tưới cây tự động thường dùng cảm biến gì?','Cảm biến độ ẩm đất','Cảm biến âm thanh','Cảm biến ánh sáng duy nhất','Không cần cảm biến'],
  [2,'Lợi ích của mạch điều khiển tự động dùng cảm biến là gì?','Tiện lợi, tiết kiệm năng lượng, chính xác, giảm công sức','Tốn điện vô ích','Bất tiện','Kém chính xác'],
  [2,'Thành phần nào ra lệnh đóng/ngắt thiết bị trong mạch điều khiển?','Mạch xử lí (mô đun) dựa vào tín hiệu cảm biến','Bóng đèn','Dây dẫn trơn','Vỏ nhựa'],
  [3,'Nêu nguyên lí hoạt động của mạch điện điều khiển dùng mô đun cảm biến.','Cảm biến thu nhận đại lượng môi trường (ánh sáng, độ ẩm...) và tạo tín hiệu; mô đun xử lí so sánh, khi đạt ngưỡng sẽ điều khiển đóng/ngắt mạch cấp điện cho thiết bị (đèn, bơm...), giúp thiết bị tự động hoạt động.'],
  [3,'Kể một số ứng dụng của mạch điều khiển dùng cảm biến trong đời sống.','Đèn chiếu sáng tự động (cảm biến ánh sáng, chuyển động); hệ thống tưới cây tự động (cảm biến độ ẩm); điều hòa, quạt theo nhiệt độ; báo động chống trộm, báo cháy.'],
  [4,'Vì sao mạch điều khiển dùng cảm biến góp phần tiết kiệm năng lượng và tiện lợi?','Thiết bị chỉ hoạt động khi cần (đèn bật khi tối và có người, bơm tưới khi đất khô), tránh lãng phí điện, nước; đồng thời tự động hóa nên tiện lợi, chính xác, giảm công sức con người và phù hợp với cuộc sống hiện đại.']
 ]);
 add(M,8,'Bài 17: Ngành nghề trong lĩnh vực kĩ thuật điện',[
  [1,'Ngành kĩ thuật điện liên quan đến công việc nào?','Thiết kế, lắp đặt, vận hành, sửa chữa hệ thống, thiết bị điện','Trồng lúa','Nấu ăn','Dạy nhạc'],
  [1,'Nghề nào thuộc lĩnh vực kĩ thuật điện?','Thợ điện, kĩ sư điện','Nông dân','Đầu bếp','Họa sĩ'],
  [2,'Người làm nghề điện cần phẩm chất gì?','Cẩn thận, tuân thủ an toàn, có kiến thức kĩ thuật','Ẩu, chủ quan','Coi thường an toàn','Thiếu hiểu biết'],
  [2,'Công việc của thợ điện dân dụng là gì?','Lắp đặt, sửa chữa điện trong nhà, công trình','Chỉ bán hàng','Chỉ lái xe','Chỉ nấu ăn'],
  [2,'Vì sao nghề điện đòi hỏi tính kỉ luật và tuân thủ an toàn cao?','Vì làm việc với điện nguy hiểm, sai sót dễ gây tai nạn, cháy nổ','Vì điện không nguy hiểm','Vì nghề nhàn','Không có lí do'],
  [3,'Kể một số ngành nghề trong lĩnh vực kĩ thuật điện.','Kĩ sư điện; thợ điện dân dụng; thợ lắp đặt, vận hành, sửa chữa thiết bị điện; công nhân điện nhà máy; nhân viên vận hành trạm điện; thiết kế hệ thống điện.'],
  [3,'Nêu những yêu cầu đối với người làm nghề kĩ thuật điện.','Có kiến thức về điện, đọc được sơ đồ; cẩn thận, tỉ mỉ; tuân thủ nghiêm quy trình an toàn điện; có sức khỏe; trách nhiệm cao; ham học hỏi công nghệ mới.'],
  [4,'Vì sao các nghề trong lĩnh vực kĩ thuật điện ngày càng cần thiết?','Điện là nguồn năng lượng thiết yếu cho mọi hoạt động sản xuất và đời sống; nhu cầu lắp đặt, vận hành, bảo trì hệ thống và thiết bị điện ngày càng lớn, nhất là khi tự động hóa, năng lượng tái tạo phát triển. Vì vậy nghề điện rất cần thiết và nhiều cơ hội.']
 ]);
 add(M,8,'Bài 18: Giới thiệu về thiết kế kĩ thuật',[
  [1,'Thiết kế kĩ thuật là gì?','Quá trình sáng tạo ra sản phẩm kĩ thuật nhằm giải quyết một nhu cầu, vấn đề','Chép lại sản phẩm có sẵn','Vẽ tranh','Nấu ăn'],
  [1,'Mục đích của thiết kế kĩ thuật là gì?','Tạo ra sản phẩm đáp ứng nhu cầu của con người','Làm cho phức tạp','Không có mục đích','Gây lãng phí'],
  [2,'Một sản phẩm thiết kế tốt cần bảo đảm yêu cầu nào?','Đáp ứng nhu cầu sử dụng, an toàn, hiệu quả, khả thi','Càng đắt càng tốt','Chỉ cần đẹp','Không cần an toàn'],
  [2,'Thiết kế kĩ thuật đòi hỏi người thiết kế có khả năng gì?','Sáng tạo, tư duy kĩ thuật, giải quyết vấn đề','Lười suy nghĩ','Sao chép','Thiếu kiên trì'],
  [2,'Thiết kế kĩ thuật gắn liền với lĩnh vực nào?','Khoa học, công nghệ, kĩ thuật','Chỉ văn học','Chỉ âm nhạc','Không liên quan gì'],
  [3,'Nêu vai trò của thiết kế kĩ thuật trong đời sống.','Tạo ra các sản phẩm, công cụ, máy móc giải quyết nhu cầu và vấn đề của con người; cải tiến sản phẩm cho tốt hơn; thúc đẩy sự phát triển của công nghệ, nâng cao chất lượng cuộc sống.'],
  [3,'Nêu một số yêu cầu đối với một sản phẩm thiết kế kĩ thuật.','Đáp ứng đúng nhu cầu sử dụng; an toàn; bền, hiệu quả; khả thi (chế tạo được, chi phí hợp lí); thẩm mĩ; thân thiện môi trường.'],
  [4,'Vì sao thiết kế kĩ thuật được coi là hoạt động sáng tạo và giải quyết vấn đề?','Thiết kế bắt đầu từ một nhu cầu/ vấn đề thực tế; người thiết kế phải tìm tòi, đề xuất nhiều ý tưởng, lựa chọn và tạo ra giải pháp (sản phẩm) mới, tốt hơn. Đó là quá trình sáng tạo và giải quyết vấn đề, không phải sao chép.']
 ]);
 add(M,8,'Bài 19: Các bước cơ bản trong thiết kế kĩ thuật',[
  [1,'Bước đầu tiên trong thiết kế kĩ thuật là gì?','Xác định nhu cầu, vấn đề cần giải quyết','Chế tạo ngay','Bán sản phẩm','Bỏ qua'],
  [1,'Sau khi có ý tưởng, bước tiếp theo thường là gì?','Lựa chọn giải pháp và thiết kế (phác thảo, tính toán)','Vứt bỏ ý tưởng','Nghỉ ngơi','Không làm gì'],
  [2,'Việc làm mẫu (chế thử) trong thiết kế nhằm mục đích gì?','Kiểm tra, thử nghiệm ý tưởng trước khi sản xuất','Trang trí','Lãng phí','Không cần thiết'],
  [2,'Sau khi thử nghiệm mẫu, nếu phát hiện lỗi thì làm gì?','Điều chỉnh, cải tiến thiết kế','Bỏ cuộc','Giữ nguyên lỗi','Sản xuất hàng loạt ngay'],
  [2,'Đánh giá sản phẩm thiết kế dựa trên tiêu chí nào?','Mức độ đáp ứng nhu cầu, an toàn, hiệu quả, chi phí','Màu sắc duy nhất','Tên người thiết kế','Thời tiết'],
  [3,'Nêu các bước cơ bản trong thiết kế kĩ thuật.','Xác định nhu cầu/ vấn đề; tìm hiểu, đề xuất ý tưởng; lựa chọn giải pháp và thiết kế (phác thảo, tính toán); chế tạo mẫu; thử nghiệm, đánh giá; điều chỉnh, hoàn thiện.'],
  [3,'Vì sao thiết kế kĩ thuật thường là quá trình lặp lại, điều chỉnh nhiều lần?','Vì mẫu thử nghiệm ban đầu thường chưa hoàn hảo; qua thử nghiệm, đánh giá phát hiện hạn chế nên phải điều chỉnh, cải tiến rồi thử lại. Quá trình lặp giúp sản phẩm ngày càng tốt, đáp ứng yêu cầu trước khi sản xuất.'],
  [4,'Vì sao bước xác định nhu cầu, vấn đề là quan trọng nhất khi bắt đầu thiết kế?','Vì nó định hướng toàn bộ quá trình: hiểu đúng nhu cầu mới thiết kế ra sản phẩm phù hợp, giải quyết đúng vấn đề. Xác định sai nhu cầu dẫn đến sản phẩm vô ích dù thiết kế có công phu. Đây là nền tảng cho các bước sau.']
 ]);
 add(M,8,'Bài 20: Dự án: Thiết kế hệ thống tưới cây tự động',[
  [1,'Hệ thống tưới cây tự động dựa trên cảm biến nào là chính?','Cảm biến độ ẩm đất','Cảm biến âm thanh','Cảm biến ánh sáng duy nhất','Không cần cảm biến'],
  [1,'Khi đất khô (độ ẩm thấp), hệ thống tưới tự động sẽ làm gì?','Tự động bật bơm để tưới','Tắt bơm','Không làm gì','Báo cháy'],
  [2,'Lợi ích của hệ thống tưới cây tự động là gì?','Tiết kiệm nước, công sức; tưới đúng lúc, cây phát triển tốt','Lãng phí nước','Tốn công hơn','Hại cây'],
  [2,'Thành phần nào ra lệnh bật/tắt bơm trong hệ thống tưới tự động?','Mạch điều khiển (mô đun) dựa vào cảm biến độ ẩm','Cái bàn','Dây phơi','Chậu cây'],
  [2,'Khi thiết kế hệ thống, cần thử nghiệm nhằm mục đích gì?','Kiểm tra hoạt động đúng và điều chỉnh cho phù hợp','Trang trí','Lãng phí','Không cần'],
  [3,'Nêu các bước thực hiện dự án thiết kế hệ thống tưới cây tự động.','Xác định nhu cầu; tìm hiểu, lên ý tưởng (dùng cảm biến độ ẩm, bơm, mạch điều khiển); thiết kế sơ đồ; lắp ráp mẫu; thử nghiệm (đặt ngưỡng độ ẩm); đánh giá, điều chỉnh, hoàn thiện.'],
  [3,'Nêu nguyên lí hoạt động của hệ thống tưới cây tự động.','Cảm biến đo độ ẩm đất; khi độ ẩm xuống dưới ngưỡng, mô đun điều khiển bật bơm tưới nước; khi đủ ẩm thì tắt bơm. Nhờ đó cây được tưới đúng lúc, tự động.'],
  [4,'Vì sao hệ thống tưới cây tự động vừa tiết kiệm vừa thân thiện môi trường?','Hệ thống chỉ tưới khi đất khô, đúng lượng cần nên tiết kiệm nước và điện, tránh lãng phí; cây được chăm đúng nhu cầu nên phát triển tốt. Tiết kiệm tài nguyên nước, năng lượng cũng góp phần bảo vệ môi trường.']
 ]);
 /* L8: bù lẻ các bài */
 add(M,8,'Bài 18: Giới thiệu về thiết kế kĩ thuật',[
  [1,'Thiết kế kĩ thuật xuất phát từ đâu?','Từ một nhu cầu hoặc vấn đề cần giải quyết','Từ việc sao chép','Từ ngẫu nhiên','Không từ đâu'],
  [3,'Nêu một số sản phẩm quanh em là kết quả của hoạt động thiết kế kĩ thuật.','VD: bàn ghế, xe đạp, quạt điện, điện thoại, đồ dùng học tập... đều được con người thiết kế để đáp ứng nhu cầu sử dụng.']
 ]);
 add(M,8,'Bài 19: Các bước cơ bản trong thiết kế kĩ thuật',[
  [3,'Việc chế tạo mẫu (chế thử) trong thiết kế nhằm mục đích gì?','Để kiểm tra, thử nghiệm ý tưởng, phát hiện hạn chế và điều chỉnh trước khi sản xuất chính thức.']
 ]);

 /* Chủ đề tổng hợp L8 */
 add(M,8,'Vẽ kĩ thuật, cơ khí',[
  [1,'Có mấy hình chiếu vuông góc cơ bản?','Ba: đứng, bằng, cạnh','Một','Hai','Năm'],
  [2,'Kim loại đen gồm những vật liệu nào?','Gang và thép','Đồng, nhôm','Nhựa','Cao su'],
  [2,'Nét liền đậm trên bản vẽ dùng vẽ gì?','Đường bao thấy','Đường khuất','Đường tâm','Khung tên'],
  [3,'Phân biệt bản vẽ chi tiết và bản vẽ lắp.','Bản vẽ chi tiết thể hiện một chi tiết để chế tạo; bản vẽ lắp thể hiện nhiều chi tiết ở vị trí lắp ráp để lắp thành sản phẩm và kiểm tra.'],
  [4,'Vì sao bản vẽ kĩ thuật phải theo tiêu chuẩn thống nhất?','Để mọi người đọc hiểu giống nhau, chính xác; nhờ đó trao đổi thông tin kĩ thuật thuận lợi và chế tạo đúng sản phẩm. Vẽ tùy tiện sẽ gây hiểu nhầm, sai sót.']
 ]);
 add(M,8,'Kĩ thuật điện, an toàn điện',[
  [1,'Trước khi sửa thiết bị điện phải làm gì?','Ngắt nguồn điện','Dùng tay ướt','Vừa sửa vừa cắm điện','Để trẻ làm'],
  [2,'Thiết bị nào tự ngắt điện khi có dòng rò, bảo vệ người?','Thiết bị chống giật (ELCB)','Bóng đèn','Quạt','Ti vi'],
  [2,'Khi gặp người bị điện giật, việc đầu tiên là gì?','Ngắt nguồn điện','Chạm ngay vào nạn nhân','Dội nước','Bỏ chạy'],
  [3,'Nêu một số biện pháp an toàn điện trong gia đình.','Không chạm vật mang điện, không dùng điện khi tay ướt; dùng dây, ổ cắm, thiết bị đúng tải; ngắt nguồn khi sửa; lắp aptomat, thiết bị chống giật, nối đất; để xa tầm trẻ.'],
  [4,'Vì sao sơ cứu kịp thời, đúng cách rất quan trọng với người bị điện giật?','Điện giật có thể gây ngừng tim, ngừng thở; tách khỏi nguồn và hô hấp nhân tạo, ép tim kịp thời trong vài phút đầu thì khả năng cứu sống cao. Chậm hoặc sai cách khiến nạn nhân nguy kịch, tử vong.']
 ]);
 add(M,8,'Thiết kế kĩ thuật và an toàn lao động',[
  [1,'Bước đầu tiên trong thiết kế kĩ thuật là gì?','Xác định nhu cầu, vấn đề cần giải quyết','Chế tạo ngay','Bán sản phẩm','Bỏ qua'],
  [2,'Khi gia công cơ khí bằng tay cần bảo đảm gì?','An toàn lao động (kẹp chặt phôi, đeo bảo hộ, cẩn thận)','Làm vội','Không bảo hộ','Dùng dụng cụ hỏng'],
  [2,'Hệ thống tưới cây tự động dựa vào cảm biến nào?','Cảm biến độ ẩm đất','Cảm biến âm thanh','Cảm biến ánh sáng duy nhất','Không cần cảm biến'],
  [3,'Nêu các bước cơ bản trong thiết kế kĩ thuật.','Xác định nhu cầu/ vấn đề; đề xuất ý tưởng; lựa chọn giải pháp và thiết kế; chế tạo mẫu; thử nghiệm, đánh giá; điều chỉnh, hoàn thiện.'],
  [4,'Vì sao thiết kế kĩ thuật thường phải lặp lại, điều chỉnh nhiều lần?','Mẫu ban đầu thường chưa hoàn hảo; qua thử nghiệm phát hiện hạn chế nên phải điều chỉnh, cải tiến rồi thử lại. Quá trình lặp giúp sản phẩm ngày càng tốt, đạt yêu cầu trước khi sản xuất.']
 ]);
 add(M,8,'Kĩ thuật điện trong gia đình',[
  [1,'Mạch điện gồm những thành phần cơ bản nào?','Nguồn điện, dây dẫn, thiết bị đóng cắt/bảo vệ, phụ tải','Chỉ bóng đèn','Chỉ dây','Chỉ pin'],
  [2,'Cảm biến ánh sáng ứng dụng để làm gì?','Tự động bật/tắt đèn theo ánh sáng','Nấu ăn','Giặt đồ','Tưới cây bằng tay'],
  [2,'Mạch điều khiển dùng cảm biến có lợi ích gì?','Tiện lợi, tiết kiệm năng lượng, chính xác','Tốn điện','Bất tiện','Kém chính xác'],
  [3,'Nêu các thành phần cơ bản của mạch điện và vai trò.','Nguồn (cấp điện năng); dây dẫn (dẫn điện); thiết bị đóng cắt, bảo vệ (công tắc, cầu chì – điều khiển, bảo vệ); phụ tải (đồ dùng điện – tiêu thụ điện năng).'],
  [4,'Vì sao cảm biến và mạch điều khiển tự động góp phần tiết kiệm năng lượng?','Thiết bị chỉ hoạt động khi cần (đèn bật khi tối và có người, bơm tưới khi đất khô), tránh lãng phí điện, nước; vừa tiết kiệm vừa tiện lợi, phù hợp cuộc sống hiện đại và bảo vệ môi trường.']
 ]);

 /* L8: bù lẻ chủ đề tổng hợp */
 add(M,8,'Vẽ kĩ thuật, cơ khí',[
  [1,'Nét đứt (nét khuất) dùng để thể hiện gì?','Đường bao khuất (không nhìn thấy)','Cạnh thấy','Khung tên','Tiêu đề'],
  [3,'Nêu các loại nét vẽ cơ bản và công dụng.','Nét liền đậm: đường bao thấy; nét đứt: đường bao khuất; nét chấm gạch mảnh: đường tâm, trục đối xứng; nét liền mảnh: đường kích thước, đường gióng.']
 ]);
 add(M,8,'Kĩ thuật điện, an toàn điện',[
  [1,'Hành vi nào dễ gây tai nạn điện?','Dùng tay ướt chạm thiết bị điện, dây hở','Ngắt điện khi sửa','Dùng ổ cắm an toàn','Để xa tầm trẻ'],
  [3,'Vì sao khi cứu người bị điện giật phải bảo đảm an toàn cho bản thân trước?','Nếu chạm vào nạn nhân khi chưa ngắt điện, người cứu cũng bị giật; phải ngắt điện hoặc dùng vật cách điện khô, đứng nơi khô ráo rồi mới cứu để an toàn cho cả hai.']
 ]);
 add(M,8,'Thiết kế kĩ thuật và an toàn lao động',[
  [3,'Nêu một số yêu cầu đối với một sản phẩm thiết kế kĩ thuật.','Đáp ứng đúng nhu cầu sử dụng; an toàn; bền, hiệu quả; khả thi (chế tạo được, chi phí hợp lí); thẩm mĩ; thân thiện môi trường.']
 ]);
 add(M,8,'Kĩ thuật điện trong gia đình',[
  [1,'Công tắc trong mạch điện dùng để làm gì?','Đóng, ngắt mạch điện','Cung cấp điện','Tiêu thụ điện','Tăng điện áp'],
  [3,'Kể một số ứng dụng của mạch điều khiển dùng cảm biến trong đời sống.','Đèn chiếu sáng tự động (cảm biến ánh sáng, chuyển động); tưới cây tự động (cảm biến độ ẩm); điều hòa, quạt theo nhiệt độ; báo động chống trộm, báo cháy.']
 ]);

 /* ===================== LỚP 9 ===================== */
 add(M,9,'Bài 1: Thành phần dinh dưỡng trong thực phẩm',[
  [1,'Thực phẩm cung cấp cho cơ thể những chất dinh dưỡng nào?','Chất bột đường, chất đạm, chất béo, vi-ta-min và chất khoáng','Chỉ nước','Chỉ không khí','Không có chất nào'],
  [1,'Chất đạm (protein) có vai trò chính là gì?','Xây dựng, phát triển và tái tạo cơ thể','Chỉ cung cấp nước','Không có vai trò','Làm cơ thể yếu đi'],
  [2,'Chất bột đường (gluxit) có vai trò chính là gì?','Cung cấp năng lượng chính cho cơ thể','Xây dựng cơ bắp','Chống bệnh','Không có vai trò'],
  [2,'Vi-ta-min và chất khoáng có vai trò gì?','Tăng sức đề kháng, giúp cơ thể hoạt động bình thường','Chỉ cung cấp năng lượng','Chỉ tạo mỡ','Không cần thiết'],
  [2,'Thực phẩm nào giàu chất béo?','Dầu, mỡ, bơ','Rau xanh','Nước lọc','Cơm trắng chủ yếu'],
  [3,'Kể tên các nhóm chất dinh dưỡng và vai trò của mỗi nhóm.','Chất bột đường: cung cấp năng lượng; chất đạm: xây dựng, phát triển cơ thể; chất béo: dự trữ và cung cấp năng lượng; vi-ta-min và chất khoáng: tăng đề kháng, giúp cơ thể hoạt động bình thường; nước và chất xơ cũng rất cần thiết.'],
  [3,'Thế nào là một chế độ ăn uống cân đối, hợp lí?','Có đủ và cân đối các nhóm chất dinh dưỡng, phù hợp lứa tuổi và nhu cầu; ăn đúng giờ, đủ bữa, đa dạng thực phẩm, nhiều rau quả, đủ nước, không thừa hay thiếu chất.'],
  [4,'Vì sao cần ăn uống cân đối, đủ chất dinh dưỡng?','Mỗi chất có vai trò riêng; ăn cân đối giúp cơ thể phát triển khỏe mạnh, đủ năng lượng, tăng đề kháng. Thiếu chất gây suy dinh dưỡng, bệnh tật; thừa chất (nhất là bột đường, béo) gây béo phì, bệnh mạn tính. Vì vậy ăn cân đối rất quan trọng cho sức khỏe.']
 ]);
 add(M,9,'Bài 2: Lựa chọn và bảo quản thực phẩm',[
  [1,'Khi lựa chọn thực phẩm tươi, cần chú ý điều gì?','Chọn thực phẩm tươi, sạch, có nguồn gốc, còn hạn sử dụng','Chọn thực phẩm ôi thiu','Không rõ nguồn gốc','Đã hết hạn'],
  [1,'Dấu hiệu nào cho thấy thịt tươi, an toàn?','Màu sắc tự nhiên, đàn hồi tốt, không có mùi lạ','Có mùi hôi','Màu tái, nhớt','Chảy nước, mềm nhũn'],
  [2,'Thực phẩm đóng gói cần kiểm tra thông tin gì trước khi mua?','Hạn sử dụng, nguồn gốc, thành phần, bao bì nguyên vẹn','Chỉ xem màu bao bì','Không cần kiểm tra','Chỉ xem giá'],
  [2,'Phương pháp bảo quản nào phù hợp với rau, thịt, cá tươi?','Bảo quản lạnh (tủ lạnh, tủ đông)','Để ngoài nắng','Để nơi ẩm thấp','Không bảo quản'],
  [2,'Vì sao không nên để lẫn thực phẩm sống và chín?','Tránh lây nhiễm vi khuẩn từ thực phẩm sống sang thực phẩm chín','Cho tiết kiệm chỗ','Cho đẹp mắt','Không có lí do'],
  [3,'Nêu một số cách lựa chọn thực phẩm an toàn.','Chọn thực phẩm tươi, có nguồn gốc rõ ràng; xem hạn sử dụng, nhãn mác với đồ đóng gói; tránh thực phẩm ôi, mốc, bị bơm hóa chất; mua ở nơi uy tín, bảo đảm vệ sinh.'],
  [3,'Nêu các phương pháp bảo quản thực phẩm và ví dụ.','Bảo quản lạnh/đông (thịt, cá, rau); phơi, sấy khô (cá khô, măng); ướp muối, đường (dưa, mứt); đóng hộp, hút chân không. Chọn cách phù hợp từng loại thực phẩm.'],
  [4,'Vì sao lựa chọn và bảo quản thực phẩm đúng cách lại quan trọng với sức khỏe?','Thực phẩm tươi, an toàn và bảo quản đúng giữ được chất dinh dưỡng, không nhiễm khuẩn, không hư hỏng; nhờ đó phòng tránh ngộ độc, bệnh tật. Chọn hoặc bảo quản sai khiến thực phẩm mất chất, nhiễm độc, gây hại cho sức khỏe.']
 ]);
 add(M,9,'Bài 3: Một số ngành nghề liên quan đến chế biến thực phẩm',[
  [1,'Ngành chế biến thực phẩm liên quan đến công việc nào?','Chế biến, sản xuất, bảo quản thực phẩm phục vụ con người','Trồng lúa thuần túy','Sửa máy tính','Dạy nhạc'],
  [1,'Nghề nào thuộc lĩnh vực chế biến thực phẩm?','Đầu bếp, kĩ sư công nghệ thực phẩm','Thợ điện','Nông dân trồng rừng','Lập trình viên'],
  [2,'Người làm nghề chế biến thực phẩm cần phẩm chất nào?','Sạch sẽ, cẩn thận, hiểu biết về dinh dưỡng và an toàn vệ sinh','Ẩu, mất vệ sinh','Coi thường an toàn','Thiếu hiểu biết'],
  [2,'Kĩ sư công nghệ thực phẩm thường làm công việc gì?','Nghiên cứu, cải tiến quy trình sản xuất, chế biến, bảo quản thực phẩm','Chỉ bán hàng','Chỉ lái xe','Chỉ trồng cây'],
  [2,'Vì sao nghề chế biến thực phẩm đòi hỏi tuân thủ vệ sinh an toàn thực phẩm?','Vì sản phẩm ảnh hưởng trực tiếp đến sức khỏe người tiêu dùng','Vì nghề nhàn','Vì không quan trọng','Không có lí do'],
  [3,'Kể một số ngành nghề liên quan đến chế biến thực phẩm.','Đầu bếp, thợ làm bánh; kĩ sư, kĩ thuật viên công nghệ thực phẩm; nhân viên kiểm nghiệm, bảo đảm an toàn thực phẩm; công nhân chế biến; chuyên viên dinh dưỡng.'],
  [3,'Nêu những yêu cầu đối với người làm nghề chế biến thực phẩm.','Hiểu biết về dinh dưỡng, an toàn vệ sinh thực phẩm; sạch sẽ, cẩn thận, khéo léo; tuân thủ quy trình; có sức khỏe, trách nhiệm; ham học hỏi, sáng tạo.'],
  [4,'Vì sao ngành chế biến thực phẩm ngày càng phát triển và cần nhiều lao động?','Nhu cầu về thực phẩm chế biến sẵn, đa dạng, an toàn ngày càng cao; công nghiệp chế biến phát triển để phục vụ tiêu dùng trong nước và xuất khẩu. Vì vậy ngành cần nhiều lao động có kĩ năng, mở ra nhiều cơ hội nghề nghiệp.']
 ]);
 add(M,9,'Bài 4: An toàn lao động và an toàn vệ sinh thực phẩm',[
  [1,'An toàn vệ sinh thực phẩm là gì?','Bảo đảm thực phẩm sạch, không gây hại cho sức khỏe người dùng','Thực phẩm bẩn','Thực phẩm hết hạn','Thực phẩm nhiễm độc'],
  [1,'Trước khi chế biến thực phẩm, cần làm gì?','Rửa tay sạch, vệ sinh dụng cụ và khu vực chế biến','Để tay bẩn','Dùng dao thớt bẩn','Không rửa gì'],
  [2,'Nguyên nhân nào gây ngộ độc thực phẩm?','Thực phẩm ôi thiu, nhiễm khuẩn, tồn dư hóa chất, chế biến không hợp vệ sinh','Ăn chín uống sôi','Rửa tay sạch','Bảo quản lạnh đúng cách'],
  [2,'Khi chế biến, cần tách riêng thực phẩm sống và chín để làm gì?','Tránh lây nhiễm vi khuẩn chéo','Cho nhanh','Cho đẹp','Không có lí do'],
  [2,'Trong lao động chế biến, an toàn lao động gồm việc gì?','Dùng đúng dụng cụ, cẩn thận với dao, bếp, điện; đeo bảo hộ','Làm ẩu','Không bảo hộ','Dùng dụng cụ hỏng'],
  [3,'Nêu các nguyên tắc bảo đảm an toàn vệ sinh thực phẩm.','Chọn thực phẩm sạch, an toàn; giữ vệ sinh (tay, dụng cụ, nơi chế biến); ăn chín, uống sôi; tách riêng thực phẩm sống – chín; bảo quản đúng cách; dùng nước sạch.'],
  [3,'Nêu một số biện pháp an toàn lao động khi chế biến thực phẩm.','Cẩn thận khi dùng dao, dụng cụ sắc; đề phòng bỏng khi dùng bếp, nước sôi, dầu nóng; dùng điện an toàn; giữ sàn khô, không trơn trượt; đeo tạp dề, găng khi cần.'],
  [4,'Vì sao an toàn vệ sinh thực phẩm được coi là trách nhiệm của cả người chế biến và người tiêu dùng?','Người chế biến phải bảo đảm thực phẩm sạch, chế biến hợp vệ sinh; người tiêu dùng phải biết chọn, bảo quản, chế biến và ăn uống đúng cách. Chỉ khi cả hai cùng có ý thức thì mới phòng tránh được ngộ độc, bệnh tật, bảo vệ sức khỏe cộng đồng.']
 ]);
 add(M,9,'Bài 5: Dự án: Tính toán chi phí bữa ăn theo thực đơn',[
  [1,'Khi lập thực đơn cho bữa ăn, cần bảo đảm điều gì?','Đủ chất dinh dưỡng, phù hợp khẩu vị và chi phí','Chỉ cần nhiều món','Chỉ cần đắt tiền','Chỉ cần rẻ'],
  [1,'Để tính chi phí bữa ăn, cần biết thông tin gì?','Số lượng và giá của từng loại thực phẩm','Màu bát đĩa','Tên người nấu','Thời tiết'],
  [2,'Công cụ nào giúp tính toán chi phí bữa ăn nhanh, chính xác?','Bảng tính (phần mềm bảng tính)','Máy giặt','Quạt điện','Ti vi'],
  [2,'Vì sao cần tính toán chi phí bữa ăn hợp lí?','Để chi tiêu phù hợp, không lãng phí, vẫn đủ dinh dưỡng','Để tiêu nhiều hơn','Để bữa ăn thiếu chất','Không có lí do'],
  [2,'Khi chi phí vượt dự kiến, nên làm gì?','Điều chỉnh thực đơn, chọn thực phẩm phù hợp hơn nhưng vẫn đủ chất','Bỏ bữa','Vay tiền','Mua đồ đắt hơn'],
  [3,'Nêu các bước thực hiện dự án tính chi phí một bữa ăn theo thực đơn.','Lập thực đơn đủ chất; liệt kê các thực phẩm và số lượng cần; tìm giá từng loại; tính chi phí từng món và tổng; so với ngân sách; điều chỉnh nếu cần.'],
  [3,'Nêu lợi ích của việc tính toán chi phí bữa ăn.','Giúp chi tiêu hợp lí, cân đối ngân sách gia đình; tránh lãng phí; vẫn bảo đảm bữa ăn đủ chất; rèn kĩ năng quản lí tài chính và lập kế hoạch.'],
  [4,'Vì sao biết lập thực đơn và tính chi phí bữa ăn là kĩ năng cần thiết trong đời sống?','Vì ai cũng cần ăn uống hằng ngày với chi phí có hạn; biết lập thực đơn đủ chất và tính toán chi phí giúp chăm sóc sức khỏe gia đình, chi tiêu hợp lí, tiết kiệm, tránh lãng phí — là kĩ năng sống thiết thực và hữu ích lâu dài.']
 ]);
 add(M,9,'Bài 6: Chế biến thực phẩm có sử dụng nhiệt',[
  [1,'Chế biến thực phẩm có sử dụng nhiệt là gì?','Dùng nhiệt (lửa, điện...) làm chín thực phẩm','Trộn gỏi','Muối chua','Ngâm giấm'],
  [1,'Phương pháp nào là chế biến có sử dụng nhiệt?','Luộc, kho, rán, hấp, nướng','Trộn nộm','Muối dưa','Ngâm chua'],
  [2,'Luộc là phương pháp chế biến như thế nào?','Làm chín thực phẩm trong nước sôi','Rán trong dầu','Nướng trên lửa','Trộn với gia vị không nấu'],
  [2,'Khi rán (chiên) thực phẩm, cần lưu ý điều gì để an toàn?','Cẩn thận với dầu nóng, tránh bắn, bỏng','Để dầu tràn ra bếp','Cho nước vào chảo dầu đang sôi','Không cần cẩn thận'],
  [2,'Vì sao chế biến có sử dụng nhiệt giúp thực phẩm an toàn hơn?','Nhiệt tiêu diệt vi khuẩn, kí sinh trùng, dễ tiêu hóa','Làm thực phẩm bẩn hơn','Gây ngộ độc','Không có tác dụng'],
  [3,'Kể tên các phương pháp chế biến thực phẩm có sử dụng nhiệt và ví dụ.','Luộc (rau, thịt); kho (cá, thịt); rán/chiên (nem, cá); hấp (bánh, cá); nướng (thịt, bánh); xào (rau, thịt). Nhiệt làm chín và tạo hương vị món ăn.'],
  [3,'Nêu ưu điểm và lưu ý khi chế biến thực phẩm có sử dụng nhiệt.','Ưu điểm: làm chín, diệt khuẩn, dễ tiêu, ngon miệng. Lưu ý: nấu vừa chín tới để giữ chất dinh dưỡng; không để cháy khét (sinh chất độc); cẩn thận với lửa, dầu nóng, nước sôi để tránh bỏng.'],
  [4,'Vì sao khi chế biến bằng nhiệt không nên nấu quá kĩ hoặc để cháy khét thức ăn?','Nấu quá kĩ làm mất nhiều vi-ta-min và chất dinh dưỡng; thức ăn cháy khét sinh ra chất có hại cho sức khỏe. Nên nấu vừa chín tới, đúng cách để vừa an toàn, ngon vừa giữ được giá trị dinh dưỡng của thực phẩm.']
 ]);
 add(M,9,'Bài 7: Chế biến thực phẩm không sử dụng nhiệt',[
  [1,'Chế biến thực phẩm không sử dụng nhiệt là gì?','Chế biến món ăn không dùng nhiệt làm chín','Luộc, rán','Nướng','Kho'],
  [1,'Phương pháp nào là chế biến không sử dụng nhiệt?','Trộn (nộm/gỏi), muối chua, ngâm','Luộc','Rán','Hấp'],
  [2,'Món nộm (gỏi) được chế biến bằng cách nào?','Trộn các nguyên liệu với gia vị, không dùng nhiệt','Luộc chín','Rán giòn','Nướng'],
  [2,'Muối chua (dưa, cà) dựa vào quá trình nào?','Lên men nhờ vi khuẩn có lợi','Đun sôi','Chiên rán','Nướng than'],
  [2,'Khi chế biến món không dùng nhiệt, cần đặc biệt chú ý điều gì?','Vệ sinh an toàn thực phẩm (rửa sạch, nước sạch, dụng cụ sạch)','Dùng nguyên liệu bẩn','Không cần vệ sinh','Dùng nước bẩn'],
  [3,'Kể tên các phương pháp chế biến không sử dụng nhiệt và ví dụ.','Trộn (nộm rau, gỏi); muối chua (dưa cải, cà muối, kim chi); ngâm (ngâm giấm, ngâm đường). Giữ được độ giòn, hương vị tươi của nguyên liệu.'],
  [3,'Vì sao khi chế biến món ăn không sử dụng nhiệt cần đặc biệt chú ý vệ sinh?','Vì thực phẩm không qua nhiệt nên vi khuẩn không bị tiêu diệt; nếu nguyên liệu, nước, dụng cụ hoặc tay bẩn thì món ăn dễ nhiễm khuẩn, gây ngộ độc. Do đó phải rửa sạch, dùng nước và dụng cụ sạch, bảo đảm vệ sinh tuyệt đối.'],
  [4,'Vì sao các món chế biến không dùng nhiệt vẫn được ưa chuộng dù nguy cơ vệ sinh cao hơn?','Vì chúng giữ được độ tươi, giòn, hương vị tự nhiên và nhiều vi-ta-min (ít bị phá hủy bởi nhiệt); đa dạng món ăn, kích thích vị giác. Tuy nhiên cần bảo đảm vệ sinh an toàn thực phẩm nghiêm ngặt để phòng tránh ngộ độc.']
 ]);
 /* Chủ đề tổng hợp L9 */
 add(M,9,'Định hướng nghề nghiệp',[
  [1,'Nghề nào thuộc lĩnh vực chế biến thực phẩm?','Đầu bếp, kĩ sư công nghệ thực phẩm','Thợ điện','Lập trình viên','Kiến trúc sư'],
  [2,'Để chọn nghề phù hợp, cần căn cứ vào đâu?','Sở thích, năng lực bản thân và nhu cầu xã hội','Chọn theo bạn','Chọn ngẫu nhiên','Chọn nghề khó nhất'],
  [2,'Người làm nghề chế biến thực phẩm cần phẩm chất gì?','Sạch sẽ, cẩn thận, hiểu biết dinh dưỡng và an toàn vệ sinh','Ẩu','Mất vệ sinh','Coi thường an toàn'],
  [3,'Là học sinh, em cần chuẩn bị gì để định hướng nghề nghiệp tương lai?','Tìm hiểu bản thân (sở thích, năng lực); tìm hiểu các nghề và nhu cầu xã hội; học tốt, rèn kĩ năng; trải nghiệm, tham gia hoạt động hướng nghiệp.'],
  [4,'Vì sao định hướng nghề nghiệp sớm lại có lợi cho học sinh?','Giúp hiểu bản thân và các nghề, chọn hướng học tập, rèn luyện phù hợp; chuẩn bị kiến thức, kĩ năng cần thiết; tránh chọn nghề sai, bị động khi trưởng thành; chủ động cho tương lai.']
 ]);
 add(M,9,'Mô-đun công nghệ (trồng trọt/lắp đặt điện/chế biến…)',[
  [1,'Mô-đun công nghệ giúp học sinh điều gì?','Tìm hiểu, trải nghiệm một lĩnh vực nghề cụ thể (chế biến, trồng trọt, điện...)','Không giúp gì','Chỉ để chơi','Làm mất thời gian'],
  [2,'Khi thực hành một mô-đun công nghệ, cần bảo đảm điều gì?','An toàn lao động và vệ sinh','Làm ẩu','Không cần an toàn','Bỏ qua quy trình'],
  [2,'Trải nghiệm mô-đun nghề giúp học sinh định hướng điều gì?','Hiểu công việc, tự đánh giá sự phù hợp với nghề','Không liên quan nghề','Chỉ để điểm cao','Không có tác dụng'],
  [3,'Nêu lợi ích của việc học và trải nghiệm các mô-đun công nghệ.','Giúp hiểu kiến thức và kĩ năng của một nghề; rèn kĩ năng thực hành, thái độ lao động; khám phá sở thích, năng lực bản thân để định hướng nghề nghiệp phù hợp.'],
  [4,'Vì sao trải nghiệm thực tế qua các mô-đun giúp học sinh chọn nghề đúng hơn?','Qua thực hành, học sinh được tiếp xúc công việc thật, biết nghề đó làm gì, cần kĩ năng gì, có hợp với mình không; nhờ đó tự đánh giá đúng năng lực, sở thích và chọn nghề phù hợp hơn so với chỉ nghe nói hoặc tưởng tượng.']
 ]);
 add(M,9,'Dinh dưỡng, chế biến và nghề nghiệp',[
  [1,'Có mấy nhóm chất dinh dưỡng chính trong thực phẩm?','Bốn nhóm','Một nhóm','Hai nhóm','Sáu nhóm'],
  [2,'Phương pháp nào là chế biến có sử dụng nhiệt?','Luộc, kho, rán, hấp','Trộn gỏi','Muối chua','Ngâm giấm'],
  [2,'Khi chế biến món không dùng nhiệt, cần chú ý nhất điều gì?','Vệ sinh an toàn thực phẩm','Không cần vệ sinh','Dùng nguyên liệu bẩn','Dùng nước bẩn'],
  [3,'Nêu các nguyên tắc bảo đảm an toàn vệ sinh thực phẩm khi chế biến.','Chọn thực phẩm sạch; vệ sinh tay, dụng cụ, nơi chế biến; ăn chín, uống sôi; tách riêng sống – chín; bảo quản đúng; dùng nước sạch.'],
  [4,'Vì sao kiến thức về dinh dưỡng và chế biến thực phẩm hữu ích cho mọi người?','Vì ai cũng cần ăn uống hằng ngày; hiểu dinh dưỡng giúp ăn cân đối, khỏe mạnh; biết chọn, bảo quản, chế biến đúng giúp giữ chất, bảo đảm an toàn, phòng bệnh. Đây là kiến thức thiết thực cho sức khỏe bản thân và gia đình, cũng mở ra cơ hội nghề nghiệp.']
 ]);
 add(M,9,'Chế biến thực phẩm và an toàn',[
  [1,'Vì sao cần ăn chín, uống sôi?','Để tiêu diệt vi khuẩn, phòng ngộ độc và bệnh tật','Để mất chất','Cho đẹp mắt','Không có lí do'],
  [2,'Nguyên nhân gây ngộ độc thực phẩm là gì?','Thực phẩm ôi thiu, nhiễm khuẩn, tồn dư hóa chất, chế biến mất vệ sinh','Ăn chín uống sôi','Rửa tay sạch','Bảo quản lạnh đúng'],
  [2,'Khi chế biến, vì sao cần tách riêng thực phẩm sống và chín?','Tránh lây nhiễm vi khuẩn chéo từ sống sang chín','Cho đẹp','Cho nhanh','Không có lí do'],
  [3,'Nêu một số biện pháp phòng tránh ngộ độc thực phẩm.','Chọn thực phẩm tươi, an toàn; giữ vệ sinh khi chế biến; ăn chín uống sôi; tách sống – chín; bảo quản đúng cách; không ăn thực phẩm ôi, mốc, quá hạn.'],
  [4,'Vì sao bảo đảm an toàn vệ sinh thực phẩm là trách nhiệm chung của cả cộng đồng?','Vì thực phẩm liên quan đến sức khỏe và tính mạng mọi người; từ người sản xuất, chế biến đến người tiêu dùng đều phải có ý thức giữ vệ sinh. Chỉ một khâu mất an toàn cũng có thể gây ngộ độc hàng loạt; vì vậy bảo đảm an toàn thực phẩm là trách nhiệm chung.']
 ]);

 /* L9: bù lẻ chủ đề tổng hợp */
 add(M,9,'Định hướng nghề nghiệp',[
  [1,'Kĩ sư công nghệ thực phẩm thường làm công việc gì?','Nghiên cứu, cải tiến quy trình sản xuất, chế biến, bảo quản thực phẩm','Chỉ bán hàng','Chỉ lái xe','Chỉ trồng cây'],
  [3,'Nêu những yếu tố cần cân nhắc khi chọn nghề.','Sở thích và năng lực bản thân; nhu cầu xã hội và thị trường lao động; điều kiện gia đình; giá trị, triển vọng của nghề.']
 ]);
 add(M,9,'Mô-đun công nghệ (trồng trọt/lắp đặt điện/chế biến…)',[
  [1,'Mục đích chính của việc học các mô-đun công nghệ là gì?','Trải nghiệm, tìm hiểu kĩ năng của một lĩnh vực nghề để định hướng nghề nghiệp','Để nghỉ ngơi','Chỉ để chơi','Không có mục đích'],
  [3,'Nêu một số mô-đun công nghệ mà em có thể trải nghiệm ở lớp 9.','VD: chế biến thực phẩm, trồng trọt, lắp đặt điện trong nhà... Mỗi mô-đun giúp tìm hiểu kiến thức, kĩ năng của một lĩnh vực nghề.']
 ]);
 add(M,9,'Dinh dưỡng, chế biến và nghề nghiệp',[
  [3,'Kể tên 4 nhóm chất dinh dưỡng và vai trò mỗi nhóm.','Bột đường: cung cấp năng lượng; đạm: xây dựng, phát triển cơ thể; béo: dự trữ, cung cấp năng lượng; vi-ta-min và khoáng: tăng đề kháng, giúp cơ thể hoạt động bình thường.']
 ]);
 add(M,9,'Chế biến thực phẩm và an toàn',[
  [1,'Phương pháp nào là chế biến không sử dụng nhiệt?','Trộn gỏi, muối chua, ngâm','Luộc','Rán','Hấp'],
  [3,'Nêu ưu điểm và lưu ý khi chế biến thực phẩm có sử dụng nhiệt.','Ưu điểm: làm chín, diệt khuẩn, dễ tiêu, ngon miệng. Lưu ý: nấu vừa chín tới để giữ chất; không để cháy khét; cẩn thận lửa, dầu nóng, nước sôi để tránh bỏng.']
 ]);

})();
