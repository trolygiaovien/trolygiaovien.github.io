/* NGÂN HÀNG GIÁO DỤC THỂ CHẤT – LỚP 1–9 — bổ sung đủ chuẩn. Câu hỏi nguyên bản, bám SGK Kết nối tri thức. */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Giáo dục thể chất';

 /* ===== LỚP 1 ===== */
 add(M,1,'Đội hình đội ngũ',[
  [1,'Khi nghe khẩu lệnh "Nghiêm!", em đứng như thế nào?','hai chân thẳng, hai gót chân chạm nhau, hai tay buông thẳng, mắt nhìn thẳng','ngồi xổm xuống đất','hai tay chống hông, chân dang rộng','cúi đầu nhìn xuống chân'],
  [1,'Khi nghe khẩu lệnh "Nghỉ!", em làm gì?','đứng thoải mái, một chân hơi chùng gối','chạy quanh sân','ngồi xuống nghỉ','nằm ra sân'],
  [1,'Khẩu lệnh "Bên phải – quay!" yêu cầu em quay về bên nào?','bên phải','bên trái','quay ra sau','không quay'],
  [2,'Khi tập hợp hàng dọc, bạn đứng sau phải đứng ở đâu so với bạn đứng trước?','đứng thẳng ngay sau lưng bạn trước, cách một cánh tay','đứng bên cạnh bạn trước','đứng ở đâu cũng được','đứng quay lưng lại với bạn trước'],
  [2,'Khi dóng hàng ngang, em nhìn về phía nào để dóng cho thẳng?','nhìn về phía bạn đứng đầu hàng','nhìn lên trời','nhìn ra sau','nhìn xuống đất'],
  [2,'Khi nghe khẩu lệnh "Giải tán!", em làm gì?','rời khỏi hàng một cách trật tự','đứng nguyên tại chỗ','chạy xô đẩy bạn','hô to rồi ngồi xuống'],
  [3,'Em hãy kể tên ba khẩu lệnh đội hình đội ngũ mà em đã học ở lớp 1.','Ví dụ: "Nghiêm!", "Nghỉ!", "Bên phải – quay!", "Bên trái – quay!", "Thành một hàng dọc – tập hợp!", "Giải tán!".'],
  [3,'Nêu cách đứng đúng khi em ở tư thế nghiêm.','Người đứng thẳng, hai gót chân chạm nhau, hai bàn chân mở hình chữ V, hai tay duỗi thẳng áp sát thân, mắt nhìn thẳng, không nói chuyện.'],
  [3,'Khi tập hợp hàng dọc, em làm gì để hàng được thẳng và cách đều?','Đứng ngay sau lưng bạn trước, giơ tay trái chạm vai bạn trước để lấy khoảng cách rồi hạ tay xuống, nhìn thẳng gáy bạn trước.'],
  [4,'Vì sao khi tập đội hình đội ngũ, cả lớp cần làm theo khẩu lệnh cùng một lúc?','Vì khẩu lệnh giúp cả lớp cùng làm một động tác giống nhau. Nếu mỗi bạn làm một kiểu, hàng sẽ lộn xộn, dễ va vào nhau. Làm đúng và cùng lúc giúp lớp gọn gàng, trật tự, đẹp mắt và an toàn.']
 ]);
 add(M,1,'Vệ sinh và an toàn trong tập luyện',[
  [1,'Trước giờ học thể dục, em cần kiểm tra sân tập để làm gì?','xem có vật nhọn, gạch đá hay chỗ trơn trượt không để tránh bị thương','để chọn chỗ ngồi chơi','để tìm đồ chơi','không cần kiểm tra'],
  [1,'Khi tập thể dục, em nên đi loại giày nào?','giày thể thao vừa chân, buộc dây chắc chắn','dép lê','giày cao gót','đi chân đất trên sân sỏi'],
  [1,'Sau khi tập xong, tay chân bẩn, em cần làm gì?','rửa tay chân sạch sẽ bằng nước và xà phòng','cầm ngay đồ ăn','lau tay vào áo','không cần rửa'],
  [2,'Vì sao không nên ăn quá no ngay trước khi tập thể dục?','vì dễ bị đau bụng, khó chịu khi vận động','vì sẽ chạy nhanh hơn','vì sẽ hết đói','vì thầy cô không cho ăn'],
  [2,'Trong giờ học, nếu thấy bạn bị ngã và đau, em nên làm gì?','báo ngay cho thầy cô giáo','cười bạn','tiếp tục chơi','kéo bạn đứng dậy chạy tiếp ngay'],
  [2,'Em nên uống nước như thế nào khi tập luyện xong?','uống từng ngụm nhỏ, từ từ','uống thật nhiều một hơi','uống nước đá thật lạnh ngay','không uống nước'],
  [3,'Kể ba việc em cần làm để giữ an toàn trong giờ học thể dục.','Ví dụ: khởi động trước khi tập, đi giày thể thao, không xô đẩy bạn, không chạy ra ngoài khu vực tập, nghe theo hướng dẫn của thầy cô.'],
  [3,'Vì sao cần khởi động trước khi tập thể dục?','Khởi động giúp cơ thể nóng lên, các khớp và cơ dẻo dai hơn, khi tập không bị đau, không bị chuột rút hay bong gân.'],
  [3,'Em cần giữ vệ sinh cá nhân như thế nào sau giờ học thể dục?','Lau khô mồ hôi, rửa tay chân sạch sẽ, thay áo nếu bị ướt, uống nước từ từ, không ngồi ngay trước quạt mạnh.'],
  [4,'Bạn An đến giờ thể dục nhưng quên mang giày thể thao và đi dép lê. Theo em, bạn An có nên chạy nhảy cùng các bạn không? Vì sao?','Không nên. Dép lê dễ tuột, dễ trượt ngã, có thể làm bạn An hoặc bạn khác bị thương. Bạn An nên báo thầy cô để được hướng dẫn tập những bài nhẹ phù hợp và lần sau nhớ mang đủ giày tập.']
 ]);
 add(M,1,'Vận động cơ bản và trò chơi',[
  [1,'Khi đi thường, hai tay em làm gì?','vung nhẹ tự nhiên theo nhịp bước chân','giữ chặt sau lưng','giơ cao lên trời','cho vào túi quần'],
  [1,'Khi tập động tác "tay" trong bài thể dục, em cần làm gì?','đưa tay đúng hướng theo nhịp hô','nhắm mắt','ngồi xuống','chạy quanh sân'],
  [1,'Trong trò chơi "Mèo đuổi chuột", ai là người phải chạy trốn?','bạn làm chuột','bạn làm mèo','các bạn đứng vòng tròn','thầy cô giáo'],
  [2,'Khi đứng một chân giữ thăng bằng, em cần làm gì để không ngã?','đứng thẳng người, mắt nhìn thẳng, hai tay dang ngang','nhắm mắt, cúi đầu','nhảy lò cò liên tục','cúi gập người xuống'],
  [2,'Khi đi theo đường kẻ thẳng, em cần chú ý điều gì?','bước chân đặt đúng trên đường kẻ, mắt nhìn phía trước','nhìn chân bạn khác','chạy thật nhanh','bước ra ngoài đường kẻ'],
  [2,'Khi bị thua trong trò chơi vận động, em nên làm gì?','vui vẻ chúc mừng bạn và cố gắng ở lần sau','giận bạn và không chơi nữa','cãi nhau với bạn','bỏ về chỗ ngồi'],
  [3,'Kể tên các tư thế của đầu và cổ mà em đã tập.','Ví dụ: cúi đầu, ngửa đầu, nghiêng đầu sang trái, nghiêng đầu sang phải, quay đầu sang hai bên.'],
  [3,'Nêu cách chơi trò chơi "Nhảy ô tiếp sức".','Các bạn xếp hàng, lần lượt từng bạn nhảy chụm chân hoặc một chân qua các ô vẽ trên sân, tới đích rồi chạy về chạm tay bạn tiếp theo; đội xong trước và đúng luật thì thắng.'],
  [3,'Nêu hai điều em cần làm khi chơi trò chơi vận động cùng các bạn.','Ví dụ: chơi đúng luật, không xô đẩy bạn, biết nhường nhịn, chơi vui vẻ và đoàn kết.'],
  [4,'Vì sao khi chơi trò chơi vận động, em không được xô đẩy hay kéo bạn?','Vì xô đẩy, kéo bạn làm bạn dễ ngã, bị đau hoặc bị thương. Trò chơi là để vui và rèn sức khỏe, không phải để hơn thua. Chơi an toàn, đúng luật thì cả lớp đều vui và không ai bị đau.']
 ]);
 add(M,1,'Thói quen vận động hằng ngày',[
  [1,'Mỗi ngày em nên tập thể dục vào lúc nào là tốt?','buổi sáng sau khi ngủ dậy','khi đang ăn cơm','trước khi đi ngủ ngay lúc buồn ngủ','chỉ tập khi được điểm cao'],
  [1,'Việc nào dưới đây là vận động giúp em khỏe mạnh?','nhảy dây','xem ti vi cả ngày','nằm chơi điện thoại','ngủ cả buổi chiều'],
  [1,'Em nên ngồi học như thế nào để không bị cong lưng?','ngồi thẳng lưng, mắt cách vở khoảng một gang tay rưỡi đến hai gang tay','nằm ra bàn mà viết','gục đầu sát vở','ngồi vẹo người sang một bên'],
  [2,'Vì sao em nên ngủ đủ giấc mỗi ngày?','để cơ thể lớn nhanh, khỏe mạnh và học tập tốt','để không phải tập thể dục','để được xem phim nhiều hơn','để ăn ít hơn'],
  [2,'Sau khi ngồi học lâu, em nên làm gì?','đứng lên đi lại, vươn vai, vận động nhẹ','ngồi tiếp thêm thật lâu','nằm xuống sàn ngủ','ăn thật nhiều bánh kẹo'],
  [2,'Việc nào sau đây giúp em có thói quen vận động tốt?','đi bộ hoặc chơi vận động ngoài trời mỗi ngày','chỉ chơi điện tử trong nhà','ngồi một chỗ cả ngày','nhịn ăn để gầy đi'],
  [3,'Kể ba hoạt động vận động em có thể làm cùng gia đình vào buổi chiều.','Ví dụ: đi bộ, đạp xe, chơi đá cầu, nhảy dây, chơi bóng, tập bài thể dục cùng bố mẹ.'],
  [3,'Nêu lợi ích của việc tập thể dục buổi sáng hằng ngày.','Giúp cơ thể tỉnh táo, khỏe mạnh, mau lớn, ít bị ốm, vui vẻ và học tập tốt hơn.'],
  [3,'Em hãy kể những việc em làm mỗi sáng để bắt đầu một ngày khỏe mạnh.','Ví dụ: thức dậy đúng giờ, tập thể dục nhẹ, đánh răng rửa mặt, ăn sáng đủ, đi học đúng giờ.'],
  [4,'Bạn Nam thích ngồi xem ti vi và ít khi ra ngoài chơi. Em hãy nói cho bạn Nam biết vì sao nên vận động nhiều hơn.','Ngồi lâu xem ti vi làm mắt mỏi, lưng dễ cong và cơ thể yếu. Khi ra ngoài chạy nhảy, chơi bóng, nhảy dây, cơ thể sẽ khỏe mạnh, mau lớn, vui vẻ và ít bị ốm. Mỗi ngày bạn Nam nên dành ít nhất 30 phút để vận động cùng bạn bè hoặc gia đình.']
 ]);

 /* ===== LỚP 2 ===== */
 add(M,2,'Đội hình đội ngũ',[
  [1,'Khẩu lệnh "Thành hai hàng dọc – tập hợp!" yêu cầu lớp đứng thành mấy hàng dọc?','hai hàng','một hàng','ba hàng','bốn hàng'],
  [1,'Khi nghe khẩu lệnh "Đứng lại – đứng!", em làm gì?','bước thêm một bước rồi dừng, đứng nghiêm','chạy nhanh về đích','ngồi xuống','quay ra sau'],
  [1,'Khi giậm chân tại chỗ, em bắt đầu giậm bằng chân nào theo nhịp hô "một"?','chân trái','chân phải','cả hai chân cùng lúc','chân nào cũng được'],
  [2,'Khi đi đều, chân và tay phối hợp như thế nào?','chân trái bước thì tay phải vung ra trước, chân phải bước thì tay trái vung ra trước','chân trái bước thì tay trái vung ra trước','hai tay cùng vung ra trước','hai tay giữ im không vung'],
  [2,'Mục đích của động tác dóng hàng là gì?','để hàng thẳng và các bạn đứng cách đều nhau','để chạy nhanh hơn','để ngồi nghỉ','để đổi chỗ với bạn'],
  [2,'Khi nghe khẩu lệnh "Thôi!", em làm gì?','dừng động tác đang tập, trở về tư thế đứng nghiêm','làm nhanh hơn','ngồi xuống đất','chạy ra khỏi hàng'],
  [3,'Nêu cách chuyển từ một hàng dọc thành hai hàng dọc.','Lớp điểm số 1–2 đến hết; khi có khẩu lệnh, các bạn số 2 bước sang bên cạnh (hoặc theo hướng dẫn) để đứng ngang với bạn số 1, tạo thành hai hàng dọc thẳng và cách đều.'],
  [3,'Nêu cách thực hiện động tác giậm chân tại chỗ.','Nghe khẩu lệnh "Giậm chân tại chỗ – giậm!", em nhấc chân trái lên trước theo nhịp "một", rồi chân phải theo nhịp "hai", tay vung tự nhiên phối hợp với chân; nghe "Đứng lại – đứng!" thì giậm thêm một nhịp rồi dừng.'],
  [3,'Khi tập hợp hàng ngang, em dóng hàng bằng cách nào?','Đứng ngang hàng với bạn bên cạnh, nhìn về phía bạn đầu hàng, dang tay trái chạm vai bạn bên cạnh để lấy khoảng cách rồi hạ tay xuống.'],
  [4,'Vì sao khi đi đều, cả hàng phải bước cùng một chân theo cùng một nhịp?','Vì khi cả hàng bước cùng chân, cùng nhịp thì hàng sẽ đều, đẹp và không ai bị giẫm chân hay va vào nhau. Nếu mỗi bạn bước một kiểu, hàng sẽ rối, dễ vấp ngã. Đi đều cũng rèn cho em tính kỉ luật và biết phối hợp với bạn.']
 ]);
 add(M,2,'Vệ sinh và an toàn trong tập luyện',[
  [1,'Dụng cụ tập luyện như bóng, vòng, dây sau khi dùng xong cần làm gì?','cất đúng nơi quy định','vứt ở sân','ném vào nhau để chơi','mang về nhà'],
  [1,'Trang phục tập thể dục cần có đặc điểm gì?','gọn gàng, thoáng mát, dễ vận động','thật đẹp và nhiều phụ kiện','áo dài tay dày và bó','quần áo rộng lùng thùng, dài quét đất'],
  [1,'Khi trời nắng gắt, tập ngoài trời em cần làm gì?','đội mũ, uống đủ nước, tập ở chỗ có bóng mát nếu có','cởi áo ra tập','nhịn uống nước','chạy thật lâu dưới nắng'],
  [2,'Vì sao không được tập luyện ở nơi sân trơn, ướt?','vì dễ trượt chân, ngã và bị thương','vì sân sẽ nhanh khô hơn','vì chạy sẽ nhanh hơn','vì sẽ làm bẩn sân'],
  [2,'Nếu đang tập mà thấy chóng mặt, buồn nôn, em nên làm gì?','dừng tập, ngồi nghỉ nơi thoáng mát và báo thầy cô','cố gắng tập tiếp','chạy thật nhanh về lớp','uống nhiều nước đá'],
  [2,'Việc nào dưới đây giúp phòng tránh chấn thương khi tập?','khởi động kĩ và tập đúng động tác thầy cô hướng dẫn','tập thật nhanh cho xong','đùa nghịch trong khi tập','tập ngay khi vừa ăn no'],
  [3,'Kể những việc em cần chuẩn bị trước giờ học thể dục.','Mặc trang phục thể thao, đi giày tập, buộc gọn tóc, bỏ các vật nhọn trong túi, mang nước uống, kiểm tra sân tập an toàn.'],
  [3,'Nêu các bước khởi động đơn giản trước khi tập.','Xoay các khớp cổ, vai, hông, gối, cổ chân; chạy nhẹ tại chỗ hoặc đi bộ nhanh; vươn vai, ép dẻo nhẹ nhàng.'],
  [3,'Vì sao sau khi tập luyện em không nên ngồi ngay trước quạt mạnh hoặc tắm nước lạnh?','Vì lúc đó cơ thể còn nóng và ra nhiều mồ hôi, gặp lạnh đột ngột dễ bị cảm, ốm. Em nên lau khô mồ hôi, nghỉ một lúc rồi mới tắm.'],
  [4,'Trong giờ thể dục, bạn Lan muốn chạy thi với bạn trên sân có nhiều sỏi và một vũng nước. Em sẽ khuyên bạn Lan điều gì? Vì sao?','Em khuyên bạn Lan không chạy thi ở đó vì sỏi dễ làm trượt chân, vũng nước làm sân trơn, chạy nhanh rất dễ ngã và bị thương. Hai bạn nên chọn chỗ sân khô, bằng phẳng, không có vật cản hoặc nhờ thầy cô chỉ chỗ an toàn để chơi.']
 ]);
 add(M,2,'Vận động cơ bản và trò chơi',[
  [1,'Khi chạy, bàn chân em tiếp đất bằng phần nào là đúng?','nửa trước bàn chân (gần các ngón chân)','gót chân thật mạnh','cạnh ngoài bàn chân','cả bàn chân dập mạnh xuống'],
  [1,'Khi bật nhảy tại chỗ, em tiếp đất như thế nào để không bị đau?','tiếp đất bằng nửa trước bàn chân, gối hơi khuỵu','tiếp đất bằng gót chân, chân thẳng cứng','ngã người ra sau','tiếp đất bằng một chân rồi ngồi xuống'],
  [1,'Trong trò chơi "Bịt mắt bắt dê", bạn bịt mắt phải làm gì?','tìm và bắt các bạn khác bằng cách nghe tiếng động','chạy thật nhanh ra khỏi vòng','mở mắt để nhìn bạn','đứng yên không di chuyển'],
  [2,'Khi đi kiễng gót, bộ phận nào của bàn chân chạm đất?','nửa trước bàn chân','gót chân','cả bàn chân','mép ngoài bàn chân'],
  [2,'Khi tung và bắt bóng bằng hai tay, mắt em cần nhìn vào đâu?','nhìn theo quả bóng','nhìn xuống chân','nhìn sang bạn bên cạnh','nhắm mắt lại'],
  [2,'Trò chơi vận động nào dưới đây giúp rèn sức mạnh của tay và sự đoàn kết?','kéo co','nhảy lò cò','đi kiễng gót','đi theo đường kẻ'],
  [3,'Nêu cách thực hiện động tác đi kiễng gót.','Đứng thẳng, nhấc gót chân lên, đi bằng nửa trước bàn chân, thân người thẳng, hai tay dang ngang hoặc chống hông để giữ thăng bằng, mắt nhìn thẳng.'],
  [3,'Nêu cách chơi trò chơi "Kéo co".','Hai đội đứng hai bên dây, mỗi bạn nắm chắc dây, chân trụ vững; khi có hiệu lệnh, cả đội cùng kéo dây về phía mình; đội kéo được vạch giữa dây qua vạch bên mình thì thắng.'],
  [3,'Kể hai bài tập giúp em rèn luyện sự khéo léo của đôi tay.','Ví dụ: tung và bắt bóng bằng hai tay, chuyền bóng cho bạn, lăn bóng theo đường kẻ, tung bóng lên cao rồi bắt.'],
  [4,'Vì sao khi chạy, em nên tiếp đất bằng nửa trước bàn chân và gối hơi chùng thay vì đập cả gót chân xuống?','Vì nửa trước bàn chân và gối chùng giúp giảm lực va chạm xuống chân, chạy nhẹ nhàng, êm và nhanh hơn. Nếu đập gót chân mạnh, chân sẽ nhanh mỏi, dễ đau gót, đau gối và dễ bị thương.']
 ]);
 add(M,2,'Thói quen vận động hằng ngày',[
  [1,'Mỗi ngày em nên dành ít nhất bao nhiêu thời gian để vận động?','khoảng 30 phút đến 1 giờ','5 phút là đủ','không cần vận động','chỉ vận động vào ngày nghỉ'],
  [1,'Hoạt động nào dưới đây là vận động tốt cho sức khỏe?','đi bộ đến trường cùng bố mẹ','ngồi chơi điện thoại','nằm xem phim','ngủ nướng đến trưa'],
  [1,'Trong ngày, em nên uống đủ nước như thế nào?','uống nước nhiều lần trong ngày, kể cả khi chưa khát lắm','chỉ uống khi rất khát','chỉ uống nước ngọt','không cần uống nước'],
  [2,'Khi xem ti vi hoặc dùng máy tính lâu, em nên làm gì để bảo vệ mắt và cơ thể?','nghỉ sau mỗi 20–30 phút, đứng lên vận động, nhìn ra xa','xem liên tục nhiều giờ','ngồi sát màn hình','nằm xem trong bóng tối'],
  [2,'Vì sao em nên ăn sáng trước khi đi học và tập thể dục?','để có đủ năng lượng học tập và vận động','để không phải ăn trưa','để tăng cân thật nhanh','vì ăn sáng giúp bỏ bữa tối'],
  [2,'Khi mang cặp sách, em nên đeo như thế nào để không bị lệch vai?','đeo cả hai dây trên hai vai, cặp không quá nặng','đeo một bên vai','xách bằng một tay','kéo lê trên đất'],
  [3,'Kể ba thói quen giúp cơ thể em khỏe mạnh mỗi ngày.','Ví dụ: tập thể dục buổi sáng, ăn đủ bữa, uống đủ nước, ngủ đủ giấc, giữ vệ sinh sạch sẽ, chơi vận động ngoài trời.'],
  [3,'Nêu một số hoạt động vận động em có thể làm trong giờ ra chơi.','Ví dụ: nhảy dây, đá cầu, chơi trò chơi vận động với bạn, đi lại, vươn vai, không ngồi lì trong lớp.'],
  [3,'Vì sao không nên vận động mạnh ngay sau khi ăn no?','Vì sau khi ăn, dạ dày đang làm việc để tiêu hóa thức ăn; chạy nhảy mạnh lúc này dễ bị đau bụng, buồn nôn, khó chịu. Nên nghỉ khoảng 1–2 giờ rồi mới tập.'],
  [4,'Em hãy giải thích vì sao nói "Ăn đủ, ngủ đủ, vận động đủ" giúp em lớn khỏe.','Ăn đủ cung cấp chất dinh dưỡng để cơ thể lớn lên. Ngủ đủ giúp cơ thể nghỉ ngơi, não và cơ bắp phục hồi. Vận động đủ giúp xương chắc, cơ khỏe, tim phổi hoạt động tốt và tinh thần vui vẻ. Ba việc này cùng nhau giúp em cao lớn, khỏe mạnh và học tốt.']
 ]);

 /* ===== LỚP 3 ===== */
 add(M,3,'Đội hình đội ngũ',[
  [1,'Khẩu lệnh "Đằng sau – quay!" yêu cầu em quay về hướng nào?','quay ra phía sau (quay 180 độ)','quay sang bên phải','quay sang bên trái','không quay, chỉ cúi đầu'],
  [1,'Khi đi đều, khẩu lệnh để cả hàng bắt đầu đi là gì?','"Đi đều – bước!"','"Giải tán!"','"Nghỉ!"','"Thôi!"'],
  [1,'Khi nghe khẩu lệnh "Thành vòng tròn – tập hợp!", lớp sẽ đứng theo đội hình nào?','vòng tròn','hàng dọc','hàng ngang','hai hàng ngang'],
  [2,'Khi thực hiện động tác quay đằng sau, em quay theo hướng nào?','quay về bên phải, lấy gót chân phải và mũi chân trái làm trụ','quay về bên trái tùy ý','nhảy lên rồi quay','quay bằng cách chạy một vòng'],
  [2,'Mục đích của động tác dàn hàng là gì?','để các bạn trong hàng cách nhau một khoảng rộng hơn, đủ chỗ tập bài thể dục','để đứng sát vào nhau','để kết thúc giờ học','để chạy nhanh hơn'],
  [2,'Khi dồn hàng, em di chuyển như thế nào?','bước về phía bạn đứng đầu hàng để đứng sát lại khoảng cách quy định','chạy ra khỏi hàng','đứng yên tại chỗ','bước lùi ra sau xa bạn'],
  [3,'Nêu cách thực hiện động tác quay đằng sau.','Nghe dự lệnh "Đằng sau" và động lệnh "quay!", em dùng gót chân phải và nửa trước bàn chân trái làm trụ, quay người về bên phải ra sau 180 độ, sau đó đưa chân trái về sát chân phải thành tư thế nghiêm.'],
  [3,'Nêu cách thực hiện động tác dàn hàng ngang.','Theo khẩu lệnh "Em A làm chuẩn, cách một (hoặc hai) cánh tay – dàn hàng!", các bạn lần lượt bước sang bên, dang tay chạm tay bạn để lấy khoảng cách, rồi hạ tay, đứng thẳng hàng với bạn làm chuẩn.'],
  [3,'Kể tên các đội hình mà em đã học ở lớp 3.','Ví dụ: hàng dọc, hàng ngang, nhiều hàng dọc, nhiều hàng ngang, vòng tròn.'],
  [4,'Vì sao trong khẩu lệnh thường có hai phần (dự lệnh và động lệnh), ví dụ "Bên phải – quay!"?','Dự lệnh ("Bên phải") báo trước cho cả lớp biết sắp làm động tác gì để chuẩn bị; động lệnh ("quay!") là lúc tất cả cùng thực hiện. Nhờ vậy cả lớp làm đồng loạt, đúng và đều, không bạn nào làm sớm hoặc làm sai hướng.']
 ]);
 add(M,3,'Vệ sinh và an toàn trong tập luyện',[
  [1,'Khi tập với dụng cụ (vòng, gậy, bóng), em cần chú ý điều gì?','giữ khoảng cách với bạn để không va vào nhau','đứng sát vào bạn','ném dụng cụ vào bạn','vừa tập vừa đùa nghịch'],
  [1,'Môi trường tập luyện nào là an toàn?','sân bằng phẳng, sạch, thoáng, không có vật sắc nhọn','sân ướt trơn','gần đường xe chạy','nơi có nhiều gạch đá vỡ'],
  [1,'Em cần làm gì với tóc dài trước khi tập luyện?','buộc gọn gàng','để xõa tự nhiên','cài nhiều kẹp sắt nhọn','không cần quan tâm'],
  [2,'Vì sao cần thả lỏng (hồi tĩnh) sau khi tập luyện?','để cơ thể dần trở về trạng thái bình thường, giảm mỏi cơ','để tập được lâu hơn','để tăng nhịp tim','để ra nhiều mồ hôi hơn'],
  [2,'Khi trời nắng nóng, dấu hiệu nào cho biết em cần dừng tập ngay?','chóng mặt, hoa mắt, buồn nôn, da đỏ và rất nóng','ra một ít mồ hôi','thở nhanh hơn một chút','thấy khát nước'],
  [2,'Việc nào sau đây đúng khi tập luyện vào mùa đông?','mặc đủ ấm, khởi động kĩ hơn, cởi dần áo khi đã nóng người','mặc áo cộc tay ngay từ đầu dù rất lạnh','không cần khởi động vì trời lạnh','tập xong ngồi ngay chỗ gió lùa'],
  [3,'Nêu ba quy tắc an toàn khi tập luyện với dụng cụ.','Kiểm tra dụng cụ trước khi dùng; giữ khoảng cách với bạn; không dùng dụng cụ để ném, đánh nhau; dùng xong cất đúng chỗ.'],
  [3,'Kể một số dấu hiệu cho thấy em đang tập quá sức.','Thở gấp, chóng mặt, hoa mắt, mặt tái, buồn nôn, đau nhói ở ngực hoặc bụng, chân tay run. Khi đó cần dừng tập, nghỉ ngơi và báo thầy cô.'],
  [3,'Vì sao phải uống đủ nước khi tập luyện, nhất là trời nóng?','Khi tập, cơ thể ra nhiều mồ hôi và mất nước. Thiếu nước làm mệt, chóng mặt, dễ bị chuột rút, say nắng. Nên uống từng ngụm nhỏ trước, trong và sau khi tập.'],
  [4,'Phân tích tác hại của việc bỏ qua khởi động và thả lỏng trong một buổi tập.','Bỏ khởi động thì cơ và khớp còn cứng, dễ bị bong gân, căng cơ, chuột rút khi vận động mạnh. Bỏ thả lỏng thì cơ thể từ trạng thái hoạt động mạnh dừng đột ngột, dễ chóng mặt, mỏi cơ kéo dài, hồi phục chậm. Vì vậy một buổi tập đầy đủ phải có khởi động – tập chính – thả lỏng.']
 ]);
 add(M,3,'Vận động cơ bản và trò chơi',[
  [1,'Khi nhảy dây cá nhân, em tiếp đất bằng bộ phận nào?','nửa trước bàn chân, gối hơi khuỵu','gót chân','cả bàn chân dập mạnh','đầu gối'],
  [1,'Khi bật xa tại chỗ, hai tay vung như thế nào để nhảy xa hơn?','vung mạnh từ sau ra trước lên cao khi bật','giữ im hai bên người','chống hông','cho vào túi'],
  [1,'Trong trò chơi "Chuyền bóng tiếp sức", đội thắng là đội nào?','chuyền bóng đến bạn cuối cùng nhanh nhất và không làm rơi bóng','làm rơi bóng nhiều nhất','la hét to nhất','có nhiều bạn nhất'],
  [2,'Khi di chuyển lăng chân, mắt em nên nhìn vào đâu?','nhìn thẳng phía trước để giữ thăng bằng','nhìn xuống chân','nhìn lên trời','nhìn sang hai bên'],
  [2,'Khi tung bóng và bắt bóng bằng một tay, em cần làm gì để bắt được bóng?','mắt nhìn theo bóng, tay đưa ra đón bóng đúng lúc','nhắm mắt đoán hướng bóng','quay lưng lại bóng','giữ tay sát người'],
  [2,'Tư thế nào đúng khi chạy nhanh về đích?','người hơi ngả về trước, tay vung mạnh, chạy thẳng hướng','người ngả ra sau, chạy ngoằn ngoèo','dừng lại trước vạch đích','nhìn ra sau bạn chạy phía sau'],
  [3,'Nêu cách thực hiện bật xa tại chỗ.','Đứng hai chân rộng bằng vai, hơi khuỵu gối, hai tay đưa ra sau; bật mạnh hai chân đồng thời vung tay ra trước lên cao; trên không gập thân; tiếp đất bằng hai chân, gối khuỵu, hai tay đưa ra trước giữ thăng bằng.'],
  [3,'Nêu cách nhảy dây cá nhân kiểu chụm hai chân.','Hai tay cầm hai đầu dây, dây để sau chân; quay dây từ sau lên trên ra trước bằng cổ tay; khi dây gần chạm đất thì bật nhẹ hai chân chụm qua dây, tiếp đất bằng nửa trước bàn chân; nhảy đều theo nhịp dây.'],
  [3,'Kể tên hai trò chơi vận động em đã học ở lớp 3 và nêu tác dụng của chúng.','Ví dụ: "Chuyền bóng tiếp sức" rèn khéo léo và phối hợp; "Chạy tiếp sức" rèn tốc độ và tinh thần đồng đội; "Lò cò tiếp sức" rèn sức mạnh chân và thăng bằng.'],
  [4,'Vì sao khi bật xa, động tác vung tay và khuỵu gối trước khi bật lại giúp em nhảy xa hơn?','Khuỵu gối giúp cơ chân co lại như một chiếc lò xo, khi bật sẽ tạo lực đẩy mạnh hơn. Vung tay từ sau ra trước lên cao kéo cả thân người về phía trước và lên trên, giúp thân bay xa hơn. Hai động tác phối hợp đúng lúc nên lực bật lớn và đúng hướng.']
 ]);
 add(M,3,'Thể thao tự chọn',[
  [1,'Trong môn bóng đá, bộ phận nào của bàn chân thường dùng để chuyền bóng gần, chính xác?','má trong bàn chân','gót chân','ngón chân','mu bàn chân ngoài'],
  [1,'Trong bóng rổ, động tác đưa bóng đi bằng cách đập xuống sân liên tục gọi là gì?','dẫn bóng','sút bóng','đánh đầu','phát cầu'],
  [1,'Quả cầu lông được đánh bằng dụng cụ gì?','vợt cầu lông','chân','gậy','tay không'],
  [2,'Khi dẫn bóng trong bóng đá, em cần chú ý điều gì?','đẩy bóng nhẹ, bóng luôn ở gần chân, mắt quan sát phía trước','đá bóng thật xa rồi chạy theo','dùng tay ôm bóng chạy','nhắm mắt đá'],
  [2,'Khi dẫn bóng trong bóng rổ, em dùng bộ phận nào của tay để điều khiển bóng?','các đầu ngón tay, phối hợp cổ tay đẩy bóng xuống sàn (không dùng lòng bàn tay đập mạnh)','nắm tay đấm bóng','khuỷu tay','lòng bàn tay vỗ mạnh xuống bóng'],
  [2,'Trong đá cầu, khi tâng cầu bằng đùi, mắt em nhìn vào đâu?','nhìn theo quả cầu','nhìn xuống đất','nhìn sang bạn','nhắm mắt'],
  [3,'Nêu cách đá bóng bằng má trong bàn chân.','Đặt chân trụ cạnh bóng, hướng mũi chân về phía mục tiêu; chân đá vung từ sau ra trước, bàn chân xoay ngang, dùng má trong tiếp xúc vào giữa quả bóng; sau khi đá chân tiếp tục đưa theo hướng bóng đi.'],
  [3,'Nêu tư thế chuẩn bị cơ bản trong môn cầu lông.','Hai chân rộng bằng vai hoặc chân trước chân sau, gối hơi khuỵu, thân người hơi ngả về trước, tay cầm vợt đưa ra trước ngang ngực, mắt nhìn theo cầu.'],
  [3,'Kể ba môn thể thao tự chọn mà em biết và một kĩ năng cơ bản của mỗi môn.','Ví dụ: bóng đá – dẫn bóng; bóng rổ – dẫn bóng, ném rổ; cầu lông – cầm vợt, đánh cầu; đá cầu – tâng cầu; bơi – thở nước, nổi người.'],
  [4,'Vì sao khi mới học bóng đá, thầy cô thường dạy em chuyền bóng bằng má trong trước các kiểu đá khác?','Vì má trong bàn chân có diện tích tiếp xúc với bóng rộng và phẳng, dễ điều khiển hướng bóng, bóng đi chính xác, lực vừa phải và an toàn cho bàn chân. Học kĩ thuật này trước giúp em có cảm giác bóng tốt, rồi mới học sút bằng mu bàn chân hay má ngoài khó hơn.']
 ]);
 add(M,3,'Thói quen vận động hằng ngày',[
  [1,'Hoạt động nào dưới đây giúp rèn luyện sức bền?','đi bộ hoặc chạy nhẹ đều đặn mỗi ngày','ngồi xem phim nhiều giờ','ngủ nhiều hơn 12 giờ mỗi ngày','ăn nhiều đồ ngọt'],
  [1,'Em nên tập thể dục với mức độ như thế nào?','vừa sức, tăng dần từ nhẹ đến nặng','thật nặng ngay từ ngày đầu','chỉ tập khi có người nhắc','tập đến khi kiệt sức'],
  [1,'Sau khi tập thể dục xong, em thấy khát, em nên làm gì?','uống nước lọc từ từ từng ngụm','uống nước ngọt có ga thật nhiều','không uống nước','uống nước đá thật lạnh một hơi'],
  [2,'Vì sao nên hạn chế ngồi lâu một chỗ trong ngày?','vì ngồi lâu làm cơ thể ít vận động, dễ mỏi lưng, cong vẹo cột sống và tăng cân','vì ngồi lâu sẽ cao nhanh hơn','vì ngồi lâu làm chân khỏe hơn','vì ngồi lâu giúp ngủ ngon'],
  [2,'Khi lập thời gian biểu tập luyện, em cần chú ý điều gì?','chọn giờ cố định, nội dung phù hợp sức mình và thực hiện đều đặn','tập thật nhiều trong một ngày rồi nghỉ cả tuần','chỉ tập khi thấy thích','tập vào lúc đang ăn'],
  [2,'Việc nào dưới đây giúp em có giấc ngủ tốt?','đi ngủ đúng giờ, không dùng điện thoại trước khi ngủ','xem phim đến khuya','ăn thật no ngay trước khi ngủ','chạy nhảy mạnh ngay trước khi ngủ'],
  [3,'Lập một thời gian biểu vận động trong một ngày của em.','Ví dụ: 6 giờ tập thể dục buổi sáng 15 phút; giờ ra chơi nhảy dây, đá cầu; 17 giờ đi bộ hoặc chơi bóng cùng bạn 30 phút; tối vươn vai thả lỏng trước khi ngủ.'],
  [3,'Nêu lợi ích của việc đi bộ hoặc đạp xe đến trường (khi an toàn).','Giúp rèn sức bền, chân khỏe, tim phổi hoạt động tốt, tinh thần tỉnh táo, bảo vệ môi trường và tiết kiệm.'],
  [3,'Theo em, thế nào là một thói quen vận động tốt?','Là việc vận động được thực hiện đều đặn mỗi ngày, vào giờ cố định, phù hợp với sức của mình, an toàn và mang lại niềm vui, sức khỏe.'],
  [4,'Em hãy giải thích vì sao tập thể dục đều đặn mỗi ngày 20 phút tốt hơn là tập thật nhiều trong một ngày rồi nghỉ cả tuần.','Cơ thể cần được vận động thường xuyên để cơ, xương, tim và phổi quen dần và khỏe lên từng ngày. Tập quá nhiều trong một lần dễ bị đau cơ, quá sức, chấn thương, rồi nghỉ lâu thì cơ thể lại yếu đi. Tập đều đặn vừa sức giúp hình thành thói quen tốt, tiến bộ bền vững và an toàn hơn.']
 ]);

 /* ===== LỚP 4 ===== */
 add(M,4,'Đội hình đội ngũ',[
  [1,'Khẩu lệnh "Vòng bên phải – bước!" dùng khi nào?','khi hàng đang đi đều cần chuyển hướng sang bên phải','khi lớp cần ngồi xuống','khi kết thúc giờ học','khi tập hợp hàng ngang'],
  [1,'Khi đổi chân trong lúc đi đều sai nhịp, em làm gì?','bước đệm một bước ngắn để đổi chân cho đúng nhịp','dừng lại hẳn rồi đi tiếp','nhảy lên hai chân','chạy vượt lên trước hàng'],
  [1,'Khi đi đều, khoảng cách giữa bạn trước và bạn sau nên như thế nào?','cách đều nhau, khoảng một cánh tay','sát nhau không có khoảng cách','xa tùy ý','mỗi bạn một kiểu'],
  [2,'Khi hàng dọc đang đi đều, muốn cả hàng chuyển hướng đi ngược lại, dùng khẩu lệnh nào?','"Bên trái (hoặc bên phải) vòng đằng sau – bước!"','"Đứng lại – đứng!"','"Nghiêm!"','"Giải tán!"'],
  [2,'Bạn đứng đầu hàng (bạn làm chuẩn) có nhiệm vụ gì khi tập hợp?','đứng đúng vị trí và tư thế để các bạn khác lấy làm chuẩn dóng hàng','ra khẩu lệnh thay thầy cô','chạy đi gọi các bạn','đứng cuối hàng'],
  [2,'Khi quay phải hoặc quay trái, lấy bộ phận nào làm trụ?','gót chân cùng bên hướng quay và nửa trước bàn chân bên kia','cả hai gót chân','hai đầu gối','mũi chân cùng bên hướng quay'],
  [3,'Nêu cách thực hiện động tác đi đều vòng bên phải.','Khi nghe khẩu lệnh "Vòng bên phải – bước!", bạn đầu hàng bước ngắn và vòng dần sang phải, các bạn phía sau vẫn đi đều và lần lượt vòng theo đúng vị trí bạn trước đã vòng, giữ hàng thẳng và khoảng cách đều.'],
  [3,'Nêu các bước chuyển từ đội hình hàng ngang thành đội hình vòng tròn.','Theo khẩu lệnh, bạn làm chuẩn đứng yên hoặc di chuyển theo hướng dẫn, các bạn còn lại lần lượt đi theo đường vòng nối tiếp nhau rồi dừng lại khi tạo thành vòng tròn, dóng cách đều nhau.'],
  [3,'Theo em, người chỉ huy (hô khẩu lệnh) cần làm gì để lớp tập hợp nhanh và đúng?','Hô to, rõ, dứt khoát; chia đúng dự lệnh và động lệnh; đứng ở vị trí mọi người đều nhìn thấy; quan sát và sửa cho các bạn.'],
  [4,'Khi đội hình nhiều hàng dọc đi đều vòng bên phải (hoặc bên trái), vì sao bạn ở hàng phía trong (sát tâm vòng) phải bước ngắn hơn còn bạn ở hàng phía ngoài phải bước dài hơn?','Vì khi vòng, các hàng phải đi theo các đường cong có độ dài khác nhau nhưng vẫn phải giữ hàng ngang thẳng và đều: hàng ở gần tâm vòng đi quãng ngắn hơn nên bước ngắn, hàng ở xa tâm đi quãng dài hơn nên bước dài, tất cả vẫn giữ cùng một nhịp. Nhờ đó cả đội hình cùng hoàn thành vòng mà không bị xô lệch hay đứt hàng.']
 ]);
 add(M,4,'Vệ sinh và an toàn trong tập luyện',[
  [1,'Trước khi tập, việc kiểm tra dụng cụ như dây nhảy, bóng, vòng nhằm mục đích gì?','phát hiện dụng cụ hỏng, rách để tránh gây thương tích','để chọn dụng cụ đẹp nhất','để cất bớt dụng cụ','không có mục đích'],
  [1,'Khi bị trầy xước nhẹ trong giờ tập, em nên làm gì đầu tiên?','báo thầy cô, rửa sạch vết thương bằng nước sạch','tiếp tục chạy cho quên đau','bôi đất lên vết thương','giấu không cho ai biết'],
  [1,'Em nên ăn nhẹ trước giờ tập khoảng bao lâu?','khoảng 1–2 giờ trước khi tập','ngay trước lúc tập','không được ăn gì cả ngày','ăn thật no 5 phút trước khi tập'],
  [2,'Khi tập ngoài trời vào lúc nắng gắt, em nên làm gì?','đội mũ, tập ở nơi có bóng mát, uống nước đều và không tập quá lâu','cởi áo tập cho mát','tập đến khi ra thật nhiều mồ hôi','nhịn uống nước để không bị đau bụng'],
  [2,'Ý nào sau đây là biểu hiện của say nắng?','mặt đỏ, đau đầu, chóng mặt, buồn nôn, da nóng','thấy hơi đói','ra một ít mồ hôi ở trán','thở nhanh hơn bình thường một chút'],
  [2,'Khi bạn bị chuột rút ở bắp chân, em có thể giúp bạn bằng cách nào?','cho bạn ngồi nghỉ, nhẹ nhàng kéo duỗi bàn chân về phía ống chân và xoa bóp bắp chân','bắt bạn chạy tiếp','bỏ mặc bạn','đập mạnh vào bắp chân bạn'],
  [3,'Nêu các bước xử lí khi em hoặc bạn bị bong gân nhẹ ở cổ chân khi tập.','Dừng tập ngay, báo thầy cô; ngồi nghỉ, kê cao chân; chườm lạnh vùng sưng; không cố đi lại hay xoa bóp mạnh; nếu đau nhiều, sưng to cần đến cơ sở y tế.'],
  [3,'Nêu cách phòng tránh say nắng, say nóng khi tập luyện ngoài trời.','Tập vào lúc trời mát (sáng sớm, chiều muộn); đội mũ, mặc đồ thoáng; uống đủ nước; nghỉ giữa giờ ở chỗ mát; dừng tập khi thấy chóng mặt, đau đầu.'],
  [3,'Vì sao cần vệ sinh sân tập và dụng cụ tập luyện thường xuyên?','Sân sạch không có vật nhọn, rác thì tránh được trượt ngã, đâm vào chân; dụng cụ sạch giúp phòng bệnh lây qua tay, da; đồng thời rèn thói quen giữ gìn của chung.'],
  [4,'Phân tích vì sao khi bị bong gân không nên tiếp tục tập hay xoa bóp mạnh ngay lúc đó.','Khi bong gân, dây chằng ở khớp bị tổn thương và đang sưng, chảy máu bên trong. Tiếp tục tập làm tổn thương nặng hơn, lâu khỏi. Xoa bóp mạnh lúc này làm máu chảy nhiều hơn, chỗ sưng to hơn và đau hơn. Vì vậy phải nghỉ, chườm lạnh, kê cao chân và báo người lớn.']
 ]);
 add(M,4,'Vận động cơ bản và trò chơi',[
  [1,'Khi chạy theo đường dích dắc (chạy đổi hướng), em cần làm gì?','hạ thấp trọng tâm, bước ngắn khi đổi hướng, mắt nhìn phía trước','chạy thật nhanh theo đường thẳng','nhắm mắt chạy','dừng hẳn ở mỗi chỗ đổi hướng'],
  [1,'Khi ném bóng vào đích bằng một tay, tay cầm bóng vung từ đâu?','từ phía sau lên trên ra trước','từ dưới chân lên','từ bên hông ngang ra','không vung tay, chỉ đẩy'],
  [1,'Khi nhảy dây tập thể, các bạn quay dây cần làm gì?','quay dây đều, nhịp nhàng, cùng tốc độ','quay thật nhanh bất ngờ','mỗi bạn quay một nhịp','dừng dây đột ngột'],
  [2,'Khi di chuyển kết hợp tung và bắt bóng, mắt em nhìn vào đâu?','nhìn theo bóng, kết hợp quan sát đường di chuyển','chỉ nhìn xuống chân','nhìn sang bạn bên cạnh','nhìn cố định vào một điểm trên đất'],
  [2,'Trong chạy tiếp sức, khi trao vật tiếp sức, bạn chạy sau nên làm gì?','đưa tay ra sau đón, nhận vật tiếp sức rồi chạy ngay, không dừng lại','đứng yên chờ bạn chạy đến đưa tận tay rồi mới chạy','chạy ngược về phía bạn','ném vật tiếp sức cho bạn tiếp theo'],
  [2,'Khi bật nhảy qua chướng ngại vật thấp, em tiếp đất bằng cách nào để an toàn?','tiếp đất bằng hai chân, nửa trước bàn chân, gối khuỵu','tiếp đất bằng gót chân, chân thẳng','tiếp đất bằng một chân rồi ngồi bệt','ngã người ra sau'],
  [3,'Nêu cách thực hiện ném bóng trúng đích bằng một tay trên vai.','Đứng chân trước chân sau, tay cầm bóng đưa ra sau lên cao ngang đầu; mắt nhìn đích; dùng sức thân người và tay vung bóng ra trước, cổ tay vẩy để bóng bay đúng hướng; sau khi ném, chân sau bước lên giữ thăng bằng.'],
  [3,'Nêu cách chơi và luật chơi của trò chơi "Chạy tiếp sức".','Lớp chia thành các đội xếp hàng dọc; bạn đầu chạy đến đích rồi quay về trao vật tiếp sức cho bạn tiếp theo; lần lượt cho đến hết; đội xong trước, không phạm luật (không chạy trước khi nhận vật tiếp sức, không làm rơi vật) thì thắng.'],
  [3,'Kể tên hai bài tập rèn khả năng phối hợp vận động mà em đã học.','Ví dụ: di chuyển tung và bắt bóng; chạy đổi hướng theo tín hiệu; nhảy dây tập thể; bật nhảy qua chướng ngại vật rồi chạy.'],
  [4,'Vì sao khi chạy đổi hướng, hạ thấp trọng tâm và bước ngắn lại giúp em không bị ngã?','Hạ thấp trọng tâm làm cơ thể vững hơn, khó bị mất thăng bằng khi quay người. Bước ngắn giúp chân luôn ở gần dưới thân, dễ phanh và đẩy sang hướng mới. Nếu chạy nhanh, bước dài rồi đổi hướng đột ngột, theo đà cơ thể sẽ bị văng ra ngoài và dễ trượt ngã.']
 ]);
 add(M,4,'Thể thao tự chọn',[
  [1,'Trong bóng đá, động tác dừng bóng để giữ bóng lại gần chân gọi là gì?','dừng bóng (khống chế bóng)','sút bóng','ném biên','phát bóng'],
  [1,'Trong bóng rổ, động tác dùng hai tay ném bóng vào rổ từ trước ngực gọi là gì?','ném rổ bằng hai tay trước ngực','dẫn bóng','chuyền bóng bật đất','cản phá'],
  [1,'Trong môn bơi, kĩ năng quan trọng nhất cần học đầu tiên là gì?','làm quen với nước, tập thở và nổi người','bơi thật nhanh','nhảy cầu','lặn sâu'],
  [2,'Trong cầu lông, khi phát cầu, quả cầu phải bay qua đâu?','qua lưới sang phần sân của đối phương','xuống đất phía sân mình','ra ngoài sân','vào người đối phương'],
  [2,'Khi chuyền bóng rổ bằng hai tay trước ngực, em đẩy bóng ra bằng cách nào?','duỗi hai tay, lật cổ tay và miết các ngón tay để bóng đi thẳng tới bạn','ném bóng lên trời','đập bóng xuống đất thật mạnh','ôm bóng chạy tới đưa cho bạn'],
  [2,'Khi tâng cầu bằng mu bàn chân (đá cầu), em cần làm gì?','nhìn theo cầu, nâng chân nhẹ đưa mu bàn chân chạm đúng đế cầu','đá thật mạnh cho cầu bay xa','nhắm mắt đoán vị trí cầu','dùng tay ném cầu lên'],
  [3,'Nêu cách thực hiện động tác dừng bóng lăn sệt bằng lòng bàn chân (bóng đá).','Đứng chân trụ hơi khuỵu, nhìn bóng lăn tới; chân dừng bóng nhấc lên, bàn chân xoay ngang, lòng bàn chân đón bóng và hơi kéo về sau để bóng dừng êm trước mặt.'],
  [3,'Nêu các bước ném rổ bằng hai tay trước ngực.','Đứng hai chân rộng bằng vai, gối hơi khuỵu, hai tay cầm bóng trước ngực; mắt nhìn rổ; duỗi chân, đồng thời đẩy hai tay lên cao ra trước, cổ tay miết để bóng bay theo đường vòng cung vào rổ.'],
  [3,'Nêu ba quy tắc an toàn khi học bơi.','Chỉ bơi khi có người lớn hoặc thầy cô giám sát; khởi động kĩ trước khi xuống nước; không bơi khi đói, quá no hoặc mệt; không chạy đùa quanh bể; bơi ở khu vực có độ sâu phù hợp.'],
  [4,'Vì sao khi ném rổ, bóng bay theo đường vòng cung lại dễ vào rổ hơn là ném thẳng?','Vì rổ nằm ngang và cao trên đầu, bóng bay vòng cung sẽ rơi xuống từ trên cao, miệng rổ "mở" rộng hơn so với đường bóng nên dễ lọt vào. Bóng ném thẳng, bay ngang dễ đập vào vành rổ hoặc bảng rồi bật ra. Đường vòng cung còn giúp bóng đi chậm lại khi tới rổ, giảm bật ra.']
 ]);
 add(M,4,'Thói quen vận động hằng ngày',[
  [1,'Khi tự tập luyện ở nhà, em nên chọn nơi tập như thế nào?','rộng rãi, bằng phẳng, thoáng, không có vật dễ vỡ hay sắc nhọn','trong phòng chật có nhiều đồ đạc','trên cầu thang','gần bếp đang nấu'],
  [1,'Hoạt động nào dưới đây giúp cơ thể phát triển chiều cao tốt?','nhảy dây, bơi, chơi bóng rổ kết hợp ăn uống đủ chất','ngồi lâu một chỗ','thức khuya chơi game','bỏ bữa sáng'],
  [1,'Bữa ăn giúp em vận động tốt cần có gì?','đủ các nhóm chất: bột đường, chất đạm, chất béo, vitamin và khoáng chất','chỉ toàn đồ ngọt','chỉ nước ngọt có ga','chỉ ăn thịt, không ăn rau'],
  [2,'Vì sao em nên vận động ngoài trời vào buổi sáng sớm?','vì không khí trong lành, ánh nắng dịu giúp cơ thể tổng hợp vitamin D tốt cho xương','vì buổi sáng có nhiều người xem','vì sẽ không phải học bài','vì sáng sớm không cần khởi động'],
  [2,'Việc nào dưới đây thể hiện em biết tự chăm sóc sức khỏe?','tự giác tập thể dục mỗi sáng và ngủ đúng giờ','chỉ tập khi bố mẹ nhắc nhiều lần','ăn vặt thay cơm','xem điện thoại đến khuya'],
  [2,'Khi tự tập, em thấy đau nhói ở một khớp, em nên làm gì?','dừng tập, nghỉ ngơi và nói với người lớn','cố tập tiếp cho hết bài','tập mạnh hơn để hết đau','giấu không nói với ai'],
  [3,'Lập kế hoạch tự tập luyện buổi sáng trong một tuần của em.','Ví dụ: mỗi sáng 6 giờ, 15–20 phút: khởi động 3 phút; bài thể dục 8 động tác; nhảy dây 2 phút; chạy nhẹ quanh sân 3 phút; thả lỏng 2 phút; ghi lại cảm nhận mỗi ngày.'],
  [3,'Kể những việc nên và không nên làm trước khi đi ngủ để có sức khỏe tốt.','Nên: vệ sinh cá nhân, vận động nhẹ thả lỏng, ngủ đúng giờ, phòng ngủ thoáng. Không nên: ăn quá no, dùng điện thoại, xem phim khuya, vận động mạnh ngay trước khi ngủ.'],
  [3,'Nêu lợi ích của việc tham gia các hoạt động thể thao cùng bạn bè.','Rèn sức khỏe, học cách phối hợp và tinh thần đồng đội, biết tôn trọng luật chơi, vui vẻ, giảm căng thẳng, có thêm bạn tốt.'],
  [4,'Vì sao vận động hợp lí kết hợp ăn uống đủ chất và ngủ đủ giấc lại giúp em phát triển chiều cao?','Vận động như nhảy, chạy, bơi kích thích xương dài ra và chắc hơn. Ăn đủ chất, nhất là chất đạm, canxi và vitamin D, cung cấp nguyên liệu để xương phát triển. Ngủ đủ và đúng giờ là lúc cơ thể tiết nhiều hoóc-môn tăng trưởng nhất. Ba yếu tố này hỗ trợ nhau nên thiếu một yếu tố thì chiều cao sẽ phát triển kém hơn.']
 ]);

 /* ===== LỚP 5 ===== */
 add(M,5,'Đội hình đội ngũ',[
  [1,'Khi đi đều, nghe khẩu lệnh "Đứng lại – đứng!", em dừng như thế nào?','động lệnh "đứng!" rơi vào chân phải, em bước thêm một bước chân trái rồi đưa chân phải lên đứng nghiêm','dừng ngay lập tức bất kì chân nào','chạy thêm vài bước rồi dừng','ngồi xuống'],
  [1,'Trong đội hình đội ngũ, "cự li" là gì?','khoảng cách giữa người đứng trước và người đứng sau trong hàng dọc','độ dài của sân tập','số người trong hàng','tốc độ đi đều'],
  [1,'Trong đội hình đội ngũ, "giãn cách" là gì?','khoảng cách giữa hai người đứng cạnh nhau trong hàng ngang','khoảng cách từ hàng đến thầy cô','thời gian nghỉ giữa hai bài tập','chiều cao của người đứng đầu'],
  [2,'Khi điểm số theo tổ trong đội hình nhiều hàng dọc, bạn nào bắt đầu điểm số?','bạn đứng đầu mỗi hàng, điểm số "một", các bạn sau tiếp theo','bạn cuối hàng','thầy cô','bạn nào cũng được'],
  [2,'Khi đi đều, nhận thấy mình bước sai nhịp so với hàng, em nên làm gì?','thực hiện động tác đổi chân khi đi đều để kịp nhịp','dừng lại rồi chạy đuổi theo','tiếp tục đi sai nhịp','nhảy lò cò để đổi chân'],
  [2,'Khi đi đều, tay vung đến đâu là phù hợp?','tay trước vung đến ngang thắt lưng, tay sau vung thẳng tự nhiên','hai tay giơ cao quá đầu','hai tay buông thõng không vung','hai tay chống hông'],
  [3,'Nêu cách thực hiện động tác đổi chân khi đi đều sai nhịp.','Khi thấy sai nhịp, em bước một bước đệm ngắn (chân sau kéo lên sát gót chân trước rồi bước tiếp bằng chân trước) để đổi chân, sau đó tiếp tục đi đều đúng nhịp hô với cả hàng.'],
  [3,'Nêu cách thực hiện động tác đi đều, đứng lại.','Nghe "Đi đều – bước!" bắt đầu bước bằng chân trái theo nhịp "một – hai", tay vung tự nhiên; nghe "Đứng lại – đứng!" (động lệnh rơi vào chân phải), bước thêm một bước chân trái rồi thu chân phải về đứng nghiêm.'],
  [3,'Hãy nêu vai trò của việc tập đội hình đội ngũ đối với học sinh.','Rèn tính kỉ luật, trật tự, tác phong nhanh nhẹn; giúp lớp di chuyển, tập hợp nhanh gọn, an toàn; rèn khả năng phối hợp tập thể và tư thế đúng.'],
  [4,'Vì sao khẩu lệnh "Đứng lại – đứng!" phải hô động lệnh "đứng!" đúng vào lúc chân phải chạm đất?','Vì theo quy định đi đều bắt đầu bằng chân trái; khi động lệnh rơi vào chân phải, em bước thêm một bước chân trái rồi thu chân phải về là vừa đủ hai nhịp để cả hàng dừng cùng lúc, đúng chân và không ai bị lỡ bước. Nếu hô vào chân trái, các bạn sẽ dừng lệch nhịp nhau, hàng không đều.']
 ]);
 add(M,5,'Vệ sinh và an toàn trong tập luyện',[
  [1,'Trước khi tập, nên kiểm tra sức khỏe bản thân như thế nào?','xem mình có đang mệt, sốt, đau hay vừa ăn quá no không','không cần kiểm tra','chỉ cần soi gương','chỉ hỏi bạn bên cạnh'],
  [1,'Khi tập luyện ra nhiều mồ hôi, quần áo ướt, em nên làm gì sau buổi tập?','lau khô người, thay quần áo khô sạch','mặc nguyên đồ ướt cả ngày','ngồi trước quạt mạnh cho khô','tắm nước lạnh ngay'],
  [1,'Khi bạn bị chảy máu cam trong giờ tập, em nên làm gì?','cho bạn ngồi, hơi cúi đầu về trước, bóp nhẹ cánh mũi và báo thầy cô','bảo bạn ngửa đầu ra sau thật lâu','để bạn tiếp tục chạy','nhét giấy sâu vào mũi bạn'],
  [2,'Vì sao không nên tập luyện khi đang bị sốt hoặc mệt?','vì cơ thể đang yếu, tập sẽ làm bệnh nặng hơn và dễ gặp nguy hiểm','vì tập lúc ốm sẽ nhanh khỏe hơn','vì thầy cô sẽ không chấm điểm','vì sẽ lây bệnh cho dụng cụ'],
  [2,'Khi tập luyện trong nhà tập, điều nào sau đây là đúng?','giữ sàn sạch, khô; không chạy đùa gần cửa kính, cột, tường','để dụng cụ bừa bãi trên sàn','tập ngay dưới quạt trần đang quay thấp','đóng kín cửa cho ấm khi trời nóng'],
  [2,'Việc nào sau đây giúp bảo vệ cột sống khi tập luyện và sinh hoạt?','giữ lưng thẳng khi ngồi, đứng, nâng vật; không mang vác quá nặng','gù lưng khi ngồi học','xách cặp một bên vai','cúi gập lưng nâng vật nặng'],
  [3,'Nêu các việc cần làm để phòng tránh chấn thương trong tập luyện thể dục thể thao.','Khởi động kĩ; tập đúng kĩ thuật, vừa sức; mặc trang phục và đi giày phù hợp; kiểm tra sân bãi, dụng cụ; không đùa nghịch; dừng tập khi mệt; thả lỏng sau tập.'],
  [3,'Nêu cách sơ cứu ban đầu khi bạn bị ngã trầy xước chân, chảy ít máu.','Rửa vết thương bằng nước sạch; dùng gạc hoặc khăn sạch ấn nhẹ cầm máu; sát trùng nếu có; băng nhẹ; báo thầy cô hoặc người lớn; không bôi đất, lá cây lên vết thương.'],
  [3,'Theo em, vì sao giữ vệ sinh cá nhân sau tập luyện lại quan trọng?','Mồ hôi, bụi bẩn bám trên da nếu không rửa sẽ gây ngứa, nấm da, mùi hôi, dễ bị bệnh; thay đồ khô tránh bị cảm lạnh; giữ cơ thể sạch sẽ, khỏe mạnh và tự tin.'],
  [4,'Phân tích tác hại của việc tập luyện quá sức và cách nhận biết để điều chỉnh.','Tập quá sức làm cơ thể mệt mỏi kéo dài, đau cơ, dễ chấn thương, mất ngủ, chán ăn, học tập kém, thậm chí ngất xỉu. Nhận biết qua dấu hiệu: thở gấp không nói được, chóng mặt, buồn nôn, tim đập quá nhanh, hôm sau vẫn rất đau mỏi. Khi đó cần giảm khối lượng tập, nghỉ ngơi, ăn uống và ngủ đủ rồi tăng dần trở lại.']
 ]);
 add(M,5,'Vận động cơ bản và trò chơi',[
  [1,'Khi chạy, để chạy nhanh hơn em cần làm gì?','đạp sau tích cực, nâng cao đùi, tay vung mạnh theo nhịp chân','chạy bước thật ngắn và chậm','hai tay ôm ngực','nhìn xuống đất suốt quãng chạy'],
  [1,'Khi bật cao với tay chạm vật trên cao, em bật bằng mấy chân?','hai chân, kết hợp vung tay lên cao','chỉ một chân, tay giữ im','không cần bật, chỉ với tay','bật bằng gót chân'],
  [1,'Trong trò chơi "Ném trúng đích", đội thắng là đội nào?','ném trúng đích nhiều lần nhất và đúng luật','ném xa nhất ra ngoài sân','ném nhanh nhất không cần trúng','có nhiều bạn hô to nhất'],
  [2,'Khi nhảy dây kiểu chân trước chân sau, em cần giữ nhịp như thế nào?','đổi chân đều theo nhịp quay dây, tiếp đất nhẹ bằng nửa trước bàn chân','nhảy thật cao mỗi lần','chụm hai chân cứng','dừng dây sau mỗi lần nhảy'],
  [2,'Khi phối hợp chạy – bật nhảy qua vật cản thấp, bước cuối trước khi bật cần như thế nào?','bước ngắn, nhanh, hạ thấp trọng tâm để tạo lực bật','bước thật dài và chậm','dừng hẳn rồi bật','bước lùi lại một bước'],
  [2,'Khi chơi trò chơi vận động theo đội, điều quan trọng nhất là gì?','phối hợp, tôn trọng luật chơi và an toàn cho bạn','thắng bằng mọi cách','chỉ một bạn giỏi chơi','không cần nghe hiệu lệnh'],
  [3,'Nêu kĩ thuật cơ bản của động tác chạy nhanh (chạy cự li ngắn) ở lớp 5.','Thân người hơi ngả về trước; đạp sau mạnh, nâng cao đùi; chân tiếp đất bằng nửa trước bàn chân; tay co khuỷu vung mạnh theo nhịp chân, ngược chiều với chân; mắt nhìn thẳng phía trước; chạy thẳng hướng về đích không giảm tốc sớm.'],
  [3,'Nêu cách thực hiện bật cao chạm vật treo trên cao.','Đứng chân rộng bằng vai, hơi khuỵu gối, hai tay hạ thấp ra sau; bật mạnh hai chân đồng thời vung tay lên cao, thân vươn thẳng, tay chạm vật; tiếp đất bằng hai chân, gối khuỵu để giảm chấn động.'],
  [3,'Thiết kế một trò chơi vận động đơn giản cho nhóm 10 bạn và nêu luật chơi.','Ví dụ: "Chuyền bóng qua đầu – qua chân": chia 2 đội 5 bạn đứng hàng dọc, chuyền bóng lần lượt qua đầu rồi qua chân; bạn cuối nhận bóng chạy lên đầu hàng; đội xong trước, không rơi bóng thì thắng. Luật: không bỏ cách bạn, rơi bóng phải nhặt và chuyền lại từ bạn đó.'],
  [4,'Vì sao khi chạy nhanh, động tác vung tay lại giúp em chạy nhanh hơn và giữ thăng bằng tốt hơn?','Tay và chân vung ngược chiều nhau giúp cân bằng lực xoay của thân khi chân đạp sau, nên thân không bị vặn, chạy thẳng hướng. Vung tay mạnh và đúng nhịp còn kéo theo nhịp chân nhanh hơn, tăng tần số bước. Nếu tay giữ im hoặc vung lệch, thân sẽ lắc, mất sức và chạy chậm lại.']
 ]);
 add(M,5,'Thể thao tự chọn',[
  [1,'Trong bóng đá, cú đá bằng mu bàn chân thường dùng để làm gì?','sút bóng mạnh, chuyền bóng xa','dừng bóng','ném biên','phát bóng bằng tay'],
  [1,'Trong bóng rổ, động tác đưa bóng đến bạn bằng cách đập bóng xuống sân một lần gọi là gì?','chuyền bóng bật đất','dẫn bóng','ném rổ','cướp bóng'],
  [1,'Trong cầu lông, cú đánh cầu từ dưới thấp đưa cầu bay cao sang sân đối phương gọi là gì?','đánh cầu thấp tay (đánh cầu từ dưới)','đập cầu','bỏ nhỏ','đánh cầu cao tay trên đầu'],
  [2,'Khi phát cầu thấp tay trong cầu lông, điểm tiếp xúc giữa vợt và cầu ở đâu?','phía trước thân, dưới thắt lưng','trên đầu','sau lưng','ngang vai'],
  [2,'Trong đá cầu, kĩ thuật nào giúp đưa cầu sang sân đối phương khi cầu ở tầm thấp?','đá cầu bằng mu bàn chân hoặc má trong','đánh đầu','dùng tay đập','ôm cầu chạy'],
  [2,'Trong bơi ếch, hai chân thực hiện động tác nào?','co chân, bẻ bàn chân, đạp nước ra sau rồi khép lại','đập chân lên xuống liên tục như bơi sải','giữ chân thẳng không cử động','đạp xe đạp trong nước'],
  [3,'Nêu kĩ thuật đá bóng bằng mu bàn chân (mu chính diện).','Chạy đà thẳng hướng, chân trụ đặt cạnh bóng; chân đá vung từ sau ra trước, mũi chân duỗi xuống, dùng mu bàn chân tiếp xúc vào giữa phía sau bóng; thân hơi ngả về trước, sau khi đá chân tiếp tục theo hướng bóng.'],
  [3,'Nêu cách thực hiện chuyền bóng bật đất trong bóng rổ.','Hai tay cầm bóng trước ngực, bước một chân về phía bạn; đẩy bóng xuống sân sao cho bóng chạm đất ở khoảng hai phần ba quãng đường rồi bật lên ngang hông bạn nhận; cổ tay miết, ngón tay hướng theo bóng.'],
  [3,'Nêu các quy định cơ bản để chơi cầu lông (đánh đơn) đúng luật.','Mỗi lần giao cầu chỉ được đánh một lần; cầu phải bay qua lưới vào phần sân đối phương; cầu chạm đất là mất điểm; không để cầu chạm người, chạm lưới khi đang đánh; thi đấu tính điểm, bên ghi điểm sẽ phát cầu.'],
  [4,'So sánh đá bóng bằng má trong và bằng mu bàn chân: khi nào nên dùng kĩ thuật nào? Vì sao?','Má trong có mặt tiếp xúc rộng, bóng đi chính xác nhưng lực không mạnh, nên dùng khi chuyền gần, dứt điểm gần cầu môn cần chính xác. Mu bàn chân có lực mạnh, bóng đi xa và nhanh nhưng khó chính xác hơn, nên dùng khi sút xa, chuyền dài, phá bóng. Chọn đúng kĩ thuật giúp đường bóng phù hợp với mục đích chơi.']
 ]);
 add(M,5,'Thói quen vận động hằng ngày',[
  [1,'Theo khuyến nghị, học sinh nên vận động với mức độ vừa đến mạnh mỗi ngày ít nhất bao lâu?','khoảng 60 phút','5 phút','không cần vận động hằng ngày','chỉ 10 phút mỗi tuần'],
  [1,'Hoạt động nào sau đây vừa rèn sức bền vừa an toàn với lứa tuổi em?','chạy bộ nhẹ, đạp xe, bơi','nâng tạ thật nặng','chạy thi dưới trời nắng gắt lúc giữa trưa','thức khuya tập đến mệt lả'],
  [1,'Khi ngồi học hoặc dùng máy tính, bao lâu em nên đứng lên vận động một lần?','khoảng 30–45 phút một lần','3–4 giờ một lần','không cần đứng lên','chỉ khi tan học'],
  [2,'Vì sao cần cân đối giữa học tập, vận động và nghỉ ngơi?','để cơ thể khỏe, tinh thần thoải mái, học tập hiệu quả và tránh căng thẳng','để có nhiều thời gian chơi game hơn','để không phải tập thể dục','để ăn nhiều hơn'],
  [2,'Việc nào thể hiện lối sống lành mạnh?','ăn đủ chất, ngủ đủ 9–11 giờ mỗi đêm, vận động mỗi ngày, hạn chế đồ uống có ga','ăn vặt thay bữa chính','thức đến 1 giờ sáng xem phim','uống nước ngọt thay nước lọc'],
  [2,'Khi theo dõi kết quả tập luyện của mình, em có thể ghi lại điều gì?','số lần, thời gian tập, cảm nhận cơ thể và sự tiến bộ qua từng tuần','chỉ ghi tên các bạn cùng tập','không cần ghi gì','chỉ ghi khi bị điểm kém'],
  [3,'Xây dựng kế hoạch rèn luyện thể lực trong một tuần cho bản thân.','Ví dụ: Thứ 2, 4, 6: chạy nhẹ 10 phút + nhảy dây 3 lượt x 1 phút; Thứ 3, 5: bài thể dục + bật cao, chống đẩy vừa sức; Thứ 7: chơi thể thao tự chọn 45 phút; Chủ nhật: đi bộ, đạp xe cùng gia đình. Mỗi buổi đều khởi động và thả lỏng.'],
  [3,'Nêu các yếu tố giúp hình thành thói quen vận động lâu dài.','Chọn hoạt động mình yêu thích; đặt mục tiêu nhỏ, phù hợp; tập vào giờ cố định; tập cùng bạn bè hoặc gia đình; ghi lại sự tiến bộ; tự khen khi hoàn thành.'],
  [3,'Theo em, vì sao học sinh lớp 5 cần hạn chế thời gian dùng điện thoại, máy tính để vận động nhiều hơn?','Ngồi lâu với màn hình gây mỏi mắt, cận thị, cong vẹo cột sống, ít vận động dẫn đến thừa cân, kém sức bền; dành thời gian vận động giúp khỏe mạnh, tỉnh táo, học tập tốt và giao tiếp với bạn bè nhiều hơn.'],
  [4,'Vận dụng kiến thức đã học, hãy giải thích vì sao một thời gian biểu tốt phải có cả vận động, học tập, ăn uống và nghỉ ngơi hợp lí.','Học tập cần sự tập trung, nếu kéo dài không nghỉ sẽ mệt và kém hiệu quả. Vận động giúp máu lưu thông, não tỉnh táo, cơ thể khỏe nên học tốt hơn. Ăn uống đủ chất cung cấp năng lượng cho cả học và tập. Nghỉ ngơi, ngủ đủ giúp cơ thể phục hồi và lớn lên. Thiếu một yếu tố thì các yếu tố khác đều bị ảnh hưởng, nên cần sắp xếp cân đối trong ngày.']
 ]);

 /* ===== LỚP 6 ===== */
 add(M,6,'Kiến thức chung về thể dục thể thao',[
  [1,'Theo em, các tố chất thể lực cơ bản gồm những gì?','sức nhanh, sức mạnh, sức bền, mềm dẻo và khả năng phối hợp vận động','chiều cao, cân nặng, màu da','trí nhớ, tính toán, ngôn ngữ','sở thích, thói quen, tính cách'],
  [1,'Một bữa ăn hợp lí cho người tập luyện cần có đủ các nhóm chất nào?','chất bột đường, chất đạm, chất béo, vitamin và chất khoáng','chỉ chất đạm và chất béo','chỉ đường và muối','chỉ vitamin'],
  [1,'Nên ăn bữa chính trước khi tập luyện khoảng bao lâu?','khoảng 1,5–2 giờ','ngay trước khi tập 5 phút','không ăn gì cả ngày tập','ăn thật no rồi tập ngay'],
  [2,'Vì sao người tập luyện thể dục thể thao cần uống đủ nước?','vì khi vận động cơ thể mất nước qua mồ hôi, thiếu nước gây mệt, chuột rút, giảm khả năng vận động','vì nước làm tăng cân nhanh','vì uống nhiều nước thay được bữa ăn','vì nước giúp cơ to lên ngay'],
  [2,'Nguyên tắc "tập luyện vừa sức" có nghĩa là gì?','khối lượng và cường độ tập phù hợp với sức khỏe, lứa tuổi, trình độ của bản thân','tập càng nặng càng tốt','chỉ tập khi thấy thích','tập giống hoàn toàn vận động viên chuyên nghiệp'],
  [2,'Tác dụng của tập luyện thể dục thể thao đối với hệ hô hấp là gì?','phổi khỏe hơn, hít thở sâu hơn, cơ thể nhận được nhiều ô-xi hơn','phổi nhỏ lại','thở nhanh và nông hơn khi nghỉ','không có tác dụng gì'],
  [3,'Nêu lợi ích của tập luyện thể dục thể thao thường xuyên đối với cơ thể và tinh thần.','Cơ thể: tim, phổi khỏe; cơ, xương chắc; phát triển chiều cao; tăng sức đề kháng; vóc dáng cân đối. Tinh thần: giảm căng thẳng, vui vẻ, tự tin, ngủ ngon, học tập tập trung hơn; rèn ý chí, kỉ luật, tinh thần đồng đội.'],
  [3,'Nêu chế độ dinh dưỡng hợp lí trong một ngày có tập luyện thể dục thể thao.','Ăn đủ 3 bữa chính, bữa sáng đầy đủ; đủ 4 nhóm chất, nhiều rau xanh và trái cây; uống 1,5–2 lít nước, uống thêm trước – trong – sau tập; ăn trước tập 1,5–2 giờ; sau tập ăn nhẹ có chất đạm và bột đường; hạn chế đồ chiên rán, nước ngọt có ga.'],
  [3,'Nêu các nguyên tắc cơ bản khi tự tập luyện thể dục thể thao.','Tập thường xuyên, đều đặn; tăng dần khối lượng từ nhẹ đến nặng; tập vừa sức; tập toàn diện nhiều nhóm cơ và tố chất; luôn khởi động và thả lỏng; chú ý an toàn, vệ sinh.'],
  [4,'Vì sao bữa sáng và việc uống nước đủ lại ảnh hưởng trực tiếp đến hiệu quả tập luyện của học sinh trong giờ Giáo dục thể chất?','Bữa sáng cung cấp năng lượng (chủ yếu từ chất bột đường) cho não và cơ bắp hoạt động; bỏ bữa sáng dễ bị hạ đường huyết, hoa mắt, chóng mặt, ngất khi vận động. Nước giúp điều hòa thân nhiệt và vận chuyển dinh dưỡng; thiếu nước làm mệt nhanh, dễ chuột rút, say nóng. Vì vậy học sinh ăn sáng đủ và uống đủ nước sẽ tập bền hơn, tập trung hơn và an toàn hơn.']
 ]);
 add(M,6,'Kĩ thuật và luật cơ bản',[
  [1,'Khẩu lệnh xuất phát trong chạy cự li ngắn là gì?','"Vào chỗ! – Sẵn sàng! – Chạy!"','"Nghiêm! – Nghỉ! – Chạy!"','"Chuẩn bị! – Đi!"','"Một! – Hai! – Ba!"'],
  [1,'Kĩ thuật chạy cự li ngắn gồm mấy giai đoạn?','4 giai đoạn: xuất phát, chạy lao sau xuất phát, chạy giữa quãng, về đích','2 giai đoạn: chạy và dừng','3 giai đoạn: đi, chạy, nghỉ','5 giai đoạn: khởi động, chạy, nghỉ, ăn, ngủ'],
  [1,'Trong kĩ thuật ném bóng (bóng nhỏ) xa, bóng được giữ bằng bộ phận nào?','các ngón tay, không nắm chặt vào lòng bàn tay','lòng bàn tay nắm thật chặt','hai tay ôm bóng','khuỷu tay kẹp bóng'],
  [2,'Trong chạy cự li ngắn với xuất phát cao, khi nghe "Sẵn sàng!" người chạy làm gì?','khuỵu gối, thân ngả về trước, trọng tâm dồn vào chân trước, mắt nhìn phía trước','đứng thẳng, hai tay chống hông','ngồi xuống đất','quay lưng về hướng chạy'],
  [2,'Khi về đích trong chạy cự li ngắn, vận động viên nên làm gì?','duy trì tốc độ, đánh ngực hoặc vai về trước ở vạch đích, không giảm tốc sớm','dừng hẳn trước vạch đích','nhảy qua vạch đích','quay lại nhìn đối thủ'],
  [2,'Trong chạy cự li trung bình, cách phân phối sức hợp lí là gì?','chạy đều, giữ tốc độ ổn định, dồn sức tăng tốc ở đoạn cuối','chạy hết sức ngay từ đầu','đi bộ nửa đầu rồi chạy nhanh','dừng lại nghỉ nhiều lần'],
  [3,'Mô tả kĩ thuật xuất phát cao trong chạy cự li ngắn.','"Vào chỗ!": đứng chân trước (chân thuận) sát sau vạch xuất phát, chân sau cách khoảng nửa bước, hai tay buông tự nhiên. "Sẵn sàng!": khuỵu hai gối, thân trên ngả về trước, trọng tâm dồn vào chân trước, tay trước – tay sau ngược với chân. "Chạy!": đạp mạnh hai chân, chân sau đưa nhanh về trước, tay vung mạnh, xuất phát lao đi.'],
  [3,'Nêu các giai đoạn của kĩ thuật ném bóng xa có đà.','Cầm bóng và chuẩn bị; chạy đà (bước đà thẳng, các bước chéo cuối đưa bóng ra sau); ra sức cuối cùng (chân trụ đạp, xoay thân, vung tay ném bóng qua vai); giữ thăng bằng sau khi ném (bước đổi chân, không vượt vạch giới hạn).'],
  [3,'Nêu một số điểm luật cơ bản trong thi đấu chạy cự li ngắn.','Mỗi vận động viên chạy trong ô chạy của mình, không được lấn sang ô khác; không xuất phát trước hiệu lệnh (phạm quy); thành tích tính khi thân người (ngực, vai) chạm mặt phẳng vạch đích; không cản trở người chạy khác.'],
  [4,'Vì sao sau khẩu lệnh "Chạy!" vận động viên không đứng thẳng lên ngay mà phải chạy lao với thân người ngả về trước?','Ở giai đoạn chạy lao, cơ thể cần tăng tốc từ 0 lên tốc độ cao nhất. Thân người ngả về trước làm trọng tâm đổ về trước, lực đạp sau của chân hướng nhiều về phía trước nên cơ thể được đẩy đi mạnh hơn. Đứng thẳng ngay sẽ làm lực đạp hướng lên trên, mất đà và chậm lại. Khi đạt tốc độ cao, thân người mới dần thẳng lên để vào chạy giữa quãng.']
 ]);
 add(M,6,'Sức khỏe và vận động',[
  [1,'Nhịp tim của người bình thường khi nghỉ ngơi ở lứa tuổi học sinh trung học cơ sở khoảng bao nhiêu?','khoảng 70–90 lần/phút','khoảng 20–30 lần/phút','khoảng 200 lần/phút','khoảng 5 lần/phút'],
  [1,'Khi nào em nên dừng tập và nghỉ ngơi ngay?','khi thấy chóng mặt, hoa mắt, buồn nôn, đau ngực, khó thở','khi ra một ít mồ hôi','khi hết giờ nghỉ','khi bạn bên cạnh dừng'],
  [1,'Tư thế đứng đúng giúp cột sống phát triển bình thường là gì?','đầu thẳng, vai mở, lưng thẳng, trọng tâm rơi đều hai chân','gù lưng, đầu cúi','ưỡn bụng ra trước quá mức','dồn trọng tâm vào một chân thường xuyên'],
  [2,'Hoạt động nào giúp phát triển sức bền chung hiệu quả cho học sinh lớp 6?','chạy chậm hoặc đi bộ nhanh liên tục 10–15 phút, đạp xe, bơi','nâng tạ nặng','chạy 30 m thật nhanh một lần','ngồi thiền'],
  [2,'Thả lỏng sau tập có tác dụng gì đối với cơ thể?','giúp nhịp tim, nhịp thở trở lại bình thường từ từ, giảm đau mỏi cơ, hồi phục nhanh','làm cơ thể mệt thêm','tăng nhịp tim cao hơn','không có tác dụng'],
  [2,'Vì sao học sinh nên ngủ đủ 8–10 giờ mỗi đêm?','vì khi ngủ cơ thể hồi phục, tiết hoóc-môn tăng trưởng, não ghi nhớ bài học tốt hơn','vì ngủ nhiều giúp giảm cân nhanh','vì ngủ ít làm cao hơn','vì ngủ nhiều thay được ăn uống'],
  [3,'Nêu cách đo nhịp tim của bản thân và ý nghĩa của việc theo dõi nhịp tim trong tập luyện.','Đặt hai ngón tay (ngón trỏ và ngón giữa) lên cổ tay phía ngón cái hoặc bên cổ, đếm số nhịp trong 15 giây rồi nhân 4. Theo dõi nhịp tim giúp biết mức độ vận động: quá cao thì giảm cường độ, quá thấp thì tăng; nhịp tim trở lại bình thường nhanh sau tập là dấu hiệu thể lực tốt.'],
  [3,'Nêu các biểu hiện của một cơ thể khỏe mạnh ở lứa tuổi học sinh.','Ăn ngon, ngủ tốt; chiều cao, cân nặng tăng đều phù hợp lứa tuổi; ít ốm; vận động bền, nhanh nhẹn; tinh thần vui vẻ, tập trung học tập; tư thế đứng, ngồi đúng.'],
  [3,'Nêu tác hại của việc ngồi học sai tư thế và cách phòng tránh.','Tác hại: cong vẹo cột sống, gù lưng, cận thị, mỏi cổ vai, ảnh hưởng phát triển chiều cao. Phòng tránh: ngồi thẳng lưng, bàn ghế đúng cỡ, đủ ánh sáng, mắt cách sách 25–30 cm, sau 30–45 phút đứng lên vận động, tập thể dục đều.'],
  [4,'Phân tích mối quan hệ giữa vận động hợp lí và sự phát triển chiều cao, vóc dáng của học sinh lớp 6.','Lớp 6 là lứa tuổi bắt đầu dậy thì, xương phát triển nhanh. Các vận động như chạy, nhảy, bơi, bóng rổ kích thích đầu xương dài ra, cơ chắc, cột sống thẳng nên vóc dáng cân đối. Vận động hợp lí còn giúp ăn ngon, ngủ sâu, tiết nhiều hoóc-môn tăng trưởng. Ngược lại, ít vận động hoặc tập quá sức, sai tư thế đều cản trở phát triển chiều cao và gây cong vẹo cột sống.']
 ]);
 add(M,6,'Kĩ thuật và luật thi đấu',[
  [1,'Trong bóng đá 11 người, một trận đấu chính thức kéo dài bao lâu?','2 hiệp, mỗi hiệp 45 phút','2 hiệp, mỗi hiệp 20 phút','4 hiệp, mỗi hiệp 10 phút','1 hiệp 60 phút'],
  [1,'Trong bóng rổ, mỗi đội có bao nhiêu cầu thủ thi đấu trên sân?','5 cầu thủ','11 cầu thủ','6 cầu thủ','7 cầu thủ'],
  [1,'Trong môn cầu lông, một ván đấu (set) thường kết thúc khi một bên đạt bao nhiêu điểm (cách biệt ít nhất 2 điểm)?','21 điểm','11 điểm','15 điểm','25 điểm'],
  [2,'Trong bóng đá, khi bóng ra ngoài đường biên dọc do một cầu thủ chạm cuối cùng, đội đối phương được hưởng gì?','quả ném biên','quả phạt đền','quả phạt góc','quả phát bóng lên'],
  [2,'Trong bóng rổ, khi cầu thủ cầm bóng chạy quá số bước quy định mà không dẫn bóng thì phạm lỗi gì?','lỗi chạy bước','lỗi việt vị','lỗi ném biên','lỗi phạt góc'],
  [2,'Trong đá cầu, khi quả cầu chạm đất trong phần sân của đội nào thì đội nào mất điểm?','đội có cầu rơi trong sân mình bị mất điểm','đội vừa đá cầu sang mất điểm','không đội nào mất điểm','trọng tài quyết định ngẫu nhiên'],
  [3,'Nêu một số điểm luật cơ bản của môn bóng đá mà học sinh cần biết khi thi đấu.','Chỉ thủ môn được dùng tay trong khu phạt đền của mình; bóng ra biên dọc thì ném biên, ra biên ngang do đội tấn công chạm cuối thì phát bóng lên, do đội phòng ngự chạm cuối thì phạt góc; phạm lỗi với đối phương bị phạt trực tiếp hoặc gián tiếp; cầu thủ thô bạo bị thẻ vàng, thẻ đỏ; không được ở vị trí việt vị khi nhận bóng.'],
  [3,'Nêu các cách ghi điểm trong bóng rổ.','Ném rổ thành công từ trong vạch 3 điểm được 2 điểm; từ ngoài vạch 3 điểm được 3 điểm; ném phạt thành công được 1 điểm mỗi quả.'],
  [3,'Theo em, tinh thần thi đấu thể thao trung thực, cao thượng được thể hiện qua những hành vi nào?','Tôn trọng luật, trọng tài, đối thủ và khán giả; không gian lận, không chơi xấu, không cố ý gây chấn thương; thắng không kiêu, thua không nản; bắt tay, động viên đối thủ sau trận; giúp đỡ bạn bị thương dù là đối thủ.'],
  [4,'Vì sao trong thi đấu thể thao cần có luật và người trọng tài? Điều gì xảy ra nếu không có luật?','Luật quy định cách chơi, cách tính điểm, hành vi được và không được phép, bảo đảm công bằng, an toàn và để mọi người hiểu trận đấu giống nhau. Trọng tài là người áp dụng luật khách quan tại chỗ. Nếu không có luật, mỗi đội sẽ chơi một kiểu, dễ cãi vã, chơi thô bạo gây chấn thương, kết quả không được công nhận và trận đấu mất ý nghĩa rèn luyện, giáo dục.']
 ]);
 add(M,6,'(Bổ sung) Sức khỏe và vận động',[
  [1,'Hoạt động nào sau đây giúp phát triển sức mạnh của cơ chân phù hợp với lớp 6?','bật nhảy tại chỗ, nhảy dây, lên xuống bậc thang','ngồi xem ti vi','cử tạ thật nặng','nằm nghỉ cả buổi'],
  [1,'Khi vận động dưới trời nắng nóng lâu, hiện tượng nguy hiểm nào có thể xảy ra?','say nắng, say nóng','cảm lạnh','ngứa da do lạnh','buồn ngủ do thiếu ánh sáng'],
  [1,'Sau khi tập luyện, nên ăn bữa chính sau khoảng bao lâu để tốt cho tiêu hóa?','khoảng 30–60 phút sau khi tập','ngay khi vừa dừng tập','sau 6 giờ','không cần ăn'],
  [2,'Dấu hiệu nào cho biết cường độ tập đang phù hợp với học sinh?','thở nhanh hơn nhưng vẫn nói được câu ngắn, ra mồ hôi, không chóng mặt','không ra mồ hôi, không mệt chút nào','thở gấp không nói được, hoa mắt','đau nhói ở ngực'],
  [2,'Vì sao cần tập luyện cả sức nhanh, sức mạnh, sức bền và mềm dẻo thay vì chỉ tập một tố chất?','vì cơ thể phát triển toàn diện, cân đối, giảm chấn thương và vận động hiệu quả hơn','vì chỉ tập một tố chất là phạm luật','vì tập nhiều loại cho đỡ chán','vì các tố chất đều giống nhau'],
  [2,'Khi bị căng cơ nhẹ sau buổi tập, cách xử lí nào là đúng?','nghỉ ngơi, chườm lạnh trong ngày đầu, kéo giãn nhẹ nhàng những ngày sau','tập mạnh hơn để hết đau','chườm nóng và xoa bóp mạnh ngay','bó chặt chân cả ngày'],
  [3,'Nêu các biện pháp phòng tránh say nắng, say nóng khi tập luyện và thi đấu.','Không tập ngoài trời lúc nắng gắt (11–15 giờ); mặc đồ thoáng, sáng màu, đội mũ; uống nước đều trước, trong, sau tập; nghỉ giữa giờ ở nơi mát; giảm cường độ khi trời quá nóng; dừng ngay khi có dấu hiệu chóng mặt, đau đầu, da nóng khô.'],
  [3,'Hãy xây dựng một bài tập phát triển sức bền đơn giản cho bản thân trong 4 tuần.','Tuần 1: chạy chậm 5 phút + đi bộ 3 phút, 3 buổi/tuần. Tuần 2: chạy chậm 8 phút. Tuần 3: chạy chậm 10–12 phút. Tuần 4: chạy chậm 15 phút. Mỗi buổi khởi động 5 phút, thả lỏng 5 phút; giữ nhịp thở đều, tốc độ vừa, có thể nói chuyện được khi chạy.'],
  [3,'Nêu các bước sơ cứu người bị say nắng nhẹ.','Đưa người bệnh vào chỗ mát, thoáng; nới rộng quần áo; cho uống nước từng ngụm nhỏ (nếu còn tỉnh); lau mát bằng khăn ướt ở trán, cổ, nách; quạt nhẹ; theo dõi, nếu không đỡ hoặc bất tỉnh phải gọi người lớn và đưa đến cơ sở y tế.'],
  [4,'Vận dụng kiến thức đã học, hãy giải thích vì sao sau một buổi tập nặng, cơ thể cần nghỉ ngơi và ăn uống đầy đủ thì mới khỏe lên.','Khi tập nặng, cơ bắp tiêu hao năng lượng và có những tổn thương rất nhỏ. Trong thời gian nghỉ ngơi và ngủ, cơ thể dùng chất đạm, chất bột đường từ bữa ăn để sửa chữa, tái tạo cơ, bù năng lượng và thích nghi ở mức cao hơn trước, nhờ đó sức mạnh, sức bền tăng. Nếu không nghỉ và ăn đủ, cơ không hồi phục, dẫn đến mệt mỏi kéo dài, dễ chấn thương và thành tích giảm.']
 ]);

 /* ===== LỚP 7 ===== */
 add(M,7,'Kiến thức chung về thể dục thể thao',[
  [1,'Những yếu tố tự nhiên nào có thể được sử dụng để rèn luyện sức khỏe?','không khí, ánh nắng mặt trời và nước','tiếng ồn, khói bụi','bóng tối và độ ẩm cao','gió bão'],
  [1,'Tắm nắng vào thời điểm nào trong ngày là có lợi cho sức khỏe?','buổi sáng sớm (trước 9 giờ) hoặc chiều muộn','giữa trưa 12 giờ','bất kì lúc nào càng lâu càng tốt','lúc nắng gắt nhất'],
  [1,'Ánh nắng mặt trời giúp cơ thể tổng hợp loại vitamin nào?','vitamin D','vitamin C','vitamin B1','vitamin A'],
  [2,'Tập luyện ở nơi có không khí trong lành mang lại lợi ích gì?','cơ thể nhận nhiều ô-xi, hô hấp tốt hơn, tinh thần sảng khoái','làm da đen nhanh','khiến mệt nhanh hơn','không có gì khác so với trong phòng kín'],
  [2,'Rèn luyện với nước (tắm, bơi, lau người nước mát) đúng cách giúp cơ thể điều gì?','tăng khả năng thích nghi với sự thay đổi nhiệt độ, tăng sức đề kháng','dễ bị cảm hơn','không có tác dụng','làm giảm chiều cao'],
  [2,'Khi thành phố có cảnh báo ô nhiễm không khí cao, học sinh nên tập luyện như thế nào?','tập trong nhà hoặc giảm cường độ, tránh tập ngoài trời lâu, đeo khẩu trang khi ra ngoài','tập ngoài trời như bình thường','chạy nhanh hơn để hít nhiều không khí','không cần quan tâm'],
  [3,'Nêu cách sử dụng ánh nắng mặt trời để rèn luyện sức khỏe một cách an toàn.','Tắm nắng vào sáng sớm hoặc chiều muộn, bắt đầu 5–10 phút rồi tăng dần; để lộ một phần da (tay, chân); không tắm nắng lúc nắng gắt; đội mũ, uống nước; dừng khi thấy da đỏ, nóng rát hoặc chóng mặt.'],
  [3,'Nêu cách sử dụng yếu tố nước để rèn luyện cơ thể và những điều cần chú ý.','Tắm, lau người bằng nước mát sau khi tập (khi đã hết mồ hôi), bơi lội, đi bộ dưới nước; bắt đầu từ nước ấm rồi hạ dần nhiệt độ; không tắm nước lạnh khi cơ thể đang nóng, ra nhiều mồ hôi hoặc khi đang ốm; không bơi nơi không an toàn, không có người giám sát.'],
  [3,'Nêu các yêu cầu về dinh dưỡng cho học sinh lớp 7 có tập luyện thể dục thể thao thường xuyên.','Ăn đủ 3 bữa, đa dạng thực phẩm, đủ 4 nhóm chất; tăng rau xanh, trái cây, thực phẩm giàu canxi (sữa, cá, đậu); uống đủ nước; không bỏ bữa, không ăn quá no trước tập; hạn chế đồ ngọt, nước có ga, đồ chiên rán.'],
  [4,'Phân tích vì sao việc kết hợp sử dụng không khí, ánh nắng, nước với tập luyện lại hiệu quả hơn so với chỉ tập luyện trong phòng kín.','Tập ở nơi thoáng cung cấp nhiều ô-xi hơn giúp cơ thể hoạt động bền hơn. Ánh nắng sáng sớm giúp tổng hợp vitamin D, hấp thu canxi tốt nên xương chắc, hỗ trợ tăng chiều cao. Tiếp xúc hợp lí với nước và nhiệt độ ngoài trời rèn khả năng thích nghi, tăng sức đề kháng nên ít ốm. Phòng kín không có các yếu tố đó, không khí dễ ngột ngạt, nên hiệu quả rèn luyện toàn diện thấp hơn. Tuy vậy cần dùng các yếu tố tự nhiên đúng cách để tránh say nắng, cảm lạnh, ô nhiễm.']
 ]);
 add(M,7,'Kĩ thuật và luật cơ bản',[
  [1,'Kĩ thuật nhảy xa kiểu ngồi gồm những giai đoạn nào?','chạy đà, giậm nhảy, trên không, tiếp đất','đứng, ngồi, nằm, chạy','khởi động, chạy, nghỉ','xuất phát, chạy lao, về đích'],
  [1,'Trong nhảy xa, giậm nhảy được thực hiện bằng mấy chân?','một chân (chân giậm)','hai chân cùng lúc','không cần giậm','luân phiên hai chân'],
  [1,'Trong nhảy xa kiểu ngồi, ở giai đoạn trên không, tư thế cơ thể giống như đang làm gì?','ngồi: hai đùi nâng cao, thân hơi gập, hai tay đưa ra trước','đứng thẳng','nằm sấp','quay lưng'],
  [2,'Trong nhảy xa, thành tích được đo như thế nào?','từ mép ván giậm nhảy (phía hố cát) đến điểm chạm cát gần ván nhất của bất kì bộ phận cơ thể','từ điểm bắt đầu chạy đà đến chỗ rơi','từ ván đến điểm chạm cát xa nhất','từ mép hố cát đến gót chân'],
  [2,'Trường hợp nào sau đây bị tính là phạm quy trong nhảy xa?','giậm nhảy vượt quá mép ván giậm nhảy về phía hố cát','rơi bằng hai chân vào hố cát','chạy đà bằng 7 bước','tay chạm cát ở phía trước chân'],
  [2,'Vì sao bước đà cuối cùng trước khi giậm nhảy thường ngắn và nhanh hơn?','để hạ thấp trọng tâm, đặt chân giậm nhanh và chuyển từ tốc độ chạy sang lực bật lên','để nghỉ lấy sức','để nhìn ván giậm cho rõ','vì luật quy định'],
  [3,'Mô tả kĩ thuật giậm nhảy và trên không trong nhảy xa kiểu ngồi.','Giậm nhảy: đặt cả bàn chân giậm vào ván nhanh, mạnh; chân giậm duỗi hết các khớp, chân lăng đá mạnh về trước lên trên, hai tay vung lên. Trên không: giữ tư thế bước bộ, sau đó thu chân giậm lên ngang chân lăng, hai đùi nâng cao, thân hơi gập như "ngồi", tay đưa ra trước; chuẩn bị duỗi chân về trước để tiếp đất.'],
  [3,'Nêu kĩ thuật tiếp đất an toàn trong nhảy xa và các lỗi thường gặp.','Tiếp đất bằng hai gót chân rồi chuyển sang cả bàn chân, gối chùng để giảm chấn động, thân người và tay đưa về trước, không ngã ngồi về sau. Lỗi thường gặp: chân thẳng cứng khi tiếp đất; ngã ngồi về sau làm thành tích bị đo ở điểm mông chạm cát; tiếp đất một chân mất thăng bằng.'],
  [3,'Nêu một số quy định cơ bản trong thi đấu nhảy xa.','Mỗi vận động viên có số lần nhảy quy định (thường 3 lần, vào vòng chung kết thêm 3 lần); giậm nhảy quá ván là phạm quy; thành tích đo từ mép ván đến điểm chạm gần nhất; rời hố cát phải đi về phía trước; thành tích tốt nhất được tính.'],
  [4,'Vì sao tốc độ chạy đà và lực giậm nhảy đều quan trọng với thành tích nhảy xa? Nếu chạy đà rất nhanh nhưng giậm nhảy yếu thì kết quả sẽ thế nào?','Thành tích nhảy xa phụ thuộc tốc độ bay ban đầu và góc bay. Chạy đà tạo tốc độ nằm ngang, giậm nhảy tạo lực bật lên để có góc bay thích hợp (khoảng 18–24 độ). Nếu chạy đà rất nhanh nhưng giậm yếu, thân bay thấp, góc bay nhỏ, nhanh chạm đất nên không xa; ngược lại giậm mạnh mà đà chậm thì bay cao nhưng gần. Vì vậy phải phối hợp đà nhanh với giậm nhảy mạnh, đúng kĩ thuật.']
 ]);
 add(M,7,'Sức khỏe và vận động',[
  [1,'Trong chạy cự li trung bình, hiện tượng khó thở, tức ngực, chân nặng xuất hiện sau một đoạn chạy được gọi là gì?','hiện tượng "cực điểm"','hiện tượng chuột rút','hiện tượng say nắng','hiện tượng bong gân'],
  [1,'Khi gặp "cực điểm" trong chạy bền, người chạy nên làm gì?','giảm nhẹ tốc độ, thở sâu và đều, tiếp tục chạy để vượt qua','dừng hẳn và ngồi xuống ngay','tăng tốc hết sức','nín thở'],
  [1,'Cách thở hợp lí khi chạy cự li trung bình là gì?','thở sâu, nhịp nhàng theo bước chạy, hít bằng mũi và thở ra bằng miệng','nín thở từng đoạn','thở thật nhanh và nông','chỉ thở bằng mũi khi rất mệt'],
  [2,'Vì sao sau khi chạy bền không nên dừng lại đột ngột và ngồi hoặc nằm ngay?','vì máu dồn ở chân, tim chưa kịp thích nghi dễ gây choáng, chóng mặt, ngất','vì sẽ bị chuột rút ở tay','vì luật không cho phép','vì sẽ bị cảm lạnh ngay lập tức'],
  [2,'Lợi ích chính của chạy cự li trung bình đối với sức khỏe là gì?','phát triển sức bền, tim phổi khỏe, tăng khả năng chịu đựng và ý chí','phát triển sức mạnh tay','làm cao lên nhanh trong vài ngày','tăng cân nhanh'],
  [2,'Vì sao cần kiểm tra sức khỏe trước khi tham gia chạy bền hoặc thi đấu?','để phát hiện bệnh về tim mạch, hô hấp hoặc tình trạng mệt mỏi có thể gây nguy hiểm khi gắng sức','để biết ai chạy nhanh hơn','để được miễn thi','vì chỉ là thủ tục không cần thiết'],
  [3,'Giải thích hiện tượng "cực điểm" trong chạy cự li trung bình và cách khắc phục.','Sau khoảng 2–3 phút chạy, nhu cầu ô-xi của cơ thể tăng cao trong khi hệ tim mạch, hô hấp chưa kịp đáp ứng nên xuất hiện khó thở, tức ngực, chân nặng, muốn bỏ cuộc – đó là "cực điểm". Khắc phục: giảm nhẹ tốc độ, hít thở sâu và đều, giữ ý chí tiếp tục chạy; sau một lúc cơ thể thích nghi, cảm giác dễ chịu trở lại ("hô hấp lần hai").'],
  [3,'Nêu cách phân phối sức khi chạy cự li trung bình (500–800 m) cho học sinh.','Xuất phát nhanh vừa phải để chiếm vị trí, sau đó chạy đều với tốc độ phù hợp (có thể nói được câu ngắn), giữ nhịp thở ổn định; đoạn giữa duy trì tốc độ, không chạy quá nhanh; khoảng 100–150 m cuối tăng tốc dần về đích; sau đích đi bộ thả lỏng, không dừng đột ngột.'],
  [3,'Nêu các việc cần làm để bảo đảm an toàn khi tập chạy bền.','Kiểm tra sức khỏe, không chạy khi ốm; khởi động kĩ; chọn đường chạy bằng phẳng, thoáng, không có xe; uống đủ nước; chạy vừa sức, tăng dần quãng đường; thở đúng; dừng và báo thầy cô khi đau ngực, chóng mặt; thả lỏng sau khi chạy.'],
  [4,'Vì sao luyện tập chạy bền thường xuyên lại làm cho hiện tượng "cực điểm" xuất hiện muộn hơn và nhẹ hơn?','Tập chạy bền thường xuyên làm tim khỏe hơn (mỗi lần co bóp đẩy được nhiều máu hơn), phổi hít sâu hơn, mạch máu và cơ bắp sử dụng ô-xi hiệu quả hơn. Nhờ vậy khi chạy, hệ tim mạch – hô hấp đáp ứng kịp nhu cầu ô-xi của cơ thể, sự "lệch pha" giữa nhu cầu và cung cấp ô-xi nhỏ hơn, nên cảm giác cực điểm đến muộn hơn, nhẹ hơn và qua nhanh hơn. Người ít tập thì ngược lại.']
 ]);
 add(M,7,'Kĩ thuật và luật thi đấu',[
  [1,'Trong bóng chuyền, mỗi đội được chạm bóng tối đa bao nhiêu lần trước khi đưa bóng sang sân đối phương (không tính chạm chắn bóng)?','3 lần','1 lần','5 lần','không giới hạn'],
  [1,'Trong bóng chuyền, một hiệp đấu thông thường kết thúc khi một đội đạt bao nhiêu điểm (cách biệt ít nhất 2 điểm)?','25 điểm','15 điểm','21 điểm','11 điểm'],
  [1,'Trong cầu lông, khi tỉ số 20–20 thì ván đấu kết thúc như thế nào?','bên nào dẫn trước cách biệt 2 điểm sẽ thắng; nếu đến 29–29 thì bên ghi điểm 30 thắng','bên ghi điểm 21 thắng ngay','chơi lại từ đầu','hòa và không tính ván đó'],
  [2,'Trong bóng rổ, cầu thủ dẫn bóng rồi dừng, sau đó dẫn bóng lại lần nữa thì phạm lỗi gì?','lỗi hai lần dẫn bóng','lỗi chạy bước','lỗi 3 giây','lỗi ném biên'],
  [2,'Trong bóng đá, cầu thủ bị phạt thẻ đỏ sẽ bị xử lí như thế nào?','bị truất quyền thi đấu, đội không được thay người khác vào','được tiếp tục chơi','bị phạt góc','chỉ bị nhắc nhở'],
  [2,'Trong đá cầu, điều nào sau đây là đúng luật?','mỗi bên được chạm cầu tối đa số lần quy định (đơn 2, đôi 4) trước khi đá sang sân đối phương','dùng tay đỡ cầu','để cầu chạm đất sân mình rồi đá lại','ôm cầu chạy qua lưới'],
  [3,'Nêu các kĩ thuật cơ bản trong môn bóng chuyền mà học sinh được học.','Tư thế chuẩn bị và di chuyển; chuyền bóng cao tay bằng hai tay (trước mặt); đệm bóng (chuyền bóng thấp tay); phát bóng thấp tay hoặc cao tay; bước đầu làm quen với đập bóng và chắn bóng.'],
  [3,'Nêu một số điểm luật cơ bản trong thi đấu bóng chuyền.','Mỗi đội 6 người trên sân; chạm bóng tối đa 3 lần rồi phải đưa bóng qua lưới; một người không được chạm bóng 2 lần liên tiếp (trừ chắn bóng); bóng chạm đất sân đối phương hoặc đối phương đánh ra ngoài thì được điểm; không được chạm lưới khi đánh bóng, không vượt hẳn qua vạch giữa sang sân đối phương khi đang chơi; hiệp 25 điểm, cách biệt ít nhất 2; thắng 3 hiệp là thắng trận.'],
  [3,'Theo em, khi thi đấu các môn thể thao có đối kháng, học sinh cần làm gì để bảo đảm an toàn cho mình và đối thủ?','Khởi động kĩ; tuân thủ luật, không chơi thô bạo, không cố ý va chạm; dùng trang phục, dụng cụ bảo hộ phù hợp; kiểm soát cảm xúc, nghe trọng tài; dừng ngay khi có bạn bị chấn thương và báo thầy cô.'],
  [4,'Vì sao trong bóng chuyền, luật chỉ cho mỗi đội chạm bóng tối đa 3 lần trước khi đưa bóng qua lưới? Điều này tác động thế nào đến cách chơi?','Giới hạn 3 lần chạm buộc các đội phải xử lí bóng nhanh, chính xác và phối hợp chặt chẽ: thường là đỡ bước một – chuyền hai – đập bóng. Nhờ vậy trận đấu diễn ra nhanh, hấp dẫn, công bằng, đòi hỏi kĩ thuật, chiến thuật và tinh thần đồng đội cao. Nếu không giới hạn, đội có thể giữ bóng lâu, trận đấu chậm, kém hấp dẫn và lợi thế thuộc về đội giữ bóng tốt hơn chứ không phải đội chơi hay hơn.']
 ]);
 add(M,7,'(Bổ sung) Sức khỏe và vận động',[
  [1,'Chỉ số thường dùng để đánh giá cân nặng so với chiều cao là gì?','chỉ số khối cơ thể BMI','nhịp tim','số đo vòng tay','huyết áp'],
  [1,'Khi tập luyện vào mùa lạnh, điều gì cần chú ý?','khởi động kĩ và lâu hơn, giữ ấm, cởi dần áo khi đã nóng người','không cần khởi động vì trời lạnh','mặc áo cộc tay ngay từ đầu','tập xong ngồi ngay nơi gió lùa'],
  [1,'Loại thực phẩm nào cung cấp nhiều canxi giúp xương chắc khỏe?','sữa và các sản phẩm từ sữa, cá nhỏ ăn cả xương, đậu, rau xanh đậm','nước ngọt có ga','bánh kẹo','đồ chiên rán nhiều dầu mỡ'],
  [2,'Vì sao học sinh lớp 7 không nên tập cử tạ nặng hoặc các bài tập sức mạnh tối đa?','vì cơ thể đang phát triển, xương và khớp chưa hoàn thiện, dễ chấn thương và ảnh hưởng tăng trưởng','vì tập tạ làm thấp đi ngay lập tức','vì luật thể thao cấm tuyệt đối','vì không có tác dụng gì'],
  [2,'Dấu hiệu nào cho thấy em đang tập luyện quá sức trong thời gian dài?','mệt mỏi kéo dài, mất ngủ, chán ăn, hay ốm, thành tích giảm','ra nhiều mồ hôi khi tập','đói sau khi tập','ngủ ngon hơn'],
  [2,'Cách tính chỉ số BMI là gì?','cân nặng (kg) chia cho bình phương chiều cao (m)','chiều cao (cm) chia cho cân nặng (kg)','cân nặng (kg) nhân chiều cao (m)','chiều cao (m) trừ cân nặng (kg)'],
  [3,'Nêu cách xử lí khi bị chuột rút bắp chân trong lúc tập luyện.','Dừng vận động, ngồi hoặc nằm; duỗi thẳng chân, kéo nhẹ các ngón chân và bàn chân về phía ống chân để kéo giãn bắp chân; xoa bóp nhẹ; uống nước có chút muối khoáng nếu có; nghỉ đến khi hết đau rồi vận động nhẹ; phòng tránh bằng khởi động kĩ và uống đủ nước.'],
  [3,'Nêu các việc cần làm để phòng tránh chấn thương khi tập các môn nhảy (nhảy xa, nhảy cao).','Khởi động kĩ các khớp cổ chân, gối, hông; kiểm tra hố cát tơi xốp, đệm nhảy đúng vị trí, ván giậm không trơn; học đúng kĩ thuật giậm nhảy và tiếp đất; không đùa nghịch ở khu vực nhảy; nhảy theo thứ tự, người sau chờ người trước rời hố.'],
  [3,'Nêu vai trò của giấc ngủ đối với học sinh có tập luyện thể dục thể thao.','Giấc ngủ đủ (8–10 giờ) giúp cơ bắp phục hồi, tiết hoóc-môn tăng trưởng, não củng cố trí nhớ, tinh thần tỉnh táo, giảm nguy cơ chấn thương do mệt mỏi; ngủ thiếu làm giảm thành tích và sức đề kháng.'],
  [4,'Em hãy phân tích vì sao việc theo dõi chỉ số BMI và nhịp tim giúp học sinh điều chỉnh chế độ tập luyện, ăn uống phù hợp hơn.','BMI cho biết cân nặng đang thiếu, bình thường hay thừa so với chiều cao; nếu thừa cân cần tăng vận động sức bền, giảm đồ ngọt; nếu thiếu cân cần ăn đủ chất và tập vừa sức. Nhịp tim lúc nghỉ giảm dần và hồi phục nhanh sau tập cho thấy thể lực tốt hơn; nhịp tim khi tập quá cao cảnh báo tập quá sức. Theo dõi hai chỉ số này giúp em biết cơ thể đang thay đổi thế nào và điều chỉnh kịp thời, tránh tập sai cách gây hại.']
 ]);

 /* ===== LỚP 8 ===== */
 add(M,8,'Kiến thức chung về thể dục thể thao',[
  [1,'Thể dục thể thao có vai trò gì đối với sự phát triển thể chất của học sinh?','phát triển hình thể cân đối, nâng cao chức năng các cơ quan và các tố chất thể lực','chỉ giúp giải trí','làm chậm quá trình phát triển','không liên quan đến thể chất'],
  [1,'Chấn thương thường gặp nhất trong hoạt động thể dục thể thao ở trường học là gì?','bong gân, căng cơ, trầy xước, bầm tím','gãy xương sọ','bệnh truyền nhiễm','ngộ độc thực phẩm'],
  [1,'Nguyên tắc sơ cứu ban đầu đối với bong gân, căng cơ thường được tóm tắt bằng mấy bước chính?','4 bước: nghỉ ngơi, chườm lạnh, băng ép, kê cao','1 bước: xoa bóp mạnh','2 bước: chạy tiếp và uống nước','3 bước: chườm nóng, đi lại, ăn uống'],
  [2,'Vì sao nói tập luyện thể dục thể thao giúp hệ tim mạch khỏe hơn?','vì tim được rèn luyện co bóp mạnh hơn, mỗi nhịp đẩy nhiều máu hơn, nhịp tim lúc nghỉ thấp hơn, mạch máu đàn hồi tốt','vì tim đập nhanh hơn lúc nghỉ','vì tim nhỏ đi','vì máu chảy chậm hơn'],
  [2,'Nguyên nhân chủ yếu dẫn đến chấn thương trong tập luyện là gì?','không khởi động hoặc khởi động không kĩ, sai kĩ thuật, tập quá sức, sân bãi dụng cụ không an toàn','tập đúng kĩ thuật','mặc trang phục thể thao','khởi động quá kĩ'],
  [2,'Khi một bạn bị ngã nghi gãy xương tay, em nên làm gì?','không di chuyển chỗ gãy, cố định tạm bằng nẹp hoặc vật cứng, báo thầy cô và gọi y tế','kéo thẳng tay bạn cho khớp lại','xoa bóp mạnh chỗ đau','bảo bạn tiếp tục tập cho quen'],
  [3,'Nêu các tác động tích cực của thể dục thể thao đối với từng hệ cơ quan trong cơ thể.','Hệ vận động: cơ to, chắc; xương dày, cứng, phát triển chiều cao; khớp linh hoạt. Hệ tim mạch: tim khỏe, nhịp tim nghỉ thấp, mạch đàn hồi. Hệ hô hấp: dung tích sống tăng, thở sâu. Hệ thần kinh: phản xạ nhanh, giảm căng thẳng, ngủ tốt. Hệ tiêu hóa, bài tiết hoạt động tốt hơn; sức đề kháng tăng.'],
  [3,'Nêu các bước xử lí ban đầu khi bị bong gân cổ chân trong tập luyện.','Nghỉ ngơi: dừng vận động ngay, không đi lại nhiều. Chườm lạnh: dùng túi đá bọc khăn chườm 15–20 phút, nhiều lần trong 1–2 ngày đầu. Băng ép: băng vừa chặt để hạn chế sưng. Kê cao chân hơn tim khi nằm. Không xoa bóp, không chườm nóng ngay; nếu đau nhiều, sưng to, không đứng được phải đến cơ sở y tế.'],
  [3,'Nêu các biện pháp phòng tránh chấn thương trong hoạt động thể dục thể thao.','Kiểm tra sức khỏe; khởi động kĩ, thả lỏng đủ; tập đúng kĩ thuật theo hướng dẫn; tăng dần khối lượng, vừa sức; trang phục, giày, dụng cụ bảo hộ phù hợp; sân bãi, dụng cụ an toàn; không đùa nghịch; tuân thủ luật; dinh dưỡng, nghỉ ngơi hợp lí.'],
  [4,'Vì sao lứa tuổi học sinh trung học cơ sở được coi là "thời kì vàng" để phát triển thể chất và nên tập luyện như thế nào để tận dụng điều đó?','Lớp 8 nằm trong giai đoạn dậy thì, hoóc-môn tăng trưởng tiết mạnh, xương dài nhanh, cơ bắp và tim phổi phát triển, khả năng học kĩ năng vận động cao. Tập luyện hợp lí lúc này đem lại hiệu quả lớn và lâu dài về chiều cao, vóc dáng, sức khỏe. Nên tập toàn diện (chạy, nhảy, bơi, bóng, bài thể dục), đều đặn, vừa sức, tránh tập sức mạnh tối đa với tạ nặng, kết hợp dinh dưỡng đủ chất và ngủ đủ giấc.']
 ]);
 add(M,8,'Kĩ thuật và luật cơ bản',[
  [1,'Kĩ thuật nhảy cao kiểu bước qua gồm những giai đoạn nào?','chạy đà, giậm nhảy, trên không, tiếp đất','xuất phát, chạy lao, về đích','đứng, ngồi, nằm','khởi động, nhảy, nghỉ'],
  [1,'Trong nhảy cao kiểu bước qua, hướng chạy đà so với xà như thế nào?','chạy đà chéo với xà, góc khoảng 30–40 độ','chạy thẳng vuông góc với xà','chạy song song với xà','chạy từ phía sau xà'],
  [1,'Trong chạy cự li ngắn, xuất phát thấp sử dụng dụng cụ gì để hỗ trợ?','bàn đạp xuất phát','ván giậm nhảy','xà ngang','hố cát'],
  [2,'Trong nhảy cao kiểu bước qua, chân nào đi qua xà trước?','chân lăng (chân không giậm nhảy)','chân giậm nhảy','hai chân cùng lúc','tay đi trước chân'],
  [2,'Khi xuất phát thấp, ở khẩu lệnh "Sẵn sàng!" vận động viên có tư thế như thế nào?','nâng mông lên cao hơn vai một chút, hai chân tì chắc vào bàn đạp, trọng tâm dồn về trước, tay chống thẳng','đứng thẳng lên','ngồi hẳn xuống bàn đạp','nằm sấp xuống đường chạy'],
  [2,'Trong thi đấu nhảy cao, vận động viên được nhảy tối đa bao nhiêu lần ở mỗi mức xà?','3 lần','1 lần','5 lần','không giới hạn'],
  [3,'Mô tả kĩ thuật giậm nhảy và qua xà trong nhảy cao kiểu bước qua.','Giậm nhảy: bước đà cuối đặt chân giậm (chân xa xà) xuống đất bằng gót rồi cả bàn, chân giậm duỗi mạnh, chân lăng đá thẳng lên cao về phía xà, hai tay vung lên. Trên không: chân lăng qua xà trước, thân người hơi ngả về phía xà rồi gập về trước; khi chân lăng qua xà thì hạ xuống, đồng thời chân giậm nâng lên và "bước qua" xà. Tiếp đất bằng chân lăng rồi chân giậm, gối chùng.'],
  [3,'Nêu kĩ thuật xuất phát thấp trong chạy cự li ngắn.','"Vào chỗ!": ngồi xuống, đặt hai chân vào bàn đạp (chân thuận ở bàn đạp trước), hai tay chống rộng bằng vai sát sau vạch xuất phát, gối chân sau chạm đất, mắt nhìn trước khoảng 1 m. "Sẵn sàng!": nâng mông cao hơn vai, trọng tâm dồn lên hai tay và chân trước, hít sâu. "Chạy!": đạp mạnh hai chân vào bàn đạp, tay rời đất vung mạnh, chân sau đưa nhanh về trước, lao ra với thân ngả về trước.'],
  [3,'Nêu một số quy định trong thi đấu nhảy cao.','Nhảy bằng một chân; vận động viên có tối đa 3 lần nhảy ở mỗi mức xà, hỏng 3 lần liên tiếp thì bị loại; thành tích là mức xà cao nhất vượt qua; làm rơi xà hoặc chạm vào khu vực sau xà trước khi vượt qua là hỏng; mức xà được nâng dần theo quy định của ban tổ chức.'],
  [4,'So sánh xuất phát thấp và xuất phát cao trong chạy cự li ngắn: ưu điểm của xuất phát thấp là gì và vì sao?','Xuất phát thấp có trọng tâm cơ thể thấp và dồn về trước, hai chân tì vào bàn đạp nên lực đạp sau hướng về trước mạnh hơn, giúp cơ thể lao ra nhanh, tăng tốc tốt ngay những bước đầu – rất quan trọng với cự li ngắn vì thời gian chạy rất ngắn. Xuất phát cao đơn giản, không cần dụng cụ nhưng trọng tâm cao hơn, lực đạp kém hiệu quả hơn nên tốc độ ban đầu thấp hơn. Vì vậy trong thi đấu cự li ngắn, vận động viên dùng xuất phát thấp.']
 ]);
 add(M,8,'Sức khỏe và vận động',[
  [1,'Để đánh giá sức bền chung của bản thân, có thể dùng bài kiểm tra nào?','chạy tùy sức trong 5 phút hoặc chạy cự li 800–1000 m','bật xa tại chỗ','chạy 30 m xuất phát cao','gập thân về trước'],
  [1,'Tố chất thể lực nào thể hiện khả năng thực hiện động tác trong thời gian ngắn nhất?','sức nhanh','sức bền','mềm dẻo','sức mạnh'],
  [1,'Hoạt động nào sau đây giúp phát triển sức mạnh của cơ thân mình phù hợp với học sinh?','nằm ngửa gập bụng, chống đẩy, plank (giữ tư thế tấm ván)','ngồi xem phim','nâng tạ tối đa','chạy 100 m'],
  [2,'Khi tập các bài phát triển sức mạnh, học sinh lớp 8 cần tuân thủ điều gì?','dùng trọng lượng cơ thể hoặc dụng cụ nhẹ, số lần vừa phải, đúng kĩ thuật, nghỉ giữa các lượt','tập đến khi không nâng được nữa mỗi ngày','chỉ tập một nhóm cơ duy nhất','nín thở suốt bài tập'],
  [2,'Thời điểm nào không nên tập luyện với cường độ cao?','ngay sau khi ăn no, khi đang ốm, khi quá đói hoặc thiếu ngủ nhiều','buổi chiều sau giờ học','buổi sáng sau khi ăn nhẹ 1–2 giờ','cuối tuần'],
  [2,'Vì sao cần hồi phục đầy đủ giữa các buổi tập sức mạnh?','vì cơ cần thời gian (thường 1–2 ngày) để sửa chữa và phát triển, tập liên tục làm cơ suy yếu, dễ chấn thương','vì cơ không bao giờ mệt','vì luật quy định','vì nghỉ nhiều mới to cơ nhanh nhất mà không cần tập'],
  [3,'Nêu các bài tập đơn giản để phát triển sức bền, sức mạnh, sức nhanh và mềm dẻo cho học sinh lớp 8.','Sức bền: chạy chậm 10–20 phút, nhảy dây liên tục, đạp xe. Sức mạnh: chống đẩy, gập bụng, bật cóc, squat (đứng lên ngồi xuống). Sức nhanh: chạy 30 m xuất phát cao, chạy nâng cao đùi nhanh, phản ứng theo tín hiệu. Mềm dẻo: gập thân, xoạc, ép dẻo các khớp, các động tác kéo giãn.'],
  [3,'Nêu cách tự kiểm tra và theo dõi sự tiến bộ về thể lực của bản thân.','Chọn các bài kiểm tra đơn giản (chạy 30 m, bật xa tại chỗ, chống đẩy trong 30 giây, gập bụng, chạy 5 phút tùy sức, gập thân về trước); đo thành tích và nhịp tim định kì (ví dụ mỗi tháng); ghi vào sổ theo dõi; so sánh kết quả để điều chỉnh bài tập.'],
  [3,'Nêu các việc cần làm trước, trong và sau buổi tập để bảo đảm sức khỏe.','Trước: ăn nhẹ trước 1–2 giờ, uống nước, trang phục phù hợp, khởi động 8–10 phút. Trong: tập đúng kĩ thuật, vừa sức, thở đúng, uống nước từng ngụm, nghỉ giữa các lượt, dừng khi có dấu hiệu bất thường. Sau: thả lỏng, kéo giãn, lau mồ hôi, thay quần áo, bù nước, ăn nhẹ sau 30–60 phút, ngủ đủ.'],
  [4,'Vì sao các bài tập dùng trọng lượng cơ thể (chống đẩy, gập bụng, squat) được khuyến khích hơn tập tạ nặng với học sinh lớp 8? Phân tích.','Ở lớp 8 xương còn các đầu sụn tăng trưởng chưa đóng, khớp và dây chằng chưa hoàn thiện; tạ nặng gây áp lực lớn lên cột sống và khớp, dễ chấn thương và có thể ảnh hưởng phát triển chiều cao. Bài tập dùng trọng lượng cơ thể có lực vừa phải, phù hợp với khả năng chịu đựng, giúp cơ phát triển cân đối, rèn kĩ thuật và khả năng kiểm soát cơ thể, an toàn, không cần dụng cụ và có thể tập ở mọi nơi. Khi cơ thể trưởng thành hơn mới tăng dần tải trọng.']
 ]);
 add(M,8,'Kĩ thuật và luật thi đấu',[
  [1,'Trong bóng chuyền, hiệp thứ 5 (hiệp quyết định) kết thúc khi một đội đạt bao nhiêu điểm (cách biệt ít nhất 2)?','15 điểm','25 điểm','21 điểm','11 điểm'],
  [1,'Trong bóng rổ, vạch 3 điểm có ý nghĩa gì?','ném rổ thành công từ ngoài vạch này được 3 điểm','cầu thủ không được vượt qua vạch này','đây là vạch ném phạt','đây là đường biên dọc'],
  [1,'Trong bóng đá, cầu thủ bị coi là ở vị trí việt vị khi nào?','ở phần sân đối phương, gần đường biên ngang đối phương hơn cả bóng và cầu thủ phòng ngự thứ hai từ cuối lên vào thời điểm đồng đội chuyền bóng','đứng trong vòng cấm của đội mình','chạm bóng bằng tay','đứng gần trọng tài'],
  [2,'Trong cầu lông đánh đôi, khu vực phát cầu hợp lệ khác đánh đơn ở điểm nào?','khu phát cầu đôi ngắn hơn (đến vạch phát cầu dài phía sau) nhưng rộng hơn (dùng cả hành lang biên dọc)','hoàn toàn giống đánh đơn','không có vạch giới hạn nào','phát cầu phải rơi ngoài sân'],
  [2,'Trong bóng rổ, cầu thủ tấn công đứng trong khu vực giới hạn (khu 3 giây, hình chữ nhật dưới rổ) của đối phương quá 3 giây liên tục khi đội mình đang khống chế bóng thì phạm lỗi gì?','lỗi 3 giây','lỗi chạy bước','lỗi hai lần dẫn bóng','lỗi 24 giây'],
  [2,'Trong đá cầu, khi phát cầu, người phát phải đứng ở đâu?','trong khu vực phát cầu ở cuối sân mình, không chạm vạch','sát lưới','ngoài sân bất kì chỗ nào','bên sân đối phương'],
  [3,'Nêu một số điểm luật về thời gian và điểm số trong bóng rổ (theo luật FIBA).','Trận đấu gồm 4 hiệp, mỗi hiệp 10 phút; đội tấn công phải ném rổ trong 24 giây; đưa bóng qua sân đối phương trong 8 giây; ném trong vạch 3 điểm được 2 điểm, ngoài vạch được 3 điểm, ném phạt 1 điểm; đội nhiều điểm hơn khi hết giờ thắng, hòa thì đấu thêm hiệp phụ 5 phút.'],
  [3,'Nêu các lỗi kĩ thuật thường gặp trong bóng rổ và cách khắc phục trong tập luyện.','Chạy bước (di chuyển quá 2 bước khi cầm bóng): tập dừng nhảy, dừng hai bước. Hai lần dẫn bóng: dẫn bóng xong phải chuyền hoặc ném. Lỗi 3 giây: không đứng quá 3 giây liên tục trong khu vực giới hạn (khu 3 giây) của đối phương khi đội mình khống chế bóng. Dùng chân đá bóng, đấm bóng: chỉ dùng tay. Chạm tay, đẩy người đối phương: tập phòng thủ bằng di chuyển chân, không dùng tay kéo đẩy.'],
  [3,'Nêu một số quy định về trang phục, dụng cụ và trọng tài trong thi đấu các môn thể thao ở trường.','Trang phục gọn, đồng phục đội, giày thể thao phù hợp; không mang đồ trang sức, vật sắc nhọn; dụng cụ (bóng, cầu, vợt, lưới) đúng kích cỡ, an toàn; có trọng tài điều khiển trận đấu, các đội phải tuân thủ quyết định của trọng tài; có thư kí ghi điểm, theo dõi thời gian.'],
  [4,'Vì sao luật bóng đá cần có quy định việt vị? Phân tích tác dụng của luật này đối với lối chơi.','Nếu không có luật việt vị, cầu thủ tấn công có thể đứng chờ sẵn ngay trước khung thành đối phương để nhận bóng dài, trận đấu sẽ chỉ còn những đường chuyền vượt tuyến, mất tính tổ chức và kém hấp dẫn. Luật việt vị buộc đội tấn công phải di chuyển, phối hợp đúng thời điểm và tạo khoảng trống bằng kĩ thuật, chiến thuật, đồng thời giúp đội phòng ngự có thể tổ chức hàng thủ. Nhờ vậy trận đấu cân bằng, giàu chiến thuật và công bằng hơn.']
 ]);
 add(M,8,'(Bổ sung) Sức khỏe và vận động',[
  [1,'Khi bị chảy máu do trầy xước hoặc vết cắt nhỏ, việc đầu tiên cần làm là gì?','rửa sạch vết thương bằng nước sạch rồi ấn gạc sạch lên để cầm máu','bôi đất hoặc lá cây','ngâm vào nước ấm lâu','để nguyên và tiếp tục tập'],
  [1,'Bộ phận nào của cơ thể dễ bị bong gân nhất trong các môn chạy, nhảy, bóng?','khớp cổ chân','khớp hàm','khớp ngón tay cái','khớp khuỷu tay'],
  [1,'Khi bạn bị ngất trong giờ tập, em nên làm gì đầu tiên?','đặt bạn nằm ở nơi thoáng, kê chân cao, nới lỏng quần áo và báo ngay thầy cô, y tế','cho bạn uống nước ngay khi còn bất tỉnh','lắc mạnh bạn để tỉnh lại','bế bạn chạy quanh sân'],
  [2,'Khi bị chấn thương, vì sao nên chườm lạnh thay cho chườm nóng trong 1–2 ngày đầu?','vì lạnh làm co mạch, giảm chảy máu bên trong, giảm sưng và đau; nóng làm giãn mạch, sưng to hơn','vì nóng làm bỏng da','vì lạnh làm cho vui hơn','vì không có nước nóng ở trường'],
  [2,'Trong tập luyện thể thao, "khối lượng vận động" và "cường độ vận động" khác nhau như thế nào?','khối lượng là tổng số lần, thời gian, quãng đường tập; cường độ là mức độ gắng sức (tốc độ, trọng lượng) khi tập','hai khái niệm giống nhau hoàn toàn','khối lượng là tốc độ, cường độ là số lần','cả hai đều chỉ thời gian nghỉ'],
  [2,'Việc sử dụng chất kích thích (doping) trong thể thao bị cấm vì lí do nào?','gây hại nghiêm trọng cho sức khỏe và vi phạm tinh thần công bằng, trung thực trong thể thao','làm giảm thành tích','vì quá đắt tiền','vì chỉ vận động viên chuyên nghiệp mới được dùng'],
  [3,'Nêu các bước sơ cứu khi bạn bị chảy máu cam trong tập luyện.','Cho bạn ngồi, đầu hơi cúi về trước (không ngửa ra sau); dùng ngón tay bóp nhẹ hai cánh mũi khoảng 10 phút, thở bằng miệng; có thể chườm lạnh vùng gáy, sống mũi; không nhét giấy sâu vào mũi, không nằm; nếu máu chảy nhiều, lâu không cầm thì báo y tế.'],
  [3,'Nêu các nguyên tắc tăng dần lượng vận động để nâng cao thể lực mà vẫn an toàn.','Tăng từ từ, mỗi lần chỉ tăng một yếu tố (số lần, thời gian hoặc tốc độ) khoảng 10%; tăng khối lượng trước rồi mới tăng cường độ; có ngày nghỉ hồi phục; theo dõi cảm giác cơ thể, nhịp tim; giảm tải khi mệt, ốm; duy trì đều đặn thay vì tăng đột ngột.'],
  [3,'Trình bày những điều nên và không nên làm khi tập luyện trong thời tiết nắng nóng.','Nên: tập sáng sớm hoặc chiều muộn, nơi thoáng mát; đội mũ, mặc đồ sáng màu, thoáng; uống nước đều; giảm cường độ; nghỉ giữa giờ. Không nên: tập lúc 11–15 giờ ngoài trời; nhịn uống nước; tập quá lâu; uống nước đá quá lạnh hoặc nước ngọt có ga; tắm nước lạnh ngay sau khi tập.'],
  [4,'Phân tích vì sao việc "nghỉ ngơi" lại là một phần bắt buộc của quá trình tập luyện chứ không phải sự lười biếng.','Tập luyện tạo ra kích thích làm cơ thể mệt và tiêu hao; sự thích nghi (cơ khỏe hơn, tim phổi tốt hơn) chỉ xảy ra trong thời gian nghỉ ngơi và ngủ, khi cơ thể sửa chữa tổn thương nhỏ và dự trữ năng lượng vượt mức ban đầu. Nếu tập liên tục không nghỉ, cơ thể không kịp hồi phục, dẫn đến quá tải: mệt kéo dài, giảm thành tích, chấn thương, dễ ốm. Vì vậy một kế hoạch tập hợp lí luôn xen kẽ ngày tập nặng, nhẹ và ngày nghỉ.']
 ]);

 /* ===== LỚP 9 ===== */
 add(M,9,'Kiến thức chung về thể dục thể thao',[
  [1,'Tập luyện thể dục thể thao thường xuyên có ý nghĩa gì đối với học sinh lớp 9 trong giai đoạn ôn thi căng thẳng?','giảm căng thẳng, tăng lưu thông máu lên não, cải thiện trí nhớ và giấc ngủ','làm mất thời gian học','không có ích gì khi đang ôn thi','làm mệt thêm nên không nên tập'],
  [1,'Nguyên tắc nào dưới đây KHÔNG thuộc các nguyên tắc tập luyện thể dục thể thao?','tập càng nhiều càng tốt, không cần nghỉ','tập thường xuyên, hệ thống','tăng tiến dần','phù hợp với cá nhân'],
  [1,'Một chế độ ăn giúp cơ thể hồi phục tốt sau tập luyện cần chú trọng nhóm chất nào?','chất đạm để tái tạo cơ và chất bột đường để bù năng lượng, cùng đủ nước','chỉ chất béo','chỉ đồ ngọt','chỉ muối'],
  [2,'Vì sao thanh thiếu niên cần hạn chế nước ngọt có ga, thức ăn nhanh dù vẫn tập luyện đều?','vì chúng nhiều đường, chất béo xấu, ít dinh dưỡng, dễ gây thừa cân, sâu răng, giảm hấp thu canxi','vì chúng làm tăng chiều cao quá nhanh','vì giá đắt','vì chúng không có vị ngon'],
  [2,'Tập luyện cùng với nghỉ ngơi và dinh dưỡng hợp lí tạo nên điều gì?','sự thích nghi và phát triển của cơ thể, nâng cao thể lực bền vững','sự mệt mỏi kéo dài','không thay đổi gì','giảm sức đề kháng'],
  [2,'Khi lập kế hoạch tập luyện cá nhân, bước đầu tiên nên làm là gì?','đánh giá tình trạng sức khỏe, thể lực hiện tại và xác định mục tiêu phù hợp','mua dụng cụ đắt tiền','tập ngay thật nặng để thử sức','sao chép y nguyên kế hoạch của vận động viên'],
  [3,'Nêu các nguyên tắc cơ bản của tập luyện thể dục thể thao và giải thích ngắn gọn từng nguyên tắc.','Thường xuyên, hệ thống: tập đều đặn, có kế hoạch. Tăng tiến: nâng dần lượng vận động. Vừa sức, phù hợp cá nhân: theo tuổi, giới, sức khỏe. Toàn diện: phát triển nhiều tố chất, nhóm cơ. Kết hợp tập luyện với nghỉ ngơi, dinh dưỡng. An toàn: khởi động, kĩ thuật đúng, phòng chấn thương.'],
  [3,'Nêu chế độ dinh dưỡng và sinh hoạt hợp lí cho học sinh lớp 9 vừa học tập vừa tập luyện thể dục thể thao.','Ăn đủ 3 bữa, đa dạng, đủ 4 nhóm chất, nhiều rau, trái cây, thực phẩm giàu canxi và sắt; uống 1,5–2 lít nước; không bỏ bữa sáng; ngủ 8–9 giờ, đúng giờ; học – nghỉ – vận động xen kẽ; vận động ít nhất 60 phút mỗi ngày; hạn chế thiết bị điện tử khuya.'],
  [3,'Hãy lập một kế hoạch tập luyện thể dục thể thao trong một tuần cho bản thân phù hợp với mục tiêu nâng cao sức bền.','Ví dụ: Thứ 2, 4, 6: chạy chậm 15–25 phút (tăng dần theo tuần) + bài tập sức mạnh thân mình 10 phút. Thứ 3, 5: thể thao tự chọn (cầu lông, bóng rổ…) 45 phút. Thứ 7: đạp xe hoặc bơi 30–40 phút. Chủ nhật: nghỉ hoặc đi bộ, kéo giãn. Mỗi buổi khởi động 8–10 phút, thả lỏng 5 phút; theo dõi nhịp tim và cảm giác; điều chỉnh khi mệt.'],
  [4,'Vì sao tập luyện thể dục thể thao hợp lí lại giúp học sinh lớp 9 học tập hiệu quả hơn thay vì làm mất thời gian học? Phân tích.','Khi vận động, tim đập nhanh hơn đưa nhiều máu và ô-xi lên não, não tiết các chất giúp tỉnh táo, giảm căng thẳng và cải thiện trí nhớ. Vận động còn giúp ngủ sâu hơn, nhờ đó kiến thức được củng cố và tinh thần hồi phục. Ngồi học liên tục nhiều giờ làm não mệt, hiệu quả giảm dần; xen kẽ 30–60 phút vận động mỗi ngày khiến thời gian học còn lại tập trung hơn. Vì vậy tập luyện hợp lí là một cách đầu tư cho việc học, không phải mất thời gian.']
 ]);
 add(M,9,'Kĩ thuật và luật cơ bản',[
  [1,'Trong chạy cự li ngắn, giai đoạn nào có tốc độ cao nhất và cần duy trì ổn định?','chạy giữa quãng','xuất phát','chạy lao sau xuất phát','sau khi qua đích'],
  [1,'Trong nhảy xa, chạy đà có vai trò gì?','tạo tốc độ nằm ngang lớn nhất trước khi giậm nhảy','để nghỉ trước khi nhảy','để chọn chỗ rơi','để làm nóng hố cát'],
  [1,'Trong nhảy cao kiểu bước qua, chân giậm nhảy là chân nào so với xà?','chân xa xà hơn','chân gần xà hơn','cả hai chân','chân nào cũng được tùy ý mỗi lần'],
  [2,'Kĩ thuật đánh tay trong chạy giữa quãng cự li ngắn đúng là gì?','khuỷu tay gấp khoảng 90 độ, đánh so le với chân, tay trước lên ngang cằm, tay sau ra sau hơi mở, vai thả lỏng','hai tay duỗi thẳng vung sang hai bên','hai tay giữ im sát người','hai tay vung cùng chiều với chân cùng bên'],
  [2,'Cách đo đà trong nhảy xa thường được thực hiện như thế nào?','chạy ngược từ ván giậm nhảy về số bước đã định hoặc đo bằng bàn chân để xác định vạch xuất phát, rồi chạy thử để chỉnh','không cần đo, chạy tùy ý','đo từ hố cát ra sau','chỉ đo một lần suốt đời'],
  [2,'Trong chạy cự li trung bình khi thi đấu, sau xuất phát các vận động viên chạy theo nguyên tắc nào?','có thể chạy chung đường, không được cản trở, xô đẩy hoặc chặn người khác','phải chạy trong ô riêng suốt cự li','được kéo áo đối thủ','có thể chạy tắt qua sân cỏ'],
  [3,'Nêu kĩ thuật chạy giữa quãng trong chạy cự li ngắn.','Thân trên hơi ngả về trước (khoảng 10–15 độ); chân đạp sau duỗi thẳng mạnh, đưa đùi lên cao về trước, tiếp đất bằng nửa trước bàn chân, bước dài và tần số cao; tay đánh so le với chân, khuỷu gấp 90 độ; đầu thẳng, mắt nhìn trước, vai và mặt thả lỏng, thở tự nhiên.'],
  [3,'Nêu cách sửa các lỗi thường gặp khi học nhảy xa kiểu ngồi.','Giậm nhảy không trúng ván: đo lại đà, đánh dấu bước đà, chạy đà ổn định. Giậm yếu, bay thấp: tập bật nhảy, đá lăng, chú ý bước cuối ngắn nhanh và duỗi hết chân giậm. Trên không không thu chân: tập nhảy từ bục thấp thu gối. Tiếp đất ngã sau: tập duỗi chân trước và gập thân, tay đưa trước khi tiếp đất.'],
  [3,'Nêu một số điểm luật về phạm quy trong chạy cự li ngắn và chạy cự li trung bình.','Cự li ngắn: xuất phát trước hiệu lệnh (phạm quy xuất phát); chạy lấn sang ô chạy khác; cản trở đối thủ. Cự li trung bình: xô đẩy, chặn, cản trở người khác; chạy tắt ra khỏi đường chạy; nhận sự trợ giúp từ bên ngoài. Vận động viên phạm quy có thể bị loại.'],
  [4,'Vận dụng kiến thức đã học, hãy giải thích vì sao ở chạy cự li ngắn người chạy cần bước dài và tần số bước cao đồng thời, còn ở chạy cự li trung bình lại ưu tiên bước đều và tiết kiệm sức.','Tốc độ chạy = độ dài bước x tần số bước. Cự li ngắn chỉ kéo dài vài chục giây, cơ thể dùng nguồn năng lượng tức thời, nên phải tận dụng cả độ dài bước và tần số để đạt tốc độ tối đa, không cần tiết kiệm. Cự li trung bình kéo dài vài phút, năng lượng chủ yếu phụ thuộc vào ô-xi hít vào; nếu bước quá dài, quá nhanh sẽ tiêu hao năng lượng sớm, gặp cực điểm nặng và giảm tốc ở cuối. Vì vậy phải chạy bước đều, nhịp thở ổn định, phân phối sức để về đích với thành tích tốt nhất.']
 ]);
 add(M,9,'Sức khỏe và vận động',[
  [1,'Nhịp tim tối đa theo lứa tuổi được ước tính bằng công thức nào?','khoảng 220 trừ đi số tuổi','số tuổi nhân 2','100 cộng số tuổi','luôn là 200'],
  [1,'Khi cơ thể bị mất nước nhiều qua mồ hôi, cần bù lại gì ngoài nước?','muối khoáng (điện giải)','đồ ngọt nhiều đường','nước đá thật lạnh','chất béo'],
  [1,'Tư thế ngồi học sai lâu ngày dễ dẫn đến bệnh nào?','cong vẹo cột sống','viêm họng','đau răng','rụng tóc'],
  [2,'Vùng nhịp tim phù hợp để phát triển sức bền chung ở học sinh khoảng bao nhiêu phần trăm nhịp tim tối đa?','khoảng 60–75%','dưới 30%','95–100% suốt buổi','không cần quan tâm nhịp tim'],
  [2,'Dấu hiệu nào cho biết cơ thể đã hồi phục tốt sau một buổi tập nặng?','sáng hôm sau nhịp tim nghỉ bình thường, không đau mỏi nhiều, ăn ngủ tốt, cảm giác muốn tập','nhịp tim nghỉ cao hơn hẳn, mệt, chán ăn','mất ngủ và đau nhức toàn thân','không muốn vận động suốt tuần'],
  [2,'Vì sao vận động giúp phòng chống thừa cân, béo phì?','vì vận động tiêu hao năng lượng dư thừa, tăng khối cơ, cải thiện chuyển hóa','vì vận động làm người lùn đi','vì vận động giúp ăn nhiều hơn mà không ảnh hưởng','vì vận động làm hết đói'],
  [3,'Nêu cách sử dụng nhịp tim để điều chỉnh cường độ tập luyện của bản thân.','Tính nhịp tim tối đa (220 – tuổi, ví dụ 15 tuổi là 205). Tập sức bền chung ở 60–75% (khoảng 125–155 lần/phút); tập cường độ cao chỉ trong thời gian ngắn và có nghỉ. Đo nhịp tim ngay sau tập (đếm 10 giây x 6); nếu quá cao thì giảm tốc độ, nếu quá thấp thì tăng. Theo dõi nhịp tim nghỉ buổi sáng: tăng cao bất thường là dấu hiệu chưa hồi phục.'],
  [3,'Nêu các biện pháp phòng tránh cong vẹo cột sống và cận thị ở học sinh.','Ngồi học đúng tư thế, bàn ghế đúng cỡ, đủ ánh sáng, mắt cách sách 25–30 cm; không đeo cặp một bên, cặp không quá nặng; sau 30–45 phút học thì đứng lên vận động, nhìn xa; tập thể dục thường xuyên, nhất là các bài tập cho lưng, bụng; bơi, xà đơn; hạn chế dùng thiết bị điện tử; khám sức khỏe định kì.'],
  [3,'Trình bày tác hại của lối sống ít vận động đối với sức khỏe thanh thiếu niên.','Thừa cân, béo phì; cơ yếu, xương kém chắc; tim phổi hoạt động kém, dễ mệt; tư thế xấu, cong vẹo cột sống; nguy cơ sớm mắc bệnh tim mạch, tiểu đường; tinh thần uể oải, dễ căng thẳng, khó ngủ, giảm tập trung học tập.'],
  [4,'Phân tích vì sao cùng một bài tập, hai học sinh có thể lực khác nhau lại cần cường độ khác nhau và cách dùng nhịp tim để cá nhân hóa bài tập.','Mỗi người có trình độ thể lực, cân nặng, sức khỏe khác nhau nên cùng một tốc độ chạy, với bạn khỏe là nhẹ còn với bạn yếu đã là quá sức, dễ gây mệt mỏi, chấn thương hoặc ngược lại không đủ kích thích để tiến bộ. Nhịp tim phản ánh mức gắng sức của chính cơ thể đó, vì vậy dùng tỉ lệ phần trăm nhịp tim tối đa làm chuẩn thì mỗi bạn tự điều chỉnh tốc độ để nhịp tim nằm trong vùng phù hợp. Cách này giúp cả hai cùng tập an toàn, hiệu quả theo đúng khả năng của mình.']
 ]);
 add(M,9,'Kĩ thuật và luật thi đấu',[
  [1,'Trong bóng đá, quả phạt đền được thực hiện từ khoảng cách bao nhiêu mét so với vạch cầu môn?','11 m','9 m','16,5 m','5,5 m'],
  [1,'Trong cầu lông, một trận đấu thường được tính theo thể thức nào?','thắng 2 trong 3 ván, mỗi ván 21 điểm','thắng 1 ván 11 điểm','thắng 3 trong 5 hiệp 25 điểm','tính thời gian 45 phút'],
  [1,'Trong bóng chuyền, chiều cao lưới thi đấu của nam và nữ (theo luật) lần lượt là bao nhiêu?','2,43 m và 2,24 m','1,55 m và 1,50 m','3,05 m và 2,80 m','2,00 m và 1,80 m'],
  [2,'Trong bóng rổ, cầu thủ phạm bao nhiêu lỗi cá nhân thì bị truất quyền thi đấu trong trận (theo luật FIBA)?','5 lỗi','2 lỗi','3 lỗi','10 lỗi'],
  [2,'Trong cầu lông, khi phát cầu, điểm tiếp xúc giữa vợt và cầu phải ở độ cao nào so với mặt sân (luật hiện hành)?','không cao quá 1,15 m','bất kì độ cao nào','cao trên đầu','ngang vai'],
  [2,'Trong bóng đá, khi thủ môn cầm bóng trong tay quá 6 giây hoặc nhận bóng từ đường chuyền về bằng chân của đồng đội thì đội đối phương được hưởng gì?','quả phạt gián tiếp','quả phạt đền','quả phạt góc','quả ném biên'],
  [3,'Nêu các chiến thuật cơ bản trong thi đấu cầu lông đánh đơn.','Phát cầu đa dạng (cao sâu, ngắn); đánh cầu vào các góc xa để kéo đối thủ di chuyển; kết hợp đánh cao sâu cuối sân và bỏ nhỏ gần lưới; đập cầu khi cầu cao thuận lợi; luôn trở về vị trí trung tâm sau mỗi lần đánh; tấn công vào điểm yếu (trái tay) của đối thủ; giữ nhịp độ phù hợp với thể lực.'],
  [3,'Nêu các vị trí và vai trò cơ bản của cầu thủ trong đội bóng chuyền.','Chủ công: đập bóng ở vị trí biên; Phụ công: tấn công nhanh ở giữa và chắn bóng; Chuyền hai: điều phối, chuyền bóng cho người đập; Đối chuyền: tấn công ở vị trí đối diện chuyền hai; Libero: chuyên phòng thủ, không được phát bóng, đập bóng, chắn bóng. Các vị trí xoay vòng theo luật sau mỗi lần giành quyền phát bóng.'],
  [3,'Nêu nhiệm vụ của trọng tài và những biểu hiện thiếu văn hóa cần tránh của người thi đấu, khán giả.','Trọng tài điều khiển trận đấu theo luật, quyết định lỗi, điểm, thời gian, bảo đảm công bằng và an toàn. Người chơi cần tránh: phản ứng thô lỗ với trọng tài, chơi xấu, cố ý gây chấn thương, gian lận, bỏ trận. Khán giả cần tránh: la ó, chửi bới, ném đồ vật xuống sân, xúc phạm cầu thủ, trọng tài, gây mất trật tự.'],
  [4,'Vì sao các môn bóng như bóng chuyền, bóng rổ, bóng đá lại chú trọng chiến thuật và phân công vị trí? Phân tích vai trò của sự phối hợp đồng đội đối với kết quả thi đấu.','Trong các môn bóng tập thể, không cầu thủ nào có thể làm mọi việc; mỗi vị trí đòi hỏi kĩ thuật, thể hình và nhiệm vụ riêng (tấn công, phòng thủ, điều phối). Chiến thuật sắp xếp các vị trí và cách di chuyển, chuyền bóng để phát huy điểm mạnh của từng người và khai thác điểm yếu đối thủ. Một đội có cá nhân xuất sắc nhưng thiếu phối hợp thường thua đội biết tổ chức, hỗ trợ, bù trừ cho nhau. Vì vậy tinh thần đồng đội, hiểu ý và kỉ luật chiến thuật là yếu tố quyết định không kém kĩ thuật cá nhân.']
 ]);
 add(M,9,'(Bổ sung) Sức khỏe và vận động',[
  [1,'Khi xây dựng chế độ ăn cho ngày thi đấu, bữa ăn trước thi đấu nên như thế nào?','ăn trước 2–3 giờ, dễ tiêu, giàu chất bột đường, ít chất béo, không ăn quá no','ăn thật nhiều đồ chiên rán ngay trước giờ thi','nhịn ăn hoàn toàn','chỉ uống nước ngọt có ga'],
  [1,'Hoạt động nào sau đây giúp phát triển sự mềm dẻo của cơ thể?','các bài tập kéo giãn, ép dẻo, yoga cơ bản','chạy 60 m','nâng tạ','chống đẩy nhanh'],
  [1,'Khi tập luyện ngoài trời mà gặp sấm sét, giông bão, em nên làm gì?','dừng tập ngay, vào nơi trú an toàn, tránh đứng dưới cây to, cột điện','tiếp tục tập cho xong','đứng dưới cây to để trú','chạy ra giữa sân rộng'],
  [2,'Vì sao sau khi thi đấu hoặc tập nặng không nên tắm nước lạnh ngay?','vì cơ thể đang nóng, mạch máu giãn, gặp lạnh đột ngột gây co mạch, dễ choáng, cảm lạnh, chuột rút','vì nước lạnh làm mất mồ hôi','vì sẽ làm bẩn nước','vì luật thi đấu không cho phép'],
  [2,'Tập luyện thể dục thể thao góp phần phòng tránh những thói quen có hại nào ở thanh thiếu niên?','hút thuốc, uống rượu bia, nghiện trò chơi điện tử, thức khuya','đọc sách, học nhóm','đi ngủ sớm','ăn rau xanh'],
  [2,'Khi một bạn có dấu hiệu say nóng nặng (da khô nóng, lơ mơ, bất tỉnh), em cần làm gì ngay?','gọi cấp cứu hoặc người lớn ngay, đưa bạn vào chỗ mát, làm mát cơ thể bằng khăn ướt, quạt','ép bạn uống nhiều nước khi đang bất tỉnh','để bạn nằm ngoài nắng chờ tỉnh','cho bạn chạy nhẹ để hồi phục'],
  [3,'Nêu các bước xây dựng và thực hiện kế hoạch tập luyện cá nhân hướng tới một mục tiêu cụ thể (ví dụ chạy 1500 m đạt yêu cầu).','1. Đánh giá thể lực hiện tại (thời gian chạy hiện tại, nhịp tim). 2. Đặt mục tiêu cụ thể, có thời hạn. 3. Chọn bài tập phù hợp (chạy chậm dài, chạy biến tốc, sức mạnh chân, kéo giãn). 4. Lập lịch tuần, tăng tiến dần, có ngày nghỉ. 5. Thực hiện và ghi chép kết quả. 6. Kiểm tra định kì, điều chỉnh kế hoạch. 7. Kết hợp dinh dưỡng, ngủ đủ.'],
  [3,'Nêu các nguyên tắc dinh dưỡng và bù nước trước, trong và sau thi đấu thể thao.','Trước: ăn bữa chính trước 2–3 giờ, dễ tiêu, nhiều bột đường; uống 300–500 ml nước trước 1–2 giờ. Trong: uống từng ngụm nhỏ 100–200 ml mỗi 15–20 phút, có thể dùng nước có điện giải nếu kéo dài. Sau: bù nước và muối khoáng, ăn nhẹ có bột đường và chất đạm trong vòng 30–60 phút, bữa chính đầy đủ sau đó; tránh rượu bia, nước ngọt có ga.'],
  [3,'Trình bày vai trò của thể dục thể thao trong việc hình thành lối sống lành mạnh và phẩm chất của người học sinh.','Rèn tính kỉ luật, kiên trì, ý chí vượt khó; biết hợp tác, tôn trọng luật và người khác; biết tự chăm sóc sức khỏe, sinh hoạt điều độ; tránh xa thói quen xấu; tự tin, lạc quan; hình thành thói quen vận động suốt đời.'],
  [4,'Vận dụng kiến thức đã học, hãy phân tích vì sao một học sinh lớp 9 muốn giảm cân lành mạnh không nên nhịn ăn mà cần kết hợp vận động với ăn uống hợp lí.','Nhịn ăn làm cơ thể thiếu năng lượng và chất dinh dưỡng trong giai đoạn còn phát triển, gây mệt mỏi, giảm tập trung, mất cơ, ảnh hưởng chiều cao và sức đề kháng; khi ăn lại dễ tăng cân nhanh hơn. Vận động đều (sức bền 30–60 phút mỗi ngày, kết hợp bài tập sức mạnh) tiêu hao năng lượng dư thừa, tăng khối cơ nên chuyển hóa tốt hơn. Ăn đủ 3 bữa, giảm đồ ngọt, chiên rán, nước có ga, tăng rau, trái cây, chất đạm vừa đủ giúp giảm cân từ từ mà vẫn khỏe mạnh và phát triển bình thường.']
 ]);

})();
