/* ============================================================
   NGÂN HÀNG TIN HỌC (THCS) — bổ sung cho đủ chuẩn
   Mỗi mục: ≥6 trắc nghiệm + ≥4 tự luận + có câu nâng cao (mức 4).
   Nguyên bản, bám SGK Kết nối tri thức. Lượt này: LỚP 6.
   TN [mức,'câu','ĐÚNG','sai','sai','sai'] · TL [mức,'câu','đáp án']
   ============================================================ */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Tin học';

 /* ===================== LỚP 6 ===================== */
 add(M,6,'Bài 1: Thông tin và dữ liệu',[
  [1,'Thông tin là gì?','Những gì đem lại hiểu biết cho con người về sự vật, sự việc','Chỉ là con số','Chỉ là hình ảnh','Máy tính'],
  [1,'Dữ liệu là gì?','Thông tin được ghi lại (chữ, số, hình ảnh, âm thanh...) đưa vào máy tính','Chỉ là âm thanh','Chỉ là con người','Phần mềm'],
  [2,'Khi em nghe dự báo thời tiết "ngày mai trời mưa", đó là gì?','Thông tin','Phần cứng','Thiết bị','Chương trình'],
  [2,'Vật mang tin là gì?','Phương tiện dùng để lưu trữ và truyền thông tin (sách, đĩa, thẻ nhớ...)','Con người','Thông tin','Trí nhớ'],
  [2,'Dạng nào KHÔNG phải là dạng cơ bản của thông tin trong tin học?','Mùi vị','Văn bản','Hình ảnh','Âm thanh'],
  [3,'Phân biệt thông tin và dữ liệu, cho ví dụ.','Thông tin đem lại hiểu biết; dữ liệu là thông tin được ghi lại, đưa vào máy tính xử lí. VD: "18 độ C" là dữ liệu; biết "trời lạnh" là thông tin.'],
  [3,'Nêu ba dạng thông tin cơ bản và mỗi dạng một ví dụ.','Văn bản (bài báo), hình ảnh (bức ảnh), âm thanh (bài hát). (Có thể thêm phim/đa phương tiện.)'],
  [4,'Vì sao cùng một dữ liệu nhưng có thể đem lại thông tin khác nhau với mỗi người?','Vì thông tin phụ thuộc vào hiểu biết, hoàn cảnh của người tiếp nhận. Cùng con số hay hình ảnh, người này rút ra hiểu biết này, người khác rút ra hiểu biết khác tùy cách hiểu và mục đích.']
 ]);
 add(M,6,'Bài 2: Xử lý thông tin',[
  [1,'Quá trình xử lí thông tin gồm những hoạt động cơ bản nào?','Thu nhận, lưu trữ, xử lí, truyền thông tin','Chỉ lưu trữ','Chỉ truyền','Chỉ in'],
  [1,'Bộ phận nào của máy tính thực hiện việc xử lí thông tin?','Bộ xử lí (CPU)','Màn hình','Bàn phím','Loa'],
  [2,'Thiết bị vào dùng để làm gì?','Thu nhận (nhập) thông tin vào máy tính','Hiển thị kết quả','Xử lí','Lưu trữ'],
  [2,'Thiết bị nào dưới đây là thiết bị ra?','Màn hình','Bàn phím','Chuột','Micro'],
  [2,'Bộ nhớ của máy tính dùng để làm gì?','Lưu trữ dữ liệu','Nhập dữ liệu','Hiển thị','In ấn'],
  [3,'Nêu các hoạt động xử lí thông tin của máy tính tương ứng với con người.','Thu nhận (giác quan ↔ thiết bị vào); xử lí và ghi nhớ (bộ não ↔ CPU, bộ nhớ); truyền/đưa ra (nói, viết ↔ thiết bị ra).'],
  [3,'Kể tên một số thiết bị vào và thiết bị ra của máy tính.','Thiết bị vào: bàn phím, chuột, micro, máy quét, webcam. Thiết bị ra: màn hình, loa, máy in, máy chiếu.'],
  [4,'Vì sao nói máy tính xử lí thông tin tốt hơn con người ở một số việc nhưng không thay thế hoàn toàn con người?','Máy tính tính toán nhanh, chính xác, làm việc không mệt mỏi với khối lượng lớn; nhưng máy tính làm theo chương trình do con người tạo ra, không có sáng tạo, cảm xúc, hiểu biết linh hoạt như con người.']
 ]);
 add(M,6,'Bài 3: Thông tin trong máy tính',[
  [1,'Máy tính biểu diễn và xử lí thông tin ở dạng nào?','Dãy bit (số 0 và 1)','Chữ cái','Hình vẽ','Tiếng nói'],
  [1,'Một bit có thể nhận mấy giá trị?','Hai giá trị: 0 hoặc 1','Một','Mười','Không giới hạn'],
  [2,'1 byte bằng bao nhiêu bit?','8 bit','2 bit','4 bit','16 bit'],
  [2,'Đơn vị nào lớn hơn Ki-lô-bai (KB)?','Mê-ga-bai (MB)','Bai (B)','Bit','Không có'],
  [2,'1 KB xấp xỉ bằng bao nhiêu byte?','1024 byte','10 byte','100 byte','8 byte'],
  [3,'Sắp xếp các đơn vị đo dữ liệu từ nhỏ đến lớn: MB, B, KB, GB.','B < KB < MB < GB.'],
  [3,'Vì sao máy tính dùng hệ nhị phân (0 và 1) để biểu diễn thông tin?','Vì các mạch điện tử trong máy tính dễ biểu diễn hai trạng thái (có điện/không điện, bật/tắt) tương ứng 1 và 0, nên tin cậy, đơn giản và chính xác.'],
  [4,'Một thiết bị nhớ 2 GB có thể chứa khoảng bao nhiêu tệp ảnh, mỗi ảnh 2 MB? Giải thích.','2 GB = 2048 MB. Số ảnh ≈ 2048 : 2 = khoảng 1024 ảnh (chưa trừ dung lượng hệ thống).']
 ]);
 add(M,6,'Bài 4: Mạng máy tính',[
  [1,'Mạng máy tính là gì?','Nhiều máy tính được kết nối để trao đổi dữ liệu, dùng chung thiết bị','Một máy tính riêng lẻ','Một phần mềm','Một tệp'],
  [1,'Lợi ích nào dưới đây KHÔNG phải của mạng máy tính?','Làm máy tính chạy chậm hơn','Chia sẻ dữ liệu','Dùng chung máy in','Trao đổi thông tin'],
  [2,'Thiết bị nào thường dùng để kết nối các máy tính trong mạng?','Bộ định tuyến (Router) / bộ chuyển mạch (Switch)','Máy in','Loa','Bàn phím'],
  [2,'Mạng kết nối các máy tính trong phạm vi hẹp (một phòng, một tòa nhà) gọi là gì?','Mạng cục bộ (LAN)','Internet','WWW','Email'],
  [2,'Thành phần nào là thiết bị đầu cuối trong mạng?','Máy tính, điện thoại của người dùng','Dây cáp','Router','Switch'],
  [3,'Nêu các lợi ích của mạng máy tính.','Chia sẻ dữ liệu, dùng chung thiết bị (máy in, ổ đĩa), trao đổi thông tin nhanh, làm việc cộng tác, tiết kiệm chi phí.'],
  [3,'Phân biệt mạng có dây và mạng không dây.','Mạng có dây dùng cáp để kết nối (ổn định, nhanh); mạng không dây dùng sóng (Wi-Fi) để kết nối (tiện lợi, di động nhưng dễ bị nhiễu).'],
  [4,'Vì sao trong trường học, việc kết nối các máy tính thành mạng lại cần thiết?','Giúp chia sẻ bài giảng, dữ liệu giữa các máy; dùng chung máy in, Internet; giáo viên quản lí, giao bài; học sinh truy cập tài nguyên học tập chung, tiết kiệm chi phí và thuận tiện.']
 ]);
 add(M,6,'Bài 5: Internet',[
  [1,'Internet là gì?','Mạng kết nối hàng tỉ máy tính và thiết bị trên toàn thế giới','Một máy tính','Một phần mềm soạn thảo','Một tệp văn bản'],
  [1,'Để truy cập Internet, máy tính cần có gì?','Kết nối mạng (qua nhà cung cấp dịch vụ Internet)','Chỉ cần máy in','Chỉ cần loa','Không cần gì'],
  [2,'Dịch vụ nào dưới đây là dịch vụ trên Internet?','Thư điện tử, tìm kiếm, mạng xã hội','Quét virus trên máy riêng','Soạn thảo văn bản ngoại tuyến','Vẽ hình trên giấy'],
  [2,'ISP là viết tắt của gì?','Nhà cung cấp dịch vụ Internet','Thiết bị ra','Mạng cục bộ','Phần mềm diệt virus'],
  [2,'Đặc điểm nào đúng về Internet?','Có tính toàn cầu và không thuộc sở hữu của riêng ai','Chỉ dùng trong một nước','Thuộc một công ty duy nhất','Chỉ có văn bản'],
  [3,'Nêu một số lợi ích và một số tác hại của Internet.','Lợi ích: tra cứu thông tin, học tập, liên lạc, giải trí, mua bán. Tác hại: nghiện Internet, thông tin xấu/giả, lừa đảo, lộ thông tin cá nhân nếu dùng không an toàn.'],
  [3,'Kể tên một số dịch vụ phổ biến trên Internet.','World Wide Web (trang web), thư điện tử, tìm kiếm thông tin, mạng xã hội, lưu trữ đám mây, hội họp trực tuyến.'],
  [4,'Vì sao nói Internet vừa là cơ hội vừa là thách thức đối với học sinh?','Cơ hội: kho tri thức khổng lồ, học tập, kết nối. Thách thức: dễ gặp thông tin xấu, nghiện, lừa đảo, mất an toàn. Cần biết khai thác lợi ích và tự bảo vệ, sử dụng có trách nhiệm.']
 ]);
 add(M,6,'Bài 6: Mạng thông tin toàn cầu',[
  [1,'World Wide Web (WWW) là gì?','Dịch vụ cung cấp, chia sẻ thông tin dưới dạng các trang web trên Internet','Một loại máy tính','Một thiết bị mạng','Một phần mềm diệt virus'],
  [1,'Phần mềm dùng để xem các trang web gọi là gì?','Trình duyệt web','Hệ điều hành','Bảng tính','Trình chiếu'],
  [2,'Đâu là một trình duyệt web?','Google Chrome','Microsoft Word','Windows','Excel'],
  [2,'Địa chỉ của một trang web được gọi là gì?','URL (địa chỉ web)','Email','CPU','RAM'],
  [2,'Siêu liên kết (hyperlink) dùng để làm gì?','Liên kết, chuyển nhanh đến trang/tài liệu khác','In văn bản','Tính toán','Diệt virus'],
  [3,'Phân biệt Internet và World Wide Web.','Internet là mạng kết nối toàn cầu (hạ tầng); WWW là một dịch vụ chạy trên Internet, gồm các trang web được liên kết với nhau. Internet rộng hơn, WWW là một phần của Internet.'],
  [3,'Nêu các bước cơ bản để truy cập một trang web.','Mở trình duyệt web → gõ địa chỉ (URL) vào thanh địa chỉ → nhấn Enter → trang web hiển thị; dùng siêu liên kết để chuyển trang.'],
  [4,'Vì sao siêu liên kết làm cho việc tìm và đọc thông tin trên web trở nên thuận tiện?','Siêu liên kết cho phép chuyển nhanh giữa các trang, tài liệu liên quan chỉ bằng một cú nhấp; nhờ đó người dùng dễ dàng đi từ thông tin này đến thông tin khác, tạo nên mạng lưới thông tin liên kết khổng lồ.']
 ]);
 add(M,6,'Bài 7: Tìm kiếm thông tin trên Internet',[
  [1,'Công cụ dùng để tìm kiếm thông tin trên Internet gọi là gì?','Máy tìm kiếm (Search engine)','Máy in','Bảng tính','Loa'],
  [1,'Đâu là một máy tìm kiếm?','Google','Word','Paint','Windows'],
  [2,'Để tìm kiếm, em nhập cái gì vào máy tìm kiếm?','Từ khóa','Mật khẩu ngân hàng','Số điện thoại cá nhân','Địa chỉ nhà'],
  [2,'Để kết quả tìm kiếm chính xác hơn, em nên làm gì?','Chọn từ khóa cụ thể, rõ ràng','Nhập từ khóa càng mơ hồ càng tốt','Nhập thật nhiều từ không liên quan','Không cần từ khóa'],
  [2,'Khi dùng thông tin tìm được trên Internet, em cần lưu ý điều gì?','Kiểm chứng nguồn tin cậy, tôn trọng bản quyền','Tin ngay mọi kết quả','Sao chép tùy ý','Bỏ qua nguồn gốc'],
  [3,'Nêu các bước tìm kiếm thông tin trên Internet bằng máy tìm kiếm.','Mở trình duyệt, truy cập máy tìm kiếm; nhập từ khóa; nhấn tìm; chọn và mở kết quả phù hợp; kiểm tra độ tin cậy của thông tin.'],
  [3,'Vì sao cần chọn từ khóa phù hợp khi tìm kiếm?','Từ khóa đúng, cụ thể giúp máy tìm kiếm trả về kết quả sát với nhu cầu, tiết kiệm thời gian; từ khóa mơ hồ cho kết quả lan man, khó tìm đúng thông tin.'],
  [4,'Vì sao không nên tin tưởng tuyệt đối mọi thông tin tìm thấy trên Internet?','Vì ai cũng có thể đăng thông tin lên mạng, có thông tin sai, giả, lỗi thời hoặc thiên lệch. Cần đối chiếu nhiều nguồn, chọn nguồn uy tín, kiểm chứng trước khi tin và sử dụng.']
 ]);
 add(M,6,'Bài 8: Thư điện tử',[
  [1,'Thư điện tử (email) là gì?','Dịch vụ gửi, nhận thư qua Internet','Thư viết tay','Tin nhắn điện thoại','Cuộc gọi'],
  [1,'Một địa chỉ email luôn có kí tự nào?','@','#','&','%'],
  [2,'Thành phần nào KHÔNG có trong một email?','Số căn cước của người nhận','Địa chỉ người nhận','Chủ đề (tiêu đề)','Nội dung thư'],
  [2,'Ưu điểm của thư điện tử so với thư truyền thống là gì?','Gửi nhanh, rẻ, gửi được nhiều người, kèm tệp','Phải chờ nhiều ngày','Tốn nhiều tiền tem','Không gửi được tệp'],
  [2,'Mục "Đính kèm" (Attach) trong email dùng để làm gì?','Gửi kèm tệp (ảnh, văn bản...) theo thư','Xóa thư','In thư','Đổi mật khẩu'],
  [3,'Nêu các bước cơ bản để gửi một email.','Đăng nhập hộp thư; chọn Soạn thư; nhập địa chỉ người nhận, tiêu đề, nội dung; đính kèm tệp nếu cần; nhấn Gửi.'],
  [3,'Nêu một số lưu ý để sử dụng thư điện tử an toàn, lịch sự.','Không mở tệp đính kèm lạ; đặt mật khẩu mạnh; viết tiêu đề rõ, lời lẽ lịch sự; kiểm tra kĩ địa chỉ người nhận; không gửi thông tin nhạy cảm bừa bãi.'],
  [4,'Vì sao không nên mở các tệp đính kèm hoặc liên kết lạ trong email?','Vì chúng có thể chứa virus, mã độc hoặc là email lừa đảo nhằm đánh cắp thông tin, mật khẩu. Mở ra có thể làm hỏng máy, mất dữ liệu hoặc bị chiếm tài khoản.']
 ]);
 add(M,6,'Bài 9: An toàn thông tin trên Internet',[
  [1,'An toàn thông tin là gì?','Bảo vệ thông tin và dữ liệu khỏi bị mất, đánh cắp, hư hỏng','Xóa hết dữ liệu','Chia sẻ mọi thông tin','Tắt máy tính'],
  [1,'Phần mềm độc hại (virus) có thể gây ra điều gì?','Làm hỏng, mất dữ liệu, chậm máy, đánh cắp thông tin','Giúp máy chạy nhanh hơn','Bảo vệ máy tính','Tăng dung lượng'],
  [2,'Để bảo vệ tài khoản, em nên đặt mật khẩu như thế nào?','Đủ dài, kết hợp chữ, số, kí tự; không dễ đoán','Ngày sinh của mình','123456','Tên của mình'],
  [2,'Việc làm nào gây mất an toàn thông tin?','Nhấp vào liên kết lạ, cài phần mềm không rõ nguồn gốc','Cài phần mềm diệt virus','Sao lưu dữ liệu','Đặt mật khẩu mạnh'],
  [2,'Khi gặp thông tin xấu, lừa đảo trên mạng, em nên làm gì?','Không làm theo, báo người lớn, chặn/ báo cáo','Làm theo ngay','Chia sẻ cho bạn bè','Cung cấp thông tin cá nhân'],
  [3,'Nêu một số biện pháp bảo vệ an toàn thông tin cho máy tính và tài khoản cá nhân.','Dùng mật khẩu mạnh, không chia sẻ; cài và cập nhật phần mềm diệt virus; không mở liên kết/tệp lạ; sao lưu dữ liệu; không cung cấp thông tin cá nhân bừa bãi.'],
  [3,'Vì sao không nên chia sẻ mật khẩu và thông tin cá nhân cho người khác trên mạng?','Vì kẻ xấu có thể lợi dụng để chiếm tài khoản, lừa đảo, mạo danh, gây hại cho em và người khác; thông tin cá nhân bị lộ rất khó thu hồi.'],
  [4,'Vì sao sao lưu (backup) dữ liệu định kì là việc quan trọng?','Vì dữ liệu có thể mất do virus, hỏng thiết bị, xóa nhầm. Có bản sao lưu giúp khôi phục lại dữ liệu quan trọng, tránh thiệt hại; đây là biện pháp phòng ngừa chủ động và hiệu quả.']
 ]);
 add(M,6,'Bài 10: Sơ đồ tư duy',[
  [1,'Sơ đồ tư duy là gì?','Cách trình bày thông tin trực quan bằng từ khóa, hình ảnh, nhánh','Một đoạn văn dài','Một bảng tính','Một trò chơi'],
  [1,'Thành phần ở trung tâm sơ đồ tư duy thường là gì?','Chủ đề chính','Một con số bất kì','Dấu chấm câu','Mật khẩu'],
  [2,'Lợi ích của sơ đồ tư duy là gì?','Giúp ghi nhớ, hệ thống hóa, nắm ý chính nhanh','Làm thông tin rối hơn','Tốn giấy vô ích','Không có lợi ích'],
  [2,'Các nhánh trong sơ đồ tư duy thể hiện điều gì?','Các ý triển khai từ chủ đề chính','Các lỗi sai','Các mật khẩu','Các địa chỉ web'],
  [2,'Khi vẽ sơ đồ tư duy, nên dùng gì để các ý ngắn gọn, dễ nhớ?','Từ khóa và hình ảnh','Đoạn văn dài','Toàn chữ hoa','Chỉ con số'],
  [3,'Nêu các bước cơ bản để tạo một sơ đồ tư duy.','Viết chủ đề chính ở trung tâm; vẽ các nhánh chính là các ý lớn; từ nhánh chính vẽ nhánh phụ chi tiết; dùng từ khóa, hình ảnh, màu sắc để dễ nhớ.'],
  [3,'Vì sao sơ đồ tư duy giúp học bài hiệu quả hơn?','Vì nó trình bày trực quan, có cấu trúc; thể hiện mối liên hệ giữa các ý; dùng từ khóa, màu sắc, hình ảnh giúp dễ hiểu, dễ nhớ và ôn lại nhanh.'],
  [4,'Khi tóm tắt một bài học dài, vì sao sơ đồ tư duy lại phù hợp hơn chép lại toàn bộ nội dung?','Sơ đồ tư duy giữ lại ý chính và mối liên hệ giữa chúng bằng từ khóa, hình ảnh, giúp nhìn tổng thể và nhớ lâu; chép lại toàn bộ dài dòng, khó nắm ý chính và mất thời gian hơn.']
 ]);
 add(M,6,'Bài 11: Định dạng văn bản',[
  [1,'Định dạng văn bản là gì?','Thay đổi cách trình bày (phông chữ, cỡ chữ, màu, căn lề...) cho văn bản','Xóa văn bản','Tắt máy','Gửi email'],
  [1,'Thao tác nào là định dạng kí tự?','Đổi phông chữ, cỡ chữ, in đậm','Lưu tệp','In văn bản','Mở tệp'],
  [2,'Để chữ in đậm, thường dùng tổ hợp phím nào?','Ctrl + B','Ctrl + S','Ctrl + P','Ctrl + O'],
  [2,'Căn giữa, căn đều hai bên là định dạng của đối tượng nào?','Đoạn văn bản','Một kí tự đơn lẻ','Tệp tin','Thư mục'],
  [2,'Thao tác nào giúp làm nổi bật tiêu đề của văn bản?','Tăng cỡ chữ, in đậm, căn giữa','Xóa tiêu đề','Thu nhỏ hết cỡ','Đổi thành màu trắng trên nền trắng'],
  [3,'Phân biệt định dạng kí tự và định dạng đoạn văn bản.','Định dạng kí tự: phông, cỡ, kiểu (đậm/nghiêng), màu chữ. Định dạng đoạn: căn lề, khoảng cách dòng, thụt lề, khoảng cách giữa các đoạn.'],
  [3,'Nêu các bước để định dạng một đoạn văn bản (ví dụ căn giữa, in đậm).','Chọn (bôi đen) đoạn/kí tự cần định dạng; chọn lệnh định dạng trên thanh công cụ (hoặc phím tắt) như in đậm (Ctrl+B), căn giữa; kiểm tra kết quả.'],
  [4,'Vì sao định dạng văn bản hợp lí lại quan trọng khi trình bày một tài liệu?','Giúp văn bản rõ ràng, dễ đọc, làm nổi bật ý chính (tiêu đề, mục), tạo tính thẩm mĩ và chuyên nghiệp; người đọc nắm thông tin nhanh và thiện cảm hơn. Định dạng rối hoặc thiếu nhất quán gây khó đọc.']
 ]);
 add(M,6,'Bài 12: Trình bày thông tin ở dạng bảng',[
  [1,'Bảng gồm những thành phần nào?','Hàng và cột, giao nhau tạo thành các ô','Chỉ có hàng','Chỉ có cột','Chỉ có một ô'],
  [1,'Khi nào nên trình bày thông tin ở dạng bảng?','Khi thông tin có nhiều mục cần so sánh, sắp xếp theo hàng, cột','Khi viết một đoạn văn cảm xúc','Khi vẽ tranh','Khi nghe nhạc'],
  [2,'Ô (cell) trong bảng là gì?','Giao của một hàng và một cột','Một trang giấy','Cả bảng','Một dòng văn bản'],
  [2,'Lợi ích của việc trình bày bằng bảng là gì?','Thông tin gọn, rõ, dễ so sánh và tra cứu','Làm thông tin dài hơn','Khó đọc hơn','Không có lợi ích'],
  [2,'Thao tác nào dùng khi cần thêm dữ liệu vào bảng còn thiếu dòng?','Chèn thêm hàng','Xóa cả bảng','Thu nhỏ chữ','Đổi màu nền'],
  [3,'Nêu một ví dụ thông tin nên trình bày ở dạng bảng và lí do.','VD: thời khóa biểu, bảng điểm, danh sách lớp. Vì có nhiều mục (thứ/tiết/môn; họ tên/điểm) cần sắp xếp, so sánh, tra cứu nhanh.'],
  [3,'Nêu các bước cơ bản để tạo một bảng trong phần mềm soạn thảo.','Chọn lệnh chèn bảng (Insert → Table); chọn số hàng, số cột; nhập dữ liệu vào các ô; định dạng (độ rộng cột, đường viền, căn chữ) nếu cần.'],
  [4,'Vì sao cùng một nội dung, trình bày bằng bảng đôi khi hiệu quả hơn viết thành đoạn văn?','Bảng sắp xếp dữ liệu theo hàng, cột có cấu trúc nên dễ so sánh, tra cứu, nhìn tổng thể nhanh; đoạn văn phải đọc hết mới nắm được, khó đối chiếu các mục với nhau.']
 ]);
 add(M,6,'Bài 13: Thực hành: Tìm kiếm và thay thế',[
  [1,'Công cụ Tìm kiếm (Find) trong phần mềm soạn thảo dùng để làm gì?','Tìm nhanh một từ/cụm từ trong văn bản','Xóa cả văn bản','In văn bản','Tắt máy'],
  [1,'Công cụ Thay thế (Replace) dùng để làm gì?','Thay một từ/cụm từ bằng từ/cụm từ khác','Đổi phông chữ','Lưu tệp','Gửi email'],
  [2,'Tổ hợp phím thường dùng để mở hộp thoại Tìm kiếm là gì?','Ctrl + F','Ctrl + S','Ctrl + P','Ctrl + N'],
  [2,'Khi cần sửa một từ bị viết sai ở nhiều chỗ trong văn bản dài, nên dùng công cụ nào?','Thay thế (Replace)','Vẽ hình','Chèn bảng','In ấn'],
  [2,'Chức năng "Thay thế tất cả" (Replace All) có tác dụng gì?','Thay toàn bộ các vị trí tìm thấy cùng lúc','Chỉ thay một vị trí','Xóa văn bản','Đổi màu nền'],
  [3,'Nêu các bước dùng công cụ Thay thế để sửa một từ viết sai trong văn bản.','Mở hộp thoại Thay thế (Ctrl+H); nhập từ cần tìm và từ thay thế; chọn Thay thế từng chỗ hoặc Thay thế tất cả; kiểm tra lại kết quả.'],
  [3,'Nêu lợi ích của công cụ Tìm kiếm và Thay thế khi làm việc với văn bản dài.','Giúp tìm nhanh thông tin, sửa lỗi hàng loạt chính xác, tiết kiệm thời gian, tránh bỏ sót so với sửa thủ công từng chỗ.'],
  [4,'Khi dùng "Thay thế tất cả", vì sao cần cẩn thận kiểm tra trước khi thực hiện?','Vì lệnh thay tất cả có thể thay cả những chỗ không mong muốn (ví dụ thay "an" sẽ ảnh hưởng "bàn", "bạn"...), gây sai sót hàng loạt. Nên kiểm tra kĩ hoặc thay từng chỗ để chính xác.']
 ]);
 add(M,6,'Bài 14: Thực hành tổng hợp: Hoàn thiện Sổ lưu niệm',[
  [1,'Để tạo một cuốn sổ lưu niệm đẹp trên máy tính, em cần kết hợp kĩ năng nào?','Soạn thảo, định dạng văn bản, chèn hình ảnh, bảng','Chỉ tắt máy','Chỉ đọc email','Chỉ chơi game'],
  [1,'Để minh họa sinh động cho sổ lưu niệm, em nên chèn thêm gì?','Hình ảnh','Virus','Mật khẩu','Lỗi chính tả'],
  [2,'Việc định dạng nhất quán (phông, cỡ chữ, màu) trong sổ lưu niệm giúp ích gì?','Trình bày đẹp, chuyên nghiệp, dễ đọc','Làm rối mắt','Tốn dung lượng vô ích','Không có tác dụng'],
  [2,'Trước khi in sản phẩm, em nên làm gì?','Kiểm tra lỗi chính tả, bố cục, xem trước khi in','In ngay không kiểm tra','Xóa hết nội dung','Tắt máy'],
  [2,'Thao tác nào giúp lưu lại sản phẩm để dùng sau?','Lưu tệp (Save)','Xóa tệp','Tắt máy đột ngột','Rút điện'],
  [3,'Nêu các bước cơ bản để hoàn thiện một sản phẩm văn bản có hình ảnh (như sổ lưu niệm).','Gõ nội dung; định dạng văn bản (tiêu đề, đoạn); chèn và căn chỉnh hình ảnh, bảng; kiểm tra bố cục, chính tả; lưu và xem trước khi in.'],
  [3,'Vì sao cần lưu tệp thường xuyên khi làm bài trên máy tính?','Để tránh mất dữ liệu khi máy bị tắt đột ngột, mất điện hoặc lỗi phần mềm; lưu thường xuyên giúp giữ lại công sức đã làm.'],
  [4,'Vì sao một sản phẩm tin học tốt không chỉ cần nội dung đúng mà còn cần trình bày đẹp, hợp lí?','Vì trình bày đẹp, rõ ràng giúp người xem dễ tiếp nhận, tạo thiện cảm và thể hiện sự chuyên nghiệp; nội dung đúng mà trình bày rối, cẩu thả sẽ khó đọc và giảm hiệu quả truyền đạt.']
 ]);
 add(M,6,'Bài 15: Thuật toán',[
  [1,'Thuật toán là gì?','Dãy các bước (thao tác) được sắp xếp theo thứ tự để giải quyết một công việc','Một phần cứng','Một loại virus','Một trang web'],
  [1,'Đặc điểm nào đúng về thuật toán?','Các bước rõ ràng, thực hiện theo thứ tự, cho kết quả','Các bước lộn xộn, không rõ','Không bao giờ kết thúc','Không có kết quả'],
  [2,'"Các bước pha một cốc nước chanh" có thể coi là gì?','Một thuật toán','Một phần mềm','Một thiết bị','Một tệp'],
  [2,'Thuật toán thường được mô tả bằng cách nào?','Liệt kê các bước hoặc dùng sơ đồ khối','Chỉ bằng hình vẽ phong cảnh','Bằng mật khẩu','Bằng âm thanh'],
  [2,'Đầu vào (input) của thuật toán là gì?','Dữ liệu đưa vào để xử lí','Kết quả cuối cùng','Tên thuật toán','Máy tính'],
  [3,'Nêu các bước (thuật toán) để tính tổng hai số a và b.','Bước 1: Nhập a, b. Bước 2: Tính tổng = a + b. Bước 3: Thông báo (xuất) kết quả tổng. Kết thúc.'],
  [3,'Phân biệt đầu vào và đầu ra của thuật toán, cho ví dụ.','Đầu vào là dữ liệu đưa vào; đầu ra là kết quả nhận được. VD thuật toán tính diện tích hình chữ nhật: đầu vào là chiều dài, chiều rộng; đầu ra là diện tích.'],
  [4,'Vì sao một thuật toán cần có các bước rõ ràng và kết thúc sau hữu hạn bước?','Để máy tính (hoặc người) thực hiện được chính xác, không nhầm lẫn và chắc chắn cho ra kết quả. Nếu bước mơ hồ hoặc không bao giờ kết thúc thì không giải quyết được công việc.']
 ]);
 add(M,6,'Bài 16: Cấu trúc điều khiển',[
  [1,'Trong thuật toán có mấy cấu trúc điều khiển cơ bản?','Ba: tuần tự, rẽ nhánh, lặp','Một','Hai','Năm'],
  [1,'Cấu trúc tuần tự là gì?','Các bước thực hiện lần lượt theo thứ tự','Thực hiện ngược','Bỏ qua các bước','Lặp vô hạn'],
  [2,'Cấu trúc rẽ nhánh (điều kiện) dùng khi nào?','Khi cần chọn thực hiện theo điều kiện đúng/sai','Khi làm đi làm lại','Khi chỉ có một việc','Khi không cần quyết định'],
  [2,'Cấu trúc lặp dùng để làm gì?','Thực hiện lặp lại một hoặc một số bước','Chỉ làm một lần','Bỏ qua các bước','Dừng thuật toán'],
  [2,'Câu "Nếu trời mưa thì mang ô, nếu không thì đội mũ" thể hiện cấu trúc nào?','Rẽ nhánh','Tuần tự','Lặp','Không có cấu trúc'],
  [3,'Nêu ví dụ về cấu trúc lặp trong đời sống.','VD: mỗi ngày đánh răng 2 lần; chép lại một câu 5 lần; tưới cây mỗi sáng cho đến khi hết tuần — các việc lặp lại nhiều lần.'],
  [3,'Mô tả thuật toán có rẽ nhánh: kiểm tra một số a có phải số dương không.','Nhập a. Nếu a > 0 thì thông báo "a là số dương"; ngược lại thông báo "a không phải số dương". Kết thúc.'],
  [4,'Vì sao ba cấu trúc tuần tự, rẽ nhánh và lặp đủ để mô tả mọi thuật toán?','Mọi công việc đều có thể chia thành: làm lần lượt (tuần tự), chọn lựa theo điều kiện (rẽ nhánh) và làm lặp lại (lặp). Kết hợp ba cấu trúc này một cách linh hoạt có thể diễn đạt được logic của mọi thuật toán.']
 ]);
 add(M,6,'Bài 17: Chương trình máy tính',[
  [1,'Chương trình máy tính là gì?','Thuật toán được viết bằng ngôn ngữ lập trình để máy tính thực hiện','Một thiết bị','Một tờ giấy','Một loại virus'],
  [1,'Để máy tính hiểu và thực hiện, thuật toán cần được viết bằng gì?','Ngôn ngữ lập trình','Tiếng Việt thường','Hình vẽ','Âm thanh'],
  [2,'Môi trường lập trình trực quan kéo thả khối lệnh mà học sinh thường dùng là gì?','Scratch','Microsoft Word','Excel','Paint'],
  [2,'Trong Scratch, nhân vật thực hiện hành động theo cái gì?','Các khối lệnh được ghép lại','Màu nền','Âm thanh nền','Tên nhân vật'],
  [2,'Việc chạy thử chương trình nhằm mục đích gì?','Kiểm tra chương trình chạy đúng không, phát hiện lỗi','Xóa chương trình','Tắt máy','Đổi tên tệp'],
  [3,'Nêu mối quan hệ giữa thuật toán và chương trình máy tính.','Thuật toán là cách giải quyết công việc (các bước); chương trình là thuật toán được viết bằng ngôn ngữ lập trình để máy tính thực hiện. Có thuật toán đúng rồi mới viết thành chương trình.'],
  [3,'Nêu các bước cơ bản để tạo một chương trình giải quyết công việc.','Xác định công việc (đầu vào, đầu ra); xây dựng thuật toán; viết chương trình bằng ngôn ngữ lập trình (VD Scratch); chạy thử, sửa lỗi; hoàn thiện.'],
  [4,'Vì sao cần xây dựng thuật toán đúng trước khi viết chương trình?','Vì chương trình chỉ là cách diễn đạt thuật toán cho máy hiểu; nếu thuật toán sai thì chương trình dù viết đúng cú pháp vẫn cho kết quả sai. Thuật toán đúng là nền tảng để có chương trình đúng.']
 ]);

 /* -------- LỚP 6: chủ đề tổng hợp -------- */
 add(M,6,'Thông tin và dữ liệu, máy tính',[
  [1,'Máy tính xử lí thông tin ở dạng nào?','Dãy bit 0 và 1','Chữ cái','Hình vẽ','Âm thanh'],
  [2,'1 byte bằng bao nhiêu bit?','8 bit','4 bit','2 bit','16 bit'],
  [2,'Hoạt động cơ bản của xử lí thông tin gồm những gì?','Thu nhận, lưu trữ, xử lí, truyền','Chỉ in ấn','Chỉ xóa','Chỉ tắt máy'],
  [3,'Nêu ba dạng thông tin cơ bản và các đơn vị đo dữ liệu từ nhỏ đến lớn.','Ba dạng: văn bản, hình ảnh, âm thanh. Đơn vị: B < KB < MB < GB (< TB).'],
  [4,'Vì sao máy tính dùng hệ nhị phân để biểu diễn và xử lí thông tin?','Vì mạch điện tử dễ biểu diễn hai trạng thái (bật/tắt) tương ứng 1 và 0, cho độ tin cậy và chính xác cao, dễ chế tạo.']
 ]);
 add(M,6,'Mạng máy tính và Internet',[
  [1,'Mạng cục bộ (phạm vi hẹp) được viết tắt là gì?','LAN','WAN toàn cầu','WWW','CPU'],
  [2,'Phần mềm dùng để xem trang web gọi là gì?','Trình duyệt web','Hệ điều hành','Bảng tính','Trình chiếu'],
  [2,'Công cụ tìm kiếm thông tin trên Internet là gì?','Máy tìm kiếm (VD Google)','Máy in','Loa','Webcam'],
  [3,'Phân biệt Internet và World Wide Web.','Internet là mạng kết nối toàn cầu (hạ tầng); WWW là dịch vụ các trang web chạy trên Internet. WWW là một phần của Internet.'],
  [4,'Vì sao mạng máy tính và Internet làm thay đổi cách con người học tập, làm việc?','Giúp chia sẻ, truy cập kho thông tin khổng lồ mọi lúc mọi nơi; liên lạc, cộng tác nhanh; học trực tuyến, làm việc từ xa — thay đổi lớn cách tiếp cận tri thức và tổ chức công việc.']
 ]);
 add(M,6,'An toàn thông tin, soạn thảo',[
  [1,'Để chữ in đậm, dùng tổ hợp phím nào?','Ctrl + B','Ctrl + S','Ctrl + P','Ctrl + F'],
  [2,'Việc làm nào gây mất an toàn thông tin?','Nhấp liên kết lạ, dùng mật khẩu dễ đoán','Đặt mật khẩu mạnh','Cài phần mềm diệt virus','Sao lưu dữ liệu'],
  [2,'Công cụ Thay thế (Replace) dùng để làm gì?','Thay một từ/cụm từ bằng từ khác trong văn bản','Tắt máy','Gửi email','Vẽ hình'],
  [3,'Nêu một số biện pháp giữ an toàn thông tin cá nhân khi dùng Internet.','Mật khẩu mạnh, không chia sẻ; không mở liên kết/tệp lạ; cài diệt virus; không cung cấp thông tin cá nhân bừa bãi; sao lưu dữ liệu.'],
  [4,'Vì sao định dạng văn bản hợp lí giúp truyền đạt thông tin hiệu quả hơn?','Định dạng rõ ràng, nhất quán làm nổi bật ý chính, dễ đọc, tạo thẩm mĩ; người đọc nắm thông tin nhanh và thiện cảm hơn so với văn bản trình bày rối.']
 ]);
 add(M,6,'Sơ đồ tư duy, trình bày thông tin',[
  [1,'Ở trung tâm sơ đồ tư duy thường là gì?','Chủ đề chính','Một con số','Dấu câu','Mật khẩu'],
  [2,'Khi nào nên trình bày thông tin ở dạng bảng?','Khi có nhiều mục cần so sánh, sắp xếp theo hàng, cột','Khi viết đoạn văn cảm xúc','Khi vẽ tranh','Khi nghe nhạc'],
  [2,'Lợi ích của sơ đồ tư duy là gì?','Giúp hệ thống hóa, ghi nhớ, nắm ý chính nhanh','Làm rối thông tin','Tốn giấy vô ích','Không có lợi ích'],
  [3,'Nêu các bước tạo một sơ đồ tư duy để tóm tắt bài học.','Viết chủ đề chính ở trung tâm; vẽ nhánh chính là các ý lớn; vẽ nhánh phụ chi tiết; dùng từ khóa, hình ảnh, màu sắc.'],
  [4,'Vì sao sơ đồ tư duy và bảng giúp trình bày thông tin hiệu quả?','Cả hai sắp xếp thông tin có cấu trúc, trực quan: sơ đồ tư duy thể hiện mối liên hệ và ý chính bằng từ khóa; bảng giúp so sánh, tra cứu nhanh. Nhờ đó dễ hiểu, dễ nhớ hơn văn bản dài.']
 ]);

 /* -------- LỚP 6: bù lẻ cho đủ chuẩn -------- */
 add(M,6,'Thông tin và dữ liệu, máy tính',[
  [3,'Nêu các thiết bị vào và thiết bị ra của máy tính.','Thiết bị vào: bàn phím, chuột, micro, máy quét. Thiết bị ra: màn hình, loa, máy in, máy chiếu.']
 ]);
 add(M,6,'Mạng máy tính và Internet',[
  [3,'Nêu một số dịch vụ phổ biến trên Internet.','World Wide Web, thư điện tử, tìm kiếm thông tin, mạng xã hội, lưu trữ đám mây, hội họp trực tuyến.']
 ]);
 add(M,6,'An toàn thông tin, soạn thảo',[
  [1,'Khi gặp email có liên kết lạ, em nên làm gì?','Không nhấp vào, xóa hoặc báo người lớn','Nhấp ngay để xem','Chuyển cho bạn bè','Trả lời kèm thông tin cá nhân'],
  [3,'Nêu các bước định dạng một đoạn tiêu đề cho nổi bật (cỡ chữ lớn, in đậm, căn giữa).','Bôi đen tiêu đề; tăng cỡ chữ; nhấn in đậm (Ctrl+B); chọn căn giữa; kiểm tra kết quả.']
 ]);
 add(M,6,'Sơ đồ tư duy, trình bày thông tin',[
  [1,'Bảng gồm những thành phần nào?','Hàng và cột tạo thành các ô','Chỉ có hàng','Chỉ có một ô','Chỉ có cột'],
  [3,'Nêu một ví dụ thông tin nên trình bày ở dạng bảng và lí do.','VD: thời khóa biểu, bảng điểm — có nhiều mục cần sắp xếp, so sánh, tra cứu nhanh theo hàng, cột.']
 ]);
 add(M,6,'Bài 1: Thông tin và dữ liệu',[
  [1,'Đâu là ví dụ về dữ liệu?','Con số 25, một bức ảnh, một đoạn ghi âm','Sự hiểu biết trong đầu','Cảm xúc vui buồn','Suy nghĩ']
 ]);
 add(M,6,'Bài 3: Thông tin trong máy tính',[
  [3,'1 MB bằng khoảng bao nhiêu KB? 1 GB bằng khoảng bao nhiêu MB?','1 MB ≈ 1024 KB; 1 GB ≈ 1024 MB.']
 ]);
 add(M,6,'Bài 4: Mạng máy tính',[
  [1,'Mạng máy tính giúp các máy tính làm gì?','Trao đổi dữ liệu và dùng chung thiết bị','Chạy chậm lại','Hỏng nhanh hơn','Không làm gì']
 ]);
 add(M,6,'Bài 6: Mạng thông tin toàn cầu',[
  [3,'Nêu các bước truy cập một trang web khi đã biết địa chỉ.','Mở trình duyệt; gõ địa chỉ (URL) vào thanh địa chỉ; nhấn Enter; trang web hiển thị; dùng siêu liên kết để chuyển trang khác.']
 ]);
 add(M,6,'Bài 17: Chương trình máy tính',[
  [3,'Vì sao cần chạy thử và sửa lỗi chương trình?','Để phát hiện và sửa các lỗi khiến chương trình chạy sai hoặc không chạy, bảo đảm chương trình cho kết quả đúng như mong muốn.']
 ]);

 /* ===================== LỚP 7 ===================== */
 add(M,7,'Bài 1: Thiết bị vào - ra',[
  [1,'Thiết bị vào dùng để làm gì?','Nhập dữ liệu vào máy tính','Hiển thị kết quả','Lưu trữ','In ấn'],
  [1,'Thiết bị nào là thiết bị ra?','Màn hình','Bàn phím','Chuột','Máy quét'],
  [2,'Thiết bị nào vừa là thiết bị vào vừa là thiết bị ra?','Màn hình cảm ứng','Bàn phím','Loa','Máy in'],
  [2,'Webcam thuộc nhóm thiết bị nào?','Thiết bị vào','Thiết bị ra','Bộ nhớ','Bộ xử lí'],
  [2,'Máy in thuộc nhóm thiết bị nào?','Thiết bị ra','Thiết bị vào','Bộ xử lí','Bộ nhớ trong'],
  [3,'Kể tên 3 thiết bị vào và 3 thiết bị ra của máy tính.','Thiết bị vào: bàn phím, chuột, micro, máy quét, webcam. Thiết bị ra: màn hình, loa, máy in, máy chiếu.'],
  [3,'Nêu một thiết bị vừa vào vừa ra và giải thích.','Màn hình cảm ứng: vừa hiển thị (ra) vừa nhận thao tác chạm của người dùng (vào). Tai nghe có micro cũng vừa ra (nghe) vừa vào (nói).'],
  [4,'Vì sao thiết bị vào - ra được coi là cầu nối giữa con người và máy tính?','Thiết bị vào giúp con người đưa thông tin/lệnh vào máy; thiết bị ra giúp máy đưa kết quả cho con người. Nhờ chúng, con người và máy tính mới trao đổi, làm việc được với nhau.']
 ]);
 add(M,7,'Bài 2: Phần mềm máy tính',[
  [1,'Phần mềm máy tính là gì?','Các chương trình điều khiển máy tính hoạt động và xử lí công việc','Các bộ phận cứng','Dây cáp','Màn hình'],
  [1,'Phần mềm được chia thành mấy loại chính?','Hai: phần mềm hệ thống và phần mềm ứng dụng','Một','Ba','Bốn'],
  [2,'Hệ điều hành (Windows) thuộc loại phần mềm nào?','Phần mềm hệ thống','Phần mềm ứng dụng','Phần cứng','Thiết bị vào'],
  [2,'Phần mềm nào dưới đây là phần mềm ứng dụng?','Microsoft Word','Windows','Android (hệ điều hành)','BIOS'],
  [2,'Phần mềm hệ thống có vai trò gì?','Quản lí, điều khiển hoạt động của máy tính và các phần mềm khác','Chỉ để soạn văn bản','Chỉ để vẽ','Chỉ để chơi game'],
  [3,'Phân biệt phần mềm hệ thống và phần mềm ứng dụng, cho ví dụ.','Phần mềm hệ thống quản lí, điều khiển máy tính (VD hệ điều hành Windows, Android). Phần mềm ứng dụng giúp người dùng làm công việc cụ thể (VD Word, Excel, trình duyệt).'],
  [3,'Vì sao máy tính cần có hệ điều hành?','Hệ điều hành quản lí phần cứng, bộ nhớ, tệp; làm nền để chạy các phần mềm ứng dụng; tạo giao diện cho người dùng điều khiển máy. Không có hệ điều hành, máy tính không hoạt động được.'],
  [4,'Vì sao phần cứng và phần mềm phải phối hợp với nhau thì máy tính mới hoạt động?','Phần cứng là các thiết bị vật lí, phần mềm là chương trình điều khiển. Phần cứng không có phần mềm thì không biết làm gì; phần mềm không có phần cứng thì không có nơi chạy. Hai phần phối hợp mới tạo nên hoạt động của máy tính.']
 ]);
 add(M,7,'Bài 3: Quản lí dữ liệu trong máy tính',[
  [1,'Dữ liệu trong máy tính được lưu dưới dạng gì?','Các tệp (file)','Chỉ trong đầu người dùng','Trên giấy','Trong không khí'],
  [1,'Thư mục (folder) dùng để làm gì?','Tổ chức, sắp xếp, chứa các tệp và thư mục con','Xóa tệp','Tắt máy','In tệp'],
  [2,'Phần mở rộng của tên tệp (.docx, .jpg...) cho biết điều gì?','Loại tệp / phần mềm mở được tệp','Dung lượng ổ cứng','Tên người tạo','Ngày hết hạn'],
  [2,'Thao tác nào giúp tìm lại tệp nhanh khi có nhiều tệp?','Dùng chức năng Tìm kiếm / sắp xếp theo tên, ngày','Xóa bớt ổ đĩa','Tắt máy','Đổi màn hình'],
  [2,'Cách tổ chức dữ liệu khoa học là gì?','Tạo thư mục rõ ràng, đặt tên tệp dễ hiểu, phân loại hợp lí','Để lộn xộn ngoài màn hình','Đặt tên ngẫu nhiên','Gộp tất cả vào một tệp'],
  [3,'Nêu lợi ích của việc tổ chức dữ liệu thành thư mục hợp lí.','Dễ tìm, dễ quản lí, tránh nhầm lẫn, không bị mất tệp, tiết kiệm thời gian khi làm việc với nhiều tệp.'],
  [3,'Nêu các thao tác cơ bản với tệp và thư mục.','Tạo mới, đổi tên, sao chép, di chuyển, xóa, tìm kiếm, mở tệp/thư mục.'],
  [4,'Vì sao nên đặt tên tệp và sắp xếp thư mục một cách khoa học ngay từ đầu?','Khi dữ liệu nhiều lên, tổ chức khoa học giúp tìm và quản lí nhanh, tránh trùng lặp, nhầm lẫn, mất tệp. Để lộn xộn sẽ rất khó tìm và dễ mất dữ liệu quan trọng về sau.']
 ]);
 add(M,7,'Bài 4: Mạng xã hội và một số kênh trao đổi thông tin trên internet',[
  [1,'Mạng xã hội là gì?','Dịch vụ trên Internet giúp mọi người kết nối, chia sẻ, trao đổi thông tin','Một loại máy tính','Một thiết bị mạng','Một phần mềm diệt virus'],
  [1,'Đâu là một kênh trao đổi thông tin trên Internet?','Thư điện tử, mạng xã hội, diễn đàn','Quyển sổ tay giấy','Bảng đen','Loa phát thanh xã'],
  [2,'Lợi ích của mạng xã hội là gì?','Kết nối bạn bè, chia sẻ, học tập, cập nhật thông tin','Chỉ gây hại','Làm hỏng máy','Không có lợi ích'],
  [2,'Tác hại có thể gặp khi dùng mạng xã hội là gì?','Nghiện, thông tin xấu/giả, lộ thông tin cá nhân, bị lừa đảo','Giúp học giỏi hơn chắc chắn','Bảo vệ máy tính','Tăng dung lượng ổ cứng'],
  [2,'Khi dùng mạng xã hội, thông tin nào KHÔNG nên chia sẻ công khai?','Địa chỉ nhà, số điện thoại, mật khẩu','Lời chúc mừng bạn','Bài viết học tập','Ảnh phong cảnh'],
  [3,'Nêu một số lợi ích và tác hại của mạng xã hội đối với học sinh.','Lợi ích: kết nối, học nhóm, cập nhật thông tin, giải trí. Tác hại: nghiện, giảm thời gian học, gặp thông tin xấu, bị lừa đảo, lộ thông tin cá nhân.'],
  [3,'Nêu các kênh trao đổi thông tin phổ biến trên Internet.','Thư điện tử, mạng xã hội, ứng dụng nhắn tin, diễn đàn, hội họp trực tuyến.'],
  [4,'Vì sao cần cân nhắc kĩ trước khi chia sẻ thông tin lên mạng xã hội?','Thông tin đưa lên mạng khó thu hồi, lan nhanh; chia sẻ thông tin cá nhân hoặc nội dung chưa kiểm chứng có thể gây hại cho mình và người khác, bị lợi dụng, lừa đảo hoặc ảnh hưởng xấu đến người khác.']
 ]);
 add(M,7,'Bài 5: Ứng xử trên mạng',[
  [1,'Ứng xử văn hóa trên mạng là gì?','Giao tiếp lịch sự, tôn trọng người khác, tuân thủ pháp luật','Nói xấu, công kích người khác','Bịa đặt thông tin','Phát tán nội dung xấu'],
  [1,'Hành vi nào là KHÔNG nên khi dùng mạng?','Bình luận xúc phạm, tung tin giả','Chia sẻ bài học bổ ích','Cảm ơn, động viên bạn','Góp ý lịch sự'],
  [2,'Khi bị bắt nạt trên mạng (cyberbullying), em nên làm gì?','Không trả đũa, lưu bằng chứng, chặn và báo người lớn','Trả đũa gay gắt','Im lặng chịu đựng','Chia sẻ rộng cho mọi người'],
  [2,'Trước khi chia sẻ một thông tin, em nên làm gì?','Kiểm tra nguồn, độ tin cậy của thông tin','Chia sẻ ngay cho nhanh','Thêm thắt cho hấp dẫn','Giật tít câu view'],
  [2,'Bản quyền trên mạng nghĩa là gì?','Tôn trọng quyền tác giả, không sao chép, dùng trái phép sản phẩm của người khác','Tự do lấy mọi thứ','Chỉ cần ghi tên mình','Không cần quan tâm'],
  [3,'Nêu một số quy tắc ứng xử văn hóa khi tham gia mạng.','Lịch sự, tôn trọng người khác; không nói xấu, bịa đặt; kiểm chứng trước khi chia sẻ; tôn trọng bản quyền; bảo vệ thông tin cá nhân; tuân thủ pháp luật.'],
  [3,'Em sẽ làm gì khi thấy một bạn bị nói xấu, bôi nhọ trên mạng?','Không hùa theo, không chia sẻ; động viên bạn; khuyên các bạn dừng lại; báo thầy cô, người lớn để xử lí và bảo vệ bạn.'],
  [4,'Vì sao "ứng xử trên mạng" cũng cần văn hóa như ứng xử ngoài đời thực?','Vì sau mỗi tài khoản là một con người thật; lời nói, hành vi trên mạng có thể làm tổn thương người khác, lan rộng, để lại hậu quả lâu dài và có thể vi phạm pháp luật. Ứng xử văn hóa trên mạng thể hiện sự tôn trọng người khác và chính mình.']
 ]);
 add(M,7,'Bài 6: Làm quen với phần mềm bảng tính',[
  [1,'Phần mềm bảng tính dùng để làm gì?','Nhập, tính toán, xử lí và trình bày dữ liệu dạng bảng','Vẽ tranh','Nghe nhạc','Diệt virus'],
  [1,'Đâu là một phần mềm bảng tính?','Microsoft Excel','Microsoft Word','Paint','Windows'],
  [2,'Trang tính (worksheet) gồm các thành phần nào?','Các hàng, cột và ô','Chỉ có hàng','Chỉ có một ô','Chỉ có cột'],
  [2,'Địa chỉ ô trong bảng tính được xác định bởi gì?','Tên cột và số hàng (VD A1, B3)','Chỉ số hàng','Chỉ tên cột','Màu của ô'],
  [2,'Ô A1 nằm ở vị trí nào?','Giao của cột A và hàng 1','Cột 1 hàng A','Giữa bảng','Ô bất kì'],
  [3,'Nêu lợi ích của phần mềm bảng tính so với tính toán thủ công.','Tính toán tự động, nhanh, chính xác; dễ sửa và cập nhật dữ liệu; sắp xếp, lọc, vẽ biểu đồ; trình bày đẹp, chuyên nghiệp.'],
  [3,'Nêu các thành phần cơ bản của một trang tính.','Các cột (đặt tên A, B, C...), các hàng (đánh số 1, 2, 3...), các ô (giao của hàng và cột, có địa chỉ như A1), vùng nhập liệu và thanh công thức.'],
  [4,'Vì sao bảng tính đặc biệt hữu ích khi quản lí bảng điểm hoặc danh sách lớp?','Vì dữ liệu có nhiều dòng, cột; bảng tính giúp nhập nhanh, tự động tính tổng/trung bình, sắp xếp, lọc, cập nhật dễ dàng và vẽ biểu đồ thống kê — hiệu quả hơn nhiều so với tính tay.']
 ]);
 add(M,7,'Bài 7: Tính toán tự động trên bảng tính',[
  [1,'Trong bảng tính, công thức thường bắt đầu bằng dấu gì?','Dấu bằng (=)','Dấu cộng (+)','Dấu chấm (.)','Dấu hỏi (?)'],
  [1,'Kết quả của công thức "=5+3" trong một ô là bao nhiêu?','8','53','5+3','Lỗi'],
  [2,'Công thức "=A1+B1" có nghĩa là gì?','Cộng giá trị trong ô A1 và ô B1','Cộng chữ A1 và B1','Nhân A1 với B1','Không hợp lệ'],
  [2,'Ưu điểm của việc dùng địa chỉ ô trong công thức là gì?','Khi dữ liệu trong ô thay đổi, kết quả tự động cập nhật','Phải tính lại bằng tay','Luôn cho kết quả sai','Không dùng được'],
  [2,'Để tính hiệu của ô A1 và A2, em nhập công thức nào?','=A1-A2','A1-A2','=A1 A2','-A1A2'],
  [3,'Nêu lợi ích của tính toán tự động bằng công thức trong bảng tính.','Tính nhanh, chính xác; khi sửa dữ liệu, kết quả tự cập nhật; áp dụng cho nhiều ô; tránh sai sót so với tính tay.'],
  [3,'Viết công thức tính tổng điểm của ba môn ở các ô B2, C2, D2.','=B2+C2+D2 (hoặc =SUM(B2:D2)).'],
  [4,'Vì sao nên dùng địa chỉ ô (như A1, B2) trong công thức thay vì nhập trực tiếp con số?','Vì khi dữ liệu trong ô thay đổi, công thức tự tính lại kết quả mới mà không phải sửa công thức; giúp cập nhật nhanh, chính xác và tái sử dụng công thức cho nhiều trường hợp.']
 ]);
 add(M,7,'Bài 8: Công cụ hỗ trợ tính toán',[
  [1,'Hàm trong bảng tính là gì?','Công thức dựng sẵn giúp tính toán nhanh (SUM, AVERAGE...)','Một loại virus','Một thiết bị','Một tệp ảnh'],
  [1,'Hàm SUM dùng để làm gì?','Tính tổng các giá trị','Tính trung bình','Tìm số lớn nhất','Đếm ô'],
  [2,'Hàm AVERAGE dùng để làm gì?','Tính trung bình cộng','Tính tổng','Tìm giá trị nhỏ nhất','Đếm số ô trống'],
  [2,'Hàm nào tìm giá trị lớn nhất trong một vùng?','MAX','MIN','SUM','COUNT'],
  [2,'Công thức "=AVERAGE(B2:B10)" tính gì?','Trung bình các giá trị từ B2 đến B10','Tổng B2 và B10','Hiệu B2 trừ B10','Số ô từ B2 đến B10'],
  [3,'Nêu công dụng của các hàm SUM, AVERAGE, MAX, MIN.','SUM: tính tổng; AVERAGE: tính trung bình; MAX: tìm giá trị lớn nhất; MIN: tìm giá trị nhỏ nhất của một vùng dữ liệu.'],
  [3,'Viết công thức tính điểm trung bình của các ô từ C2 đến C5.','=AVERAGE(C2:C5).'],
  [4,'Vì sao dùng hàm (như SUM, AVERAGE) tiện lợi hơn viết phép tính dài khi dữ liệu nhiều?','Hàm áp dụng cho cả vùng dữ liệu lớn chỉ bằng một công thức ngắn, dễ viết, ít sai sót; khi thêm/bớt dữ liệu chỉ cần sửa vùng, kết quả tự cập nhật; nhanh và chính xác hơn viết cộng từng ô.']
 ]);
 add(M,7,'Bài 9: Trình bày bảng tính',[
  [1,'Trình bày (định dạng) bảng tính nhằm mục đích gì?','Làm bảng rõ ràng, dễ đọc, đẹp và dễ hiểu','Làm chậm máy','Xóa dữ liệu','Tắt máy'],
  [1,'Thao tác nào là định dạng dữ liệu trong ô?','Đổi phông, cỡ chữ, màu, căn chỉnh','Tắt máy','Gửi email','Cài phần mềm'],
  [2,'Để dữ liệu số thẳng hàng dễ đọc, nên căn như thế nào?','Căn phải','Căn trái','Căn giữa nhiều dòng','Không căn'],
  [2,'Kẻ đường viền (border) cho bảng có tác dụng gì?','Phân tách rõ các ô, bảng gọn gàng','Xóa dữ liệu','Làm hỏng bảng','Đổi công thức'],
  [2,'Khi tiêu đề cột quá dài so với ô, nên làm gì?','Mở rộng độ rộng cột hoặc xuống dòng trong ô','Xóa tiêu đề','Thu nhỏ hết cỡ','Để tràn che ô khác'],
  [3,'Nêu các thao tác định dạng thường dùng để bảng tính dễ đọc.','Chỉnh độ rộng cột/hàng; định dạng chữ (đậm cho tiêu đề), căn chỉnh (số căn phải, chữ căn trái); kẻ viền; tô màu nền; định dạng kiểu số (ngày, %, tiền).'],
  [3,'Vì sao cần định dạng kiểu dữ liệu đúng (ngày tháng, phần trăm, tiền tệ) cho các ô?','Để dữ liệu hiển thị đúng ý nghĩa, dễ đọc và tính toán chính xác; VD định dạng ngày giúp sắp xếp theo thời gian, định dạng % hiển thị đúng tỉ lệ.'],
  [4,'Vì sao một bảng tính trình bày tốt lại giúp người xem ra quyết định nhanh hơn?','Bảng rõ ràng, tiêu đề nổi bật, số liệu căn chỉnh, có màu/viền phân nhóm giúp người xem nắm bắt, so sánh dữ liệu nhanh và chính xác, từ đó phân tích và quyết định hiệu quả hơn.']
 ]);
 add(M,7,'Bài 10: Hoàn thiện bảng tính',[
  [1,'Sắp xếp dữ liệu (Sort) trong bảng tính giúp gì?','Xếp dữ liệu theo thứ tự tăng/giảm để dễ xem','Xóa dữ liệu','Tắt máy','Đổi phông chữ'],
  [1,'Lọc dữ liệu (Filter) dùng để làm gì?','Chỉ hiển thị các dòng thỏa điều kiện mong muốn','Xóa toàn bộ','In tất cả','Tính tổng'],
  [2,'Biểu đồ trong bảng tính dùng để làm gì?','Biểu diễn dữ liệu trực quan để dễ so sánh, nhận xét','Làm rối dữ liệu','Xóa dữ liệu','Tắt máy'],
  [2,'Muốn xem học sinh có điểm cao nhất, nên dùng công cụ nào?','Sắp xếp giảm dần theo cột điểm (hoặc hàm MAX)','Xóa bảng','Đổi màu nền','In ra giấy'],
  [2,'Loại biểu đồ nào thường dùng để so sánh số liệu giữa các nhóm?','Biểu đồ cột','Không có loại nào','Chỉ dùng chữ','Chỉ dùng màu'],
  [3,'Nêu các bước cơ bản để tạo một biểu đồ từ dữ liệu bảng tính.','Chọn vùng dữ liệu cần vẽ; chọn lệnh Chèn biểu đồ (Insert → Chart); chọn loại biểu đồ phù hợp; thêm tiêu đề, chú thích; chỉnh sửa cho rõ ràng.'],
  [3,'Nêu lợi ích của việc sắp xếp và lọc dữ liệu.','Sắp xếp giúp xem dữ liệu theo thứ tự (điểm cao→thấp...); lọc giúp chỉ hiện dữ liệu cần quan tâm (VD HS giỏi), nhờ đó phân tích, tra cứu nhanh và chính xác.'],
  [4,'Vì sao biểu đồ giúp "nói" nhiều hơn một bảng số liệu dày đặc?','Biểu đồ biểu diễn số liệu bằng hình ảnh (cột, đường, quạt), giúp nhìn thấy ngay xu hướng, so sánh, tỉ lệ mà không phải đọc từng con số; truyền đạt thông tin nhanh và ấn tượng hơn bảng số.']
 ]);
 add(M,7,'Bài 11: Tạo bài trình chiếu',[
  [1,'Phần mềm trình chiếu dùng để làm gì?','Tạo bài thuyết trình gồm nhiều trang chiếu (slide)','Tính toán','Diệt virus','Lưu trữ mạng'],
  [1,'Đâu là một phần mềm trình chiếu?','Microsoft PowerPoint','Microsoft Excel','Paint','Windows'],
  [2,'Mỗi trang trong bài trình chiếu gọi là gì?','Trang chiếu (slide)','Ô','Hàng','Thư mục'],
  [2,'Nội dung trên trang chiếu nên như thế nào?','Ngắn gọn, nổi bật ý chính, kèm hình ảnh minh họa','Chép nguyên cả bài dài','Toàn chữ nhỏ','Không có tiêu đề'],
  [2,'Thao tác nào giúp thêm một trang mới vào bài trình chiếu?','Chèn trang chiếu mới (New Slide)','Xóa bài','Tắt máy','Đổi phông'],
  [3,'Nêu các bước cơ bản để tạo một bài trình chiếu.','Mở phần mềm trình chiếu; tạo các trang chiếu; nhập tiêu đề và nội dung ngắn gọn; chèn hình ảnh, biểu đồ; định dạng; trình chiếu thử và chỉnh sửa.'],
  [3,'Nêu một số lưu ý để bài trình chiếu dễ theo dõi.','Mỗi slide một ý chính; chữ to, ít chữ; dùng từ khóa; hình ảnh minh họa; màu nền và chữ tương phản; bố cục nhất quán.'],
  [4,'Vì sao không nên đưa quá nhiều chữ vào một trang chiếu?','Vì slide nhiều chữ khiến người xem khó đọc, mất tập trung vào lời thuyết trình; slide chỉ nên nêu ý chính bằng từ khóa, hình ảnh để hỗ trợ, còn nội dung chi tiết do người trình bày nói.']
 ]);
 add(M,7,'Bài 12: Định dạng đối tượng trên trang chiếu',[
  [1,'Đối tượng trên trang chiếu có thể là gì?','Văn bản, hình ảnh, hình khối, biểu đồ','Chỉ có văn bản','Chỉ có con số','Chỉ có âm thanh'],
  [1,'Định dạng đối tượng nhằm mục đích gì?','Làm trang chiếu đẹp, rõ ràng, sinh động','Làm chậm máy','Xóa nội dung','Tắt máy'],
  [2,'Hiệu ứng động (animation) trên trang chiếu dùng để làm gì?','Làm đối tượng xuất hiện/chuyển động sinh động, thu hút','Xóa đối tượng','Tính toán','Diệt virus'],
  [2,'Nên dùng hiệu ứng động như thế nào cho hợp lí?','Vừa phải, phù hợp nội dung, không lạm dụng','Càng nhiều càng tốt','Dùng mọi hiệu ứng cho một slide','Không bao giờ dùng'],
  [2,'Để hình ảnh không che chữ, em nên làm gì?','Sắp xếp, thay đổi kích thước và vị trí hợp lí','Để chồng lên nhau','Phóng to hết cỡ','Xóa chữ'],
  [3,'Nêu một số thao tác định dạng đối tượng trên trang chiếu.','Thay đổi kích thước, vị trí; đổi màu, đường viền; thêm hiệu ứng xuất hiện/chuyển trang; căn chỉnh, nhóm các đối tượng.'],
  [3,'Vì sao cần dùng màu nền và màu chữ tương phản trên trang chiếu?','Để chữ nổi bật, dễ đọc từ xa; nền và chữ cùng tông sẽ khó nhìn, người xem mỏi mắt và khó tiếp nhận nội dung.'],
  [4,'Vì sao lạm dụng hiệu ứng động lại làm giảm chất lượng bài trình chiếu?','Quá nhiều hiệu ứng gây rối mắt, phân tán sự chú ý khỏi nội dung, làm bài trình chiếu thiếu chuyên nghiệp và mất thời gian. Hiệu ứng chỉ nên dùng vừa phải để hỗ trợ, nhấn mạnh ý chính.']
 ]);
 add(M,7,'Bài 13: Thực hành tổng hợp: Hoàn thiện bài trình chiếu',[
  [1,'Để hoàn thiện bài trình chiếu, cần kết hợp kĩ năng nào?','Tạo slide, nhập nội dung, chèn hình, định dạng, thêm hiệu ứng','Chỉ tắt máy','Chỉ đọc email','Chỉ chơi game'],
  [1,'Trước khi trình chiếu trước lớp, nên làm gì?','Trình chiếu thử, kiểm tra lỗi và chỉnh sửa','Trình chiếu luôn không kiểm tra','Xóa hết slide','Tắt máy'],
  [2,'Một bài trình chiếu tốt cần bảo đảm điều gì?','Nội dung đúng, bố cục rõ, trình bày đẹp, dễ theo dõi','Càng nhiều chữ càng tốt','Nhiều hiệu ứng rối mắt','Không cần hình ảnh'],
  [2,'Thao tác nào giúp lưu lại bài trình chiếu để dùng sau?','Lưu tệp (Save)','Tắt máy đột ngột','Xóa tệp','Rút điện'],
  [2,'Để minh họa số liệu trong bài trình chiếu, nên chèn gì?','Biểu đồ hoặc bảng','Nhiều đoạn văn dài','Virus','Mật khẩu'],
  [3,'Nêu các bước hoàn thiện một bài trình chiếu trước khi báo cáo.','Rà soát nội dung, chính tả; kiểm tra bố cục, màu sắc, hình ảnh; điều chỉnh hiệu ứng vừa phải; trình chiếu thử; lưu tệp và chuẩn bị thuyết trình.'],
  [3,'Nêu một số tiêu chí đánh giá một bài trình chiếu tốt.','Nội dung đúng, đủ, rõ ràng; bố cục hợp lí, mỗi slide một ý; trình bày đẹp, chữ dễ đọc; hình ảnh/biểu đồ minh họa phù hợp; hiệu ứng vừa phải.'],
  [4,'Vì sao kĩ năng trình chiếu lại quan trọng trong học tập và cuộc sống?','Giúp trình bày ý tưởng rõ ràng, thuyết phục trước nhiều người; rèn khả năng diễn đạt, tự tin; cần thiết khi báo cáo, thuyết trình trong học tập và công việc sau này.']
 ]);
 add(M,7,'Bài 14: Thuật toán tìm kiếm tuần tự',[
  [1,'Thuật toán tìm kiếm tuần tự hoạt động như thế nào?','Lần lượt so sánh từng phần tử từ đầu đến khi tìm thấy hoặc hết dãy','Chia đôi dãy','Bỏ qua các phần tử','Tìm ngẫu nhiên'],
  [1,'Tìm kiếm tuần tự áp dụng được cho dãy như thế nào?','Mọi dãy, kể cả chưa sắp xếp','Chỉ dãy đã sắp xếp','Chỉ dãy số','Chỉ dãy rỗng'],
  [2,'Khi phần tử cần tìm nằm ở cuối dãy, tìm kiếm tuần tự phải làm gì?','So sánh gần như toàn bộ dãy','Tìm thấy ngay','Không tìm được','Bỏ qua'],
  [2,'Kết quả của thuật toán tìm kiếm là gì?','Vị trí phần tử (nếu có) hoặc thông báo không tìm thấy','Luôn là số 0','Sắp xếp lại dãy','Xóa dãy'],
  [2,'Nhược điểm của tìm kiếm tuần tự với dãy rất lớn là gì?','Có thể phải duyệt nhiều phần tử nên chậm','Luôn nhanh nhất','Không bao giờ sai','Không duyệt phần tử nào'],
  [3,'Mô tả thuật toán tìm kiếm tuần tự để tìm số x trong một dãy số.','Lần lượt từ phần tử đầu: so sánh phần tử với x; nếu bằng thì thông báo vị trí và dừng; nếu duyệt hết dãy mà không có thì thông báo "không tìm thấy".'],
  [3,'Vì sao tìm kiếm tuần tự áp dụng được cho cả dãy chưa sắp xếp?','Vì nó chỉ lần lượt so sánh từng phần tử, không phụ thuộc vào thứ tự của dãy; dù dãy lộn xộn vẫn duyệt hết và tìm được (nếu có).'],
  [4,'Với một danh sách rất dài, vì sao tìm kiếm tuần tự có thể không hiệu quả?','Vì trong trường hợp xấu nhất phải so sánh gần như toàn bộ phần tử (phần tử ở cuối hoặc không có), tốn nhiều thời gian. Với dãy đã sắp xếp, tìm kiếm nhị phân sẽ nhanh hơn nhiều.']
 ]);
 add(M,7,'Bài 15: Thuật toán tìm kiếm nhị phân',[
  [1,'Thuật toán tìm kiếm nhị phân yêu cầu dãy phải như thế nào?','Đã được sắp xếp','Lộn xộn','Rỗng','Chỉ có một phần tử'],
  [1,'Tìm kiếm nhị phân hoạt động theo cách nào?','So sánh với phần tử giữa rồi loại bỏ một nửa dãy','Duyệt lần lượt từ đầu','Tìm ngẫu nhiên','Sắp xếp lại dãy'],
  [2,'Sau mỗi bước so sánh, tìm kiếm nhị phân loại bỏ bao nhiêu phần dãy?','Khoảng một nửa','Một phần tử','Toàn bộ','Không loại bỏ gì'],
  [2,'So với tìm kiếm tuần tự, tìm kiếm nhị phân trên dãy đã sắp xếp có ưu điểm gì?','Nhanh hơn nhiều với dãy lớn','Chậm hơn','Giống hệt nhau','Không dùng được'],
  [2,'Nếu phần tử giữa lớn hơn giá trị cần tìm thì tiếp tục tìm ở đâu?','Nửa bên trái (các phần tử nhỏ hơn)','Nửa bên phải','Toàn bộ dãy','Không tìm nữa'],
  [3,'Mô tả ngắn gọn thuật toán tìm kiếm nhị phân.','Với dãy đã sắp xếp: so sánh x với phần tử giữa; nếu bằng thì tìm thấy; nếu x nhỏ hơn thì tìm ở nửa trái, nếu lớn hơn thì tìm ở nửa phải; lặp lại đến khi tìm thấy hoặc hết.'],
  [3,'Vì sao tìm kiếm nhị phân nhanh hơn tìm kiếm tuần tự với dãy lớn đã sắp xếp?','Vì mỗi bước loại bỏ được một nửa số phần tử cần xét, nên số lần so sánh ít hơn rất nhiều so với duyệt lần lượt từng phần tử.'],
  [4,'Vì sao tìm kiếm nhị phân không áp dụng được cho dãy chưa sắp xếp?','Vì nó dựa vào thứ tự để quyết định bỏ nửa trái hay nửa phải; nếu dãy chưa sắp xếp, việc so sánh với phần tử giữa không cho biết phần tử cần tìm ở nửa nào, nên thuật toán không còn đúng.']
 ]);
 add(M,7,'Bài 16: Thuật toán sắp xếp',[
  [1,'Thuật toán sắp xếp dùng để làm gì?','Xếp các phần tử của dãy theo thứ tự (tăng hoặc giảm)','Xóa dãy','Tìm phần tử','Cộng các phần tử'],
  [1,'Sau khi sắp xếp tăng dần, phần tử đầu dãy là gì?','Phần tử nhỏ nhất','Phần tử lớn nhất','Phần tử ở giữa','Phần tử bất kì'],
  [2,'Vì sao cần sắp xếp dữ liệu?','Dễ tra cứu, so sánh và áp dụng tìm kiếm nhị phân','Làm dữ liệu rối hơn','Xóa bớt dữ liệu','Không có lí do'],
  [2,'Ý tưởng chung của thuật toán sắp xếp là gì?','So sánh và đổi chỗ các phần tử cho đến khi đúng thứ tự','Xóa dần phần tử','Thêm phần tử mới','Chia đôi dãy'],
  [2,'Sắp xếp danh sách học sinh theo điểm từ cao xuống thấp là sắp xếp gì?','Giảm dần','Tăng dần','Ngẫu nhiên','Không sắp xếp'],
  [3,'Nêu một ví dụ thực tế cần sắp xếp dữ liệu.','VD: xếp hạng học sinh theo điểm; sắp xếp danh sách theo bảng chữ cái; xếp sản phẩm theo giá; xếp sự kiện theo thời gian.'],
  [3,'Nêu mối liên hệ giữa sắp xếp và tìm kiếm nhị phân.','Tìm kiếm nhị phân chỉ dùng được trên dãy đã sắp xếp; vì vậy muốn tìm kiếm nhanh bằng nhị phân thì trước hết phải sắp xếp dữ liệu.'],
  [4,'Vì sao dữ liệu đã sắp xếp giúp các công việc xử lí sau này nhanh và thuận tiện hơn?','Dữ liệu có thứ tự giúp tra cứu nhanh (áp dụng tìm kiếm nhị phân), dễ so sánh, phát hiện trùng lặp, lập bảng xếp hạng, thống kê; tiết kiệm thời gian xử lí so với dữ liệu lộn xộn.']
 ]);

 /* -------- LỚP 7: bù lẻ cho đủ chuẩn (các bài) -------- */
 add(M,7,'Bài 1: Thiết bị vào - ra',[
  [3,'Nêu vai trò của thiết bị vào và thiết bị ra trong quá trình xử lí thông tin.','Thiết bị vào giúp đưa dữ liệu vào máy để xử lí; thiết bị ra đưa kết quả xử lí cho người dùng. Cả hai là cầu nối giữa con người và máy tính.']
 ]);
 add(M,7,'Bài 2: Phần mềm máy tính',[
  [3,'Kể tên 2 phần mềm hệ thống và 2 phần mềm ứng dụng.','Phần mềm hệ thống: Windows, Android (hệ điều hành). Phần mềm ứng dụng: Word, Excel, trình duyệt web, PowerPoint.']
 ]);
 add(M,7,'Bài 6: Làm quen với phần mềm bảng tính',[
  [3,'Nêu lợi ích của bảng tính so với tính toán bằng tay.','Tính tự động, nhanh, chính xác; sửa và cập nhật dễ; sắp xếp, lọc, vẽ biểu đồ; trình bày đẹp.']
 ]);
 add(M,7,'Bài 8: Công cụ hỗ trợ tính toán',[
  [1,'Hàm COUNT (hoặc đếm) dùng để làm gì?','Đếm số ô có chứa số (dữ liệu)','Tính tổng','Tính trung bình','Tìm giá trị lớn nhất'],
  [3,'Viết công thức tìm điểm cao nhất và thấp nhất của các ô từ D2 đến D20.','Cao nhất: =MAX(D2:D20). Thấp nhất: =MIN(D2:D20).']
 ]);

 /* -------- LỚP 7: chủ đề tổng hợp -------- */
 add(M,7,'Bảng tính điện tử',[
  [1,'Trong bảng tính, công thức bắt đầu bằng dấu gì?','Dấu bằng (=)','Dấu cộng','Dấu chấm','Dấu hỏi'],
  [2,'Hàm nào tính trung bình cộng?','AVERAGE','SUM','MAX','COUNT'],
  [2,'Địa chỉ ô A1 chỉ vị trí nào?','Giao của cột A và hàng 1','Cột 1 hàng A','Ô giữa','Ô bất kì'],
  [3,'Viết công thức tính tổng và trung bình các ô từ B2 đến B6.','Tổng: =SUM(B2:B6). Trung bình: =AVERAGE(B2:B6).'],
  [4,'Vì sao bảng tính giúp quản lí bảng điểm hiệu quả?','Nhập nhanh, tự động tính tổng/trung bình, sắp xếp, lọc, cập nhật dễ, vẽ biểu đồ — tiết kiệm thời gian và chính xác hơn tính tay.']
 ]);
 add(M,7,'Mạng xã hội, thuật toán',[
  [1,'Khi dùng mạng xã hội, thông tin nào KHÔNG nên chia sẻ công khai?','Mật khẩu, địa chỉ nhà, số điện thoại','Lời chúc bạn','Ảnh phong cảnh','Bài học bổ ích'],
  [2,'Tìm kiếm nhị phân yêu cầu dãy phải thế nào?','Đã sắp xếp','Lộn xộn','Rỗng','Chỉ một phần tử'],
  [2,'Ứng xử văn hóa trên mạng là gì?','Lịch sự, tôn trọng người khác, tuân thủ pháp luật','Nói xấu người khác','Tung tin giả','Vi phạm bản quyền'],
  [3,'So sánh tìm kiếm tuần tự và tìm kiếm nhị phân.','Tuần tự: duyệt lần lượt, dùng cho mọi dãy, chậm với dãy lớn. Nhị phân: chia đôi dãy, chỉ dùng cho dãy đã sắp xếp, nhanh hơn nhiều với dãy lớn.'],
  [4,'Vì sao cần ứng xử có văn hóa và an toàn khi tham gia mạng xã hội?','Vì lời nói, hành vi trên mạng ảnh hưởng đến người khác và chính mình, lan nhanh, khó thu hồi; ứng xử văn hóa và cẩn trọng giúp tránh tổn thương, lừa đảo, vi phạm pháp luật và bảo vệ bản thân.']
 ]);
 add(M,7,'Phần mềm trình chiếu và bảng tính nâng cao',[
  [1,'Mỗi trang của bài trình chiếu gọi là gì?','Trang chiếu (slide)','Ô','Hàng','Thư mục'],
  [2,'Biểu đồ trong bảng tính dùng để làm gì?','Biểu diễn dữ liệu trực quan, dễ so sánh','Xóa dữ liệu','Làm rối bảng','Tắt máy'],
  [2,'Nội dung trên mỗi trang chiếu nên thế nào?','Ngắn gọn, mỗi slide một ý, có hình minh họa','Chép cả bài dài','Toàn chữ nhỏ','Không tiêu đề'],
  [3,'Nêu các bước tạo biểu đồ từ dữ liệu bảng tính.','Chọn vùng dữ liệu; chọn Chèn biểu đồ; chọn loại phù hợp (cột, đường, quạt); thêm tiêu đề, chú thích; chỉnh sửa cho rõ.'],
  [4,'Vì sao kết hợp bảng tính (số liệu, biểu đồ) với trình chiếu giúp báo cáo thuyết phục hơn?','Bảng tính cho số liệu và biểu đồ trực quan; trình chiếu trình bày ý chính mạch lạc. Kết hợp giúp người nghe vừa thấy dữ liệu chứng minh, vừa dễ theo dõi lập luận, nên báo cáo rõ ràng và thuyết phục hơn.']
 ]);

 /* -------- LỚP 7: bù lẻ cho đủ chuẩn (chủ đề tổng hợp) -------- */
 add(M,7,'Bảng tính điện tử',[
  [3,'Nêu một số hàm thông dụng trong bảng tính và công dụng.','SUM: tính tổng; AVERAGE: trung bình; MAX: giá trị lớn nhất; MIN: nhỏ nhất; COUNT: đếm ô có số.']
 ]);
 add(M,7,'Mạng xã hội, thuật toán',[
  [1,'Khi bị bắt nạt trên mạng, em nên làm gì?','Không trả đũa, lưu bằng chứng, chặn và báo người lớn','Trả đũa gay gắt','Im lặng chịu đựng','Chia sẻ rộng cho mọi người'],
  [3,'Vì sao tìm kiếm nhị phân nhanh hơn tìm kiếm tuần tự với dãy lớn đã sắp xếp?','Vì mỗi bước loại bỏ được một nửa số phần tử cần xét nên số lần so sánh ít hơn nhiều so với duyệt lần lượt.']
 ]);
 add(M,7,'Phần mềm trình chiếu và bảng tính nâng cao',[
  [3,'Nêu một số lưu ý để bài trình chiếu dễ theo dõi.','Mỗi slide một ý chính; chữ to, ít chữ; dùng từ khóa; hình ảnh minh họa; màu nền và chữ tương phản; hiệu ứng vừa phải.']
 ]);

 /* ===================== LỚP 8 ===================== */
 add(M,8,'Bài 1: Lược sử công cụ tính toán',[
  [1,'Công cụ tính toán cổ xưa dùng các hạt trượt trên que là gì?','Bàn tính','Máy tính điện tử','Điện thoại','Máy chiếu'],
  [1,'Máy tính điện tử hiện đại hoạt động dựa trên hệ số nào?','Hệ nhị phân (0 và 1)','Hệ thập phân','Hệ La Mã','Hệ chữ cái'],
  [2,'Xu hướng phát triển của công cụ tính toán theo thời gian là gì?','Ngày càng nhỏ gọn, nhanh, mạnh và thông minh hơn','Ngày càng to và chậm','Không thay đổi','Ngày càng đắt và yếu'],
  [2,'Thiết bị nào dưới đây là máy tính cá nhân hiện đại?','Máy tính để bàn, máy tính xách tay','Bàn tính gảy','Thước loga','Que tính'],
  [2,'Một trong những đặc điểm nổi bật của máy tính ngày nay là gì?','Xử lí nhanh khối lượng dữ liệu rất lớn','Chỉ tính được số nhỏ','Không lưu trữ được','Phải quay tay'],
  [3,'Nêu xu hướng phát triển của công cụ tính toán từ xưa đến nay.','Từ các công cụ thủ công (bàn tính) đến máy cơ khí, rồi máy tính điện tử; ngày càng nhỏ gọn, nhanh, mạnh, nhiều chức năng và phổ biến hơn.'],
  [3,'Nêu một số thiết bị tính toán, xử lí thông tin em biết hiện nay.','Máy tính để bàn, laptop, máy tính bảng, điện thoại thông minh, máy chủ, siêu máy tính.'],
  [4,'Vì sao sự ra đời của máy tính điện tử được coi là bước ngoặt lớn của công cụ tính toán?','Máy tính điện tử xử lí tự động, nhanh, chính xác với khối lượng dữ liệu khổng lồ, lập trình được để làm nhiều việc khác nhau; nhờ đó thay đổi sâu sắc cách con người tính toán, làm việc, giao tiếp và sống.']
 ]);
 add(M,8,'Bài 2: Thông tin trong môi trường số',[
  [1,'Thông tin số là gì?','Thông tin được biểu diễn, lưu trữ, xử lí trong các thiết bị số','Chỉ thông tin trên giấy','Chỉ lời nói','Chỉ hình vẽ tay'],
  [1,'Đặc điểm nào đúng về thông tin số?','Dễ sao chép, lan truyền nhanh, khó thu hồi','Không sao chép được','Lan truyền chậm','Luôn chính xác'],
  [2,'Vì sao cần đánh giá độ tin cậy của thông tin số?','Vì có nhiều thông tin sai, giả, thiếu kiểm chứng trên mạng','Vì mọi thông tin đều đúng','Vì thông tin số không quan trọng','Vì không ai đăng sai'],
  [2,'Cách nào giúp kiểm tra độ tin cậy của một thông tin trên mạng?','Đối chiếu nhiều nguồn, xem nguồn uy tín, kiểm tra thời gian','Tin ngay nguồn đầu tiên','Xem tiêu đề giật gân','Dựa vào số lượt thích'],
  [2,'Thông tin đáng tin cậy thường có đặc điểm gì?','Có nguồn rõ ràng, uy tín, cập nhật, khách quan','Giấu nguồn','Giật tít câu view','Thiếu kiểm chứng'],
  [3,'Nêu các tiêu chí để đánh giá độ tin cậy của thông tin số.','Nguồn gốc (uy tín, chính thống); tác giả; thời gian cập nhật; tính khách quan; đối chiếu với các nguồn khác; mục đích của thông tin.'],
  [3,'Nêu tác hại của việc tin và chia sẻ thông tin sai lệch.','Hiểu sai sự việc, ra quyết định sai; gây hoang mang, mâu thuẫn; làm hại người khác; có thể vi phạm pháp luật khi lan truyền tin giả.'],
  [4,'Vì sao trong môi trường số, kĩ năng chọn lọc và đánh giá thông tin lại rất quan trọng?','Vì lượng thông tin khổng lồ, lẫn lộn đúng – sai, tốt – xấu, lan truyền nhanh. Biết chọn lọc, đánh giá giúp tiếp nhận thông tin đúng, tránh bị lừa, bị thao túng và sử dụng thông tin hiệu quả, an toàn.']
 ]);
 add(M,8,'Bài 3: Thực hành: Khai thác thông tin số',[
  [1,'Khai thác thông tin số là gì?','Tìm kiếm, chọn lọc, sử dụng thông tin từ các nguồn số một cách phù hợp','Xóa thông tin','Chỉ lưu trữ','Chặn Internet'],
  [1,'Khi lấy thông tin, hình ảnh của người khác trên mạng, em cần chú ý điều gì?','Tôn trọng bản quyền, ghi nguồn, xin phép khi cần','Lấy tùy ý','Nhận là của mình','Không cần quan tâm'],
  [2,'Để tìm thông tin đúng nhu cầu, em nên làm gì?','Chọn từ khóa phù hợp, dùng nguồn uy tín, chọn lọc kết quả','Nhập từ khóa mơ hồ','Tin mọi kết quả','Chỉ xem quảng cáo'],
  [2,'Khi dùng thông tin từ Internet cho bài học, em nên làm gì?','Chọn lọc, kiểm chứng, trích dẫn nguồn','Sao chép nguyên si không ghi nguồn','Dùng tin chưa kiểm chứng','Bịa thêm số liệu'],
  [2,'Việc trích dẫn nguồn khi dùng thông tin của người khác thể hiện điều gì?','Trung thực, tôn trọng bản quyền','Sợ hãi','Lười biếng','Khoe khoang'],
  [3,'Nêu các bước khai thác một thông tin số phục vụ học tập.','Xác định nhu cầu; chọn từ khóa, tìm kiếm; chọn nguồn uy tín; đánh giá độ tin cậy; chọn lọc, ghi lại và trích dẫn nguồn; sử dụng đúng mục đích.'],
  [3,'Vì sao cần ghi rõ nguồn khi sử dụng thông tin, hình ảnh của người khác?','Để tôn trọng công sức, quyền tác giả; bảo đảm trung thực; giúp người đọc kiểm chứng; tránh vi phạm bản quyền.'],
  [4,'Vì sao khai thác thông tin số đúng cách vừa hiệu quả vừa thể hiện người dùng có văn hóa?','Khai thác đúng cách giúp tìm được thông tin chính xác, hữu ích, tiết kiệm thời gian; đồng thời tôn trọng bản quyền, trung thực khi trích dẫn, không lan truyền tin sai — thể hiện người dùng có hiểu biết và trách nhiệm.']
 ]);
 add(M,8,'Bài 4: Đạo đức và văn hóa trong sử dụng công nghệ kĩ thuật số',[
  [1,'Hành vi nào thể hiện văn hóa khi sử dụng công nghệ số?','Tôn trọng người khác, tuân thủ pháp luật, bảo vệ bản quyền','Tung tin giả','Xâm phạm riêng tư người khác','Sao chép trái phép'],
  [1,'Hành vi nào vi phạm đạo đức, pháp luật khi dùng công nghệ số?','Đăng tin sai, bôi nhọ, đánh cắp thông tin','Học trực tuyến','Gửi email lịch sự','Trích dẫn ghi nguồn'],
  [2,'Khi sử dụng sản phẩm số của người khác (ảnh, nhạc, phần mềm), em cần làm gì?','Tôn trọng bản quyền, không sao chép, dùng trái phép','Tự do lấy dùng','Bán lại kiếm lời','Xóa tên tác giả'],
  [2,'Việc bảo vệ thông tin cá nhân của mình và người khác thể hiện điều gì?','Ý thức đạo đức, trách nhiệm khi dùng công nghệ số','Sự ích kỉ','Sự lạc hậu','Không cần thiết'],
  [2,'Hành vi nào tôn trọng quyền riêng tư của người khác?','Không tự ý đăng ảnh, thông tin của người khác khi chưa được phép','Chia sẻ ảnh người khác tùy ý','Phát tán tin nhắn riêng','Theo dõi trộm'],
  [3,'Nêu một số quy tắc đạo đức, văn hóa khi sử dụng công nghệ kĩ thuật số.','Tôn trọng người khác và quyền riêng tư; không tung tin giả, bôi nhọ; tôn trọng bản quyền; bảo vệ thông tin cá nhân; tuân thủ pháp luật; sử dụng có trách nhiệm.'],
  [3,'Nêu hậu quả của các hành vi thiếu đạo đức khi dùng công nghệ số (tung tin giả, xâm phạm riêng tư).','Gây tổn hại danh dự, tinh thần cho người khác; gây hoang mang xã hội; làm mất lòng tin; bị xử lí theo pháp luật; ảnh hưởng xấu đến chính người vi phạm.'],
  [4,'Vì sao sử dụng công nghệ số cần đi đôi với đạo đức và ý thức pháp luật?','Công nghệ số có sức lan tỏa mạnh, hành vi xấu gây hậu quả nhanh và rộng. Dùng có đạo đức, đúng pháp luật giúp bảo vệ mình và người khác, xây dựng môi trường số lành mạnh, văn minh; thiếu đạo đức dễ gây hại và vi phạm pháp luật.']
 ]);
 add(M,8,'Bài 5: Sử dụng bảng tính giải quyết bài toán thực tế',[
  [1,'Bảng tính giúp giải quyết bài toán thực tế nào?','Quản lí thu chi, bảng điểm, thống kê, dự toán','Vẽ tranh nghệ thuật','Nghe nhạc','Diệt virus'],
  [1,'Để tính toán tự động trong bảng tính, em dùng gì?','Công thức và hàm','Hình vẽ','Màu nền','Hiệu ứng'],
  [2,'Khi dữ liệu thay đổi, công thức trong bảng tính sẽ thế nào?','Tự động tính lại kết quả','Giữ nguyên kết quả cũ','Báo lỗi','Xóa dữ liệu'],
  [2,'Để lập bảng quản lí chi tiêu, cần có những cột nào?','Khoản mục, số tiền, ngày, ghi chú','Chỉ màu sắc','Chỉ hình ảnh','Chỉ tiêu đề'],
  [2,'Hàm nào dùng để tính tổng chi tiêu trong tháng?','SUM','MAX','MIN','COUNT'],
  [3,'Nêu các bước dùng bảng tính để quản lí chi tiêu cá nhân.','Lập bảng (cột: khoản mục, số tiền, ngày); nhập dữ liệu; dùng hàm SUM tính tổng, AVERAGE tính trung bình; định dạng, vẽ biểu đồ; theo dõi và điều chỉnh.'],
  [3,'Nêu lợi ích của việc dùng bảng tính để giải quyết bài toán thực tế.','Tính nhanh, chính xác, tự cập nhật; dễ thống kê, so sánh; trực quan qua biểu đồ; giúp quản lí, ra quyết định hiệu quả.'],
  [4,'Vì sao bảng tính là công cụ phù hợp để giải nhiều bài toán quản lí trong thực tế?','Vì bảng tính xử lí dữ liệu dạng bảng linh hoạt, tính toán tự động bằng công thức/hàm, cập nhật nhanh khi dữ liệu thay đổi, biết sắp xếp, lọc, thống kê và vẽ biểu đồ — rất hợp để quản lí thu chi, điểm số, kho hàng, thống kê...']
 ]);
 add(M,8,'Bài 6: Sắp xếp và lọc dữ liệu',[
  [1,'Sắp xếp dữ liệu (Sort) là gì?','Xếp dữ liệu theo thứ tự tăng hoặc giảm','Xóa dữ liệu','Thêm dữ liệu','Tính tổng'],
  [1,'Lọc dữ liệu (Filter) để làm gì?','Chỉ hiển thị các dòng thỏa điều kiện','Xóa toàn bộ dữ liệu','In tất cả','Vẽ hình'],
  [2,'Muốn xem danh sách học sinh giỏi (điểm ≥ 8), em dùng công cụ nào?','Lọc dữ liệu theo điều kiện','Xóa bảng','Đổi màu','Tắt máy'],
  [2,'Sắp xếp danh sách theo điểm từ cao xuống thấp là sắp xếp gì?','Giảm dần','Tăng dần','Ngẫu nhiên','Theo màu'],
  [2,'Lợi ích của sắp xếp và lọc dữ liệu là gì?','Dễ tra cứu, phân tích, tìm thông tin cần thiết nhanh','Làm rối dữ liệu','Mất dữ liệu','Không có lợi ích'],
  [3,'Nêu các bước lọc dữ liệu để tìm những học sinh đạt điểm từ 8 trở lên.','Chọn vùng dữ liệu (có tiêu đề); bật chức năng Lọc (Filter); đặt điều kiện cho cột điểm (≥ 8); bảng hiển thị các dòng thỏa điều kiện.'],
  [3,'Phân biệt sắp xếp và lọc dữ liệu.','Sắp xếp: thay đổi thứ tự các dòng theo tăng/giảm. Lọc: giữ nguyên dữ liệu nhưng chỉ hiển thị các dòng thỏa điều kiện, ẩn các dòng còn lại.'],
  [4,'Vì sao sắp xếp và lọc dữ liệu giúp ích nhiều khi làm việc với bảng dữ liệu lớn?','Với dữ liệu nhiều dòng, sắp xếp giúp xem theo thứ tự (xếp hạng), lọc giúp nhanh chóng tách ra nhóm cần quan tâm; nhờ đó tra cứu, phân tích, báo cáo nhanh và chính xác, tránh dò tìm thủ công mất thời gian.']
 ]);
 add(M,8,'Bài 7: Trình bày dữ liệu bằng biểu đồ',[
  [1,'Biểu đồ dùng để làm gì?','Biểu diễn dữ liệu trực quan để dễ so sánh, nhận xét','Xóa dữ liệu','Tính toán','Diệt virus'],
  [1,'Loại biểu đồ nào thường dùng để so sánh số liệu giữa các nhóm?','Biểu đồ cột','Biểu đồ không có','Chỉ dùng chữ','Chỉ dùng màu'],
  [2,'Biểu đồ hình quạt (tròn) thường dùng để thể hiện gì?','Tỉ lệ phần trăm của các phần trong tổng thể','So sánh theo thời gian','Danh sách tên','Công thức'],
  [2,'Biểu đồ đường thường dùng để thể hiện điều gì?','Sự thay đổi của dữ liệu theo thời gian','Tỉ lệ phần trăm','Danh sách','Màu sắc'],
  [2,'Để biểu đồ dễ hiểu, cần có gì?','Tiêu đề, chú thích, nhãn trục rõ ràng','Không có tiêu đề','Nhiều màu lộn xộn','Không nhãn'],
  [3,'Nêu các bước tạo biểu đồ từ dữ liệu bảng tính.','Chọn vùng dữ liệu; chọn Chèn biểu đồ; chọn loại phù hợp (cột, đường, quạt); thêm tiêu đề, chú thích, nhãn; chỉnh sửa cho rõ ràng.'],
  [3,'Nêu cách chọn loại biểu đồ phù hợp với dữ liệu.','So sánh giữa các nhóm → biểu đồ cột; thể hiện tỉ lệ trong tổng → biểu đồ quạt; thể hiện xu hướng theo thời gian → biểu đồ đường.'],
  [4,'Vì sao chọn đúng loại biểu đồ lại quan trọng khi trình bày dữ liệu?','Mỗi loại biểu đồ phù hợp với một kiểu dữ liệu; chọn đúng giúp thể hiện rõ ý nghĩa (so sánh, tỉ lệ, xu hướng), người xem hiểu nhanh và đúng. Chọn sai loại dễ gây hiểu nhầm hoặc không làm nổi bật được thông tin.']
 ]);
 add(M,8,'Bài 12: Từ thuật toán đến chương trình',[
  [1,'Để máy tính thực hiện, thuật toán cần được chuyển thành gì?','Chương trình (viết bằng ngôn ngữ lập trình)','Một bức tranh','Một bài hát','Một tờ giấy'],
  [1,'Quan hệ giữa thuật toán và chương trình là gì?','Chương trình là thuật toán được viết bằng ngôn ngữ lập trình','Chúng không liên quan','Chương trình có trước thuật toán','Giống hệt phần cứng'],
  [2,'Trước khi viết chương trình, nên làm gì?','Xác định bài toán và xây dựng thuật toán','Viết ngay không suy nghĩ','Tắt máy','Xóa dữ liệu'],
  [2,'Môi trường lập trình trực quan phổ biến cho học sinh là gì?','Scratch','Microsoft Word','Paint','Windows'],
  [2,'Việc chạy thử chương trình nhằm mục đích gì?','Kiểm tra đúng/sai và phát hiện lỗi','Xóa chương trình','Tắt máy','Đổi tên tệp'],
  [3,'Nêu các bước chuyển từ bài toán thành chương trình.','Xác định bài toán (đầu vào, đầu ra); xây dựng thuật toán; viết chương trình bằng ngôn ngữ lập trình; chạy thử, gỡ lỗi; hoàn thiện.'],
  [3,'Vì sao cần xây dựng thuật toán đúng trước khi viết chương trình?','Vì chương trình chỉ diễn đạt thuật toán cho máy hiểu; thuật toán sai thì chương trình dù đúng cú pháp vẫn cho kết quả sai. Thuật toán đúng là nền tảng của chương trình đúng.'],
  [4,'Vì sao cùng một bài toán có thể có nhiều thuật toán và chương trình khác nhau?','Vì có nhiều cách giải quyết một vấn đề; mỗi cách cho một thuật toán, viết thành chương trình khác nhau. Người lập trình chọn thuật toán hiệu quả (nhanh, dễ hiểu, ít tốn tài nguyên) phù hợp với yêu cầu.']
 ]);
 add(M,8,'Bài 13: Biểu diễn dữ liệu',[
  [1,'Trong chương trình, biến (variable) dùng để làm gì?','Lưu trữ dữ liệu có thể thay đổi khi chương trình chạy','Xóa chương trình','Tắt máy','Trang trí'],
  [1,'Kiểu dữ liệu số dùng để lưu gì?','Các con số để tính toán','Chỉ chữ cái','Chỉ hình ảnh','Chỉ âm thanh'],
  [2,'Dữ liệu dạng văn bản (xâu kí tự) thường dùng để lưu gì?','Tên, địa chỉ, câu chữ','Chỉ phép tính','Chỉ đúng/sai','Chỉ ngày tháng'],
  [2,'Kiểu dữ liệu lô-gic (boolean) nhận những giá trị nào?','Đúng (true) hoặc Sai (false)','Mọi con số','Mọi chữ cái','Hình ảnh'],
  [2,'Vì sao cần chọn đúng kiểu dữ liệu cho biến?','Để lưu và xử lí dữ liệu đúng, tránh lỗi','Để chương trình đẹp hơn','Không có lí do','Để tốn bộ nhớ'],
  [3,'Nêu một số kiểu dữ liệu cơ bản và ví dụ.','Số (tính toán: 5, 3.14); xâu kí tự/văn bản ("Hoa", "Lớp 8A"); lô-gic (đúng/sai). Mỗi biến có một kiểu dữ liệu phù hợp.'],
  [3,'Biến là gì? Cho ví dụ về việc dùng biến trong chương trình.','Biến là vùng nhớ có tên dùng để lưu dữ liệu thay đổi được. VD: biến "diem" lưu điểm; biến "ten" lưu tên; khi chạy, giá trị của biến có thể thay đổi.'],
  [4,'Vì sao việc dùng biến giúp chương trình linh hoạt hơn?','Nhờ biến, chương trình có thể làm việc với dữ liệu khác nhau (nhập vào lúc chạy) mà không phải sửa chương trình; cùng một chương trình xử lí được nhiều trường hợp, tái sử dụng và dễ bảo trì.']
 ]);
 add(M,8,'Bài 14: Cấu trúc điều khiển',[
  [1,'Có mấy loại cấu trúc điều khiển cơ bản trong lập trình?','Ba: tuần tự, rẽ nhánh, lặp','Một','Hai','Năm'],
  [1,'Cấu trúc rẽ nhánh dùng để làm gì?','Chọn thực hiện công việc tùy theo điều kiện đúng/sai','Lặp lại mãi','Bỏ qua lệnh','Tắt máy'],
  [2,'Cấu trúc lặp dùng khi nào?','Khi cần thực hiện lặp lại một số lệnh nhiều lần','Khi chỉ làm một lần','Khi không cần làm gì','Khi tắt chương trình'],
  [2,'Câu lệnh "Nếu điểm ≥ 5 thì Đạt, ngược lại Chưa đạt" thể hiện cấu trúc nào?','Rẽ nhánh','Tuần tự','Lặp','Không có'],
  [2,'Để in ra các số từ 1 đến 100, nên dùng cấu trúc nào?','Lặp','Tuần tự thuần túy (viết 100 lệnh)','Rẽ nhánh','Không dùng được'],
  [3,'Nêu ví dụ sử dụng cấu trúc lặp trong lập trình.','VD: lặp để tính tổng 1+2+...+n; lặp in dãy số; lặp để nhập điểm cho cả lớp — làm lại một việc nhiều lần nên dùng cấu trúc lặp thay vì viết nhiều lệnh.'],
  [3,'Viết mô tả thuật toán có rẽ nhánh: xếp loại điểm (Đạt nếu điểm ≥ 5).','Nhập điểm. Nếu điểm ≥ 5 thì in "Đạt"; ngược lại in "Chưa đạt". Kết thúc.'],
  [4,'Vì sao cấu trúc lặp giúp chương trình ngắn gọn và mạnh hơn?','Thay vì viết lại nhiều lệnh giống nhau, cấu trúc lặp cho phép máy tự thực hiện lặp lại nhiều lần chỉ với một đoạn lệnh; chương trình ngắn, dễ sửa và xử lí được khối lượng công việc lớn (hàng nghìn, triệu lần).']
 ]);
 add(M,8,'Bài 15: Gỡ lỗi',[
  [1,'Gỡ lỗi (debug) chương trình là gì?','Tìm và sửa các lỗi khiến chương trình chạy sai','Xóa chương trình','Tắt máy','Đổi tên tệp'],
  [1,'Lỗi cú pháp là lỗi gì?','Viết sai quy tắc của ngôn ngữ lập trình','Máy tính bị hỏng','Mất điện','Màn hình tối'],
  [2,'Lỗi lô-gic (logic) là lỗi như thế nào?','Chương trình chạy được nhưng cho kết quả sai','Không chạy được do sai chính tả lệnh','Do hỏng phần cứng','Do mất mạng'],
  [2,'Cách nào giúp phát hiện lỗi trong chương trình?','Chạy thử với dữ liệu mẫu, kiểm tra kết quả từng bước','Không chạy thử','Xóa chương trình','Tắt máy'],
  [2,'Khi chương trình cho kết quả sai, trước hết nên làm gì?','Kiểm tra lại thuật toán và các lệnh, chạy thử tìm lỗi','Bỏ cuộc','Đổi máy tính','Xóa hết'],
  [3,'Nêu các bước cơ bản để gỡ lỗi một chương trình.','Chạy thử với dữ liệu mẫu đã biết kết quả; so sánh kết quả; xác định chỗ sai (cú pháp hay lô-gic); sửa lỗi; chạy lại kiểm tra đến khi đúng.'],
  [3,'Phân biệt lỗi cú pháp và lỗi lô-gic.','Lỗi cú pháp: viết sai quy tắc ngôn ngữ nên chương trình không chạy. Lỗi lô-gic: chương trình chạy được nhưng thuật toán sai nên kết quả sai.'],
  [4,'Vì sao kĩ năng gỡ lỗi quan trọng với người lập trình?','Hầu hết chương trình ban đầu đều có lỗi; biết tìm và sửa lỗi giúp chương trình chạy đúng, đáng tin cậy. Gỡ lỗi rèn tư duy logic, cẩn thận và kiên nhẫn — kĩ năng thiết yếu của lập trình.']
 ]);
 add(M,8,'Bài 16: Tin học với nghề nghiệp',[
  [1,'Tin học có vai trò như thế nào đối với các ngành nghề hiện nay?','Hỗ trợ hầu hết các ngành nghề, nâng cao hiệu quả công việc','Chỉ dùng cho một nghề','Không liên quan','Làm chậm công việc'],
  [1,'Nghề nào dưới đây liên quan trực tiếp đến tin học?','Lập trình viên, kĩ sư phần mềm','Chỉ nông dân','Chỉ thợ may','Không có nghề nào'],
  [2,'Kĩ năng tin học giúp ích gì cho người lao động?','Làm việc nhanh, chính xác, tra cứu và xử lí thông tin tốt','Làm chậm công việc','Không có ích','Gây khó khăn'],
  [2,'Để chuẩn bị cho nghề nghiệp tương lai liên quan tin học, học sinh nên làm gì?','Học tốt tin học, rèn tư duy, tự tìm hiểu công nghệ','Bỏ qua tin học','Chỉ chơi game','Không cần học'],
  [2,'Ứng dụng của tin học trong y tế là gì?','Quản lí hồ sơ bệnh án, chẩn đoán, thiết bị y tế số','Không có ứng dụng','Làm bệnh nặng hơn','Thay thế hoàn toàn bác sĩ'],
  [3,'Kể một số nghề nghiệp trong lĩnh vực tin học.','Lập trình viên, kĩ sư phần mềm, quản trị mạng, chuyên gia an toàn thông tin, phân tích dữ liệu, thiết kế đồ họa, quản trị web.'],
  [3,'Nêu ví dụ ứng dụng của tin học trong một số lĩnh vực đời sống.','Giáo dục (học trực tuyến), y tế (quản lí bệnh án), giao thông (bản đồ, điều khiển), kinh doanh (bán hàng online), ngân hàng (giao dịch số)...'],
  [4,'Vì sao hiểu biết tin học trở thành kĩ năng cần thiết với hầu hết nghề nghiệp ngày nay?','Vì tin học và công nghệ số thâm nhập mọi lĩnh vực; biết dùng máy tính, phần mềm, xử lí dữ liệu, làm việc trực tuyến giúp làm việc hiệu quả, nhanh, chính xác và thích ứng với thời đại số, dù ở ngành nghề nào.']
 ]);
 /* Chủ đề tổng hợp L8 */
 add(M,8,'Sơ đồ, biểu đồ, xử lí dữ liệu',[
  [1,'Biểu đồ cột thường dùng để làm gì?','So sánh số liệu giữa các nhóm','Thể hiện tỉ lệ phần trăm là chính','Lưu trữ dữ liệu','Diệt virus'],
  [2,'Lọc dữ liệu (Filter) dùng để làm gì?','Chỉ hiển thị các dòng thỏa điều kiện','Xóa dữ liệu','Tính tổng','Tắt máy'],
  [2,'Biểu đồ hình quạt thể hiện điều gì?','Tỉ lệ các phần trong tổng thể','Xu hướng theo thời gian','Danh sách tên','Công thức'],
  [3,'Nêu các loại biểu đồ thông dụng và trường hợp dùng.','Cột: so sánh nhóm; đường: xu hướng theo thời gian; quạt (tròn): tỉ lệ phần trăm trong tổng thể.'],
  [4,'Vì sao kết hợp sắp xếp, lọc và biểu đồ giúp phân tích dữ liệu hiệu quả?','Sắp xếp và lọc giúp tổ chức, chọn lọc dữ liệu cần quan tâm; biểu đồ trực quan hóa để thấy nhanh xu hướng, tỉ lệ, so sánh. Kết hợp lại giúp hiểu và rút ra kết luận từ dữ liệu nhanh, chính xác.']
 ]);
 add(M,8,'Thuật toán, lập trình trực quan',[
  [1,'Môi trường lập trình trực quan kéo thả khối lệnh là gì?','Scratch','Word','Excel','Paint'],
  [2,'Cấu trúc nào dùng để lặp lại công việc nhiều lần?','Cấu trúc lặp','Tuần tự thuần','Không có','Rẽ nhánh một lần'],
  [2,'Gỡ lỗi (debug) là làm gì?','Tìm và sửa lỗi của chương trình','Xóa chương trình','Tắt máy','Đổi tên tệp'],
  [3,'Nêu ba cấu trúc điều khiển cơ bản và vai trò.','Tuần tự (thực hiện lần lượt), rẽ nhánh (chọn theo điều kiện), lặp (thực hiện lặp lại). Kết hợp để diễn đạt mọi thuật toán.'],
  [4,'Vì sao cần chạy thử và gỡ lỗi sau khi viết chương trình?','Vì chương trình ban đầu thường còn lỗi cú pháp hoặc lô-gic; chạy thử với dữ liệu mẫu giúp phát hiện và sửa, bảo đảm chương trình cho kết quả đúng, đáng tin cậy.']
 ]);
 add(M,8,'Bảng tính và xử lí dữ liệu',[
  [1,'Hàm tính tổng trong bảng tính là hàm nào?','SUM','MAX','MIN','IF'],
  [2,'Muốn lọc học sinh có điểm ≥ 8, dùng công cụ nào?','Lọc dữ liệu theo điều kiện','Xóa bảng','Đổi màu','Tắt máy'],
  [2,'Biểu đồ giúp gì khi xử lí dữ liệu?','Trực quan hóa để dễ so sánh, nhận xét','Làm rối dữ liệu','Xóa dữ liệu','Không có tác dụng'],
  [3,'Viết công thức tính tổng và trung bình các ô từ C2 đến C40.','Tổng: =SUM(C2:C40). Trung bình: =AVERAGE(C2:C40).'],
  [4,'Vì sao bảng tính giúp giải quyết nhiều bài toán thực tế hiệu quả?','Bảng tính tính toán tự động, cập nhật nhanh khi dữ liệu đổi; biết sắp xếp, lọc, thống kê và vẽ biểu đồ; phù hợp quản lí thu chi, điểm số, thống kê... giúp xử lí và phân tích dữ liệu nhanh, chính xác.']
 ]);

 /* ===================== LỚP 9 ===================== */
 add(M,9,'Bài 1: Thế giới kĩ thuật số',[
  [1,'Thế giới kĩ thuật số là gì?','Môi trường mà thông tin được số hóa, kết nối qua các thiết bị số và Internet','Thế giới chỉ có giấy bút','Chỉ gồm sách in','Không có máy tính'],
  [1,'Thiết bị nào là thiết bị số phổ biến?','Điện thoại thông minh, máy tính','Bàn tính gảy','Bảng phấn','Que tính'],
  [2,'Đặc điểm nổi bật của thế giới số là gì?','Kết nối toàn cầu, thông tin lan truyền nhanh','Thông tin lan chậm','Không kết nối','Chỉ ở một nơi'],
  [2,'Công nghệ nào góp phần tạo nên thế giới kĩ thuật số?','Internet, điện toán đám mây, trí tuệ nhân tạo','Chỉ máy đánh chữ','Chỉ máy quay đĩa','Không có công nghệ'],
  [2,'Lợi ích của thế giới số đối với học tập là gì?','Học trực tuyến, tra cứu tài nguyên, kết nối toàn cầu','Không có lợi ích','Làm học khó hơn','Chỉ để chơi'],
  [3,'Nêu một số lợi ích và thách thức của thế giới kĩ thuật số.','Lợi ích: kết nối, tra cứu, học tập, làm việc từ xa, tiện lợi. Thách thức: an toàn thông tin, tin giả, nghiện công nghệ, khoảng cách số, quyền riêng tư.'],
  [3,'Kể tên một số công nghệ tiêu biểu của thời đại số.','Internet, điện toán đám mây, dữ liệu lớn, trí tuệ nhân tạo (AI), Internet vạn vật (IoT), mạng di động.'],
  [4,'Vì sao công dân trong thời đại số cần có năng lực số?','Vì mọi hoạt động học tập, làm việc, giao tiếp ngày càng diễn ra trên môi trường số; có năng lực số (biết sử dụng, khai thác, đánh giá thông tin và tự bảo vệ) giúp làm việc hiệu quả, an toàn và thích ứng với xã hội hiện đại.']
 ]);
 add(M,9,'Bài 2: Thông tin trong giải quyết vấn đề',[
  [1,'Trong giải quyết vấn đề, thông tin có vai trò gì?','Là cơ sở để phân tích, ra quyết định đúng','Không quan trọng','Chỉ để trang trí','Làm rối vấn đề'],
  [1,'Bước đầu tiên khi giải quyết một vấn đề là gì?','Thu thập và phân tích thông tin liên quan','Quyết định ngay','Bỏ qua thông tin','Đoán bừa'],
  [2,'Thông tin dùng để ra quyết định cần bảo đảm điều gì?','Chính xác, đầy đủ, kịp thời, đáng tin cậy','Càng nhiều tin đồn càng tốt','Không cần kiểm chứng','Chỉ cần nhanh'],
  [2,'Vì sao cần chọn lọc thông tin khi giải quyết vấn đề?','Để dùng thông tin đúng, tránh bị nhiễu, sai lệch','Để mất thời gian','Vì mọi tin đều đúng','Không cần chọn lọc'],
  [2,'Thông tin sai lệch có thể dẫn đến điều gì khi ra quyết định?','Quyết định sai, hậu quả xấu','Quyết định tốt hơn','Không ảnh hưởng','Luôn đúng'],
  [3,'Nêu vai trò của thông tin trong quá trình giải quyết vấn đề.','Giúp hiểu đúng vấn đề; phân tích nguyên nhân; đưa ra và so sánh các phương án; ra quyết định và kiểm tra kết quả. Thông tin đúng, đủ là cơ sở cho quyết định đúng.'],
  [3,'Nêu các bước xử lí thông tin để giải quyết một vấn đề.','Xác định vấn đề; thu thập thông tin; chọn lọc, đánh giá độ tin cậy; phân tích; đề xuất phương án; quyết định; kiểm tra, đánh giá kết quả.'],
  [4,'Vì sao "có thông tin đúng" chưa đủ mà còn cần biết phân tích, xử lí thông tin?','Vì thông tin thô chỉ là dữ liệu; phải phân tích, sắp xếp, so sánh mới rút ra được ý nghĩa và phương án phù hợp. Biết xử lí thông tin giúp biến dữ liệu thành hiểu biết để ra quyết định đúng.']
 ]);
 add(M,9,'Bài 3: Thực hành: Đánh giá chất lượng thông tin',[
  [1,'Đánh giá chất lượng thông tin là làm gì?','Xem thông tin có chính xác, đáng tin cậy, phù hợp hay không','Xóa thông tin','Chỉ lưu lại','Chia sẻ ngay'],
  [1,'Nguồn thông tin đáng tin cậy thường là nguồn nào?','Cơ quan, tổ chức chính thống, uy tín','Tin đồn','Trang không rõ nguồn gốc','Bình luận ẩn danh'],
  [2,'Dấu hiệu nào cho thấy một thông tin có thể là tin giả?','Giật tít, không nguồn, nội dung vô lí, yêu cầu chia sẻ gấp','Có nguồn rõ ràng','Được kiểm chứng','Từ cơ quan chính thống'],
  [2,'Khi nghi ngờ một thông tin, em nên làm gì?','Đối chiếu nhiều nguồn uy tín trước khi tin và chia sẻ','Chia sẻ ngay','Tin tuyệt đối','Thêm thắt rồi đăng'],
  [2,'Tiêu chí nào KHÔNG dùng để đánh giá chất lượng thông tin?','Số lượt thích nhiều','Nguồn gốc','Tính chính xác','Tính cập nhật'],
  [3,'Nêu các tiêu chí đánh giá chất lượng một thông tin trên mạng.','Nguồn gốc (uy tín); tác giả; tính chính xác; tính khách quan; thời gian cập nhật; đối chiếu nhiều nguồn; mục đích của thông tin.'],
  [3,'Nêu các bước kiểm chứng một thông tin trước khi tin và chia sẻ.','Xem nguồn có uy tín không; tìm thông tin đó ở các nguồn chính thống khác; kiểm tra thời gian, số liệu; cảnh giác với tiêu đề giật gân; chỉ chia sẻ khi đã xác thực.'],
  [4,'Vì sao việc đánh giá chất lượng thông tin ngày càng quan trọng trong thời đại số?','Vì thông tin trên mạng rất nhiều, dễ tạo và lan truyền, lẫn nhiều tin sai, giả, có mục đích xấu. Biết đánh giá chất lượng giúp tránh bị lừa, không lan truyền tin sai, và sử dụng thông tin đúng để học tập, ra quyết định.']
 ]);
 add(M,9,'Bài 4: Một số vấn đề pháp lí về sử dụng dịch vụ Internet',[
  [1,'Hành vi nào là vi phạm pháp luật khi sử dụng Internet?','Tung tin sai sự thật, xâm phạm thông tin cá nhân người khác','Học trực tuyến','Gửi email lịch sự','Tra cứu tài liệu'],
  [1,'Bản quyền (quyền tác giả) trên Internet nghĩa là gì?','Quyền của người tạo ra sản phẩm; người khác không được dùng trái phép','Ai cũng được lấy tùy ý','Chỉ cần ghi tên mình','Không cần quan tâm'],
  [2,'Việc tự ý sao chép, phát tán phần mềm, phim, nhạc có bản quyền là gì?','Vi phạm pháp luật về bản quyền','Hành vi hợp pháp','Việc nên làm','Được khuyến khích'],
  [2,'Khi sử dụng dịch vụ Internet, công dân cần làm gì?','Tuân thủ pháp luật, tôn trọng quyền và lợi ích của người khác','Làm gì tùy thích','Vi phạm cũng không sao','Ẩn danh để phạm luật'],
  [2,'Hành vi nào tôn trọng pháp luật khi dùng Internet?','Dùng phần mềm có bản quyền, không phát tán nội dung cấm','Dùng phần mềm lậu','Phát tán tin giả','Đánh cắp tài khoản'],
  [3,'Nêu một số hành vi vi phạm pháp luật khi sử dụng dịch vụ Internet.','Tung tin giả, bôi nhọ, xúc phạm người khác; xâm phạm thông tin, tài khoản cá nhân; vi phạm bản quyền; phát tán nội dung cấm; lừa đảo trên mạng.'],
  [3,'Vì sao cần tôn trọng bản quyền khi sử dụng sản phẩm số?','Vì sản phẩm số là công sức, tài sản của người tạo ra; dùng trái phép là vi phạm pháp luật, gây thiệt hại cho tác giả và thể hiện sự thiếu trung thực, thiếu văn hóa.'],
  [4,'Vì sao hiểu biết pháp luật về Internet giúp người dùng tự bảo vệ mình?','Hiểu luật giúp biết hành vi nào được phép, hành vi nào vi phạm để tránh; biết quyền của mình (bảo vệ thông tin, khiếu nại khi bị xâm phạm); nhờ đó sử dụng Internet an toàn, đúng luật và tự bảo vệ quyền lợi chính đáng.']
 ]);
 add(M,9,'Bài 5: Tìm hiểu phần mềm mô phỏng',[
  [1,'Phần mềm mô phỏng là gì?','Phần mềm tái hiện lại một hiện tượng, quá trình hay hệ thống thực tế trên máy tính','Phần mềm diệt virus','Phần mềm soạn thảo','Phần mềm nghe nhạc'],
  [1,'Phần mềm mô phỏng thường dùng để làm gì?','Học tập, nghiên cứu, thử nghiệm an toàn trước khi làm thật','Chỉ để chơi','Xóa dữ liệu','Tắt máy'],
  [2,'Ưu điểm của phần mềm mô phỏng trong học tập là gì?','Quan sát trực quan, thử nghiệm nhiều lần, an toàn, tiết kiệm','Nguy hiểm','Tốn kém hơn làm thật','Không trực quan'],
  [2,'Mô phỏng thí nghiệm hóa học trên máy tính giúp gì?','Quan sát phản ứng an toàn, lặp lại nhiều lần, tiết kiệm hóa chất','Gây cháy nổ','Không học được gì','Thay thế hoàn toàn thực hành thật'],
  [2,'Lĩnh vực nào thường dùng phần mềm mô phỏng?','Giáo dục, khoa học, kĩ thuật, y học','Không lĩnh vực nào','Chỉ giải trí','Chỉ nấu ăn'],
  [3,'Nêu lợi ích của phần mềm mô phỏng trong học tập.','Trực quan, dễ hiểu; thử nghiệm nhiều lần an toàn; tiết kiệm chi phí, thời gian; quan sát được hiện tượng khó thấy trong thực tế; hỗ trợ khi thiếu điều kiện thực hành.'],
  [3,'Kể một số ví dụ ứng dụng phần mềm mô phỏng.','Mô phỏng thí nghiệm vật lí, hóa học; mô phỏng chuyển động thiên thể; luyện lái xe, lái máy bay; mô phỏng mạch điện; mô phỏng thiên tai.'],
  [4,'Vì sao mô phỏng không thể thay thế hoàn toàn thực hành, trải nghiệm thực tế?','Mô phỏng tái hiện gần đúng nhưng không hoàn toàn giống thực tế; thiếu cảm nhận, thao tác thật và các yếu tố bất ngờ. Nó hỗ trợ, bổ sung chứ không thay thế hoàn toàn kĩ năng và kinh nghiệm có được từ thực hành thật.']
 ]);
 add(M,9,'Bài 6: Thực hành: Khai thác phần mềm mô phỏng',[
  [1,'Khi khai thác phần mềm mô phỏng, bước đầu nên làm gì?','Tìm hiểu mục đích, cách sử dụng phần mềm','Xóa phần mềm','Tắt máy','Bỏ qua hướng dẫn'],
  [1,'Phần mềm mô phỏng giúp học sinh điều gì?','Quan sát, thử nghiệm và hiểu sâu kiến thức','Không giúp gì','Làm hỏng máy','Chỉ mất thời gian'],
  [2,'Khi mô phỏng, thay đổi các tham số đầu vào giúp gì?','Quan sát kết quả thay đổi, rút ra quy luật','Làm hỏng phần mềm','Không có tác dụng','Xóa dữ liệu'],
  [2,'Sau khi mô phỏng, học sinh nên làm gì?','Ghi nhận, phân tích kết quả và rút ra kết luận','Tắt máy ngay','Bỏ qua kết quả','Xóa phần mềm'],
  [2,'Lợi ích khi lặp lại mô phỏng nhiều lần là gì?','Kiểm chứng, hiểu rõ quy luật, so sánh các trường hợp','Lãng phí','Không cần thiết','Gây lỗi'],
  [3,'Nêu các bước khai thác một phần mềm mô phỏng để học một hiện tượng.','Tìm hiểu mục đích, giao diện phần mềm; thiết lập/thay đổi tham số đầu vào; chạy mô phỏng và quan sát; ghi nhận, phân tích kết quả; rút ra kết luận, nhận xét.'],
  [3,'Vì sao nên thử thay đổi các tham số khi dùng phần mềm mô phỏng?','Để quan sát kết quả thay đổi theo từng trường hợp, từ đó phát hiện quy luật, hiểu sâu mối quan hệ giữa các yếu tố mà không tốn chi phí hay nguy hiểm như làm thật.'],
  [4,'Vì sao phần mềm mô phỏng là công cụ học tập hiệu quả trong nhiều môn học?','Nó giúp trực quan hóa những hiện tượng trừu tượng, khó quan sát; cho phép thử nghiệm an toàn, lặp lại, thay đổi điều kiện; nhờ đó học sinh hiểu bản chất, nhớ lâu và hứng thú hơn so với chỉ học lí thuyết.']
 ]);
 add(M,9,'Bài 7: Trình bày thông tin trong trao đổi và hợp tác',[
  [1,'Trình bày thông tin rõ ràng khi hợp tác giúp ích gì?','Mọi người hiểu đúng, thống nhất và làm việc hiệu quả','Gây hiểu nhầm','Làm mất thời gian','Không cần thiết'],
  [1,'Công cụ nào hỗ trợ trình bày và chia sẻ thông tin khi làm việc nhóm?','Phần mềm trình chiếu, tài liệu trực tuyến, biểu đồ','Chỉ giấy nháp','Không có công cụ','Chỉ nói miệng'],
  [2,'Khi trình bày thông tin cho nhóm, nên chú ý điều gì?','Ngắn gọn, rõ ràng, có hình ảnh/biểu đồ minh họa','Dài dòng, khó hiểu','Nhiều chữ nhỏ','Thiếu cấu trúc'],
  [2,'Lợi ích của tài liệu trực tuyến dùng chung là gì?','Nhiều người cùng xem, chỉnh sửa, cập nhật theo thời gian thực','Chỉ một người xem','Không chia sẻ được','Dễ mất dữ liệu'],
  [2,'Để truyền đạt số liệu hiệu quả khi báo cáo nhóm, nên dùng gì?','Bảng và biểu đồ trực quan','Chỉ đọc số liệu','Nhiều đoạn văn dài','Không minh họa'],
  [3,'Nêu một số công cụ và cách trình bày thông tin khi làm việc nhóm.','Dùng phần mềm trình chiếu, tài liệu/bảng tính trực tuyến dùng chung, sơ đồ tư duy, biểu đồ; trình bày ngắn gọn, có cấu trúc, minh họa trực quan, thống nhất ý kiến.'],
  [3,'Vì sao trình bày thông tin tốt lại giúp hợp tác hiệu quả?','Thông tin rõ ràng, trực quan giúp mọi người hiểu đúng và nhanh, tránh hiểu nhầm, dễ góp ý, thống nhất và phân công công việc; nhờ đó nhóm làm việc ăn ý và hiệu quả hơn.'],
  [4,'Vì sao các công cụ trực tuyến làm thay đổi cách con người trao đổi và hợp tác?','Chúng cho phép nhiều người ở xa cùng xem, chỉnh sửa, thảo luận theo thời gian thực, lưu lịch sử thay đổi; nhờ đó hợp tác không bị giới hạn bởi khoảng cách, thời gian, nhanh và hiệu quả hơn cách truyền thống.']
 ]);
 add(M,9,'Bài 8: Thực hành: Sử dụng công cụ trực quan trình bày thông tin trong trao đổi và hợp tác',[
  [1,'Công cụ trực quan để trình bày thông tin gồm những gì?','Sơ đồ, biểu đồ, bảng, hình ảnh, trình chiếu','Chỉ đoạn văn dài','Chỉ con số rời','Không có'],
  [1,'Sơ đồ tư duy giúp gì khi làm việc nhóm?','Hệ thống ý tưởng, trình bày trực quan, dễ thống nhất','Làm rối ý','Không có tác dụng','Chỉ tốn giấy'],
  [2,'Khi dùng công cụ trực tuyến để hợp tác, lợi ích là gì?','Cùng chỉnh sửa, góp ý, cập nhật tức thời','Chỉ một người làm','Không lưu được','Mất kết nối'],
  [2,'Để báo cáo kết quả nhóm cho cả lớp, nên dùng công cụ nào?','Bài trình chiếu kèm biểu đồ, hình ảnh','Chỉ nói miệng','Chỉ viết tay nhỏ','Không trình bày'],
  [2,'Khi trình bày trực quan, điều quan trọng là gì?','Rõ ràng, nổi bật ý chính, dễ theo dõi','Càng nhiều chi tiết rối càng tốt','Chữ nhỏ, màu mờ','Thiếu tiêu đề'],
  [3,'Nêu các bước sử dụng công cụ trực quan để trình bày kết quả làm việc nhóm.','Thống nhất nội dung; chọn công cụ (trình chiếu, sơ đồ, biểu đồ); tổ chức thông tin theo cấu trúc rõ ràng; minh họa bằng hình ảnh/biểu đồ; kiểm tra và trình bày thử.'],
  [3,'Vì sao công cụ trực quan giúp buổi trao đổi, hợp tác hiệu quả hơn?','Hình ảnh, sơ đồ, biểu đồ giúp truyền đạt ý nhanh, dễ hiểu, dễ nhớ; mọi người cùng nhìn vào một nội dung trực quan nên dễ thảo luận, góp ý và thống nhất.'],
  [4,'Vì sao biết chọn công cụ trình bày phù hợp lại quan trọng khi trao đổi, hợp tác?','Mỗi công cụ hợp với một mục đích (sơ đồ tư duy để hệ thống ý; biểu đồ để thể hiện số liệu; trình chiếu để báo cáo). Chọn đúng công cụ giúp thông tin rõ ràng, thuyết phục, tiết kiệm thời gian và nhóm làm việc hiệu quả hơn.']
 ]);
 add(M,9,'Bài 14: Giải quyết vấn đề',[
  [1,'Giải quyết vấn đề bằng máy tính gồm các bước chính nào?','Xác định bài toán, xây dựng thuật toán, viết và chạy chương trình','Chỉ bật máy','Chỉ gõ phím','Chỉ tắt máy'],
  [1,'Bước xác định bài toán nhằm làm rõ điều gì?','Đầu vào (dữ liệu) và đầu ra (kết quả) cần đạt','Màu màn hình','Tên máy','Giá máy'],
  [2,'Vì sao cần chia một vấn đề lớn thành các vấn đề nhỏ hơn?','Để dễ giải quyết từng phần, đơn giản hơn','Để phức tạp hơn','Để bỏ sót','Không có lí do'],
  [2,'Sau khi có chương trình, cần làm gì để chắc chắn đúng?','Chạy thử với dữ liệu mẫu, kiểm tra kết quả','Không kiểm tra','Xóa luôn','Đổi máy'],
  [2,'Yếu tố nào quan trọng để giải quyết vấn đề hiệu quả bằng máy tính?','Thuật toán đúng và hợp lí','Máy đắt tiền','Màn hình to','Nhiều màu sắc'],
  [3,'Nêu các bước giải quyết một vấn đề bằng máy tính.','Xác định bài toán (đầu vào, đầu ra); xây dựng thuật toán; viết chương trình; chạy thử, gỡ lỗi; đánh giá và hoàn thiện.'],
  [3,'Vì sao "chia nhỏ vấn đề" là cách tiếp cận hiệu quả?','Vấn đề lớn, phức tạp được chia thành các phần nhỏ, đơn giản, dễ giải quyết và kiểm tra từng phần; sau đó ghép lại thành lời giải tổng thể. Cách này giúp dễ làm, dễ sửa lỗi và rõ ràng hơn.'],
  [4,'Vì sao cùng một vấn đề, lựa chọn thuật toán tốt lại quan trọng?','Thuật toán tốt cho lời giải đúng, nhanh, tiết kiệm tài nguyên, dễ hiểu và dễ bảo trì. Với dữ liệu lớn, thuật toán kém có thể chạy rất lâu hoặc không khả thi, trong khi thuật toán tốt giải quyết hiệu quả.']
 ]);
 add(M,9,'Bài 15: Bài toán tin học',[
  [1,'Bài toán tin học thường được mô tả bởi những thành phần nào?','Đầu vào (Input) và đầu ra (Output)','Chỉ tên bài','Chỉ màu sắc','Chỉ tác giả'],
  [1,'Input của bài toán là gì?','Thông tin (dữ liệu) đã cho','Kết quả cần tìm','Tên chương trình','Máy tính'],
  [2,'Output của bài toán là gì?','Kết quả cần tìm từ Input','Dữ liệu đưa vào','Tên biến','Màn hình'],
  [2,'Để giải bài toán tin học, sau khi xác định Input/Output, cần làm gì?','Xây dựng thuật toán rồi viết chương trình','In ngay kết quả','Tắt máy','Bỏ qua thuật toán'],
  [2,'Việc xác định rõ Input và Output giúp ích gì?','Hiểu đúng yêu cầu, xây dựng thuật toán phù hợp','Gây nhầm lẫn','Không cần thiết','Làm chậm'],
  [3,'Xác định Input và Output cho bài toán: Tính trung bình cộng của n số.','Input: số lượng n và n số đã cho. Output: trung bình cộng của n số đó.'],
  [3,'Nêu các bước giải một bài toán tin học.','Xác định Input, Output; xây dựng thuật toán; viết chương trình; chạy thử, gỡ lỗi; kiểm tra với nhiều bộ dữ liệu; hoàn thiện.'],
  [4,'Vì sao việc xác định đúng Input và Output là bước quan trọng đầu tiên khi giải bài toán tin học?','Vì nó làm rõ "cho gì, cần tìm gì"; hiểu đúng yêu cầu mới xây dựng được thuật toán và chương trình đúng. Xác định sai Input/Output sẽ dẫn đến giải sai bài toán dù chương trình chạy tốt.']
 ]);
 add(M,9,'Bài 16: Thực hành: Lập chương trình máy tính',[
  [1,'Lập chương trình máy tính là gì?','Viết các lệnh bằng ngôn ngữ lập trình để máy thực hiện thuật toán','Vẽ tranh','Soạn nhạc','Tắt máy'],
  [1,'Trước khi lập trình, cần có gì?','Thuật toán giải bài toán','Không cần gì','Chỉ cần máy đắt','Chỉ cần mạng nhanh'],
  [2,'Sau khi viết xong chương trình, bước tiếp theo là gì?','Chạy thử và gỡ lỗi','Tắt máy ngay','Xóa chương trình','Đổi tên tệp'],
  [2,'Để chương trình nhận dữ liệu từ người dùng, cần dùng lệnh gì?','Lệnh nhập (input)','Lệnh xóa','Lệnh tắt máy','Lệnh in hình'],
  [2,'Để chương trình đưa kết quả ra màn hình, dùng lệnh gì?','Lệnh xuất/in (output)','Lệnh nhập','Lệnh xóa','Lệnh lưu'],
  [3,'Nêu các bước lập một chương trình giải bài toán đơn giản (VD tính tổng hai số).','Xác định Input (a, b), Output (tổng); xây dựng thuật toán; viết chương trình (nhập a, b; tính tổng; in kết quả); chạy thử, gỡ lỗi; hoàn thiện.'],
  [3,'Vì sao cần chạy thử chương trình với nhiều bộ dữ liệu khác nhau?','Để kiểm tra chương trình chạy đúng trong nhiều trường hợp (số dương, âm, bằng 0, dữ liệu lớn...), phát hiện lỗi tiềm ẩn, bảo đảm chương trình đáng tin cậy.'],
  [4,'Vì sao lập trình giúp rèn luyện tư duy logic và khả năng giải quyết vấn đề?','Lập trình đòi hỏi phân tích bài toán, chia nhỏ, sắp xếp các bước logic, dự đoán và xử lí tình huống, tìm và sửa lỗi. Quá trình đó rèn tư duy mạch lạc, chặt chẽ và kĩ năng giải quyết vấn đề có hệ thống.']
 ]);
 add(M,9,'Bài 17: Tin học và thế giới nghề nghiệp',[
  [1,'Tin học ảnh hưởng đến nghề nghiệp hiện nay như thế nào?','Có mặt và hỗ trợ hầu hết các ngành nghề','Không ảnh hưởng','Chỉ một nghề','Làm mất việc làm hoàn toàn'],
  [1,'Nghề nào thuộc lĩnh vực công nghệ thông tin?','Lập trình viên, chuyên gia an toàn thông tin, phân tích dữ liệu','Chỉ nông dân','Chỉ thợ xây','Không có'],
  [2,'Để thành công trong nghề liên quan tin học, cần rèn luyện gì?','Kiến thức, tư duy logic, kĩ năng tự học và công nghệ','Chỉ chơi game','Không cần học','Chỉ cần máy mạnh'],
  [2,'Xu hướng nghề nghiệp trong thời đại số là gì?','Nhiều nghề mới về công nghệ, dữ liệu, AI; yêu cầu năng lực số','Không thay đổi','Giảm dùng công nghệ','Bỏ máy tính'],
  [2,'Năng lực số cần thiết cho hầu hết nghề nghiệp là gì?','Biết sử dụng máy tính, phần mềm, khai thác và bảo vệ thông tin','Không cần thiết','Chỉ cho lập trình viên','Chỉ để giải trí'],
  [3,'Kể một số ngành nghề mới xuất hiện nhờ sự phát triển của tin học.','Phát triển phần mềm/ứng dụng, phân tích dữ liệu lớn, trí tuệ nhân tạo, an toàn thông tin, thương mại điện tử, sáng tạo nội dung số, quản trị mạng xã hội.'],
  [3,'Là học sinh, em cần chuẩn bị gì cho nghề nghiệp trong thời đại số?','Học tốt tin học và các môn nền tảng; rèn tư duy, kĩ năng tự học, ngoại ngữ; tìm hiểu nghề nghiệp, công nghệ mới; rèn đạo đức và năng lực số.'],
  [4,'Vì sao trong thời đại số, "học cách tự học" và thích ứng công nghệ lại quan trọng với nghề nghiệp?','Vì công nghệ thay đổi rất nhanh, kiến thức dễ lạc hậu; biết tự học và thích ứng giúp cập nhật kĩ năng mới, không bị tụt hậu, nắm bắt cơ hội nghề nghiệp và làm việc hiệu quả trong môi trường luôn đổi mới.']
 ]);
 /* Chủ đề tổng hợp L9 */
 add(M,9,'Mạng và ứng dụng, đạo đức số',[
  [1,'Hành vi nào vi phạm pháp luật khi dùng Internet?','Tung tin giả, xâm phạm thông tin cá nhân người khác','Học trực tuyến','Tra cứu tài liệu','Gửi email lịch sự'],
  [2,'Tôn trọng bản quyền số nghĩa là gì?','Không sao chép, phát tán, dùng trái phép sản phẩm của người khác','Lấy dùng tùy ý','Xóa tên tác giả','Bán lại kiếm lời'],
  [2,'Thế giới kĩ thuật số có đặc điểm nổi bật nào?','Kết nối toàn cầu, thông tin lan truyền nhanh','Không kết nối','Lan truyền chậm','Chỉ ở một nơi'],
  [3,'Nêu một số quy tắc đạo đức và pháp lí khi sử dụng Internet.','Tôn trọng người khác và quyền riêng tư; không tung tin giả, bôi nhọ; tôn trọng bản quyền; bảo vệ thông tin cá nhân; tuân thủ pháp luật.'],
  [4,'Vì sao công dân số cần có cả năng lực số và ý thức đạo đức, pháp luật?','Năng lực số giúp sử dụng, khai thác công nghệ hiệu quả, an toàn; ý thức đạo đức, pháp luật giúp hành xử đúng, tôn trọng người khác, không vi phạm. Có cả hai mới trở thành công dân số có trách nhiệm trong môi trường kết nối toàn cầu.']
 ]);
 add(M,9,'Giải quyết vấn đề với máy tính',[
  [1,'Bài toán tin học được mô tả bởi gì?','Đầu vào (Input) và đầu ra (Output)','Chỉ tên bài','Chỉ màu sắc','Chỉ giá máy'],
  [2,'Bước đầu tiên để giải quyết vấn đề bằng máy tính là gì?','Xác định bài toán (Input, Output)','Viết chương trình ngay','Tắt máy','In kết quả'],
  [2,'Vì sao nên chia nhỏ vấn đề lớn?','Để dễ giải quyết từng phần','Để phức tạp hơn','Để bỏ sót','Không có lí do'],
  [3,'Nêu các bước giải quyết một vấn đề bằng máy tính.','Xác định bài toán (Input/Output); xây dựng thuật toán; viết chương trình; chạy thử, gỡ lỗi; đánh giá, hoàn thiện.'],
  [4,'Vì sao thuật toán đúng và hiệu quả là yếu tố then chốt khi giải quyết vấn đề bằng máy tính?','Thuật toán là cách giải; thuật toán đúng mới cho kết quả đúng, hiệu quả (nhanh, tiết kiệm tài nguyên) giúp xử lí được dữ liệu lớn. Chương trình chỉ là cách viết thuật toán cho máy, nên chất lượng phụ thuộc vào thuật toán.']
 ]);
 add(M,9,'Thuật toán, lập trình và dữ liệu',[
  [1,'Biến trong chương trình dùng để làm gì?','Lưu trữ dữ liệu có thể thay đổi','Tắt máy','Trang trí','Xóa dữ liệu'],
  [2,'Cấu trúc nào dùng để lặp lại công việc nhiều lần?','Cấu trúc lặp','Rẽ nhánh một lần','Tuần tự thuần','Không có'],
  [2,'Gỡ lỗi chương trình là làm gì?','Tìm và sửa lỗi để chương trình chạy đúng','Xóa chương trình','Tắt máy','Đổi tên'],
  [3,'Nêu ba cấu trúc điều khiển cơ bản trong lập trình và vai trò.','Tuần tự (lần lượt), rẽ nhánh (chọn theo điều kiện), lặp (lặp lại nhiều lần). Kết hợp để diễn đạt mọi thuật toán.'],
  [4,'Vì sao hiểu về thuật toán và dữ liệu giúp viết chương trình tốt hơn?','Thuật toán quyết định cách giải đúng và hiệu quả; hiểu dữ liệu (kiểu, cách tổ chức) giúp lưu và xử lí phù hợp, tránh lỗi. Nắm chắc cả hai giúp chương trình đúng, nhanh, dễ đọc và dễ bảo trì.']
 ]);

 /* -------- L8 + L9: bù lẻ chủ đề tổng hợp -------- */
 add(M,8,'Sơ đồ, biểu đồ, xử lí dữ liệu',[
  [1,'Sắp xếp dữ liệu (Sort) là gì?','Xếp dữ liệu theo thứ tự tăng hoặc giảm','Xóa dữ liệu','Tính tổng','Thêm cột'],
  [3,'Nêu các bước tạo một biểu đồ từ dữ liệu bảng tính.','Chọn vùng dữ liệu; chọn Chèn biểu đồ; chọn loại phù hợp (cột, đường, quạt); thêm tiêu đề, chú thích; chỉnh sửa cho rõ.']
 ]);
 add(M,8,'Thuật toán, lập trình trực quan',[
  [1,'Lỗi lô-gic là lỗi như thế nào?','Chương trình chạy được nhưng cho kết quả sai','Sai quy tắc viết lệnh','Do hỏng phần cứng','Do mất điện'],
  [3,'Mô tả thuật toán có rẽ nhánh: xếp loại Đạt nếu điểm ≥ 5.','Nhập điểm; nếu điểm ≥ 5 thì in "Đạt", ngược lại in "Chưa đạt". Kết thúc.']
 ]);
 add(M,8,'Bảng tính và xử lí dữ liệu',[
  [3,'Nêu lợi ích của việc sắp xếp và lọc dữ liệu trong bảng tính.','Sắp xếp giúp xem dữ liệu theo thứ tự (xếp hạng); lọc giúp chỉ hiển thị nhóm cần quan tâm; nhờ đó tra cứu, phân tích nhanh và chính xác.']
 ]);
 add(M,9,'Mạng và ứng dụng, đạo đức số',[
  [1,'Phần mềm mô phỏng dùng để làm gì?','Tái hiện hiện tượng, quá trình thực tế để học tập, thử nghiệm an toàn','Diệt virus','Soạn thảo','Nghe nhạc'],
  [3,'Nêu một số lợi ích của thế giới kĩ thuật số đối với học tập và cuộc sống.','Học trực tuyến, tra cứu tài nguyên, kết nối toàn cầu, làm việc từ xa, tiện lợi trong giao dịch, giải trí; giúp tiếp cận tri thức nhanh và rộng.']
 ]);
 add(M,9,'Giải quyết vấn đề với máy tính',[
  [1,'Input và Output của bài toán tin học lần lượt là gì?','Dữ liệu đã cho và kết quả cần tìm','Tên và giá máy','Màu và cỡ chữ','Hai loại virus'],
  [3,'Xác định Input và Output cho bài toán tính chu vi hình chữ nhật.','Input: chiều dài và chiều rộng. Output: chu vi = (dài + rộng) × 2.']
 ]);
 add(M,9,'Thuật toán, lập trình và dữ liệu',[
  [3,'Nêu các bước lập một chương trình giải bài toán đơn giản.','Xác định Input, Output; xây dựng thuật toán; viết chương trình (nhập, xử lí, xuất); chạy thử, gỡ lỗi; kiểm tra với nhiều dữ liệu; hoàn thiện.']
 ]);

})();
