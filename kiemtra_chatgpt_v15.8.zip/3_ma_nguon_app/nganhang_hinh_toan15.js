/* NGÂN HÀNG TOÁN – LỚP 1–5 — câu hỏi CÓ HÌNH MINH HỌA (mã @img). Câu hỏi nguyên bản, bám SGK Kết nối tri thức. */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Toán';
 /* ================= LỚP 1 ================= */
 add(M,1,'★ Nâng cao: Các số từ 0 đến 10',[
  [1,'Có bao nhiêu quả táo trong hình?','7','6','8','5','@img:dem:tao:7'],
  [1,'Đếm số bông hoa trong hình.','5','4','6','3','@img:dem:hoa:5'],
  [1,'Trong hình có mấy ngôi sao?','9','8','10','7','@img:dem:sao:9'],
  [1,'Có bao nhiêu con cá trong hình?','4','3','5','6','@img:dem:ca:4'],
  [1,'Trong hình có mấy chiếc bút?','6','5','7','8','@img:dem:but:6'],
  [1,'Có bao nhiêu con bướm trong hình?','10','9','8','7','@img:dem:buom:10'],
  [1,'Đếm số quả trứng trong hình.','3','2','4','5','@img:dem:trung:3'],
  [2,'Hình vẽ hai nhóm quả cam (nhóm trên và nhóm dưới). Nhóm nào có nhiều quả cam hơn?','Nhóm dưới','Nhóm trên','Hai nhóm bằng nhau','Không so sánh được','@img:dem:cam:4:6'],
  [2,'Hình vẽ hai nhóm ngôi sao. So sánh số sao ở nhóm trên với số sao ở nhóm dưới.','8 > 5','8 < 5','8 = 5','5 > 8','@img:dem:sao:8:5'],
  [2,'Hình vẽ hai nhóm chiếc lá. Số lá ở nhóm trên và nhóm dưới như thế nào?','Bằng nhau','Nhóm trên nhiều hơn','Nhóm dưới nhiều hơn','Nhóm trên ít hơn 1 chiếc','@img:dem:la:6:6'],
  [1,'Trên tia số, điểm được tô đỏ ứng với số nào?','4','3','5','6','@img:truc:0:10:4'],
  [2,'Trên tia số, hai điểm được tô đỏ ứng với hai số nào?','2 và 9','2 và 8','3 và 9','1 và 9','@img:truc:0:10:2,9'],
  [2,'Trên tia số, số liền sau của số được tô đỏ là số nào?','8','6','9','5','@img:truc:0:10:7'],
  [2,'Có bao nhiêu chiếc ô tô trong hình? Số đó đứng liền sau số nào?','3; liền sau số 2','3; liền sau số 4','2; liền sau số 1','4; liền sau số 3','@img:dem:xe:3'],
  [3,'Đếm số bóng trong hình rồi viết số liền trước và số liền sau của số đó.','Có 8 quả bóng. Số liền trước là 7, số liền sau là 9.','@img:dem:bong:8'],
  [3,'Hình vẽ hai nhóm kẹo. Đếm số kẹo mỗi nhóm rồi viết phép so sánh.','Nhóm trên có 7 chiếc kẹo, nhóm dưới có 9 chiếc kẹo. 7 < 9 (hoặc 9 > 7).','@img:dem:keo:7:9'],
  [4,'Trên tia số, điểm được tô đỏ ứng với số nào? Hãy kể tất cả các số lớn hơn số đó nhưng bé hơn 10 và giải thích cách tìm.','Điểm đỏ ứng với số 6. Các số lớn hơn 6 và bé hơn 10 là 7, 8, 9. Trên tia số, các số này nằm bên phải số 6 và bên trái số 10, vì số càng đứng bên phải càng lớn.','@img:truc:0:10:6']
 ]);
 add(M,1,'★ Nâng cao: Làm quen với một số hình phẳng',[
  [1,'Hình trong hình vẽ là hình gì?','Hình vuông','Hình tròn','Hình tam giác','Hình chữ nhật','@img:vuong:3'],
  [1,'Em hãy gọi tên hình trong hình vẽ.','Hình tròn','Hình vuông','Hình tam giác','Hình chữ nhật','@img:tron:4'],
  [1,'Hình vẽ cho thấy hình gì?','Hình tam giác','Hình vuông','Hình tròn','Hình chữ nhật','@img:tamgiac:5:3'],
  [1,'Hình bên là hình gì?','Hình chữ nhật','Hình vuông','Hình tam giác','Hình tròn','@img:hcn:5:3'],
  [2,'Hình trong hình vẽ có mấy cạnh?','3 cạnh','4 cạnh','2 cạnh','5 cạnh','@img:tgl:A:B:C'],
  [2,'Hình trong hình vẽ có mấy đỉnh?','4 đỉnh','3 đỉnh','5 đỉnh','6 đỉnh','@img:vuong:2'],
  [2,'Hình trong hình vẽ có cạnh thẳng và đỉnh không?','Không, hình tròn không có cạnh thẳng và không có đỉnh','Có 4 cạnh và 4 đỉnh','Có 3 cạnh và 3 đỉnh','Có 1 cạnh và 1 đỉnh','@img:tron:5'],
  [3,'Nhìn hình vẽ, em hãy gọi tên hình và cho biết hình đó có mấy cạnh.','Hình chữ nhật, có 4 cạnh.','@img:hcn:6:3'],
  [4,'Hình trong hình vẽ là hình gì? Hình này khác hình tròn ở điểm nào?','Đó là hình tam giác. Hình tam giác có 3 cạnh thẳng và 3 đỉnh, còn hình tròn không có cạnh thẳng và không có đỉnh.','@img:tamgiac:6:4']
 ]);
 add(M,1,'★ Nâng cao: Phép cộng, phép trừ trong phạm vi 10',[
  [1,'Nhóm trên có một số quả táo, nhóm dưới có thêm một số quả táo nữa. Có tất cả bao nhiêu quả táo?','7','6','8','5','@img:dem:tao:3:4'],
  [1,'Hình vẽ hai nhóm cá. Phép cộng nào phù hợp với hình?','5 + 2 = 7','5 + 3 = 8','4 + 2 = 6','5 - 2 = 3','@img:dem:ca:5:2'],
  [1,'Đếm số bông hoa ở mỗi nhóm rồi tìm tổng số hoa.','9','8','10','7','@img:dem:hoa:4:5'],
  [1,'Hình vẽ hai nhóm que tính. Có tất cả bao nhiêu que tính?','8','7','9','6','@img:dem:que:5:3'],
  [2,'Hình vẽ hai nhóm ngôi sao. Phép tính nào đúng với hình?','6 + 3 = 9','6 + 2 = 8','3 + 3 = 6','6 - 3 = 3','@img:dem:sao:6:3'],
  [2,'Có một số quả cam ở nhóm trên. Nếu lấy đi số cam bằng số cam ở nhóm dưới thì nhóm trên còn lại mấy quả?','5','4','6','3','@img:dem:cam:8:3'],
  [2,'Hình vẽ hai nhóm bóng. Số bóng nhóm trên nhiều hơn số bóng nhóm dưới bao nhiêu quả?','3','2','4','1','@img:dem:bong:7:4'],
  [2,'Hình vẽ hai nhóm con chim. Tổng số chim ở hai nhóm là bao nhiêu?','10','9','8','11','@img:dem:chim:6:4'],
  [2,'Hình vẽ hai nhóm chiếc bút. Phép trừ nào phù hợp với hình (số bút nhóm trên trừ số bút nhóm dưới)?','9 - 5 = 4','9 - 4 = 5','5 - 4 = 1','9 + 5 = 14','@img:dem:but:9:5'],
  [3,'Đếm số kẹo ở mỗi nhóm trong hình, viết phép cộng và tính kết quả.','Nhóm trên có 3 chiếc kẹo, nhóm dưới có 6 chiếc kẹo. Phép cộng: 3 + 6 = 9 (hoặc 6 + 3 = 9).','@img:dem:keo:3:6'],
  [3,'Nhìn hình vẽ hai nhóm quả trứng, hãy viết một phép trừ phù hợp và tính kết quả.','Nhóm trên có 10 quả trứng, nhóm dưới có 4 quả trứng. Phép trừ: 10 - 4 = 6 (hoặc 10 - 6 = 4).','@img:dem:trung:10:4'],
  [3,'Trong hình có một số con bướm. Nếu bay đi 4 con thì còn lại mấy con? Viết phép tính.','Có 9 con bướm. 9 - 4 = 5. Còn lại 5 con bướm.','@img:dem:buom:9'],
  [4,'Hình vẽ hai nhóm chiếc lá. Em hãy viết hai phép cộng và hai phép trừ từ các số trong hình, rồi giải thích vì sao các phép tính đó liên quan với nhau.','Nhóm trên có 2 lá, nhóm dưới có 7 lá, tổng là 9 lá. Hai phép cộng: 2 + 7 = 9 và 7 + 2 = 9. Hai phép trừ: 9 - 2 = 7 và 9 - 7 = 2. Các phép tính liên quan với nhau vì cùng ba số 2, 7, 9: tổng trừ đi một số hạng thì được số hạng kia.','@img:dem:la:2:7']
 ]);
 add(M,1,'★ Nâng cao: Làm quen với một số hình khối',[
  [1,'Hình vẽ cho thấy khối gì?','Khối lập phương','Khối hộp chữ nhật','Khối cầu','Khối trụ','@img:hinh3d:lapphuong'],
  [1,'Em hãy gọi tên khối trong hình vẽ.','Khối hộp chữ nhật','Khối lập phương','Khối trụ','Khối cầu','@img:hinh3d:hophcn'],
  [2,'Có bao nhiêu khối lập phương nhỏ trong hình?','6','5','7','8','@img:dem:khoi:6'],
  [3,'Đếm số khối lập phương trong hình. Nếu xếp thêm 3 khối nữa thì có tất cả bao nhiêu khối?','Có 7 khối lập phương. 7 + 3 = 10 khối.','@img:dem:khoi:7'],
  [4,'Khối trong hình vẽ là khối gì? Nêu điểm khác nhau giữa khối này và khối lập phương.','Đó là khối hộp chữ nhật. Khối hộp chữ nhật có các mặt là hình chữ nhật (có mặt dài, mặt ngắn), còn khối lập phương có tất cả các mặt đều là hình vuông bằng nhau.','@img:hinh3d:hophcn']
 ]);
 add(M,1,'★ Nâng cao: Thời gian, giờ và lịch',[
  [1,'Đồng hồ trong hình chỉ mấy giờ?','3 giờ','12 giờ','9 giờ','6 giờ','@img:dongho:3:0'],
  [1,'Đồng hồ chỉ mấy giờ?','7 giờ','8 giờ','6 giờ','12 giờ','@img:dongho:7:0'],
  [1,'Em hãy đọc giờ trên đồng hồ trong hình.','10 giờ','2 giờ','11 giờ','9 giờ','@img:dongho:10:0'],
  [2,'Bây giờ là mấy giờ theo đồng hồ trong hình?','1 giờ','12 giờ','2 giờ','11 giờ','@img:dongho:1:0'],
  [2,'Đồng hồ trong hình chỉ mấy giờ? Kim ngắn đang chỉ vào số nào?','5 giờ; kim ngắn chỉ số 5','12 giờ; kim ngắn chỉ số 12','6 giờ; kim ngắn chỉ số 6','5 giờ; kim ngắn chỉ số 12','@img:dongho:5:0'],
  [3,'Đồng hồ trong hình chỉ mấy giờ? Sau 2 giờ nữa đồng hồ sẽ chỉ mấy giờ?','Đồng hồ chỉ 9 giờ. Sau 2 giờ nữa đồng hồ chỉ 11 giờ.','@img:dongho:9:0'],
  [4,'Quan sát đồng hồ trong hình. Vì sao em biết đồng hồ chỉ giờ đúng và đó là mấy giờ?','Kim dài chỉ đúng số 12 nên đây là giờ đúng. Kim ngắn chỉ số 4 nên đồng hồ chỉ 4 giờ.','@img:dongho:4:0']
 ]);
 add(M,1,'★ Nâng cao: Độ dài và đo độ dài',[
  [1,'Đoạn thẳng màu xanh trong hình dài bao nhiêu xăng-ti-mét?','6 cm','5 cm','7 cm','10 cm','@img:thuoc:6'],
  [2,'Dùng thước đo, đoạn thẳng màu xanh dài mấy xăng-ti-mét?','3 cm','2 cm','4 cm','30 cm','@img:thuoc:3'],
  [3,'Đo đoạn thẳng màu xanh trong hình và cho biết nó ngắn hơn 10 cm bao nhiêu xăng-ti-mét.','Đoạn thẳng dài 8 cm. 10 - 8 = 2, nên đoạn thẳng ngắn hơn 10 cm là 2 cm.','@img:thuoc:8'],
  [4,'Đoạn thẳng màu xanh dài bao nhiêu xăng-ti-mét? Khi đo, vì sao phải đặt một đầu đoạn thẳng trùng với vạch số 0 của thước?','Đoạn thẳng dài 5 cm. Phải đặt một đầu trùng với vạch 0 vì khi đó số ghi ở đầu kia của đoạn thẳng chính là độ dài; nếu đặt lệch, số đọc được sẽ không đúng độ dài thật.','@img:thuoc:5']
 ]);
 add(M,1,'Hình học và đo lường',[
  [1,'Hình trong hình vẽ có mấy cạnh và là hình gì?','4 cạnh, hình vuông','3 cạnh, hình tam giác','4 cạnh, hình tròn','0 cạnh, hình tròn','@img:vuong:5'],
  [2,'Đoạn thẳng màu xanh trong hình dài bao nhiêu?','4 cm','3 cm','5 cm','40 cm','@img:thuoc:4'],
  [3,'Nhìn hình, kể tên hình và cho biết hình có mấy đỉnh.','Hình tam giác, có 3 đỉnh.','@img:tgl:M:N:P']
 ]);
 add(M,1,'★ Nâng cao: Các số đến 100',[
  [1,'Trên tia số, điểm được tô đỏ ứng với số nào?','24','23','25','34','@img:truc:20:30:24'],
  [2,'Hình vẽ hai nhóm que tính. Có tất cả bao nhiêu que tính?','18','17','19','16','@img:dem:que:10:8'],
  [3,'Trên tia số, hai điểm được tô đỏ ứng với hai số nào? Số nào lớn hơn?','Hai điểm đỏ ứng với 42 và 47. Số 47 lớn hơn 42.','@img:truc:40:50:42,47']
 ]);
 add(M,1,'★ Nâng cao: Phép cộng, phép trừ (không nhớ) trong phạm vi 100',[
  [2,'Nhóm trên có một số que tính, nhóm dưới có thêm một số que tính. Phép cộng nào đúng với hình?','10 + 5 = 15','10 + 4 = 14','10 + 6 = 16','10 - 5 = 5','@img:dem:que:10:5'],
  [3,'Trên tia số, điểm đỏ ứng với số nào? Tính số đó cộng với 3 và trừ đi 3.','Điểm đỏ ứng với số 65. 65 + 3 = 68; 65 - 3 = 62.','@img:truc:60:70:65']
 ]);
 add(M,1,'★ Nâng cao: Ôn tập học kì 1',[
  [2,'Hình vẽ hai nhóm quả cam. Phép tính nào đúng với hình?','4 + 4 = 8','4 + 3 = 7','4 + 5 = 9','8 - 4 = 0','@img:dem:cam:4:4'],
  [3,'Đồng hồ trong hình chỉ mấy giờ? Kim dài và kim ngắn đang chỉ số nào?','Đồng hồ chỉ 8 giờ. Kim dài chỉ số 12, kim ngắn chỉ số 8.','@img:dongho:8:0']
 ]);
 add(M,1,'★ Nâng cao: Ôn tập cuối năm',[
  [2,'Đoạn thẳng màu xanh dài bao nhiêu xăng-ti-mét?','7 cm','6 cm','8 cm','70 cm','@img:thuoc:7'],
  [3,'Có bao nhiêu cái nấm trong hình? Nếu hái đi 2 cái thì còn mấy cái? Viết phép tính.','Có 6 cái nấm. 6 - 2 = 4. Còn lại 4 cái nấm.','@img:dem:nam:6'],
  [4,'Trên tia số, hai điểm đỏ ứng với hai số nào? Tính hiệu của số lớn và số bé rồi giải thích cách tính bằng tia số.','Hai điểm đỏ ứng với 3 và 8. Hiệu: 8 - 3 = 5. Trên tia số, từ 3 đếm sang phải 5 vạch thì đến 8, nên 8 - 3 = 5.','@img:truc:0:10:3,8']
 ]);
 /* ================= LỚP 2 ================= */
 add(M,2,'★ Nâng cao: Ôn tập và bổ sung',[
  [1,'Có bao nhiêu ngôi sao trong hình?','15','14','16','13','@img:dem:sao:15'],
  [1,'Đếm số que tính trong hình.','18','17','19','20','@img:dem:que:18'],
  [2,'Trên tia số, điểm đỏ ứng với số nào?','17','16','18','7','@img:truc:10:20:17'],
  [2,'Hình vẽ hai nhóm quả táo. Tổng số táo ở hai nhóm là bao nhiêu?','16','15','17','14','@img:dem:tao:10:6'],
  [3,'Đếm số chiếc kẹo trong hình. Số đó gồm mấy chục và mấy đơn vị?','Có 14 chiếc kẹo. Số 14 gồm 1 chục và 4 đơn vị.','@img:dem:keo:14']
 ]);
 add(M,2,'★ Nâng cao: Phép cộng, phép trừ trong phạm vi 20',[
  [1,'Hình vẽ hai nhóm con cá. Phép cộng nào đúng với hình?','9 + 4 = 13','9 + 3 = 12','9 + 5 = 14','9 - 4 = 5','@img:dem:ca:9:4'],
  [2,'Hình vẽ hai nhóm quả cam. Có tất cả bao nhiêu quả cam?','15','14','16','13','@img:dem:cam:8:7'],
  [2,'Nhóm trên có một số bông hoa, nhóm dưới có ít hơn. Số hoa nhóm trên nhiều hơn số hoa nhóm dưới bao nhiêu bông?','6','5','7','4','@img:dem:hoa:12:6'],
  [2,'Hình vẽ hai nhóm bóng. Phép trừ nào phù hợp với hình (số bóng nhóm trên trừ số bóng nhóm dưới)?','14 - 5 = 9','14 - 4 = 10','14 - 6 = 8','9 - 5 = 4','@img:dem:bong:14:5'],
  [3,'Đếm số con chim ở mỗi nhóm trong hình, viết phép cộng có nhớ tương ứng và nêu cách tính.','Nhóm trên 7 con, nhóm dưới 8 con. 7 + 8 = 15. Cách tính: tách 8 = 3 + 5, lấy 7 + 3 = 10, rồi 10 + 5 = 15.','@img:dem:chim:7:8'],
  [3,'Trong hình có một số quả trứng. Nếu dùng 9 quả để làm bánh thì còn lại bao nhiêu quả? Viết phép tính.','Có 16 quả trứng. 16 - 9 = 7. Còn lại 7 quả trứng.','@img:dem:trung:16'],
  [4,'Hình vẽ hai nhóm chiếc bút. Hãy viết tất cả các phép cộng, phép trừ có thể lập được từ ba số (số bút nhóm trên, số bút nhóm dưới, tổng) và giải thích mối quan hệ giữa chúng.','Nhóm trên 6 bút, nhóm dưới 9 bút, tổng 15. Các phép tính: 6 + 9 = 15; 9 + 6 = 15; 15 - 6 = 9; 15 - 9 = 6. Phép trừ là phép tính ngược của phép cộng: lấy tổng trừ đi số hạng này thì được số hạng kia.','@img:dem:but:6:9']
 ]);
 add(M,2,'★ Nâng cao: Phép cộng, phép trừ (có nhớ) trong phạm vi 100',[
  [2,'Dựa vào bảng, tổng số điểm của Lan và Hà là bao nhiêu?','65','55','64','11','@img:bang:Bạn;Số điểm|Lan;38|Hà;27'],
  [2,'Theo bảng, số bông hoa của Mai nhiều hơn số hoa của Bình bao nhiêu bông?','18','17','28','16','@img:bang:Bạn;Số bông hoa|Mai;45|Bình;27'],
  [3,'Bảng cho biết số sách của ba bạn. Tính tổng số sách của Nam và Hoa; tính số sách Nam nhiều hơn Hoa.','Nam 36 quyển, Hoa 29 quyển. Tổng: 36 + 29 = 65 (quyển). Nam nhiều hơn Hoa: 36 - 29 = 7 (quyển).','@img:bang:Bạn;Số sách|Nam;36|Hoa;29|Tú;18'],
  [4,'Bảng ghi số kg giấy vụn ba lớp thu được. Lớp nào thu được nhiều nhất? Cả ba lớp thu được bao nhiêu kg? Nêu cách tính nhanh.','Lớp 2B thu nhiều nhất (47 kg). Tổng: 25 + 47 + 35 = 107 (kg); cách tính nhanh: 25 + 35 = 60 trước, rồi 60 + 47 = 107.','@img:bang:Lớp;Số kg giấy|2A;25|2B;47|2C;35']
 ]);
 add(M,2,'★ Nâng cao: Làm quen với hình phẳng',[
  [1,'Hình trong hình vẽ là hình gì?','Hình tứ giác','Hình tam giác','Hình tròn','Đường gấp khúc','@img:thoi:4'],
  [1,'Hình bên có mấy cạnh?','4 cạnh','3 cạnh','5 cạnh','6 cạnh','@img:hbh:5:3'],
  [2,'Đoạn thẳng màu xanh trong hình dài bao nhiêu xăng-ti-mét?','9 cm','8 cm','10 cm','90 cm','@img:thuoc:9'],
  [2,'Hình vẽ có mấy đỉnh và là hình gì?','4 đỉnh, hình tứ giác','3 đỉnh, hình tam giác','4 đỉnh, hình tam giác','5 đỉnh, hình tứ giác','@img:thang:8:5:4'],
  [3,'Nhìn hình vẽ, gọi tên hình và kể tên các đỉnh, các cạnh của hình.','Hình tam giác ABC. Ba đỉnh: A, B, C. Ba cạnh: AB, BC, CA.','@img:tgl:A:B:C'],
  [4,'Hình trong hình vẽ là hình tứ giác hay hình tam giác? Giải thích dựa vào số cạnh, số đỉnh.','Là hình tứ giác vì hình có 4 cạnh và 4 đỉnh; hình tam giác chỉ có 3 cạnh và 3 đỉnh.','@img:hcn:6:4']
 ]);
 add(M,2,'★ Nâng cao: Ngày – giờ, giờ – phút, ngày – tháng',[
  [1,'Đồng hồ trong hình chỉ mấy giờ?','2 giờ 30 phút','2 giờ','3 giờ 30 phút','6 giờ 10 phút','@img:dongho:2:30'],
  [1,'Đồng hồ chỉ mấy giờ?','8 giờ 15 phút','3 giờ 40 phút','8 giờ 30 phút','9 giờ 15 phút','@img:dongho:8:15'],
  [2,'Đồng hồ trong hình chỉ mấy giờ? (Cách đọc khác của giờ này là gì?)','6 giờ 30 phút (6 giờ rưỡi)','6 giờ (6 giờ đúng)','7 giờ 30 phút (7 giờ rưỡi)','6 giờ 6 phút','@img:dongho:6:30'],
  [2,'Buổi chiều, đồng hồ trong hình chỉ mấy giờ? (đọc theo cách 24 giờ)','15 giờ','3 giờ','13 giờ','17 giờ','@img:dongho:3:0'],
  [3,'Đồng hồ trong hình chỉ mấy giờ? Nếu đó là buổi tối thì đọc theo cách 24 giờ là mấy giờ?','Đồng hồ chỉ 9 giờ 30 phút. Buổi tối là 21 giờ 30 phút.','@img:dongho:9:30'],
  [3,'Đọc giờ trên đồng hồ trong hình. Kim phút chỉ số mấy và vì sao đọc là 15 phút?','Đồng hồ chỉ 11 giờ 15 phút. Kim phút chỉ số 3; từ số 12 đến số 3 có 3 khoảng, mỗi khoảng 5 phút, 3 × 5 = 15 phút.','@img:dongho:11:15'],
  [4,'Đồng hồ chỉ mấy giờ? Em đi học lúc giờ này và đến trường sau 30 phút. Đến trường lúc mấy giờ? Giải thích.','Đồng hồ chỉ 7 giờ. Sau 30 phút là 7 giờ 30 phút, vì kim phút đi từ số 12 đến số 6 là 30 phút, trong khi kim giờ đi được nửa khoảng giữa số 7 và số 8.','@img:dongho:7:0']
 ]);
 add(M,2,'★ Nâng cao: Phép nhân, phép chia',[
  [2,'Có bao nhiêu bông hoa trong hình? Nếu chia đều số hoa cho 4 bạn thì mỗi bạn được mấy bông?','12 bông; mỗi bạn 3 bông','12 bông; mỗi bạn 4 bông','12 bông; mỗi bạn 2 bông','10 bông; mỗi bạn 5 bông','@img:dem:hoa:12'],
  [2,'Trong hình, mỗi hàng có 5 quả cam. Có mấy hàng cam và có tất cả bao nhiêu quả? Phép nhân nào đúng?','5 × 3 = 15','5 × 2 = 10','3 × 5 = 10','5 + 3 = 8','@img:dem:cam:15'],
  [3,'Đếm số chiếc kẹo trong hình. Chia đều số kẹo đó vào 2 hộp thì mỗi hộp có bao nhiêu chiếc? Viết phép chia.','Có 10 chiếc kẹo. 10 : 2 = 5. Mỗi hộp có 5 chiếc kẹo.','@img:dem:keo:10'],
  [4,'Hình xếp các ngôi sao thành các hàng, mỗi hàng 5 ngôi sao. Hãy viết phép nhân và phép chia tương ứng với hình và giải thích ý nghĩa của mỗi phép tính.','Có 4 hàng, mỗi hàng 5 ngôi sao, tổng 20 ngôi sao. Phép nhân: 5 × 4 = 20 (5 được lấy 4 lần). Phép chia: 20 : 5 = 4 (20 ngôi sao chia thành các hàng 5 ngôi sao thì được 4 hàng) hoặc 20 : 4 = 5.','@img:dem:sao:20']
 ]);
 add(M,2,'★ Nâng cao: Làm quen với hình khối',[
  [1,'Hình vẽ cho thấy khối gì?','Khối trụ','Khối cầu','Khối lập phương','Khối hộp chữ nhật','@img:hinh3d:tru'],
  [1,'Em hãy gọi tên khối trong hình vẽ.','Khối cầu','Khối trụ','Khối lập phương','Khối nón','@img:hinh3d:cau'],
  [2,'Khối trong hình vẽ có hai mặt đáy là hình gì?','Hình tròn','Hình vuông','Hình tam giác','Hình chữ nhật','@img:hinh3d:tru'],
  [3,'Khối trong hình là khối gì? Kể tên hai đồ vật trong thực tế có dạng khối này.','Khối cầu. Ví dụ: quả bóng đá, viên bi (hoặc quả địa cầu).','@img:hinh3d:cau'],
  [4,'Khối trong hình vẽ là khối gì? So sánh khối này với khối cầu (về mặt đáy và khả năng lăn).','Đây là khối trụ. Khối trụ có hai mặt đáy là hình tròn bằng nhau và một mặt cong, đặt đứng thì không lăn, đặt nằm thì lăn được theo một hướng. Khối cầu không có mặt đáy, toàn bộ là mặt cong nên lăn được theo mọi hướng.','@img:hinh3d:tru']
 ]);
 add(M,2,'★ Nâng cao: Các số trong phạm vi 1000',[
  [2,'Trên tia số, điểm đỏ ứng với số nào?','305','350','304','315','@img:truc:300:310:305'],
  [3,'Trên tia số, hai điểm đỏ ứng với hai số nào? So sánh hai số đó.','Hai điểm đỏ ứng với 493 và 498. 493 < 498 (hoặc 498 > 493).','@img:truc:490:500:493,498']
 ]);
 add(M,2,'★ Nâng cao: Độ dài và đơn vị đo độ dài. Tiền Việt Nam',[
  [1,'Trong hình có những tờ tiền nào?','20 000 đồng, 5 000 đồng, 1 000 đồng','20 000 đồng, 5 000 đồng, 2 000 đồng','10 000 đồng, 5 000 đồng, 1 000 đồng','20 000 đồng, 2 000 đồng, 1 000 đồng','@img:tien:20000,5000,1000'],
  [2,'Tổng số tiền trong hình là bao nhiêu?','7 000 đồng','6 000 đồng','8 000 đồng','12 000 đồng','@img:tien:5000,1000,1000'],
  [2,'Các tờ tiền trong hình có tổng là bao nhiêu đồng?','13 000 đồng','12 000 đồng','23 000 đồng','11 000 đồng','@img:tien:10000,2000,1000'],
  [2,'Đoạn thẳng màu xanh trong hình dài bao nhiêu đề-xi-mét?','1 dm','10 dm','100 dm','2 dm','@img:thuoc:10'],
  [3,'Mai có số tiền như trong hình. Mai mua một quyển vở giá 8 000 đồng. Hỏi Mai còn lại bao nhiêu tiền?','Số tiền của Mai: 10 000 + 5 000 = 15 000 (đồng). Còn lại: 15 000 - 8 000 = 7 000 (đồng).','@img:tien:10000,5000'],
  [4,'Hình vẽ số tiền của Hùng. Hùng muốn mua một chiếc bút giá 25 000 đồng. Hùng có đủ tiền không? Nếu thiếu thì thiếu bao nhiêu? Giải thích cách tính.','Số tiền của Hùng: 20 000 + 2 000 + 1 000 = 23 000 (đồng). 23 000 < 25 000 nên chưa đủ; còn thiếu 25 000 - 23 000 = 2 000 (đồng).','@img:tien:20000,2000,1000']
 ]);
 add(M,2,'★ Nâng cao: Phép cộng, phép trừ trong phạm vi 1000',[
  [2,'Dựa vào bảng, cả hai thửa ruộng thu hoạch được bao nhiêu kg thóc?','781 kg','771 kg','791 kg','103 kg','@img:bang:Thửa ruộng;Số kg thóc|Thửa 1;442|Thửa 2;339'],
  [3,'Bảng ghi số học sinh của hai trường. Trường nào đông hơn và đông hơn bao nhiêu học sinh?','Trường B đông hơn. 625 - 480 = 145 (học sinh).','@img:bang:Trường;Số học sinh|Trường A;480|Trường B;625'],
  [4,'Dựa vào bảng số cây ba lớp trồng được, tính tổng số cây của cả ba lớp và cho biết lớp 2C cần trồng thêm bao nhiêu cây để bằng lớp 2A. Nêu rõ cách tính.','Tổng: 215 + 190 + 178 = 583 (cây). Lớp 2C cần thêm: 215 - 178 = 37 (cây). Cách tính: cộng lần lượt 215 + 190 = 405, rồi 405 + 178 = 583; hiệu 215 - 178 tính bằng phép trừ có nhớ.','@img:bang:Lớp;Số cây|2A;215|2B;190|2C;178']
 ]);
 add(M,2,'★ Nâng cao: Làm quen với yếu tố thống kê, xác suất',[
  [1,'Biểu đồ tranh cho biết số quả mỗi loại (mỗi ★ là 1 quả). Có bao nhiêu quả cam?','6','4','3','5','@img:bieudo:tranh:Táo=4,Cam=6,Chuối=3'],
  [2,'Theo biểu đồ tranh (mỗi ★ là 1 bạn), môn thể thao nào được nhiều bạn thích nhất?','Bóng đá','Cầu lông','Bơi','Cờ vua','@img:bieudo:tranh:Bóng đá=7,Cầu lông=4,Bơi=5,Cờ vua=2'],
  [2,'Biểu đồ tranh cho biết số sách mỗi bạn đọc (mỗi ★ là 1 quyển). Lan đọc nhiều hơn Hà bao nhiêu quyển?','3 quyển','2 quyển','4 quyển','11 quyển','@img:bieudo:tranh:Lan=7,Hà=4'],
  [3,'Dựa vào biểu đồ tranh (mỗi ★ là 1 con), tính tổng số con vật của ba loại.','Gà 6 con, Vịt 4 con, Ngỗng 2 con. Tổng: 6 + 4 + 2 = 12 (con).','@img:bieudo:tranh:Gà=6,Vịt=4,Ngỗng=2'],
  [3,'Bảng kiểm đếm cho biết số bạn chọn mỗi loại hoa. Loại hoa nào được chọn ít nhất? Loại nhiều nhất hơn loại ít nhất bao nhiêu bạn?','Hoa cúc được chọn ít nhất (3 bạn). Hoa hồng nhiều nhất (9 bạn), nhiều hơn 9 - 3 = 6 (bạn).','@img:bang:Loại hoa;Số bạn chọn|Hoa hồng;9|Hoa cúc;3|Hoa sen;5'],
  [4,'Biểu đồ tranh cho biết số ngày nắng, mưa trong một tuần (mỗi ★ là 1 ngày). Dựa vào biểu đồ, hãy cho biết tổng số ngày, và nhận xét tuần đó có nhiều ngày nắng hay mưa hơn, hơn bao nhiêu ngày.','Nắng 5 ngày, mưa 2 ngày, tổng 5 + 2 = 7 ngày (đúng 1 tuần). Tuần đó nhiều ngày nắng hơn ngày mưa, hơn 5 - 2 = 3 ngày.','@img:bieudo:tranh:Nắng=5,Mưa=2']
 ]);
 add(M,2,'★ Nâng cao: Làm quen với khối lượng, dung tích',[
  [2,'Bảng cho biết cân nặng của hai con vật. Con nào nặng hơn và nặng hơn bao nhiêu ki-lô-gam?','Con ngỗng nặng hơn 2 kg','Con gà nặng hơn 2 kg','Con ngỗng nặng hơn 3 kg','Hai con nặng bằng nhau','@img:bang:Con vật;Cân nặng|Gà;3 kg|Ngỗng;5 kg'],
  [3,'Dựa vào bảng, tính tổng số lít nước trong cả ba bình.','5 + 3 + 2 = 10 (lít).','@img:bang:Bình;Số lít nước|Bình 1;5 l|Bình 2;3 l|Bình 3;2 l']
 ]);
 add(M,2,'Hình học và đo lường',[
  [2,'Đoạn thẳng màu xanh dài mấy xăng-ti-mét?','2 cm','1 cm','3 cm','20 cm','@img:thuoc:2'],
  [2,'Hình trong hình vẽ là hình gì?','Hình tứ giác','Hình tam giác','Đường gấp khúc','Hình tròn','@img:thang:7:4:3'],
  [3,'Đồng hồ trong hình chỉ mấy giờ? Đó là lúc kim phút chỉ số mấy?','Đồng hồ chỉ 4 giờ 15 phút. Kim phút chỉ số 3.','@img:dongho:4:15']
 ]);
 add(M,2,'★ Nâng cao: Ôn tập học kì 1',[
  [2,'Đồng hồ trong hình chỉ mấy giờ?','10 giờ 30 phút','10 giờ','11 giờ 30 phút','6 giờ 50 phút','@img:dongho:10:30'],
  [3,'Hình vẽ hai nhóm con cá. Viết phép cộng tương ứng và tính kết quả.','Nhóm trên 8 con, nhóm dưới 6 con. 8 + 6 = 14 (con cá).','@img:dem:ca:8:6']
 ]);
 add(M,2,'★ Nâng cao: Ôn tập cuối năm',[
  [2,'Tổng số tiền trong hình là bao nhiêu?','27 000 đồng','25 000 đồng','26 000 đồng','17 000 đồng','@img:tien:20000,5000,2000'],
  [3,'Biểu đồ tranh cho biết số xe mỗi màu trong bãi (mỗi ★ là 1 xe). Có tất cả bao nhiêu xe? Màu nào nhiều nhất?','Đỏ 5 xe, Xanh 8 xe, Trắng 3 xe. Tổng 16 xe. Màu xanh nhiều nhất.','@img:bieudo:tranh:Đỏ=5,Xanh=8,Trắng=3'],
  [4,'Đồng hồ chỉ mấy giờ? Em hãy giải thích vì sao kim giờ không chỉ đúng vào một số và điều đó cho biết gì.','Đồng hồ chỉ 5 giờ 30 phút. Kim giờ nằm giữa số 5 và số 6 vì đã qua 5 giờ được nửa giờ nhưng chưa đến 6 giờ; kim giờ đi chậm, trong 30 phút chỉ đi được nửa khoảng giữa hai số.','@img:dongho:5:30']
 ]);
 /* ================= LỚP 3 ================= */
 add(M,3,'★ Nâng cao: Ôn tập và bổ sung',[
  [2,'Trên tia số, điểm đỏ ứng với số nào?','706','705','707','760','@img:truc:700:710:706'],
  [2,'Dựa vào bảng, tổng số học sinh hai lớp là bao nhiêu?','71','70','72','61','@img:bang:Lớp;Số học sinh|3A;35|3B;36']
 ]);
 add(M,3,'★ Nâng cao: Bảng nhân, bảng chia',[
  [2,'Trong hình, mỗi hàng có 5 quả táo. Hình minh họa phép nhân nào?','5 × 4 = 20','5 × 3 = 15','4 × 4 = 16','5 + 4 = 9','@img:dem:tao:20'],
  [2,'Đếm số ngôi sao trong hình. Số đó chia cho 3 được bao nhiêu?','18 : 3 = 6','18 : 3 = 5','15 : 3 = 5','18 : 2 = 9','@img:dem:sao:18'],
  [3,'Đếm số bông hoa trong hình. Nếu cắm đều vào 4 lọ thì mỗi lọ có mấy bông? Viết phép chia.','Có 16 bông hoa. 16 : 4 = 4. Mỗi lọ có 4 bông hoa.','@img:dem:hoa:16'],
  [4,'Hình xếp các khối lập phương thành các hàng 5 khối. Viết một phép nhân và hai phép chia từ hình, giải thích vì sao ba phép tính này cùng mô tả hình.','Có 3 hàng × 5 khối = 15 khối: 5 × 3 = 15. Hai phép chia: 15 : 5 = 3 (15 khối chia thành hàng 5 khối được 3 hàng) và 15 : 3 = 5 (15 khối chia đều 3 hàng, mỗi hàng 5 khối). Ba phép tính cùng dùng ba số 15, 5, 3 để mô tả cùng một cách sắp xếp.','@img:dem:khoi:15']
 ]);
 add(M,3,'★ Nâng cao: Làm quen với hình phẳng, hình khối',[
  [1,'Hình tròn trong hình vẽ có tâm là điểm nào và đường kính dài bao nhiêu?','Tâm O, đường kính 6 cm','Tâm O, đường kính 3 cm','Tâm A, đường kính 6 cm','Tâm O, bán kính 6 cm','@img:tron:6'],
  [2,'Hình tròn trong hình có đường kính 8 cm. Bán kính của hình tròn là bao nhiêu?','4 cm','8 cm','16 cm','2 cm','@img:tron:8'],
  [2,'Khối trong hình vẽ có bao nhiêu mặt, bao nhiêu đỉnh?','6 mặt, 8 đỉnh','6 mặt, 6 đỉnh','8 mặt, 6 đỉnh','4 mặt, 8 đỉnh','@img:hinh3d:lapphuong'],
  [2,'Hình tam giác trong hình có các cạnh dài bao nhiêu? Cạnh nào dài nhất?','AB = 5 cm, BC = 7 cm, CA = 6 cm; cạnh BC dài nhất','AB = 5 cm, BC = 7 cm, CA = 6 cm; cạnh CA dài nhất','AB = 7 cm, BC = 5 cm, CA = 6 cm; cạnh AB dài nhất','AB = 5 cm, BC = 6 cm, CA = 7 cm; cạnh CA dài nhất','@img:tgl:A:B:C:AB=5 cm:BC=7 cm:CA=6 cm'],
  [3,'Khối trong hình là khối gì? Nêu số mặt, số đỉnh, số cạnh của khối đó.','Khối hộp chữ nhật, có 6 mặt, 8 đỉnh, 12 cạnh.','@img:hinh3d:hophcn'],
  [4,'Hình tròn trong hình có tâm O và đường kính dài 10 cm. Tính bán kính và giải thích mối quan hệ giữa đường kính và bán kính.','Bán kính là 10 : 2 = 5 (cm). Đường kính là đoạn thẳng đi qua tâm nối hai điểm trên hình tròn, dài gấp 2 lần bán kính; bán kính là đoạn từ tâm đến một điểm trên hình tròn.','@img:tron:10']
 ]);
 add(M,3,'★ Nâng cao: Một số đơn vị đo độ dài, khối lượng, dung tích, nhiệt độ',[
  [1,'Nhiệt kế trong hình chỉ bao nhiêu độ C?','30°C','20°C','40°C','35°C','@img:nhietke:30'],
  [2,'Nhiệt kế trong hình chỉ nhiệt độ của nước. Nước đang ở trạng thái nào?','100°C, nước đang sôi','0°C, nước đóng băng','80°C, nước ấm','50°C, nước nguội','@img:nhietke:100'],
  [2,'Đoạn thẳng màu xanh trong hình dài bao nhiêu mi-li-mét?','70 mm','7 mm','700 mm','17 mm','@img:thuoc:7'],
  [3,'Nhiệt kế chỉ bao nhiêu độ C? Nếu nhiệt độ tăng thêm 15 độ thì nhiệt kế chỉ bao nhiêu?','Nhiệt kế chỉ 20°C. 20 + 15 = 35. Nhiệt kế sẽ chỉ 35°C.','@img:nhietke:20'],
  [4,'Bảng ghi cân nặng của ba bạn. Hãy sắp xếp các bạn theo thứ tự cân nặng từ nhẹ đến nặng và cho biết cả ba bạn nặng bao nhiêu kg; có cần đổi đơn vị không, vì sao?','Thứ tự nhẹ đến nặng: Hà (27 kg), Lan (29 kg), Nam (32 kg). Tổng: 27 + 29 + 32 = 88 (kg). Các số liệu cùng đơn vị kg nên cộng trực tiếp, không cần đổi.','@img:bang:Bạn;Cân nặng|Lan;29 kg|Nam;32 kg|Hà;27 kg']
 ]);
 add(M,3,'★ Nâng cao: Phép nhân, phép chia trong phạm vi 100',[
  [2,'Dựa vào bảng, 4 hộp bút có tất cả bao nhiêu chiếc bút?','48 chiếc','44 chiếc','16 chiếc','12 chiếc','@img:bang:Số hộp;Số bút|1 hộp;12 chiếc|4 hộp;?'],
  [3,'Bảng cho biết số kẹo trong mỗi túi. Hỏi 7 túi như thế có bao nhiêu chiếc kẹo? Nếu có 56 chiếc kẹo thì chia được mấy túi?','Mỗi túi 8 chiếc: 8 × 7 = 56 (chiếc). 56 : 8 = 7 (túi).','@img:bang:Số túi;Số kẹo|1 túi;8 chiếc|7 túi;?']
 ]);
 add(M,3,'★ Nâng cao: Phép nhân, phép chia trong phạm vi 1000',[
  [2,'Theo bảng, mỗi thùng có 125 quyển vở. 3 thùng có bao nhiêu quyển?','375 quyển','365 quyển','128 quyển','275 quyển','@img:bang:Số thùng;Số vở|1 thùng;125 quyển|3 thùng;?'],
  [3,'Bảng cho biết tổng số gạo và số bao. Hỏi mỗi bao có bao nhiêu kg gạo?','Mỗi bao: 480 : 6 = 80 (kg).','@img:bang:Tổng số gạo;Số bao|480 kg;6 bao']
 ]);
 add(M,3,'★ Nâng cao: Chu vi, diện tích một số hình phẳng',[
  [1,'Chu vi hình chữ nhật trong hình là bao nhiêu?','16 cm','15 cm','8 cm','30 cm','@img:hcn:5:3'],
  [1,'Chu vi hình vuông trong hình là bao nhiêu?','16 cm','8 cm','12 cm','32 cm','@img:vuong:4'],
  [2,'Diện tích hình chữ nhật trong hình là bao nhiêu?','24 cm²','20 cm²','10 cm²','14 cm²','@img:hcn:6:4'],
  [2,'Diện tích hình vuông trong hình là bao nhiêu?','25 cm²','20 cm²','10 cm²','50 cm²','@img:vuong:5'],
  [2,'Tính chu vi của hình chữ nhật trong hình vẽ.','26 cm','40 cm','13 cm','18 cm','@img:hcn:8:5'],
  [3,'Tính chu vi và diện tích hình chữ nhật trong hình.','Chu vi: (7 + 4) × 2 = 22 (cm). Diện tích: 7 × 4 = 28 (cm²).','@img:hcn:7:4'],
  [3,'Tính chu vi và diện tích hình vuông trong hình.','Chu vi: 6 × 4 = 24 (cm). Diện tích: 6 × 6 = 36 (cm²).','@img:vuong:6'],
  [4,'Tính diện tích hình chữ nhật trong hình. Một hình vuông có diện tích bằng diện tích hình chữ nhật này thì cạnh dài bao nhiêu? So sánh chu vi hai hình.','Diện tích: 8 × 2 = 16 (cm²). Hình vuông cạnh 4 cm vì 4 × 4 = 16. Chu vi hình chữ nhật: (8 + 2) × 2 = 20 (cm); chu vi hình vuông: 4 × 4 = 16 (cm). Hai hình cùng diện tích nhưng hình chữ nhật có chu vi lớn hơn.','@img:hcn:8:2']
 ]);
 add(M,3,'★ Nâng cao: Xem đồng hồ. Tháng – năm. Tiền Việt Nam',[
  [1,'Đồng hồ trong hình chỉ mấy giờ?','9 giờ 15 phút','3 giờ 45 phút','9 giờ 3 phút','9 giờ 45 phút','@img:dongho:9:15'],
  [1,'Đồng hồ chỉ mấy giờ?','3 giờ 30 phút','6 giờ 15 phút','3 giờ 6 phút','4 giờ 30 phút','@img:dongho:3:30'],
  [2,'Đồng hồ trong hình chỉ mấy giờ? (đọc theo 2 cách)','7 giờ 50 phút hay 8 giờ kém 10 phút','7 giờ 10 phút hay 8 giờ kém 50 phút','8 giờ 50 phút hay 9 giờ kém 10 phút','10 giờ 40 phút hay 11 giờ kém 20 phút','@img:dongho:7:50'],
  [2,'Em hãy đọc giờ trên đồng hồ.','1 giờ 25 phút','5 giờ 5 phút','1 giờ 5 phút','2 giờ 25 phút','@img:dongho:1:25'],
  [2,'Tổng số tiền trong hình là bao nhiêu?','62 000 đồng','52 000 đồng','61 000 đồng','72 000 đồng','@img:tien:50000,10000,2000'],
  [3,'Đồng hồ trong hình chỉ mấy giờ? Nếu là buổi chiều thì đó là mấy giờ theo cách đọc 24 giờ? Còn bao nhiêu phút nữa thì đến 5 giờ?','Đồng hồ chỉ 4 giờ 40 phút (5 giờ kém 20 phút). Buổi chiều là 16 giờ 40 phút. Còn 20 phút nữa thì đến 5 giờ.','@img:dongho:4:40'],
  [3,'Hình vẽ số tiền của Lan. Lan mua một hộp màu giá 65 000 đồng. Hỏi Lan được trả lại bao nhiêu tiền?','Số tiền của Lan: 50 000 + 20 000 + 5 000 = 75 000 (đồng). Được trả lại: 75 000 - 65 000 = 10 000 (đồng).','@img:tien:50000,20000,5000'],
  [4,'Hình vẽ các tờ tiền của Nam. Nam muốn đổi toàn bộ số tiền này thành các tờ 10 000 đồng. Nam đổi được bao nhiêu tờ? Nếu còn thừa thì thừa bao nhiêu? Giải thích.','Tổng: 100 000 + 20 000 + 5 000 + 2 000 = 127 000 (đồng). 127 000 : 10 000 = 12 (dư 7 000), nên đổi được 12 tờ 10 000 đồng và còn thừa 7 000 đồng (vì 12 × 10 000 = 120 000; 127 000 - 120 000 = 7 000).','@img:tien:100000,20000,5000,2000']
 ]);
 add(M,3,'★ Nâng cao: Làm quen với yếu tố thống kê, xác suất',[
  [1,'Bảng số liệu cho biết số cây mỗi lớp trồng. Lớp nào trồng được nhiều cây nhất?','3B','3A','3C','Ba lớp bằng nhau','@img:bang:Lớp;Số cây|3A;24|3B;31|3C;27'],
  [2,'Biểu đồ tranh cho biết số quyển truyện mỗi bạn đọc trong tháng (mỗi ★ là 1 quyển). Cả ba bạn đọc bao nhiêu quyển?','15 quyển','14 quyển','16 quyển','6 quyển','@img:bieudo:tranh:Minh=6,Thu=4,Phúc=5'],
  [2,'Theo bảng, số học sinh nữ của lớp 3A nhiều hơn số học sinh nam bao nhiêu bạn?','4 bạn','3 bạn','5 bạn','36 bạn','@img:bang:Lớp 3A;Số học sinh|Nam;16|Nữ;20'],
  [3,'Bảng cho biết số điểm 10 của ba tổ trong tuần. Tính tổng số điểm 10 và cho biết tổ nào ít nhất, kém tổ nhiều nhất bao nhiêu điểm 10.','Tổng: 12 + 9 + 15 = 36 (điểm 10). Tổ 2 ít nhất (9), kém tổ 3 (nhiều nhất, 15) là 15 - 9 = 6 (điểm 10).','@img:bang:Tổ;Số điểm 10|Tổ 1;12|Tổ 2;9|Tổ 3;15'],
  [4,'Biểu đồ tranh cho biết số ô tô bán được trong 3 tháng (mỗi ★ là 1 chiếc). Nhận xét xu hướng bán hàng và dự đoán tháng 4 có thể bán được nhiều hơn hay ít hơn tháng 3; giải thích.','Tháng 1: 3 chiếc, tháng 2: 5 chiếc, tháng 3: 8 chiếc; số xe bán tăng dần qua các tháng (tăng 2 rồi tăng 3). Nếu xu hướng tiếp tục, tháng 4 có thể bán nhiều hơn tháng 3 (hơn 8 chiếc), nhưng đó chỉ là dự đoán, không chắc chắn xảy ra.','@img:bieudo:tranh:Tháng 1=3,Tháng 2=5,Tháng 3=8']
 ]);
 add(M,3,'Hình học và đo lường',[
  [1,'Góc trong hình vẽ là góc gì?','Góc vuông','Góc không vuông','Góc nhọn','Góc tù','@img:goc:90'],
  [2,'Góc trong hình vẽ có phải góc vuông không?','Không, đó là góc không vuông (bé hơn góc vuông)','Có, đó là góc vuông','Không, đó là góc bẹt','Không, đó là góc lớn hơn góc vuông','@img:goc:50'],
  [2,'Hình chữ nhật trong hình có mấy góc vuông và chu vi bằng bao nhiêu?','4 góc vuông; chu vi 20 cm','4 góc vuông; chu vi 24 cm','2 góc vuông; chu vi 20 cm','4 góc vuông; chu vi 10 cm','@img:hcn:6:4'],
  [3,'Trên tia số, hai điểm đỏ ứng với số nào? Tìm số ở chính giữa hai số đó (ứng với trung điểm).','Hai điểm đỏ ứng với 2 và 8. Số ở chính giữa là 5, vì 5 cách đều 2 và 8 (cách mỗi số 3 đơn vị).','@img:truc:0:10:2,8'],
  [3,'Đoạn thẳng màu xanh dài bao nhiêu? Trung điểm của đoạn thẳng cách mỗi đầu bao nhiêu xăng-ti-mét?','Đoạn thẳng dài 8 cm. Trung điểm cách mỗi đầu 8 : 2 = 4 (cm).','@img:thuoc:8']
 ]);
 add(M,3,'★ Nâng cao: Các số đến 10 000',[
  [2,'Trên tia số, điểm đỏ ứng với số nào?','2 004','2 003','2 400','2 040','@img:truc:2000:2010:2004']
 ]);
 add(M,3,'★ Nâng cao: Các số đến 100 000',[
  [2,'Bảng cho biết số dân của ba xã. Xã nào có số dân lớn nhất?','Xã C','Xã A','Xã B','Ba xã bằng nhau','@img:bang:Xã;Số dân|Xã A;12 450|Xã B;9 870|Xã C;15 320']
 ]);
 add(M,3,'★ Nâng cao: Cộng, trừ, nhân, chia trong phạm vi 10 000',[
  [3,'Dựa vào bảng, tính tổng số vở hai kho và số vở kho 1 nhiều hơn kho 2.','Tổng: 3 250 + 1 875 = 5 125 (quyển). Kho 1 nhiều hơn: 3 250 - 1 875 = 1 375 (quyển).','@img:bang:Kho;Số quyển vở|Kho 1;3 250|Kho 2;1 875']
 ]);
 add(M,3,'★ Nâng cao: Cộng, trừ trong phạm vi 100 000',[
  [3,'Bảng ghi số tiền bán hàng hai ngày của một cửa hàng. Tính tổng số tiền hai ngày và cho biết ngày nào bán được nhiều hơn, nhiều hơn bao nhiêu.','Tổng: 45 600 + 38 900 = 84 500 (đồng). Ngày 1 bán nhiều hơn: 45 600 - 38 900 = 6 700 (đồng).','@img:bang:Ngày;Số tiền|Ngày 1;45 600 đ|Ngày 2;38 900 đ']
 ]);
 add(M,3,'★ Nâng cao: Nhân, chia trong phạm vi 100 000',[
  [3,'Bảng cho biết giá một quyển sách. Mua 4 quyển hết bao nhiêu tiền? Với 60 000 đồng mua được nhiều nhất mấy quyển?','4 quyển: 12 500 × 4 = 50 000 (đồng). 60 000 : 12 500 = 4 (dư 10 000) nên mua được nhiều nhất 4 quyển.','@img:bang:Mặt hàng;Giá|Sách;12 500 đ']
 ]);
 add(M,3,'★ Nâng cao: Ôn tập học kì 1',[
  [2,'Đồng hồ trong hình chỉ mấy giờ?','6 giờ 35 phút','7 giờ 35 phút','6 giờ 7 phút','7 giờ kém 35 phút','@img:dongho:6:35'],
  [3,'Tính chu vi hình chữ nhật trong hình. Nếu chiều dài tăng thêm 2 cm thì chu vi tăng thêm bao nhiêu?','Chu vi: (10 + 6) × 2 = 32 (cm). Chiều dài tăng 2 cm thì chu vi tăng 2 × 2 = 4 (cm), thành 36 cm.','@img:hcn:10:6']
 ]);
 add(M,3,'★ Nâng cao: Ôn tập cuối năm',[
  [2,'Diện tích hình vuông trong hình là bao nhiêu?','49 cm²','28 cm²','14 cm²','21 cm²','@img:vuong:7'],
  [3,'Nhiệt kế trong hình chỉ bao nhiêu độ C? Nhiệt độ này cao hơn hay thấp hơn 37°C (thân nhiệt bình thường của người), chênh bao nhiêu độ?','Nhiệt kế chỉ 40°C, cao hơn 37°C là 3 độ.','@img:nhietke:40'],
  [4,'Tính diện tích và chu vi hình chữ nhật trong hình. Nếu cắt hình này thành các hình vuông cạnh 2 cm thì được bao nhiêu hình vuông? Giải thích.','Diện tích: 12 × 4 = 48 (cm²); chu vi: (12 + 4) × 2 = 32 (cm). Mỗi hình vuông cạnh 2 cm có diện tích 4 cm². Số hình vuông: 48 : 4 = 12 (hình); cũng có thể tính: theo chiều dài xếp được 12 : 2 = 6 hình, theo chiều rộng 4 : 2 = 2 hình, 6 × 2 = 12 hình.','@img:hcn:12:4']
 ]);
 /* ================= LỚP 4 ================= */
 add(M,4,'★ Nâng cao: Góc và đơn vị đo góc',[
  [1,'Góc trong hình vẽ là góc gì?','Góc nhọn','Góc vuông','Góc tù','Góc bẹt','@img:goc:45'],
  [1,'Em hãy cho biết góc trong hình thuộc loại góc nào.','Góc tù','Góc nhọn','Góc vuông','Góc bẹt','@img:goc:120'],
  [1,'Góc được vẽ trong hình là góc gì?','Góc bẹt','Góc tù','Góc vuông','Góc nhọn','@img:goc:180'],
  [2,'Góc trong hình có số đo 60°. Góc này là góc gì và so với góc vuông thì thế nào?','Góc nhọn, bé hơn góc vuông','Góc tù, lớn hơn góc vuông','Góc vuông, bằng góc vuông','Góc bẹt, gấp đôi góc vuông','@img:goc:60'],
  [2,'Góc trong hình có số đo 135°. Góc này là góc gì?','Góc tù (lớn hơn góc vuông, bé hơn góc bẹt)','Góc nhọn (bé hơn góc vuông)','Góc vuông','Góc bẹt','@img:goc:135'],
  [3,'Góc trong hình có số đo 150°. Góc này là góc gì? Góc này lớn hơn góc vuông bao nhiêu độ và kém góc bẹt bao nhiêu độ?','Góc tù. Lớn hơn góc vuông: 150 - 90 = 60 (độ). Kém góc bẹt: 180 - 150 = 30 (độ).','@img:goc:150'],
  [4,'Góc trong hình có số đo 30°. Nếu ghép ba góc như thế lại với nhau (chung đỉnh, kề nhau) thì được góc gì? Vì sao?','Ba góc 30° ghép lại được góc 30 × 3 = 90°, tức là góc vuông, vì tổng số đo các góc kề nhau bằng số đo góc tạo thành và góc vuông có số đo 90°.','@img:goc:30']
 ]);
 add(M,4,'Hai đường thẳng vuông góc, song song',[
  [1,'Hai đường thẳng a và b trong hình có quan hệ gì?','Song song với nhau','Vuông góc với nhau','Cắt nhau tạo góc nhọn','Trùng nhau','@img:songsong'],
  [2,'Hai đường thẳng a và b vuông góc với nhau tạo thành góc gì tại điểm cắt?','Góc vuông (90°)','Góc nhọn','Góc tù','Góc bẹt','@img:vuonggoc'],
  [3,'Hình chữ nhật trong hình có các cặp cạnh nào song song với nhau, cặp cạnh nào vuông góc với nhau? (kể theo kích thước)','Hai cạnh dài 6 cm song song với nhau; hai cạnh 4 cm song song với nhau. Mỗi cạnh 6 cm vuông góc với mỗi cạnh 4 cm kề nó (4 cặp cạnh vuông góc).','@img:hcn:6:4'],
  [4,'Quan sát hai đường thẳng a và b trong hình. Nếu vẽ thêm đường thẳng c vuông góc với a thì c có quan hệ gì với b? Giải thích.','a và b song song. Đường thẳng c vuông góc với a thì cũng vuông góc với b, vì hai đường thẳng song song cùng tạo với đường thẳng c những góc bằng nhau (đều là góc vuông).','@img:songsong']
 ]);
 add(M,4,'★ Nâng cao: Đường thẳng vuông góc. Đường thẳng song song',[
  [1,'Hai đường thẳng a và b trong hình có quan hệ gì?','Vuông góc với nhau','Song song với nhau','Cắt nhau tạo góc tù','Không cắt nhau','@img:vuonggoc'],
  [2,'Hai đường thẳng a và b trong hình có cắt nhau không? Vì sao?','Không, vì chúng song song với nhau nên kéo dài mãi cũng không cắt nhau','Có, vì kéo dài sẽ gặp nhau','Có, vì chúng vuông góc','Không, vì chúng trùng nhau','@img:songsong'],
  [3,'Hình vuông trong hình có mấy cặp cạnh vuông góc và mấy cặp cạnh song song?','Hình vuông có 4 cặp cạnh vuông góc (các cạnh kề nhau) và 2 cặp cạnh song song (các cạnh đối nhau).','@img:vuong:5']
 ]);
 add(M,4,'Hình bình hành, hình thoi',[
  [1,'Hình trong hình vẽ là hình gì?','Hình bình hành','Hình thoi','Hình chữ nhật','Hình thang','@img:hbh:6:4'],
  [1,'Hình vẽ cho thấy hình gì?','Hình thoi','Hình bình hành','Hình vuông','Hình chữ nhật','@img:thoi:5'],
  [2,'Hình thoi trong hình có cạnh 5 cm. Chu vi hình thoi là bao nhiêu?','20 cm','10 cm','25 cm','15 cm','@img:thoi:5'],
  [2,'Hình bình hành trong hình có hai cạnh 6 cm và 4 cm. Chu vi của nó là bao nhiêu?','20 cm','24 cm','10 cm','12 cm','@img:hbh:6:4'],
  [3,'Hình bình hành trong hình có các cạnh 7 cm và 3 cm. Tính chu vi và nêu đặc điểm các cặp cạnh đối của hình bình hành.','Chu vi: (7 + 3) × 2 = 20 (cm). Hình bình hành có hai cặp cạnh đối diện song song và bằng nhau.','@img:hbh:7:3'],
  [4,'Hình thoi trong hình có cạnh 6 cm. Tính chu vi. Hình thoi và hình bình hành giống và khác nhau như thế nào?','Chu vi: 6 × 4 = 24 (cm). Giống: cả hai đều có hai cặp cạnh đối diện song song và bằng nhau. Khác: hình thoi có bốn cạnh bằng nhau, hình bình hành nói chung chỉ có các cạnh đối bằng nhau.','@img:thoi:6']
 ]);
 add(M,4,'★ Nâng cao: Làm quen với yếu tố thống kê, xác suất',[
  [1,'Biểu đồ cột cho biết số học sinh giỏi của các lớp. Lớp nào có nhiều học sinh giỏi nhất?','4B','4A','4C','4D','@img:bieudo:cot:4A=12,4B=18,4C=9,4D=15'],
  [2,'Biểu đồ cột cho biết số cây trồng được của các tổ. Tổ 1 và tổ 3 trồng được tất cả bao nhiêu cây?','40 cây','35 cây','45 cây','25 cây','@img:bieudo:cot:Tổ 1=25,Tổ 2=20,Tổ 3=15'],
  [2,'Theo biểu đồ, số sách bán được tháng 3 nhiều hơn tháng 1 bao nhiêu quyển?','30 quyển','20 quyển','50 quyển','80 quyển','@img:bieudo:cot:Th1=50,Th2=60,Th3=80'],
  [3,'Biểu đồ cột cho biết lượng mưa (mm) bốn tháng. Tháng nào mưa nhiều nhất, ít nhất? Tổng lượng mưa bốn tháng là bao nhiêu?','Tháng 8 mưa nhiều nhất (300 mm), tháng 5 ít nhất (120 mm). Tổng: 120 + 200 + 250 + 300 = 870 (mm).','@img:bieudo:cot:Th5=120,Th6=200,Th7=250,Th8=300'],
  [3,'Dựa vào biểu đồ cột về số con vật của một trang trại, tính trung bình mỗi loại có bao nhiêu con.','Tổng: 30 + 18 + 24 = 72 (con). Trung bình mỗi loại: 72 : 3 = 24 (con).','@img:bieudo:cot:Gà=30,Vịt=18,Ngan=24'],
  [4,'Biểu đồ cột cho biết số bạn chọn mỗi loại nước uống. Nếu chọn ngẫu nhiên một bạn thì khả năng bạn đó chọn loại nào là lớn nhất, nhỏ nhất? Giải thích dựa vào số liệu.','Nước cam 16 bạn, sữa 10 bạn, trà 4 bạn. Khả năng chọn trúng bạn thích nước cam là lớn nhất vì số bạn chọn nước cam nhiều nhất; khả năng chọn trúng bạn thích trà là nhỏ nhất vì chỉ có 4 bạn chọn (ít nhất).','@img:bieudo:cot:Nước cam=16,Sữa=10,Trà=4']
 ]);
 add(M,4,'★ Nâng cao: Phân số',[
  [1,'Phần tô màu của hình tròn biểu thị phân số nào?','3/8','5/8','3/5','8/3','@img:phanso:3:8'],
  [1,'Phần tô màu trong hình biểu thị phân số nào?','2/5','3/5','5/2','2/3','@img:phanso:2:5:thanh'],
  [2,'Phần chưa tô màu của hình tròn biểu thị phân số nào?','1/4','3/4','1/3','4/3','@img:phanso:3:4'],
  [2,'Phân số chỉ phần tô màu trong hình bằng phân số nào dưới đây?','1/2','1/3','2/3','4/6','@img:phanso:3:6'],
  [3,'Viết phân số chỉ phần đã tô màu và phân số chỉ phần chưa tô màu trong hình. Tổng hai phân số đó bằng bao nhiêu?','Phần tô màu: 5/8; phần chưa tô: 3/8. Tổng: 5/8 + 3/8 = 8/8 = 1.','@img:phanso:5:8:thanh'],
  [4,'Phần tô màu của hình tròn biểu thị phân số nào? Hãy rút gọn phân số đó và giải thích vì sao hai phân số này bằng nhau dựa trên hình vẽ.','Phần tô màu là 4/8. Rút gọn: 4/8 = 1/2 (chia cả tử và mẫu cho 4). Trên hình, 4 phần tô màu bằng đúng một nửa hình tròn nên 4/8 = 1/2.','@img:phanso:4:8']
 ]);
 add(M,4,'★ Nâng cao: Phép cộng, phép trừ phân số',[
  [2,'Phần tô màu của hình tròn là 2/6 hình tròn. Nếu tô thêm 3/6 hình tròn nữa thì phần tô màu là bao nhiêu?','5/6','5/12','1/6','6/6','@img:phanso:2:6'],
  [3,'Phần tô màu trong hình biểu thị phân số nào? Cần tô thêm bao nhiêu phần nữa để tô kín cả thanh? Viết phép tính.','Phần tô màu: 3/7. Cần tô thêm: 1 - 3/7 = 4/7 (thanh).','@img:phanso:3:7:thanh']
 ]);
 add(M,4,'★ Nâng cao: Phép nhân, phép chia phân số',[
  [3,'Phần tô màu của hình tròn biểu thị phân số nào? Nếu lấy 1/2 phần tô màu đó thì được bao nhiêu phần hình tròn? Viết phép nhân.','Phần tô màu: 2/3. Lấy 1/2 của 2/3: 2/3 × 1/2 = 2/6 = 1/3 (hình tròn).','@img:phanso:2:3']
 ]);
 add(M,4,'Hình học và đo lường',[
  [2,'Diện tích hình chữ nhật trong hình là bao nhiêu?','72 cm²','34 cm²','17 cm²','36 cm²','@img:hcn:9:8'],
  [2,'Góc trong hình là góc gì?','Góc tù','Góc nhọn','Góc vuông','Góc bẹt','@img:goc:110'],
  [3,'Tính chu vi và diện tích hình chữ nhật trong hình; đổi diện tích ra mi-li-mét vuông.','Chu vi: (15 + 10) × 2 = 50 (cm). Diện tích: 15 × 10 = 150 (cm²) = 15 000 mm².','@img:hcn:15:10'],
  [4,'Hình chữ nhật trong hình có chiều dài 20 cm, chiều rộng 5 cm. Tính diện tích. Nếu gấp đôi chiều rộng và giữ nguyên chiều dài thì diện tích thay đổi thế nào? Giải thích.','Diện tích: 20 × 5 = 100 (cm²). Gấp đôi chiều rộng thành 10 cm: diện tích 20 × 10 = 200 (cm²), gấp đôi diện tích ban đầu, vì diện tích bằng dài nhân rộng nên một thừa số gấp đôi thì tích gấp đôi.','@img:hcn:20:5']
 ]);
 add(M,4,'★ Nâng cao: Một số đơn vị đo đại lượng',[
  [2,'Hình chữ nhật trong hình có kích thước 3 dm × 2 dm. Diện tích của nó bằng bao nhiêu xăng-ti-mét vuông?','600 cm²','6 cm²','60 cm²','6 000 cm²','@img:hcn:3:2:dm'],
  [3,'Bảng cho biết khối lượng hàng ba xe chở. Đổi về cùng đơn vị rồi tính tổng khối lượng hàng (theo kg).','2 tấn = 2 000 kg; 15 tạ = 1 500 kg; 800 kg. Tổng: 2 000 + 1 500 + 800 = 4 300 (kg).','@img:bang:Xe;Khối lượng|Xe 1;2 tấn|Xe 2;15 tạ|Xe 3;800 kg']
 ]);
 add(M,4,'★ Nâng cao: Số có nhiều chữ số',[
  [2,'Bảng cho biết số dân ba tỉnh. Hãy sắp xếp theo thứ tự số dân từ bé đến lớn.','Tỉnh B, tỉnh A, tỉnh C','Tỉnh A, tỉnh B, tỉnh C','Tỉnh C, tỉnh A, tỉnh B','Tỉnh B, tỉnh C, tỉnh A','@img:bang:Tỉnh;Số dân|Tỉnh A;1 245 300|Tỉnh B;987 650|Tỉnh C;1 302 480']
 ]);
 add(M,4,'★ Nâng cao: Phép cộng và phép trừ',[
  [3,'Dựa vào bảng, tính tổng số tiền thu được hai ngày và ngày 2 thu nhiều hơn ngày 1 bao nhiêu.','Tổng: 125 400 + 148 650 = 274 050 (đồng). Ngày 2 nhiều hơn: 148 650 - 125 400 = 23 250 (đồng).','@img:bang:Ngày;Số tiền|Ngày 1;125 400 đ|Ngày 2;148 650 đ']
 ]);
 add(M,4,'★ Nâng cao: Phép nhân, phép chia',[
  [3,'Bảng cho biết số ghế mỗi hàng và số hàng ghế của hội trường. Hội trường có bao nhiêu ghế? Nếu có 540 người thì cần thêm bao nhiêu ghế?','Số ghế: 24 × 18 = 432 (ghế). Cần thêm: 540 - 432 = 108 (ghế).','@img:bang:Số ghế mỗi hàng;Số hàng|24;18']
 ]);
 add(M,4,'★ Nâng cao: Ôn tập và bổ sung',[
  [2,'Biểu đồ cột cho biết số sản phẩm xưởng làm được trong 3 ngày. Trung bình mỗi ngày xưởng làm được bao nhiêu sản phẩm?','40 sản phẩm','45 sản phẩm','120 sản phẩm','35 sản phẩm','@img:bieudo:cot:Ngày 1=35,Ngày 2=45,Ngày 3=40']
 ]);
 add(M,4,'★ Nâng cao: Ôn tập học kì 1',[
  [2,'Góc trong hình là góc gì?','Góc nhọn','Góc tù','Góc vuông','Góc bẹt','@img:goc:70'],
  [3,'Biểu đồ cột cho biết số học sinh tham gia các câu lạc bộ. Tính tổng số học sinh và cho biết câu lạc bộ nào đông gấp đôi câu lạc bộ nào.','Tổng: 24 + 12 + 30 = 66 (học sinh). Câu lạc bộ Vẽ (24) đông gấp đôi câu lạc bộ Cờ (12).','@img:bieudo:cot:Vẽ=24,Cờ=12,Nhạc=30']
 ]);
 add(M,4,'★ Nâng cao: Ôn tập cuối năm',[
  [2,'Phần tô màu trong hình biểu thị phân số nào?','3/4','1/4','4/3','3/5','@img:phanso:3:4:thanh'],
  [3,'Hình bình hành trong hình có cạnh 8 cm và 5 cm. Tính chu vi; nếu cạnh 8 cm giảm đi 2 cm thì chu vi mới là bao nhiêu?','Chu vi: (8 + 5) × 2 = 26 (cm). Cạnh 8 cm giảm còn 6 cm: chu vi mới (6 + 5) × 2 = 22 (cm).','@img:hbh:8:5'],
  [4,'Biểu đồ cột cho biết số lít nước một gia đình dùng trong 4 tuần. Tính trung bình mỗi tuần; tuần nào dùng nhiều hơn mức trung bình? Giải thích ý nghĩa của số trung bình.','Tổng: 120 + 150 + 90 + 140 = 500 (lít); trung bình 500 : 4 = 125 (lít/tuần). Tuần 2 (150) và tuần 4 (140) dùng nhiều hơn mức trung bình. Số trung bình là mức mà nếu san đều tổng lượng nước cho 4 tuần thì mỗi tuần dùng bấy nhiêu.','@img:bieudo:cot:Tuần 1=120,Tuần 2=150,Tuần 3=90,Tuần 4=140']
 ]);
 /* ================= LỚP 5 ================= */
 add(M,5,'★ Nâng cao: Một số hình phẳng. Chu vi và diện tích',[
  [1,'Diện tích hình tam giác trong hình là bao nhiêu?','12 cm²','24 cm²','10 cm²','20 cm²','@img:tamgiac:6:4'],
  [2,'Diện tích hình thang trong hình là bao nhiêu?','26 cm²','52 cm²','17 cm²','32 cm²','@img:thang:8:5:4'],
  [2,'Hình tròn trong hình có đường kính 6 cm. Chu vi của nó là bao nhiêu?','18,84 cm','9,42 cm','28,26 cm','37,68 cm','@img:tron:6'],
  [2,'Hình tròn trong hình có đường kính 10 cm. Diện tích hình tròn là bao nhiêu?','78,5 cm²','31,4 cm²','314 cm²','15,7 cm²','@img:tron:10'],
  [2,'Hình tam giác ABC trong hình có AB = 5 cm, BC = 7 cm, CA = 6 cm. Chu vi của tam giác là bao nhiêu?','18 cm','17 cm','19 cm','35 cm','@img:tgl:A:B:C:AB=5 cm:BC=7 cm:CA=6 cm'],
  [3,'Tính diện tích hình tam giác trong hình (đáy 10 cm, chiều cao 7 cm). Nếu đổi đơn vị sang mi-li-mét vuông thì được bao nhiêu?','Diện tích: 10 × 7 : 2 = 35 (cm²) = 3 500 mm².','@img:tamgiac:10:7'],
  [3,'Tính diện tích hình thang trong hình có đáy lớn 12 m, đáy bé 8 m, chiều cao 5 m.','Diện tích: (12 + 8) × 5 : 2 = 50 (m²).','@img:thang:12:8:5:m'],
  [3,'Hình tròn trong hình có đường kính 8 dm. Tính chu vi và diện tích hình tròn.','Bán kính: 8 : 2 = 4 (dm). Chu vi: 8 × 3,14 = 25,12 (dm). Diện tích: 4 × 4 × 3,14 = 50,24 (dm²).','@img:tron:8:dm'],
  [4,'Hình thang trong hình có đáy lớn 9 cm, đáy bé 5 cm, chiều cao 4 cm. Tính diện tích. Một hình tam giác có cùng chiều cao 4 cm và cùng diện tích với hình thang này thì đáy dài bao nhiêu? Giải thích.','Diện tích hình thang: (9 + 5) × 4 : 2 = 28 (cm²). Tam giác có diện tích 28 cm², chiều cao 4 cm thì đáy là 28 × 2 : 4 = 14 (cm), đúng bằng tổng hai đáy của hình thang, vì công thức diện tích hình thang chính là diện tích tam giác có đáy bằng tổng hai đáy và cùng chiều cao.','@img:thang:9:5:4']
 ]);
 add(M,5,'★ Nâng cao: Diện tích và thể tích của một số hình khối',[
  [1,'Hình khối trong hình vẽ là hình gì?','Hình hộp chữ nhật','Hình lập phương','Hình trụ','Hình cầu','@img:hinh3d:hophcn'],
  [1,'Hình vẽ cho thấy hình khối nào?','Hình trụ','Hình nón','Hình cầu','Hình lập phương','@img:hinh3d:tru'],
  [2,'Bảng cho kích thước một hình hộp chữ nhật. Thể tích của hình hộp đó là bao nhiêu?','120 cm³','15 cm³','100 cm³','148 cm³','@img:bang:Hình hộp;Chiều dài;Chiều rộng;Chiều cao|Kích thước;6 cm;4 cm;5 cm'],
  [2,'Hình khối trong hình có bao nhiêu mặt, các mặt là hình gì?','6 mặt, đều là hình vuông bằng nhau','6 mặt, đều là hình chữ nhật khác nhau','8 mặt, đều là hình vuông','4 mặt, đều là hình vuông','@img:hinh3d:lapphuong'],
  [3,'Bảng cho cạnh của một hình lập phương. Tính diện tích toàn phần và thể tích của hình lập phương đó.','Cạnh 5 cm. Diện tích toàn phần: 5 × 5 × 6 = 150 (cm²). Thể tích: 5 × 5 × 5 = 125 (cm³).','@img:bang:Hình;Cạnh|Lập phương;5 cm'],
  [3,'Dựa vào kích thước trong bảng, tính diện tích xung quanh và thể tích của hình hộp chữ nhật.','Diện tích xung quanh: (8 + 5) × 2 × 3 = 78 (cm²). Thể tích: 8 × 5 × 3 = 120 (cm³).','@img:bang:Hình hộp;Chiều dài;Chiều rộng;Chiều cao|Kích thước;8 cm;5 cm;3 cm'],
  [4,'Hình trong hình vẽ là hình trụ. Hãy nêu đặc điểm của hình trụ (mặt đáy, mặt xung quanh) và so sánh với hình hộp chữ nhật về số mặt phẳng.','Hình trụ có hai mặt đáy là hai hình tròn bằng nhau và một mặt xung quanh là mặt cong. Hình hộp chữ nhật có 6 mặt đều là mặt phẳng (hình chữ nhật), còn hình trụ chỉ có 2 mặt phẳng (hai đáy) và một mặt cong, không có đỉnh, không có cạnh thẳng.','@img:hinh3d:tru']
 ]);
 add(M,5,'★ Nâng cao: Thể tích. Đơn vị đo thể tích',[
  [2,'Trong hình có bao nhiêu khối lập phương nhỏ? Nếu mỗi khối có thể tích 1 cm³ thì thể tích của tất cả các khối là bao nhiêu?','12 khối; 12 cm³','10 khối; 10 cm³','12 khối; 12 cm²','15 khối; 15 cm³','@img:dem:khoi:12'],
  [3,'Đếm số khối lập phương trong hình (mỗi khối có cạnh 1 dm). Tổng thể tích của chúng là bao nhiêu đề-xi-mét khối, bằng bao nhiêu xăng-ti-mét khối?','Có 9 khối, mỗi khối 1 dm³. Tổng: 9 dm³ = 9 000 cm³.','@img:dem:khoi:9']
 ]);
 add(M,5,'★ Nâng cao: Một số yếu tố thống kê và xác suất',[
  [1,'Biểu đồ cột cho biết số học sinh khối 5 chọn môn thể thao. Môn nào ít bạn chọn nhất?','Cờ vua','Bóng đá','Bơi','Cầu lông','@img:bieudo:cot:Cờ vua=15,Bóng đá=40,Bơi=25,Cầu lông=30'],
  [2,'Theo biểu đồ, tổng số sản phẩm bán được trong ba quý đầu năm là bao nhiêu?','1 050 sản phẩm','950 sản phẩm','1 150 sản phẩm','350 sản phẩm','@img:bieudo:cot:Quý 1=300,Quý 2=350,Quý 3=400'],
  [2,'Biểu đồ cột cho biết số cây của bốn lớp. Số cây lớp 5A chiếm bao nhiêu phần trăm tổng số cây?','25%','20%','30%','50%','@img:bieudo:cot:5A=50,5B=60,5C=40,5D=50'],
  [3,'Dựa vào biểu đồ cột về số ngày nắng trong 3 tháng, tính trung bình mỗi tháng và tỉ số phần trăm số ngày nắng tháng 6 so với tổng số ngày nắng ba tháng.','Tổng: 18 + 24 + 18 = 60 (ngày); trung bình 60 : 3 = 20 (ngày). Tỉ số phần trăm tháng 6: 24 : 60 = 0,4 = 40%.','@img:bieudo:cot:Th5=18,Th6=24,Th7=18'],
  [3,'Bảng cho biết kết quả tung đồng xu 20 lần. Tính tỉ số phần trăm số lần xuất hiện mặt sấp.','Mặt sấp 8 lần trong 20 lần: 8 : 20 = 0,4 = 40%.','@img:bang:Kết quả;Số lần|Mặt sấp;8|Mặt ngửa;12'],
  [4,'Biểu đồ cột cho biết số xe bán được của một cửa hàng trong 4 tháng. Nhận xét xu hướng, tính tỉ số phần trăm số xe tháng 4 so với tháng 1 và cho biết số xe tăng bao nhiêu phần trăm.','Số xe tăng dần: 20, 25, 30, 40. Tỉ số phần trăm tháng 4 so với tháng 1: 40 : 20 = 2 = 200%, tức tháng 4 bán gấp đôi tháng 1, tăng 100% so với tháng 1.','@img:bieudo:cot:Th1=20,Th2=25,Th3=30,Th4=40']
 ]);
 add(M,5,'★ Nâng cao: Tỉ số và các bài toán liên quan',[
  [2,'Phần tô màu của thanh chiếm bao nhiêu phần trăm cả thanh?','30%','3%','70%','40%','@img:phanso:3:10:thanh'],
  [2,'Thanh được chia thành các phần bằng nhau. Phần tô màu bằng bao nhiêu phần trăm?','75%','25%','50%','34%','@img:phanso:3:4:thanh'],
  [2,'Tỉ số giữa phần tô màu và phần chưa tô màu của thanh là bao nhiêu?','2 : 3','3 : 2','2 : 5','3 : 5','@img:phanso:2:5:thanh'],
  [3,'Thanh trong hình biểu thị 1 000 000 đồng tiền tiết kiệm của Lan, phần tô màu là số tiền Lan đã dùng. Lan đã dùng bao nhiêu phần trăm và bao nhiêu tiền?','Phần tô màu 4/10 = 40%. Số tiền đã dùng: 1 000 000 × 40 : 100 = 400 000 (đồng).','@img:phanso:4:10:thanh'],
  [4,'Thanh trong hình chia thành 5 phần bằng nhau, phần tô màu biểu thị số học sinh nữ của một lớp có 30 học sinh. Tính số học sinh nữ, số học sinh nam và tỉ số phần trăm của học sinh nam so với cả lớp. Giải thích cách làm.','Phần tô màu là 1/5 = 20%, nên số nữ: 30 × 20 : 100 = 6 (bạn); số nam: 30 - 6 = 24 (bạn). Tỉ số phần trăm nam so với cả lớp: 24 : 30 = 0,8 = 80% (hoặc 100% - 20% = 80%).','@img:phanso:1:5:thanh']
 ]);
 add(M,5,'★ Nâng cao: Số thập phân',[
  [2,'Nhiệt kế trong hình chỉ bao nhiêu độ C? Nếu nhiệt độ giảm 2,5 độ thì còn bao nhiêu?','25°C; còn 22,5°C','25°C; còn 23,5°C','20°C; còn 17,5°C','30°C; còn 27,5°C','@img:nhietke:25']
 ]);
 add(M,5,'★ Nâng cao: Các phép tính với số thập phân',[
  [3,'Bảng cho biết chiều cao của ba bạn. Hãy sắp xếp theo thứ tự từ thấp đến cao và tính bạn cao nhất hơn bạn thấp nhất bao nhiêu mét.','Thứ tự: Hà (1,38 m), Nam (1,42 m), Lan (1,45 m). Chênh lệch: 1,45 - 1,38 = 0,07 (m).','@img:bang:Bạn;Chiều cao|Nam;1,42 m|Lan;1,45 m|Hà;1,38 m'],
  [3,'Dựa vào bảng giá, tính số tiền mua 2,5 kg cam và 1,2 kg nho.','Cam: 35 000 × 2,5 = 87 500 (đồng). Nho: 120 000 × 1,2 = 144 000 (đồng). Tổng: 87 500 + 144 000 = 231 500 (đồng).','@img:bang:Mặt hàng;Giá 1 kg|Cam;35 000 đ|Nho;120 000 đ']
 ]);
 add(M,5,'★ Nâng cao: Một số đơn vị đo diện tích',[
  [2,'Hình chữ nhật trong hình có chiều dài 12 m, chiều rộng 5 m. Diện tích là bao nhiêu đề-xi-mét vuông?','6 000 dm²','60 dm²','600 dm²','60 000 dm²','@img:hcn:12:5:m'],
  [3,'Tính diện tích hình vuông trong hình (cạnh 30 m), rồi đổi ra héc-ta.','Diện tích: 30 × 30 = 900 (m²) = 0,09 ha.','@img:vuong:30:m']
 ]);
 add(M,5,'★ Nâng cao: Số đo thời gian. Vận tốc. Các bài toán chuyển động đều',[
  [2,'Đồng hồ chỉ giờ xe xuất phát (buổi sáng). Xe chạy 2 giờ 30 phút thì đến nơi. Xe đến nơi lúc mấy giờ?','9 giờ 15 phút','9 giờ 45 phút','8 giờ 45 phút','9 giờ 30 phút','@img:dongho:6:45'],
  [3,'Bảng cho biết quãng đường và thời gian đi của một ô tô. Tính vận tốc của ô tô.','Thời gian: 2 giờ 30 phút = 2,5 giờ. Vận tốc: 150 : 2,5 = 60 (km/giờ).','@img:bang:Quãng đường;Thời gian|150 km;2,5 giờ'],
  [4,'Đồng hồ chỉ lúc Nam bắt đầu đi bộ từ nhà (buổi chiều). Nam đi với vận tốc 4 km/giờ và đến nhà bạn lúc 15 giờ 50 phút. Tính quãng đường từ nhà Nam đến nhà bạn. Nêu rõ cách đổi đơn vị thời gian.','Đồng hồ chỉ 3 giờ 5 phút, buổi chiều là 15 giờ 5 phút. Thời gian đi: 15 giờ 50 phút - 15 giờ 5 phút = 45 phút = 0,75 giờ (45 : 60). Quãng đường: 4 × 0,75 = 3 (km).','@img:dongho:3:5']
 ]);
 add(M,5,'Hình học và đo lường',[
  [2,'Diện tích hình tam giác trong hình là bao nhiêu?','20 cm²','40 cm²','13 cm²','16 cm²','@img:tamgiac:8:5'],
  [3,'Tính diện tích hình thang trong hình (đáy lớn 10 cm, đáy bé 6 cm, chiều cao 5 cm).','(10 + 6) × 5 : 2 = 40 (cm²).','@img:thang:10:6:5']
 ]);
 add(M,5,'★ Nâng cao: Ôn tập và bổ sung',[
  [2,'Phần tô màu của hình tròn biểu thị phân số nào? Viết dưới dạng phân số thập phân.','4/5 = 8/10','4/5 = 4/10','1/5 = 2/10','5/4 = 10/8','@img:phanso:4:5']
 ]);
 add(M,5,'★ Nâng cao: Ôn tập học kì 1',[
  [3,'Hình tròn trong hình có đường kính 4 cm. Tính chu vi và diện tích.','Bán kính 2 cm. Chu vi: 4 × 3,14 = 12,56 (cm). Diện tích: 2 × 2 × 3,14 = 12,56 (cm²).','@img:tron:4']
 ]);
 add(M,5,'★ Nâng cao: Ôn tập cuối năm',[
  [2,'Diện tích hình thang trong hình là bao nhiêu?','45 cm²','90 cm²','30 cm²','27 cm²','@img:thang:11:7:5'],
  [4,'Hình tam giác trong hình có đáy 12 cm, chiều cao 9 cm. Tính diện tích. Nếu một hình chữ nhật có cùng diện tích và chiều rộng 6 cm thì chiều dài bao nhiêu? Giải thích.','Diện tích tam giác: 12 × 9 : 2 = 54 (cm²). Hình chữ nhật diện tích 54 cm², chiều rộng 6 cm thì chiều dài 54 : 6 = 9 (cm), vì diện tích hình chữ nhật bằng dài nhân rộng nên dài bằng diện tích chia rộng.','@img:tamgiac:12:9']
 ]);
})();
