/* ============================================================
   NGÂN HÀNG CÂU HỎI NÂNG CAO (BỒI DƯỠNG HSG) – tất cả mức 4
   Soạn theo chủ đề SGK Kết nối tri thức. Bắt đầu: môn TOÁN (lớp 1–9).
   Mỗi chủ đề 5–6 câu. Hiện trong: Bồi dưỡng HS giỏi, Đề (mức 4), Phiếu.
   Định dạng: TN [4,'câu','ĐÚNG','sai','sai','sai'] ; TL [4,'câu','đáp án']
   ============================================================ */
(function(){
 if(typeof NH==='undefined')return;
 const push=(mon,lop,cd,q)=>{if(!NH[mon])NH[mon]={};if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];NH[mon][lop].push({cd:'★ Nâng cao: '+cd,q:q,_nc:true});};

 /* ==================== TOÁN LỚP 1 ==================== */
 push('Toán',1,'Các số từ 0 đến 10',[
  [4,'Số lớn nhất có một chữ số là số nào?','9','10','8','0'],
  [4,'Có bao nhiêu số lớn hơn 5 và bé hơn 10?','4','3','5','6'],
  [4,'Em hãy viết các số 7, 2, 9, 4, 0 theo thứ tự từ bé đến lớn.','0, 2, 4, 7, 9'],
  [4,'Số liền trước của số liền sau số 6 là số nào?','6'],
  [4,'Bạn An có 8 cái kẹo, bạn An nhiều hơn bạn Bình 3 cái. Hỏi bạn Bình có mấy cái kẹo?','5 cái'],
  [4,'Từ các số 1, 0, 5 em viết được số có hai chữ số lớn nhất là bao nhiêu?','51'],
 ]);
 push('Toán',1,'Làm quen với một số hình phẳng',[
  [4,'Hình vuông có mấy cạnh bằng nhau?','4','3','2','0'],
  [4,'Vẽ 2 hình tam giác ghép lại có thể tạo thành hình gì có 4 cạnh?','Hình vuông (hoặc hình chữ nhật)'],
  [4,'Một hình có 3 cạnh thẳng là hình gì?','Hình tam giác'],
  [4,'Em đếm xem có bao nhiêu hình tam giác nếu chia một hình vuông bằng một đường chéo?','2 hình'],
  [4,'Hình tròn có cạnh thẳng không?','Không (hình tròn không có cạnh thẳng)'],
 ]);
 push('Toán',1,'Phép cộng, phép trừ trong phạm vi 10',[
  [4,'Tìm số còn thiếu: 4 + ? = 9.','5'],
  [4,'Tìm số còn thiếu: ? − 3 = 4.','7'],
  [4,'Lan có 10 bông hoa, Lan cho Mai 2 bông, cho Hà 3 bông. Lan còn mấy bông?','5 bông'],
  [4,'Tổng của hai số là 7. Nếu một số là 0 thì số kia là bao nhiêu?','7'],
  [4,'Điền dấu +, − thích hợp: 8 ? 3 = 5.','− (dấu trừ)'],
  [4,'Có 3 + 4 = 7. Vậy 4 + 3 bằng mấy?','7'],
 ]);
 push('Toán',1,'Làm quen với một số hình khối',[
  [4,'Khối lập phương có mấy mặt?','6','4','8','2'],
  [4,'Quả bóng có dạng khối gì?','Khối cầu'],
  [4,'Hộp phấn (hộp chữ nhật) có dạng khối gì?','Khối hộp chữ nhật'],
  [4,'Xếp 2 khối lập phương cạnh nhau được một khối có dạng gì?','Khối hộp chữ nhật'],
  [4,'Khối lập phương và khối hộp chữ nhật đều có mấy mặt?','6 mặt'],
 ]);
 push('Toán',1,'Ôn tập học kì 1',[
  [4,'Tính nhanh: 2 + 3 + 4 + 1 = ?','10'],
  [4,'Số nào cộng với 5 thì được 10?','5'],
  [4,'Có 9 con chim đậu trên cành, bay đi 4 con rồi bay đến 2 con. Trên cành còn mấy con?','7 con'],
  [4,'Viết số lớn nhất có hai chữ số khác nhau tạo từ 3 và 8.','83'],
  [4,'Từ 0 đến 9 có bao nhiêu số bé hơn 4?','4 số (0, 1, 2, 3)'],
 ]);
 push('Toán',1,'Các số đến 100',[
  [4,'Số 47 gồm mấy chục và mấy đơn vị?','4 chục 7 đơn vị'],
  [4,'Số liền sau số lớn nhất có hai chữ số là số nào?','100'],
  [4,'Có bao nhiêu số tròn chục bé hơn 100?','9 số (10, 20, …, 90)'],
  [4,'Số gồm 6 chục và 0 đơn vị là số nào?','60'],
  [4,'Sắp xếp 35, 53, 30, 50 từ lớn đến bé.','53, 50, 35, 30'],
  [4,'Số chẵn lớn nhất có hai chữ số là số nào?','98'],
 ]);
 push('Toán',1,'Độ dài và đo độ dài',[
  [4,'Bút chì dài 10 cm, gãy mất 3 cm. Bút chì còn dài bao nhiêu xăng-ti-mét?','7 cm'],
  [4,'Băng giấy dài 20 cm cắt thành 2 đoạn, một đoạn dài 12 cm. Đoạn kia dài bao nhiêu?','8 cm'],
  [4,'Đoạn thẳng AB dài 5 cm, đoạn BC dài 4 cm (A, B, C thẳng hàng). AC dài bao nhiêu?','9 cm'],
  [4,'1 gang tay của em đo được 15 cm. Hai gang tay đo được bao nhiêu xăng-ti-mét?','30 cm'],
  [4,'Que tính A dài 8 cm, que B dài hơn que A 5 cm. Que B dài bao nhiêu?','13 cm'],
 ]);
 push('Toán',1,'Phép cộng, phép trừ (không nhớ) trong phạm vi 100',[
  [4,'Tính: 34 + 25 = ?','59'],
  [4,'Tính: 78 − 43 = ?','35'],
  [4,'Tìm số còn thiếu: 25 + ? = 69.','44'],
  [4,'Nhà An có 45 con gà và 24 con vịt. Nhà An có tất cả bao nhiêu con?','69 con'],
  [4,'Một cửa hàng có 88 quyển vở, bán 56 quyển. Cửa hàng còn bao nhiêu quyển?','32 quyển'],
  [4,'Tính nhanh: 20 + 14 + 30 = ?','64'],
 ]);
 push('Toán',1,'Thời gian, giờ và lịch',[
  [4,'Bây giờ là 8 giờ. Sau 3 giờ nữa là mấy giờ?','11 giờ'],
  [4,'Một tuần có mấy ngày?','7 ngày'],
  [4,'Hôm nay là thứ Ba. Hỏi 2 ngày sau là thứ mấy?','Thứ Năm'],
  [4,'Kim ngắn chỉ số 9, kim dài chỉ số 12 thì là mấy giờ?','9 giờ'],
  [4,'Em ngủ lúc 9 giờ tối và dậy lúc 6 giờ sáng. Em ngủ bao nhiêu giờ?','9 giờ'],
 ]);
 push('Toán',1,'Ôn tập cuối năm',[
  [4,'Tính nhanh: 10 + 20 + 30 + 40 = ?','100'],
  [4,'Số lớn nhất có hai chữ số trừ số bé nhất có hai chữ số bằng bao nhiêu?','89'],
  [4,'An có 56 viên bi, cho em 24 viên rồi được anh cho thêm 10 viên. An có bao nhiêu viên?','42 viên'],
  [4,'Có bao nhiêu số có hai chữ số mà chữ số hàng chục bằng chữ số hàng đơn vị?','9 số (11, 22, …, 99)'],
  [4,'Viết tất cả các số tròn chục lớn hơn 50 và bé hơn 90.','60, 70, 80'],
 ]);

 /* ==================== TOÁN LỚP 2 ==================== */
 push('Toán',2,'Ôn tập và bổ sung',[
  [4,'Tính nhanh: 15 + 23 + 5 + 7 = ?','50'],
  [4,'Số lớn nhất có hai chữ số khác nhau là số nào?','98'],
  [4,'Tìm x: x − 18 = 27.','x = 45'],
  [4,'Từ ba chữ số 0, 4, 7 viết được số có ba chữ số lớn nhất là bao nhiêu?','740'],
  [4,'Tổng hai số là 46, số lớn hơn số bé 10 đơn vị. Tìm hai số đó.','28 và 18'],
  [4,'Dãy số 2, 4, 6, 8, … Số thứ 10 trong dãy là số nào?','20'],
 ]);
 push('Toán',2,'Phép cộng, phép trừ trong phạm vi 20',[
  [4,'Tính nhanh: 9 + 8 + 1 + 2 = ?','20'],
  [4,'Tìm x: 17 − x = 9.','x = 8'],
  [4,'Hùng có 15 viên bi, cho Nam 7 viên rồi được thêm 6 viên. Hùng có bao nhiêu viên?','14 viên'],
  [4,'Hai số có tổng là 18 và hiệu là 4. Tìm hai số đó.','11 và 7'],
  [4,'Điền dấu thích hợp để được 12: 7 ? 8 ? 3.','7 + 8 − 3'],
 ]);
 push('Toán',2,'Làm quen với khối lượng, dung tích',[
  [4,'Một túi gạo nặng 5 kg, một túi đường nặng 2 kg. Cả hai túi nặng bao nhiêu ki-lô-gam?','7 kg'],
  [4,'Can 10 lít đang chứa đầy nước, rót ra 4 lít. Trong can còn mấy lít?','6 lít'],
  [4,'Quả bí nặng 3 kg, quả bí nặng hơn quả bầu 1 kg. Hai quả nặng tất cả bao nhiêu?','5 kg'],
  [4,'Có 3 chai nước, mỗi chai 2 lít. Tất cả có bao nhiêu lít?','6 lít'],
  [4,'Mẹ mua 8 kg cam chia đều vào 2 túi. Mỗi túi nặng bao nhiêu ki-lô-gam?','4 kg'],
 ]);
 push('Toán',2,'Phép cộng, phép trừ (có nhớ) trong phạm vi 100',[
  [4,'Tính: 47 + 38 = ?','85'],
  [4,'Tìm x: x − 29 = 46.','x = 75'],
  [4,'Lớp 2A có 36 học sinh, lớp 2B nhiều hơn lớp 2A 7 bạn. Cả hai lớp có bao nhiêu học sinh?','79 học sinh'],
  [4,'Một số cộng với 28 được 63. Tìm số đó.','35'],
  [4,'Tính nhanh: 28 + 35 + 72 = ?','135'],
  [4,'Mảnh vải dài 90 cm, cắt đi 2 lần mỗi lần 25 cm. Còn lại bao nhiêu xăng-ti-mét?','40 cm'],
 ]);
 push('Toán',2,'Làm quen với hình phẳng',[
  [4,'Hình tứ giác có mấy cạnh và mấy đỉnh?','4 cạnh và 4 đỉnh'],
  [4,'Một hình vuông được chia bởi 2 đường chéo thì tạo thành mấy hình tam giác?','4 hình tam giác'],
  [4,'Có 3 điểm không thẳng hàng thì nối được mấy đoạn thẳng?','3 đoạn thẳng'],
  [4,'Đường gấp khúc gồm 3 đoạn, mỗi đoạn dài 4 cm. Đường gấp khúc dài bao nhiêu?','12 cm'],
  [4,'Có 4 điểm trên một đường thẳng. Có bao nhiêu đoạn thẳng được tạo thành?','6 đoạn thẳng'],
 ]);
 push('Toán',2,'Ngày – giờ, giờ – phút, ngày – tháng',[
  [4,'Bây giờ là 7 giờ 30 phút. Sau 1 giờ 30 phút nữa là mấy giờ?','9 giờ'],
  [4,'Một ngày có mấy giờ?','24 giờ'],
  [4,'Tháng 2 năm thường có bao nhiêu ngày?','28 ngày'],
  [4,'Hôm nay là ngày 28 tháng 4. Hỏi 5 ngày sau là ngày nào?','Ngày 3 tháng 5'],
  [4,'Phim bắt đầu lúc 8 giờ và kéo dài 2 giờ. Phim kết thúc lúc mấy giờ?','10 giờ'],
 ]);
 push('Toán',2,'Ôn tập học kì 1',[
  [4,'Tính nhanh: 25 + 47 + 75 + 53 = ?','200'],
  [4,'Tìm x: x + 19 = 52.','x = 33'],
  [4,'Số bé nhất có ba chữ số khác nhau là số nào?','102'],
  [4,'Hai số có tổng 50, nếu số lớn bớt 6 thì bằng số bé. Tìm hai số.','28 và 22'],
  [4,'An hơn Bình 5 tuổi, Bình 8 tuổi. Tổng số tuổi hai bạn là bao nhiêu?','21 tuổi'],
 ]);
 push('Toán',2,'Phép nhân, phép chia',[
  [4,'Tính: 5 × 4 + 5 = ?','25'],
  [4,'Tìm x: x × 3 = 18.','x = 6'],
  [4,'Có 20 cái kẹo chia đều cho 5 bạn. Mỗi bạn được mấy cái?','4 cái'],
  [4,'Mỗi bàn có 2 học sinh. Hỏi 9 bàn có bao nhiêu học sinh?','18 học sinh'],
  [4,'Tìm x: x : 4 = 5.','x = 20'],
  [4,'Một tá bút có 12 cái. Hỏi 3 tá bút có bao nhiêu cái?','36 cái'],
 ]);
 push('Toán',2,'Làm quen với hình khối',[
  [4,'Khối lập phương có mấy đỉnh?','8 đỉnh'],
  [4,'Xếp 4 khối lập phương nhỏ bằng nhau thành một hàng. Khối tạo thành có dạng gì?','Khối hộp chữ nhật'],
  [4,'Một khối hộp chữ nhật có mấy mặt, mấy đỉnh?','6 mặt và 8 đỉnh'],
  [4,'Cần mấy khối lập phương nhỏ để xếp đầy một khối hộp dài 3, rộng 1, cao 1?','3 khối'],
  [4,'Khối lập phương có mấy cạnh?','12 cạnh'],
 ]);
 push('Toán',2,'Các số trong phạm vi 1000',[
  [4,'Số 605 gồm mấy trăm, mấy chục, mấy đơn vị?','6 trăm, 0 chục, 5 đơn vị'],
  [4,'Số liền sau số lớn nhất có ba chữ số là số nào?','1000'],
  [4,'Viết số lớn nhất có ba chữ số khác nhau từ 3, 0, 9.','930'],
  [4,'Có bao nhiêu số tròn trăm bé hơn 1000?','9 số (100, …, 900)'],
  [4,'Sắp xếp 305, 350, 503, 530 từ lớn đến bé.','530, 503, 350, 305'],
  [4,'Số chẵn lớn nhất có ba chữ số là số nào?','998'],
 ]);
 push('Toán',2,'Độ dài và đơn vị đo độ dài. Tiền Việt Nam',[
  [4,'1 m = 100 cm. Hỏi 3 m 5 cm bằng bao nhiêu xăng-ti-mét?','305 cm'],
  [4,'Em có 1 tờ 2000 đồng và 2 tờ 1000 đồng. Em có tất cả bao nhiêu tiền?','4000 đồng'],
  [4,'Mua bút 3000 đồng, đưa tờ 5000 đồng. Được trả lại bao nhiêu?','2000 đồng'],
  [4,'Đoạn dây dài 2 m, cắt đi 70 cm. Còn lại bao nhiêu xăng-ti-mét?','130 cm'],
  [4,'Có 10000 đồng mua 2 quyển vở mỗi quyển 4000 đồng. Còn lại bao nhiêu?','2000 đồng'],
 ]);
 push('Toán',2,'Phép cộng, phép trừ trong phạm vi 1000',[
  [4,'Tính: 456 + 237 = ?','693'],
  [4,'Tìm x: x − 145 = 328.','x = 473'],
  [4,'Một kho có 750 bao gạo, chuyển đi 280 bao rồi nhập thêm 150 bao. Kho còn bao nhiêu bao?','620 bao'],
  [4,'Tính nhanh: 198 + 203 + 2 = ?','403'],
  [4,'Tổng hai số là 500, số lớn hơn số bé 100. Tìm hai số.','300 và 200'],
 ]);
 push('Toán',2,'Làm quen với yếu tố thống kê, xác suất',[
  [4,'Tổ 1 trồng 8 cây, tổ 2 trồng 5 cây, tổ 3 trồng 7 cây. Trung bình… à, cả ba tổ trồng mấy cây?','20 cây'],
  [4,'Bảng số liệu: An 6 điểm 10, Bình 4 điểm 10, Chi 8 điểm 10. Ai nhiều điểm 10 nhất?','Chi'],
  [4,'Tung một đồng xu, có mấy khả năng xảy ra (mặt ngửa hay sấp)?','2 khả năng'],
  [4,'Trong hộp có 3 bi đỏ, 0 bi xanh. Lấy 1 viên, chắc chắn lấy được bi màu gì?','Bi đỏ'],
  [4,'Tổ 1 có 9 bạn, tổ 2 ít hơn tổ 1 là 2 bạn. Cả hai tổ có bao nhiêu bạn?','16 bạn'],
 ]);
 push('Toán',2,'Ôn tập cuối năm',[
  [4,'Tính nhanh: 125 + 437 + 75 + 63 = ?','700'],
  [4,'Tìm x: x × 5 = 45.','x = 9'],
  [4,'Có 36 học sinh xếp đều thành 4 hàng. Mỗi hàng có mấy bạn?','9 bạn'],
  [4,'Hai số có tổng 84 và hiệu 20. Tìm hai số.','52 và 32'],
  [4,'Một số nhân 4 rồi cộng 8 thì được 28. Tìm số đó.','5'],
  [4,'Từ 100 đến 200 có bao nhiêu số tròn chục?','11 số'],
 ]);
})();
(function(){
 if(typeof NH==='undefined')return;
 const push=(mon,lop,cd,q)=>{if(!NH[mon])NH[mon]={};if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];NH[mon][lop].push({cd:'★ Nâng cao: '+cd,q:q,_nc:true});};

 /* ==================== TOÁN LỚP 3 ==================== */
 push('Toán',3,'Ôn tập và bổ sung',[
  [4,'Tìm x: x − 275 = 418.','x = 693'],
  [4,'Tính nhanh: 268 + 135 + 32 + 65 = ?','500'],
  [4,'Hai số có tổng 640, số lớn gấp 3 lần số bé. Tìm hai số.','480 và 160'],
  [4,'Số lớn nhất có ba chữ số khác nhau trừ số bé nhất có ba chữ số khác nhau bằng bao nhiêu?','885'],
  [4,'Một cửa hàng ngày đầu bán 345 kg gạo, ngày sau bán nhiều hơn 80 kg. Cả hai ngày bán bao nhiêu?','770 kg'],
 ]);
 push('Toán',3,'Bảng nhân, bảng chia',[
  [4,'Tính: 7 × 8 − 6 × 5 = ?','26'],
  [4,'Tìm x: x × 6 = 54.','x = 9'],
  [4,'Có 48 quả cam xếp đều vào các đĩa, mỗi đĩa 6 quả. Cần bao nhiêu đĩa?','8 đĩa'],
  [4,'Một số chia cho 7 được 8 dư 3. Tìm số đó.','59'],
  [4,'Tính nhanh: 9 × 7 + 9 × 3 = ?','90'],
  [4,'Tìm x: 63 : x = 9.','x = 7'],
 ]);
 push('Toán',3,'Làm quen với hình phẳng, hình khối',[
  [4,'Một hình chữ nhật có chiều dài 8 cm, chiều rộng 3 cm. Chu vi của nó là bao nhiêu?','22 cm'],
  [4,'Hình vuông có cạnh 6 cm thì chu vi là bao nhiêu?','24 cm'],
  [4,'Trong một hình có 5 điểm, cứ 2 điểm nối thành một đoạn thẳng thì có mấy đoạn (các điểm không thẳng hàng)?','10 đoạn thẳng'],
  [4,'Khối lập phương có 6 mặt đều là hình gì?','Hình vuông'],
  [4,'Một hình chữ nhật có chu vi 20 cm, chiều dài 6 cm. Chiều rộng là bao nhiêu?','4 cm'],
 ]);
 push('Toán',3,'Phép nhân, phép chia trong phạm vi 100',[
  [4,'Tính: 24 × 3 + 15 = ?','87'],
  [4,'Tìm x: x : 4 = 12.','x = 48'],
  [4,'Có 96 học sinh xếp đều thành 4 hàng. Mỗi hàng bao nhiêu bạn?','24 bạn'],
  [4,'Một số nhân 5 rồi bớt 8 thì được 42. Tìm số đó.','10'],
  [4,'Chia 85 cái bánh cho mỗi hộp 4 cái. Được bao nhiêu hộp và thừa mấy cái?','21 hộp, thừa 1 cái'],
 ]);
 push('Toán',3,'Một số đơn vị đo độ dài, khối lượng, dung tích, nhiệt độ',[
  [4,'1 km = 1000 m. Hỏi 2 km 50 m bằng bao nhiêu mét?','2050 m'],
  [4,'Một bao gạo nặng 25 kg. Hỏi 4 bao như thế nặng bao nhiêu ki-lô-gam?','100 kg'],
  [4,'Thùng chứa 30 lít dầu, rót đều vào 6 can. Mỗi can bao nhiêu lít?','5 lít'],
  [4,'Nhiệt độ buổi sáng 24°C, buổi trưa tăng thêm 9°C. Nhiệt độ buổi trưa là bao nhiêu?','33°C'],
  [4,'Đổi: 5 m 3 cm = ? cm.','503 cm'],
 ]);
 push('Toán',3,'Phép nhân, phép chia trong phạm vi 1000',[
  [4,'Tính: 123 × 4 = ?','492'],
  [4,'Tìm x: x : 5 = 164.','x = 820'],
  [4,'Chia 725 cho 5 được kết quả là bao nhiêu?','145'],
  [4,'Một xe chở 215 kg hàng. Hỏi 3 xe như thế chở bao nhiêu ki-lô-gam?','645 kg'],
  [4,'Một số nhân 6 được 834. Tìm số đó.','139'],
 ]);
 push('Toán',3,'Ôn tập học kì 1',[
  [4,'Tính nhanh: 25 × 4 × 7 = ?','700'],
  [4,'Tìm x: x × 8 = 648.','x = 81'],
  [4,'Hai số có tổng 480, số lớn gấp 5 lần số bé. Tìm số bé.','80'],
  [4,'Một đội trồng 356 cây ngày đầu, ngày sau trồng gấp đôi. Cả hai ngày trồng bao nhiêu cây?','1068 cây'],
  [4,'Có 6 thùng, mỗi thùng 48 chai. Chia đều số chai vào 8 kệ thì mỗi kệ mấy chai?','36 chai'],
 ]);
 push('Toán',3,'Các số đến 10 000',[
  [4,'Số 7049 gồm mấy nghìn, mấy trăm, mấy chục, mấy đơn vị?','7 nghìn, 0 trăm, 4 chục, 9 đơn vị'],
  [4,'Viết số lớn nhất có bốn chữ số khác nhau.','9876'],
  [4,'Số liền sau số lớn nhất có bốn chữ số là số nào?','10000'],
  [4,'Từ các chữ số 2, 5, 0, 8 viết số bé nhất có bốn chữ số khác nhau.','2058'],
  [4,'Có bao nhiêu số tròn nghìn bé hơn 10000?','9 số'],
  [4,'Số chẵn lớn nhất có bốn chữ số khác nhau là số nào?','9876'],
 ]);
 push('Toán',3,'Chu vi, diện tích một số hình phẳng',[
  [4,'Hình chữ nhật dài 12 cm, rộng 5 cm. Diện tích là bao nhiêu?','60 cm²'],
  [4,'Hình vuông cạnh 7 cm. Diện tích là bao nhiêu?','49 cm²'],
  [4,'Hình chữ nhật có diện tích 48 cm², chiều rộng 6 cm. Chiều dài là bao nhiêu?','8 cm'],
  [4,'Một hình vuông có chu vi 36 cm. Diện tích của nó là bao nhiêu?','81 cm²'],
  [4,'Hình chữ nhật dài 9 cm, rộng 4 cm. Hiệu giữa chu vi và diện tích là bao nhiêu?','Chu vi 26 cm, diện tích 36 cm²; diện tích hơn chu vi 10'],
 ]);
 push('Toán',3,'Cộng, trừ, nhân, chia trong phạm vi 10 000',[
  [4,'Tính: 3456 + 2178 = ?','5634'],
  [4,'Tìm x: x − 1234 = 2766.','x = 4000'],
  [4,'Tính: 2048 × 3 = ?','6144'],
  [4,'Chia 8064 cho 8 được bao nhiêu?','1008'],
  [4,'Một kho có 6250 kg hàng, xuất 2 lần mỗi lần 1480 kg. Kho còn bao nhiêu?','3290 kg'],
 ]);
 push('Toán',3,'Các số đến 100 000',[
  [4,'Số 60507 gồm mấy chục nghìn, nghìn, trăm, chục, đơn vị?','6 chục nghìn, 0 nghìn, 5 trăm, 0 chục, 7 đơn vị'],
  [4,'Viết số lớn nhất có năm chữ số khác nhau.','98765'],
  [4,'Số liền trước số 70000 là số nào?','69999'],
  [4,'Sắp xếp 35200, 35020, 53002, 30502 từ bé đến lớn.','30502, 35020, 35200, 53002'],
  [4,'Số tròn chục nghìn lớn nhất bé hơn 100000 là số nào?','90000'],
 ]);
 push('Toán',3,'Cộng, trừ trong phạm vi 100 000',[
  [4,'Tính: 45678 + 23456 = ?','69134'],
  [4,'Tìm x: x − 12345 = 54321.','x = 66666'],
  [4,'Tính nhanh: 29999 + 30001 = ?','60000'],
  [4,'Một nhà máy sản xuất 42500 sản phẩm, bán 2 đợt mỗi đợt 15000. Còn lại bao nhiêu?','12500 sản phẩm'],
  [4,'Hai số có tổng 90000, số lớn hơn số bé 20000. Tìm hai số.','55000 và 35000'],
 ]);
 push('Toán',3,'Xem đồng hồ. Tháng – năm. Tiền Việt Nam',[
  [4,'Bây giờ là 9 giờ 45 phút. Sau 30 phút nữa là mấy giờ, mấy phút?','10 giờ 15 phút'],
  [4,'Một năm thường có bao nhiêu ngày?','365 ngày'],
  [4,'Tháng nào trong năm có 28 hoặc 29 ngày?','Tháng 2'],
  [4,'Mua 3 quyển vở mỗi quyển 7000 đồng, đưa tờ 50000 đồng. Được trả lại bao nhiêu?','29000 đồng'],
  [4,'Từ 8 giờ 20 phút đến 9 giờ 5 phút là bao nhiêu phút?','45 phút'],
 ]);
 push('Toán',3,'Nhân, chia trong phạm vi 100 000',[
  [4,'Tính: 12345 × 4 = ?','49380'],
  [4,'Chia 84000 cho 6 được bao nhiêu?','14000'],
  [4,'Một kho có 21500 kg, xếp đều vào 5 ô. Mỗi ô bao nhiêu ki-lô-gam?','4300 kg'],
  [4,'Tìm x: x × 7 = 63000.','x = 9000'],
  [4,'Chia 95000 cho 4 được thương và số dư là bao nhiêu?','Thương 23750, dư 0'],
 ]);
 push('Toán',3,'Làm quen với yếu tố thống kê, xác suất',[
  [4,'Ba lớp quyên góp: 3A 45 quyển, 3B 38 quyển, 3C 52 quyển. Cả ba lớp bao nhiêu quyển?','135 quyển'],
  [4,'Số HS giỏi của tổ 1, 2, 3 là 6, 9, 3. Tổ nào nhiều nhất và hơn tổ ít nhất bao nhiêu?','Tổ 2 nhiều nhất, hơn tổ 3 là 6 bạn'],
  [4,'Trong hộp có 4 bi đỏ và 6 bi xanh. Lấy 1 viên, màu nào có khả năng xảy ra nhiều hơn?','Màu xanh'],
  [4,'Gieo một con xúc xắc, có bao nhiêu kết quả có thể xảy ra?','6 kết quả'],
  [4,'Bảng số liệu điểm 10 cả tuần: 5, 7, 4, 8, 6. Cả tuần được bao nhiêu điểm 10?','30 điểm 10'],
 ]);
 push('Toán',3,'Ôn tập cuối năm',[
  [4,'Tính nhanh: 1250 × 8 × 0 + 2345 = ?','2345'],
  [4,'Tìm x: x : 9 = 1234.','x = 11106'],
  [4,'Hai số có tổng 7200, số lớn gấp 3 lần số bé. Tìm số lớn.','5400'],
  [4,'Một mảnh đất hình chữ nhật dài 25 m, rộng 16 m. Chu vi và diện tích là bao nhiêu?','Chu vi 82 m, diện tích 400 m²'],
  [4,'Có 2436 kg gạo chia đều vào 6 xe. Mỗi xe chở bao nhiêu ki-lô-gam?','406 kg'],
 ]);

 /* ==================== TOÁN LỚP 4 ==================== */
 push('Toán',4,'Ôn tập và bổ sung',[
  [4,'Tìm x: (x − 125) × 4 = 1200.','x = 425'],
  [4,'Tính nhanh: 125 × 8 × 9 = ?','9000'],
  [4,'Hai số có tổng 2024 và hiệu 468. Tìm số lớn.','1246'],
  [4,'Trung bình cộng của 4 số là 75. Biết 3 số đầu là 60, 80, 90. Tìm số thứ tư.','70'],
  [4,'Tổng hai số là 936, số lớn gấp 5 lần số bé. Tìm hai số.','780 và 156'],
 ]);
 push('Toán',4,'Góc và đơn vị đo góc',[
  [4,'Góc vuông có số đo bao nhiêu độ?','90°'],
  [4,'Một góc bẹt bằng bao nhiêu độ?','180°'],
  [4,'Hai góc phụ nhau, một góc 35°. Góc kia bao nhiêu độ?','55°'],
  [4,'Kim giờ và kim phút lúc 3 giờ tạo thành góc gì?','Góc vuông (90°)'],
  [4,'Một góc tù có số đo lớn hơn bao nhiêu độ và bé hơn bao nhiêu độ?','Lớn hơn 90° và bé hơn 180°'],
 ]);
 push('Toán',4,'Số có nhiều chữ số',[
  [4,'Viết số lớn nhất có sáu chữ số khác nhau.','987654'],
  [4,'Số 5 triệu 40 nghìn 7 đơn vị viết là số nào?','5040007'],
  [4,'Trong số 73 905 416, chữ số 3 có giá trị bao nhiêu?','3 000 000'],
  [4,'Số liền sau số lớn nhất có bảy chữ số là số nào?','10000000'],
  [4,'Làm tròn số 486 729 đến hàng nghìn.','487000'],
  [4,'Từ các chữ số 0, 3, 5, 9 viết số chẵn bé nhất có bốn chữ số khác nhau.','3590'],
 ]);
 push('Toán',4,'Một số đơn vị đo đại lượng',[
  [4,'Đổi: 3 tấn 50 kg = ? kg.','3050 kg'],
  [4,'Đổi: 2 giờ 15 phút = ? phút.','135 phút'],
  [4,'Đổi: 5 km² = ? m² không cần, hãy đổi 4 phút 30 giây = ? giây.','270 giây'],
  [4,'Một bao xi măng nặng 50 kg. Hỏi 24 bao nặng mấy tạ?','12 tạ'],
  [4,'Đổi: 7 thế kỉ = ? năm.','700 năm'],
 ]);
 push('Toán',4,'Phép cộng và phép trừ',[
  [4,'Tìm x: x − 3456 = 7890.','x = 11346'],
  [4,'Tính nhanh: 2975 + 4017 + 25 + 983 = ?','8000'],
  [4,'Hai số có tổng 15000, nếu số lớn bớt 2000 thì bằng số bé. Tìm hai số.','8500 và 6500'],
  [4,'Một trang trại thu 12450 kg thóc vụ một, vụ hai nhiều hơn 3600 kg. Cả hai vụ bao nhiêu?','28500 kg'],
  [4,'Tổng của ba số là 10000, số thứ nhất 3200, số thứ hai 4500. Tìm số thứ ba.','2300'],
 ]);
 push('Toán',4,'Đường thẳng vuông góc. Đường thẳng song song',[
  [4,'Hai đường thẳng vuông góc tạo với nhau mấy góc vuông?','4 góc vuông'],
  [4,'Hình chữ nhật có mấy cặp cạnh song song?','2 cặp'],
  [4,'Hình vuông cạnh 5 cm có chu vi và diện tích là bao nhiêu?','Chu vi 20 cm, diện tích 25 cm²'],
  [4,'Trong hình chữ nhật, hai cạnh dài có song song với nhau không?','Có, chúng song song'],
  [4,'Một hình chữ nhật có chiều dài gấp đôi chiều rộng, chu vi 48 cm. Tìm chiều dài.','16 cm'],
 ]);
 push('Toán',4,'Ôn tập học kì 1',[
  [4,'Tìm x: x × 6 − 150 = 1200.','x = 225'],
  [4,'Trung bình cộng của 5 số là 48. Tổng của chúng là bao nhiêu?','240'],
  [4,'Hai số có tổng 1800 và hiệu 240. Tìm số bé.','780'],
  [4,'Một hình chữ nhật có chu vi 120 m, chiều dài hơn chiều rộng 20 m. Tìm diện tích.','Dài 40 m, rộng 20 m; diện tích 800 m²'],
  [4,'Tính nhanh: 96 × 25 = ?','2400'],
 ]);
 push('Toán',4,'Phép nhân, phép chia',[
  [4,'Tính: 234 × 56 = ?','13104'],
  [4,'Chia 9408 cho 24 được bao nhiêu?','392'],
  [4,'Tìm x: x × 15 = 3450.','x = 230'],
  [4,'Một đoàn xe 18 chiếc, mỗi chiếc chở 125 bao. Cả đoàn chở bao nhiêu bao?','2250 bao'],
  [4,'Chia 5377 cho 7 được thương và dư bao nhiêu?','Thương 768, dư 1'],
  [4,'Tính nhanh: 125 × 32 × 25 = ?','100000'],
 ]);
 push('Toán',4,'Làm quen với yếu tố thống kê, xác suất',[
  [4,'Biểu đồ: 4A 120 cây, 4B 150 cây, 4C 90 cây. Trung bình mỗi lớp trồng bao nhiêu cây?','120 cây'],
  [4,'Số HS 3 khối là 240, 180, 300. Khối đông nhất hơn khối ít nhất bao nhiêu?','120 học sinh'],
  [4,'Gieo một xúc xắc, khả năng ra số lớn hơn 4 gồm những số nào?','Số 5 và 6'],
  [4,'Trong hộp có 10 thẻ đánh số 1–10. Lấy 1 thẻ, có mấy khả năng ra số chẵn?','5 khả năng (2,4,6,8,10)'],
  [4,'Nhiệt độ 5 ngày: 28, 30, 29, 31, 32 (°C). Nhiệt độ trung bình là bao nhiêu?','30°C'],
 ]);
 push('Toán',4,'Phân số',[
  [4,'Rút gọn phân số 24/36 về tối giản.','2/3'],
  [4,'So sánh 3/4 và 5/7 (phân số nào lớn hơn)?','3/4'],
  [4,'Quy đồng mẫu số 2/3 và 3/5 rồi cho biết tổng tử số sau quy đồng.','10/15 và 9/15; tổng tử số 19'],
  [4,'Phân số nào bằng 4/5 và có mẫu số là 20?','16/20'],
  [4,'Một lớp có 2/5 số học sinh là nam, biết có 12 nam. Lớp có bao nhiêu học sinh?','30 học sinh'],
  [4,'Tìm phân số lớn nhất trong các phân số 1/2, 2/3, 3/4, 5/6.','5/6'],
 ]);
 push('Toán',4,'Phép cộng, phép trừ phân số',[
  [4,'Tính: 3/4 + 5/6 = ?','19/12'],
  [4,'Tính: 7/8 − 1/2 = ?','3/8'],
  [4,'Tìm x: x + 2/5 = 1.','x = 3/5'],
  [4,'Một người đi 1/3 quãng đường buổi sáng, 2/5 quãng đường buổi chiều. Đã đi mấy phần quãng đường?','11/15'],
  [4,'Tính: 1/2 + 1/3 + 1/6 = ?','1'],
 ]);
 push('Toán',4,'Phép nhân, phép chia phân số',[
  [4,'Tính: 3/4 × 8/9 = ?','2/3'],
  [4,'Tính: 5/6 : 10/3 = ?','1/4'],
  [4,'Tìm x: x × 2/3 = 4/9.','x = 2/3'],
  [4,'Một tấm vải dài 3/4 m, cắt thành các đoạn 1/8 m. Được bao nhiêu đoạn?','6 đoạn'],
  [4,'Tính: 2/3 của 3/5 của 25 bằng bao nhiêu?','10'],
 ]);
 push('Toán',4,'Ôn tập cuối năm',[
  [4,'Tính: 2/3 + 3/4 × 8/9 = ?','4/3'],
  [4,'Hai số có tổng 2100, tỉ số số bé so với số lớn là 2/5. Tìm hai số.','600 và 1500'],
  [4,'Trung bình cộng của 6 số là 40, biết 5 số đầu có tổng 190. Tìm số thứ sáu.','50'],
  [4,'Một mảnh vườn hình chữ nhật chu vi 200 m, chiều dài gấp 3 chiều rộng. Tìm diện tích.','Rộng 25 m, dài 75 m; diện tích 1875 m²'],
  [4,'Rút gọn 45/60 rồi cộng với 1/4. Kết quả là bao nhiêu?','3/4 + 1/4 = 1'],
 ]);

 /* ==================== TOÁN LỚP 5 ==================== */
 push('Toán',5,'Ôn tập và bổ sung',[
  [4,'Tìm x: (x + 2,5) × 4 = 30.','x = 5'],
  [4,'Hai số có tổng 120, tỉ số 3/5. Tìm hai số.','45 và 75'],
  [4,'Tính nhanh: 0,25 × 40 × 2 = ?','20'],
  [4,'Trung bình cộng của 3 số là 24, hai số đầu là 20 và 22. Tìm số thứ ba.','30'],
  [4,'Một cửa hàng giảm giá 20% một món giá 150000 đồng. Giá sau giảm là bao nhiêu?','120000 đồng'],
 ]);
 push('Toán',5,'Số thập phân',[
  [4,'Viết hỗn số 3 4/5 dưới dạng số thập phân.','3,8'],
  [4,'So sánh 0,45 và 0,5 (số nào lớn hơn)?','0,5'],
  [4,'Làm tròn 7,836 đến hàng phần mười.','7,8'],
  [4,'Chuyển 2,07 thành phân số thập phân tối giản.','207/100'],
  [4,'Số thập phân nào lớn nhất trong 0,9; 0,89; 0,901; 0,91?','0,91'],
  [4,'Viết số thập phân gồm 5 đơn vị, 0 phần mười, 7 phần trăm.','5,07'],
 ]);
 push('Toán',5,'Một số đơn vị đo diện tích',[
  [4,'Đổi: 3 m² 5 dm² = ? dm².','305 dm²'],
  [4,'Đổi: 2 ha = ? m².','20000 m²'],
  [4,'Một thửa ruộng 5000 m². Hỏi bằng bao nhiêu héc-ta?','0,5 ha'],
  [4,'Đổi: 7 km² = ? ha.','700 ha'],
  [4,'Một hình vuông cạnh 30 m. Diện tích bằng bao nhiêu a (1 a = 100 m²)?','9 a'],
 ]);
 push('Toán',5,'Các phép tính với số thập phân',[
  [4,'Tính: 12,5 × 0,8 = ?','10'],
  [4,'Tính: 45,6 : 1,2 = ?','38'],
  [4,'Tìm x: x × 2,5 = 10.','x = 4'],
  [4,'Tính nhanh: 2,5 × 7,9 + 2,5 × 2,1 = ?','25'],
  [4,'Một can 15,5 lít dầu rót đều vào 5 chai. Mỗi chai bao nhiêu lít?','3,1 lít'],
  [4,'Mua 3,5 kg gạo giá 18000 đồng/kg. Hết bao nhiêu tiền?','63000 đồng'],
 ]);
 push('Toán',5,'Một số hình phẳng. Chu vi và diện tích',[
  [4,'Hình tam giác có đáy 12 cm, chiều cao 8 cm. Diện tích là bao nhiêu?','48 cm²'],
  [4,'Hình thang có hai đáy 10 cm và 6 cm, chiều cao 4 cm. Diện tích là bao nhiêu?','32 cm²'],
  [4,'Hình bình hành có đáy 15 cm, chiều cao 6 cm. Diện tích là bao nhiêu?','90 cm²'],
  [4,'Hình tam giác có diện tích 60 cm², đáy 15 cm. Chiều cao là bao nhiêu?','8 cm'],
  [4,'Một hình thang có diện tích 55 cm², chiều cao 5 cm, đáy lớn 13 cm. Đáy bé là bao nhiêu?','9 cm'],
 ]);
 push('Toán',5,'Ôn tập học kì 1',[
  [4,'Tính: 25% của 320 là bao nhiêu?','80'],
  [4,'Một số tăng 10% thì được 220. Tìm số đó.','200'],
  [4,'Tính nhanh: 0,5 × 48 + 0,5 × 52 = ?','50'],
  [4,'Hình tam giác vuông hai cạnh góc vuông 9 cm và 12 cm. Diện tích là bao nhiêu?','54 cm²'],
  [4,'Tìm x: x : 0,25 = 16.','x = 4'],
 ]);
 push('Toán',5,'Tỉ số và các bài toán liên quan',[
  [4,'Tỉ số phần trăm của 18 và 24 là bao nhiêu?','75%'],
  [4,'Một lớp có 20 nữ và 25 nam. Số nữ chiếm bao nhiêu phần trăm cả lớp?','≈ 44,44%'],
  [4,'Hai số có tỉ số 2/3, số lớn hơn số bé 14. Tìm hai số.','28 và 42'],
  [4,'Một món giá 500000 đồng giảm còn 400000 đồng. Đã giảm bao nhiêu phần trăm?','20%'],
  [4,'Lãi suất 6%/năm, gửi 2 000 000 đồng. Sau 1 năm lãi bao nhiêu?','120000 đồng'],
  [4,'Một trường có 600 học sinh, trong đó 55% là nữ. Số nam là bao nhiêu?','270 học sinh'],
 ]);
 push('Toán',5,'Thể tích. Đơn vị đo thể tích',[
  [4,'Đổi: 2 m³ = ? dm³.','2000 dm³'],
  [4,'Đổi: 5 dm³ = ? cm³.','5000 cm³'],
  [4,'Một bể 1,5 m³ nước bằng bao nhiêu lít (1 dm³ = 1 lít)?','1500 lít'],
  [4,'Đổi: 3200 cm³ = ? dm³.','3,2 dm³'],
  [4,'Một thùng 0,8 m³ chứa bao nhiêu lít?','800 lít'],
 ]);
 push('Toán',5,'Diện tích và thể tích của một số hình khối',[
  [4,'Hình hộp chữ nhật dài 5 cm, rộng 4 cm, cao 3 cm. Thể tích là bao nhiêu?','60 cm³'],
  [4,'Hình lập phương cạnh 4 cm. Thể tích và diện tích toàn phần là bao nhiêu?','Thể tích 64 cm³, diện tích toàn phần 96 cm²'],
  [4,'Hình hộp chữ nhật dài 8 dm, rộng 5 dm, cao 4 dm. Diện tích xung quanh là bao nhiêu?','104 dm²'],
  [4,'Một bể hình hộp chữ nhật 2 m × 1,5 m × 1 m. Bể chứa đầy bao nhiêu lít nước?','3000 lít'],
  [4,'Hình lập phương có diện tích toàn phần 150 cm². Thể tích là bao nhiêu?','125 cm³'],
 ]);
 push('Toán',5,'Số đo thời gian. Vận tốc. Các bài toán chuyển động đều',[
  [4,'Một ô tô đi 135 km trong 3 giờ. Vận tốc là bao nhiêu?','45 km/giờ'],
  [4,'Vận tốc 50 km/giờ, đi trong 2,5 giờ được bao nhiêu ki-lô-mét?','125 km'],
  [4,'Quãng đường 180 km, vận tốc 60 km/giờ. Thời gian đi là bao nhiêu?','3 giờ'],
  [4,'Hai xe xuất phát cùng lúc ngược chiều từ hai điểm cách nhau 200 km, vận tốc 45 và 55 km/giờ. Sau mấy giờ gặp nhau?','2 giờ'],
  [4,'Đổi: 2 giờ 45 phút = ? giờ (thập phân).','2,75 giờ'],
  [4,'Một người đi bộ 5 km/giờ trong 1 giờ 12 phút. Đi được bao nhiêu ki-lô-mét?','6 km'],
 ]);
 push('Toán',5,'Một số yếu tố thống kê và xác suất',[
  [4,'Điểm 5 bài: 7, 8, 6, 9, 10. Điểm trung bình là bao nhiêu?','8'],
  [4,'Biểu đồ quạt: loại giỏi 40%, khá 35%, còn lại trung bình. Trung bình chiếm bao nhiêu phần trăm?','25%'],
  [4,'Lớp 40 bạn, 25% đạt loại giỏi. Có bao nhiêu bạn giỏi?','10 bạn'],
  [4,'Gieo xúc xắc, xác suất ra mặt 6 chấm là bao nhiêu?','1/6'],
  [4,'Một hộp 3 bi đỏ, 2 bi xanh. Lấy ngẫu nhiên 1 viên, xác suất được bi đỏ là bao nhiêu?','3/5'],
 ]);
 push('Toán',5,'Ôn tập cuối năm',[
  [4,'Một ô tô đi nửa quãng đường đầu với vận tốc 40 km/giờ, nửa sau 60 km/giờ, mỗi nửa 120 km. Tổng thời gian là bao nhiêu?','3 + 2 = 5 giờ'],
  [4,'Tính: 75% của 240 cộng 0,25 của 240.','180 + 60 = 240'],
  [4,'Một bể hình hộp chữ nhật 3 m × 2 m × 1,5 m đang chứa 60% nước. Có bao nhiêu lít?','5400 lít'],
  [4,'Hai số có tổng 450, tỉ số 4/5. Tìm số lớn.','250'],
  [4,'Một người gửi 5 000 000 đồng lãi 7%/năm. Sau 1 năm cả vốn lẫn lãi là bao nhiêu?','5350000 đồng'],
 ]);
})();
(function(){
 if(typeof NH==='undefined')return;
 const push=(mon,lop,cd,q)=>{if(!NH[mon])NH[mon]={};if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];NH[mon][lop].push({cd:'★ Nâng cao: '+cd,q:q,_nc:true});};

 /* ==================== TOÁN LỚP 6 ==================== */
 push('Toán',6,'Tập hợp các số tự nhiên',[
  [4,'Tính nhanh tổng 1 + 2 + 3 + … + 100.','5050'],
  [4,'Tính nhanh: 25 × 37 + 25 × 63.','2500'],
  [4,'Tìm số tự nhiên x, biết 2^x = 32.','x = 5'],
  [4,'Tập hợp A = {x ∈ ℕ | 5 ≤ x ≤ 50 và x ⋮ 5} có bao nhiêu phần tử?','10 phần tử'],
  [4,'Tính nhanh tổng các số lẻ: 1 + 3 + 5 + … + 99.','2500'],
  [4,'Tính giá trị biểu thức: 3^3 − 2^4 + 5^0.','12'],
 ]);
 push('Toán',6,'Tính chia hết trong tập hợp các số tự nhiên',[
  [4,'Tìm ƯCLN(24, 36).','12'],
  [4,'Tìm BCNN(8, 12).','24'],
  [4,'Số tự nhiên nhỏ nhất khác 0 chia hết cho cả 4 và 6 là số nào?','12'],
  [4,'Số có hai chữ số lớn nhất chia hết cho 9 là số nào?','99'],
  [4,'Tìm số nguyên tố nhỏ nhất có hai chữ số.','11'],
  [4,'Hai bạn cứ 4 ngày và 6 ngày trực một lần, cùng trực hôm nay. Sau ít nhất bao nhiêu ngày lại cùng trực?','12 ngày'],
 ]);
 push('Toán',6,'Số nguyên',[
  [4,'Tính: (−15) + (−7).','−22'],
  [4,'Tính: (−8) × (−5).','40'],
  [4,'Tính: (−12) + 20 − (−5).','13'],
  [4,'Tìm x, biết x + 7 = −3.','x = −10'],
  [4,'Tính: (−2)^3.','−8'],
  [4,'Nhiệt độ lúc đầu −5°C, sau đó tăng 8°C. Nhiệt độ lúc sau là bao nhiêu?','3°C'],
 ]);
 push('Toán',6,'Một số hình phẳng trong thực tiễn',[
  [4,'Hình thoi có hai đường chéo 6 cm và 8 cm. Diện tích là bao nhiêu?','24 cm²'],
  [4,'Hình thang có hai đáy 8 cm và 12 cm, chiều cao 5 cm. Diện tích là bao nhiêu?','50 cm²'],
  [4,'Hình bình hành có đáy 10 cm, chiều cao 4 cm. Diện tích là bao nhiêu?','40 cm²'],
  [4,'Hình chữ nhật có diện tích 40 cm² và chiều rộng 5 cm. Chu vi là bao nhiêu?','26 cm'],
  [4,'Một mảnh đất hình vuông có diện tích 49 m². Chu vi của nó là bao nhiêu?','28 m'],
 ]);
 push('Toán',6,'Tính đối xứng của hình phẳng trong tự nhiên',[
  [4,'Hình vuông có mấy trục đối xứng?','4 trục'],
  [4,'Hình chữ nhật (không phải hình vuông) có mấy trục đối xứng?','2 trục'],
  [4,'Tam giác đều có mấy trục đối xứng?','3 trục'],
  [4,'Hình tròn có bao nhiêu trục đối xứng?','Vô số trục'],
  [4,'Hình bình hành có tâm đối xứng không? Nếu có thì là điểm nào?','Có; là giao điểm hai đường chéo'],
 ]);
 push('Toán',6,'Phân số',[
  [4,'Rút gọn phân số 36/48 về tối giản.','3/4'],
  [4,'Tính: 2/3 + 3/4.','17/12'],
  [4,'Tính: 5/6 − 1/4.','7/12'],
  [4,'Tìm x, biết x × 3/5 = 9/10.','x = 3/2'],
  [4,'So sánh hai phân số −2/3 và −3/4.','−2/3 > −3/4'],
  [4,'Tính 2/3 của 45.','30'],
 ]);
 push('Toán',6,'Số thập phân',[
  [4,'Tính: 12,5 × 0,8.','10'],
  [4,'Tính: (−2,5) + 7,3.','4,8'],
  [4,'Làm tròn số 3,146 đến hàng phần trăm.','3,15'],
  [4,'Tính 15% của 80.','12'],
  [4,'Tìm tỉ số phần trăm của 15 và 60.','25%'],
  [4,'Tính: 0,25 × 4 + 0,5 × 6.','4'],
 ]);
 push('Toán',6,'Những hình hình học cơ bản',[
  [4,'Qua 5 điểm, trong đó không có 3 điểm nào thẳng hàng, vẽ được bao nhiêu đường thẳng?','10 đường thẳng'],
  [4,'Trên một đường thẳng lấy 4 điểm. Có bao nhiêu đoạn thẳng được tạo thành?','6 đoạn thẳng'],
  [4,'Hai góc kề bù, một góc bằng 110°. Góc còn lại bằng bao nhiêu?','70°'],
  [4,'Tia Oz nằm giữa hai tia Ox, Oy; biết xÔy = 80°, xÔz = 30°. Tính zÔy.','50°'],
  [4,'Hai góc phụ nhau, một góc bằng 52°. Góc còn lại bằng bao nhiêu?','38°'],
 ]);
 push('Toán',6,'Dữ liệu và xác suất thực nghiệm',[
  [4,'Gieo một xúc xắc 60 lần, mặt 6 chấm xuất hiện 12 lần. Xác suất thực nghiệm của biến cố "ra mặt 6 chấm" là bao nhiêu?','12/60 = 1/5 = 0,2'],
  [4,'Tung một đồng xu 50 lần, mặt ngửa xuất hiện 30 lần. Xác suất thực nghiệm mặt ngửa là bao nhiêu?','30/50 = 0,6'],
  [4,'Điểm kiểm tra của 5 bạn: 6, 7, 8, 9, 10. Điểm trung bình là bao nhiêu?','8'],
  [4,'Một hộp có 3 bi đỏ và 7 bi xanh. Lấy ngẫu nhiên 1 viên, khả năng ra màu nào lớn hơn?','Màu xanh'],
  [4,'Gieo một xúc xắc, có bao nhiêu kết quả có thể xảy ra?','6 kết quả'],
 ]);

 /* ==================== TOÁN LỚP 7 ==================== */
 push('Toán',7,'Số hữu tỉ',[
  [4,'Tính: 1/2 + (−2/3).','−1/6'],
  [4,'Tính: (−3/4) × 8/9.','−2/3'],
  [4,'Tìm x, biết x − 1/3 = 1/2.','x = 5/6'],
  [4,'Tính: |−2,5| + |3|.','5,5'],
  [4,'Tính: (1/2)^2 + (1/3)^0.','5/4'],
  [4,'So sánh hai số −0,6 và −2/3.','−0,6 > −2/3'],
 ]);
 push('Toán',7,'Số thực',[
  [4,'Tính: √9 + √25.','8'],
  [4,'Tìm x, biết x² = 49.','x = 7 hoặc x = −7'],
  [4,'Số √2 là số hữu tỉ hay số vô tỉ?','Số vô tỉ'],
  [4,'Tính: |−√5| + √5.','2√5'],
  [4,'Làm tròn √2 đến hàng phần trăm.','≈ 1,41'],
  [4,'Tính: √(16) × √(9).','12'],
 ]);
 push('Toán',7,'Góc và đường thẳng song song',[
  [4,'Hai đường thẳng song song bị cắt bởi một đường thẳng, một góc so le trong bằng 65°. Góc so le trong còn lại bằng bao nhiêu?','65°'],
  [4,'Hai góc trong cùng phía (với hai đường thẳng song song) có một góc 120°. Góc kia bằng bao nhiêu?','60°'],
  [4,'Hai góc đối đỉnh, một góc bằng 50°. Góc còn lại bằng bao nhiêu?','50°'],
  [4,'Hai góc kề bù, một góc 130°. Góc còn lại bằng bao nhiêu?','50°'],
  [4,'Tia phân giác chia góc 80° thành hai góc, mỗi góc bằng bao nhiêu?','40°'],
 ]);
 push('Toán',7,'Tam giác bằng nhau',[
  [4,'Tam giác có hai góc bằng 50° và 60°. Góc còn lại bằng bao nhiêu?','70°'],
  [4,'Tam giác vuông cân có mỗi góc nhọn bằng bao nhiêu?','45°'],
  [4,'Tam giác cân có góc ở đỉnh 40°. Mỗi góc ở đáy bằng bao nhiêu?','70°'],
  [4,'Mỗi góc của tam giác đều bằng bao nhiêu?','60°'],
  [4,'Một góc ngoài của tam giác bằng 120°, một góc trong không kề nó bằng 50°. Góc trong không kề còn lại bằng bao nhiêu?','70°'],
 ]);
 push('Toán',7,'Thu thập và biểu diễn dữ liệu',[
  [4,'Điểm của 5 bạn: 6, 7, 9, 10, 8. Điểm trung bình là bao nhiêu?','8'],
  [4,'Một biểu đồ có 4 loại chiếm 40%, 30%, 20% và phần còn lại. Phần còn lại chiếm bao nhiêu phần trăm?','10%'],
  [4,'Giá trị 8 xuất hiện 5 lần trong tổng số 20 giá trị. Tần suất (tần số tương đối) của giá trị 8 là bao nhiêu?','25%'],
  [4,'Số HS giỏi của 3 lớp là 12, 15, 9. Trung bình mỗi lớp có bao nhiêu HS giỏi?','12'],
  [4,'Nhiệt độ 4 ngày: 29, 31, 30, 34 (°C). Nhiệt độ trung bình là bao nhiêu?','31°C'],
 ]);
 push('Toán',7,'Tỉ lệ thức và đại lượng tỉ lệ',[
  [4,'Tìm x trong tỉ lệ thức 3/4 = x/12.','x = 9'],
  [4,'Chia số 100 thành hai phần tỉ lệ với 2 và 3. Tìm hai phần đó.','40 và 60'],
  [4,'y tỉ lệ thuận với x, biết y = 12 khi x = 3. Tìm y khi x = 5.','y = 20'],
  [4,'y tỉ lệ nghịch với x, biết x × y = 24. Khi x = 6 thì y bằng bao nhiêu?','y = 4'],
  [4,'Ba số tỉ lệ với 2 : 3 : 5 và có tổng bằng 60. Tìm ba số đó.','12, 18, 30'],
 ]);
 push('Toán',7,'Biểu thức đại số và đa thức một biến',[
  [4,'Tính giá trị biểu thức 2x² − 3x + 1 tại x = 2.','3'],
  [4,'Thu gọn: (3x² + 2x) − (x² − x).','2x² + 3x'],
  [4,'Tìm nghiệm của đa thức P(x) = 2x − 6.','x = 3'],
  [4,'Cho đa thức Q(x) = x³ − 2x + 5. Bậc của đa thức là bao nhiêu?','Bậc 3'],
  [4,'Khai triển (x + 3)(x − 3).','x² − 9'],
 ]);
 push('Toán',7,'Làm quen với biến cố và xác suất của biến cố',[
  [4,'Gieo một xúc xắc cân đối. Xác suất ra mặt có số chấm là số chẵn là bao nhiêu?','1/2'],
  [4,'Gieo một xúc xắc, xác suất ra số chấm lớn hơn 4 là bao nhiêu?','1/3'],
  [4,'Một biến cố chắc chắn có xác suất bằng bao nhiêu?','1'],
  [4,'Hộp có 4 bi đỏ và 6 bi xanh. Lấy ngẫu nhiên 1 viên, xác suất được bi đỏ là bao nhiêu?','2/5'],
  [4,'Tung một đồng xu cân đối, xác suất ra mặt ngửa là bao nhiêu?','1/2'],
 ]);
 push('Toán',7,'Quan hệ giữa các yếu tố trong tam giác',[
  [4,'Tam giác có hai cạnh 3 cm và 5 cm. Cạnh thứ ba x thỏa mãn điều kiện nào?','2 cm < x < 8 cm'],
  [4,'Tam giác có hai cạnh 4 cm và 9 cm, cạnh thứ ba là số nguyên lớn nhất bằng bao nhiêu?','12 cm'],
  [4,'Trọng tâm chia mỗi đường trung tuyến theo tỉ số nào (tính từ đỉnh)?','2 : 1'],
  [4,'Ba đường trung tuyến của tam giác đồng quy tại điểm gọi là gì?','Trọng tâm'],
  [4,'Trong một tam giác, đối diện với góc lớn hơn là cạnh như thế nào?','Cạnh lớn hơn'],
 ]);
 push('Toán',7,'Một số hình khối trong thực tiễn',[
  [4,'Hình hộp chữ nhật dài 4 cm, rộng 3 cm, cao 2 cm. Thể tích là bao nhiêu?','24 cm³'],
  [4,'Hình lập phương cạnh 5 cm. Thể tích và diện tích toàn phần là bao nhiêu?','Thể tích 125 cm³, diện tích toàn phần 150 cm²'],
  [4,'Hình lăng trụ đứng có diện tích đáy 6 cm², chiều cao 10 cm. Thể tích là bao nhiêu?','60 cm³'],
  [4,'Một bể hình hộp chữ nhật 2 m × 1 m × 0,5 m. Bể chứa đầy bao nhiêu lít nước?','1000 lít'],
  [4,'Hình hộp chữ nhật dài 4 dm, rộng 3 dm, cao 2 dm. Diện tích xung quanh là bao nhiêu?','28 dm²'],
 ]);

 /* ==================== TOÁN LỚP 8 ==================== */
 push('Toán',8,'Đa thức',[
  [4,'Khai triển và thu gọn: (2x + 3)(x − 1).','2x² + x − 3'],
  [4,'Nhân đơn thức với đa thức: 3x²(2x − 5).','6x³ − 15x²'],
  [4,'Thu gọn: (x² + 2x) − (2x² − x).','−x² + 3x'],
  [4,'Bậc của đơn thức 5x³y² là bao nhiêu?','5'],
  [4,'Tính giá trị của 2x² − 3xy tại x = 2, y = 1.','2'],
 ]);
 push('Toán',8,'Hằng đẳng thức đáng nhớ và ứng dụng',[
  [4,'Khai triển (x + 5)².','x² + 10x + 25'],
  [4,'Phân tích thành nhân tử: x² − 16.','(x − 4)(x + 4)'],
  [4,'Tính nhanh bằng hằng đẳng thức: 101².','10201'],
  [4,'Tính nhanh: 53² − 47².','600'],
  [4,'Phân tích thành nhân tử: x² − 6x + 9.','(x − 3)²'],
  [4,'Phân tích thành nhân tử: x³ − 8.','(x − 2)(x² + 2x + 4)'],
 ]);
 push('Toán',8,'Tứ giác',[
  [4,'Tứ giác có ba góc 80°, 90°, 100°. Góc thứ tư bằng bao nhiêu?','90°'],
  [4,'Hình bình hành có một góc 70°. Góc kề với nó bằng bao nhiêu?','110°'],
  [4,'Hình thang cân có hai góc ở một đáy như thế nào với nhau?','Bằng nhau'],
  [4,'Trong hình chữ nhật, hai đường chéo có quan hệ gì?','Bằng nhau và cắt nhau tại trung điểm mỗi đường'],
  [4,'Hình bình hành có một góc 90° là hình gì?','Hình chữ nhật'],
 ]);
 push('Toán',8,'Định lí Thalès',[
  [4,'Tam giác ABC, DE // BC (D ∈ AB, E ∈ AC), AD = 2, DB = 3, AE = 4. Tính EC.','EC = 6'],
  [4,'Tam giác ABC, DE // BC, AD = 3, AB = 9, BC = 12. Tính DE.','DE = 4'],
  [4,'Theo định lí Thalès, nếu một đường thẳng song song với một cạnh của tam giác thì nó định ra trên hai cạnh kia các đoạn thẳng như thế nào?','Tương ứng tỉ lệ'],
  [4,'Tam giác có đường thẳng DE // BC, AD/DB = 2/3, DB = 6. Tính AD.','AD = 4'],
  [4,'Cho AD/AB = AE/AC thì DE và BC có quan hệ gì?','DE // BC'],
 ]);
 push('Toán',8,'Dữ liệu và biểu đồ',[
  [4,'Điểm của 6 bạn: 5, 6, 7, 8, 9, 7. Điểm trung bình là bao nhiêu?','7'],
  [4,'Biểu đồ hình quạt có 3 loại 50%, 30% và phần còn lại. Phần còn lại là bao nhiêu phần trăm?','20%'],
  [4,'Một lớp 40 HS, 30% xếp loại giỏi. Số HS giỏi là bao nhiêu?','12 HS'],
  [4,'Tần số của giá trị 9 là 6 trong tổng 24 giá trị. Tần số tương đối là bao nhiêu?','25%'],
  [4,'Doanh thu 4 tháng: 20, 25, 30, 25 (triệu). Trung bình mỗi tháng là bao nhiêu?','25 triệu'],
 ]);
 push('Toán',8,'Phân thức đại số',[
  [4,'Rút gọn phân thức (x² − 9)/(x − 3) với x ≠ 3.','x + 3'],
  [4,'Tìm điều kiện xác định của phân thức (x + 2)/(x − 1).','x ≠ 1'],
  [4,'Rút gọn: (x² − 4)/(x + 2) với x ≠ −2.','x − 2'],
  [4,'Tính: 1/x + 2/x (x ≠ 0).','3/x'],
  [4,'Rút gọn: (6x²y)/(3xy) với x, y ≠ 0.','2x'],
 ]);
 push('Toán',8,'Phương trình bậc nhất và hàm số bậc nhất',[
  [4,'Giải phương trình: 3x + 5 = 2x + 9.','x = 4'],
  [4,'Giải phương trình: 5(x − 1) = 3x + 7.','x = 6'],
  [4,'Hàm số y = 2x − 1. Tính y khi x = 3.','y = 5'],
  [4,'Đường thẳng y = ax + b đi qua (0; 2) và (1; 5). Tìm a và b.','a = 3, b = 2'],
  [4,'Giải phương trình: (x − 2)/3 = (x + 1)/4.','x = 11'],
 ]);
 push('Toán',8,'Mở đầu về tính xác suất của biến cố',[
  [4,'Gieo một xúc xắc, xác suất ra số nguyên tố (2, 3, 5) là bao nhiêu?','1/2'],
  [4,'Hộp có 5 bi đỏ và 15 bi xanh. Xác suất lấy được bi đỏ là bao nhiêu?','1/4'],
  [4,'Tung đồng xu hai lần, xác suất cả hai lần đều ngửa là bao nhiêu?','1/4'],
  [4,'Một biến cố không thể xảy ra có xác suất bằng bao nhiêu?','0'],
  [4,'Rút ngẫu nhiên 1 thẻ trong 10 thẻ đánh số 1–10, xác suất ra số chia hết cho 3 là bao nhiêu?','3/10'],
 ]);
 push('Toán',8,'Tam giác đồng dạng',[
  [4,'Hai tam giác đồng dạng với tỉ số đồng dạng k = 2. Tỉ số diện tích của chúng là bao nhiêu?','4'],
  [4,'Hai tam giác đồng dạng tỉ số 3/5, một cạnh của tam giác nhỏ là 9. Cạnh tương ứng của tam giác lớn là bao nhiêu?','15'],
  [4,'Tỉ số diện tích hai tam giác đồng dạng là 9. Tỉ số đồng dạng là bao nhiêu?','3'],
  [4,'Tam giác ABC đồng dạng tam giác DEF theo tỉ số 2/3, chu vi ABC là 24 cm. Chu vi DEF là bao nhiêu?','36 cm'],
  [4,'Hai tam giác đồng dạng tỉ số đồng dạng 1/2, diện tích tam giác lớn 48 cm². Diện tích tam giác nhỏ là bao nhiêu?','12 cm²'],
 ]);
 push('Toán',8,'Một số hình khối trong thực tiễn',[
  [4,'Hình chóp tứ giác đều có đáy là hình vuông cạnh 6 cm, chiều cao 5 cm. Thể tích là bao nhiêu?','60 cm³'],
  [4,'Thể tích hình chóp được tính bằng công thức nào?','V = 1/3 × diện tích đáy × chiều cao'],
  [4,'Hình chóp có diện tích đáy 27 cm², chiều cao 10 cm. Thể tích là bao nhiêu?','90 cm³'],
  [4,'Hình chóp tam giác đều có diện tích đáy 12 cm², chiều cao 6 cm. Thể tích là bao nhiêu?','24 cm³'],
  [4,'Một hình chóp tứ giác đều đáy cạnh 4 cm, thể tích 32 cm³. Chiều cao là bao nhiêu?','6 cm'],
 ]);

 /* ==================== TOÁN LỚP 9 ==================== */
 push('Toán',9,'Phương trình và hệ hai phương trình bậc nhất hai ẩn',[
  [4,'Giải hệ: x + y = 10 và x − y = 4.','x = 7, y = 3'],
  [4,'Giải hệ: 2x + y = 8 và x + y = 5.','x = 3, y = 2'],
  [4,'Cho 3x + 2y = 12 và x = 2. Tìm y.','y = 3'],
  [4,'Tổng hai số là 30, hiệu là 8. Tìm hai số (lập hệ).','19 và 11'],
  [4,'Giải hệ: x + 2y = 7 và 2x − y = 4.','x = 3, y = 2'],
 ]);
 push('Toán',9,'Phương trình và bất phương trình bậc nhất một ẩn',[
  [4,'Giải phương trình: 2x − 5 = 9.','x = 7'],
  [4,'Giải bất phương trình: 3x − 6 > 0.','x > 2'],
  [4,'Giải phương trình: x/3 + x/6 = 3.','x = 6'],
  [4,'Giải bất phương trình: 2x + 1 ≤ 7.','x ≤ 3'],
  [4,'Giải phương trình: (x − 1)/2 = 3.','x = 7'],
 ]);
 push('Toán',9,'Căn bậc hai và căn bậc ba',[
  [4,'Tính: √144.','12'],
  [4,'Rút gọn: √50.','5√2'],
  [4,'Tính: √81 − √36.','3'],
  [4,'Tính: ∛27 + ∛8.','5'],
  [4,'Rút gọn: √12 + √27.','5√3'],
  [4,'Tìm x, biết √x = 7.','x = 49'],
 ]);
 push('Toán',9,'Hệ thức lượng trong tam giác vuông',[
  [4,'Tam giác vuông có hai cạnh góc vuông 6 cm và 8 cm. Cạnh huyền dài bao nhiêu?','10 cm'],
  [4,'Tam giác vuông có cạnh huyền 13 cm, một cạnh góc vuông 5 cm. Cạnh góc vuông kia dài bao nhiêu?','12 cm'],
  [4,'Tính: sin 30° + cos 60°.','1'],
  [4,'Tính: tan 45°.','1'],
  [4,'Trong tam giác vuông, đường cao ứng với cạnh huyền chia cạnh huyền thành hai đoạn 4 cm và 9 cm. Đường cao dài bao nhiêu?','6 cm'],
 ]);
 push('Toán',9,'Đường tròn',[
  [4,'Đường tròn bán kính 5 cm. Chu vi của nó là bao nhiêu (theo π)?','10π cm (≈ 31,4 cm)'],
  [4,'Hình tròn bán kính 7 cm. Diện tích là bao nhiêu (theo π)?','49π cm² (≈ 153,86 cm²)'],
  [4,'Góc nội tiếp chắn nửa đường tròn bằng bao nhiêu độ?','90°'],
  [4,'Góc ở tâm chắn một cung bằng 80°. Góc nội tiếp cùng chắn cung đó bằng bao nhiêu?','40°'],
  [4,'Dây cung dài nhất của một đường tròn gọi là gì?','Đường kính'],
 ]);
 push('Toán',9,'Hàm số y = ax² (a ≠ 0). Phương trình bậc hai một ẩn',[
  [4,'Giải phương trình: x² − 5x + 6 = 0.','x = 2 hoặc x = 3'],
  [4,'Giải phương trình: x² − 9 = 0.','x = 3 hoặc x = −3'],
  [4,'Cho hàm số y = 2x². Tính y khi x = 3.','y = 18'],
  [4,'Phương trình x² − 4x + 4 = 0 có nghiệm như thế nào?','Nghiệm kép x = 2'],
  [4,'Theo định lí Vi-ét, phương trình x² − 7x + 12 = 0 có tổng và tích hai nghiệm là bao nhiêu?','Tổng 7, tích 12'],
  [4,'Giải phương trình: x² + x − 6 = 0.','x = 2 hoặc x = −3'],
 ]);
 push('Toán',9,'Tần số và tần số tương đối',[
  [4,'Giá trị 8 có tần số 5 trong tổng 20 giá trị. Tần số tương đối của nó là bao nhiêu?','25%'],
  [4,'Điểm của 5 bạn: 7, 8, 8, 9, 8. Điểm trung bình là bao nhiêu?','8'],
  [4,'Một mẫu có 40 giá trị, giá trị x có tần số tương đối 15%. Tần số của x là bao nhiêu?','6'],
  [4,'Tổng các tần số tương đối của một bảng số liệu bằng bao nhiêu?','100% (hay 1)'],
  [4,'Giá trị xuất hiện nhiều nhất trong mẫu số liệu được gọi là gì?','Mốt (mode)'],
 ]);
 push('Toán',9,'Xác suất của biến cố trong một số mô hình xác suất đơn giản',[
  [4,'Gieo một xúc xắc, xác suất ra số lớn hơn 4 là bao nhiêu?','1/3'],
  [4,'Hộp có 5 bi đỏ và 5 bi xanh. Xác suất lấy được bi đỏ là bao nhiêu?','1/2'],
  [4,'Tung hai đồng xu, xác suất được đúng hai mặt ngửa là bao nhiêu?','1/4'],
  [4,'Rút 1 thẻ trong 10 thẻ đánh số 1–10, xác suất ra số chẵn là bao nhiêu?','1/2'],
  [4,'Một biến cố chắc chắn có xác suất bằng bao nhiêu?','1'],
 ]);
 push('Toán',9,'Đường tròn ngoại tiếp và đường tròn nội tiếp',[
  [4,'Tâm đường tròn ngoại tiếp tam giác là giao điểm của các đường nào?','Các đường trung trực của ba cạnh'],
  [4,'Tâm đường tròn nội tiếp tam giác là giao điểm của các đường nào?','Các đường phân giác trong'],
  [4,'Với tam giác vuông, tâm đường tròn ngoại tiếp nằm ở đâu?','Trung điểm cạnh huyền'],
  [4,'Hình vuông cạnh 4 cm. Bán kính đường tròn ngoại tiếp bằng bao nhiêu?','2√2 cm'],
  [4,'Tam giác vuông hai cạnh góc vuông 6 và 8. Bán kính đường tròn ngoại tiếp bằng bao nhiêu?','5 cm'],
 ]);
 push('Toán',9,'Một số hình khối trong thực tiễn',[
  [4,'Hình trụ bán kính đáy 3 cm, chiều cao 5 cm. Thể tích là bao nhiêu (theo π)?','45π cm³ (≈ 141,3 cm³)'],
  [4,'Hình cầu bán kính 3 cm. Thể tích là bao nhiêu (theo π)?','36π cm³'],
  [4,'Hình nón bán kính đáy 3 cm, chiều cao 4 cm. Thể tích là bao nhiêu (theo π)?','12π cm³'],
  [4,'Diện tích xung quanh hình trụ bán kính 2 cm, cao 5 cm là bao nhiêu (theo π)?','20π cm²'],
  [4,'Diện tích mặt cầu bán kính 2 cm là bao nhiêu (theo π)?','16π cm²'],
 ]);
})();
(function(){
 if(typeof NH==='undefined')return;
 const push=(mon,lop,cd,q)=>{if(!NH[mon])NH[mon]={};if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];NH[mon][lop].push({cd:'★ Nâng cao: '+cd,q:q,_nc:true});};

 /* ============ TIẾNG VIỆT LỚP 4 (nâng cao) ============ */
 push('Tiếng Việt',4,'Danh từ, động từ, tính từ',[
  [4,'Trong câu "Những bông hoa hồng nở rộ rực rỡ trong vườn", hãy tìm danh từ, động từ, tính từ.','Danh từ: bông hoa hồng, vườn; Động từ: nở; Tính từ: rực rỡ'],
  [4,'Từ "cưa" trong "cái cưa" và "cưa gỗ" thuộc từ loại nào ở mỗi trường hợp?','"cái cưa" là danh từ; "cưa gỗ" là động từ'],
  [4,'Xếp các từ sau theo từ loại: bàn, chạy, xanh, học sinh, vui, đọc.','Danh từ: bàn, học sinh; Động từ: chạy, đọc; Tính từ: xanh, vui'],
  [4,'Tìm các tính từ trong câu "Dòng sông quê em hiền hòa, trong vắt và mát rượi."','hiền hòa, trong vắt, mát rượi'],
  [4,'Đặt một câu kể có ít nhất một danh từ, một động từ và một tính từ.','VD: "Chú chó nhỏ đang chạy tung tăng." (DT: chú chó; ĐT: chạy; TT: nhỏ, tung tăng)'],
 ]);
 push('Tiếng Việt',4,'Biện pháp nhân hóa',[
  [4,'Câu "Ông mặt trời đạp xe qua đỉnh núi" dùng biện pháp gì? Nêu dấu hiệu.','Nhân hóa — gọi mặt trời bằng "ông" và tả hành động "đạp xe" như con người'],
  [4,'Tìm sự vật được nhân hóa và từ ngữ nhân hóa trong câu "Hàng cây đứng tần ngần bên đường."','Sự vật: hàng cây; từ nhân hóa: "đứng tần ngần"'],
  [4,'Đặt một câu tả cơn mưa có dùng biện pháp nhân hóa.','VD: "Những hạt mưa tinh nghịch nhảy nhót trên mái nhà."'],
  [4,'Nhân hóa có mấy cách thường gặp? Kể tên.','3 cách: gọi vật bằng từ gọi người; tả vật bằng từ tả hoạt động/đặc điểm của người; trò chuyện, xưng hô với vật như với người'],
  [4,'Câu "Trâu ơi ta bảo trâu này" dùng cách nhân hóa nào?','Cách trò chuyện, xưng hô với vật (con trâu) như với người'],
 ]);
 push('Tiếng Việt',4,'Câu: chủ ngữ, vị ngữ, trạng ngữ',[
  [4,'Xác định trạng ngữ, chủ ngữ, vị ngữ trong câu "Sáng nay, trên sân trường, các bạn học sinh nô đùa vui vẻ."','Trạng ngữ: Sáng nay, trên sân trường; Chủ ngữ: các bạn học sinh; Vị ngữ: nô đùa vui vẻ'],
  [4,'Trạng ngữ trong câu "Vì trời mưa, chúng em nghỉ học." chỉ ý gì?','Chỉ nguyên nhân (trạng ngữ chỉ nguyên nhân)'],
  [4,'Thêm trạng ngữ chỉ thời gian cho câu: "Hoa phượng nở đỏ rực."','VD: "Mỗi độ hè về, hoa phượng nở đỏ rực."'],
  [4,'Câu "Trên cành cây, những chú chim hót líu lo." — bộ phận nào là chủ ngữ?','Chủ ngữ: những chú chim'],
  [4,'Đặt một câu có trạng ngữ chỉ nơi chốn.','VD: "Ngoài đồng, các bác nông dân đang gặt lúa."'],
 ]);

 /* ============ TIẾNG VIỆT LỚP 5 (nâng cao) ============ */
 push('Tiếng Việt',5,'Từ đồng nghĩa, từ đa nghĩa',[
  [4,'Tìm 3 từ đồng nghĩa với từ "chăm chỉ".','siêng năng, cần cù, chịu khó'],
  [4,'Từ "đi" trong các câu sau là nghĩa gốc hay nghĩa chuyển: (a) Em đi bộ đến trường. (b) Chiếc đồng hồ chạy đi.','(a) nghĩa gốc; (b) nghĩa chuyển'],
  [4,'Đặt câu để phân biệt hai nghĩa của từ nhiều nghĩa "mũi".','VD: "Mũi em bị nghẹt." (bộ phận cơ thể) / "Thuyền rẽ sóng ở mũi đất." (phần đất nhô ra)'],
  [4,'Chọn từ đồng nghĩa thích hợp điền vào chỗ trống: "Bạn Lan rất … giúp đỡ người khác." (nhiệt tình / lạnh lùng).','nhiệt tình'],
  [4,'Tìm cặp từ trái nghĩa trong câu tục ngữ "Lên thác xuống ghềnh".','lên – xuống'],
 ]);
 push('Tiếng Việt',5,'Đại từ, kết từ',[
  [4,'Tìm đại từ trong câu "Nó chạy lại, tôi liền đưa cho nó quyển vở."','Đại từ: Nó, tôi'],
  [4,'Kết từ trong câu "Em học giỏi vì em chăm chỉ." là từ nào và nối ý gì?','Kết từ "vì" — nối vế chỉ kết quả với vế chỉ nguyên nhân'],
  [4,'Thay thế từ lặp bằng đại từ cho câu: "Lan rất ngoan. Lan luôn giúp đỡ bạn bè."','VD: "Lan rất ngoan. Bạn ấy luôn giúp đỡ bạn bè."'],
  [4,'Đặt một câu có dùng cặp kết từ "tuy … nhưng …".','VD: "Tuy trời mưa nhưng chúng em vẫn đến lớp đầy đủ."'],
  [4,'Đại từ dùng để làm gì?','Dùng để xưng hô, thay thế cho danh từ/động từ/tính từ nhằm tránh lặp từ, hoặc để hỏi'],
 ]);
 push('Tiếng Việt',5,'Câu ghép và liên kết câu',[
  [4,'Câu "Trời càng về khuya, trăng càng sáng." là câu đơn hay câu ghép? Vì sao?','Câu ghép — có hai vế, mỗi vế có đủ chủ ngữ – vị ngữ, nối bằng cặp từ "càng … càng"'],
  [4,'Xác định các vế và từ nối trong câu ghép "Vì em chăm học nên kết quả rất tốt."','Vế 1: em chăm học; Vế 2: kết quả rất tốt; cặp quan hệ từ "vì … nên" (nguyên nhân – kết quả)'],
  [4,'Hai câu sau liên kết bằng cách nào: "Lan là học sinh giỏi. Em ấy luôn giúp đỡ bạn bè."','Liên kết bằng cách thay thế từ ngữ — dùng "em ấy" thay cho "Lan"'],
  [4,'Đặt một câu ghép dùng cặp quan hệ từ "nếu … thì …".','VD: "Nếu em cố gắng thì em sẽ đạt kết quả cao."'],
  [4,'Tìm từ ngữ nối liên kết hai câu: "Trời mưa to. Tuy vậy, chúng em vẫn đi học đều."','Từ nối: "Tuy vậy"'],
 ]);

 /* ============ KHOA HỌC LỚP 4 (nâng cao) ============ */
 push('Khoa học',4,'Chất: nước và không khí',[
  [4,'Nước tồn tại ở mấy thể? Kể tên và cho ví dụ mỗi thể.','3 thể: rắn (nước đá), lỏng (nước uống), khí (hơi nước)'],
  [4,'Vì sao khi đun nước sôi, ta thấy "khói" bốc lên phía trên ấm?','Hơi nước bốc lên gặp không khí lạnh ngưng tụ thành những giọt nước nhỏ li ti tạo thành "khói"'],
  [4,'Thành phần nào của không khí duy trì sự cháy và sự sống?','Khí ô-xi'],
  [4,'Nêu một cách làm sạch nước đục đơn giản.','Lọc qua cát, sỏi, than (hoặc để lắng rồi gạn) để loại bỏ cặn bẩn'],
  [4,'Vì sao không nên đóng kín cửa khi đốt than, củi trong phòng?','Sự cháy cần ô-xi và thải khí các-bô-níc độc; đóng kín thiếu ô-xi, khí độc tích tụ gây ngạt'],
 ]);
 push('Khoa học',4,'Năng lượng: ánh sáng, âm thanh, nhiệt',[
  [4,'Vì sao ban ngày không cần bật đèn vẫn nhìn thấy mọi vật?','Nhờ ánh sáng mặt trời chiếu sáng, vật hắt lại ánh sáng tới mắt ta'],
  [4,'Âm thanh truyền được qua những môi trường nào?','Qua chất khí, chất lỏng và chất rắn; không truyền qua chân không'],
  [4,'Vì sao mùa đông mặc áo len, áo bông lại thấy ấm?','Áo giữ lớp không khí, ngăn nhiệt từ cơ thể truyền ra ngoài nên giữ ấm'],
  [4,'Bóng của một vật xuất hiện khi nào?','Khi vật cản sáng chắn đường truyền của ánh sáng'],
  [4,'Nêu một ví dụ cho thấy nhiệt làm vật nở ra.','VD: Quả bóng bàn bẹp nhúng vào nước nóng sẽ phồng lại do không khí trong bóng nở ra'],
 ]);
 push('Khoa học',4,'Thực vật, động vật và nấm',[
  [4,'Nêu các yếu tố cần cho sự sống và phát triển của thực vật.','Ánh sáng, nước, không khí, chất khoáng (và nhiệt độ thích hợp)'],
  [4,'Trong quá trình quang hợp, cây xanh hút khí gì và thải ra khí gì?','Hút khí các-bô-níc, thải ra khí ô-xi'],
  [4,'Nấm có phải là thực vật không? Vì sao?','Không. Nấm không có chất diệp lục nên không tự quang hợp tạo thức ăn như thực vật'],
  [4,'Kể tên các chất mà động vật cần để sống.','Thức ăn, nước, không khí (ô-xi) và nhiệt độ/ánh sáng thích hợp'],
  [4,'Vì sao cần bảo vệ các loài động vật hoang dã?','Chúng giữ cân bằng chuỗi thức ăn, cân bằng tự nhiên; mất một loài ảnh hưởng nhiều loài khác và môi trường'],
 ]);
 push('Khoa học',4,'Con người và sức khỏe',[
  [4,'Nêu 4 nhóm chất dinh dưỡng chính cần cho cơ thể.','Chất bột đường, chất đạm, chất béo, vi-ta-min và chất khoáng'],
  [4,'Vì sao cần ăn phối hợp nhiều loại thức ăn?','Mỗi loại thức ăn chỉ cung cấp một số chất; ăn phối hợp mới đủ các chất dinh dưỡng cơ thể cần'],
  [4,'Nêu 3 việc nên làm để phòng bệnh lây qua đường tiêu hóa.','Ăn chín uống sôi; rửa tay trước khi ăn và sau khi đi vệ sinh; giữ vệ sinh thức ăn, nguồn nước'],
  [4,'Khi bị đứt tay chảy máu nhẹ, em nên làm gì?','Rửa sạch vết thương, sát trùng và băng lại; nếu nặng thì báo người lớn/đến cơ sở y tế'],
  [4,'Vì sao nên uống đủ nước mỗi ngày?','Nước giúp cơ thể tiêu hóa, bài tiết, điều hòa thân nhiệt và vận chuyển chất dinh dưỡng'],
 ]);
 push('Khoa học',4,'Sinh vật và môi trường',[
  [4,'Chuỗi thức ăn là gì? Cho một ví dụ.','Là dãy các sinh vật có quan hệ thức ăn; VD: cỏ → châu chấu → ếch → rắn'],
  [4,'Điều gì xảy ra với chuỗi thức ăn "lúa → chuột → rắn" nếu rắn bị diệt hết?','Chuột mất thiên địch nên tăng nhanh, phá hoại nhiều lúa; chuỗi thức ăn mất cân bằng'],
  [4,'Nêu 2 việc học sinh làm được để bảo vệ môi trường.','VD: bỏ rác đúng nơi, trồng và chăm sóc cây xanh, tiết kiệm nước/điện'],
  [4,'Vì sao thực vật được gọi là mắt xích đầu tiên của chuỗi thức ăn?','Vì cây xanh tự tạo được thức ăn (quang hợp), là nguồn thức ăn khởi đầu cho các sinh vật khác'],
  [4,'Rừng có vai trò gì với môi trường sống?','Điều hòa khí hậu, giữ nước chống lũ/xói mòn, cung cấp ô-xi và là nơi ở của nhiều loài'],
 ]);

 /* ============ KHOA HỌC LỚP 5 (nâng cao) ============ */
 push('Khoa học',5,'Chất',[
  [4,'Thế nào là sự biến đổi hóa học? Cho ví dụ.','Là sự biến đổi chất này thành chất khác; VD: đốt giấy thành tro, sắt bị gỉ'],
  [4,'Phân biệt biến đổi lí học và hóa học qua "hòa tan đường" và "đốt đường".','Hòa tan đường: biến đổi lí học (vẫn là đường); đốt đường: biến đổi hóa học (thành chất mới – than, khí)'],
  [4,'Hỗn hợp là gì? Cho một ví dụ.','Là hai hay nhiều chất trộn lẫn nhau; VD: nước muối, không khí, gạo lẫn sạn'],
  [4,'Nêu một cách tách muối ra khỏi nước muối.','Đun (cô cạn) cho nước bay hơi hết, còn lại muối'],
  [4,'Dung dịch là gì? Khác hỗn hợp thường ở điểm nào?','Dung dịch là hỗn hợp chất lỏng với chất bị hòa tan tan đều (VD nước đường); chất tan tan hoàn toàn, không thấy riêng'],
 ]);
 push('Khoa học',5,'Năng lượng',[
  [4,'Kể tên 3 nguồn năng lượng sạch (tái tạo).','Năng lượng mặt trời, năng lượng gió, năng lượng nước (thủy điện)'],
  [4,'Vì sao cần sử dụng tiết kiệm điện?','Sản xuất điện tốn tài nguyên và gây ô nhiễm; tiết kiệm điện là tiết kiệm chi phí và bảo vệ môi trường'],
  [4,'Than, dầu mỏ, khí đốt gọi chung là gì? Vì sao cần tiết kiệm?','Nhiên liệu hóa thạch; chúng có hạn, cần hàng triệu năm mới tạo thành, dùng hết sẽ cạn kiệt'],
  [4,'Nêu một ví dụ biến đổi năng lượng mặt trời thành điện.','Pin (tấm) năng lượng mặt trời biến ánh sáng thành điện'],
  [4,'Mạch điện đơn giản gồm những bộ phận nào để đèn sáng?','Nguồn điện (pin), dây dẫn và bóng đèn nối thành mạch kín'],
 ]);
 push('Khoa học',5,'Thực vật và động vật',[
  [4,'Hoa có chức năng gì đối với sự sinh sản của thực vật có hoa?','Là cơ quan sinh sản; nhờ thụ phấn, thụ tinh mà tạo thành quả và hạt'],
  [4,'Hạt gồm những bộ phận chính nào?','Vỏ hạt, phôi (mầm) và chất dinh dưỡng dự trữ'],
  [4,'Nêu các giai đoạn phát triển của cây từ hạt.','Hạt → nảy mầm → cây con → cây trưởng thành → ra hoa, kết quả'],
  [4,'Phần lớn động vật đẻ trứng hay đẻ con? Cho mỗi loại một ví dụ.','Có loài đẻ trứng (gà, cá), có loài đẻ con (trâu, chó)'],
  [4,'Vì sao thực vật rất quan trọng với đời sống động vật và con người?','Cung cấp thức ăn, ô-xi, nơi ở; điều hòa khí hậu và môi trường'],
 ]);
 push('Khoa học',5,'Vi khuẩn',[
  [4,'Vi khuẩn có lợi hay có hại? Cho ví dụ mỗi loại.','Có cả hai: có lợi (làm sữa chua, muối dưa); có hại (gây bệnh, làm ôi thiu thức ăn)'],
  [4,'Vì sao để thức ăn lâu ngoài không khí lại bị ôi thiu?','Vi khuẩn xâm nhập và sinh sôi làm thức ăn phân hủy, biến chất'],
  [4,'Nêu 2 cách bảo quản thức ăn hạn chế vi khuẩn phát triển.','Để lạnh/đông lạnh; phơi khô, ướp muối, đóng hộp kín'],
  [4,'Để phòng bệnh do vi khuẩn qua đường ăn uống, em cần làm gì?','Ăn chín uống sôi, rửa tay sạch, giữ vệ sinh thức ăn và dụng cụ'],
  [4,'Sữa chua được làm nhờ loại sinh vật nào?','Nhờ vi khuẩn có lợi (vi khuẩn lên men)'],
 ]);
 push('Khoa học',5,'Con người và sức khỏe',[
  [4,'Nêu các giai đoạn phát triển chính của con người.','Tuổi ấu thơ → tuổi dậy thì → tuổi trưởng thành → tuổi già'],
  [4,'Tuổi dậy thì có đặc điểm gì nổi bật?','Cơ thể lớn nhanh, có nhiều thay đổi về thể chất và tâm lí'],
  [4,'Nêu 3 việc nên làm để giữ cơ thể khỏe mạnh ở tuổi học trò.','Ăn đủ chất, ngủ đủ giấc, tập thể dục, giữ vệ sinh thân thể'],
  [4,'Vì sao không nên dùng chung bàn chải đánh răng, khăn mặt?','Dùng chung dễ lây truyền một số bệnh qua dịch cơ thể; nên dùng đồ dùng cá nhân riêng'],
  [4,'Nêu 2 việc nên làm để phòng tránh tai nạn đuối nước.','Không chơi gần ao hồ sông suối khi không có người lớn; học bơi và mặc áo phao khi đi thuyền'],
 ]);
 push('Khoa học',5,'Sinh vật và môi trường',[
  [4,'Môi trường cung cấp cho con người những gì?','Thức ăn, nước, không khí, đất, khoáng sản, nơi ở… (tài nguyên cho đời sống và sản xuất)'],
  [4,'Nêu 2 nguyên nhân làm rừng bị tàn phá.','Chặt phá rừng lấy gỗ, đốt rừng làm nương rẫy, cháy rừng'],
  [4,'Hậu quả của việc phá rừng là gì?','Lũ lụt, xói mòn đất, hạn hán, mất nơi ở của động vật, biến đổi khí hậu'],
  [4,'Nêu 3 việc làm để bảo vệ môi trường ở địa phương.','Trồng cây, bỏ rác đúng nơi, không xả nước thải bừa bãi, tiết kiệm điện nước'],
  [4,'Vì sao cần bảo vệ nguồn nước sạch?','Nước sạch cần cho ăn uống, sinh hoạt, sản xuất; ô nhiễm nước gây bệnh và thiếu nước dùng'],
 ]);

 /* ============ NGỮ VĂN THCS (nâng cao phần Tiếng Việt) ============ */
 push('Ngữ văn',6,'Tiếng Việt: từ loại, biện pháp tu từ',[
  [4,'Xác định biện pháp tu từ trong câu "Mặt trời xuống biển như hòn lửa." và nêu tác dụng.','So sánh (mặt trời – hòn lửa); gợi hình ảnh mặt trời đỏ rực, sinh động lúc hoàng hôn'],
  [4,'Gọi tên biện pháp tu từ: "Ông trời mặc áo giáp đen ra trận."','Nhân hóa (gọi trời bằng "ông", tả hành động "mặc áo giáp, ra trận")'],
  [4,'Phân biệt từ đơn và từ phức qua các từ: nhà, hoa hồng, xe đạp, cây.','Từ đơn: nhà, cây; Từ phức: hoa hồng, xe đạp'],
  [4,'Từ "chân" trong "chân bàn" và "chân người" là hiện tượng gì của từ?','Từ nhiều nghĩa (nghĩa chuyển và nghĩa gốc của từ "chân")'],
  [4,'Đặt một câu có sử dụng biện pháp so sánh.','VD: "Cánh đồng lúa chín vàng như một tấm thảm khổng lồ."'],
 ]);
 push('Ngữ văn',7,'Tiếng Việt: từ, cụm từ, dấu câu',[
  [4,'Xác định các cụm từ trong câu "Những học sinh ấy đang chăm chú nghe giảng."','Cụm danh từ: Những học sinh ấy; Cụm động từ: đang chăm chú nghe giảng'],
  [4,'Nêu công dụng của dấu chấm lửng (…).','Tỏ ý còn nhiều sự vật chưa liệt kê hết; thể hiện lời nói ngập ngừng, ngắt quãng; giãn nhịp câu'],
  [4,'Tìm số từ và lượng từ trong câu "Ba con mèo và những chú chim nhỏ."','Số từ: ba; Lượng từ: những'],
  [4,'Biện pháp tu từ trong câu "Trăng tròn như mắt cá" là gì?','So sánh'],
  [4,'Đặt câu có dùng dấu gạch ngang để đánh dấu bộ phận chú thích.','VD: "Lan – lớp trưởng lớp em – học rất giỏi."'],
 ]);
 push('Ngữ văn',8,'Tiếng Việt: câu, biện pháp tu từ',[
  [4,'Câu "Ôi, cảnh bình minh đẹp quá!" thuộc kiểu câu gì theo mục đích nói?','Câu cảm thán (bộc lộ cảm xúc)'],
  [4,'Xác định biện pháp tu từ và tác dụng: "Bàn tay ta làm nên tất cả / Có sức người sỏi đá cũng thành cơm."','Hoán dụ ("bàn tay" chỉ sức lao động) kết hợp nói quá; khẳng định sức mạnh lao động của con người'],
  [4,'Phân biệt câu ghép và câu đơn qua ví dụ "Trời mưa to nhưng em vẫn đi học."','Câu ghép — hai vế "Trời mưa to" và "em vẫn đi học", nối bằng quan hệ từ "nhưng"'],
  [4,'Biện pháp "nói giảm nói tránh" dùng để làm gì? Cho ví dụ.','Diễn đạt tế nhị, tránh gây cảm giác đau buồn/thô tục; VD: "Ông em đã đi xa" (thay cho "đã mất")'],
  [4,'Đặt một câu cầu khiến.','VD: "Em hãy đóng cửa sổ lại giúp cô!"'],
 ]);
 push('Ngữ văn',9,'Tiếng Việt: nghĩa của từ, cách dẫn',[
  [4,'Phân biệt cách dẫn trực tiếp và cách dẫn gián tiếp.','Dẫn trực tiếp: nhắc nguyên văn lời/ý, đặt trong dấu ngoặc kép; dẫn gián tiếp: thuật lại có điều chỉnh, không dùng ngoặc kép'],
  [4,'Chuyển sang lời dẫn gián tiếp: Lan nói: "Tôi sẽ đi học sớm."','VD: Lan nói rằng bạn ấy sẽ đi học sớm.'],
  [4,'Thành ngữ "nước đổ lá khoai" có nghĩa là gì?','Chỉ việc khuyên bảo vô ích, nói mà người nghe không tiếp thu'],
  [4,'Xác định nghĩa gốc và nghĩa chuyển của từ "đầu" trong "đầu người" và "đầu sông".','"đầu người": nghĩa gốc; "đầu sông": nghĩa chuyển'],
  [4,'Biện pháp tu từ trong "Mặt trời của bắp thì nằm trên đồi / Mặt trời của mẹ, em nằm trên lưng" là gì?','Ẩn dụ ("mặt trời của mẹ" chỉ đứa con) — thể hiện tình yêu con tha thiết của người mẹ'],
 ]);
})();
