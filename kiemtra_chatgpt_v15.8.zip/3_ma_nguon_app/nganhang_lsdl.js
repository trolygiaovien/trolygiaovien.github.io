/* ============================================================
   NGÂN HÀNG LỊCH SỬ VÀ ĐỊA LÍ (THCS) — bổ sung cho đủ chuẩn
   Mỗi mục: ≥6 trắc nghiệm + ≥4 tự luận + có câu nâng cao (mức 4).
   Câu hỏi nguyên bản, kiến thức bám SGK Kết nối tri thức.
   Lượt này: LỊCH SỬ – LỚP 6.
   TN [mức,'câu','ĐÚNG','sai','sai','sai'] · TL [mức,'câu','đáp án']
   ============================================================ */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Lịch sử và Địa lí';

 /* ===================== LỊCH SỬ – LỚP 6 ===================== */
 add(M,6,'Bài 1 (Lịch sử): Lịch sử và cuộc sống',[
  [1,'Lịch sử là gì?','Những gì đã diễn ra trong quá khứ','Những gì sẽ xảy ra','Chuyện tưởng tượng','Dự báo tương lai'],
  [1,'Môn Lịch sử là môn học tìm hiểu về điều gì?','Quá khứ của loài người','Thời tiết','Số học','Tiếng nước ngoài'],
  [2,'Vì sao chúng ta cần học lịch sử?','Để biết cội nguồn, hiểu quá khứ, rút kinh nghiệm cho hiện tại và tương lai','Để quên quá khứ','Để không cần cố gắng','Không có lí do'],
  [2,'Câu "Dân ta phải biết sử ta" nhắc nhở điều gì?','Người Việt cần hiểu biết lịch sử dân tộc mình','Chỉ học sử nước ngoài','Không cần học sử','Chỉ cần học toán'],
  [2,'Học lịch sử giúp em bồi dưỡng tình cảm nào?','Lòng yêu nước, tự hào dân tộc, biết ơn tổ tiên','Sự thờ ơ','Quên cội nguồn','Coi thường quá khứ'],
  [3,'Nêu ý nghĩa của việc học lịch sử.','Giúp hiểu cội nguồn dân tộc, quá trình dựng nước và giữ nước của cha ông; rút ra bài học kinh nghiệm; bồi dưỡng lòng yêu nước, tự hào dân tộc và ý thức trách nhiệm xây dựng, bảo vệ đất nước.'],
  [3,'Theo em, học lịch sử có cần thiết cho cuộc sống hiện tại không? Vì sao?','Cần thiết. Hiểu quá khứ giúp lí giải hiện tại, kế thừa truyền thống tốt đẹp, tránh lặp lại sai lầm; bồi đắp lòng yêu nước và định hướng cho tương lai.'],
  [4,'Vì sao nói "Lịch sử là thầy dạy của cuộc sống"?','Qua lịch sử, con người rút ra bài học từ thành công và thất bại của quá khứ để ứng xử, hành động đúng đắn hơn trong hiện tại và tương lai; lịch sử giúp hiểu quy luật phát triển, kế thừa kinh nghiệm — như người thầy dạy cho cuộc sống.']
 ]);
 add(M,6,'Bài 2 (Lịch sử): Dựa vào đâu để biết và phục dựng lại lịch sử',[
  [1,'Người ta dựa vào đâu để biết và phục dựng lại lịch sử?','Các nguồn tư liệu lịch sử','Trí tưởng tượng','Dự báo thời tiết','Suy đoán vô căn cứ'],
  [1,'Trống đồng, mũi tên đồng, công cụ đá là loại tư liệu nào?','Tư liệu hiện vật','Tư liệu chữ viết','Tư liệu truyền miệng','Không phải tư liệu'],
  [2,'Truyền thuyết, ca dao, truyện kể dân gian là loại tư liệu nào?','Tư liệu truyền miệng','Tư liệu hiện vật','Tư liệu chữ viết','Không phải tư liệu'],
  [2,'Bia đá, sách cổ, văn bản chữ viết là loại tư liệu nào?','Tư liệu chữ viết','Tư liệu hiện vật','Tư liệu truyền miệng','Tư liệu gốc duy nhất'],
  [2,'Tư liệu gốc là loại tư liệu như thế nào?','Tư liệu liên quan trực tiếp, ra đời vào thời kì diễn ra sự kiện','Tư liệu người đời sau viết','Chuyện tưởng tượng','Suy đoán'],
  [3,'Kể tên các loại tư liệu lịch sử và cho ví dụ.','Tư liệu hiện vật (trống đồng, công cụ đá, thành cổ); tư liệu chữ viết (bia đá, sách cổ); tư liệu truyền miệng (truyền thuyết, ca dao, truyện kể). Tư liệu gốc là tư liệu có giá trị tin cậy cao.'],
  [3,'Vì sao tư liệu hiện vật được coi là bằng chứng quan trọng để tìm hiểu lịch sử?','Vì hiện vật là những gì còn lại thật từ quá khứ, phản ánh trực tiếp đời sống, kĩ thuật của người xưa; giúp kiểm chứng và phục dựng lịch sử một cách khách quan, đáng tin cậy.'],
  [4,'Vì sao cần kết hợp nhiều nguồn tư liệu khi nghiên cứu lịch sử?','Mỗi loại tư liệu có ưu điểm và hạn chế riêng (truyền miệng dễ sai lệch, hiện vật không nói hết sự kiện...). Kết hợp, đối chiếu nhiều nguồn giúp kiểm chứng lẫn nhau, phục dựng lịch sử đầy đủ, chính xác và khách quan hơn.']
 ]);
 add(M,6,'Bài 3 (Lịch sử): Thời gian trong lịch sử',[
  [1,'Hai cách tính lịch chính của con người là gì?','Dương lịch và âm lịch','Chỉ dương lịch','Chỉ âm lịch','Lịch vạn niên duy nhất'],
  [1,'Dương lịch được tính dựa theo chu kì chuyển động của thiên thể nào?','Trái Đất quanh Mặt Trời','Mặt Trăng quanh Trái Đất','Các vì sao','Sao chổi'],
  [2,'Âm lịch được tính dựa theo chu kì của thiên thể nào?','Mặt Trăng quay quanh Trái Đất','Trái Đất quanh Mặt Trời','Mặt Trời','Sao Kim'],
  [2,'Một thế kỉ bằng bao nhiêu năm?','100 năm','10 năm','1000 năm','50 năm'],
  [2,'Công nguyên (CN) được lấy làm mốc tính thời gian; TCN nghĩa là gì?','Trước Công nguyên','Sau Công nguyên','Thế kỉ mới','Thiên niên kỉ'],
  [3,'Một thiên niên kỉ, một thế kỉ, một thập kỉ lần lượt bằng bao nhiêu năm?','Thiên niên kỉ: 1000 năm; thế kỉ: 100 năm; thập kỉ: 10 năm.'],
  [3,'Năm 179 TCN thuộc thế kỉ nào trước Công nguyên? Giải thích.','Thuộc thế kỉ II TCN. Vì các năm từ 101 đến 200 TCN thuộc thế kỉ II TCN (lấy phần trăm làm thế kỉ, năm có ba chữ số 1xx TCN thuộc thế kỉ II TCN).'],
  [4,'Vì sao con người cần xác định và thống nhất cách tính thời gian trong lịch sử?','Để ghi chép, sắp xếp các sự kiện theo đúng trình tự trước – sau, tính khoảng cách thời gian; nhờ đó nghiên cứu, trình bày lịch sử chính xác, mọi người hiểu thống nhất. Không có cách tính thời gian thống nhất sẽ rối loạn, khó xác định sự kiện.']
 ]);
 add(M,6,'Bài 4 (Lịch sử): Nguồn gốc loài người',[
  [1,'Loài người có nguồn gốc tiến hóa từ loài nào?','Một loài vượn người cổ','Loài cá','Loài chim','Tự nhiên sinh ra'],
  [1,'Quá trình tiến hóa từ vượn người đến con người trải qua các dạng nào?','Vượn người → Người tối cổ → Người tinh khôn','Người tinh khôn → vượn','Không thay đổi','Chỉ có một dạng'],
  [2,'Người tối cổ đã biết làm gì để tồn tại?','Chế tạo công cụ đá, biết dùng lửa','Dùng máy tính','Trồng lúa nước hiện đại','Đi xe'],
  [2,'Người tinh khôn (Homo sapiens) có đặc điểm gì so với Người tối cổ?','Hình dáng, cấu tạo cơ thể gần như người ngày nay, tiến bộ hơn','Giống hệt vượn','Không biết chế tạo công cụ','Không biết dùng lửa'],
  [2,'Việc phát hiện và sử dụng lửa có ý nghĩa gì với Người tối cổ?','Sưởi ấm, nấu chín thức ăn, xua thú dữ','Không có tác dụng','Làm hại con người','Chỉ để chơi'],
  [3,'Nêu các giai đoạn tiến hóa từ vượn người thành người.','Vượn người (sống cách đây hàng triệu năm) → Người tối cổ (biết chế tạo công cụ đá thô sơ, dùng lửa) → Người tinh khôn (cơ thể gần như người ngày nay, công cụ tiến bộ hơn).'],
  [3,'Nêu một số tiến bộ của Người tối cổ so với loài vượn.','Đi đứng bằng hai chân, hai tay tự do; biết chế tạo và sử dụng công cụ bằng đá; biết dùng lửa; sống thành bầy, biết hợp tác kiếm ăn.'],
  [4,'Vì sao việc biết chế tạo công cụ lao động được xem là bước tiến quan trọng, đánh dấu con người khác hẳn con vật?','Nhờ chế tạo công cụ, con người chủ động cải tạo tự nhiên, kiếm sống hiệu quả hơn thay vì phụ thuộc hoàn toàn vào tự nhiên như con vật; lao động và chế tạo công cụ còn phát triển bàn tay, bộ não, ngôn ngữ — là yếu tố quyết định đưa vượn người thành người.']
 ]);
 add(M,6,'Bài 5 (Lịch sử): Xã hội nguyên thủy',[
  [1,'Tổ chức xã hội đầu tiên của loài người là gì?','Bầy người nguyên thủy','Nhà nước','Thành bang','Đế quốc'],
  [1,'Thị tộc là tổ chức gồm những người như thế nào?','Những người có quan hệ họ hàng, cùng huyết thống','Người xa lạ','Người của nhiều nước','Người không quan hệ'],
  [2,'Công cụ lao động chủ yếu của người nguyên thủy làm bằng gì?','Đá (thời kì đồ đá)','Sắt thép hiện đại','Nhựa','Nhôm'],
  [2,'Trong xã hội nguyên thủy, của cải được phân chia như thế nào?','Chung, công bằng (chưa có tư hữu)','Kẻ giàu người nghèo rõ rệt','Vua chiếm hết','Chỉ một người có'],
  [2,'Nhiều thị tộc sống gần nhau, có quan hệ với nhau hợp thành tổ chức nào?','Bộ lạc','Nhà nước','Đế quốc','Thành bang'],
  [3,'Phân biệt bầy người nguyên thủy, thị tộc và bộ lạc.','Bầy người nguyên thủy: nhóm người sống cùng, chưa chặt chẽ. Thị tộc: những người cùng huyết thống, quan hệ gắn bó. Bộ lạc: gồm nhiều thị tộc có quan hệ sống gần nhau.'],
  [3,'Nêu đời sống của người nguyên thủy.','Sống thành bầy, thị tộc; kiếm sống bằng săn bắt, hái lượm; dùng công cụ đá; biết dùng lửa; của cải chung, làm chung, hưởng chung, bình đẳng.'],
  [4,'Vì sao trong xã hội nguyên thủy con người phải sống thành bầy, thị tộc và làm chung, hưởng chung?','Vì công cụ thô sơ, năng suất lao động thấp, một người không thể tự tồn tại trước thiên nhiên và thú dữ; phải chung sức săn bắt, hái lượm, chia đều của cải để cùng sống sót. Điều kiện sản xuất thấp quy định quan hệ công bằng, bình đẳng đó.']
 ]);
 add(M,6,'Bài 6 (Lịch sử): Sự biến chuyển và phân hóa của xã hội nguyên thủy',[
  [1,'Phát minh quan trọng làm thay đổi xã hội nguyên thủy là gì?','Con người biết chế tạo và sử dụng công cụ bằng kim loại','Phát minh máy tính','Phát minh ô tô','Phát minh điện thoại'],
  [1,'Kim loại đầu tiên con người sử dụng là gì?','Đồng','Sắt hiện đại','Nhôm','Vàng nguyên chất'],
  [2,'Công cụ kim loại ra đời dẫn đến hệ quả gì về sản xuất?','Năng suất lao động tăng, tạo ra của cải dư thừa','Năng suất giảm','Không ảnh hưởng','Mất mùa'],
  [2,'Của cải dư thừa dẫn đến điều gì trong xã hội?','Sự phân hóa giàu – nghèo, xuất hiện tư hữu','Mọi người bằng nhau mãi','Không ai có của cải','Xã hội tan rã ngay'],
  [2,'Sự phân hóa xã hội là tiền đề dẫn tới sự ra đời của cái gì?','Nhà nước','Thị tộc','Bầy người','Công cụ đá'],
  [3,'Nêu tác động của việc sử dụng công cụ kim loại đến xã hội nguyên thủy.','Năng suất lao động tăng, tạo của cải dư thừa; xuất hiện tư hữu; xã hội phân hóa giàu – nghèo, kẻ có quyền và người phụ thuộc; xã hội nguyên thủy dần tan rã, tiến tới xã hội có giai cấp và nhà nước.'],
  [3,'Vì sao công cụ kim loại làm tăng năng suất lao động hơn công cụ đá?','Kim loại (đồng, sắt) cứng, sắc, bền hơn đá; dễ chế tạo nhiều loại công cụ (lưỡi cày, rìu, dao...); giúp khai phá đất, sản xuất nhanh và hiệu quả hơn, nên năng suất tăng cao.'],
  [4,'Vì sao sự xuất hiện của cải dư thừa lại dẫn đến sự tan rã của xã hội nguyên thủy?','Khi có của cải dư thừa, một số người chiếm làm của riêng (tư hữu), xã hội phân chia giàu – nghèo, không còn công bằng, bình đẳng như trước. Quan hệ "làm chung, hưởng chung" bị phá vỡ, dẫn tới xã hội có giai cấp và nhà nước ra đời, xã hội nguyên thủy tan rã.']
 ]);
 add(M,6,'Bài 7 (Lịch sử): Ai Cập và Lưỡng Hà cổ đại',[
  [1,'Nền văn minh Ai Cập cổ đại hình thành bên dòng sông nào?','Sông Nin','Sông Hằng','Sông Hoàng Hà','Sông Nil Xanh duy nhất'],
  [1,'Lưỡng Hà cổ đại nằm giữa hai con sông nào?','Sông Ti-grơ và sông Ơ-phrát','Sông Nin và sông Hằng','Hoàng Hà và Trường Giang','Sông Ấn và sông Hằng'],
  [2,'Công trình kiến trúc nổi tiếng của Ai Cập cổ đại là gì?','Kim tự tháp','Vạn Lí Trường Thành','Đền Pác-tê-nông','Đấu trường La Mã'],
  [2,'Người Ai Cập cổ đại sáng tạo ra loại chữ viết nào?','Chữ tượng hình','Chữ La-tinh','Chữ Hán','Chữ Quốc ngữ'],
  [2,'Vì sao các nền văn minh cổ đại thường hình thành ở lưu vực các dòng sông lớn?','Đất phù sa màu mỡ, nguồn nước thuận lợi cho trồng trọt, sinh sống','Vì ở đó lạnh','Vì không có nước','Vì khô cằn'],
  [3,'Nêu những thành tựu tiêu biểu của Ai Cập và Lưỡng Hà cổ đại.','Chữ viết (tượng hình); toán học, thiên văn, làm lịch; kiến trúc (kim tự tháp Ai Cập, vườn treo Ba-bi-lon); kĩ thuật ướp xác; luật pháp (bộ luật Ha-mu-ra-bi của Lưỡng Hà).'],
  [3,'Vì sao sông Nin có vai trò quan trọng với Ai Cập cổ đại?','Sông Nin bồi đắp phù sa màu mỡ cho đất đai, cung cấp nước cho trồng trọt, sinh hoạt và giao thông. Nhờ sông Nin, nông nghiệp phát triển, dân cư tập trung, hình thành nền văn minh Ai Cập rực rỡ.'],
  [4,'Vì sao nói các dòng sông lớn là "cái nôi" của các nền văn minh cổ đại phương Đông?','Lưu vực sông lớn có đất phù sa màu mỡ, nước tưới dồi dào, thuận lợi cho nông nghiệp; nhờ đó dân cư đông đúc, của cải dư thừa, nhà nước và văn minh sớm ra đời (Ai Cập bên sông Nin, Lưỡng Hà, Ấn Độ, Trung Quốc). Vì vậy các dòng sông được coi là cái nôi của văn minh.']
 ]);
 add(M,6,'Bài 8 (Lịch sử): Ấn Độ cổ đại',[
  [1,'Nền văn minh Ấn Độ cổ đại gắn với hai dòng sông nào?','Sông Ấn và sông Hằng','Sông Nin và Ti-grơ','Hoàng Hà và Trường Giang','Sông Nin và sông Hằng'],
  [1,'Chế độ xã hội đặc trưng của Ấn Độ cổ đại là gì?','Chế độ đẳng cấp (varna)','Chế độ dân chủ','Chế độ cộng hòa','Không phân chia xã hội'],
  [2,'Tôn giáo nào ra đời ở Ấn Độ cổ đại?','Đạo Bà La Môn (Hindu) và Phật giáo','Đạo Hồi duy nhất','Đạo Thiên Chúa','Không có tôn giáo'],
  [2,'Người sáng lập Phật giáo là ai?','Thích Ca Mâu Ni (Xít-đác-ta Gô-ta-ma)','Khổng Tử','Giê-su','Mô-ha-mét'],
  [2,'Chế độ đẳng cấp ở Ấn Độ cổ đại thể hiện điều gì?','Sự phân biệt địa vị, quyền lợi giữa các tầng lớp người','Sự bình đẳng hoàn toàn','Dân chủ','Không có phân biệt'],
  [3,'Nêu một số thành tựu văn hóa tiêu biểu của Ấn Độ cổ đại.','Chữ viết (chữ Phạn); tôn giáo (Bà La Môn/Hindu, Phật giáo); toán học (phát minh hệ số đếm, chữ số và số 0); văn học, kiến trúc, điêu khắc độc đáo.'],
  [3,'Chế độ đẳng cấp (varna) ở Ấn Độ cổ đại có đặc điểm gì?','Xã hội chia thành các đẳng cấp với địa vị, quyền lợi khác nhau, phân biệt khắt khe; đẳng cấp trên có nhiều quyền lợi, đẳng cấp dưới chịu thiệt thòi; sự phân biệt mang tính cha truyền con nối.'],
  [4,'Vì sao phát minh ra chữ số và số 0 của người Ấn Độ cổ đại được coi là đóng góp lớn cho nhân loại?','Hệ chữ số (được gọi là chữ số Ả Rập) và đặc biệt số 0 giúp việc ghi số, tính toán trở nên đơn giản, chính xác, là nền tảng cho toán học và khoa học phát triển. Phát minh này được cả thế giới sử dụng đến ngày nay, nên có ý nghĩa to lớn.']
 ]);
 add(M,6,'Bài 9 (Lịch sử): Trung Quốc cổ đại',[
  [1,'Nền văn minh Trung Quốc cổ đại hình thành bên lưu vực sông nào?','Hoàng Hà và Trường Giang','Sông Nin','Sông Ấn và sông Hằng','Ti-grơ và Ơ-phrát'],
  [1,'Ai là người đã thống nhất Trung Quốc, lập ra nhà Tần?','Tần Thủy Hoàng','Khổng Tử','Hán Vũ Đế','Lưu Bang đầu tiên'],
  [2,'Công trình nổi tiếng được xây dựng để phòng thủ ở Trung Quốc cổ đại là gì?','Vạn Lí Trường Thành','Kim tự tháp','Đấu trường La Mã','Vườn treo Ba-bi-lon'],
  [2,'Nhà tư tưởng lớn của Trung Quốc cổ đại, sáng lập Nho giáo là ai?','Khổng Tử','Thích Ca','Tần Thủy Hoàng','Lão Tử là người duy nhất'],
  [2,'Người Trung Quốc cổ đại sáng tạo ra loại chữ viết nào?','Chữ Hán (chữ tượng hình)','Chữ La-tinh','Chữ Phạn','Chữ Quốc ngữ'],
  [3,'Nêu một số thành tựu tiêu biểu của văn minh Trung Quốc cổ đại.','Chữ viết (chữ Hán); tư tưởng (Nho giáo của Khổng Tử, Đạo giáo); sử học, văn học; kĩ thuật (làm giấy, la bàn...); kiến trúc (Vạn Lí Trường Thành); làm lịch.'],
  [3,'Việc Tần Thủy Hoàng thống nhất Trung Quốc có ý nghĩa gì?','Chấm dứt tình trạng chia cắt, tạo nên một quốc gia thống nhất rộng lớn; thống nhất tiền tệ, chữ viết, đo lường, tạo điều kiện cho kinh tế, văn hóa phát triển và quản lí đất nước.'],
  [4,'Vì sao những thành tựu văn minh Trung Quốc cổ đại (chữ viết, Nho giáo, kĩ thuật...) có ảnh hưởng lớn đến nhiều nước, trong đó có Việt Nam?','Trung Quốc là nền văn minh lớn, lâu đời; qua giao lưu, tiếp xúc (buôn bán, di cư, đô hộ), các thành tựu như chữ Hán, Nho giáo, kĩ thuật, lịch pháp lan tỏa sang các nước lân cận. Việt Nam tiếp thu có chọn lọc, vận dụng phù hợp, góp phần làm phong phú văn hóa dân tộc.']
 ]);
 add(M,6,'Bài 10 (Lịch sử): Hy Lạp và La Mã cổ đại',[
  [1,'Nhà nước Hy Lạp cổ đại được tổ chức theo hình thức nào?','Các thành bang (thị quốc)','Một đế quốc thống nhất','Các bộ lạc','Thị tộc'],
  [1,'Thành bang nổi tiếng với nền dân chủ ở Hy Lạp cổ đại là gì?','A-ten (Athens)','Rô-ma','Ba-bi-lon','Mem-phít'],
  [2,'La Mã cổ đại về sau phát triển thành hình thức nhà nước nào?','Đế chế (đế quốc) La Mã rộng lớn','Thành bang nhỏ','Bộ lạc','Thị tộc'],
  [2,'Hy Lạp và La Mã cổ đại nằm ở khu vực nào?','Ven Địa Trung Hải (Nam Âu)','Đông Á','Nam Á','Bắc Phi sa mạc'],
  [2,'Hệ chữ cái La-tinh ngày nay có nguồn gốc từ nền văn minh nào?','Hy Lạp – La Mã cổ đại','Ai Cập','Trung Quốc','Ấn Độ'],
  [3,'Nêu một số thành tựu tiêu biểu của văn minh Hy Lạp – La Mã cổ đại.','Hệ chữ cái La-tinh (cơ sở của nhiều ngôn ngữ châu Âu); lịch (dương lịch); khoa học (toán, vật lí, triết học); văn học, sử học; kiến trúc, điêu khắc (đền Pác-tê-nông, đấu trường La Mã); thể chế dân chủ ở A-ten.'],
  [3,'Nền dân chủ ở thành bang A-ten có đặc điểm gì?','Công dân (nam giới tự do) được tham gia bàn bạc, quyết định các công việc của thành bang qua Đại hội nhân dân; đề cao vai trò của công dân. Tuy nhiên dân chủ này còn hạn chế (nô lệ, phụ nữ, người nước ngoài không có quyền).'],
  [4,'Vì sao các thành tựu của văn minh Hy Lạp – La Mã cổ đại (chữ viết, khoa học, dân chủ...) vẫn có giá trị đến ngày nay?','Nhiều thành tựu là nền tảng của văn minh phương Tây và nhân loại: hệ chữ La-tinh dùng rộng rãi; các định lí toán học, tư tưởng triết học vẫn được học; mô hình dân chủ, luật pháp La Mã ảnh hưởng đến thể chế hiện đại. Vì giá trị khoa học và nhân văn sâu sắc nên chúng còn nguyên ý nghĩa.']
 ]);
 add(M,6,'Bài 11 (Lịch sử): Các quốc gia sơ kì ở Đông Nam Á',[
  [1,'Các quốc gia sơ kì ở Đông Nam Á ra đời chủ yếu dựa trên nền kinh tế nào?','Nông nghiệp trồng lúa nước','Công nghiệp nặng','Du mục','Thương mại hàng không'],
  [1,'Khu vực Đông Nam Á có vị trí như thế nào?','Nằm trên đường giao thương giữa Ấn Độ và Trung Quốc','Giữa sa mạc','Vùng băng giá','Tách biệt hoàn toàn'],
  [2,'Điều kiện tự nhiên thuận lợi cho các quốc gia sơ kì ĐNA là gì?','Khí hậu nhiệt đới gió mùa, nhiều sông, đất phù sa màu mỡ','Sa mạc khô cằn','Băng tuyết','Không có nước'],
  [2,'Hoạt động kinh tế quan trọng của cư dân Đông Nam Á sơ kì là gì?','Trồng lúa nước và buôn bán (giao thương biển)','Chỉ chăn nuôi du mục','Chỉ khai thác dầu mỏ','Chỉ làm công nghiệp'],
  [2,'Nhờ vị trí giao thương, Đông Nam Á sớm tiếp nhận văn hóa từ đâu?','Ấn Độ và Trung Quốc','Châu Mỹ','Bắc Cực','Nam Cực'],
  [3,'Nêu những điều kiện dẫn đến sự ra đời của các quốc gia sơ kì ở Đông Nam Á.','Điều kiện tự nhiên thuận lợi (khí hậu nhiệt đới, sông ngòi, đất màu mỡ) phát triển nông nghiệp trồng lúa nước; vị trí nằm trên đường giao thương Đông – Tây thúc đẩy buôn bán; tiếp thu văn hóa Ấn Độ, Trung Quốc; sản xuất phát triển dẫn đến phân hóa xã hội và hình thành nhà nước.'],
  [3,'Vì sao vị trí địa lí có vai trò quan trọng với sự phát triển của các quốc gia Đông Nam Á sơ kì?','Đông Nam Á nằm trên con đường giao thương biển giữa Ấn Độ và Trung Quốc, là nơi thuyền buôn qua lại, trao đổi hàng hóa. Nhờ đó cư dân phát triển buôn bán, tiếp thu văn hóa, kĩ thuật từ bên ngoài, thúc đẩy kinh tế và sự ra đời của các quốc gia.'],
  [4,'Vì sao nông nghiệp trồng lúa nước được coi là cơ sở hình thành các quốc gia sơ kì ở Đông Nam Á?','Trồng lúa nước cho năng suất cao, tạo nguồn lương thực ổn định, nuôi sống đông dân cư; đòi hỏi hợp tác làm thủy lợi, dẫn tới tổ chức cộng đồng chặt chẽ. Sản xuất phát triển tạo của cải dư thừa, phân hóa xã hội, là cơ sở để các nhà nước sơ kì ra đời.']
 ]);
 add(M,6,'Bài 13 (Lịch sử): Giao lưu văn hóa ở Đông Nam Á từ đầu Công nguyên đến thế kỉ X',[
  [1,'Trong giai đoạn này, văn hóa Đông Nam Á chịu ảnh hưởng lớn từ đâu?','Ấn Độ và Trung Quốc','Châu Mỹ','Bắc Âu','Châu Phi'],
  [1,'Tôn giáo nào từ Ấn Độ được truyền bá vào Đông Nam Á?','Phật giáo và Hin-đu giáo (Bà La Môn)','Chỉ đạo Hồi','Đạo Thiên Chúa','Không có tôn giáo'],
  [2,'Giao lưu văn hóa có tác động gì đến Đông Nam Á?','Làm phong phú văn hóa bản địa (chữ viết, tôn giáo, kiến trúc...)','Xóa bỏ văn hóa bản địa','Không ảnh hưởng gì','Làm nghèo văn hóa'],
  [2,'Nhiều công trình kiến trúc ở Đông Nam Á chịu ảnh hưởng của văn hóa Ấn Độ thể hiện qua điều gì?','Các đền, tháp mang phong cách Hin-đu giáo, Phật giáo','Nhà cao tầng hiện đại','Đấu trường La Mã','Kim tự tháp'],
  [2,'Cư dân Đông Nam Á tiếp thu văn hóa bên ngoài theo cách nào?','Tiếp thu có chọn lọc, sáng tạo phù hợp với bản địa','Sao chép nguyên vẹn','Từ chối hoàn toàn','Chỉ bắt chước'],
  [3,'Nêu những ảnh hưởng của văn hóa Ấn Độ và Trung Quốc đến Đông Nam Á.','Về chữ viết (nhiều nước dựa trên chữ Phạn, chữ Hán); tôn giáo (Phật giáo, Hin-đu giáo, Nho giáo); kiến trúc, điêu khắc (đền, tháp); văn học, lịch pháp, tổ chức nhà nước.'],
  [3,'Vì sao nói cư dân Đông Nam Á tiếp thu văn hóa bên ngoài một cách chủ động, sáng tạo?','Họ không sao chép nguyên vẹn mà chọn lọc những yếu tố phù hợp, kết hợp với văn hóa bản địa để tạo nên nét riêng (kiến trúc đền tháp mang bản sắc từng dân tộc, chữ viết cải biến...). Nhờ đó văn hóa Đông Nam Á vừa phong phú vừa giữ được bản sắc.'],
  [4,'Vì sao giao lưu văn hóa vừa làm phong phú vừa giúp giữ gìn bản sắc của các dân tộc Đông Nam Á?','Giao lưu giúp tiếp thu thành tựu (tôn giáo, chữ viết, kĩ thuật) làm giàu thêm văn hóa; đồng thời do tiếp thu có chọn lọc, sáng tạo, kết hợp với yếu tố bản địa nên không bị đồng hóa mà hình thành nét riêng. Vì vậy vừa phong phú vừa giữ được bản sắc.']
 ]);
 add(M,6,'Bài 14 (Lịch sử): Nhà nước Văn Lang, Âu Lạc',[
  [1,'Nhà nước Văn Lang do ai đứng đầu?','Các vua Hùng','An Dương Vương','Hai Bà Trưng','Ngô Quyền'],
  [1,'Kinh đô của nước Văn Lang đặt ở đâu?','Phong Châu (Phú Thọ ngày nay)','Cổ Loa','Hoa Lư','Thăng Long'],
  [2,'Nhà nước Âu Lạc do ai lập ra?','An Dương Vương (Thục Phán)','Vua Hùng','Hai Bà Trưng','Lý Bí'],
  [2,'Kinh đô của nước Âu Lạc là ở đâu?','Cổ Loa (Đông Anh, Hà Nội ngày nay)','Phong Châu','Hoa Lư','Thăng Long'],
  [2,'Thành tựu quân sự nổi bật của nước Âu Lạc là gì?','Xây thành Cổ Loa và chế tạo nỏ (bắn nhiều tên)','Vạn Lí Trường Thành','Kim tự tháp','Đấu trường'],
  [3,'Nêu đời sống vật chất và tinh thần của cư dân Văn Lang – Âu Lạc.','Vật chất: trồng lúa nước, chăn nuôi, làm nghề thủ công (đúc đồng, làm gốm), ở nhà sàn, ăn cơm, mặc vải. Tinh thần: thờ cúng tổ tiên, thần tự nhiên; có nhiều lễ hội, phong tục (xăm mình, nhuộm răng, ăn trầu); trống đồng là biểu tượng văn hóa.'],
  [3,'Nêu ý nghĩa sự ra đời của nhà nước Văn Lang.','Là nhà nước đầu tiên của người Việt, mở đầu thời kì dựng nước; đánh dấu bước phát triển của xã hội, tạo nền tảng cho truyền thống dân tộc; là cội nguồn, niềm tự hào của dân tộc Việt Nam.'],
  [4,'Vì sao sự ra đời của Nhà nước Văn Lang – Âu Lạc có ý nghĩa to lớn trong lịch sử dân tộc?','Đây là những nhà nước đầu tiên, mở đầu lịch sử dựng nước và giữ nước; hình thành nền văn minh sông Hồng với nhiều thành tựu (trống đồng, thành Cổ Loa, nỏ); tạo nên cội nguồn, bản sắc và truyền thống yêu nước, đoàn kết của dân tộc, là niềm tự hào được các thế hệ sau gìn giữ.']
 ]);
 add(M,6,'Bài 16 (Lịch sử): Các cuộc khởi nghĩa tiêu biểu giành độc lập trước thế kỉ X',[
  [1,'Cuộc khởi nghĩa Hai Bà Trưng nổ ra vào năm nào?','Năm 40','Năm 248','Năm 542','Năm 938'],
  [1,'Hai Bà Trưng khởi nghĩa chống lại ách đô hộ của triều đại phương Bắc nào?','Nhà Hán','Nhà Đường','Nhà Tống','Nhà Minh'],
  [2,'Cuộc khởi nghĩa Bà Triệu (năm 248) chống lại ách đô hộ của triều đại nào?','Nhà Ngô','Nhà Hán','Nhà Đường','Nhà Minh'],
  [2,'Lý Bí lãnh đạo khởi nghĩa (năm 542) thắng lợi đã lập ra nhà nước nào?','Nước Vạn Xuân','Nước Âu Lạc','Nước Đại Cồ Việt','Nước Đại Việt'],
  [2,'Các cuộc khởi nghĩa trước thế kỉ X thể hiện điều gì của dân tộc ta?','Tinh thần yêu nước, ý chí đấu tranh giành độc lập','Sự khuất phục','Sự thờ ơ','Chấp nhận đô hộ'],
  [3,'Kể tên một số cuộc khởi nghĩa tiêu biểu giành độc lập trước thế kỉ X.','Khởi nghĩa Hai Bà Trưng (năm 40); khởi nghĩa Bà Triệu (năm 248); khởi nghĩa Lý Bí (năm 542) lập nước Vạn Xuân; khởi nghĩa Mai Thúc Loan; khởi nghĩa Phùng Hưng.'],
  [3,'Nêu ý nghĩa của cuộc khởi nghĩa Hai Bà Trưng.','Thể hiện tinh thần yêu nước, ý chí quật cường và vai trò to lớn của phụ nữ Việt Nam; giành lại độc lập trong thời gian ngắn; cổ vũ, khích lệ tinh thần đấu tranh giành độc lập của dân tộc trong các giai đoạn sau.'],
  [4,'Vì sao các cuộc khởi nghĩa liên tiếp nổ ra trong hơn một nghìn năm Bắc thuộc lại có ý nghĩa quan trọng?','Dù nhiều cuộc bị đàn áp, các cuộc khởi nghĩa liên tiếp thể hiện tinh thần yêu nước, ý chí không chịu khuất phục của dân tộc; duy trì khát vọng độc lập; hun đúc truyền thống đấu tranh, tạo tiền đề và sức mạnh để cuối cùng giành lại độc lập hoàn toàn vào thế kỉ X.']
 ]);
 add(M,6,'Bài 17 (Lịch sử): Cuộc đấu tranh bảo tồn và phát triển văn hóa dân tộc của người Việt',[
  [1,'Trong hơn một nghìn năm Bắc thuộc, các triều đại phương Bắc thực hiện chính sách gì về văn hóa?','Đồng hóa dân tộc Việt','Tôn trọng văn hóa Việt','Phát triển văn hóa Việt','Không can thiệp'],
  [1,'Nhân dân ta đã làm gì để bảo tồn văn hóa dân tộc?','Giữ gìn tiếng nói, phong tục, tập quán của tổ tiên','Từ bỏ tiếng Việt','Quên phong tục','Theo hoàn toàn văn hóa ngoại bang'],
  [2,'Phong tục, tập quán nào của người Việt được giữ gìn qua thời Bắc thuộc?','Thờ cúng tổ tiên, ăn trầu, nhuộm răng, làm bánh chưng bánh giầy','Hoàn toàn theo phương Bắc','Không còn phong tục nào','Bỏ hết lễ hội'],
  [2,'Việc nhân dân ta vẫn giữ được tiếng nói (tiếng Việt) có ý nghĩa gì?','Giữ được bản sắc, chống lại âm mưu đồng hóa','Không có ý nghĩa','Làm mất bản sắc','Bị đồng hóa nhanh hơn'],
  [2,'Người Việt tiếp thu văn hóa Hán theo cách nào?','Tiếp thu có chọn lọc, "Việt hóa" cho phù hợp','Tiếp thu nguyên vẹn','Từ chối hoàn toàn','Chỉ bắt chước'],
  [3,'Nêu những việc nhân dân ta đã làm để bảo tồn và phát triển văn hóa dân tộc thời Bắc thuộc.','Giữ gìn tiếng nói (tiếng Việt); duy trì phong tục, tập quán (thờ cúng tổ tiên, ăn trầu, nhuộm răng, làm bánh chưng, bánh giầy, lễ hội); tiếp thu có chọn lọc văn hóa Hán và "Việt hóa".'],
  [3,'Vì sao giữ gìn được tiếng nói và phong tục là cơ sở để dân tộc ta không bị đồng hóa?','Tiếng nói, phong tục là linh hồn, bản sắc của dân tộc; giữ được chúng nghĩa là giữ được cốt lõi văn hóa và ý thức dân tộc. Dù bị đô hộ lâu dài, nhờ kiên trì bảo tồn tiếng nói, phong tục, dân tộc ta không bị đồng hóa và nuôi dưỡng được ý chí giành độc lập.'],
  [4,'Vì sao cuộc đấu tranh bảo tồn văn hóa cũng quan trọng không kém đấu tranh vũ trang trong thời Bắc thuộc?','Đấu tranh vũ trang giành lại chính quyền, còn giữ gìn văn hóa, tiếng nói giữ được bản sắc và ý thức dân tộc — nền tảng tinh thần để dân tộc tồn tại và khát khao độc lập. Nếu bị đồng hóa về văn hóa thì dù có khởi nghĩa cũng mất gốc. Vì vậy hai cuộc đấu tranh gắn bó, đều quan trọng.']
 ]);
 add(M,6,'Bài 18 (Lịch sử): Bước ngoặt lịch sử đầu thế kỉ X',[
  [1,'Người đặt nền móng cho nền tự chủ của dân tộc đầu thế kỉ X là ai?','Khúc Thừa Dụ','Ngô Quyền','Lý Bí','Đinh Bộ Lĩnh'],
  [1,'Chiến thắng Bạch Đằng năm 938 do ai lãnh đạo?','Ngô Quyền','Khúc Thừa Dụ','Hai Bà Trưng','Lý Bí'],
  [2,'Chiến thắng Bạch Đằng năm 938 đánh bại quân xâm lược nào?','Quân Nam Hán','Quân Hán','Quân Đường','Quân Tống'],
  [2,'Kế sách nổi tiếng Ngô Quyền dùng trên sông Bạch Đằng là gì?','Đóng cọc gỗ bịt sắt dưới lòng sông, lợi dụng thủy triều','Dùng voi chiến','Xây thành cao','Dùng kị binh'],
  [2,'Chiến thắng Bạch Đằng năm 938 có ý nghĩa gì?','Chấm dứt hơn 1000 năm Bắc thuộc, mở ra thời kì độc lập lâu dài','Mở đầu thời Bắc thuộc','Không có ý nghĩa','Làm mất độc lập'],
  [3,'Trình bày diễn biến chính của chiến thắng Bạch Đằng năm 938.','Ngô Quyền cho đóng cọc gỗ bịt sắt dưới lòng sông Bạch Đằng. Khi thủy triều lên, ông cho thuyền nhẹ ra khiêu chiến, nhử quân Nam Hán vào bãi cọc; khi triều rút, quân ta phản công, thuyền giặc va vào cọc, bị đắm và tiêu diệt; quân Nam Hán đại bại.'],
  [3,'Nêu ý nghĩa lịch sử của chiến thắng Bạch Đằng năm 938.','Đánh bại hoàn toàn quân xâm lược Nam Hán, chấm dứt hơn một nghìn năm Bắc thuộc; mở ra thời kì độc lập, tự chủ lâu dài cho dân tộc; khẳng định ý chí và sức mạnh của nhân dân ta.'],
  [4,'Vì sao chiến thắng Bạch Đằng năm 938 được coi là một bước ngoặt vĩ đại trong lịch sử dân tộc?','Vì nó chấm dứt vĩnh viễn hơn một nghìn năm đô hộ của phong kiến phương Bắc, mở ra kỉ nguyên độc lập, tự chủ lâu dài của dân tộc; thể hiện tài thao lược và tinh thần quật cường của nhân dân ta; đặt nền móng cho sự phát triển của quốc gia độc lập sau này.']
 ]);
 add(M,6,'Bài 19 (Lịch sử): Vương quốc Chăm-pa từ thế kỉ II đến thế kỉ X',[
  [1,'Vương quốc Chăm-pa ra đời ở khu vực nào của nước ta ngày nay?','Vùng ven biển miền Trung','Đồng bằng Bắc Bộ','Nam Bộ','Tây Bắc'],
  [1,'Cư dân Chăm-pa chủ yếu sống bằng nghề gì?','Trồng lúa nước, nghề biển và thủ công','Du mục','Chỉ săn bắn','Chỉ buôn bán vàng'],
  [2,'Công trình kiến trúc tiêu biểu của người Chăm là gì?','Các đền, tháp Chăm (như Thánh địa Mỹ Sơn)','Vạn Lí Trường Thành','Kim tự tháp','Đấu trường La Mã'],
  [2,'Văn hóa Chăm-pa chịu ảnh hưởng của nền văn hóa nào?','Văn hóa Ấn Độ','Văn hóa Hy Lạp','Văn hóa La Mã','Văn hóa Ai Cập'],
  [2,'Thánh địa Mỹ Sơn (của người Chăm) hiện nay được công nhận là gì?','Di sản văn hóa thế giới','Một khu chợ','Một nhà máy','Một trường học'],
  [3,'Nêu một số thành tựu văn hóa của Vương quốc Chăm-pa.','Chữ viết (dựa trên chữ Phạn); tôn giáo (Hin-đu giáo, Phật giáo); kiến trúc, điêu khắc đền tháp độc đáo (Thánh địa Mỹ Sơn); nghề thủ công, hàng hải phát triển.'],
  [3,'Vì sao kiến trúc đền tháp Chăm-pa được đánh giá cao?','Đền tháp Chăm xây bằng gạch với kĩ thuật độc đáo, bền vững qua thời gian; điêu khắc tinh xảo, mang đậm bản sắc và ảnh hưởng văn hóa Ấn Độ được Việt hóa; thể hiện trình độ cao của người Chăm (Thánh địa Mỹ Sơn là di sản thế giới).'],
  [4,'Vì sao văn hóa Chăm-pa là một bộ phận của nền văn hóa đa dạng, thống nhất của Việt Nam?','Chăm-pa là một trong các quốc gia cổ trên lãnh thổ Việt Nam ngày nay; người Chăm là một dân tộc trong cộng đồng 54 dân tộc Việt Nam. Những thành tựu văn hóa Chăm (kiến trúc, điêu khắc, lễ hội) góp phần làm phong phú, đa dạng nền văn hóa chung của dân tộc Việt Nam.']
 ]);
 add(M,6,'Bài 20 (Lịch sử): Vương quốc Phù Nam',[
  [1,'Vương quốc Phù Nam ra đời ở khu vực nào của nước ta ngày nay?','Vùng Nam Bộ','Đồng bằng Bắc Bộ','Ven biển miền Trung','Tây Bắc'],
  [1,'Phù Nam là một quốc gia cổ phát triển mạnh về hoạt động nào?','Thương mại, hàng hải (buôn bán đường biển)','Du mục','Chỉ săn bắn','Khai thác than'],
  [2,'Di tích văn hóa nổi tiếng gắn với Vương quốc Phù Nam là gì?','Văn hóa Óc Eo','Thánh địa Mỹ Sơn','Thành Cổ Loa','Vạn Lí Trường Thành'],
  [2,'Nhờ vị trí nào mà Phù Nam phát triển thương mại đường biển?','Nằm gần biển, trên đường giao thương quốc tế','Nằm giữa sa mạc','Trên núi cao','Vùng băng giá'],
  [2,'Cư dân Phù Nam sinh sống chủ yếu bằng nghề gì?','Trồng lúa, đánh cá, thủ công và buôn bán','Du mục','Chỉ chăn nuôi','Chỉ khai khoáng'],
  [3,'Nêu một số nét nổi bật về Vương quốc Phù Nam.','Ra đời ở Nam Bộ (khoảng thế kỉ I), phát triển mạnh thương mại đường biển; gắn với văn hóa Óc Eo; có giao lưu với Ấn Độ và nhiều nước; từng là quốc gia hùng mạnh ở Đông Nam Á rồi suy yếu, sụp đổ (khoảng thế kỉ VII).'],
  [3,'Vì sao thương mại đường biển phát triển mạnh ở Vương quốc Phù Nam?','Phù Nam có vị trí gần biển, nằm trên tuyến đường giao thương quốc tế nối Ấn Độ – Trung Quốc; có cảng thị (Óc Eo) sầm uất, thuyền buôn nhiều nước qua lại trao đổi hàng hóa, nên thương mại đường biển phát triển mạnh.'],
  [4,'Vì sao việc nghiên cứu các vương quốc cổ như Chăm-pa, Phù Nam có ý nghĩa với lịch sử Việt Nam?','Chăm-pa và Phù Nam là những quốc gia cổ từng tồn tại trên lãnh thổ Việt Nam ngày nay; nghiên cứu chúng giúp hiểu đầy đủ, toàn diện lịch sử dân tộc trên cả ba miền; thấy được sự đa dạng, phong phú và quá trình hình thành nền văn hóa thống nhất của cộng đồng các dân tộc Việt Nam.']
 ]);
 /* Chủ đề tổng hợp Lịch sử L6 */
 add(M,6,'Lịch sử: Vì sao học lịch sử, xã hội cổ đại',[
  [1,'Lịch sử là gì?','Những gì đã diễn ra trong quá khứ','Dự báo tương lai','Chuyện tưởng tượng','Thời tiết'],
  [2,'Các nền văn minh cổ đại phương Đông thường hình thành ở đâu?','Lưu vực các dòng sông lớn','Trên sa mạc','Vùng băng giá','Giữa đại dương'],
  [2,'Người Ai Cập cổ đại xây dựng công trình nổi tiếng nào?','Kim tự tháp','Vạn Lí Trường Thành','Đấu trường La Mã','Thành Cổ Loa'],
  [3,'Nêu ý nghĩa của việc học lịch sử.','Hiểu cội nguồn, quá khứ dựng nước và giữ nước của cha ông; rút ra bài học kinh nghiệm; bồi dưỡng lòng yêu nước, tự hào dân tộc và trách nhiệm xây dựng, bảo vệ đất nước.'],
  [4,'Vì sao các dòng sông lớn được coi là cái nôi của văn minh cổ đại phương Đông?','Lưu vực sông lớn có đất phù sa màu mỡ, nước tưới dồi dào, thuận lợi cho nông nghiệp; dân cư đông, của cải dư thừa nên nhà nước và văn minh sớm ra đời (Ai Cập, Lưỡng Hà, Ấn Độ, Trung Quốc).']
 ]);
 add(M,6,'Lịch sử: Việt Nam thời nguyên thủy – Văn Lang, Âu Lạc',[
  [1,'Nhà nước đầu tiên của người Việt là nhà nước nào?','Văn Lang','Âu Lạc','Đại Cồ Việt','Đại Việt'],
  [2,'Kinh đô của nước Âu Lạc là ở đâu?','Cổ Loa','Phong Châu','Hoa Lư','Thăng Long'],
  [2,'Biểu tượng tiêu biểu cho văn hóa Văn Lang – Âu Lạc là gì?','Trống đồng','Kim tự tháp','Vạn Lí Trường Thành','Đấu trường'],
  [3,'Nêu đời sống của cư dân Văn Lang – Âu Lạc.','Trồng lúa nước, chăn nuôi, làm thủ công (đúc đồng, làm gốm); ở nhà sàn; thờ cúng tổ tiên, thần tự nhiên; có nhiều phong tục, lễ hội (ăn trầu, xăm mình...); trống đồng là biểu tượng văn hóa.'],
  [4,'Vì sao sự ra đời của Nhà nước Văn Lang – Âu Lạc có ý nghĩa to lớn?','Là nhà nước đầu tiên, mở đầu thời kì dựng nước và giữ nước; hình thành nền văn minh sông Hồng với nhiều thành tựu (trống đồng, thành Cổ Loa, nỏ); tạo nên cội nguồn, bản sắc và truyền thống yêu nước của dân tộc.']
 ]);

 /* L6 Lịch sử: bù lẻ cho đủ chuẩn */
 add(M,6,'Bài 1 (Lịch sử): Lịch sử và cuộc sống',[
  [1,'Người đầu tiên đưa ra lời dạy "Dân ta phải biết sử ta" là ai?','Chủ tịch Hồ Chí Minh','Một nhà sử học nước ngoài','Một vị vua cổ','Không rõ']
 ]);
 add(M,6,'Bài 18 (Lịch sử): Bước ngoặt lịch sử đầu thế kỉ X',[
  [1,'Chiến thắng Bạch Đằng năm 938 diễn ra trên con sông nào?','Sông Bạch Đằng','Sông Hồng','Sông Mã','Sông Hương']
 ]);
 add(M,6,'Lịch sử: Vì sao học lịch sử, xã hội cổ đại',[
  [3,'Kể tên các loại tư liệu lịch sử dùng để tìm hiểu quá khứ.','Tư liệu hiện vật (trống đồng, công cụ đá); tư liệu chữ viết (bia đá, sách cổ); tư liệu truyền miệng (truyền thuyết, ca dao, truyện kể).']
 ]);
 add(M,6,'Lịch sử: Việt Nam thời nguyên thủy – Văn Lang, Âu Lạc',[
  [3,'Nêu thành tựu quân sự nổi bật của nước Âu Lạc.','Xây thành Cổ Loa kiên cố và chế tạo nỏ (bắn được nhiều mũi tên), thể hiện kĩ thuật và tài năng quân sự của người Việt cổ.']
 ]);

 /* ===================== ĐỊA LÍ – LỚP 6 ===================== */
 add(M,6,'Bài 1 (Địa lí): Hệ thống kinh, vĩ tuyến',[
  [1,'Kinh tuyến là gì?','Các đường nối liền hai cực Bắc và Nam trên bề mặt Trái Đất','Đường vòng quanh xích đạo','Đường chân trời','Đường bờ biển'],
  [1,'Vĩ tuyến là gì?','Các đường tròn song song với xích đạo','Đường nối hai cực','Đường bờ biển','Đường chân trời'],
  [2,'Vĩ tuyến gốc (0 độ) là đường nào?','Đường Xích đạo','Kinh tuyến gốc','Chí tuyến Bắc','Vòng cực Nam'],
  [2,'Kinh tuyến gốc (0 độ) đi qua đài thiên văn nào?','Grin-uých (ở Luân Đôn, Anh)','Pa-ri','Niu Oóc','Bắc Kinh'],
  [2,'Hệ thống kinh, vĩ tuyến giúp ích gì?','Xác định vị trí của mọi điểm trên Trái Đất (tọa độ địa lí)','Đo nhiệt độ','Đo thời gian học','Vẽ tranh'],
  [3,'Phân biệt kinh tuyến và vĩ tuyến.','Kinh tuyến: đường nối hai cực Bắc – Nam, có độ dài bằng nhau. Vĩ tuyến: đường tròn song song với Xích đạo, càng xa Xích đạo càng ngắn. Kinh tuyến gốc 0 độ qua Grin-uých; vĩ tuyến gốc 0 độ là Xích đạo.'],
  [3,'Tọa độ địa lí của một điểm được xác định như thế nào?','Bằng kinh độ và vĩ độ của điểm đó: kinh độ là khoảng cách tính bằng độ từ kinh tuyến gốc đến điểm; vĩ độ là khoảng cách tính bằng độ từ Xích đạo đến điểm.'],
  [4,'Vì sao hệ thống kinh, vĩ tuyến có vai trò quan trọng trong đời sống và khoa học?','Nhờ hệ thống kinh, vĩ tuyến, mỗi điểm trên Trái Đất có một tọa độ địa lí xác định; giúp xác định chính xác vị trí, định hướng, vẽ bản đồ, dẫn đường cho tàu thuyền, máy bay và định vị GPS. Thiếu nó, việc xác định vị trí sẽ không chính xác, thống nhất.']
 ]);
 add(M,6,'Bài 2 (Địa lí): Bản đồ',[
  [1,'Bản đồ là gì?','Hình vẽ thu nhỏ một phần hoặc toàn bộ bề mặt Trái Đất lên mặt phẳng','Bức tranh phong cảnh','Quyển sách','Mô hình địa cầu'],
  [1,'Bản đồ dùng để làm gì?','Thể hiện vị trí, đặc điểm các đối tượng địa lí','Nấu ăn','Đo thời gian','Nghe nhạc'],
  [2,'Để vẽ bản đồ, người ta phải làm gì với bề mặt cong của Trái Đất?','Chiếu lên mặt phẳng (dùng phép chiếu bản đồ)','Để nguyên hình cầu','Vẽ tùy ý','Không cần xử lí'],
  [2,'Thông tin nào thường có trên một bản đồ?','Tên bản đồ, tỉ lệ, kí hiệu, hướng, lưới kinh vĩ tuyến','Giá tiền','Tên người xem','Thời tiết hôm nay'],
  [2,'Muốn đọc và hiểu bản đồ, trước hết cần xem gì?','Bảng chú giải (kí hiệu) và tỉ lệ bản đồ','Màu giấy','Góc bản đồ','Số trang'],
  [3,'Nêu vai trò của bản đồ trong học tập và đời sống.','Giúp xác định vị trí, phương hướng, khoảng cách; tìm hiểu đặc điểm tự nhiên, dân cư, kinh tế của các vùng; phục vụ học tập, du lịch, giao thông, quân sự, dự báo thời tiết...'],
  [3,'Nêu các bước cơ bản để đọc một bản đồ.','Đọc tên bản đồ để biết nội dung; xem tỉ lệ để biết mức thu nhỏ; đọc bảng chú giải để hiểu các kí hiệu; xác định phương hướng; tìm và phân tích các đối tượng cần tìm hiểu.'],
  [4,'Vì sao bản đồ được coi là "cuốn sách giáo khoa thứ hai" của môn Địa lí?','Vì bản đồ chứa đựng rất nhiều thông tin địa lí (vị trí, địa hình, khí hậu, sông ngòi, dân cư...) một cách trực quan; qua đọc và phân tích bản đồ, người học khai thác được kiến thức, rèn kĩ năng, hiểu mối quan hệ giữa các đối tượng — như một nguồn tri thức quan trọng bên cạnh SGK.']
 ]);
 add(M,6,'Bài 3 (Địa lí): Tỉ lệ bản đồ',[
  [1,'Tỉ lệ bản đồ cho biết điều gì?','Mức độ thu nhỏ của khoảng cách trên bản đồ so với thực tế','Màu sắc bản đồ','Tên bản đồ','Hướng bản đồ'],
  [1,'Tỉ lệ 1 : 100 000 nghĩa là gì?','1 cm trên bản đồ bằng 100 000 cm (1 km) ngoài thực tế','1 cm bằng 100 cm','1 cm bằng 1 cm','Không có nghĩa'],
  [2,'Bản đồ có tỉ lệ càng lớn thì thể hiện lãnh thổ như thế nào?','Lãnh thổ nhỏ hơn nhưng chi tiết hơn','Lãnh thổ rộng, ít chi tiết','Không đổi','Không thể hiện được'],
  [2,'Có mấy dạng thể hiện tỉ lệ bản đồ?','Tỉ lệ số và tỉ lệ thước','Một dạng','Ba dạng','Không có'],
  [2,'Dựa vào tỉ lệ bản đồ, ta có thể làm gì?','Tính khoảng cách thực tế giữa các địa điểm','Đo nhiệt độ','Biết dân số','Biết thời tiết'],
  [3,'Trên bản đồ tỉ lệ 1 : 200 000, khoảng cách hai điểm là 3 cm. Tính khoảng cách thực tế.','Khoảng cách thực tế = 3 × 200 000 = 600 000 cm = 6 km.'],
  [3,'Phân biệt bản đồ tỉ lệ lớn và bản đồ tỉ lệ nhỏ.','Bản đồ tỉ lệ lớn (mẫu số nhỏ, VD 1:10 000) thể hiện khu vực nhỏ nhưng rất chi tiết. Bản đồ tỉ lệ nhỏ (mẫu số lớn, VD 1:1 000 000) thể hiện khu vực rộng nhưng ít chi tiết.'],
  [4,'Vì sao khi chọn bản đồ cần chú ý đến tỉ lệ bản đồ?','Tỉ lệ quyết định mức độ chi tiết và phạm vi lãnh thổ thể hiện. Muốn xem chi tiết một khu vực nhỏ (đường phố, xã) cần bản đồ tỉ lệ lớn; muốn xem khái quát vùng rộng (quốc gia, châu lục) dùng bản đồ tỉ lệ nhỏ. Chọn đúng tỉ lệ giúp khai thác thông tin phù hợp mục đích.']
 ]);
 add(M,6,'Bài 4 (Địa lí): Kí hiệu và bảng chú giải bản đồ',[
  [1,'Kí hiệu bản đồ dùng để làm gì?','Thể hiện các đối tượng địa lí trên bản đồ','Trang trí','Ghi giá tiền','Ghi tên người vẽ'],
  [1,'Bảng chú giải của bản đồ cho biết điều gì?','Ý nghĩa của các kí hiệu dùng trên bản đồ','Giá bản đồ','Tên tác giả','Số trang'],
  [2,'Có mấy loại kí hiệu bản đồ thường gặp?','Kí hiệu điểm, kí hiệu đường, kí hiệu diện tích','Chỉ một loại','Năm loại','Không có'],
  [2,'Kí hiệu đường thường dùng để thể hiện đối tượng nào?','Sông, đường giao thông, ranh giới','Thành phố','Vùng trồng lúa','Mỏ khoáng sản'],
  [2,'Vì sao phải đọc bảng chú giải trước khi dùng bản đồ?','Để hiểu các kí hiệu, từ đó đọc đúng nội dung bản đồ','Để biết giá','Để trang trí','Không cần thiết'],
  [3,'Kể tên các loại kí hiệu bản đồ và ví dụ.','Kí hiệu điểm (sân bay, mỏ khoáng sản, thành phố); kí hiệu đường (sông, đường ô tô, ranh giới); kí hiệu diện tích (vùng trồng lúa, rừng). Bảng chú giải giải thích ý nghĩa các kí hiệu đó.'],
  [3,'Vì sao bản đồ cần dùng kí hiệu thay vì vẽ hình thật của các đối tượng?','Vì bản đồ thu nhỏ bề mặt rộng lớn lên mặt phẳng, không thể vẽ hình thật của mọi đối tượng; kí hiệu giúp thể hiện các đối tượng một cách ngắn gọn, rõ ràng, thống nhất, giúp người đọc dễ nhận biết và khai thác thông tin.'],
  [4,'Vì sao kí hiệu và bảng chú giải được coi là "ngôn ngữ" của bản đồ?','Vì mọi thông tin trên bản đồ đều được truyền tải qua hệ thống kí hiệu; muốn "đọc" được bản đồ phải hiểu ý nghĩa kí hiệu qua bảng chú giải, giống như muốn đọc chữ phải biết mặt chữ. Vì vậy kí hiệu và chú giải chính là ngôn ngữ của bản đồ.']
 ]);
 add(M,6,'Bài 5 (Địa lí): Lược đồ trí nhớ',[
  [1,'Lược đồ trí nhớ là gì?','Hình ảnh về không gian được ghi nhớ, phác họa lại trong đầu mỗi người','Bản đồ in sẵn','Ảnh chụp vệ tinh','Mô hình địa cầu'],
  [1,'Lược đồ trí nhớ giúp ích gì?','Giúp định hướng, nhớ đường đi, mô tả không gian quen thuộc','Đo nhiệt độ','Tính tiền','Vẽ tranh nghệ thuật'],
  [2,'Để vẽ lược đồ trí nhớ đường từ nhà đến trường, cần nhớ gì?','Các điểm mốc (ngã tư, cửa hàng...), hướng đi, khoảng cách tương đối','Giá nhà','Tên hàng xóm','Thời tiết'],
  [2,'Lược đồ trí nhớ khác bản đồ ở điểm nào?','Mang tính cá nhân, không chính xác tuyệt đối về tỉ lệ','Luôn chính xác tuyệt đối','In hàng loạt','Có tọa độ đầy đủ'],
  [2,'Điểm mốc trong lược đồ trí nhớ là gì?','Những địa điểm dễ nhận biết, giúp định hướng','Màu sắc','Giá tiền','Tên người'],
  [3,'Nêu lợi ích của việc sử dụng lược đồ trí nhớ trong cuộc sống.','Giúp định hướng, tìm đường đến nơi quen thuộc; mô tả, chỉ đường cho người khác; ghi nhớ và hình dung không gian xung quanh; rèn khả năng quan sát, định hướng.'],
  [3,'Nêu các bước để vẽ một lược đồ trí nhớ đường từ nhà đến trường.','Xác định điểm đầu (nhà) và điểm cuối (trường); nhớ lại các điểm mốc dọc đường (ngã tư, chợ, cây to...); xác định hướng đi và thứ tự các mốc; phác họa đường đi nối các mốc theo trí nhớ.'],
  [4,'Vì sao lược đồ trí nhớ tuy không chính xác như bản đồ nhưng vẫn rất hữu ích?','Vì nó phản ánh không gian theo cách dễ nhớ, gắn với điểm mốc quen thuộc của mỗi người, giúp định hướng và di chuyển nhanh trong cuộc sống hằng ngày mà không cần bản đồ chi tiết. Nó rèn khả năng quan sát, ghi nhớ và định hướng không gian.']
 ]);
 add(M,6,'Bài 6 (Địa lí): Trái Đất trong hệ Mặt Trời',[
  [1,'Hệ Mặt Trời gồm Mặt Trời và bao nhiêu hành tinh?','Tám hành tinh','Năm hành tinh','Mười hành tinh','Một hành tinh'],
  [1,'Trái Đất là hành tinh thứ mấy tính từ Mặt Trời?','Thứ ba','Thứ nhất','Thứ năm','Thứ tám'],
  [2,'Trái Đất có dạng hình gì?','Hình cầu (gần tròn)','Hình vuông','Mặt phẳng','Hình tam giác'],
  [2,'Điều gì làm cho Trái Đất là hành tinh duy nhất có sự sống trong hệ Mặt Trời?','Có nước, không khí (ô-xi), nhiệt độ phù hợp','Rất nóng','Rất lạnh','Không có nước'],
  [2,'Trung tâm của hệ Mặt Trời là gì?','Mặt Trời','Trái Đất','Mặt Trăng','Sao Hỏa'],
  [3,'Nêu vị trí và đặc điểm của Trái Đất trong hệ Mặt Trời.','Trái Đất là hành tinh thứ ba tính từ Mặt Trời, có dạng hình cầu; nằm ở vị trí có khoảng cách và nhiệt độ phù hợp, có nước và không khí nên là hành tinh duy nhất có sự sống trong hệ Mặt Trời.'],
  [3,'Vì sao Trái Đất có sự sống còn các hành tinh khác thì chưa phát hiện được?','Trái Đất có khoảng cách thích hợp với Mặt Trời nên nhiệt độ ôn hòa; có nước ở thể lỏng, có bầu khí quyển với ô-xi, có đất — là những điều kiện cần cho sự sống. Các hành tinh khác hoặc quá nóng, quá lạnh, thiếu nước, thiếu không khí nên chưa có sự sống.'],
  [4,'Vì sao vị trí của Trái Đất trong hệ Mặt Trời được coi là "vị trí vàng" cho sự sống?','Trái Đất không quá gần Mặt Trời (sẽ quá nóng) cũng không quá xa (sẽ quá lạnh), nên có nhiệt độ ôn hòa; nhờ đó nước tồn tại ở thể lỏng, có khí quyển bảo vệ. Vị trí thích hợp này tạo điều kiện lí tưởng cho sự sống phát sinh và phát triển, điều hiếm có trong vũ trụ.']
 ]);
 add(M,6,'Bài 7 (Địa lí): Chuyển động tự quay quanh trục của Trái Đất và hệ quả',[
  [1,'Trái Đất tự quay quanh trục theo hướng nào?','Từ tây sang đông','Từ đông sang tây','Từ bắc xuống nam','Đứng yên'],
  [1,'Trái Đất tự quay một vòng quanh trục hết bao lâu?','Khoảng 24 giờ (một ngày đêm)','1 giờ','1 tháng','1 năm'],
  [2,'Hệ quả của sự tự quay quanh trục của Trái Đất là gì?','Hiện tượng ngày và đêm luân phiên nhau','Bốn mùa','Nhật thực','Mưa bão'],
  [2,'Vì sao có hiện tượng ngày và đêm luân phiên?','Trái Đất hình cầu và tự quay nên nửa được chiếu sáng là ngày, nửa khuất là đêm','Do Mặt Trăng che','Do mây','Do con người'],
  [2,'Sự tự quay của Trái Đất còn gây ra hiện tượng nào?','Giờ khác nhau ở các kinh tuyến (các múi giờ)','Bốn mùa','Mưa','Núi lửa'],
  [3,'Nêu các hệ quả chuyển động tự quay quanh trục của Trái Đất.','Hiện tượng ngày – đêm luân phiên; giờ khác nhau ở các nơi theo kinh tuyến (các múi giờ); sự lệch hướng chuyển động của các vật thể (gió, dòng biển) trên bề mặt Trái Đất.'],
  [3,'Vì sao cùng một thời điểm, các nơi trên Trái Đất lại có giờ khác nhau?','Trái Đất hình cầu và tự quay từ tây sang đông, nên các kinh tuyến lần lượt được Mặt Trời chiếu sáng vào thời điểm khác nhau; nơi ở phía đông có giờ sớm hơn phía tây. Vì vậy người ta chia Trái Đất thành các múi giờ, mỗi nơi có giờ riêng.'],
  [4,'Vì sao hiện tượng ngày và đêm lại luân phiên và kế tiếp nhau không ngừng?','Trái Đất hình cầu nên lúc nào cũng chỉ một nửa được Mặt Trời chiếu sáng (ngày), nửa kia tối (đêm); đồng thời Trái Đất tự quay liên tục quanh trục nên mọi nơi lần lượt được chiếu sáng rồi lại khuất. Nhờ đó ngày và đêm luân phiên, kế tiếp nhau không ngừng.']
 ]);
 add(M,6,'Bài 8 (Địa lí): Chuyển động của Trái Đất quanh Mặt Trời và hệ quả',[
  [1,'Trái Đất chuyển động quanh Mặt Trời một vòng hết bao lâu?','Khoảng 365 ngày (một năm)','24 giờ','1 tháng','100 năm'],
  [1,'Khi chuyển động quanh Mặt Trời, trục Trái Đất có đặc điểm gì?','Nghiêng và không đổi hướng','Thẳng đứng','Nằm ngang','Thay đổi liên tục'],
  [2,'Hệ quả quan trọng của chuyển động quanh Mặt Trời là gì?','Sinh ra các mùa trong năm','Ngày và đêm','Giờ khác nhau','Nhật thực'],
  [2,'Vì sao có hiện tượng các mùa trong năm?','Do trục Trái Đất nghiêng và không đổi hướng khi quay quanh Mặt Trời, lượng ánh sáng, nhiệt nhận được thay đổi','Do Trái Đất tự quay','Do Mặt Trăng','Do con người'],
  [2,'Ở bán cầu Bắc, mùa hạ thường vào khoảng thời gian nào?','Tháng 6, 7, 8','Tháng 12, 1, 2','Quanh năm','Không có mùa'],
  [3,'Nêu hệ quả chuyển động của Trái Đất quanh Mặt Trời.','Sinh ra các mùa trong năm (xuân, hạ, thu, đông); hiện tượng ngày đêm dài ngắn khác nhau theo mùa và theo vĩ độ. Các mùa ở hai bán cầu trái ngược nhau.'],
  [3,'Vì sao các mùa ở bán cầu Bắc và bán cầu Nam lại trái ngược nhau?','Do trục Trái Đất nghiêng không đổi hướng khi quay quanh Mặt Trời; khi bán cầu Bắc ngả về phía Mặt Trời (nhận nhiều nhiệt, là mùa hạ) thì bán cầu Nam ngả ra xa (nhận ít nhiệt, là mùa đông) và ngược lại. Vì vậy mùa ở hai bán cầu trái ngược nhau.'],
  [4,'Vì sao hiện tượng mùa có ảnh hưởng lớn đến đời sống và sản xuất của con người?','Các mùa khác nhau về nhiệt độ, lượng mưa, ánh sáng nên ảnh hưởng đến trồng trọt, chăn nuôi (mùa vụ), sinh hoạt, trang phục, sức khỏe và nhiều hoạt động khác. Con người phải dựa vào quy luật mùa để sắp xếp sản xuất và đời sống cho phù hợp.']
 ]);
 add(M,6,'Bài 9 (Địa lí): Xác định phương hướng ngoài thực địa',[
  [1,'Trên Trái Đất có mấy hướng chính?','Bốn hướng: Đông, Tây, Nam, Bắc','Hai hướng','Sáu hướng','Tám hướng chính duy nhất'],
  [1,'Dụng cụ nào giúp xác định phương hướng chính xác?','La bàn','Thước kẻ','Cân','Nhiệt kế'],
  [2,'Buổi sáng, Mặt Trời mọc ở hướng nào?','Hướng đông','Hướng tây','Hướng bắc','Hướng nam'],
  [2,'Kim nam châm của la bàn luôn chỉ về hướng nào?','Hướng bắc – nam','Hướng đông','Hướng tây','Hướng bất kì'],
  [2,'Khi đứng quay mặt về hướng bắc, tay phải của em chỉ hướng nào?','Hướng đông','Hướng tây','Hướng nam','Hướng bắc'],
  [3,'Nêu các cách xác định phương hướng ngoài thực địa.','Dùng la bàn (kim chỉ bắc – nam); dựa vào hướng Mặt Trời mọc (đông) và lặn (tây); dựa vào các dấu hiệu tự nhiên (sao Bắc Cực, hướng rêu mọc...); dựa vào bản đồ có ghi hướng.'],
  [3,'Vì sao biết xác định phương hướng là kĩ năng cần thiết?','Giúp định hướng khi đi lại, tìm đường, nhất là nơi lạ hoặc khi bị lạc; cần cho du lịch, dã ngoại, giao thông, quân sự, hàng hải. Xác định đúng hướng giúp đến đúng nơi, tránh bị lạc, bảo đảm an toàn.'],
  [4,'Vì sao vào ban đêm không có Mặt Trời, người ta vẫn có thể xác định được phương hướng?','Có thể dùng la bàn (kim nam châm luôn chỉ hướng bắc – nam); hoặc dựa vào sao Bắc Cực (nằm gần đúng hướng bắc) và các chòm sao; hoặc dùng thiết bị định vị GPS. Nhờ các cách này, ban đêm vẫn xác định được phương hướng dù không có Mặt Trời.']
 ]);
 add(M,6,'Bài 10 (Địa lí): Cấu tạo của Trái Đất',[
  [1,'Trái Đất có cấu tạo gồm mấy lớp chính?','Ba lớp: vỏ, man-ti (lớp trung gian) và nhân (lõi)','Một lớp','Hai lớp','Năm lớp'],
  [1,'Lớp ngoài cùng, mỏng nhất của Trái Đất là lớp nào?','Lớp vỏ Trái Đất','Lớp man-ti','Lớp nhân','Khí quyển'],
  [2,'Con người sinh sống trên lớp nào của Trái Đất?','Lớp vỏ Trái Đất','Lớp nhân','Lớp man-ti','Lõi Trái Đất'],
  [2,'Lớp vỏ Trái Đất tuy mỏng nhưng có vai trò gì?','Là nơi tồn tại của các thành phần tự nhiên và xã hội loài người','Không có vai trò','Chỉ chứa dung nham','Không ai sống được'],
  [2,'Càng xuống sâu trong lòng Trái Đất, nhiệt độ thay đổi thế nào?','Càng tăng cao','Càng giảm','Không đổi','Bằng 0'],
  [3,'Nêu cấu tạo bên trong của Trái Đất.','Gồm ba lớp: lớp vỏ (mỏng ngoài cùng, nơi con người sinh sống); lớp man-ti (trung gian, vật chất ở trạng thái quánh dẻo đến lỏng); lớp nhân (lõi, trong cùng, nhiệt độ rất cao).'],
  [3,'Vì sao lớp vỏ Trái Đất tuy mỏng nhất nhưng lại quan trọng nhất đối với con người?','Vì lớp vỏ là nơi có đất, nước, không khí, sinh vật; là nơi con người sinh sống và diễn ra mọi hoạt động sản xuất, đời sống. Tuy mỏng so với toàn bộ Trái Đất nhưng đây là lớp trực tiếp liên quan đến sự tồn tại và phát triển của con người.'],
  [4,'Vì sao con người hiểu biết về cấu tạo bên trong Trái Đất còn hạn chế?','Vì con người chỉ sống và nghiên cứu được ở lớp vỏ mỏng bên ngoài; càng vào sâu, nhiệt độ và áp suất càng rất lớn, không thể khoan tới hay quan sát trực tiếp. Hiểu biết về lớp man-ti, nhân chủ yếu dựa vào nghiên cứu gián tiếp (sóng địa chấn), nên còn hạn chế.']
 ]);
 add(M,6,'Bài 11 (Địa lí): Quá trình nội sinh và quá trình ngoại sinh',[
  [1,'Quá trình nội sinh là gì?','Quá trình xảy ra trong lòng Trái Đất (như vận động kiến tạo, núi lửa, động đất)','Quá trình do mưa gió','Quá trình do con người','Không có gì'],
  [1,'Quá trình ngoại sinh là gì?','Quá trình xảy ra ở bên ngoài, trên bề mặt Trái Đất (do nước, gió, nhiệt độ...)','Xảy ra trong lòng đất','Do núi lửa','Không liên quan bề mặt'],
  [2,'Quá trình nội sinh có xu hướng làm cho bề mặt Trái Đất như thế nào?','Gồ ghề hơn (tạo núi, nâng cao)','Bằng phẳng hơn','Không đổi','Biến mất'],
  [2,'Quá trình ngoại sinh có xu hướng làm bề mặt Trái Đất như thế nào?','San bằng, hạ thấp địa hình (bào mòn, bồi tụ)','Nâng cao','Gồ ghề hơn','Không đổi'],
  [2,'Ví dụ nào thuộc quá trình ngoại sinh?','Nước chảy bào mòn đất đá, gió thổi mòn đá','Núi lửa phun','Động đất','Vận động nâng lên của vỏ'],
  [3,'Phân biệt quá trình nội sinh và quá trình ngoại sinh.','Nội sinh: xảy ra trong lòng Trái Đất (vận động kiến tạo, núi lửa, động đất), có xu hướng làm địa hình gồ ghề, nâng cao. Ngoại sinh: xảy ra trên bề mặt (do nước, gió, nhiệt độ), có xu hướng san bằng, bào mòn, bồi tụ, hạ thấp địa hình.'],
  [3,'Vì sao bề mặt Trái Đất luôn có nơi cao, nơi thấp, không bằng phẳng?','Vì đồng thời chịu tác động của hai quá trình đối lập: nội sinh làm nâng cao, tạo núi (gồ ghề) và ngoại sinh làm bào mòn, san bằng (hạ thấp). Sự đấu tranh giữa hai quá trình khiến địa hình bề mặt luôn thay đổi, có nơi cao nơi thấp.'],
  [4,'Vì sao nói nội sinh và ngoại sinh là hai quá trình đối lập nhưng cùng tạo nên địa hình bề mặt Trái Đất?','Nội sinh làm địa hình nâng cao, gồ ghề; ngoại sinh làm bào mòn, san bằng — tác dụng ngược nhau. Nhưng chính sự tác động đồng thời, liên tục của cả hai tạo nên các dạng địa hình đa dạng (núi, đồng bằng, thung lũng...) và làm bề mặt Trái Đất không ngừng biến đổi.']
 ]);
 add(M,6,'Bài 12 (Địa lí): Núi lửa và động đất',[
  [1,'Núi lửa là hiện tượng gì?','Mác-ma (vật chất nóng chảy) phun trào lên bề mặt Trái Đất','Mưa to','Gió lớn','Sóng thần'],
  [1,'Động đất là hiện tượng gì?','Các lớp đất đá gần mặt đất rung chuyển','Mưa đá','Lũ lụt','Hạn hán'],
  [2,'Núi lửa và động đất là kết quả của quá trình nào?','Quá trình nội sinh (trong lòng Trái Đất)','Quá trình ngoại sinh','Do con người','Do thời tiết'],
  [2,'Khi có động đất, để an toàn em nên làm gì?','Tìm chỗ trú ẩn an toàn (nấp dưới bàn chắc, tránh xa cửa kính, vật dễ đổ)','Chạy ra ban công','Đứng cạnh tủ cao','Đi thang máy'],
  [2,'Tác hại của núi lửa và động đất là gì?','Gây thiệt hại về người, tài sản, công trình','Giúp mùa màng tốt hơn ngay','Không có tác hại','Làm mát không khí'],
  [3,'Nêu nguyên nhân và tác hại của núi lửa, động đất.','Nguyên nhân: do hoạt động của quá trình nội sinh, sự dịch chuyển của các mảng kiến tạo trong lòng Trái Đất. Tác hại: phá hủy nhà cửa, công trình, gây thương vong; núi lửa còn gây cháy, ô nhiễm; động đất mạnh có thể gây sóng thần.'],
  [3,'Nêu một số việc cần làm để giảm thiệt hại khi xảy ra động đất.','Xây nhà kiên cố, chịu chấn động; theo dõi cảnh báo; khi động đất: bình tĩnh, trú ẩn nơi an toàn (dưới bàn chắc), tránh xa cửa kính, vật dễ đổ; không dùng thang máy; sau động đất nhanh chóng ra nơi trống an toàn.'],
  [4,'Vì sao các vùng nằm trên "vành đai lửa Thái Bình Dương" thường xuyên có núi lửa và động đất?','Đó là nơi tiếp xúc, va chạm của nhiều mảng kiến tạo lớn; các mảng này dịch chuyển, xô vào hoặc tách xa nhau tạo ra chấn động (động đất) và tạo điều kiện cho mác-ma phun trào (núi lửa). Vì hoạt động nội sinh mạnh nên khu vực này thường xuyên có núi lửa, động đất.']
 ]);
 add(M,6,'Bài 13 (Địa lí): Các dạng địa hình chính trên Trái Đất',[
  [1,'Các dạng địa hình chính trên Trái Đất gồm những gì?','Núi, đồi, cao nguyên và đồng bằng','Chỉ có núi','Chỉ có biển','Chỉ có sông'],
  [1,'Đồng bằng là dạng địa hình như thế nào?','Tương đối bằng phẳng, thấp','Cao và dốc','Gồ ghề','Nhiều đỉnh nhọn'],
  [2,'Núi là dạng địa hình có đặc điểm gì?','Nhô cao rõ rệt, độ cao thường trên 500 m, có đỉnh, sườn, chân núi','Bằng phẳng','Thấp trũng','Lõm xuống'],
  [2,'Dạng địa hình nào thuận lợi nhất cho trồng trọt, cư trú đông dân?','Đồng bằng','Núi cao','Cao nguyên hiểm trở','Vùng băng giá'],
  [2,'Cao nguyên khác đồng bằng ở điểm nào?','Cao nguyên cao hơn, có sườn dốc, bề mặt tương đối bằng; đồng bằng thấp và bằng phẳng','Giống hệt nhau','Cao nguyên thấp hơn','Đồng bằng cao hơn'],
  [3,'Kể tên các dạng địa hình chính và đặc điểm của mỗi dạng.','Núi: cao, có đỉnh, sườn dốc. Đồi: nhô cao nhưng thấp hơn núi, đỉnh tròn, sườn thoải. Cao nguyên: cao, bề mặt bằng phẳng, sườn dốc. Đồng bằng: thấp, bằng phẳng, thuận lợi trồng trọt.'],
  [3,'Vì sao đồng bằng thường là nơi dân cư tập trung đông đúc?','Đồng bằng bằng phẳng, đất đai màu mỡ (nhất là đồng bằng phù sa), nguồn nước thuận lợi, dễ trồng trọt, đi lại, xây dựng. Nhờ điều kiện thuận lợi cho sản xuất và sinh sống nên dân cư tập trung đông, kinh tế phát triển.'],
  [4,'Vì sao các dạng địa hình khác nhau lại ảnh hưởng khác nhau đến đời sống và sản xuất của con người?','Mỗi dạng địa hình có đặc điểm riêng về độ cao, độ dốc, đất, nước. Đồng bằng thuận lợi trồng lúa, cư trú; cao nguyên hợp trồng cây công nghiệp, chăn nuôi; miền núi giàu khoáng sản, lâm sản nhưng đi lại khó. Vì vậy địa hình quy định cách con người khai thác, sinh sống khác nhau ở từng vùng.']
 ]);
 add(M,6,'Bài 14 (Địa lí): Thực hành: Đọc lược đồ địa hình tỉ lệ lớn và lát cắt địa hình',[
  [1,'Đường đồng mức trên lược đồ địa hình là gì?','Đường nối các điểm có cùng độ cao','Đường ranh giới','Đường giao thông','Đường sông'],
  [1,'Lát cắt địa hình thể hiện điều gì?','Sự thay đổi độ cao của địa hình theo một đường cắt','Màu sắc đất','Dân số','Thời tiết'],
  [2,'Các đường đồng mức càng gần nhau (sát nhau) thể hiện địa hình như thế nào?','Sườn dốc','Sườn thoải','Bằng phẳng','Trũng sâu'],
  [2,'Các đường đồng mức cách xa nhau thể hiện địa hình thế nào?','Sườn thoải (độ dốc nhỏ)','Sườn rất dốc','Vách đứng','Đỉnh nhọn'],
  [2,'Dựa vào đường đồng mức, ta có thể biết điều gì?','Độ cao, hình dạng và độ dốc của địa hình','Nhiệt độ','Dân số','Giá đất'],
  [3,'Nêu ý nghĩa của đường đồng mức trên lược đồ địa hình.','Đường đồng mức nối các điểm cùng độ cao; dựa vào chúng ta biết được độ cao của địa hình, hình dạng (đỉnh, sườn, thung lũng) và độ dốc (đường sát nhau là dốc, cách xa là thoải).'],
  [3,'Nêu các bước đọc một lược đồ địa hình có đường đồng mức.','Xem tỉ lệ và khoảng cao đều của đường đồng mức; xác định độ cao các điểm; dựa vào khoảng cách giữa các đường để biết độ dốc (sát = dốc, thưa = thoải); xác định hướng dốc, đỉnh, thung lũng.'],
  [4,'Vì sao biết đọc lược đồ địa hình và lát cắt địa hình lại hữu ích trong thực tế?','Giúp hình dung địa hình một vùng (cao, thấp, dốc, bằng) mà không cần đến tận nơi; phục vụ xây dựng công trình, làm đường, quy hoạch, phòng chống thiên tai, du lịch, quân sự. Đây là kĩ năng quan trọng để khai thác thông tin địa hình phục vụ đời sống.']
 ]);
 add(M,6,'Bài 15 (Địa lí): Lớp vỏ khí của Trái Đất',[
  [1,'Lớp vỏ khí (khí quyển) là gì?','Lớp không khí bao quanh Trái Đất','Lớp nước','Lớp đất','Lớp đá'],
  [1,'Thành phần chiếm tỉ lệ lớn nhất trong không khí là gì?','Khí ni-tơ','Khí ô-xi','Khí các-bô-níc','Hơi nước'],
  [2,'Khí nào trong không khí cần cho sự hô hấp của con người và sinh vật?','Khí ô-xi','Khí ni-tơ','Khí các-bô-níc','Khí hiếm'],
  [2,'Tầng nào của khí quyển xảy ra các hiện tượng thời tiết (mây, mưa, gió)?','Tầng đối lưu','Tầng bình lưu','Tầng cao','Không tầng nào'],
  [2,'Lớp vỏ khí có vai trò gì đối với sự sống?','Cung cấp ô-xi, bảo vệ Trái Đất, điều hòa nhiệt độ','Không có vai trò','Gây hại cho sự sống','Làm Trái Đất lạnh đi'],
  [3,'Nêu thành phần của không khí và vai trò của lớp vỏ khí.','Không khí gồm chủ yếu khí ni-tơ (78%), ô-xi (21%), còn lại là hơi nước, khí các-bô-níc và các khí khác. Lớp vỏ khí cung cấp ô-xi cho sự sống, bảo vệ Trái Đất khỏi tia có hại, điều hòa nhiệt độ và là nơi sinh ra các hiện tượng thời tiết.'],
  [3,'Vì sao tầng đối lưu lại quan trọng đối với đời sống con người?','Tầng đối lưu là tầng thấp nhất, chứa phần lớn không khí và hơi nước; là nơi diễn ra các hiện tượng thời tiết (mây, mưa, gió, bão) ảnh hưởng trực tiếp đến đời sống, sản xuất; cũng là tầng cung cấp không khí cho con người và sinh vật hô hấp.'],
  [4,'Vì sao cần bảo vệ bầu khí quyển (lớp vỏ khí) của Trái Đất?','Khí quyển cung cấp ô-xi, bảo vệ Trái Đất khỏi tia có hại, điều hòa khí hậu. Nếu ô nhiễm không khí, thủng tầng ô-dôn, tăng khí nhà kính sẽ gây hại sức khỏe, biến đổi khí hậu, thiên tai. Bảo vệ khí quyển chính là bảo vệ sự sống và môi trường sống của con người.']
 ]);
 add(M,6,'Bài 16 (Địa lí): Nhiệt độ không khí',[
  [1,'Nhiệt độ không khí được đo bằng dụng cụ gì?','Nhiệt kế','Ẩm kế','La bàn','Khí áp kế'],
  [1,'Nguồn cung cấp nhiệt chủ yếu cho không khí là gì?','Mặt Trời','Mặt Trăng','Lòng đất','Con người'],
  [2,'Càng lên cao, nhiệt độ không khí thay đổi như thế nào?','Càng giảm','Càng tăng','Không đổi','Bằng 0 ngay'],
  [2,'Trong một ngày, nhiệt độ không khí thường cao nhất vào khoảng thời gian nào?','Khoảng 13 giờ (đầu giờ chiều)','Lúc nửa đêm','Lúc Mặt Trời mọc','Lúc Mặt Trời lặn'],
  [2,'Càng về phía hai cực (vĩ độ cao), nhiệt độ không khí như thế nào?','Càng thấp (lạnh)','Càng cao','Không đổi','Nóng nhất'],
  [3,'Nêu các yếu tố ảnh hưởng đến nhiệt độ không khí.','Vĩ độ (càng về cực càng lạnh); độ cao (càng lên cao càng giảm); vị trí gần hay xa biển; thời gian trong ngày và trong năm; bề mặt đệm (đất, nước, rừng...).'],
  [3,'Cách tính nhiệt độ trung bình ngày của một địa điểm.','Đo nhiệt độ tại các thời điểm trong ngày (VD lúc 1, 7, 13, 19 giờ), cộng các giá trị lại rồi chia cho số lần đo. Đó là nhiệt độ trung bình ngày.'],
  [4,'Vì sao vùng gần Xích đạo nóng quanh năm còn vùng gần hai cực lại rất lạnh?','Vùng Xích đạo (vĩ độ thấp) nhận được tia nắng Mặt Trời chiếu thẳng (gần như vuông góc) nên nhiệt lượng lớn, nóng quanh năm. Vùng cực (vĩ độ cao) nhận tia nắng chiếu xiên, nhiệt lượng ít và phân tán, nên quanh năm lạnh giá. Vì vậy nhiệt độ giảm dần từ Xích đạo về hai cực.']
 ]);
 add(M,6,'Bài 17 (Địa lí): Thời tiết và khí hậu',[
  [1,'Thời tiết là gì?','Trạng thái của khí quyển tại một nơi trong thời gian ngắn','Trạng thái lặp đi lặp lại nhiều năm','Một dạng địa hình','Một loại đất'],
  [1,'Khí hậu là gì?','Sự lặp đi lặp lại của tình hình thời tiết ở một nơi trong nhiều năm','Thời tiết trong một ngày','Một con sông','Một dạng địa hình'],
  [2,'Điểm khác nhau cơ bản giữa thời tiết và khí hậu là gì?','Thời tiết thay đổi trong thời gian ngắn; khí hậu mang tính quy luật, ổn định trong nhiều năm','Hoàn toàn giống nhau','Khí hậu thay đổi hằng giờ','Thời tiết không đổi'],
  [2,'Nước ta nằm trong đới khí hậu nào?','Đới nóng (nhiệt đới)','Đới lạnh','Đới ôn hòa','Hàn đới'],
  [2,'Trên Trái Đất có mấy đới khí hậu chính theo vĩ độ?','Ba đới: nóng, ôn hòa, lạnh','Một đới','Hai đới','Năm đới'],
  [3,'Phân biệt thời tiết và khí hậu.','Thời tiết: trạng thái khí quyển (nắng, mưa, gió, nhiệt độ...) tại một nơi trong thời gian ngắn, luôn thay đổi. Khí hậu: sự lặp lại có quy luật của thời tiết ở một nơi trong nhiều năm, mang tính ổn định, đặc trưng cho vùng đó.'],
  [3,'Kể tên và nêu đặc điểm các đới khí hậu chính trên Trái Đất.','Đới nóng (nhiệt đới – quanh Xích đạo): nóng quanh năm, mưa nhiều. Đới ôn hòa (ôn đới): nhiệt độ trung bình, bốn mùa rõ. Đới lạnh (hàn đới – gần cực): quanh năm lạnh giá, băng tuyết.'],
  [4,'Vì sao hiểu biết về khí hậu của một vùng lại quan trọng với sản xuất nông nghiệp?','Khí hậu (nhiệt độ, lượng mưa, mùa) quyết định loại cây trồng, vật nuôi và thời vụ phù hợp với từng vùng. Nắm được quy luật khí hậu giúp bố trí mùa vụ hợp lí, chọn giống thích hợp, phòng tránh thiên tai (hạn, lũ, rét), nhờ đó sản xuất nông nghiệp đạt hiệu quả cao.']
 ]);
 add(M,6,'Bài 18 (Địa lí): Thực hành: Phân tích biểu đồ nhiệt độ, lượng mưa',[
  [1,'Biểu đồ nhiệt độ, lượng mưa thể hiện yếu tố nào của một địa điểm?','Nhiệt độ và lượng mưa các tháng trong năm','Dân số','Độ cao địa hình','Giá đất'],
  [1,'Trên biểu đồ, nhiệt độ thường được biểu diễn bằng gì?','Đường biểu diễn','Cột','Hình tròn','Chữ'],
  [2,'Lượng mưa trên biểu đồ thường được biểu diễn bằng gì?','Các cột','Đường cong','Mũi tên','Hình tam giác'],
  [2,'Dựa vào biểu đồ, ta có thể xác định tháng nào nóng nhất bằng cách nào?','Xem tháng có nhiệt độ (đường biểu diễn) cao nhất','Xem cột mưa cao nhất','Xem màu sắc','Đoán'],
  [2,'Tháng mưa nhiều nhất được xác định dựa vào đâu?','Cột lượng mưa cao nhất','Đường nhiệt độ thấp nhất','Màu nền','Tên biểu đồ'],
  [3,'Nêu các bước phân tích một biểu đồ nhiệt độ, lượng mưa.','Xác định trục (nhiệt độ, lượng mưa, tháng); đọc nhiệt độ cao nhất, thấp nhất và các tháng tương ứng; đọc lượng mưa lớn nhất, nhỏ nhất; nhận xét mùa mưa – khô, đặc điểm khí hậu của địa điểm.'],
  [3,'Vì sao phân tích biểu đồ nhiệt độ, lượng mưa giúp nhận biết đặc điểm khí hậu một nơi?','Biểu đồ thể hiện trực quan nhiệt độ và lượng mưa các tháng; qua đó biết nơi đó nóng hay lạnh, mưa nhiều hay ít, có mấy mùa, mùa mưa – khô vào tháng nào. Từ các đặc điểm này ta xác định được kiểu khí hậu của địa điểm.'],
  [4,'Vì sao kĩ năng đọc và phân tích biểu đồ rất quan trọng trong học Địa lí?','Nhiều thông tin địa lí (khí hậu, dân số, kinh tế...) được trình bày bằng biểu đồ; biết đọc, phân tích biểu đồ giúp khai thác số liệu, nhận xét, so sánh và rút ra kết luận nhanh, chính xác. Đây là kĩ năng cốt lõi để học tốt và vận dụng kiến thức Địa lí vào thực tế.']
 ]);
 add(M,6,'Bài 19 (Địa lí): Thủy quyển và vòng tuần hoàn lớn của nước',[
  [1,'Thủy quyển là gì?','Toàn bộ nước trên Trái Đất (biển, sông, hồ, nước ngầm, băng, hơi nước...)','Chỉ nước biển','Chỉ nước sông','Lớp không khí'],
  [1,'Phần lớn nước trên Trái Đất là nước gì?','Nước mặn (ở biển và đại dương)','Nước ngọt','Nước đá','Hơi nước'],
  [2,'Vòng tuần hoàn của nước gồm các quá trình chính nào?','Bốc hơi, ngưng tụ, mưa, dòng chảy','Chỉ bốc hơi','Chỉ mưa','Chỉ đóng băng'],
  [2,'Nước ngọt mà con người sử dụng chủ yếu lấy từ đâu?','Sông, hồ, nước ngầm','Nước biển','Băng ở hai cực chủ yếu','Hơi nước'],
  [2,'Nước bốc hơi từ biển, ao hồ... gặp lạnh sẽ xảy ra hiện tượng gì?','Ngưng tụ tạo thành mây','Tan ra','Biến mất','Đóng băng ngay'],
  [3,'Trình bày vòng tuần hoàn lớn của nước trên Trái Đất.','Nước ở biển, đại dương, sông hồ bốc hơi lên cao, gặp lạnh ngưng tụ thành mây; mây gặp điều kiện thuận lợi gây mưa; nước mưa chảy tràn trên mặt đất thành sông, một phần ngấm xuống đất thành nước ngầm, rồi trở lại biển. Quá trình lặp lại không ngừng.'],
  [3,'Vì sao nguồn nước ngọt tuy nhiều nhưng con người vẫn phải tiết kiệm và bảo vệ nước?','Phần lớn nước Trái Đất là nước mặn; nước ngọt chiếm tỉ lệ nhỏ, lại phần lớn là băng ở hai cực, nước ngọt dùng được không nhiều. Dân số tăng, ô nhiễm nước khiến nước sạch càng khan hiếm. Vì vậy phải tiết kiệm và bảo vệ nguồn nước.'],
  [4,'Vì sao vòng tuần hoàn của nước có vai trò quan trọng đối với sự sống trên Trái Đất?','Vòng tuần hoàn phân phối lại nước khắp Trái Đất: tạo mưa cung cấp nước ngọt cho sông hồ, đất đai, sinh vật; điều hòa khí hậu, nuôi dưỡng sự sống; nếu không có vòng tuần hoàn, nhiều nơi sẽ khô hạn, không có nước ngọt để sinh vật và con người tồn tại.']
 ]);
 add(M,6,'Bài 20 (Địa lí): Sông và hồ',[
  [1,'Sông là gì?','Dòng chảy thường xuyên tự nhiên trên bề mặt lục địa','Vùng nước mặn lớn','Nước đọng không chảy','Lớp không khí'],
  [1,'Lưu vực sông là gì?','Vùng đất cung cấp nước thường xuyên cho một con sông','Lòng sông','Bờ sông','Cửa sông'],
  [2,'Phụ lưu của sông là gì?','Các dòng chảy nhỏ đổ nước vào sông chính','Dòng thoát nước ra khỏi sông','Hồ nước','Biển'],
  [2,'Hồ là gì?','Khoảng nước đọng tương đối rộng và sâu trong đất liền','Dòng chảy thường xuyên','Vùng biển','Con suối nhỏ'],
  [2,'Giá trị của sông ngòi đối với đời sống là gì?','Cung cấp nước, phù sa, thủy sản, giao thông, thủy điện','Không có giá trị','Chỉ gây lũ lụt','Làm khô hạn'],
  [3,'Nêu các bộ phận của một hệ thống sông.','Gồm sông chính và các phụ lưu (đổ nước vào sông chính), chi lưu (thoát nước ra khỏi sông chính); lưu vực sông là vùng đất cung cấp nước cho hệ thống sông đó.'],
  [3,'Nêu những giá trị kinh tế của sông, hồ.','Cung cấp nước cho sinh hoạt, sản xuất; bồi đắp phù sa cho đồng bằng; nuôi trồng, đánh bắt thủy sản; giao thông đường thủy; xây dựng thủy điện; du lịch, điều hòa khí hậu.'],
  [4,'Vì sao các con sông lớn thường gắn liền với sự phát triển của các đồng bằng và dân cư đông đúc?','Sông bồi đắp phù sa tạo nên đồng bằng màu mỡ; cung cấp nước cho trồng trọt, sinh hoạt; thuận lợi giao thông, đánh bắt thủy sản. Nhờ những điều kiện thuận lợi đó, nông nghiệp phát triển, dân cư tập trung đông đúc dọc các con sông lớn (sông Hồng, sông Cửu Long...).']
 ]);
 add(M,6,'Bài 21 (Địa lí): Biển và đại dương',[
  [1,'Biển và đại dương chiếm khoảng bao nhiêu phần bề mặt Trái Đất?','Khoảng 3/4 (71%)','Khoảng 1/4','Một nửa','Toàn bộ'],
  [1,'Nước biển và đại dương có vị gì?','Vị mặn','Vị ngọt','Không vị','Vị chua'],
  [2,'Hiện tượng nước biển dâng lên, hạ xuống theo chu kì gọi là gì?','Thủy triều','Sóng thần','Dòng biển','Gió mùa'],
  [2,'Dòng biển (hải lưu) là gì?','Chuyển động thành dòng của nước biển trên đại dương','Nước đứng yên','Sóng vỗ bờ','Mưa trên biển'],
  [2,'Giá trị của biển và đại dương là gì?','Cung cấp hải sản, muối, khoáng sản, giao thông, du lịch, điều hòa khí hậu','Không có giá trị','Chỉ gây bão','Làm khô hạn'],
  [3,'Nêu một số hiện tượng và giá trị của biển, đại dương.','Hiện tượng: sóng, thủy triều, dòng biển. Giá trị: cung cấp hải sản, muối, dầu khí, khoáng sản; đường giao thông; du lịch; điều hòa khí hậu; là kho tài nguyên và không gian phát triển kinh tế biển.'],
  [3,'Vì sao biển và đại dương có vai trò điều hòa khí hậu cho Trái Đất?','Biển, đại dương rộng lớn, hấp thụ và tỏa nhiệt chậm nên làm dịu bớt sự chênh lệch nhiệt độ; cung cấp hơi nước gây mưa; các dòng biển vận chuyển nhiệt từ nơi nóng đến nơi lạnh. Nhờ đó khí hậu toàn cầu được điều hòa, bớt khắc nghiệt.'],
  [4,'Vì sao cần khai thác hợp lí và bảo vệ môi trường biển, đại dương?','Biển cung cấp nhiều tài nguyên (hải sản, dầu khí...) và có vai trò lớn với khí hậu, đời sống. Nếu khai thác quá mức, đánh bắt hủy diệt, xả rác, dầu thải gây ô nhiễm sẽ làm cạn kiệt tài nguyên, chết sinh vật, mất cân bằng sinh thái. Khai thác hợp lí và bảo vệ biển giúp phát triển bền vững, bảo vệ sự sống.']
 ]);
 add(M,6,'Bài 22 (Địa lí): Lớp đất trên Trái Đất',[
  [1,'Đất (thổ nhưỡng) là gì?','Lớp vật chất mỏng trên bề mặt lục địa, nơi thực vật sinh trưởng','Lớp đá cứng','Lớp nước','Lớp không khí'],
  [1,'Thành phần quan trọng quyết định độ phì của đất là gì?','Chất mùn (chất hữu cơ)','Đá tảng','Cát khô','Nước mặn'],
  [2,'Độ phì của đất là gì?','Khả năng cung cấp nước, chất dinh dưỡng cho cây trồng','Màu sắc của đất','Độ cứng của đất','Độ mặn của đất'],
  [2,'Yếu tố nào góp phần hình thành đất?','Đá mẹ, khí hậu, sinh vật, địa hình và thời gian','Chỉ con người','Chỉ gió','Chỉ nước biển'],
  [2,'Loại đất phù sa (do sông bồi đắp) thường có đặc điểm gì?','Màu mỡ, thích hợp trồng lúa và hoa màu','Bạc màu','Khô cằn','Nhiễm mặn hoàn toàn'],
  [3,'Nêu các nhân tố hình thành đất.','Đá mẹ (cung cấp vật chất khoáng); khí hậu (nhiệt, ẩm thúc đẩy phân hủy); sinh vật (tạo chất mùn); địa hình; thời gian. Trong đó con người cũng tác động đến đất qua canh tác.'],
  [3,'Vì sao cần bảo vệ và sử dụng hợp lí tài nguyên đất?','Đất là tài nguyên quý, hình thành rất chậm, là nơi trồng trọt nuôi sống con người. Sử dụng không hợp lí (canh tác quá mức, chặt phá rừng, xói mòn, ô nhiễm) làm đất bạc màu, thoái hóa. Bảo vệ đất giúp duy trì độ phì, bảo đảm sản xuất lương thực lâu dài.'],
  [4,'Vì sao đất được coi là tài nguyên vô cùng quý giá nhưng có thể bị suy thoái nếu sử dụng không hợp lí?','Đất nuôi dưỡng cây trồng, là cơ sở của sản xuất nông nghiệp và sự sống; nhưng đất hình thành rất chậm (hàng trăm, nghìn năm). Nếu canh tác bừa bãi, phá rừng, để xói mòn, nhiễm mặn, ô nhiễm thì đất nhanh thoái hóa, mất độ phì. Vì vậy phải khai thác, bảo vệ hợp lí để đất không bị suy thoái.']
 ]);
 add(M,6,'Bài 23 (Địa lí): Sự sống trên Trái Đất',[
  [1,'Sinh vật trên Trái Đất gồm những nhóm chính nào?','Thực vật, động vật và vi sinh vật','Chỉ thực vật','Chỉ động vật','Chỉ con người'],
  [1,'Sinh vật phân bố trên Trái Đất ở đâu?','Khắp nơi: trên cạn, dưới nước, trong đất, trong không khí','Chỉ trên cạn','Chỉ dưới biển','Chỉ ở rừng'],
  [2,'Yếu tố nào ảnh hưởng lớn đến sự phân bố sinh vật?','Khí hậu (nhiệt độ, độ ẩm, ánh sáng)','Màu đất','Tiếng ồn','Giá đất'],
  [2,'Nơi có khí hậu nóng ẩm (như rừng nhiệt đới) thì sinh vật như thế nào?','Rất phong phú, đa dạng','Nghèo nàn','Không có sinh vật','Chỉ có băng'],
  [2,'Vùng hoang mạc, vùng cực có sinh vật như thế nào?','Nghèo nàn, ít loài do khí hậu khắc nghiệt','Phong phú nhất','Không chịu ảnh hưởng khí hậu','Giống rừng nhiệt đới'],
  [3,'Nêu các nhân tố ảnh hưởng đến sự phân bố sinh vật trên Trái Đất.','Khí hậu (nhiệt độ, độ ẩm, ánh sáng) là nhân tố quan trọng nhất; ngoài ra còn có nước, đất, địa hình và tác động của con người. Nơi khí hậu thuận lợi (nóng ẩm) sinh vật phong phú; nơi khắc nghiệt (hoang mạc, cực) sinh vật nghèo nàn.'],
  [3,'Vì sao rừng nhiệt đới là nơi có sự sống phong phú, đa dạng bậc nhất?','Rừng nhiệt đới có khí hậu nóng ẩm, mưa nhiều, ánh sáng dồi dào quanh năm — điều kiện lí tưởng cho thực vật phát triển nhiều tầng, từ đó nuôi sống vô số loài động vật, vi sinh vật. Vì vậy đây là nơi đa dạng sinh học bậc nhất Trái Đất.'],
  [4,'Vì sao bảo vệ sự đa dạng của sinh vật trên Trái Đất là trách nhiệm của con người?','Sinh vật tạo nên sự cân bằng của tự nhiên, cung cấp lương thực, thuốc, nguyên liệu và duy trì môi trường sống. Hoạt động của con người (phá rừng, săn bắt, ô nhiễm) đang làm nhiều loài suy giảm, tuyệt chủng. Bảo vệ đa dạng sinh vật chính là bảo vệ cân bằng sinh thái và cuộc sống của chính con người.']
 ]);
 add(M,6,'Bài 24 (Địa lí): Rừng nhiệt đới',[
  [1,'Rừng nhiệt đới phân bố chủ yếu ở khu vực nào?','Vùng gần Xích đạo và hai bên Xích đạo (vĩ độ thấp)','Vùng cực','Hoang mạc','Vùng ôn đới lạnh'],
  [1,'Đặc điểm khí hậu nơi có rừng nhiệt đới là gì?','Nóng ẩm, mưa nhiều quanh năm','Lạnh khô','Khô hạn','Băng giá'],
  [2,'Rừng nhiệt đới có đặc điểm nổi bật gì về cấu trúc?','Nhiều tầng tán, cây cối rậm rạp, đa dạng loài','Thưa thớt','Chỉ có cỏ','Chỉ một tầng cây'],
  [2,'Vai trò của rừng nhiệt đới với môi trường là gì?','Điều hòa khí hậu, cung cấp ô-xi, giữ đất giữ nước, bảo tồn đa dạng sinh học','Gây ô nhiễm','Làm cạn nước','Không có vai trò'],
  [2,'Nguyên nhân chính làm rừng nhiệt đới bị thu hẹp là gì?','Con người chặt phá, khai thác quá mức, cháy rừng','Do mưa nhiều','Do khí hậu lạnh','Do rừng tự biến mất'],
  [3,'Nêu đặc điểm và vai trò của rừng nhiệt đới.','Đặc điểm: khí hậu nóng ẩm, mưa nhiều; rừng rậm rạp, nhiều tầng, đa dạng sinh vật. Vai trò: cung cấp ô-xi, hấp thụ CO2, điều hòa khí hậu; giữ đất, giữ nước; bảo tồn đa dạng sinh học; cung cấp gỗ, dược liệu.'],
  [3,'Vì sao cần bảo vệ rừng nhiệt đới?','Rừng nhiệt đới là "lá phổi xanh", điều hòa khí hậu, cung cấp ô-xi, giữ đất giữ nước, bảo tồn nhiều loài sinh vật. Việc phá rừng gây mất đa dạng sinh học, xói mòn, lũ lụt, hạn hán và góp phần biến đổi khí hậu. Vì vậy bảo vệ rừng nhiệt đới rất cấp thiết.'],
  [4,'Vì sao rừng nhiệt đới được gọi là "lá phổi xanh" của Trái Đất?','Rừng nhiệt đới rộng lớn, cây cối rậm rạp, quang hợp mạnh nên hấp thụ nhiều khí các-bô-níc và thải ra lượng lớn khí ô-xi; đồng thời điều hòa nhiệt độ, độ ẩm, lọc không khí cho toàn cầu. Vai trò giống lá phổi cung cấp "dưỡng khí" và làm sạch không khí cho Trái Đất, nên được gọi là "lá phổi xanh".']
 ]);
 add(M,6,'Bài 25 (Địa lí): Sự phân bố các đới thiên nhiên trên Trái Đất',[
  [1,'Trên Trái Đất có mấy đới thiên nhiên (đới khí hậu) chính?','Ba đới: đới nóng, đới ôn hòa, đới lạnh','Một đới','Hai đới','Bốn đới'],
  [1,'Đới nóng (nhiệt đới) phân bố ở khu vực nào?','Khoảng giữa hai chí tuyến (gần Xích đạo)','Gần hai cực','Vùng ôn đới','Chỉ ở biển'],
  [2,'Đới lạnh (hàn đới) có đặc điểm khí hậu gì?','Quanh năm lạnh giá, băng tuyết','Nóng ẩm','Bốn mùa rõ rệt','Khô nóng'],
  [2,'Đới ôn hòa (ôn đới) có đặc điểm gì nổi bật?','Nhiệt độ trung bình, bốn mùa rõ rệt','Nóng quanh năm','Lạnh quanh năm','Không có mùa'],
  [2,'Sinh vật ở đới nóng so với đới lạnh như thế nào?','Phong phú, đa dạng hơn nhiều','Nghèo nàn hơn','Giống hệt nhau','Không có sinh vật'],
  [3,'Kể tên và nêu đặc điểm của các đới thiên nhiên chính trên Trái Đất.','Đới nóng (quanh Xích đạo): nóng ẩm, mưa nhiều, sinh vật phong phú (rừng nhiệt đới, xavan). Đới ôn hòa: nhiệt độ trung bình, bốn mùa, rừng lá rộng, thảo nguyên. Đới lạnh (gần cực): lạnh giá, băng tuyết, sinh vật nghèo (rêu, địa y, động vật chịu lạnh).'],
  [3,'Vì sao các đới thiên nhiên lại phân bố thành những dải theo vĩ độ?','Vì nhiệt độ, lượng mưa thay đổi theo vĩ độ (giảm dần từ Xích đạo về hai cực); khí hậu quyết định sinh vật, đất đai. Do đó thiên nhiên hình thành các đới (nóng, ôn hòa, lạnh) phân bố thành dải gần như song song với Xích đạo theo vĩ độ.'],
  [4,'Vì sao sự phân bố các đới thiên nhiên có ảnh hưởng đến đời sống và hoạt động sản xuất của con người?','Mỗi đới có khí hậu, sinh vật, đất đai khác nhau nên quy định cây trồng, vật nuôi, cách sinh sống. Đới nóng trồng lúa, cây nhiệt đới; đới ôn hòa trồng lúa mì, cây ôn đới; đới lạnh khó sản xuất nông nghiệp. Con người phải thích nghi và tổ chức sản xuất, đời sống phù hợp với đặc điểm từng đới.']
 ]);
 add(M,6,'Bài 26 (Địa lí): Thực hành: Tìm hiểu môi trường tự nhiên địa phương',[
  [1,'Môi trường tự nhiên địa phương gồm những thành phần nào?','Địa hình, khí hậu, sông ngòi, đất, sinh vật','Chỉ nhà cửa','Chỉ con người','Chỉ đường sá'],
  [1,'Để tìm hiểu môi trường tự nhiên địa phương, em có thể làm gì?','Quan sát thực tế, hỏi người lớn, tìm tài liệu, bản đồ','Đoán bừa','Không cần tìm hiểu','Chép của bạn'],
  [2,'Việc tìm hiểu môi trường địa phương giúp ích gì?','Hiểu đặc điểm tự nhiên nơi mình sống, biết cách bảo vệ môi trường','Không có ích','Gây lãng phí','Làm hại môi trường'],
  [2,'Khi khảo sát môi trường tự nhiên, cần ghi chép điều gì?','Đặc điểm địa hình, thời tiết, cây cối, sông suối, đất ở địa phương','Tên người quen','Giá nhà đất','Thời tiết nước ngoài'],
  [2,'Hành vi nào góp phần bảo vệ môi trường tự nhiên địa phương?','Trồng cây, giữ sạch nguồn nước, không xả rác','Chặt phá cây','Xả rác','Đổ chất thải ra sông'],
  [3,'Nêu các bước tìm hiểu môi trường tự nhiên ở địa phương em.','Xác định nội dung tìm hiểu (địa hình, khí hậu, sông, đất, sinh vật); thu thập thông tin (quan sát, hỏi, tra tài liệu, bản đồ); ghi chép, phân tích; nêu nhận xét về đặc điểm và đề xuất bảo vệ.'],
  [3,'Nêu một số đặc điểm tự nhiên tiêu biểu của địa phương em (gợi ý chung).','HS nêu theo thực tế: địa hình (đồng bằng/đồi núi/ven biển); khí hậu (nóng/lạnh, mưa); sông, hồ; loại đất; cây cối, con vật phổ biến ở địa phương.'],
  [4,'Vì sao hiểu biết về môi trường tự nhiên nơi mình sống lại quan trọng?','Giúp em biết thuận lợi, khó khăn của tự nhiên địa phương để sinh sống, học tập, sản xuất phù hợp; biết phòng tránh thiên tai; có ý thức bảo vệ môi trường, giữ gìn cảnh quan và tài nguyên quê hương; thêm yêu và gắn bó với nơi mình sống.']
 ]);
 add(M,6,'Bài 27 (Địa lí): Dân số và sự phân bố dân cư trên thế giới',[
  [1,'Dân số thế giới có xu hướng thay đổi như thế nào?','Ngày càng tăng','Ngày càng giảm','Không đổi','Biến mất'],
  [1,'Dân cư trên thế giới phân bố như thế nào?','Không đều: nơi đông, nơi thưa','Rất đều','Chỉ ở biển','Chỉ ở núi cao'],
  [2,'Khu vực nào thường tập trung đông dân?','Đồng bằng, ven biển, nơi khí hậu thuận lợi','Hoang mạc','Vùng cực','Núi cao hiểm trở'],
  [2,'Khu vực nào thường thưa dân?','Hoang mạc, vùng cực, núi cao, rừng rậm','Đồng bằng','Ven biển','Thành phố'],
  [2,'Yếu tố nào ảnh hưởng đến sự phân bố dân cư?','Điều kiện tự nhiên (địa hình, khí hậu, nước) và kinh tế – xã hội','Chỉ do ngẫu nhiên','Chỉ do màu da','Không có yếu tố nào'],
  [3,'Nêu đặc điểm phân bố dân cư trên thế giới.','Dân cư phân bố không đều: tập trung đông ở đồng bằng, ven biển, nơi khí hậu ôn hòa, kinh tế phát triển; thưa thớt ở hoang mạc, vùng cực, núi cao, rừng rậm — nơi điều kiện tự nhiên khắc nghiệt.'],
  [3,'Vì sao dân cư thế giới phân bố không đều?','Do điều kiện tự nhiên (địa hình bằng phẳng, khí hậu thuận lợi, nguồn nước, đất tốt) và điều kiện kinh tế – xã hội (sản xuất phát triển, giao thông, lịch sử) khác nhau ở từng nơi. Nơi thuận lợi thu hút dân đến ở đông, nơi khắc nghiệt thì thưa dân.'],
  [4,'Vì sao sự gia tăng dân số quá nhanh có thể gây sức ép lớn đến tài nguyên và môi trường?','Dân số tăng nhanh làm tăng nhu cầu lương thực, nhà ở, việc làm, nước, năng lượng; dẫn đến khai thác tài nguyên quá mức, phá rừng, ô nhiễm, thiếu việc làm, nghèo đói. Nếu không kiểm soát hợp lí, sức ép này gây suy thoái môi trường và cản trở phát triển bền vững.']
 ]);
 add(M,6,'Bài 28 (Địa lí): Mối quan hệ giữa con người và thiên nhiên',[
  [1,'Thiên nhiên có vai trò gì đối với con người?','Cung cấp tài nguyên, nơi sống, điều kiện cho sản xuất và đời sống','Không có vai trò','Chỉ gây hại','Làm con người nghèo đi'],
  [1,'Con người tác động đến thiên nhiên theo hướng nào?','Cả tích cực (cải tạo, bảo vệ) và tiêu cực (khai thác quá mức, gây ô nhiễm)','Chỉ tích cực','Chỉ tiêu cực','Không tác động'],
  [2,'Hành vi nào là tác động tiêu cực đến thiên nhiên?','Phá rừng, săn bắt bừa bãi, xả rác, gây ô nhiễm','Trồng cây','Bảo vệ động vật','Tiết kiệm tài nguyên'],
  [2,'Hậu quả của việc con người khai thác thiên nhiên quá mức là gì?','Cạn kiệt tài nguyên, ô nhiễm, thiên tai, biến đổi khí hậu','Thiên nhiên tốt lên','Không ảnh hưởng','Tài nguyên tăng'],
  [2,'Để chung sống hài hòa với thiên nhiên, con người cần làm gì?','Khai thác hợp lí, bảo vệ môi trường và tài nguyên','Khai thác cạn kiệt','Phá hoại thiên nhiên','Thờ ơ'],
  [3,'Nêu vai trò của thiên nhiên và tác động của con người đến thiên nhiên.','Thiên nhiên cung cấp đất, nước, không khí, khoáng sản, sinh vật — là cơ sở cho sự sống và sản xuất. Con người vừa cải tạo, bảo vệ thiên nhiên (trồng rừng, chống ô nhiễm), vừa có thể tác động xấu (phá rừng, khai thác quá mức, gây ô nhiễm).'],
  [3,'Nêu một số việc học sinh có thể làm để bảo vệ thiên nhiên, môi trường.','Trồng và chăm sóc cây; tiết kiệm điện, nước, giấy; bỏ rác đúng nơi, phân loại rác; hạn chế đồ nhựa dùng một lần; không bẻ cây, săn bắt thú; tuyên truyền bảo vệ môi trường.'],
  [4,'Vì sao con người cần sống hài hòa, thân thiện với thiên nhiên thay vì khai thác cạn kiệt?','Con người là một bộ phận của tự nhiên, phụ thuộc vào tài nguyên và môi trường để sống. Khai thác cạn kiệt, hủy hoại thiên nhiên sẽ dẫn đến ô nhiễm, thiên tai, biến đổi khí hậu, đe dọa chính cuộc sống con người. Sống hài hòa, bảo vệ thiên nhiên giúp phát triển bền vững cho hiện tại và tương lai.']
 ]);
 add(M,6,'Bài 30 (Địa lí): Thực hành: Tìm hiểu mối quan hệ giữa con người và thiên nhiên',[
  [1,'Để tìm hiểu mối quan hệ con người – thiên nhiên ở địa phương, em nên làm gì?','Quan sát, thu thập thông tin về cách con người khai thác và tác động đến tự nhiên','Đoán bừa','Không tìm hiểu','Chép của bạn'],
  [1,'Ví dụ nào thể hiện con người khai thác tự nhiên để sản xuất?','Trồng trọt, đánh bắt cá, khai thác khoáng sản','Ngủ nghỉ','Xem phim','Nghe nhạc'],
  [2,'Hành vi nào của con người gây hại cho thiên nhiên ở địa phương?','Xả rác, nước thải; chặt phá cây; đánh bắt hủy diệt','Trồng rừng','Dọn vệ sinh','Bảo vệ nguồn nước'],
  [2,'Việc tìm hiểu mối quan hệ con người – thiên nhiên giúp em điều gì?','Nhận ra tác động của con người và có ý thức bảo vệ môi trường','Không có ích','Gây lãng phí','Làm hại thiên nhiên'],
  [2,'Giải pháp nào giúp con người và thiên nhiên cùng tồn tại bền vững?','Khai thác hợp lí, trồng rừng, xử lí rác thải, bảo vệ môi trường','Khai thác cạn kiệt','Xả thải bừa bãi','Phá rừng'],
  [3,'Nêu các bước tìm hiểu mối quan hệ giữa con người và thiên nhiên ở địa phương.','Xác định nội dung (con người khai thác gì, tác động thế nào đến tự nhiên); thu thập thông tin (quan sát, hỏi, tra cứu); phân tích tác động tích cực và tiêu cực; đề xuất giải pháp bảo vệ môi trường.'],
  [3,'Nêu một số biểu hiện tác động tích cực và tiêu cực của con người đến thiên nhiên ở địa phương.','Tích cực: trồng cây gây rừng, cải tạo đất, xử lí rác, bảo vệ nguồn nước. Tiêu cực: phá rừng, khai thác quá mức, xả rác và nước thải gây ô nhiễm, đánh bắt hủy diệt.'],
  [4,'Vì sao mỗi người dân, kể cả học sinh, đều có trách nhiệm trong việc giữ gìn mối quan hệ hài hòa giữa con người và thiên nhiên?','Thiên nhiên là môi trường sống chung; mỗi hành vi (dù nhỏ) đều tác động đến môi trường. Nếu ai cũng khai thác bừa bãi, gây ô nhiễm thì thiên nhiên suy thoái, ảnh hưởng tất cả mọi người. Ngược lại, mỗi người có ý thức bảo vệ sẽ góp phần giữ môi trường trong lành, phát triển bền vững. Vì vậy đây là trách nhiệm chung của mọi người.']
 ]);
 /* Chủ đề tổng hợp Địa lí L6 */
 add(M,6,'Địa lí: Bản đồ, Trái Đất',[
  [1,'Kinh tuyến gốc (0 độ) đi qua đài thiên văn nào?','Grin-uých (Luân Đôn, Anh)','Pa-ri','Bắc Kinh','Niu Oóc'],
  [2,'Tỉ lệ 1 : 100 000 nghĩa là 1 cm trên bản đồ bằng bao nhiêu ngoài thực tế?','1 km (100 000 cm)','100 cm','1 cm','10 m'],
  [2,'Hệ quả của sự tự quay quanh trục của Trái Đất là gì?','Ngày và đêm luân phiên nhau','Bốn mùa','Mưa bão','Núi lửa'],
  [3,'Nêu hệ quả chuyển động tự quay quanh trục và chuyển động quanh Mặt Trời của Trái Đất.','Tự quay quanh trục: ngày – đêm luân phiên, giờ khác nhau ở các nơi. Quay quanh Mặt Trời: sinh ra các mùa, ngày đêm dài ngắn khác nhau theo mùa và vĩ độ.'],
  [4,'Vì sao hệ thống kinh, vĩ tuyến và bản đồ có vai trò quan trọng?','Kinh, vĩ tuyến giúp xác định tọa độ, vị trí chính xác mọi điểm; bản đồ thể hiện trực quan thông tin địa lí (vị trí, địa hình, khí hậu...). Nhờ đó con người định hướng, đi lại, nghiên cứu, quy hoạch, phục vụ học tập và nhiều lĩnh vực đời sống.']
 ]);
 add(M,6,'Địa lí: Khí hậu, nước và đất',[
  [1,'Nước ta nằm trong đới khí hậu nào?','Đới nóng (nhiệt đới)','Đới lạnh','Đới ôn hòa','Hàn đới'],
  [2,'Phần lớn nước trên Trái Đất là nước gì?','Nước mặn (biển, đại dương)','Nước ngọt','Nước đá','Hơi nước'],
  [2,'Thành phần quyết định độ phì của đất là gì?','Chất mùn (chất hữu cơ)','Đá tảng','Cát khô','Nước mặn'],
  [3,'Phân biệt thời tiết và khí hậu.','Thời tiết: trạng thái khí quyển tại một nơi trong thời gian ngắn, luôn thay đổi. Khí hậu: sự lặp lại có quy luật của thời tiết ở một nơi trong nhiều năm, mang tính ổn định.'],
  [4,'Vì sao cần bảo vệ nguồn nước, đất và không khí?','Nước, đất, không khí là những tài nguyên thiết yếu cho sự sống và sản xuất, nhưng có thể bị ô nhiễm, suy thoái, cạn kiệt do con người. Bảo vệ chúng giúp duy trì môi trường sống trong lành, bảo đảm sức khỏe, lương thực và sự phát triển bền vững cho hiện tại và tương lai.']
 ]);

 /* Bù chuẩn Địa lí L6 */
 add(M,6,'Bài 1 (Địa lí): Hệ thống kinh, vĩ tuyến',[
  [2,'Đường kinh tuyến nào được chọn làm kinh tuyến gốc?','Kinh tuyến 0 độ đi qua đài thiên văn Grin-uých','Kinh tuyến 180 độ','Kinh tuyến đi qua Hà Nội','Kinh tuyến đi qua Pa-ri']
 ]);
 add(M,6,'Bài 2 (Địa lí): Bản đồ',[
  [1,'Khi chuyển bề mặt cong của Trái Đất lên mặt phẳng bản đồ, điều gì xảy ra?','Có sự sai lệch (biến dạng) về hình dạng, diện tích hoặc khoảng cách','Hoàn toàn chính xác','Bản đồ trở thành hình cầu','Không vẽ được']
 ]);
 add(M,6,'Bài 5 (Địa lí): Lược đồ trí nhớ',[
  [1,'Lược đồ trí nhớ của mỗi người thường thể hiện không gian nào?','Không gian quen thuộc như nhà, trường, khu phố, làng xóm','Toàn thế giới','Đáy đại dương','Vũ trụ']
 ]);
 add(M,6,'Bài 6 (Địa lí): Trái Đất trong hệ Mặt Trời',[
  [2,'Hai hành tinh nằm gần Mặt Trời hơn Trái Đất là gì?','Thủy tinh và Kim tinh','Hỏa tinh và Mộc tinh','Thổ tinh và Thiên Vương tinh','Hải Vương tinh và Mộc tinh']
 ]);
 add(M,6,'Bài 7 (Địa lí): Chuyển động tự quay quanh trục của Trái Đất và hệ quả',[
  [1,'Trục Trái Đất là gì?','Đường tưởng tượng nối hai cực Bắc – Nam mà Trái Đất quay quanh','Đường Xích đạo','Đường bờ biển','Kinh tuyến gốc'],
  [2,'Việt Nam nằm ở múi giờ số mấy?','Múi giờ số 7','Múi giờ số 0','Múi giờ số 12','Múi giờ số 3']
 ]);
 add(M,6,'Bài 17 (Địa lí): Thời tiết và khí hậu',[
  [1,'Yếu tố nào sau đây là một yếu tố của thời tiết?','Nhiệt độ, độ ẩm, mưa, gió','Dân số','Độ cao núi','Loại đất'],
  [3,'Vì sao bản tin dự báo thời tiết lại quan trọng với đời sống hằng ngày?','Dự báo thời tiết cho biết trước nắng, mưa, nhiệt độ, gió, bão... giúp mọi người chuẩn bị trang phục, sắp xếp công việc, sản xuất, đi lại an toàn; cảnh báo sớm thiên tai (bão, lũ, rét hại) giúp phòng tránh, giảm thiệt hại về người và tài sản.']
 ]);
 add(M,6,'Bài 20 (Địa lí): Sông và hồ',[
  [2,'Chi lưu của sông là gì?','Các dòng chảy thoát nước ra khỏi sông chính','Dòng chảy đổ nước vào sông chính','Hồ chứa nước','Nguồn của sông']
 ]);
 add(M,6,'Địa lí: Bản đồ, Trái Đất',[
  [3,'Nêu các bước xác định phương hướng khi dùng la bàn ngoài thực địa.','Đặt la bàn nằm ngang, chờ kim ổn định; đầu kim có màu (thường đỏ) chỉ hướng bắc; từ hướng bắc xác định các hướng còn lại (đối diện là nam, bên phải là đông, bên trái là tây).']
 ]);
 add(M,6,'Địa lí: Khí hậu, nước và đất',[
  [3,'Nêu các nhân tố hình thành đất.','Đá mẹ (cung cấp khoáng), khí hậu (nhiệt, ẩm), sinh vật (tạo mùn), địa hình, thời gian; ngoài ra con người cũng tác động đến đất qua canh tác.']
 ]);
 add(M,6,'(Bổ sung) Thời nguyên thủy và bản đồ',[
  [1,'Người tối cổ sống chủ yếu bằng cách nào?','Săn bắt, hái lượm','Trồng lúa nước','Buôn bán','Làm công nghiệp'],
  [1,'Công cụ lao động đầu tiên của người nguyên thủy làm bằng gì?','Đá (ghè đẽo thô sơ)','Sắt','Đồng','Nhựa'],
  [2,'Vì sao người nguyên thủy phải sống thành bầy, thành nhóm?','Để cùng săn bắt, hái lượm và chống thú dữ, tự bảo vệ','Để buôn bán','Để học chữ','Để xây thành phố'],
  [2,'Tỉ lệ bản đồ 1 : 50 000 có nghĩa 1 cm trên bản đồ bằng bao nhiêu thực tế?','500 m','50 m','5 km','50 km'],
  [2,'Vĩ tuyến gốc là đường nào?','Xích đạo','Chí tuyến Bắc','Vòng cực Bắc','Kinh tuyến Grin-uých'],
  [3,'Việc phát hiện ra lửa có ý nghĩa gì với người nguyên thủy?','Lửa giúp sưởi ấm, nấu chín thức ăn, xua đuổi thú dữ, soi sáng; từ đó cải thiện sức khỏe, mở rộng nơi cư trú và là bước tiến lớn trong đời sống người nguyên thủy.'],
  [3,'Nêu các yếu tố cần có trên một bản đồ hoàn chỉnh.','Tên bản đồ, tỉ lệ, bảng chú giải (kí hiệu), phương hướng (mũi tên chỉ bắc hoặc lưới kinh vĩ tuyến), nội dung thể hiện.'],
  [3,'Kinh độ và vĩ độ của một điểm cho biết điều gì?','Kinh độ: khoảng cách tính bằng độ từ kinh tuyến gốc đến điểm; vĩ độ: khoảng cách tính bằng độ từ Xích đạo đến điểm. Hai số này tạo thành tọa độ địa lí xác định vị trí điểm đó.'],
  [4,'Vì sao công cụ bằng kim loại ra đời lại làm thay đổi lớn đời sống người nguyên thủy?','Công cụ kim loại sắc, bền hơn đá giúp khai hoang, cày cuốc, năng suất lao động tăng, của cải dư thừa xuất hiện; từ đó nảy sinh phân hóa giàu nghèo, xã hội nguyên thủy dần tan rã, chuyển sang xã hội có giai cấp và nhà nước.']
 ]);
})();
