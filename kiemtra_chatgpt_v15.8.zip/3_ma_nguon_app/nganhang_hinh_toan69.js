/* NGÂN HÀNG TOÁN – LỚP 6–9 — câu hỏi CÓ HÌNH MINH HỌA (mã @img). Câu hỏi nguyên bản, bám SGK Kết nối tri thức. */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Toán';

 /* ===================== LỚP 6 ===================== */
 add(M,6,'★ Nâng cao: Tập hợp các số tự nhiên',[
  [1,'Quan sát tia số. Tập hợp A gồm các số tự nhiên được đánh dấu bằng điểm đỏ. Cách viết đúng tập hợp A là?','A = {2; 5; 8}','A = {2; 5}','A = {0; 2; 5; 8}','A = {2; 5; 8; 10}','@img:truc:0:10:2,5,8'],
  [2,'Hai điểm đỏ trên tia số biểu diễn hai số tự nhiên a và b (a < b). Các số tự nhiên x thỏa mãn a < x < b là?','4; 5; 6','3; 4; 5; 6; 7','4; 5','5; 6','@img:truc:0:10:3,7'],
  [3,'Hai điểm đỏ trên tia số biểu diễn hai số tự nhiên a và b (a < b). Hãy viết tập hợp B các số tự nhiên x thỏa mãn a ≤ x ≤ b bằng cách liệt kê phần tử và cho biết B có bao nhiêu phần tử.','Từ hình: a = 1, b = 6. B = {1; 2; 3; 4; 5; 6}. Tập hợp B có 6 phần tử (6 − 1 + 1 = 6).','@img:truc:0:10:1,6']
 ]);
 add(M,6,'★ Nâng cao: Tính chia hết trong tập hợp các số tự nhiên',[
  [1,'Các điểm đỏ trên tia số biểu diễn những số có chung đặc điểm gì?','Đều là bội của 3','Đều là bội của 2','Đều là ước của 9','Đều là số nguyên tố','@img:truc:0:10:0,3,6,9'],
  [2,'Các điểm đỏ trên tia số biểu diễn tập hợp các số nào?','Các số nguyên tố nhỏ hơn 10','Các số lẻ nhỏ hơn 10','Các ước của 10','Các bội của 2 nhỏ hơn 10','@img:truc:0:10:2,3,5,7'],
  [3,'Các điểm đỏ trên tia số biểu diễn các số tự nhiên. Hãy cho biết số nào chia hết cho cả 2 và 3, số nào là hợp số nhưng không chia hết cho 3.','Các số được đánh dấu: 4, 6, 8, 9. Số chia hết cho cả 2 và 3 là 6. Hợp số không chia hết cho 3 là 4 và 8 (9 là hợp số nhưng chia hết cho 3).','@img:truc:0:10:4,6,8,9']
 ]);
 add(M,6,'★ Nâng cao: Số nguyên',[
  [1,'Trên trục số, hai điểm đỏ biểu diễn những số nguyên nào?','−3 và 2','3 và −2','−3 và −2','3 và 2','@img:truc:-5:5:-3,2'],
  [1,'Điểm đỏ trên trục số biểu diễn số nguyên nào?','−4','4','−3','−5','@img:truc:-5:5:-4'],
  [2,'Hai điểm đỏ trên trục số biểu diễn hai số nguyên. Kết quả so sánh đúng của hai số đó là?','−2 < 3','−2 > 3','3 < −2','−2 = 3','@img:truc:-5:5:-2,3'],
  [2,'Hai điểm đỏ trên trục số biểu diễn hai số nguyên đối nhau. Tổng của hai số đó bằng?','0','8','−8','4','@img:truc:-5:5:-4,4'],
  [2,'Hai điểm đỏ trên trục số biểu diễn hai số nguyên. Khoảng cách giữa hai điểm đó là bao nhiêu đơn vị?','4','2','3','−2','@img:truc:-5:5:-3,1'],
  [3,'Hai điểm đỏ trên trục số biểu diễn số nguyên a (điểm bên trái) và số nguyên b (điểm bên phải). Tính a + b và a − b.','Từ hình: a = −5, b = 3. a + b = (−5) + 3 = −2; a − b = (−5) − 3 = −8.','@img:truc:-5:5:-5,3'],
  [3,'Điểm đỏ trên trục số biểu diễn nhiệt độ (°C) buổi sáng ở một vùng núi. Đến trưa, nhiệt độ tăng thêm 7 °C. Hỏi nhiệt độ buổi trưa là bao nhiêu?','Nhiệt độ buổi sáng là −3 °C. Nhiệt độ buổi trưa: (−3) + 7 = 4 °C.','@img:truc:-5:5:-3'],
  [4,'Điểm đỏ trên trục số biểu diễn số nguyên a. Tìm tất cả các số nguyên x thỏa mãn a < x ≤ 2, rồi tính tổng các số đó. Giải thích cách làm.','Từ hình: a = −2. Các số nguyên x thỏa mãn −2 < x ≤ 2 là −1; 0; 1; 2 (không lấy −2 vì dấu "<", lấy 2 vì dấu "≤"). Tổng: (−1) + 0 + 1 + 2 = 2, vì (−1) + 1 = 0 (hai số đối nhau) nên tổng còn lại là 0 + 2 = 2.','@img:truc:-5:5:-2']
 ]);
 add(M,6,'★ Nâng cao: Phân số',[
  [1,'Hình tròn được chia thành các phần bằng nhau. Phần tô màu biểu diễn phân số nào?','3/8','8/3','5/8','3/5','@img:phanso:3:8'],
  [1,'Thanh hình chữ nhật được chia thành các phần bằng nhau. Phần tô màu biểu diễn phân số nào?','2/6','6/2','4/6','2/4','@img:phanso:2:6:thanh'],
  [2,'Hình tròn được chia thành các phần bằng nhau. Phần KHÔNG tô màu biểu diễn phân số nào?','3/4','1/4','1/3','4/3','@img:phanso:1:4'],
  [2,'Phần tô màu trong hình biểu diễn phân số nào dưới đây (ở dạng tối giản)?','2/3','3/2','1/3','1/2','@img:phanso:4:6:thanh'],
  [2,'Phần tô màu trong hình tròn bằng phân số nào dưới đây?','1/2','1/4','2/3','4/2','@img:phanso:2:4'],
  [3,'Hình tròn được chia thành các phần bằng nhau. Gọi phân số biểu diễn phần tô màu là p. Tính p + 1/5.','Phần tô màu là 3/10. Ta có 3/10 + 1/5 = 3/10 + 2/10 = 5/10 = 1/2.','@img:phanso:3:10'],
  [3,'Một chiếc bánh được chia thành các phần bằng nhau như hình, phần tô màu là phần đã ăn. Biết cả chiếc bánh nặng 600 g. Hỏi phần đã ăn nặng bao nhiêu gam?','Phần đã ăn là 5/12 chiếc bánh. Khối lượng phần đã ăn: 600 × 5/12 = 250 (g).','@img:phanso:5:12'],
  [4,'Hình tròn được chia thành các phần bằng nhau. Viết phân số biểu diễn phần tô màu, giải thích vì sao phân số đó bằng 1/4 và tìm phân số có mẫu số 20 bằng phân số đó.','Phần tô màu là 2/8. Vì 2 × 4 = 8 × 1 nên 2/8 = 1/4 (hai phân số bằng nhau khi tích chéo bằng nhau; hoặc rút gọn cả tử và mẫu cho 2). Phân số có mẫu 20: 1/4 = (1 × 5)/(4 × 5) = 5/20.','@img:phanso:2:8']
 ]);
 add(M,6,'★ Nâng cao: Số thập phân',[
  [1,'Bảng cho biết chiều cao của ba bạn. Bạn nào cao nhất?','Bình','An','Chi','Cả ba bằng nhau','@img:bang:Bạn;Chiều cao (m)|An;1,45|Bình;1,52|Chi;1,38'],
  [3,'Bảng cho biết chiều cao của ba bạn. Hỏi Bình cao hơn Chi bao nhiêu mét? Đổi kết quả ra xăng-ti-mét.','Bình cao hơn Chi: 1,52 − 1,38 = 0,14 (m) = 14 cm.','@img:bang:Bạn;Chiều cao (m)|An;1,45|Bình;1,52|Chi;1,38']
 ]);
 add(M,6,'★ Nâng cao: Một số hình phẳng trong thực tiễn',[
  [1,'Chu vi của hình vuông trong hình là?','24 cm','36 cm','12 cm','18 cm','@img:vuong:6'],
  [1,'Diện tích của hình chữ nhật trong hình là?','40 cm²','26 cm²','13 cm²','80 cm²','@img:hcn:8:5'],
  [2,'Chu vi của hình thoi trong hình là?','20 cm','10 cm','25 cm','15 cm','@img:thoi:5'],
  [2,'Chu vi của hình bình hành trong hình là?','22 cm','28 cm','11 cm','14 cm','@img:hbh:7:4'],
  [2,'Diện tích của hình thang trong hình là?','32 cm²','64 cm²','40 cm²','24 cm²','@img:thang:10:6:4'],
  [2,'Diện tích của tam giác trong hình là?','20 cm²','40 cm²','13 cm²','26 cm²','@img:tamgiac:8:5'],
  [3,'Tính chu vi và diện tích của hình chữ nhật trong hình.','Chu vi: (12 + 7) × 2 = 38 (cm). Diện tích: 12 × 7 = 84 (cm²).','@img:hcn:12:7'],
  [3,'Hình bình hành trong hình có chiều cao ứng với cạnh 6 cm là 3 cm. Tính chu vi và diện tích hình bình hành đó.','Chu vi: (6 + 4) × 2 = 20 (cm). Diện tích: 6 × 3 = 18 (cm²).','@img:hbh:6:4'],
  [4,'Tính diện tích hình thang trong hình. Một hình chữ nhật có diện tích bằng diện tích hình thang này và chiều rộng bằng chiều cao của hình thang. Tính chiều dài hình chữ nhật và giải thích vì sao chiều dài đó bằng trung bình cộng hai đáy của hình thang.','Diện tích hình thang: (12 + 8) × 5 : 2 = 50 (cm²). Chiều dài hình chữ nhật: 50 : 5 = 10 (cm). Giải thích: diện tích hình thang = (đáy lớn + đáy bé) : 2 × chiều cao; hình chữ nhật cùng diện tích và cùng chiều cao nên chiều dài = (đáy lớn + đáy bé) : 2 = (12 + 8) : 2 = 10 cm, đúng bằng trung bình cộng hai đáy.','@img:thang:12:8:5']
 ]);
 add(M,6,'★ Nâng cao: Tính đối xứng của hình phẳng trong tự nhiên',[
  [1,'Hình vuông trong hình có bao nhiêu trục đối xứng?','4','2','1','8','@img:vuong:4'],
  [1,'Hình chữ nhật trong hình có bao nhiêu trục đối xứng?','2','4','1','0','@img:hcn:6:4'],
  [2,'Nhận xét nào đúng về tính đối xứng của hình thoi trong hình?','Có tâm đối xứng và có 2 trục đối xứng','Không có tâm đối xứng, có 2 trục đối xứng','Có tâm đối xứng và có 4 trục đối xứng','Có tâm đối xứng, không có trục đối xứng','@img:thoi:5'],
  [3,'Hình bình hành trong hình có tâm đối xứng không? Có trục đối xứng không? Giải thích.','Hình bình hành có tâm đối xứng là giao điểm của hai đường chéo (quay hình nửa vòng quanh điểm đó thì hình trùng với chính nó). Hình bình hành (không phải hình chữ nhật, hình thoi) không có trục đối xứng vì không có đường thẳng nào chia nó thành hai nửa gấp lại trùng khít nhau.','@img:hbh:6:4'],
  [4,'Hình tròn tâm O trong hình có bao nhiêu trục đối xứng? Tâm đối xứng của nó là điểm nào? Hãy giải thích vì sao.','Hình tròn có vô số trục đối xứng: mọi đường thẳng đi qua tâm O đều là trục đối xứng, vì gấp hình tròn theo đường kính bất kì thì hai nửa trùng khít nhau. Tâm đối xứng của hình tròn là tâm O, vì mỗi điểm trên đường tròn đều có điểm đối xứng qua O cũng nằm trên đường tròn (hai đầu của một đường kính).','@img:tron:6']
 ]);
 add(M,6,'★ Nâng cao: Những hình hình học cơ bản',[
  [1,'Góc trong hình là loại góc gì?','Góc nhọn','Góc tù','Góc vuông','Góc bẹt','@img:goc:60'],
  [1,'Góc trong hình là loại góc gì?','Góc tù','Góc nhọn','Góc vuông','Góc bẹt','@img:goc:120'],
  [1,'Góc trong hình là loại góc gì?','Góc vuông','Góc nhọn','Góc tù','Góc bẹt','@img:goc:90'],
  [2,'Góc trong hình có số đo bao nhiêu và là loại góc gì?','180°, góc bẹt','90°, góc vuông','180°, góc tù','360°, góc bẹt','@img:goc:180'],
  [2,'Dùng thước trong hình, cho biết đoạn thẳng màu xanh dài bao nhiêu?','7 cm','6 cm','8 cm','7 mm','@img:thuoc:7'],
  [3,'Đoạn thẳng AB màu xanh được đo bằng thước như hình. Gọi M là trung điểm của AB. Tính độ dài AB và AM.','Theo thước, AB = 8 cm. M là trung điểm của AB nên AM = AB : 2 = 8 : 2 = 4 (cm).','@img:thuoc:8'],
  [3,'Góc xOy trong hình có số đo 45°. Vẽ tia Oz sao cho tia Oy nằm giữa hai tia Ox và Oz và góc xOz là góc vuông. Tính số đo góc yOz.','Vì tia Oy nằm giữa hai tia Ox và Oz nên góc xOy + góc yOz = góc xOz. Suy ra góc yOz = 90° − 45° = 45°.','@img:goc:45'],
  [4,'Góc trong hình có số đo 135°. Vì sao đó là góc tù? Nếu vẽ một tia nằm giữa hai cạnh của góc, chia góc thành hai góc trong đó có một góc vuông thì góc còn lại có số đo bao nhiêu và là loại góc gì?','Góc 135° lớn hơn 90° và nhỏ hơn 180° nên là góc tù. Tia nằm giữa hai cạnh chia góc 135° thành hai góc có tổng số đo bằng 135°; một góc là góc vuông (90°) nên góc còn lại là 135° − 90° = 45°, là góc nhọn.','@img:goc:135']
 ]);
 add(M,6,'★ Nâng cao: Dữ liệu và xác suất thực nghiệm',[
  [1,'Biểu đồ cột cho biết số học sinh mượn sách ở thư viện trong 4 ngày. Ngày nào có nhiều học sinh mượn sách nhất?','Thứ 4','Thứ 2','Thứ 3','Thứ 5','@img:bieudo:cot:Thứ 2=6,Thứ 3=4,Thứ 4=8,Thứ 5=5'],
  [2,'Biểu đồ cột cho biết số học sinh mượn sách ở thư viện trong 4 ngày. Tổng số lượt học sinh mượn sách trong 4 ngày đó là?','23','21','25','19','@img:bieudo:cot:Thứ 2=6,Thứ 3=4,Thứ 4=8,Thứ 5=5'],
  [1,'Bảng thống kê màu sắc yêu thích của các bạn trong lớp. Màu nào được ít bạn chọn nhất?','Tím','Đỏ','Xanh','Vàng','@img:bang:Màu yêu thích;Số bạn|Đỏ;9|Xanh;12|Vàng;7|Tím;4'],
  [2,'Bảng ghi kết quả tung một đồng xu nhiều lần. Xác suất thực nghiệm của sự kiện "xuất hiện mặt ngửa" là?','22/40 = 11/20','18/40 = 9/20','22/18','1/2','@img:bang:Mặt;Số lần|Sấp;18|Ngửa;22'],
  [2,'Biểu đồ cột cho biết sĩ số của bốn lớp khối 6. Lớp 6C có nhiều hơn lớp 6B bao nhiêu học sinh?','7','5','3','2','@img:bieudo:cot:6A=32,6B=28,6C=35,6D=30'],
  [3,'Bảng ghi kết quả gieo một con xúc xắc 60 lần. Tính xác suất thực nghiệm của sự kiện "xuất hiện mặt 3 chấm" và sự kiện "xuất hiện mặt có số chấm chẵn".','Mặt 3 chấm xuất hiện 12 lần: xác suất thực nghiệm = 12/60 = 1/5. Mặt chẵn (2, 4, 6 chấm) xuất hiện 10 + 9 + 10 = 29 lần: xác suất thực nghiệm = 29/60.','@img:bang:Số chấm;Số lần|1;8|2;10|3;12|4;9|5;11|6;10'],
  [3,'Biểu đồ cột cho biết số ngày mưa trong 4 tháng đầu năm ở một địa phương. Tính tổng số ngày mưa và cho biết tháng mưa nhiều nhất hơn tháng mưa ít nhất bao nhiêu ngày.','Tổng số ngày mưa: 12 + 9 + 15 + 6 = 42 (ngày). Tháng 3 mưa nhiều nhất (15 ngày), tháng 4 mưa ít nhất (6 ngày), chênh lệch 15 − 6 = 9 (ngày).','@img:bieudo:cot:Th1=12,Th2=9,Th3=15,Th4=6'],
  [4,'Một hộp có các quả bóng màu xanh, đỏ, vàng. Lấy ngẫu nhiên một quả, ghi màu rồi trả lại hộp; làm như vậy 50 lần được bảng bên. Tính xác suất thực nghiệm của mỗi màu. Có thể khẳng định chắc chắn trong hộp bóng đỏ nhiều nhất không? Vì sao?','Xác suất thực nghiệm: xanh 15/50 = 3/10; đỏ 25/50 = 1/2; vàng 10/50 = 1/5. Bóng đỏ có xác suất thực nghiệm lớn nhất nên có khả năng trong hộp bóng đỏ nhiều nhất, nhưng không thể khẳng định chắc chắn vì kết quả lấy ngẫu nhiên chỉ cho ước lượng; nếu lặp lại thí nghiệm, số lần có thể thay đổi. Muốn biết chính xác phải đếm trực tiếp số bóng trong hộp.','@img:bang:Màu;Số lần|Xanh;15|Đỏ;25|Vàng;10']
 ]);

 /* ===================== LỚP 7 ===================== */
 add(M,7,'★ Nâng cao: Số hữu tỉ',[
  [1,'Hai điểm đỏ trên trục số biểu diễn hai số hữu tỉ a (bên trái) và b (bên phải). Số nào dưới đây nằm giữa a và b?','−0,5','−2,5','1,5','2','@img:truc:-3:3:-2,1'],
  [3,'Hai điểm đỏ trên trục số biểu diễn hai số −2 và 2. Số hữu tỉ −3/2 được biểu diễn ở khoảng nào trên trục số? So sánh −3/2 với −2 và với 2.','−3/2 = −1,5 nằm giữa −2 và −1 trên trục số (bên trái điểm 0). Vì −2 < −1,5 < 2 nên −2 < −3/2 < 2.','@img:truc:-3:3:-2,2']
 ]);
 add(M,7,'★ Nâng cao: Số thực',[
  [2,'Trên trục số, hai điểm đỏ biểu diễn số 1 và số 2. Số √2 được biểu diễn ở vị trí nào?','Nằm giữa 1 và 2, gần 1 hơn','Nằm giữa 2 và 3','Đúng tại điểm 2','Nằm giữa 0 và 1','@img:truc:0:3:1,2'],
  [3,'Trên trục số, hai điểm đỏ biểu diễn số 1 và số 2. Hãy cho biết số √3 nằm giữa hai điểm nào và giải thích. Làm tròn √3 đến chữ số thập phân thứ hai.','Vì 1² = 1 < 3 < 4 = 2² nên 1 < √3 < 2, tức √3 nằm giữa hai điểm 1 và 2 (gần điểm 2 hơn). √3 ≈ 1,73.','@img:truc:0:3:1,2']
 ]);
 add(M,7,'★ Nâng cao: Góc và đường thẳng song song',[
  [1,'Hai đường thẳng a và b trong hình có vị trí tương đối như thế nào?','Song song với nhau','Cắt nhau','Vuông góc với nhau','Trùng nhau','@img:songsong'],
  [1,'Hai đường thẳng a và b trong hình có vị trí tương đối như thế nào?','Vuông góc với nhau','Song song với nhau','Trùng nhau','Không cắt nhau','@img:vuonggoc'],
  [2,'Góc trong hình có số đo 50°. Góc kề bù với góc đó có số đo bằng?','130°','40°','50°','310°','@img:goc:50'],
  [2,'Góc trong hình có số đo 70°. Góc đối đỉnh với góc đó có số đo bằng?','70°','110°','20°','290°','@img:goc:70'],
  [3,'Trong hình, a ∥ b. Một đường thẳng c cắt a và b, tạo với a một góc so le trong có số đo 65°. Tính số đo góc so le trong còn lại và số đo góc trong cùng phía với góc 65° đó.','Vì a ∥ b nên hai góc so le trong bằng nhau: góc so le trong còn lại bằng 65°. Hai góc trong cùng phía bù nhau nên góc trong cùng phía cần tìm bằng 180° − 65° = 115°.','@img:songsong'],
  [3,'Góc trong hình có số đo 35°. Tính số đo góc phụ và góc bù với góc đó.','Góc phụ: 90° − 35° = 55°. Góc bù: 180° − 35° = 145°.','@img:goc:35'],
  [4,'Trong hình, a ⊥ b tại O. Vẽ tia Oc nằm giữa hai tia Oa và Ob sao cho góc giữa Oc và tia Oa bằng 30°. Tính góc giữa Oc và tia Ob rồi giải thích vì sao chỉ cần biết a ⊥ b là tính được.','Vì a ⊥ b nên góc aOb = 90°. Tia Oc nằm giữa hai tia Oa, Ob nên góc aOc + góc cOb = góc aOb, suy ra góc cOb = 90° − 30° = 60°. Chỉ cần biết a ⊥ b vì khi đó góc aOb là góc vuông (90°), ta có ngay tổng hai góc kề nhau là 90° nên tính được góc còn lại.','@img:vuonggoc']
 ]);
 add(M,7,'★ Nâng cao: Tam giác bằng nhau',[
  [1,'Tam giác ABC trong hình (các số đo ghi trên hình) là tam giác gì?','Tam giác đều','Tam giác vuông','Tam giác tù','Tam giác vuông cân','@img:tgl:A:B:C:AB=6 cm:BC=6 cm:CA=6 cm'],
  [1,'Tam giác MNP trong hình cân tại đỉnh nào?','Cân tại M','Cân tại N','Cân tại P','Không phải tam giác cân','@img:tgl:M:N:P:MN=5 cm:NP=7 cm:PM=5 cm'],
  [2,'Tam giác ABC trong hình cân tại A, có góc B = 50°. Số đo góc A bằng?','80°','50°','65°','100°','@img:tgl:A:B:C:AB=4 cm:CA=4 cm'],
  [3,'Tam giác ABC trong hình cân tại A và có góc A = 40°. Tính số đo góc B, góc C và chu vi tam giác.','Tam giác cân tại A nên góc B = góc C = (180° − 40°) : 2 = 70°. Chu vi: 5 + 8 + 5 = 18 (cm).','@img:tgl:A:B:C:AB=5 cm:BC=8 cm:CA=5 cm'],
  [3,'Tam giác DEF trong hình có ba cạnh bằng nhau. Tính số đo mỗi góc và chu vi của tam giác.','Tam giác DEF đều nên mỗi góc bằng 180° : 3 = 60°. Chu vi: 6 × 3 = 18 (cm).','@img:tgl:D:E:F:DE=6 cm:EF=6 cm:FD=6 cm'],
  [4,'Tam giác ABC trong hình có AB = AC = 7 cm. Gọi M là trung điểm của BC. Chứng minh ΔABM = ΔACM và suy ra AM ⊥ BC.','Xét ΔABM và ΔACM có: AB = AC (giả thiết), BM = CM (M là trung điểm BC), AM chung. Vậy ΔABM = ΔACM (c.c.c). Suy ra góc AMB = góc AMC. Mà hai góc này kề bù nên góc AMB = góc AMC = 90°, tức AM ⊥ BC.','@img:tgl:A:B:C:AB=7 cm:CA=7 cm']
 ]);
 add(M,7,'★ Nâng cao: Quan hệ giữa các yếu tố trong tam giác',[
  [1,'Trong tam giác ABC ở hình, góc nào là góc lớn nhất?','Góc A','Góc B','Góc C','Ba góc bằng nhau','@img:tgl:A:B:C:AB=4 cm:BC=7 cm:CA=5 cm'],
  [1,'Trong tam giác MNP ở hình, góc nào là góc nhỏ nhất?','Góc N','Góc M','Góc P','Góc M và góc P','@img:tgl:M:N:P:MN=8 cm:NP=6 cm:PM=5 cm'],
  [2,'Tam giác ABC có AB = 3 cm, BC = 5 cm như hình. Độ dài cạnh AC có thể nhận giá trị nào dưới đây?','6 cm','2 cm','8 cm','9 cm','@img:tgl:A:B:C:AB=3 cm:BC=5 cm'],
  [2,'Với các số đo ghi trên hình, so sánh các góc của tam giác ABC.','Góc B = góc C < góc A','Góc A < góc B = góc C','Góc A = góc B < góc C','Góc B > góc C > góc A','@img:tgl:A:B:C:AB=6 cm:BC=9 cm:CA=6 cm'],
  [3,'Tam giác ABC có AB = 5 cm, AC = 9 cm như hình. Biết độ dài BC là một số nguyên (cm). Tìm các giá trị có thể của BC.','Theo bất đẳng thức tam giác: AC − AB < BC < AC + AB, tức 4 < BC < 14. Vì BC là số nguyên nên BC ∈ {5; 6; 7; 8; 9; 10; 11; 12; 13} (9 giá trị).','@img:tgl:A:B:C:AB=5 cm:CA=9 cm'],
  [3,'Với các số đo trên hình, hãy sắp xếp các góc của tam giác ABC theo thứ tự từ nhỏ đến lớn và giải thích.','Góc đối diện với cạnh lớn hơn thì lớn hơn. AB = 6 < CA = 8 < BC = 10, góc đối diện AB là góc C, đối diện CA là góc B, đối diện BC là góc A. Vậy góc C < góc B < góc A.','@img:tgl:A:B:C:AB=6 cm:BC=10 cm:CA=8 cm'],
  [4,'Tam giác ABC có AB = BC = 7 cm, CA = 4 cm như hình. Góc nào nhỏ nhất? Chứng tỏ rằng góc đó nhỏ hơn 60°.','CA = 4 cm là cạnh nhỏ nhất nên góc đối diện với nó là góc B nhỏ nhất. Tam giác cân tại B nên góc A = góc C. Giả sử góc B ≥ 60° thì góc A + góc C = 180° − góc B ≤ 120°, suy ra góc A = góc C ≤ 60° ≤ góc B, mâu thuẫn với việc góc B nhỏ nhất (góc B phải nhỏ hơn hẳn góc A vì CA < BC). Vậy góc B < 60°.','@img:tgl:A:B:C:AB=7 cm:BC=7 cm:CA=4 cm']
 ]);
 add(M,7,'★ Nâng cao: Thu thập và biểu diễn dữ liệu',[
  [1,'Biểu đồ cột cho biết số học sinh lớp 7A yêu thích mỗi môn học. Môn nào được nhiều bạn yêu thích nhất?','Toán','Văn','Anh','KHTN','@img:bieudo:cot:Toán=15,Văn=10,Anh=12,KHTN=8'],
  [2,'Biểu đồ cột cho biết số cây một trường trồng được mỗi năm. Từ năm 2019 đến năm 2022, số cây trồng tăng thêm bao nhiêu?','60 cây','30 cây','45 cây','180 cây','@img:bieudo:cot:2019=120,2020=135,2021=150,2022=180'],
  [2,'Bảng dữ liệu về một số bạn trong lớp. Dữ liệu ở cột "Số giờ tự học" thuộc loại nào?','Dữ liệu là số (số liệu)','Dữ liệu không là số, không sắp thứ tự được','Dữ liệu không là số nhưng sắp thứ tự được','Không phải dữ liệu','@img:bang:Tên;Môn yêu thích;Số giờ tự học|An;Toán;3|Bình;Văn;2|Chi;Anh;4'],
  [3,'Biểu đồ cột cho biết lượng mưa (mm) trong 4 tháng ở một trạm khí tượng. Tính tổng lượng mưa 4 tháng và cho biết tháng có lượng mưa lớn nhất hơn tháng có lượng mưa nhỏ nhất bao nhiêu mm.','Tổng lượng mưa: 40 + 35 + 50 + 45 = 170 (mm). Tháng 3 lớn nhất (50 mm), tháng 2 nhỏ nhất (35 mm), chênh lệch 50 − 35 = 15 (mm).','@img:bieudo:cot:Th1=40,Th2=35,Th3=50,Th4=45'],
  [4,'Bảng cho biết số học sinh giỏi và sĩ số của hai lớp. Lớp nào có tỉ lệ học sinh giỏi cao hơn? Vì sao chỉ so sánh số học sinh giỏi của hai lớp có thể dẫn đến kết luận sai?','Tỉ lệ học sinh giỏi: lớp 7A = 12/40 = 30%; lớp 7B = 15/45 ≈ 33,3%. Vậy lớp 7B có tỉ lệ cao hơn. Nếu chỉ so sánh số lượng (12 và 15) ta cũng kết luận 7B hơn, nhưng cách này không đúng về bản chất vì hai lớp có sĩ số khác nhau; ví dụ một lớp 50 học sinh có 15 giỏi thì tỉ lệ chỉ 30%, bằng lớp 7A dù số lượng nhiều hơn. Muốn so sánh công bằng phải dùng tỉ lệ phần trăm.','@img:bang:Lớp;Số HS giỏi;Sĩ số|7A;12;40|7B;15;45']
 ]);
 add(M,7,'★ Nâng cao: Tỉ lệ thức và đại lượng tỉ lệ',[
  [1,'Bảng cho biết các giá trị tương ứng của hai đại lượng x và y. Hai đại lượng này tỉ lệ thuận với hệ số tỉ lệ bằng?','3','1/3','2','4','@img:bang:x;2;4;6|y;6;12;18'],
  [2,'Bảng cho biết các giá trị tương ứng của hai đại lượng x và y. Nhận xét nào đúng?','x và y tỉ lệ nghịch với nhau, hệ số tỉ lệ 12','x và y tỉ lệ thuận với nhau, hệ số tỉ lệ 12','x và y tỉ lệ nghịch với nhau, hệ số tỉ lệ 6','x và y không tỉ lệ thuận cũng không tỉ lệ nghịch','@img:bang:x;1;2;4|y;12;6;3'],
  [3,'Bảng cho biết y tỉ lệ thuận với x. Tìm hệ số tỉ lệ k (y = kx) và giá trị còn thiếu (dấu ?) trong bảng.','k = y/x = 5/3 (kiểm tra: 10/6 = 5/3). Giá trị còn thiếu: y = (5/3) × 9 = 15.','@img:bang:x;3;6;9|y;5;10;?']
 ]);
 add(M,7,'★ Nâng cao: Biểu thức đại số và đa thức một biến',[
  [3,'Hình chữ nhật trong hình có chiều dài 5 cm, chiều rộng 3 cm. Nếu tăng chiều dài thêm x (cm) và giữ nguyên chiều rộng thì diện tích hình chữ nhật mới là biểu thức nào theo x? Tính giá trị biểu thức khi x = 2.','Diện tích mới: S = (5 + x) × 3 = 15 + 3x (cm²). Khi x = 2: S = 15 + 3 × 2 = 21 (cm²).','@img:hcn:5:3']
 ]);
 add(M,7,'★ Nâng cao: Làm quen với biến cố và xác suất của biến cố',[
  [1,'Một hộp có các quả bóng cùng kích thước với số lượng mỗi màu như bảng. Lấy ngẫu nhiên một quả bóng. Xác suất lấy được bóng màu đỏ là?','1/3','1/9','1/2','3','@img:bang:Màu bóng;Số quả|Đỏ;3|Xanh;3|Vàng;3'],
  [2,'Một hộp có các tấm thẻ như bảng, các thẻ giống nhau về kích thước. Rút ngẫu nhiên một thẻ. Xác suất của biến cố "rút được thẻ ghi số chẵn" là?','1/2','1/5','1/10','1','@img:bang:Loại thẻ;Số thẻ|Ghi số chẵn;5|Ghi số lẻ;5'],
  [3,'Một hộp có các quả bóng như bảng (cùng kích thước). Lấy ngẫu nhiên một quả. Với mỗi biến cố sau, cho biết đó là biến cố chắc chắn, không thể hay ngẫu nhiên và tính xác suất: A: "Lấy được bóng đỏ"; B: "Lấy được bóng tím"; C: "Lấy được bóng đỏ hoặc xanh".','A là biến cố ngẫu nhiên; vì số bóng đỏ bằng số bóng xanh (4 và 4) nên hai khả năng đồng khả năng, P(A) = 1/2. B là biến cố không thể (không có bóng tím), P(B) = 0. C là biến cố chắc chắn (mọi quả đều đỏ hoặc xanh), P(C) = 1.','@img:bang:Màu;Số quả|Đỏ;4|Xanh;4'],
  [4,'Một con xúc xắc có các mặt được tô màu như bảng. Gieo ngẫu nhiên một lần. Tính xác suất của các biến cố: A: "Mặt xuất hiện màu đỏ"; B: "Số chấm là số lẻ"; C: "Số chấm chẵn và mặt màu đỏ". Giải thích.','Các mặt 1, 3, 5 màu đỏ; 2, 4, 6 màu xanh. A: có 3 mặt đỏ trong 6 mặt đồng khả năng nên P(A) = 3/6 = 1/2. B: số chấm lẻ là 1, 3, 5 nên P(B) = 1/2. C: mọi mặt chẵn (2, 4, 6) đều màu xanh nên không có mặt nào vừa chẵn vừa đỏ, C là biến cố không thể, P(C) = 0.','@img:bang:Số chấm;1;2;3;4;5;6|Màu mặt;Đỏ;Xanh;Đỏ;Xanh;Đỏ;Xanh']
 ]);
 add(M,7,'★ Nâng cao: Một số hình khối trong thực tiễn',[
  [1,'Hình hộp chữ nhật trong hình có bao nhiêu mặt, bao nhiêu đỉnh, bao nhiêu cạnh?','6 mặt, 8 đỉnh, 12 cạnh','6 mặt, 12 đỉnh, 8 cạnh','8 mặt, 6 đỉnh, 12 cạnh','4 mặt, 8 đỉnh, 12 cạnh','@img:hinh3d:hophcn'],
  [2,'Hình lập phương trong hình có cạnh 5 cm. Thể tích của nó bằng?','125 cm³','25 cm³','150 cm³','30 cm³','@img:hinh3d:lapphuong'],
  [2,'Hình hộp chữ nhật trong hình có chiều dài 6 cm, chiều rộng 4 cm, chiều cao 3 cm. Diện tích xung quanh của nó bằng?','60 cm²','72 cm²','24 cm²','108 cm²','@img:hinh3d:hophcn'],
  [3,'Hình hộp chữ nhật trong hình có chiều dài 8 cm, chiều rộng 5 cm, chiều cao 4 cm. Tính thể tích, diện tích xung quanh và diện tích toàn phần của hình hộp.','Thể tích: V = 8 × 5 × 4 = 160 (cm³). Diện tích xung quanh: Sxq = 2 × (8 + 5) × 4 = 104 (cm²). Diện tích toàn phần: Stp = 104 + 2 × 8 × 5 = 184 (cm²).','@img:hinh3d:hophcn'],
  [4,'Hình lập phương trong hình có diện tích toàn phần bằng 216 cm². Tính độ dài cạnh và thể tích của hình lập phương. Giải thích cách làm.','Hình lập phương có 6 mặt là hình vuông bằng nhau nên diện tích một mặt = 216 : 6 = 36 (cm²). Cạnh a thỏa a × a = 36 nên a = 6 cm. Thể tích: V = 6 × 6 × 6 = 216 (cm³).','@img:hinh3d:lapphuong']
 ]);

 /* ===================== LỚP 8 ===================== */
 add(M,8,'★ Nâng cao: Đa thức',[
  [2,'Hình chữ nhật trong hình có chiều dài 6 cm, chiều rộng 4 cm. Nếu tăng chiều dài thêm x (cm) và chiều rộng thêm y (cm) thì diện tích hình chữ nhật mới là đa thức nào?','24 + 4x + 6y + xy','24 + 6x + 4y + xy','24 + xy','10 + x + y','@img:hcn:6:4']
 ]);
 add(M,8,'★ Nâng cao: Hằng đẳng thức đáng nhớ và ứng dụng',[
  [3,'Hình vuông trong hình có cạnh 5 cm. Nếu tăng cạnh thêm x (cm) thì diện tích hình vuông mới là đa thức nào theo x? Khai triển bằng hằng đẳng thức rồi tính giá trị khi x = 1.','Diện tích mới: S = (5 + x)² = 25 + 10x + x² (cm²). Khi x = 1: S = 25 + 10 + 1 = 36 (cm²) (đúng bằng 6² = 36).','@img:vuong:5']
 ]);
 add(M,8,'★ Nâng cao: Phân thức đại số',[
  [3,'Một hình chữ nhật khác có diện tích bằng diện tích hình chữ nhật trong hình và có chiều rộng x (cm). Viết phân thức biểu thị chiều dài của hình chữ nhật đó theo x, nêu điều kiện của x và tính chiều dài khi x = 6.','Diện tích hình trong hình: 12 × 8 = 96 (cm²). Chiều dài hình chữ nhật mới là 96/x (cm), điều kiện x ≠ 0 (thực tế x > 0). Khi x = 6: chiều dài = 96/6 = 16 (cm).','@img:hcn:12:8']
 ]);
 add(M,8,'★ Nâng cao: Tứ giác',[
  [1,'Tứ giác trong hình là hình bình hành. Tính chất nào sau đây đúng với hình bình hành?','Các cạnh đối song song và bằng nhau','Hai đường chéo bằng nhau','Bốn góc bằng nhau','Hai đường chéo vuông góc với nhau','@img:hbh:6:4'],
  [1,'Diện tích hình thang trong hình bằng?','28 cm²','56 cm²','36 cm²','18 cm²','@img:thang:9:5:4'],
  [2,'Hình bình hành ABCD trong hình có góc A = 60°. Số đo góc B bằng?','120°','60°','30°','90°','@img:hbh:7:4'],
  [3,'Hình thoi trong hình có cạnh 5 cm và một đường chéo dài 8 cm. Tính độ dài đường chéo còn lại và diện tích hình thoi.','Hai đường chéo của hình thoi vuông góc với nhau tại trung điểm mỗi đường. Nửa đường chéo đã biết: 8 : 2 = 4 (cm). Nửa đường chéo còn lại: √(5² − 4²) = √9 = 3 (cm), nên đường chéo còn lại dài 6 cm. Diện tích: (8 × 6) : 2 = 24 (cm²).','@img:thoi:5'],
  [4,'Hình chữ nhật ABCD trong hình có AB = 8 cm, BC = 6 cm. Gọi M, N, P, Q lần lượt là trung điểm của AB, BC, CD, DA. Chứng minh MNPQ là hình thoi và tính độ dài cạnh của nó.','MN là đường trung bình của tam giác ABC nên MN = AC/2; tương tự NP = BD/2, PQ = AC/2, QM = BD/2. Hình chữ nhật có hai đường chéo bằng nhau (AC = BD) nên MN = NP = PQ = QM, suy ra MNPQ là hình thoi. Đường chéo AC = √(8² + 6²) = √100 = 10 (cm), vậy cạnh hình thoi MN = 10 : 2 = 5 (cm).','@img:hcn:8:6']
 ]);
 add(M,8,'★ Nâng cao: Định lí Thalès',[
  [1,'Tam giác ABC trong hình có AB = 8 cm, AC = 6 cm. Lấy M trên AB sao cho AM = 4 cm, qua M kẻ MN ∥ BC (N thuộc AC). Độ dài AN bằng?','3 cm','4 cm','2 cm','6 cm','@img:tgl:A:B:C:AB=8 cm:CA=6 cm'],
  [2,'Tam giác ABC trong hình có BC = 12 cm. Gọi M, N lần lượt là trung điểm của AB và AC. Độ dài MN bằng?','6 cm','24 cm','12 cm','4 cm','@img:tgl:A:B:C:BC=12 cm'],
  [3,'Tam giác ABC trong hình có AB = 10 cm, AC = 15 cm, BC = 20 cm. Lấy D trên AB với AD = 4 cm, kẻ DE ∥ BC (E thuộc AC). Tính AE và DE.','Theo định lí Thalès: AE/AC = AD/AB = 4/10 = 2/5, suy ra AE = 15 × 2/5 = 6 (cm). Vì DE ∥ BC nên DE/BC = AD/AB = 2/5, suy ra DE = 20 × 2/5 = 8 (cm).','@img:tgl:A:B:C:AB=10 cm:CA=15 cm:BC=20 cm'],
  [4,'Tam giác ABC trong hình có AB = 6 cm, AC = 9 cm, BC = 10 cm. Tia phân giác của góc A cắt BC tại D. Tính DB và DC, nêu rõ tính chất đã dùng.','Theo tính chất đường phân giác trong tam giác: DB/DC = AB/AC = 6/9 = 2/3. Suy ra DB/(DB + DC) = 2/5, tức DB = 10 × 2/5 = 4 (cm) và DC = 10 − 4 = 6 (cm). Tính chất đã dùng: đường phân giác của một góc trong tam giác chia cạnh đối diện thành hai đoạn tỉ lệ với hai cạnh kề hai đoạn ấy.','@img:tgl:A:B:C:AB=6 cm:CA=9 cm:BC=10 cm']
 ]);
 add(M,8,'★ Nâng cao: Dữ liệu và biểu đồ',[
  [1,'Biểu đồ cột cho biết doanh thu (triệu đồng) của một cửa hàng theo từng quý. Quý nào có doanh thu cao nhất?','Quý 4','Quý 1','Quý 2','Quý 3','@img:bieudo:cot:Quý 1=20,Quý 2=35,Quý 3=25,Quý 4=40'],
  [2,'Biểu đồ cột cho biết doanh thu (triệu đồng) của một cửa hàng theo từng quý. Tổng doanh thu cả năm là?','120 triệu đồng','100 triệu đồng','110 triệu đồng','130 triệu đồng','@img:bieudo:cot:Quý 1=20,Quý 2=35,Quý 3=25,Quý 4=40'],
  [2,'Bảng thống kê môn thể thao yêu thích của học sinh lớp 8A. Tỉ lệ học sinh thích bóng đá là?','40%','16%','25%','50%','@img:bang:Môn;Bóng đá;Cầu lông;Bơi;Cờ vua|Số HS;16;8;10;6'],
  [3,'Biểu đồ cột cho biết số máy tính của một trường qua các năm. Số máy tính năm 2023 tăng bao nhiêu phần trăm so với năm 2022? So với năm 2020?','So với 2022: (90 − 75)/75 = 15/75 = 20%. So với 2020: (90 − 50)/50 = 40/50 = 80%.','@img:bieudo:cot:2020=50,2021=60,2022=75,2023=90'],
  [4,'Bảng cho biết sĩ số và số học sinh giỏi của hai lớp. Nếu chỉ vẽ biểu đồ cột về số học sinh giỏi thì có thể dẫn đến nhận định gì chưa chính xác? Tính tỉ lệ học sinh giỏi của mỗi lớp và cho biết nên dùng dạng biểu đồ nào để so sánh.','Biểu đồ cột về số học sinh giỏi cho thấy cột 8B (18) cao hơn 8A (16), dễ dẫn đến nhận định 8B học tốt hơn. Nhưng tỉ lệ học sinh giỏi: 8A = 16/40 = 40%, 8B = 18/50 = 36%, tức 8A có tỉ lệ cao hơn. Vì sĩ số hai lớp khác nhau nên muốn so sánh cần dùng tỉ lệ phần trăm, ví dụ biểu đồ hình quạt tròn cho mỗi lớp hoặc biểu đồ cột biểu diễn tỉ lệ phần trăm học sinh giỏi.','@img:bang:Lớp;8A;8B|Sĩ số;40;50|Số HS giỏi;16;18']
 ]);
 add(M,8,'★ Nâng cao: Phương trình bậc nhất và hàm số bậc nhất',[
  [1,'Trong mặt phẳng tọa độ ở hình, điểm A có tọa độ là?','(2; 3)','(3; 2)','(−1; 2)','(0; −2)','@img:toado:A(2,3),B(-1,2),C(0,-2)'],
  [1,'Trong mặt phẳng tọa độ ở hình, điểm N có tọa độ là?','(4; −2)','(−2; 4)','(−3; 1)','(4; 2)','@img:toado:M(-3,1),N(4,-2)'],
  [2,'Trong hình, điểm nào nằm trên trục hoành?','Điểm A','Điểm B','Cả hai điểm A và B','Không có điểm nào','@img:toado:A(3,0),B(0,-4)'],
  [1,'Đồ thị hàm số bậc nhất trong hình cắt trục tung tại điểm có tung độ bằng?','1','2','−1','0','@img:dothi:2:1'],
  [2,'Đồ thị hàm số trong hình cắt trục hoành tại điểm có tọa độ?','(3; 0)','(0; 3)','(−3; 0)','(1; 0)','@img:dothi:-1:3'],
  [2,'Hàm số có đồ thị như hình có hệ số góc bằng bao nhiêu và là hàm số đồng biến hay nghịch biến?','Hệ số góc 1, hàm số đồng biến','Hệ số góc −2, hàm số nghịch biến','Hệ số góc 1, hàm số nghịch biến','Hệ số góc −2, hàm số đồng biến','@img:dothi:1:-2'],
  [2,'Điểm nào dưới đây thuộc đồ thị hàm số trong hình?','(1; 2)','(2; 1)','(0; −4)','(1; 6)','@img:dothi:-2:4'],
  [3,'Quan sát đường thẳng trong hình (đồ thị của một hàm số bậc nhất). Xác định giao điểm của đường thẳng với trục tung, với trục hoành và nêu hệ số góc của đường thẳng.','Hàm số y = 3x − 3. Giao với trục tung: x = 0, y = −3, điểm (0; −3). Giao với trục hoành: y = 0 ⇒ 3x − 3 = 0 ⇒ x = 1, điểm (1; 0). Hệ số góc của đường thẳng là 3.','@img:dothi:3:-3'],
  [3,'Trong hình cho hai điểm A và B. Tìm hàm số bậc nhất y = ax + b có đồ thị là đường thẳng đi qua A và B.','A(1; 2), B(2; 4). Thay vào y = ax + b: a + b = 2 và 2a + b = 4. Trừ vế: a = 2, b = 0. Vậy y = 2x (đường thẳng đi qua gốc tọa độ).','@img:toado:A(1,2),B(2,4)'],
  [4,'Đường thẳng d trong hình là đồ thị hàm số y = −x + 2. (a) Viết phương trình đường thẳng d\' song song với d và đi qua điểm (0; −1). (b) Tính diện tích tam giác tạo bởi d với hai trục tọa độ. Giải thích.','(a) d\' song song với d nên có cùng hệ số góc −1: y = −x + b; đi qua (0; −1) nên b = −1. Vậy d\': y = −x − 1 (b ≠ 2 nên d\' không trùng d). (b) d cắt trục tung tại (0; 2), cắt trục hoành tại (2; 0). Tam giác tạo bởi d và hai trục là tam giác vuông tại O có hai cạnh góc vuông dài 2 và 2, diện tích = (2 × 2)/2 = 2 (đơn vị diện tích).','@img:dothi:-1:2']
 ]);
 add(M,8,'★ Nâng cao: Mở đầu về tính xác suất của biến cố',[
  [1,'Một hộp có các quả bóng cùng kích thước với số lượng như bảng. Lấy ngẫu nhiên một quả. Xác suất lấy được bóng đỏ là?','1/2','1/3','5/5','3/10','@img:bang:Màu;Đỏ;Xanh;Vàng|Số quả;5;3;2'],
  [2,'Bảng ghi kết quả tung một đồng xu 100 lần. Xác suất thực nghiệm của biến cố "xuất hiện mặt ngửa" là?','0,55','0,45','55','0,5','@img:bang:Kết quả;Sấp;Ngửa|Số lần;45;55'],
  [3,'Bảng ghi kết quả gieo một con xúc xắc cân đối 60 lần. Tính xác suất thực nghiệm của biến cố "xuất hiện mặt 5 chấm" và so sánh với xác suất lí thuyết của biến cố đó.','Mặt 5 chấm xuất hiện 12 lần nên xác suất thực nghiệm = 12/60 = 0,2. Xác suất lí thuyết = 1/6 ≈ 0,167. Hai giá trị gần nhau; khi gieo nhiều lần hơn, xác suất thực nghiệm càng gần 1/6.','@img:bang:Số chấm;1;2;3;4;5;6|Số lần;9;11;10;8;12;10'],
  [4,'Bảng thống kê số học sinh đeo kính của một lớp 40 học sinh. Chọn ngẫu nhiên một học sinh. Tính xác suất của biến cố A: "Học sinh được chọn là nữ và có đeo kính" và biến cố B: "Học sinh được chọn có đeo kính". Giải thích cách tính.','Mỗi học sinh có cùng khả năng được chọn, nên xác suất = số kết quả thuận lợi / 40. A: có 9 học sinh nữ đeo kính nên P(A) = 9/40. B: số học sinh đeo kính = 6 + 9 = 15 nên P(B) = 15/40 = 3/8.','@img:bang:Nhóm;Có kính;Không kính|Nam;6;14|Nữ;9;11']
 ]);
 add(M,8,'★ Nâng cao: Tam giác đồng dạng',[
  [1,'Tam giác ABC trong hình vuông tại A có AB = 3 cm, AC = 4 cm (hình không vẽ đúng tỉ lệ). Độ dài BC bằng?','5 cm','7 cm','1 cm','25 cm','@img:tgl:A:B:C:AB=3 cm:CA=4 cm'],
  [2,'Tam giác ABC trong hình vuông tại A có AB = 6 cm, BC = 10 cm (hình không vẽ đúng tỉ lệ). Độ dài AC bằng?','8 cm','4 cm','16 cm','12 cm','@img:tgl:A:B:C:AB=6 cm:BC=10 cm'],
  [2,'Tam giác ABC trong hình. Biết ΔDEF ∽ ΔABC với DE = 8 cm (DE tương ứng với AB). Độ dài EF bằng?','12 cm','6 cm','8 cm','10 cm','@img:tgl:A:B:C:AB=4 cm:BC=6 cm:CA=5 cm'],
  [2,'Với các số đo trên hình (hình không vẽ đúng tỉ lệ), tam giác ABC có phải tam giác vuông không?','Vuông tại A','Vuông tại B','Vuông tại C','Không phải tam giác vuông','@img:tgl:A:B:C:AB=5 cm:BC=13 cm:CA=12 cm'],
  [3,'Tam giác ABC trong hình vuông tại A có AB = 9 cm, AC = 12 cm (hình không vẽ đúng tỉ lệ). Tính BC, diện tích tam giác và độ dài đường cao AH kẻ từ A.','BC = √(9² + 12²) = √225 = 15 (cm). Diện tích S = (9 × 12)/2 = 54 (cm²). Đường cao AH = 2S/BC = 108/15 = 7,2 (cm).','@img:tgl:A:B:C:AB=9 cm:CA=12 cm'],
  [3,'Tam giác ABC trong hình. Tam giác MNP đồng dạng với tam giác ABC (M, N, P tương ứng A, B, C) có MN = 6 cm. Tính tỉ số đồng dạng, các cạnh NP, PM và chu vi tam giác MNP.','Tỉ số đồng dạng k = MN/AB = 6/4 = 3/2. NP = k × BC = 1,5 × 6 = 9 (cm); PM = k × CA = 1,5 × 5 = 7,5 (cm). Chu vi MNP = 6 + 9 + 7,5 = 22,5 (cm) (bằng 1,5 lần chu vi ABC = 15 cm).','@img:tgl:A:B:C:AB=4 cm:BC=6 cm:CA=5 cm'],
  [4,'Tam giác ABC trong hình vuông tại A có AB = 6 cm, AC = 8 cm (hình không vẽ đúng tỉ lệ), đường cao AH. Chứng minh ΔHBA ∽ ΔABC, từ đó tính BC, AH và BH.','ΔHBA và ΔABC có góc AHB = góc BAC = 90° và góc B chung nên ΔHBA ∽ ΔABC (g.g). BC = √(6² + 8²) = 10 (cm). Từ đồng dạng: AH/AC = AB/BC ⇒ AH = 8 × 6/10 = 4,8 (cm); BH/AB = AB/BC ⇒ BH = 6²/10 = 3,6 (cm).','@img:tgl:A:B:C:AB=6 cm:CA=8 cm']
 ]);
 add(M,8,'★ Nâng cao: Một số hình khối trong thực tiễn',[
  [1,'Hình chóp tứ giác đều trong hình có bao nhiêu mặt bên?','4','3','5','6','@img:hinh3d:chop'],
  [2,'Hình chóp tứ giác đều trong hình có đáy là hình vuông cạnh 6 cm và chiều cao 5 cm. Thể tích của nó bằng?','60 cm³','180 cm³','30 cm³','90 cm³','@img:hinh3d:chop'],
  [3,'Hình chóp tứ giác đều trong hình có đáy là hình vuông cạnh 10 cm, trung đoạn 13 cm. Tính diện tích xung quanh và thể tích của hình chóp.','Diện tích xung quanh: Sxq = (chu vi đáy × trung đoạn)/2 = (40 × 13)/2 = 260 (cm²). Chiều cao h = √(13² − 5²) = √144 = 12 (cm) (5 cm là nửa cạnh đáy). Thể tích: V = (1/3) × 10² × 12 = 400 (cm³).','@img:hinh3d:chop'],
  [4,'Hình chóp tứ giác đều trong hình có đáy là hình vuông cạnh a và chiều cao h. Nếu cạnh đáy tăng gấp đôi còn chiều cao giữ nguyên thì thể tích thay đổi như thế nào? Giải thích bằng công thức.','V = (1/3) × a² × h. Khi cạnh đáy là 2a: V\' = (1/3) × (2a)² × h = (1/3) × 4a² × h = 4V. Vậy thể tích tăng gấp 4 lần vì diện tích đáy tỉ lệ với bình phương cạnh đáy, còn chiều cao không đổi.','@img:hinh3d:chop']
 ]);

 /* ===================== LỚP 9 ===================== */
 add(M,9,'★ Nâng cao: Phương trình và hệ hai phương trình bậc nhất hai ẩn',[
  [1,'Đường thẳng trong hình biểu diễn tập nghiệm của phương trình bậc nhất hai ẩn nào?','2x − y = 1','2x + y = 1','x − 2y = 1','2x − y = −1','@img:dothi:2:-1'],
  [2,'Đường thẳng trong hình biểu diễn tập nghiệm của phương trình x + y = 3. Cặp số nào là một nghiệm của phương trình đó?','(1; 2)','(3; 1)','(2; 2)','(−1; 2)','@img:dothi:-1:3'],
  [3,'Đường thẳng trong hình là đồ thị của y = x − 2, tức biểu diễn tập nghiệm của phương trình x − y = 2. Giải hệ phương trình gồm x − y = 2 và x + y = 4, rồi nêu ý nghĩa hình học của nghiệm.','Cộng hai phương trình: 2x = 6 ⇒ x = 3; thay vào x + y = 4 ⇒ y = 1. Nghiệm (3; 1). Ý nghĩa: điểm (3; 1) là giao điểm của đường thẳng trong hình với đường thẳng x + y = 4.','@img:dothi:1:-2'],
  [4,'Đường thẳng d trong hình là đồ thị của y = 2x + 1, biểu diễn tập nghiệm của phương trình 2x − y = −1. Xét hệ gồm 2x − y = −1 và 4x − 2y = m. Tìm m để hệ có vô số nghiệm; với các giá trị m còn lại hệ có bao nhiêu nghiệm? Giải thích bằng hình học.','Phương trình 4x − 2y = m tương đương 2x − y = m/2, biểu diễn một đường thẳng song song hoặc trùng với d (cùng hệ số góc 2). Nếu m/2 = −1, tức m = −2, hai đường thẳng trùng nhau nên hệ có vô số nghiệm. Nếu m ≠ −2, hai đường thẳng song song, không có điểm chung nên hệ vô nghiệm. Không có giá trị m nào để hệ có nghiệm duy nhất.','@img:dothi:2:1']
 ]);
 add(M,9,'★ Nâng cao: Phương trình và bất phương trình bậc nhất một ẩn',[
  [2,'Điểm đỏ trên trục số biểu diễn nghiệm của phương trình nào dưới đây?','2x + 2 = 0','2x − 2 = 0','x + 2 = 0','3x = 3','@img:truc:-5:5:-1'],
  [3,'Điểm đỏ trên trục số biểu diễn nghiệm của phương trình 3x − 9 = 0. Giải bất phương trình 2x − 6 > 0 và cho biết trên trục số những số nguyên nào (trong khoảng đã vẽ) là nghiệm của bất phương trình đó.','3x − 9 = 0 ⇔ x = 3, đúng với điểm đỏ. 2x − 6 > 0 ⇔ x > 3. Trên trục số từ −5 đến 5, các số nguyên là nghiệm của bất phương trình là 4 và 5 (3 không là nghiệm vì bất đẳng thức là "lớn hơn").','@img:truc:-5:5:3']
 ]);
 add(M,9,'★ Nâng cao: Căn bậc hai và căn bậc ba',[
  [2,'Hình vuông trong hình có cạnh 7 cm. Độ dài đường chéo của hình vuông bằng?','7√2 cm','14 cm','√14 cm','49 cm','@img:vuong:7'],
  [3,'Tính độ dài đường chéo của hình vuông trong hình. Viết kết quả dưới dạng a√b với b nhỏ nhất và làm tròn đến chữ số thập phân thứ hai.','Đường chéo d = √(5² + 5²) = √50 = √(25 × 2) = 5√2 (cm) ≈ 7,07 cm.','@img:vuong:5']
 ]);
 add(M,9,'★ Nâng cao: Hệ thức lượng trong tam giác vuông',[
  [1,'Tam giác ABC trong hình vuông tại A (hình không vẽ đúng tỉ lệ). Giá trị sin B bằng?','4/5','3/5','3/4','4/3','@img:tgl:A:B:C:AB=3 cm:BC=5 cm:CA=4 cm'],
  [1,'Tam giác ABC trong hình vuông tại A (hình không vẽ đúng tỉ lệ). Giá trị tan C bằng?','3/4','4/3','3/5','4/5','@img:tgl:A:B:C:AB=6 cm:BC=10 cm:CA=8 cm'],
  [2,'Tam giác ABC trong hình vuông tại A có AB = 5 cm, AC = 12 cm. Giá trị cos B bằng?','5/13','12/13','5/12','12/5','@img:tgl:A:B:C:AB=5 cm:CA=12 cm'],
  [2,'Tam giác ABC trong hình vuông tại A có BC = 10 cm và góc B = 30°. Độ dài AC bằng?','5 cm','5√3 cm','10 cm','2,5 cm','@img:tgl:A:B:C:BC=10 cm'],
  [3,'Tam giác ABC trong hình vuông tại A có AB = 8 cm, AC = 6 cm, đường cao AH. Tính BC, AH, BH, CH.','BC = √(8² + 6²) = 10 (cm). AH × BC = AB × AC ⇒ AH = 48/10 = 4,8 (cm). AB² = BH × BC ⇒ BH = 64/10 = 6,4 (cm). CH = BC − BH = 3,6 (cm) (kiểm tra: AC² = 36 = CH × BC = 3,6 × 10).','@img:tgl:A:B:C:AB=8 cm:CA=6 cm'],
  [3,'Tam giác ABC trong hình vuông tại A có AB = 7 cm và góc C = 40°. Tính AC và BC (làm tròn đến chữ số thập phân thứ hai).','tan C = AB/AC ⇒ AC = 7/tan 40° ≈ 7/0,8391 ≈ 8,34 (cm). sin C = AB/BC ⇒ BC = 7/sin 40° ≈ 7/0,6428 ≈ 10,89 (cm).','@img:tgl:A:B:C:AB=7 cm'],
  [4,'Tam giác ABC trong hình vuông tại A có AB = 9 cm, AC = 12 cm. Tính bốn tỉ số lượng giác của góc B rồi kiểm chứng đẳng thức sin²B + cos²B = 1. Giải thích vì sao đẳng thức này luôn đúng với mọi góc nhọn.','BC = √(81 + 144) = 15 (cm). sin B = AC/BC = 12/15 = 4/5; cos B = AB/BC = 9/15 = 3/5; tan B = AC/AB = 4/3; cot B = 3/4. Kiểm chứng: (4/5)² + (3/5)² = 16/25 + 9/25 = 1. Tổng quát: sin²B + cos²B = (AC² + AB²)/BC² = BC²/BC² = 1 theo định lí Pythagore, nên luôn đúng với mọi góc nhọn trong tam giác vuông.','@img:tgl:A:B:C:AB=9 cm:CA=12 cm']
 ]);
 add(M,9,'★ Nâng cao: Đường tròn',[
  [1,'Đường tròn tâm O trong hình có đường kính 8 cm. Bán kính của đường tròn bằng?','4 cm','8 cm','16 cm','2 cm','@img:tron:8'],
  [2,'Đường tròn tâm O trong hình có đường kính 10 cm. Chu vi (độ dài) đường tròn bằng?','10π cm','5π cm','25π cm','100π cm','@img:tron:10'],
  [2,'Góc ở tâm AOB của đường tròn (O; 6 cm) có số đo 60° như hình. Độ dài cung nhỏ AB bằng?','2π cm','6π cm','π cm','12π cm','@img:goc:60'],
  [3,'Đường tròn tâm O trong hình có đường kính 12 cm. Tính diện tích hình tròn và diện tích hình quạt tròn ứng với cung 60°.','Bán kính R = 6 cm. Diện tích hình tròn: πR² = 36π ≈ 113,04 (cm²). Hình quạt ứng với cung 60°: S = πR² × 60/360 = 36π/6 = 6π ≈ 18,84 (cm²).','@img:tron:12'],
  [4,'Đường tròn tâm O trong hình có đường kính 10 cm. Vẽ dây AB dài 8 cm. Tính khoảng cách từ tâm O đến dây AB và giải thích cách làm.','Bán kính R = 5 cm. Kẻ OH ⊥ AB (H thuộc AB) thì H là trung điểm của AB (đường kính vuông góc với dây thì đi qua trung điểm của dây), nên HA = 4 cm. Trong tam giác vuông OHA: OH = √(OA² − HA²) = √(25 − 16) = 3 (cm). Vậy khoảng cách từ O đến AB là 3 cm.','@img:tron:10']
 ]);
 add(M,9,'★ Nâng cao: Hàm số y = ax² (a ≠ 0). Phương trình bậc hai một ẩn',[
  [2,'Hai điểm A và B trong hình cùng thuộc đồ thị hàm số y = ax². Hệ số a bằng?','2','1','1/2','−2','@img:toado:A(1,2),B(-1,2)'],
  [3,'Hai điểm A và B trong hình cùng thuộc parabol y = ax². Tìm a, cho biết điểm (4; −8) có thuộc parabol không và tính giá trị hàm số tại x = 1.','A(2; −2): −2 = a × 2² ⇒ a = −1/2 (B(−2; −2) cũng thỏa). Với x = 4: y = −(1/2) × 16 = −8, nên (4; −8) thuộc parabol. Tại x = 1: y = −1/2 = −0,5.','@img:toado:A(2,-2),B(-2,-2)']
 ]);
 add(M,9,'★ Nâng cao: Tần số và tần số tương đối',[
  [1,'Bảng tần số điểm kiểm tra của 30 học sinh. Tần số tương đối của điểm 7 là?','33,3%','10%','30%','23,3%','@img:bang:Điểm;5;6;7;8;9|Tần số;3;7;10;6;4'],
  [2,'Biểu đồ cột cho biết tần số màu sắc được chọn của 40 học sinh. Tần số tương đối của màu xanh là?','45%','18%','30%','25%','@img:bieudo:cot:Đỏ=12,Xanh=18,Vàng=10'],
  [3,'Bảng tần số điểm kiểm tra của 30 học sinh. Lập bảng tần số tương đối (làm tròn đến một chữ số thập phân) và cho biết giá trị có tần số lớn nhất.','Tần số tương đối: điểm 5: 3/30 = 10%; điểm 6: 7/30 ≈ 23,3%; điểm 7: 10/30 ≈ 33,3%; điểm 8: 6/30 = 20%; điểm 9: 4/30 ≈ 13,3%. Giá trị có tần số lớn nhất là điểm 7 (10 học sinh).','@img:bang:Điểm;5;6;7;8;9|Tần số;3;7;10;6;4'],
  [4,'Bảng tần số ghép nhóm về cân nặng (kg) của 25 học sinh. Lập bảng tần số tương đối ghép nhóm, cho biết nhóm có tần số tương đối lớn nhất và giải thích vì sao với dữ liệu này nên dùng bảng ghép nhóm thay vì bảng tần số thông thường.','Tổng 4 + 10 + 8 + 3 = 25. Tần số tương đối: nhóm 40–45: 16%; 45–50: 40%; 50–55: 32%; 55–60: 12%. Nhóm 45–50 kg có tần số tương đối lớn nhất. Cân nặng là dữ liệu số có nhiều giá trị khác nhau (có thể lẻ đến từng 0,1 kg); nếu lập bảng tần số theo từng giá trị thì bảng rất dài, mỗi giá trị chỉ xuất hiện 1–2 lần, khó nhận xét. Ghép nhóm giúp bảng gọn và thấy rõ xu hướng phân bố.','@img:bang:Nhóm (kg);40-45;45-50;50-55;55-60|Tần số;4;10;8;3']
 ]);
 add(M,9,'★ Nâng cao: Xác suất của biến cố trong một số mô hình xác suất đơn giản',[
  [1,'Tung hai đồng xu cân đối, bảng liệt kê các kết quả có thể (S: sấp, N: ngửa). Xác suất của biến cố "cả hai đồng xu đều sấp" là?','1/4','1/2','1/3','3/4','@img:bang:Kết quả;SS;SN;NS;NN'],
  [2,'Rút ngẫu nhiên một thẻ số từ hộp I (thẻ 1, 2, 3) và một thẻ chữ từ hộp II (thẻ A, B). Bảng liệt kê các kết quả. Xác suất của biến cố "thẻ số là số lẻ và thẻ chữ là A" bằng?','1/3','1/6','1/2','2/3','@img:bang:Số \\ Chữ;A;B|1;1A;1B|2;2A;2B|3;3A;3B'],
  [3,'Bảng cho biết giới tính của bốn bạn trong một nhóm. Chọn ngẫu nhiên 2 bạn trong nhóm. Liệt kê các kết quả có thể và tính xác suất của biến cố "cả hai bạn đều là nam" và biến cố "có đúng một bạn nữ".','Các cách chọn 2 bạn: An–Bình, An–Chi, An–Dũng, Bình–Chi, Bình–Dũng, Chi–Dũng (6 kết quả đồng khả năng). Cả hai đều nam: An–Bình, An–Dũng, Bình–Dũng ⇒ xác suất 3/6 = 1/2. Có đúng một bạn nữ (Chi đi cùng một bạn nam): An–Chi, Bình–Chi, Chi–Dũng ⇒ xác suất 3/6 = 1/2.','@img:bang:Bạn;An;Bình;Chi;Dũng|Giới tính;Nam;Nam;Nữ;Nam'],
  [4,'Gieo đồng thời một con xúc xắc và một đồng xu cân đối; bảng liệt kê các kết quả (số chấm và mặt S/N). Tính xác suất của biến cố A: "Đồng xu sấp và số chấm chẵn" và biến cố B: "Số chấm lớn hơn 4 hoặc đồng xu ngửa". Giải thích cách đếm.','Có 6 × 2 = 12 kết quả đồng khả năng. A: số chấm chẵn (2, 4, 6) kết hợp mặt S: 2S, 4S, 6S ⇒ P(A) = 3/12 = 1/4. B: các kết quả có mặt N là 6 (1N…6N), cộng thêm các kết quả mặt S có số chấm lớn hơn 4: 5S, 6S ⇒ tổng 8 kết quả (đếm như vậy để không đếm trùng 5N, 6N) ⇒ P(B) = 8/12 = 2/3.','@img:bang:Xúc xắc \\ Xu;S;N|1;1S;1N|2;2S;2N|3;3S;3N|4;4S;4N|5;5S;5N|6;6S;6N']
 ]);
 add(M,9,'★ Nâng cao: Đường tròn ngoại tiếp và đường tròn nội tiếp',[
  [1,'Tam giác ABC trong hình vuông tại A (hình không vẽ đúng tỉ lệ). Bán kính đường tròn ngoại tiếp tam giác ABC bằng?','5 cm','10 cm','4 cm','3 cm','@img:tgl:A:B:C:AB=6 cm:BC=10 cm:CA=8 cm'],
  [2,'Tam giác ABC trong hình là tam giác đều cạnh 6 cm. Bán kính đường tròn ngoại tiếp tam giác bằng?','2√3 cm','√3 cm','3√3 cm','3 cm','@img:tgl:A:B:C:AB=6 cm:BC=6 cm:CA=6 cm'],
  [3,'Tam giác ABC trong hình là tam giác đều cạnh 6 cm. Tính bán kính đường tròn nội tiếp và đường tròn ngoại tiếp của tam giác; hai đường tròn này có tâm ở đâu?','Với tam giác đều cạnh a: R = a√3/3, r = a√3/6. Với a = 6: R = 6√3/3 = 2√3 (cm), r = 6√3/6 = √3 (cm). Hai đường tròn có cùng tâm là trọng tâm (cũng là trực tâm, giao điểm ba đường trung trực, ba đường phân giác) của tam giác đều.','@img:tgl:A:B:C:AB=6 cm:BC=6 cm:CA=6 cm'],
  [4,'Tam giác ABC trong hình vuông tại A có AB = 3 cm, AC = 4 cm (hình không vẽ đúng tỉ lệ). Tính bán kính đường tròn ngoại tiếp R và bán kính đường tròn nội tiếp r. Giải thích vì sao r = (AB + AC − BC)/2.','BC = 5 cm. Tâm đường tròn ngoại tiếp tam giác vuông là trung điểm cạnh huyền nên R = BC/2 = 2,5 cm. Gọi I là tâm nội tiếp, các tiếp điểm trên AB, AC, BC lần lượt là D, E, F; tứ giác ADIE là hình vuông cạnh r (hai góc vuông tại D, E và góc A vuông, ID = IE = r). Hai tiếp tuyến kẻ từ một điểm bằng nhau: BD = BF, CE = CF nên BC = BD + CE = (AB − r) + (AC − r), suy ra r = (AB + AC − BC)/2 = (3 + 4 − 5)/2 = 1 (cm).','@img:tgl:A:B:C:AB=3 cm:CA=4 cm']
 ]);
 add(M,9,'★ Nâng cao: Một số hình khối trong thực tiễn',[
  [1,'Hình trụ trong hình có bán kính đáy 3 cm và chiều cao 5 cm. Thể tích của hình trụ bằng?','45π cm³','15π cm³','30π cm³','90π cm³','@img:hinh3d:tru'],
  [2,'Hình nón trong hình có bán kính đáy 3 cm và chiều cao 4 cm. Diện tích xung quanh của hình nón bằng?','15π cm²','12π cm²','20π cm²','9π cm²','@img:hinh3d:non'],
  [2,'Hình cầu trong hình có bán kính 3 cm. Thể tích của hình cầu bằng?','36π cm³','27π cm³','12π cm³','108π cm³','@img:hinh3d:cau'],
  [3,'Hình trụ trong hình có bán kính đáy 4 cm và chiều cao 10 cm. Tính diện tích xung quanh và thể tích của hình trụ (lấy π ≈ 3,14).','Sxq = 2πrh = 2π × 4 × 10 = 80π ≈ 251,2 (cm²). V = πr²h = π × 16 × 10 = 160π ≈ 502,4 (cm³).','@img:hinh3d:tru'],
  [4,'Hình nón trong hình có bán kính đáy 6 cm và chiều cao 8 cm. Tính độ dài đường sinh, diện tích xung quanh và thể tích hình nón. So sánh thể tích đó với thể tích hình trụ có cùng bán kính đáy và cùng chiều cao, giải thích.','Đường sinh l = √(6² + 8²) = 10 (cm). Sxq = πrl = π × 6 × 10 = 60π (cm²). V = (1/3)πr²h = (1/3) × π × 36 × 8 = 96π (cm³). Hình trụ cùng đáy, cùng chiều cao có V = πr²h = 288π (cm³), gấp 3 lần thể tích hình nón, đúng với công thức thể tích hình nón bằng 1/3 thể tích hình trụ cùng đáy và chiều cao.','@img:hinh3d:non']
 ]);
})();
