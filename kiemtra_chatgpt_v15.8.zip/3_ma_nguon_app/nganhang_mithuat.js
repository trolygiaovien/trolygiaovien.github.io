/* NGÂN HÀNG MĨ THUẬT – LỚP 1–9 — bổ sung đủ chuẩn. Câu hỏi nguyên bản, bám SGK Kết nối tri thức. */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Mĩ thuật';

 /* ===== LỚP 1 ===== */
 add(M,1,'Đồ dùng và sản phẩm mĩ thuật',[
  [1,'Khi vẽ phác hình trước lúc tô màu, em thường dùng dụng cụ nào?','Bút chì','Kéo','Hồ dán','Đất nặn'],
  [1,'Dụng cụ nào dùng để cắt giấy màu trong giờ Mĩ thuật?','Kéo','Bút sáp màu','Bút chì','Tẩy'],
  [1,'Em dùng vật gì để gắn các mảnh giấy màu lên nền giấy?','Hồ dán hoặc băng dính','Thước kẻ','Bút chì','Kéo'],
  [1,'Khi vẽ sai một nét bằng bút chì, em dùng dụng cụ nào để xóa?','Tẩy','Hồ dán','Bút sáp','Kéo'],
  [2,'Sản phẩm nào sau đây là sản phẩm mĩ thuật được tạo từ đất nặn?','Con vật nặn bằng đất','Bức tranh vẽ bằng bút sáp','Bài hát về mùa xuân','Bài tập đếm số'],
  [2,'Sau giờ học Mĩ thuật, em nên làm gì với đồ dùng của mình?','Lau sạch, cất gọn vào hộp đúng chỗ','Để nguyên trên bàn','Vứt vào thùng rác','Cho hết vào cặp của bạn'],
  [2,'Khi dùng kéo, em cần chú ý điều gì để an toàn?','Cầm kéo đúng cách, không hướng mũi kéo về phía người khác','Chạy nhảy khi cầm kéo','Đưa mũi kéo cho bạn cầm','Cắt khi không nhìn vào giấy'],
  [3,'Kể tên ít nhất bốn đồ dùng em cần chuẩn bị cho giờ học Mĩ thuật lớp 1.','Ví dụ: giấy vẽ, bút chì, tẩy, bút sáp màu (hoặc bút chì màu), giấy màu, kéo, hồ dán, đất nặn.'],
  [3,'Nêu cách cầm bút sáp màu và cách tô màu để mảng màu được đều, đẹp.','Cầm bút vừa tay, không quá chặt; tô theo một chiều, nét liền nhau, tô kín mảng hình và không tô ra ngoài nét vẽ.'],
  [3,'Em hãy kể tên hai sản phẩm mĩ thuật có thể thấy trong lớp học và cho biết chúng được làm bằng gì.','Ví dụ: tranh vẽ treo trên tường (làm bằng giấy, màu vẽ); đồ vật trang trí bằng giấy màu (làm bằng giấy, hồ dán); con vật nặn bằng đất nặn.'],
  [4,'Vì sao sau khi học xong em cần rửa tay, dọn dẹp và cất đồ dùng mĩ thuật đúng nơi? Hãy giải thích.','Đồ dùng như màu, hồ dán, đất nặn có thể làm bẩn tay, bàn, quần áo và sách vở; rửa tay giúp giữ vệ sinh, cất gọn giúp đồ dùng không bị mất, không hỏng và lần sau dễ tìm. Giữ lớp học sạch sẽ còn thể hiện ý thức giữ gìn của chung và tôn trọng bạn bè.']
 ]);
 add(M,1,'Màu sắc',[
  [1,'Trong ba màu cơ bản, màu nào là màu nền của lá cờ Tổ quốc Việt Nam?','Đỏ','Lam','Tím','Xanh lá'],
  [1,'Màu của bầu trời trong xanh ban ngày gần với màu cơ bản nào?','Lam','Đỏ','Cam','Nâu'],
  [1,'Quả cà chua chín thường có màu gì?','Đỏ','Xanh lam','Tím','Trắng'],
  [1,'Mặt trời trong tranh của các bạn nhỏ thường được tô màu gì?','Vàng hoặc đỏ cam','Đen','Xanh lam','Xám'],
  [2,'Vì sao ba màu đỏ, vàng, lam được gọi là màu cơ bản?','Vì không pha được từ các màu khác, nhưng từ chúng có thể pha ra nhiều màu mới','Vì chúng là ba màu đẹp nhất','Vì chúng chỉ có trong hộp bút sáp','Vì chúng đều là màu tối'],
  [2,'Khi tô một bức tranh bằng nhiều màu khác nhau, bức tranh sẽ như thế nào?','Vui tươi, sinh động hơn','Chỉ còn một màu','Bị mờ đi','Không nhìn thấy hình'],
  [3,'Kể tên ba màu cơ bản và mỗi màu nêu một đồ vật hoặc sự vật có màu đó.','Đỏ: quả cà chua chín, lá cờ; vàng: quả chuối chín, hoa hướng dương; lam: bầu trời, nước biển.'],
  [3,'Em muốn tô một bức tranh về vườn hoa. Em sẽ dùng những màu nào cho hoa, lá và bầu trời?','Hoa: đỏ, vàng, hồng, cam...; lá: xanh lá; bầu trời: xanh lam nhạt. Chọn màu tươi sáng để vườn hoa rực rỡ.'],
  [3,'Nêu một cách tạo ra màu mới từ hai màu cơ bản mà em biết.','Ví dụ: tô màu vàng rồi tô chồng màu đỏ lên sẽ được màu cam; vàng chồng lam được xanh lá; đỏ chồng lam được tím.'],
  [4,'Vì sao khi vẽ tranh về biển, em nên dùng nhiều màu lam, còn khi vẽ mặt trời buổi sáng nên dùng màu vàng, cam? Hãy giải thích.','Màu sắc giúp người xem nhận ra sự vật: biển và trời thường có màu lam nên tô lam sẽ giống thật và tạo cảm giác mát mẻ, rộng lớn; mặt trời tỏa sáng, ấm áp nên dùng vàng, cam tạo cảm giác rực rỡ, ấm nóng. Chọn màu đúng với cảm nhận giúp bức tranh đẹp và dễ hiểu hơn.']
 ]);
 add(M,1,'Chấm, nét, hình, mảng',[
  [1,'Khi chấm đầu bút màu lên giấy nhiều lần, em tạo ra yếu tố tạo hình nào?','Chấm','Khối','Mảng lớn','Chữ'],
  [1,'Nét nào sau đây là nét thẳng?','Cạnh của chiếc thước kẻ','Vành của chiếc nón','Sóng biển','Đuôi của con ốc'],
  [1,'Hình nào trong các hình sau là hình cơ bản?','Hình tròn','Hình con mèo','Hình ngôi nhà','Hình chiếc xe'],
  [1,'Bánh xe của chiếc xe đạp giống với hình cơ bản nào?','Hình tròn','Hình vuông','Hình tam giác','Hình chữ nhật'],
  [2,'Khi tô kín một hình bằng một màu, phần được tô gọi là gì?','Mảng màu','Nét','Chấm','Khối'],
  [2,'Mái nhà trong tranh của em thường được vẽ bằng hình cơ bản nào?','Hình tam giác','Hình tròn','Hình trái tim','Hình ngôi sao'],
  [2,'Để vẽ sóng nước hoặc dòng sông uốn lượn, em nên dùng loại nét nào?','Nét cong lượn sóng','Nét thẳng đứng','Chấm nhỏ','Nét gấp khúc'],
  [3,'Kể tên bốn hình cơ bản và mỗi hình nêu một đồ vật có dạng giống hình đó.','Hình vuông: viên gạch lát; hình tròn: quả bóng, mặt trời; hình tam giác: mái nhà, miếng bánh; hình chữ nhật: cửa sổ, quyển sách.'],
  [3,'Nêu cách tạo một bức tranh đơn giản chỉ bằng các chấm màu.','Chọn hình cần vẽ, dùng đầu bút màu hoặc tăm bông chấm các chấm sát nhau theo hình; chấm màu khác cho nền; chấm to, nhỏ, đậm, nhạt khác nhau để tranh sinh động.'],
  [3,'Em hãy kể các loại nét em biết và cho biết mỗi loại nét có thể dùng để vẽ gì.','Nét thẳng: thân cây, cột nhà; nét cong: cầu vồng, quả bóng; nét gấp khúc: ngọn núi, tia sét; nét lượn sóng: sóng biển, mây; nét xoắn ốc: vỏ ốc.'],
  [4,'Vì sao từ các hình cơ bản như tròn, vuông, tam giác, chữ nhật em có thể ghép thành nhiều đồ vật, con vật khác nhau? Nêu một ví dụ.','Vì hầu hết đồ vật, con vật đều có các bộ phận gần giống các hình cơ bản; khi ghép, thay đổi kích cỡ và vị trí các hình, em tạo được hình mới. Ví dụ: hình vuông làm thân nhà, hình tam giác làm mái, hình chữ nhật nhỏ làm cửa; hoặc hình tròn làm đầu và thân con gà, hình tam giác làm mỏ.']
 ]);
 add(M,1,'Quan sát và cảm nhận',[
  [1,'Trước khi vẽ một đồ vật, việc đầu tiên em nên làm là gì?','Quan sát kĩ hình dáng, màu sắc của đồ vật','Tô màu ngay','Cắt giấy','Cất đồ vật đi'],
  [1,'Khi vẽ chân dung người thân, những bộ phận nào em cần vẽ trên khuôn mặt?','Mắt, mũi, miệng','Bánh xe','Lá cây','Cánh cửa'],
  [1,'Khi xem tranh của bạn, em nên có thái độ như thế nào?','Chăm chú xem, nhận xét nhẹ nhàng và tôn trọng','Chê bai thật to','Vẽ thêm vào tranh của bạn','Không cần xem'],
  [2,'Trong bức tranh về gia đình, hình ảnh nào là hình ảnh chính?','Các thành viên trong gia đình','Đám mây trên trời','Hàng rào','Chú chim bay xa'],
  [2,'Em vẽ con cá nhưng bạn nói trông giống con gà. Em nên làm gì?','Quan sát lại con cá thật hoặc tranh ảnh để vẽ rõ đặc điểm hơn','Bỏ không vẽ nữa','Cãi với bạn','Xé bức tranh'],
  [2,'Quan sát một chiếc lá, em có thể nhận ra điều gì về hình dáng của nó?','Lá có nhiều hình dáng khác nhau như dài, tròn, răng cưa','Tất cả các lá đều giống nhau','Lá luôn có màu đỏ','Lá luôn hình vuông'],
  [3,'Khi giới thiệu sản phẩm mĩ thuật của mình với các bạn, em cần nói những gì?','Nói tên sản phẩm, vẽ hoặc làm về gì, dùng màu và chất liệu nào, em thích điều gì nhất ở sản phẩm.'],
  [3,'Em thích con vật nào nhất? Hãy nêu đặc điểm nổi bật của con vật đó mà em sẽ vẽ.','Ví dụ: con mèo có hai tai hình tam giác nhỏ, râu dài, đuôi dài cong; con thỏ có hai tai dài dựng đứng, lông trắng; HS nêu đúng đặc điểm riêng.'],
  [3,'Nêu các bước để vẽ bức tranh về chủ đề em yêu thích.','Chọn chủ đề; nhớ lại hoặc quan sát hình ảnh; vẽ hình chính to ở giữa, thêm hình phụ; tô màu hình chính nổi bật rồi tô nền; hoàn thiện và chia sẻ.'],
  [4,'Vì sao hai bạn cùng vẽ một con mèo mà hai bức tranh lại khác nhau? Theo em điều đó có đáng chê không? Giải thích.','Vì mỗi bạn quan sát, cảm nhận và tưởng tượng khác nhau nên chọn hình dáng, màu sắc, cách thể hiện khác nhau. Điều đó không đáng chê mà rất đáng quý, vì trong mĩ thuật sự khác biệt thể hiện sáng tạo riêng của mỗi người; ta nên tôn trọng và học hỏi cái hay của bạn.']
 ]);

 /* ===== LỚP 2 ===== */
 add(M,2,'Đồ dùng và sản phẩm mĩ thuật',[
  [1,'Loại màu nào cần pha với nước và dùng cọ để vẽ?','Màu nước','Bút chì đen','Bút sáp màu','Phấn viết bảng'],
  [1,'Để tạo sản phẩm bằng giấy màu, em có thể dùng những cách nào?','Gấp, cắt, xé, dán','Nấu, luộc','Đóng đinh','Khâu vá'],
  [1,'Khi dùng màu nước, em dùng vật gì để pha màu và rửa cọ?','Khay pha màu và cốc nước','Hộp bút chì','Thước kẻ','Hộp đất nặn'],
  [1,'Vật liệu nào sau đây có thể tận dụng để làm sản phẩm mĩ thuật?','Vỏ hộp sữa, lõi giấy vệ sinh, nắp chai','Dao sắc','Pin đã hỏng','Thuốc'],
  [2,'Sản phẩm mĩ thuật trong cuộc sống xuất hiện ở đâu?','Ở nhiều nơi: tranh treo, đồ chơi, quần áo, bao bì, đồ trang trí','Chỉ ở trong phòng tranh','Chỉ ở trong sách Mĩ thuật','Chỉ ở trên bảng lớp'],
  [2,'Khác với bút sáp màu, màu nước có đặc điểm gì?','Loang, trong và nhạt dần khi pha thêm nước','Không bao giờ khô','Chỉ có một màu đen','Không tô được trên giấy'],
  [2,'Vì sao nên dùng giấy dày hơn khi vẽ bằng màu nước?','Vì giấy mỏng dễ bị nhăn và rách khi ướt','Vì giấy dày đẹp hơn','Vì giấy mỏng không có màu trắng','Vì giấy dày dễ cắt hơn'],
  [3,'Nêu các bước làm một sản phẩm trang trí từ lõi giấy vệ sinh.','Rửa sạch và để khô lõi giấy; nghĩ ý tưởng (con vật, ống đựng bút...); vẽ hoặc dán giấy màu bên ngoài; thêm mắt, tai, hoa văn; hoàn thiện và giới thiệu.'],
  [3,'Em hãy phân biệt cách sử dụng bút sáp màu và màu nước.','Bút sáp: cầm tô trực tiếp, tô kín mảng, có thể chồng màu; màu nước: lấy cọ chấm màu, pha với nước trong khay, vẽ lên giấy, muốn nhạt thì thêm nước, rửa cọ khi đổi màu.'],
  [3,'Kể tên ba sản phẩm mĩ thuật em thấy trong cuộc sống hằng ngày và cho biết công dụng của chúng.','Ví dụ: bìa sách được trang trí để đẹp và thu hút; áo có họa tiết để mặc đẹp; đèn lồng để trang trí ngày lễ; tranh treo tường để làm đẹp nhà.'],
  [4,'Vì sao việc tận dụng vật liệu đã qua sử dụng để làm sản phẩm mĩ thuật vừa có ích vừa có ý nghĩa? Hãy giải thích.','Vật liệu bỏ đi như vỏ hộp, chai nhựa, giấy báo nếu được tái sử dụng sẽ giảm rác thải, bảo vệ môi trường và tiết kiệm tiền mua vật liệu mới. Đồng thời, việc biến đồ cũ thành sản phẩm đẹp, có ích rèn cho em sự khéo léo, óc sáng tạo và thói quen sống tiết kiệm.']
 ]);
 add(M,2,'Màu sắc',[
  [1,'Màu cam được tạo ra khi pha hai màu cơ bản nào?','Đỏ và vàng','Đỏ và lam','Vàng và lam','Đỏ và đen'],
  [1,'Pha màu vàng với màu lam ta được màu gì?','Xanh lục (xanh lá cây)','Cam','Tím','Hồng'],
  [1,'Pha màu đỏ với màu lam ta được màu gì?','Tím','Cam','Xanh lục','Vàng'],
  [1,'Màu cam, lục, tím được gọi chung là gì?','Màu thứ cấp (màu được pha từ hai màu cơ bản)','Màu cơ bản','Màu đen trắng','Màu kim loại'],
  [2,'Muốn có màu đỏ nhạt hơn (màu hồng), em pha thêm màu gì?','Màu trắng','Màu đen','Màu lam','Màu xanh lục'],
  [2,'Trong hai màu xanh lam đậm và xanh lam nhạt, màu nào trông tối hơn?','Xanh lam đậm','Xanh lam nhạt','Hai màu tối bằng nhau','Không màu nào tối'],
  [2,'Khi vẽ bằng màu nước, muốn màu nhạt hơn em làm thế nào?','Pha thêm nước','Thêm màu đen','Tô nhiều lớp','Để màu khô rồi tô lại'],
  [3,'Nêu cách pha ba màu thứ cấp từ ba màu cơ bản.','Đỏ pha vàng được cam; vàng pha lam được xanh lục; đỏ pha lam được tím. Lượng mỗi màu khác nhau sẽ cho sắc cam, lục, tím khác nhau.'],
  [3,'Thế nào là màu đậm, màu nhạt? Cho ví dụ.','Màu đậm là màu tối, mạnh (như đỏ đậm, lam đậm); màu nhạt là màu sáng, nhẹ (như hồng, lam nhạt). Pha thêm trắng hoặc nước được màu nhạt, thêm đen hoặc tô dày được màu đậm.'],
  [3,'Em vẽ bức tranh về khu rừng. Em sẽ dùng màu đậm, nhạt như thế nào để tranh có cây gần, cây xa?','Cây ở gần tô màu xanh đậm, rõ; cây ở xa tô xanh nhạt hơn, mờ hơn; như vậy tranh có cảm giác xa gần và sinh động.'],
  [4,'Vì sao trong một bức tranh cần có cả màu đậm và màu nhạt? Nếu chỉ dùng toàn màu đậm thì tranh sẽ ra sao?','Màu đậm và nhạt đặt cạnh nhau làm hình ảnh nổi rõ, tạo cảm giác sáng tối, gần xa và làm tranh có nhịp điệu. Nếu chỉ toàn màu đậm, các hình sẽ lẫn vào nhau, tranh nặng nề, tối và khó nhận ra hình chính; ngược lại chỉ toàn màu nhạt thì tranh mờ, thiếu điểm nhấn.']
 ]);
 add(M,2,'Chấm, nét, hình, mảng',[
  [1,'Nét đậm được tạo ra khi em vẽ như thế nào?','Ấn bút mạnh hoặc tô nét to, dày','Vẽ nhẹ tay','Vẽ bằng tẩy','Không chạm bút vào giấy'],
  [1,'Những chấm to, nhỏ, dày, thưa sắp xếp cạnh nhau có thể tạo ra điều gì trong tranh?','Hình ảnh và cảm giác đậm nhạt khác nhau','Âm thanh','Mùi hương','Chữ viết'],
  [1,'Hình dáng con cá thường được tạo từ những hình cơ bản nào?','Hình bầu dục làm thân và hình tam giác làm đuôi','Hình vuông và hình chữ nhật','Chỉ hình vuông','Chỉ hình tam giác'],
  [1,'Mảng hình trong tranh là gì?','Phần diện tích có hình dạng và màu sắc nhất định trên mặt tranh','Một chấm nhỏ','Một đường kẻ','Khung tranh'],
  [2,'Khi vẽ con vật, bạn Lan vẽ thân to ở giữa rồi thêm đầu, chân, đuôi. Bạn Lan đã dùng cách nào?','Ghép các hình cơ bản để tạo hình con vật','Chỉ dùng chấm','Chỉ dùng một nét thẳng','Cắt giấy ngẫu nhiên'],
  [2,'Xé giấy màu thành các mảng rồi dán thành bức tranh gọi là cách gì?','Xé dán','Vẽ nét','Nặn đất','In tranh'],
  [2,'Sắp xếp các nét cong, nét thẳng lặp lại đều đặn trên viền một đồ vật nhằm mục đích gì?','Trang trí cho đồ vật đẹp hơn','Làm đồ vật nặng hơn','Che hết đồ vật','Làm đồ vật bị rách'],
  [3,'Nêu cách tạo bức tranh xé dán về chủ đề con vật.','Chọn con vật; chọn giấy màu phù hợp; xé giấy thành các mảng to cho thân, mảng nhỏ cho đầu, chân, đuôi; sắp xếp lên nền rồi dán; thêm chi tiết mắt, miệng bằng bút màu.'],
  [3,'So sánh nét to và nét nhỏ, nét đậm và nét nhạt khi vẽ. Chúng được dùng để làm gì?','Nét to, đậm dùng vẽ hình chính, viền ngoài để hình nổi rõ; nét nhỏ, nhạt dùng vẽ chi tiết, hình phụ, hình ở xa. Kết hợp các loại nét làm tranh sinh động, có chính phụ.'],
  [3,'Em hãy nêu cách sử dụng chấm để trang trí một chiếc túi giấy.','Vẽ hoặc chọn hình cần trang trí trên túi; dùng tăm bông, đầu bút hoặc ngón tay chấm màu theo hình, chấm đều hoặc xen kẽ to nhỏ, màu khác nhau; để khô rồi hoàn thiện.'],
  [4,'Vì sao kết hợp chấm, nét, hình và mảng trong cùng một bức tranh lại làm tranh đẹp và sinh động hơn so với chỉ dùng một yếu tố? Hãy giải thích.','Mỗi yếu tố có vai trò riêng: mảng tạo hình lớn và màu nền, nét làm rõ hình và chi tiết, chấm tạo điểm nhấn và họa tiết, hình giúp nhận ra sự vật. Khi kết hợp, tranh có sự phong phú về to nhỏ, đậm nhạt, có chính phụ nên hấp dẫn; chỉ dùng một yếu tố thì tranh đơn điệu, thiếu chi tiết và điểm nhấn.']
 ]);
 add(M,2,'Quan sát và cảm nhận',[
  [1,'Khi vẽ tranh về các con vật dưới nước, em nên vẽ con vật nào?','Cá, tôm, cua, sao biển','Gà, vịt, ngan','Hổ, báo, sư tử','Chim sẻ, chim bồ câu'],
  [1,'Khi xem một bức tranh, em nhận ra hình chính nhờ điều gì?','Hình được vẽ to, rõ, ở vị trí nổi bật và màu nổi hơn','Hình được vẽ nhỏ ở góc tranh','Hình bị tô mờ','Hình nằm ngoài khung tranh'],
  [1,'Khi sắp xếp hình ảnh trong tranh, hình chính nên đặt ở đâu?','Ở khoảng giữa tranh, không quá sát mép','Ở sát mép trên','Ở ngoài tờ giấy','Chồng lên tất cả các hình khác'],
  [2,'Em vẽ cảnh đường phố và muốn thể hiện nhà ở xa. Em nên vẽ nhà ở xa thế nào?','Nhỏ hơn và đặt cao hơn so với nhà ở gần','To hơn nhà ở gần','Màu đậm hơn hẳn','Ở sát mép dưới tranh'],
  [2,'Bạn Minh nhận xét tranh của bạn Hoa: "Màu sắc tươi sáng, hình con mèo rất rõ". Bạn Minh đã làm gì?','Nêu cảm nhận và điều em thích ở sản phẩm của bạn','Chê bai sản phẩm của bạn','Sửa tranh của bạn','Không quan tâm đến tranh của bạn'],
  [2,'Khi quan sát một chiếc cốc để vẽ, em cần chú ý điều gì?','Hình dáng, tỉ lệ cao thấp, tay cầm, màu sắc và hoa văn','Giá tiền của chiếc cốc','Người mua cốc','Tên cửa hàng bán cốc'],
  [3,'Nêu cảm nhận của em về một bức tranh có nhiều màu đỏ, cam, vàng.','Bức tranh gợi cảm giác ấm áp, vui tươi, rực rỡ, sôi động, giống như ánh nắng hoặc ngọn lửa.'],
  [3,'Em sẽ chọn những hình ảnh nào để vẽ tranh về chủ đề "Ngôi nhà của em"? Hình nào là hình chính?','Hình chính: ngôi nhà với mái, cửa, tường; hình phụ: cây, hàng rào, con đường, người thân, mặt trời, mây. Nhà vẽ to ở giữa, hình phụ nhỏ hơn xung quanh.'],
  [3,'Để giới thiệu bức tranh của mình trước lớp, em cần chuẩn bị nói những gì?','Tên tranh và chủ đề; hình ảnh chính, hình ảnh phụ; màu sắc đã dùng và vì sao chọn; điều em thích hoặc muốn làm tốt hơn.'],
  [4,'Vì sao khi vẽ tranh ta nên vẽ hình chính to, rõ ở giữa và hình phụ nhỏ hơn ở xung quanh? Nếu vẽ tất cả đều to bằng nhau thì sao?','Hình chính to, rõ, ở giữa giúp người xem nhận ra ngay nội dung tranh muốn kể; hình phụ nhỏ hơn làm cho tranh đầy đủ, sinh động mà không lấn át hình chính. Nếu mọi hình đều to bằng nhau, tranh sẽ rối, dàn đều, không biết đâu là nội dung chính và kém hấp dẫn.']
 ]);

 /* ===== LỚP 3 ===== */
 add(M,3,'Màu sắc và đậm nhạt',[
  [1,'Nhóm màu nào sau đây gồm toàn màu nóng?','Đỏ, cam, vàng','Lam, lục, tím','Đen, trắng, xám','Lam, hồng, lục'],
  [1,'Nhóm màu nào sau đây gồm toàn màu lạnh?','Lam, lục, tím','Đỏ, cam, vàng','Đỏ, vàng, trắng','Cam, hồng, nâu'],
  [1,'Màu nóng thường gợi cảm giác gì cho người xem?','Ấm áp, sôi động, rực rỡ','Lạnh lẽo, yên tĩnh','Buồn tẻ, u ám','Không gợi cảm giác gì'],
  [1,'Màu lạnh thường gợi cảm giác gì?','Mát mẻ, dịu nhẹ, yên tĩnh','Nóng bức, sôi động','Rực rỡ, chói chang','Cay nồng'],
  [2,'Để tạo độ đậm nhạt khi vẽ bằng bút chì, em làm thế nào?','Thay đổi lực ấn tay và số lớp nét chồng lên nhau','Dùng nhiều cục tẩy','Vẽ thật nhanh','Chỉ dùng thước kẻ'],
  [2,'Khi vẽ bức tranh về mùa hè nắng nóng, em nên chọn gam màu nào làm chủ đạo?','Gam màu nóng','Gam màu lạnh','Toàn màu đen','Toàn màu xám'],
  [2,'Một mảng màu đỏ đặt cạnh mảng màu xanh lam sẽ tạo cảm giác gì?','Tương phản nóng lạnh, hai màu tôn nhau nổi bật','Hai màu lẫn vào nhau','Cả hai đều mờ đi','Giống như một màu'],
  [3,'Phân biệt màu nóng và màu lạnh. Kể tên mỗi nhóm ba màu.','Màu nóng gợi cảm giác ấm, nóng như màu lửa, mặt trời: đỏ, cam, vàng. Màu lạnh gợi cảm giác mát, lạnh như nước, cây cỏ: lam, lục, tím.'],
  [3,'Nêu ba độ đậm nhạt cơ bản của một màu và cách tạo ra chúng khi vẽ bằng màu sáp.','Đậm, trung gian (vừa), nhạt. Màu sáp: tô nhẹ tay hoặc tô thưa được nhạt, tô vừa được trung gian, tô mạnh tay nhiều lớp được đậm; có thể chồng thêm màu tối để đậm hơn.'],
  [3,'Em vẽ tranh "Đêm trung thu rước đèn". Em sẽ dùng màu nóng, màu lạnh ở những chỗ nào?','Bầu trời đêm dùng màu lạnh (lam đậm, tím); đèn lồng, ánh nến, trang phục dùng màu nóng (đỏ, cam, vàng) để nổi bật, rực rỡ trên nền tối.'],
  [4,'Vì sao các họa sĩ thường kết hợp cả màu nóng và màu lạnh trong một bức tranh thay vì chỉ dùng một nhóm? Hãy phân tích.','Màu nóng và lạnh đặt cạnh nhau tạo sự tương phản, làm hình chính nổi bật và tranh có sức hút. Nếu chỉ toàn màu nóng, tranh chói, gắt, gây mỏi mắt; chỉ toàn màu lạnh thì tranh dễ buồn, lạnh lẽo. Kết hợp hợp lí (một nhóm chủ đạo, nhóm kia làm điểm nhấn) giúp tranh hài hòa, có nhịp điệu và thể hiện đúng cảm xúc muốn gửi gắm.']
 ]);
 add(M,3,'Mĩ thuật dân gian và thường thức',[
  [1,'Tranh dân gian Đông Hồ được in bằng cách nào?','In từ các bản khắc gỗ','Vẽ trực tiếp bằng bút lông','In bằng máy in hiện đại','Vẽ bằng bút sáp màu'],
  [1,'Màu sắc trong tranh Đông Hồ truyền thống được lấy từ đâu?','Từ vật liệu tự nhiên như than lá tre, hoa hòe, sỏi son, vỏ điệp','Từ sơn công nghiệp','Từ màu nước đóng tuýp','Từ bút sáp màu'],
  [1,'Tranh dân gian thường được treo trong nhà vào dịp nào?','Tết Nguyên đán','Ngày khai giảng','Ngày Quốc tế Thiếu nhi','Ngày thi học kì'],
  [1,'Đề tài nào thường gặp trong tranh dân gian Đông Hồ?','Con vật gần gũi, sinh hoạt làng quê, chúc tụng','Tàu vũ trụ','Thành phố hiện đại','Máy tính và điện thoại'],
  [2,'Vì sao tranh dân gian Đông Hồ có thể làm ra nhiều bức giống nhau?','Vì tranh được in từ bản khắc, mỗi màu một bản, in nhiều lần','Vì nghệ nhân vẽ lại rất nhanh','Vì dùng máy photocopy','Vì tranh được chụp ảnh'],
  [2,'Hình ảnh trong tranh dân gian thường được thể hiện như thế nào?','Đơn giản, mảng màu phẳng, đường nét rõ ràng','Rất nhiều chi tiết nhỏ như ảnh chụp','Chỉ có màu đen trắng','Vẽ theo luật xa gần như ảnh'],
  [3,'Kể tên hai dòng tranh dân gian nổi tiếng của Việt Nam và cho biết chúng ở địa phương nào.','Tranh Đông Hồ ở Bắc Ninh; tranh Hàng Trống ở Hà Nội. Ngoài ra còn tranh Kim Hoàng (Hà Nội), tranh làng Sình (Huế).'],
  [3,'Nêu các bước chính để in một bức tranh Đông Hồ.','Khắc hình lên ván gỗ (ván nét và các ván màu); quét màu lên ván; đặt giấy dó quét điệp lên ván và in; in lần lượt từng màu rồi in nét đen sau cùng; phơi khô.'],
  [3,'Em có thể tạo một bức tranh theo cách in đơn giản ở lớp bằng cách nào?','Khắc hoặc dán hình nổi lên miếng xốp, củ quả, bìa cứng; quét màu lên hình nổi; úp lên giấy và ấn đều; nhấc ra để được hình in; có thể in lặp lại nhiều lần.'],
  [4,'Vì sao tranh dân gian Đông Hồ được coi là di sản văn hóa quý cần giữ gìn? Em có thể làm gì để góp phần giữ gìn?','Tranh Đông Hồ có kĩ thuật in khắc gỗ độc đáo, màu tự nhiên, đề tài phản ánh đời sống và ước mơ của người dân Việt Nam từ nhiều đời, là nét văn hóa riêng của dân tộc. Em có thể tìm hiểu, giới thiệu tranh với bạn bè, học cách in tranh đơn giản, trân trọng và sử dụng tranh dân gian trong trang trí.']
 ]);
 add(M,3,'Tạo hình và thủ công',[
  [1,'Khối cầu có đặc điểm gì?','Tròn đều mọi phía, giống quả bóng','Có sáu mặt phẳng','Có một đỉnh nhọn','Dẹt như tờ giấy'],
  [1,'Khối trụ thường thấy ở đồ vật nào sau đây?','Lon nước ngọt, lõi giấy','Quả bóng','Hộp bánh hình vuông','Chiếc nón'],
  [1,'Khi nặn một con vật bằng đất nặn, thao tác lăn tròn đất giữa hai lòng bàn tay tạo ra khối gì?','Khối cầu','Khối hộp','Khối chóp','Khối trụ dài'],
  [1,'Để tạo khối trụ bằng đất nặn, em làm thế nào?','Lăn dài đất trên mặt bàn','Ấn dẹt đất','Vê tròn đất','Xé nhỏ đất'],
  [2,'Vì sao các đồ vật trong thực tế đều có khối?','Vì chúng có chiều dài, chiều rộng và chiều cao, chiếm chỗ trong không gian','Vì chúng đều có màu','Vì chúng đều được vẽ','Vì chúng đều rất nặng'],
  [2,'Khi làm mô hình ngôi nhà từ vỏ hộp, phần mái có thể được tạo bằng cách nào?','Gấp đôi tấm bìa thành hình mái (chữ V ngược) rồi đặt lên vỏ hộp','Dùng quả bóng','Đổ nước vào hộp','Bẻ gãy hộp'],
  [2,'Để các bộ phận nặn (đầu, chân, thân) gắn chắc với nhau, em cần làm gì?','Ấn nhẹ và miết chỗ nối cho liền','Chỉ đặt cạnh nhau','Thả rơi từ cao','Để ngoài nắng'],
  [3,'Kể tên các khối cơ bản và mỗi khối nêu một đồ vật có dạng khối đó.','Khối cầu: quả bóng, quả cam; khối trụ: lon nước, cây cột; khối hộp (lập phương, chữ nhật): hộp bánh, viên gạch; khối chóp hoặc nón: nón lá, kim tự tháp.'],
  [3,'Nêu các bước nặn một con vật bằng đất nặn.','Quan sát hình dáng con vật; chọn màu đất; nặn khối to cho thân, khối tròn cho đầu, lăn dài làm chân, đuôi; gắn các bộ phận và miết chỗ nối; thêm chi tiết mắt, mũi, tai; chỉnh sửa và hoàn thiện.'],
  [3,'Nêu các bước tạo một sản phẩm đồ chơi từ vật liệu tái chế như hộp giấy, nắp chai.','Thu gom, làm sạch vật liệu; nghĩ ý tưởng và phác thảo; cắt, gấp, ghép các bộ phận bằng hồ, băng dính; trang trí bằng màu, giấy màu; kiểm tra độ chắc và giới thiệu sản phẩm.'],
  [4,'Vì sao khi tạo hình con vật, nếu biết quy mỗi bộ phận về một khối cơ bản thì em sẽ nặn hoặc lắp ghép dễ hơn? Cho ví dụ cụ thể.','Vì khối cơ bản đơn giản, dễ tạo và dễ gắn kết; khi xem thân, đầu, chân là những khối cầu, trụ, hộp, em chỉ cần tạo từng khối với kích cỡ phù hợp rồi ghép lại theo đúng vị trí, tỉ lệ. Ví dụ: con gà gồm khối cầu to làm thân, khối cầu nhỏ làm đầu, khối chóp nhỏ làm mỏ, các khối trụ ngắn làm chân.']
 ]);
 add(M,3,'Quan sát và cảm nhận',[
  [1,'Trong tranh về lễ hội quê em, hình ảnh chính thường là gì?','Đoàn người tham gia lễ hội và hoạt động chính như rước, múa, đua thuyền','Một chiếc lá rơi','Bầu trời trống','Hàng rào ở góc tranh'],
  [1,'Khi vẽ tranh về bảo vệ môi trường, em có thể chọn hình ảnh nào?','Các bạn trồng cây, nhặt rác, chăm sóc cây xanh','Người đốt rác bừa bãi được ca ngợi','Xe chở rác xả khói là hình đẹp','Chặt cây làm nhà'],
  [1,'Bức tranh có đường nét mềm mại, màu sắc dịu nhẹ thường gợi cảm giác gì?','Yên bình, nhẹ nhàng','Dữ dội, căng thẳng','Ồn ào, hối hả','Sợ hãi'],
  [2,'Khi xem một sản phẩm mĩ thuật, em nên nhận xét về những điểm gì?','Nội dung, hình ảnh chính phụ, màu sắc, cách sắp xếp và cảm nhận của em','Giá tiền của sản phẩm','Cân nặng của sản phẩm','Tên cửa hàng bán giấy'],
  [2,'Trong tranh, các hình ảnh được vẽ to dần từ xa đến gần gọi là gì?','Thể hiện xa gần (gần to, xa nhỏ)','Tô màu đều','Vẽ chấm','Vẽ nét gấp khúc'],
  [2,'Khi quan sát một con vật để vẽ, em cần chú ý điều gì nhất?','Đặc điểm riêng về hình dáng, các bộ phận và tư thế','Tên người nuôi con vật','Món ăn con vật thích','Tuổi của con vật'],
  [3,'Nêu các bước thực hiện một bức tranh đề tài lễ hội quê em.','Chọn hoạt động lễ hội muốn vẽ; phác hình chính (người, hoạt động) ở giữa, hình phụ (cờ, cây, nhà) xung quanh; vẽ chi tiết; tô màu hình chính nổi bật, màu nền hài hòa; hoàn thiện.'],
  [3,'Khi quan sát một bức tranh phong cảnh, em cảm nhận được gì qua màu sắc và đường nét? Nêu ví dụ.','Màu lạnh, nét mềm gợi cảnh yên bình như đồng quê buổi sớm; màu nóng, nét mạnh gợi cảnh sôi động như hoàng hôn rực rỡ, lễ hội. Màu sắc và nét giúp người xem cảm nhận không khí, thời gian của cảnh.'],
  [3,'Em sẽ giới thiệu sản phẩm mô hình ngôi nhà của mình với bạn như thế nào?','Giới thiệu tên sản phẩm, vật liệu dùng (hộp, bìa, giấy màu), cách làm chính, các phần của ngôi nhà, điều em thích và điều muốn làm tốt hơn; mời bạn nhận xét.'],
  [4,'Vì sao cùng một đề tài "Bảo vệ môi trường" nhưng tranh của các bạn trong lớp lại rất khác nhau? Theo em, một bức tranh đề tài này được coi là tốt khi nào?','Vì mỗi bạn chọn một hoạt động, góc nhìn và cách thể hiện màu sắc, hình ảnh khác nhau theo trải nghiệm riêng. Tranh tốt là tranh có nội dung rõ, hình chính nổi bật, thể hiện được hành động bảo vệ môi trường, màu sắc hài hòa và mang cảm xúc, ý tưởng riêng của người vẽ chứ không phải sao chép.']
 ]);

 /* ===== LỚP 4 ===== */
 add(M,4,'Màu sắc và đậm nhạt',[
  [1,'Cặp màu nào sau đây là cặp màu bổ túc?','Đỏ và xanh lục','Đỏ và cam','Vàng và cam','Lam và tím'],
  [1,'Màu bổ túc của màu vàng là màu nào?','Tím','Cam','Xanh lục','Đỏ'],
  [1,'Màu bổ túc của màu lam là màu nào?','Cam','Tím','Xanh lục','Vàng'],
  [1,'Khi đặt hai màu bổ túc cạnh nhau, chúng có tác dụng gì?','Tôn nhau lên, cùng rực rỡ và nổi bật hơn','Làm nhau mờ đi','Hòa thành một màu','Chuyển sang màu đen'],
  [2,'Hòa sắc là gì?','Sự kết hợp các màu trong bài vẽ tạo nên vẻ hài hòa chung','Một màu duy nhất','Cách tô màu thật nhanh','Cách pha màu với nước'],
  [2,'Thế nào là độ đậm nhạt trung gian?','Độ sáng tối nằm giữa mức đậm nhất và nhạt nhất','Màu đậm nhất trong tranh','Màu trắng của giấy','Màu đen hoàn toàn'],
  [2,'Bài vẽ dùng chủ yếu các màu gần nhau như vàng, cam, đỏ tạo nên hòa sắc gì?','Hòa sắc nóng','Hòa sắc lạnh','Hòa sắc tương phản mạnh','Hòa sắc đen trắng'],
  [3,'Kể tên ba cặp màu bổ túc và nêu tác dụng của chúng trong tranh.','Đỏ – lục, vàng – tím, lam – cam. Khi đặt cạnh nhau, hai màu bổ túc làm nhau nổi bật, rực rỡ hơn; thường dùng để nhấn mạnh hình chính hoặc tạo điểm nhấn.'],
  [3,'Thế nào là vẽ có đậm nhạt? Nêu cách thể hiện đậm nhạt khi vẽ một quả bóng bằng màu.','Vẽ có đậm nhạt là thể hiện ba độ sáng, trung gian, tối của màu để hình có khối. Với quả bóng: chỗ hướng về nguồn sáng tô nhạt, phần giữa tô trung gian, phần khuất sáng tô đậm; bóng đổ dưới quả bóng tô đậm nhất.'],
  [3,'Em được giao vẽ tranh về đề tài "Ngày hội". Em sẽ chọn hòa sắc nào và dùng cặp màu bổ túc nào để tạo điểm nhấn?','Chọn hòa sắc nóng (đỏ, cam, vàng) tạo không khí vui tươi; dùng màu lục hoặc lam cho một số chi tiết như cờ, lá cây để tương phản với đỏ, làm hình chính nổi bật.'],
  [4,'Vì sao tranh có đậm nhạt rõ ràng lại đẹp và có chiều sâu hơn tranh tô màu phẳng đều? Phân tích vai trò của đậm nhạt.','Đậm nhạt mô tả ánh sáng chiếu lên vật, làm hình có khối, có chỗ sáng chỗ tối nên giống thật và có chiều sâu; đậm nhạt còn phân biệt chính phụ: hình chính tương phản mạnh, hình phụ nhẹ hơn, xa thì nhạt mờ. Tranh tô phẳng đều không có sáng tối nên dẹt, các hình dễ lẫn vào nhau và thiếu điểm nhấn.']
 ]);
 add(M,4,'Mĩ thuật dân gian và thường thức',[
  [1,'Tranh dân gian Hàng Trống có nguồn gốc ở đâu?','Hà Nội','Bắc Ninh','Huế','Đà Nẵng'],
  [1,'Điểm khác biệt về kĩ thuật của tranh Hàng Trống so với tranh Đông Hồ là gì?','Chỉ in nét đen bằng ván khắc rồi tô màu bằng tay','In toàn bộ các màu bằng ván khắc','Vẽ hoàn toàn bằng bút sáp','Chụp ảnh rồi in'],
  [1,'Giấy in tranh Đông Hồ được quét một lớp bột từ vỏ sò, điệp nghiền nhỏ, gọi là giấy gì?','Giấy điệp (giấy dó quét điệp)','Giấy than','Giấy bìa cứng','Giấy bạc'],
  [1,'Tranh dân gian Việt Nam thường có những loại đề tài nào?','Tranh chúc tụng, tranh sinh hoạt, tranh thờ, tranh lịch sử, tranh châm biếm','Tranh về máy móc hiện đại','Tranh về vũ trụ','Tranh về thành phố nước ngoài'],
  [2,'Vì sao tranh Hàng Trống có màu sắc tươi, chuyển sắc mềm mại hơn tranh Đông Hồ?','Vì nghệ nhân tô màu bằng tay với bút lông và phẩm màu, có thể vờn đậm nhạt','Vì in bằng nhiều ván màu hơn','Vì dùng giấy điệp','Vì chỉ dùng màu đen'],
  [2,'Hình ảnh trong tranh dân gian thường mang ý nghĩa gì?','Ước mong về cuộc sống no đủ, hạnh phúc, con cháu đông vui','Chỉ để lấp đầy giấy','Ghi lại ảnh chụp thật','Không có ý nghĩa'],
  [3,'So sánh cách làm tranh Đông Hồ và tranh Hàng Trống.','Giống: đều là tranh dân gian, dùng ván khắc gỗ in nét. Khác: Đông Hồ in tất cả các mảng màu bằng nhiều ván màu trên giấy điệp, màu tự nhiên; Hàng Trống chỉ in nét đen rồi tô màu bằng tay với phẩm màu, có vờn đậm nhạt, thường khổ lớn hơn.'],
  [3,'Kể tên một số nguyên liệu tự nhiên dùng làm màu trong tranh Đông Hồ và màu tương ứng.','Than lá tre hoặc than rơm: màu đen; hoa hòe: màu vàng; sỏi son: màu đỏ; gỉ đồng: màu xanh; vỏ điệp nghiền: màu trắng.'],
  [3,'Em hãy nêu cách vận dụng hình ảnh, màu sắc của tranh dân gian vào việc trang trí một sản phẩm (ví dụ: túi giấy, thiệp).','Chọn hình ảnh dân gian quen thuộc như con gà, con cá, em bé ôm gà; vẽ lại đơn giản với mảng màu phẳng, nét viền rõ; dùng màu tươi như đỏ, vàng, lục, lam; bố trí hình cân đối trên túi hoặc thiệp.'],
  [4,'Vì sao tranh dân gian Đông Hồ và Hàng Trống dù cùng in từ ván khắc nhưng lại có vẻ đẹp khác nhau? Phân tích theo chất liệu và cách làm.','Đông Hồ in toàn bộ bằng các ván màu trên giấy điệp với màu tự nhiên nên mảng màu phẳng, chắc, mộc mạc, nét to khỏe, phù hợp với đời sống nông thôn. Hàng Trống chỉ in nét rồi tô tay bằng phẩm màu, nghệ nhân vờn màu đậm nhạt nên tranh tươi, mềm mại, tinh tế hơn, phục vụ chủ yếu người dân phố thị và tranh thờ. Sự khác biệt về chất liệu, kĩ thuật và đối tượng sử dụng tạo nên hai vẻ đẹp riêng.']
 ]);
 add(M,4,'Tạo hình và thủ công',[
  [1,'Khi in hình từ lá cây, em quét màu lên bộ phận nào của lá để hình in rõ gân?','Mặt lá có gân nổi','Cuống lá','Mặt bàn','Tờ giấy nền'],
  [1,'Sản phẩm thủ công nào sau đây làm từ giấy gấp?','Hoa, con vật, hộp gấp từ giấy','Tượng đồng','Bình gốm','Tranh sơn dầu'],
  [1,'Hình nổi trên tấm xốp hoặc củ quả sau khi khắc được dùng để làm gì?','In hình lên giấy (tranh in)','Làm thước đo','Làm bút vẽ','Pha màu'],
  [1,'Tạo hình bằng dây thép mềm (dây kẽm) uốn thành hình người, con vật thuộc dạng tạo hình nào?','Tạo hình ba chiều (khối)','Vẽ tranh hai chiều','In tranh','Tô màu'],
  [2,'Vì sao khi in bằng khuôn in, hình in ra lại ngược chiều so với hình trên khuôn?','Vì khuôn úp xuống giấy nên hình bị lật trái phải','Vì màu bị khô','Vì giấy quá dày','Vì ấn quá nhẹ'],
  [2,'Khi làm mặt nạ bằng bìa, em nên làm gì để mặt nạ vừa với khuôn mặt?','Đo và đánh dấu vị trí mắt, mũi trước khi cắt','Cắt ngẫu nhiên rồi đeo thử','Dùng mặt nạ nhỏ bằng bàn tay','Không cần khoét lỗ mắt'],
  [2,'Khi tạo hình bằng vật liệu tái chế, điều quan trọng nhất về an toàn là gì?','Làm sạch vật liệu, cẩn thận với mép sắc, dùng kéo đúng cách','Dùng vật liệu càng bẩn càng tốt','Dùng dao sắc không cần người lớn','Không cần rửa tay sau khi làm'],
  [3,'Nêu các bước tạo một bức tranh in từ lá cây.','Chọn lá có gân rõ; quét hoặc tô màu lên mặt gân lá; úp lá lên giấy, dùng tay hoặc giấy ấn đều; nhấc lá ra; lặp lại với màu và lá khác để tạo bố cục; vẽ thêm chi tiết nếu cần.'],
  [3,'Nêu cách làm một chiếc mặt nạ con vật bằng bìa cứng.','Vẽ hình khuôn mặt con vật vừa với mặt người; cắt theo nét, khoét lỗ mắt; vẽ hoặc dán giấy màu trang trí mắt, mũi, râu, tai; đục lỗ hai bên và buộc dây hoặc gắn que cầm.'],
  [3,'Nêu cách tạo một mô hình cây bằng giấy và vật liệu sẵn có.','Cuộn giấy báo hoặc dùng lõi giấy làm thân; xé hoặc cắt giấy màu xanh thành tán lá, cuộn nhỏ làm cành; gắn các phần bằng hồ, băng dính; đặt vào đế bằng nắp hộp hoặc đất nặn để cây đứng vững.'],
  [4,'Vì sao sản phẩm tạo hình ba chiều (mô hình, tượng nặn) cần được xem từ nhiều phía, còn tranh vẽ chỉ cần xem từ phía trước? Khi làm mô hình em cần lưu ý gì từ điều này?','Tranh vẽ trên mặt phẳng hai chiều nên chỉ có một mặt nhìn; sản phẩm ba chiều có chiều cao, rộng, sâu, chiếm chỗ trong không gian nên người xem có thể đi vòng quanh và nhìn từ trước, sau, hai bên. Vì vậy khi làm mô hình em phải chăm chút mọi phía, bảo đảm hình cân đối, đứng vững và đẹp từ các góc nhìn chứ không chỉ đẹp mặt trước.']
 ]);
 add(M,4,'Quan sát và cảm nhận',[
  [1,'Khi vẽ tranh về chủ đề "Ngày hội ở trường em", em cần quan sát hoặc nhớ lại điều gì?','Các hoạt động, trang phục, cờ hoa và không khí vui tươi của ngày hội','Thời tiết ở nước ngoài','Giá vé xem phim','Cách nấu một món ăn'],
  [1,'Khi nhận xét bài vẽ của bạn, em nên bắt đầu bằng điều gì?','Nêu điểm tốt, điểm em thích rồi góp ý nhẹ nhàng','Chỉ ra tất cả lỗi thật to','Chê bạn vẽ xấu','Giấu bài của bạn đi'],
  [1,'Đường chân trời trong tranh phong cảnh là gì?','Đường ngang nơi mặt đất hoặc mặt nước giao với bầu trời','Đường kẻ dưới tên tranh','Bóng của cây','Mép giấy'],
  [2,'Khi vẽ cảnh có con đường chạy xa dần, con đường nên được vẽ thế nào?','Rộng ở gần và hẹp dần khi ra xa','Rộng đều từ gần đến xa','Hẹp ở gần, rộng ở xa','Chỉ là một nét thẳng'],
  [2,'Một bức tranh có nhiều hình được sắp xếp cân đối, có chính phụ, màu hài hòa gọi là có gì?','Bố cục đẹp','Màu bổ túc','Nét đứt','Hình cơ bản'],
  [2,'Khi quan sát một pho tượng hoặc mô hình, em nên làm gì để cảm nhận đầy đủ?','Nhìn từ nhiều phía: trước, sau, hai bên','Chỉ nhìn một phía','Chỉ đọc tên tượng','Sờ mạnh vào tượng'],
  [3,'Trình bày các bước thực hiện bài vẽ phong cảnh quê hương.','Quan sát hoặc nhớ lại cảnh; chọn góc cảnh đẹp; vẽ đường chân trời, phác hình chính (nhà, cây, núi, sông) có gần to xa nhỏ; vẽ chi tiết; tô màu có đậm nhạt, xa nhạt gần đậm; hoàn thiện.'],
  [3,'Nêu ba tiêu chí để nhận xét một bức tranh của bạn trong lớp.','Nội dung rõ, đúng chủ đề; bố cục có hình chính phụ cân đối; màu sắc hài hòa, có đậm nhạt. Có thể thêm: nét vẽ, sự sáng tạo, cảm xúc tranh mang lại.'],
  [3,'Em cảm nhận thế nào về một bức tranh có bố cục dàn đều, các hình to bằng nhau rải khắp mặt tranh? Em sẽ góp ý bạn sửa như thế nào?','Tranh trông rối, không có trọng tâm, khó nhận ra nội dung chính. Góp ý: chọn một hình chính vẽ to, rõ ở khoảng giữa; các hình khác nhỏ hơn, ít hơn làm hình phụ; tô màu hình chính nổi bật hơn.'],
  [4,'Vì sao khi vẽ tranh phong cảnh người ta thường vẽ vật ở xa nhỏ và mờ, vật ở gần to và rõ? Nếu vẽ ngược lại, người xem sẽ cảm thấy thế nào?','Vì mắt ta nhìn vật ở xa thấy nhỏ hơn, màu nhạt và chi tiết mờ hơn do khoảng cách và lớp không khí; vẽ như vậy tạo cảm giác không gian có chiều sâu giống thật. Nếu vẽ ngược lại (xa to rõ, gần nhỏ mờ), không gian tranh bị đảo lộn, người xem khó xác định vị trí các vật và thấy tranh phi lí, dẹt.']
 ]);

 /* ===== LỚP 5 ===== */
 add(M,5,'Màu sắc và đậm nhạt',[
  [1,'Màu tương phản là gì?','Các màu đối lập nhau, đặt cạnh nhau làm nổi bật nhau như đỏ – lục, vàng – tím','Các màu giống nhau','Chỉ màu đen và trắng','Màu pha với nước'],
  [1,'Sắc độ của màu là gì?','Mức độ đậm nhạt, sáng tối khác nhau của cùng một màu','Tên gọi của màu','Số lượng màu trong hộp','Giá của tuýp màu'],
  [1,'Màu nào sau đây được coi là màu trung tính, thường dùng làm nền dịu?','Xám, nâu, trắng, đen','Đỏ tươi','Cam tươi','Vàng chanh'],
  [1,'Màu đen pha thêm vào một màu sẽ làm màu đó như thế nào?','Đậm, tối hơn','Sáng hơn','Trong hơn','Chuyển thành trắng'],
  [2,'Gam màu chủ đạo của một bức tranh là gì?','Nhóm màu chiếm phần lớn và quyết định không khí chung của tranh','Màu ở góc tranh','Màu của khung tranh','Màu ít dùng nhất'],
  [2,'Trong tranh, mảng màu sáng đặt trên nền tối sẽ cho hiệu quả gì?','Mảng sáng nổi bật, thu hút sự chú ý','Mảng sáng bị lẫn vào nền','Cả tranh tối đi','Màu sáng chuyển sang tối'],
  [2,'Khi vẽ bằng màu bột (goát), muốn màu đậm hơn em làm thế nào?','Pha thêm một ít màu tối hoặc màu đen, tô ít nước','Pha thật nhiều nước','Pha thêm màu trắng','Pha thêm màu vàng'],
  [3,'Thế nào là màu tương phản và màu tương đồng? Mỗi loại cho một ví dụ.','Màu tương phản là các màu đối nhau trên vòng màu, đặt cạnh nhau tạo sự nổi bật mạnh (đỏ – lục, lam – cam). Màu tương đồng là các màu gần nhau trên vòng màu, tạo hòa sắc êm dịu (vàng – cam – đỏ; lam – lục).'],
  [3,'Nêu cách tạo sắc độ cho một màu bằng màu bột hoặc màu nước.','Pha dần màu trắng (màu bột) hoặc thêm nước (màu nước) để có các sắc độ nhạt dần; pha dần màu đen hoặc màu tối hơn để có các sắc độ đậm dần; sắp xếp thành dải từ nhạt đến đậm.'],
  [3,'Em vẽ tranh về "Bình minh trên biển". Em chọn gam màu chủ đạo nào và tạo đậm nhạt như thế nào?','Gam chủ đạo lạnh (lam, lục) cho biển và trời; điểm nhấn màu nóng (vàng, cam, hồng) ở mặt trời và vùng trời gần mặt trời; trời phía xa nhạt, biển gần đậm, bóng thuyền đậm nhất để tạo chiều sâu.'],
  [4,'Vì sao họa sĩ phải xác định gam màu chủ đạo trước khi vẽ, thay vì dùng mọi màu với lượng bằng nhau? Phân tích bằng ví dụ.','Gam chủ đạo tạo sự thống nhất, quyết định cảm xúc chung của tranh (ấm hay mát, vui hay trầm) và làm nền cho các điểm nhấn tương phản nổi bật. Nếu dùng mọi màu với lượng bằng nhau, tranh rối, không có trọng tâm, màu triệt tiêu nhau. Ví dụ: tranh về đêm hội dùng gam lam tím chủ đạo, các đốm đỏ vàng của đèn lồng tuy ít nhưng nổi bật và nói lên không khí lễ hội.']
 ]);
 add(M,5,'Mĩ thuật dân gian và thường thức',[
  [1,'Trống đồng Đông Sơn là di sản mĩ thuật thuộc thời kì nào của Việt Nam?','Thời kì cổ đại (thời các vua Hùng, văn hóa Đông Sơn)','Thời Nguyễn','Thời hiện đại','Thời Pháp thuộc'],
  [1,'Trên mặt trống đồng Đông Sơn thường có hình ảnh gì ở chính giữa?','Ngôi sao nhiều cánh (hình mặt trời)','Hình máy bay','Hình chữ viết la-tinh','Hình ngôi nhà cao tầng'],
  [1,'Hoa văn trên trống đồng được thể hiện bằng cách nào?','Hình khắc, đúc nổi sắp xếp theo vòng tròn đồng tâm','Vẽ bằng màu nước','In bằng ván gỗ','Dán giấy màu'],
  [1,'Nghệ thuật điêu khắc dân gian ở đình làng Việt Nam thường thể hiện trên chất liệu gì?','Gỗ (chạm khắc gỗ)','Giấy điệp','Vải lụa','Nhựa'],
  [2,'Đề tài chạm khắc trên đình làng xưa thường là gì?','Cảnh sinh hoạt, vui chơi của người dân, con vật, hoa lá','Máy móc công nghiệp','Phong cảnh nước ngoài','Chữ cái tiếng Anh'],
  [2,'Vì sao các hoa văn, hình người, chim, thú trên trống đồng được xếp thành vòng tròn quanh ngôi sao?','Để tạo nhịp điệu lặp lại, cân đối theo hình tròn của mặt trống','Vì người xưa không biết vẽ hình khác','Vì trống hình vuông','Vì để tiết kiệm đồng'],
  [3,'Nêu một số đặc điểm chung về trang trí trên trống đồng Đông Sơn.','Mặt trống có ngôi sao nhiều cánh ở giữa; xung quanh là các vành hoa văn đồng tâm với hình người hóa trang, chim bay, hươu, nhà sàn, thuyền và hoa văn hình học (răng cưa, vòng tròn chấm giữa); hình được cách điệu, lặp lại tạo nhịp điệu.'],
  [3,'Kể tên một số loại hình mĩ thuật dân gian Việt Nam mà em biết.','Tranh dân gian (Đông Hồ, Hàng Trống, Kim Hoàng, làng Sình); chạm khắc gỗ đình làng; gốm (Bát Tràng, Chu Đậu); tượng dân gian; đồ thủ công như mây tre đan, thêu, nón lá.'],
  [3,'Em hãy nêu cách vận dụng hoa văn dân gian (như hoa văn trống đồng) để trang trí một chiếc đĩa tròn.','Vẽ vòng tròn đồng tâm chia đĩa thành các vành; đặt hình trung tâm ở giữa (ngôi sao, hoa); vẽ hoa văn lặp lại đều quanh các vành (răng cưa, chim, hình người cách điệu); tô màu đậm nhạt xen kẽ để hoa văn rõ và cân đối.'],
  [4,'Vì sao hoa văn trên trống đồng Đông Sơn, trên gốm hay trên trang phục dân tộc thường được "cách điệu" (đơn giản hóa) thay vì vẽ giống hệt thật? Hãy phân tích lợi ích của cách điệu trong trang trí.','Trong trang trí, hình cần lặp lại nhiều lần trên bề mặt cố định nên phải đơn giản, rõ nét để dễ khắc, dễ in, dễ nhận ra ở nhiều kích cỡ; cách điệu còn giữ lại đặc điểm chính của sự vật, lược bỏ chi tiết thừa, làm hình đẹp hơn, mang tính biểu tượng và phù hợp với nhịp điệu, bố cục của vật được trang trí. Nhờ vậy hoa văn vừa đẹp, vừa hài hòa với vật dụng.']
 ]);
 add(M,5,'Tạo hình và thủ công',[
  [1,'Sản phẩm mĩ thuật được tạo ra để sử dụng trong đời sống như túi, hộp, đèn trang trí thuộc lĩnh vực gì?','Mĩ thuật ứng dụng','Hội họa giá vẽ','Điêu khắc tượng đài','Âm nhạc'],
  [1,'Khi thiết kế một sản phẩm, bước đầu tiên em cần làm là gì?','Xác định mục đích sử dụng và phác thảo ý tưởng','Tô màu ngay','Cắt vật liệu ngẫu nhiên','Đem bán sản phẩm'],
  [1,'Để mô hình bằng bìa đứng vững, em có thể làm gì?','Gắn thêm đế hoặc gấp chân đỡ','Làm mô hình thật cao và mỏng','Dùng bìa thật mỏng','Không cần đế'],
  [1,'Kĩ thuật gấp giấy tạo hình ba chiều mà không dùng kéo và hồ dán có nguồn gốc từ Nhật Bản gọi là gì?','Gấp giấy ô-ri-ga-mi (origami)','Xé dán','In khắc gỗ','Nặn đất'],
  [2,'Vì sao khi thiết kế bao bì cho một sản phẩm, em cần quan tâm đến cả hình dáng lẫn hình ảnh trang trí?','Vì bao bì vừa phải bảo vệ, chứa được sản phẩm vừa phải đẹp, thu hút và cho biết sản phẩm bên trong','Vì chỉ cần đẹp là đủ','Vì chỉ cần chắc là đủ','Vì bao bì không quan trọng'],
  [2,'Khi làm đèn lồng bằng giấy màu, để đèn có nhiều màu khi sáng, em nên dùng loại giấy nào?','Giấy mỏng, nhiều màu, cho ánh sáng xuyên qua','Bìa cứng tối màu','Giấy bạc','Vải dày'],
  [2,'Chất cảm của bề mặt sản phẩm là gì?','Cảm giác về bề mặt như nhẵn, sần, thô, mịn mà ta nhận ra khi nhìn hoặc chạm','Màu của sản phẩm','Hình dáng của sản phẩm','Kích cỡ của sản phẩm'],
  [3,'Nêu các bước thiết kế và làm một chiếc hộp đựng bút từ vật liệu tái chế.','Xác định kích cỡ và số ngăn cần có; chọn vật liệu (lõi giấy, hộp sữa, bìa); phác thảo kiểu dáng; cắt, ghép, dán các phần; trang trí bằng giấy màu, màu vẽ, chất liệu khác; kiểm tra độ chắc, chỉnh sửa.'],
  [3,'Kể tên một số nghề liên quan đến mĩ thuật ứng dụng mà em biết và cho biết họ làm gì.','Nhà thiết kế thời trang: tạo mẫu quần áo; nhà thiết kế đồ họa: vẽ lô-gô, bìa sách, áp phích; nhà thiết kế nội thất: trang trí nhà ở; nghệ nhân thủ công: làm gốm, mây tre đan, thêu; kiến trúc sư: thiết kế công trình.'],
  [3,'Em hãy nêu cách tạo chất cảm khác nhau trên bề mặt một sản phẩm thủ công.','Dán cát, vỏ trứng, hạt đậu để tạo bề mặt sần; dán giấy nhăn, vải, len tạo bề mặt mềm, thô; dùng giấy bóng, nhũ tạo bề mặt nhẵn, bóng; tô màu dày hoặc miết đất nặn tạo vân nổi.'],
  [4,'Vì sao một sản phẩm mĩ thuật ứng dụng tốt phải vừa đẹp vừa tiện dùng? Nêu ví dụ về một sản phẩm đẹp nhưng không tiện dùng và cách sửa.','Mĩ thuật ứng dụng phục vụ đời sống nên sản phẩm phải dùng được, an toàn, phù hợp người dùng; đồng thời cái đẹp làm người dùng thích thú, muốn sử dụng và tôn giá trị sản phẩm. Ví dụ: chiếc cốc trang trí rất đẹp nhưng tay cầm quá nhỏ, khó cầm; cần sửa tay cầm to vừa tay, giữ lại họa tiết. Nếu chỉ đẹp mà không tiện, sản phẩm thành đồ trưng bày; chỉ tiện mà xấu thì kém hấp dẫn.']
 ]);
 add(M,5,'Quan sát và cảm nhận',[
  [1,'Khi vẽ chân dung, tỉ lệ giữa các bộ phận trên khuôn mặt cần được quan sát để làm gì?','Để khuôn mặt vẽ cân đối, giống đặc điểm người được vẽ','Để tô màu nhanh hơn','Để tiết kiệm giấy','Để bức tranh nhỏ hơn'],
  [1,'Trong một bức tranh, điểm nhấn là gì?','Phần nổi bật nhất thu hút mắt người xem trước tiên','Góc tranh bị bỏ trống','Chữ kí của tác giả','Khung tranh'],
  [1,'Khi thưởng thức một tác phẩm mĩ thuật, em nên tìm hiểu những điều gì?','Tên tác phẩm, chất liệu, nội dung, màu sắc, bố cục và cảm nhận của bản thân','Chỉ xem có đắt tiền không','Chỉ xem kích cỡ','Không cần tìm hiểu gì'],
  [2,'Khi vẽ người đang chạy, để tranh có cảm giác chuyển động, em nên chú ý điều gì?','Tư thế người nghiêng về phía trước, tay chân co duỗi theo hướng chạy','Vẽ người đứng thẳng, hai tay buông','Vẽ người ngồi yên','Tô màu thật đậm'],
  [2,'Tỉ lệ cơ thể trẻ em so với người lớn có đặc điểm gì?','Đầu to hơn so với thân; trẻ càng nhỏ thì chiều cao càng ít lần chiều cao đầu (khoảng 4 – 6 lần tùy tuổi)','Giống hệt người lớn','Đầu nhỏ hơn rất nhiều','Chân dài hơn người lớn'],
  [2,'Khi xem triển lãm tranh của lớp, thái độ nào là đúng?','Xem trật tự, không chạm vào sản phẩm, nhận xét tôn trọng tác giả','Chạy nhảy, kéo tranh xuống xem','Vẽ thêm lên tranh của bạn','Chỉ xem tranh của mình'],
  [3,'Nêu các bước vẽ tranh chân dung bạn em.','Quan sát khuôn mặt, kiểu tóc, đặc điểm riêng; phác khung đầu, chia tỉ lệ vị trí mắt, mũi, miệng; vẽ chi tiết các bộ phận; vẽ tóc, cổ, vai; tô màu da, tóc, trang phục có đậm nhạt; hoàn thiện nền.'],
  [3,'Em hãy nêu cách tổ chức trưng bày sản phẩm mĩ thuật của nhóm trong lớp.','Chọn sản phẩm; phân loại theo chủ đề hoặc chất liệu; treo, đặt ở vị trí dễ nhìn, ngang tầm mắt, cách nhau hợp lí; ghi tên sản phẩm, tác giả; cử người giới thiệu và mời các bạn nhận xét.'],
  [3,'Khi quan sát một dáng người đang lao động (gánh lúa, cuốc đất), em cần chú ý điều gì để vẽ sinh động?','Hướng nghiêng của thân, vị trí tay chân, độ cong của lưng, vật cầm trên tay, nét mặt; tỉ lệ các bộ phận và cảm giác nặng nhẹ của động tác.'],
  [4,'Vì sao hai bức tranh cùng vẽ một dáng người nhưng một bức có cảm giác sống động, một bức lại cứng nhắc? Phân tích các yếu tố tạo nên sự sống động.','Sự sống động đến từ tư thế có hướng động (thân nghiêng, tay chân co duỗi tự nhiên), tỉ lệ cân đối, đường nét mềm mại thay đổi đậm nhạt, và bố cục để khoảng trống theo hướng chuyển động. Bức cứng nhắc thường vẽ người thẳng đứng đối xứng, các bộ phận đều nhau, nét đều một kiểu, không có chuyển động và cảm xúc; vì vậy quan sát kĩ dáng thật trước khi vẽ rất quan trọng.']
 ]);

 /* ===== LỚP 6 ===== */
 add(M,6,'Kiến thức tạo hình',[
  [1,'Mĩ thuật tạo hình gồm những thể loại chính nào?','Hội họa, đồ họa (tranh in), điêu khắc','Thời trang, nội thất, bao bì','Âm nhạc, múa, kịch','Văn học, điện ảnh'],
  [1,'Tranh in khắc gỗ, in độc bản thuộc thể loại nào của mĩ thuật tạo hình?','Đồ họa','Hội họa','Điêu khắc','Kiến trúc'],
  [1,'Phù điêu là gì?','Hình khối đắp hoặc chạm nổi trên một mặt phẳng nền','Tranh vẽ bằng màu nước','Tượng tròn đứng tự do','Bản in trên giấy'],
  [1,'Xây dựng ý tưởng cho một sản phẩm mĩ thuật thường bắt đầu từ đâu?','Quan sát, ghi chép, chọn lọc hình ảnh từ thực tế hoặc trí tưởng tượng','Tô màu nền trước','Chọn khung tranh','Đặt tên trước rồi không vẽ'],
  [2,'Phác thảo có vai trò gì trong quá trình sáng tác?','Thử nghiệm bố cục, hình, màu ở dạng đơn giản trước khi thực hiện bản chính','Là bản vẽ hoàn thiện cuối cùng','Chỉ dùng để trang trí','Không cần thiết'],
  [2,'Điểm khác nhau cơ bản giữa tranh vẽ và tranh in là gì?','Tranh in được tạo qua khuôn in, có thể nhân bản; tranh vẽ được vẽ trực tiếp và là duy nhất','Tranh in luôn to hơn','Tranh vẽ không có màu','Tranh in không có bố cục'],
  [2,'Tượng tròn khác phù điêu ở điểm nào?','Tượng tròn có thể xem được từ mọi phía, phù điêu chỉ xem từ phía trước','Tượng tròn chỉ làm bằng gỗ','Phù điêu luôn to hơn','Tượng tròn không có khối'],
  [3,'Phân biệt mĩ thuật tạo hình và mĩ thuật ứng dụng, mỗi loại cho hai ví dụ.','Mĩ thuật tạo hình tạo ra tác phẩm chủ yếu để thưởng thức (tranh sơn dầu, tượng, tranh khắc gỗ); mĩ thuật ứng dụng tạo sản phẩm vừa đẹp vừa dùng được trong đời sống (bìa sách, lô-gô, trang phục, đồ nội thất, bao bì).'],
  [3,'Trình bày các bước xây dựng ý tưởng và thực hiện một bức tranh theo chủ đề.','Tìm hiểu chủ đề, quan sát, sưu tầm hình ảnh; chọn nội dung và hình ảnh chính; phác thảo vài bố cục nhỏ, chọn một; phác hình lên khổ chính; vẽ màu từ mảng lớn đến chi tiết; hoàn thiện và đánh giá.'],
  [3,'Nêu cách thực hiện một bức tranh in độc bản đơn giản tại lớp.','Vẽ hoặc trải màu lên tấm nhựa, kính mỏng (mặt phẳng không thấm); cạo, vẽ nét vào lớp màu tạo hình; đặt giấy lên, xoa đều; nhấc giấy ra được hình in duy nhất; có thể in thêm lớp màu khác khi lớp trước khô.'],
  [4,'Vì sao cùng một ý tưởng, một tác phẩm có thể được thể hiện bằng hội họa, đồ họa hay điêu khắc với hiệu quả khác nhau? Phân tích ưu thế của mỗi thể loại.','Mỗi thể loại có ngôn ngữ và chất liệu riêng: hội họa mạnh về màu sắc, ánh sáng, không gian trên mặt phẳng; đồ họa mạnh về nét, mảng đen trắng, tương phản và khả năng nhân bản để nhiều người xem; điêu khắc mạnh về khối, chất liệu thật và không gian ba chiều, tác động trực tiếp bằng hình khối. Người sáng tác chọn thể loại tùy vào nội dung, cảm xúc muốn truyền đạt và điều kiện thực hiện.']
 ]);
 add(M,6,'Thường thức mĩ thuật',[
  [1,'Những hình vẽ trên vách hang động thời tiền sử thường có đề tài gì?','Các loài động vật và cảnh săn bắt','Thành phố và xe cộ','Chữ viết và sách','Chân dung vua chúa'],
  [1,'Người tiền sử dùng chất liệu gì để vẽ trên vách đá?','Than, đất màu (đất son) và khoáng chất tự nhiên','Sơn dầu','Màu nước đóng tuýp','Bút sáp màu'],
  [1,'Hang Lát-xcô (Lascaux) nổi tiếng với tranh vẽ thời tiền sử nằm ở nước nào?','Pháp','Việt Nam','Ai Cập','Hy Lạp'],
  [1,'Di tích hình khắc mặt người thời tiền sử ở Việt Nam được tìm thấy ở hang nào?','Hang Đồng Nội (Hòa Bình, nay thuộc tỉnh Phú Thọ)','Hang Sơn Đoòng','Động Phong Nha','Hang Pác Bó'],
  [2,'Mĩ thuật thời kì cổ đại Ai Cập có đặc điểm nổi bật nào?','Kim tự tháp, tượng đồ sộ, hình người vẽ theo quy tắc nhìn nghiêng đầu và chân, nhìn thẳng thân','Tranh sơn dầu vẽ ngoài trời','Tượng bằng nhựa','Tranh in khắc gỗ nhiều màu'],
  [2,'Thành tựu tiêu biểu của mĩ thuật Hy Lạp cổ đại là gì?','Tượng người cân đối, đẹp lí tưởng và kiến trúc đền thờ với các thức cột','Tranh hang động','Trống đồng','Tranh dân gian khắc gỗ'],
  [2,'Mĩ thuật Việt Nam thời kì cổ đại tiêu biểu với hiện vật nào?','Trống đồng, thạp đồng thuộc văn hóa Đông Sơn','Tranh sơn mài','Nhà thờ đá','Tượng Phật bằng gỗ sơn son'],
  [3,'Nêu một số đặc điểm chung của mĩ thuật thời kì tiền sử.','Hình vẽ, khắc trên vách hang, trên đá; đề tài chủ yếu là động vật, săn bắt, bàn tay, kí hiệu; hình đơn giản nhưng sinh động, chủ yếu là nét và mảng; dùng than, đất màu tự nhiên; ngoài ra có tượng nhỏ bằng đá, ngà, đất.'],
  [3,'Kể tên ba nền mĩ thuật cổ đại tiêu biểu trên thế giới và một thành tựu của mỗi nền.','Ai Cập: kim tự tháp, tượng Nhân sư; Hy Lạp: đền Pác-tê-nông, các tượng người lí tưởng; La Mã: đấu trường Cô-li-dê, đền Pan-tê-ông với kiến trúc vòm.'],
  [3,'Hoa văn trên trống đồng Đông Sơn gợi cho em ý tưởng gì để sáng tạo sản phẩm mĩ thuật ngày nay?','Có thể dùng hoa văn ngôi sao, chim lạc, người hóa trang, hoa văn hình học cách điệu để trang trí trang phục, túi, bìa sổ, lô-gô, họa tiết trên gốm; giữ tinh thần nhịp điệu lặp lại và bố cục tròn đồng tâm.'],
  [4,'Vì sao hình vẽ động vật trong hang động tiền sử dù cách đây hàng vạn năm vẫn được coi là có giá trị nghệ thuật cao? Phân tích.','Người tiền sử đã quan sát rất kĩ nên hình động vật đúng tỉ lệ, đúng động tác, có cảm giác chuyển động; họ biết dùng nét, mảng, đậm nhạt và tận dụng độ cong vách đá tạo khối; màu từ vật liệu tự nhiên tồn tại rất lâu. Những hình vẽ này vừa là nguồn sử liệu về đời sống, tín ngưỡng, vừa cho thấy nhu cầu thẩm mĩ và khả năng sáng tạo của con người xuất hiện từ rất sớm.']
 ]);
 add(M,6,'Yếu tố và nguyên lí tạo hình',[
  [1,'Các yếu tố tạo hình cơ bản gồm những gì?','Chấm, nét, hình, khối, màu sắc, đậm nhạt, chất cảm, không gian','Nhịp điệu, hài hòa, tỉ lệ','Nhạc, lời, giai điệu','Chữ, số, kí hiệu'],
  [1,'Nguyên lí tạo hình nào thể hiện sự lặp lại có quy luật của các yếu tố tạo cảm giác chuyển động?','Nhịp điệu','Tương phản','Cân bằng','Tỉ lệ'],
  [1,'Cân bằng đối xứng trong bố cục là gì?','Hai bên trục giống hoặc gần giống nhau về hình, mảng','Một bên to một bên rất nhỏ','Toàn bộ hình dồn về một góc','Không có hình nào'],
  [1,'Chất cảm trong tạo hình là gì?','Cảm giác về bề mặt của chất liệu như thô, nhẵn, sần, mịn','Số lượng màu','Kích thước tranh','Tên tác phẩm'],
  [2,'Khi vẽ bằng các chấm màu nhỏ đặt sát nhau để tạo hình và màu, người ta dùng yếu tố tạo hình nào làm chính?','Chấm','Khối','Không gian','Chữ'],
  [2,'Tương phản trong tạo hình thể hiện qua điều gì?','Sự đối lập về đậm nhạt, màu sắc, to nhỏ, thô mịn đặt cạnh nhau','Sự giống nhau hoàn toàn','Chỉ dùng một màu','Chỉ dùng nét thẳng'],
  [2,'Cân bằng bất đối xứng được tạo ra như thế nào?','Hai bên khác nhau về hình nhưng cân đối về cảm giác nặng nhẹ nhờ sắp xếp mảng, màu, đậm nhạt','Hai bên giống y nhau','Để trống một bên hoàn toàn','Dồn mọi thứ vào giữa'],
  [3,'Kể tên các nguyên lí tạo hình và nêu ngắn gọn ý nghĩa của ba nguyên lí.','Các nguyên lí: cân bằng, tương phản, lặp lại, nhịp điệu, nhấn mạnh, chuyển động, tỉ lệ, hài hòa. Cân bằng: các phần bố cục cân đối về cảm giác; tương phản: đối lập làm nổi bật; nhịp điệu: lặp lại có quy luật tạo chuyển động, sinh động.'],
  [3,'Nêu cách sử dụng chấm và nét để tạo một họa tiết trang trí hình vuông.','Kẻ trục đối xứng; vẽ họa tiết chính ở giữa bằng nét; dùng nét lặp lại, chấm to nhỏ xen kẽ ở bốn góc và viền; tô màu theo nguyên lí đối xứng, các phần giống nhau tô cùng màu; tạo tương phản đậm nhạt giữa họa tiết và nền.'],
  [3,'Em dùng yếu tố không gian và đậm nhạt như thế nào để bức tranh có chiều sâu?','Vẽ hình gần to, rõ, đậm; hình xa nhỏ, mờ, nhạt; các hình che khuất nhau theo lớp trước sau; đường chân trời và hướng các đường tụ về xa; nền chuyển từ đậm đến nhạt.'],
  [4,'Phân tích vì sao các nguyên lí tạo hình như cân bằng, nhịp điệu, tương phản lại giúp một bức tranh trở nên hấp dẫn hơn.','Cân bằng làm người xem thấy ổn định, dễ chịu, không bị lệch nặng nhẹ; nhịp điệu nhờ lặp lại có biến đổi dẫn mắt người xem đi khắp tranh và tạo cảm giác chuyển động, sống động; tương phản tạo điểm nhấn, làm hình chính nổi bật và tranh có sức hút. Khi các nguyên lí phối hợp hài hòa, tranh có trật tự nhưng không đơn điệu, có trọng tâm và gợi cảm xúc rõ ràng.']
 ]);
 add(M,6,'Thưởng thức và ứng dụng',[
  [1,'Sản phẩm thời trang có họa tiết mô phỏng hình vẽ hang động tiền sử là ví dụ về điều gì?','Vận dụng di sản mĩ thuật vào thiết kế hiện đại','Sao chép hoàn toàn tranh cổ','Mĩ thuật tạo hình thuần túy','Điêu khắc đá'],
  [1,'Khi làm sản phẩm từ vật liệu tái chế, ý nghĩa quan trọng nhất là gì?','Góp phần bảo vệ môi trường và phát huy sáng tạo','Làm sản phẩm bán được giá cao','Chỉ để nộp bài','Tiêu thụ nhiều rác hơn'],
  [1,'Tranh dân gian Đông Hồ thuộc thể loại nào trong mĩ thuật tạo hình?','Đồ họa (tranh in khắc gỗ)','Điêu khắc','Kiến trúc','Thiết kế thời trang'],
  [2,'Khi thưởng thức một tác phẩm, "chất liệu" của tác phẩm có ý nghĩa gì?','Là vật liệu tạo nên tác phẩm như sơn dầu, lụa, gỗ, đồng, ảnh hưởng đến vẻ đẹp và cách thể hiện','Là tên của tác giả','Là nơi trưng bày','Là giá tiền'],
  [2,'Thiết kế thời trang lấy cảm hứng từ hoa văn trống đồng là sự kết hợp giữa gì với gì?','Di sản mĩ thuật truyền thống với mĩ thuật ứng dụng hiện đại','Hai dòng tranh dân gian','Điêu khắc và kiến trúc cổ','Hội họa và âm nhạc'],
  [2,'Em muốn làm một chiếc mặt nạ lễ hội từ bìa cứng và giấy màu. Đây là hoạt động thuộc lĩnh vực nào?','Mĩ thuật ứng dụng (thiết kế, thủ công)','Hội họa giá vẽ','Khảo cổ học','Nghệ thuật trình diễn'],
  [3,'Nêu các bước cơ bản để thưởng thức và nhận xét một tác phẩm mĩ thuật.','Quan sát tổng thể; tìm hiểu tên tác phẩm, tác giả, chất liệu, thời kì; phân tích nội dung, hình ảnh chính phụ, bố cục, màu sắc, đậm nhạt, kĩ thuật; nêu cảm nhận và ý nghĩa đối với bản thân.'],
  [3,'Trình bày cách vận dụng hình ảnh lễ hội quê hương vào thiết kế một tấm áp phích đơn giản.','Chọn hình ảnh tiêu biểu của lễ hội (múa lân, rước kiệu, đua thuyền); sắp xếp hình chính to ở trung tâm, chữ tên lễ hội rõ ràng ở trên hoặc dưới; dùng màu tươi, tương phản để nổi bật; thêm thông tin thời gian, địa điểm ngắn gọn.'],
  [3,'Kể tên một số sản phẩm mĩ thuật ứng dụng trong trường học và cho biết chúng phục vụ mục đích gì.','Bảng tin trang trí (thông báo, làm đẹp lớp), lô-gô trường (nhận diện), đồng phục (thống nhất, đẹp), trang trí sân khấu ngày hội, bìa sổ liên lạc, biển tên lớp.'],
  [4,'Vì sao các nhà thiết kế ngày nay thường tìm cảm hứng từ di sản mĩ thuật như hoa văn trống đồng, tranh dân gian thay vì chỉ sáng tạo hoàn toàn mới? Phân tích lợi ích và yêu cầu khi vận dụng.','Di sản mang vẻ đẹp đã được chọn lọc qua nhiều thế hệ, chứa đựng bản sắc dân tộc nên sản phẩm mới có chiều sâu văn hóa, dễ gây ấn tượng và khác biệt với sản phẩm nước ngoài; đồng thời giúp quảng bá, giữ gìn di sản. Tuy nhiên khi vận dụng cần hiểu đúng ý nghĩa hoa văn, cách điệu phù hợp với sản phẩm hiện đại, tránh sao chép nguyên xi hay dùng sai chỗ gây phản cảm.']
 ]);
 add(M,6,'(Bổ sung) Màu sắc và bố cục',[
  [1,'Vòng màu (vòng thuần sắc) cơ bản gồm những màu nào?','Ba màu cơ bản, ba màu thứ cấp và các màu trung gian giữa chúng','Chỉ đen và trắng','Chỉ ba màu cơ bản','Chỉ các màu lạnh'],
  [1,'Hòa sắc tương đồng được tạo ra từ những màu nào?','Các màu nằm gần nhau trên vòng màu','Các màu đối nhau trên vòng màu','Chỉ màu đen trắng','Màu bất kì không theo quy luật'],
  [1,'Trong bố cục tranh, "mảng chính" là gì?','Mảng hình thể hiện nội dung chủ yếu, được đặt ở vị trí nổi bật','Mảng ở sát mép tranh','Mảng nền trống','Mảng nhỏ nhất'],
  [1,'Bố cục hình tam giác trong tranh thường tạo cảm giác gì?','Vững chãi, ổn định','Rối loạn','Bay bổng không trọng tâm','Trống trải'],
  [2,'Khi phần lớn tranh là màu lạnh và chỉ một chi tiết nhỏ màu nóng, chi tiết đó sẽ trở thành gì?','Điểm nhấn thu hút sự chú ý','Phần bị bỏ qua','Mảng nền','Hình phụ mờ nhạt'],
  [2,'Vì sao không nên đặt hình chính ngay sát mép tranh hoặc chia tranh thành hai nửa bằng nhau?','Vì làm bố cục mất cân đối hoặc đơn điệu, hình chính bị cắt và kém nổi bật','Vì tốn màu hơn','Vì giấy sẽ rách','Vì không có lí do gì'],
  [2,'Màu sắc trong tranh có thể biểu đạt điều gì ngoài việc mô tả sự vật?','Cảm xúc, không khí, thời gian và ý tưởng của tác giả','Chỉ giá trị tiền bạc','Chỉ kích cỡ tranh','Không biểu đạt gì'],
  [3,'Nêu các dạng bố cục thường gặp và cảm giác mỗi dạng mang lại.','Bố cục tam giác: vững chãi; bố cục tròn: tập trung, êm dịu; bố cục ngang: yên tĩnh, rộng; bố cục dọc: cao, trang nghiêm; bố cục đường chéo: động, mạnh mẽ.'],
  [3,'Nêu cách chọn và phối màu cho một bức tranh đề tài "Mùa thu".','Chọn gam chủ đạo nóng ấm (vàng, cam, nâu đỏ) tương đồng gợi lá vàng; thêm một ít màu lạnh (lam, lục xám) cho trời, bóng để tương phản; phân chia đậm nhạt rõ giữa mảng chính và nền; giữ hòa sắc thống nhất.'],
  [3,'Trình bày các bước sắp xếp bố cục cho một bức tranh theo chủ đề tự chọn.','Xác định nội dung và hình chính; phác vài bố cục nhỏ thử các vị trí mảng chính, phụ; chọn bố cục có trọng tâm, cân bằng, có khoảng trống hợp lí; xác định hướng chuyển động, đường dẫn mắt; phác lên giấy chính và điều chỉnh tỉ lệ.'],
  [4,'Phân tích mối quan hệ giữa màu sắc và bố cục trong việc làm nổi bật hình chính của một bức tranh.','Bố cục xác định vị trí, kích cỡ của hình chính (thường ở khoảng gần trung tâm, to hơn hình phụ), còn màu sắc củng cố vị trí đó bằng tương phản: hình chính dùng màu mạnh, sáng hoặc đối lập với nền, hình phụ dùng màu gần với nền và nhạt hơn. Nếu bố cục đúng nhưng màu hình chính lẫn với nền thì hình chính vẫn chìm; ngược lại màu nổi mà đặt ở mép tranh thì bố cục lệch. Vì vậy hai yếu tố phải phối hợp để dẫn mắt người xem về trọng tâm.']
 ]);

 /* ===== LỚP 7 ===== */
 add(M,7,'Kiến thức tạo hình',[
  [1,'Khi vẽ tranh về di tích lịch sử, bước kí họa trực tiếp tại di tích giúp ích gì?','Ghi lại nhanh hình dáng, đặc điểm, tỉ lệ của di tích làm tư liệu sáng tác','Thay thế hoàn toàn bức tranh hoàn chỉnh','Chỉ để giải trí','Không có tác dụng'],
  [1,'Kí họa là gì?','Vẽ nhanh ghi lại những nét chính của đối tượng trong thời gian ngắn','Vẽ thật tỉ mỉ trong nhiều ngày','Tô màu tranh dân gian','In tranh từ ván khắc'],
  [1,'Trong tranh tĩnh vật, đối tượng được vẽ thường là gì?','Hoa, quả, bình lọ, đồ vật được sắp đặt','Người đang chạy','Cảnh biển rộng','Lễ hội đông người'],
  [1,'Chất liệu nào sau đây thường dùng trong hội họa truyền thống Việt Nam?','Sơn mài, lụa','Sắt thép','Nhựa composite','Kính màu'],
  [2,'Khi tạo hình bằng vật liệu sẵn có như đá, lá, vỏ sò để mô phỏng di tích, em cần chú ý điều gì?','Chọn vật liệu có hình, chất cảm phù hợp với đặc điểm di tích, bố cục cân đối','Dùng càng nhiều vật liệu càng tốt','Không cần quan sát di tích','Chỉ dùng một loại vật liệu'],
  [2,'Vẽ tranh theo hình thức "cuộc sống xưa và nay" đòi hỏi người vẽ phải làm gì?','Quan sát, so sánh và chọn hình ảnh đặc trưng của hai thời kì để đối chiếu trong tranh','Chỉ vẽ cảnh hiện tại','Chỉ chép lại ảnh cũ','Không cần tìm hiểu tư liệu'],
  [2,'Vẽ theo mẫu (vẽ tĩnh vật) rèn luyện kĩ năng gì?','Quan sát, so sánh tỉ lệ, thể hiện hình khối và đậm nhạt','Hát đúng nhịp','Chép chữ nhanh','Tính toán số liệu'],
  [3,'Nêu các bước vẽ một bài tĩnh vật đơn giản gồm lọ hoa và quả.','Quan sát, chọn góc nhìn; phác khung hình chung và vị trí từng vật; phác hình từng vật theo tỉ lệ; vẽ chi tiết, chỉnh sửa; xác định nguồn sáng, vẽ đậm nhạt hoặc lên màu từ mảng lớn đến nhỏ; hoàn thiện nền và bóng đổ.'],
  [3,'Trình bày cách thực hiện một sản phẩm mô hình di tích bằng bìa và vật liệu tái chế.','Tìm hiểu hình ảnh, đặc điểm kiến trúc di tích; phác thảo mặt chính và tỉ lệ các phần; cắt bìa tạo các khối chính (thân, mái, cột); ghép, gắn chắc; tạo chi tiết trang trí bằng giấy, dây, hạt; tô màu, tạo chất cảm bề mặt; làm đế.'],
  [3,'Kí họa và tranh hoàn chỉnh khác nhau như thế nào? Vì sao họa sĩ cần kí họa?','Kí họa vẽ nhanh, nét đơn giản, ghi đặc điểm chính; tranh hoàn chỉnh có bố cục, màu sắc, chi tiết đầy đủ. Kí họa giúp rèn quan sát, tích lũy tư liệu thực tế và ý tưởng để sáng tác tranh sinh động, chân thực.'],
  [4,'Vì sao khi sáng tác tranh về di tích, họa sĩ không chỉ chép lại hình ảnh giống thật mà còn chọn góc nhìn, lược bỏ hoặc nhấn mạnh một số chi tiết? Phân tích.','Mục tiêu của tranh là truyền đạt vẻ đẹp và cảm xúc về di tích, không phải ghi chép như ảnh chụp. Chọn góc nhìn giúp làm nổi đặc điểm kiến trúc đặc trưng; lược bỏ chi tiết vụn, nhấn mạnh mảng chính giúp bố cục rõ trọng tâm; thay đổi màu sắc, ánh sáng tạo không khí cổ kính, trang nghiêm hay tươi vui. Nhờ vậy tranh có dấu ấn cá nhân và cảm xúc, điều ảnh chụp thường không có.']
 ]);
 add(M,7,'Thường thức mĩ thuật',[
  [1,'Thời kì Phục Hưng ở châu Âu diễn ra chủ yếu vào khoảng thời gian nào?','Thế kỉ XIV – XVI','Thế kỉ XX','Thời tiền sử','Thế kỉ V trước Công nguyên'],
  [1,'Nghệ thuật Phục Hưng khởi nguồn từ đất nước nào?','I-ta-li-a','Ai Cập','Anh','Nga'],
  [1,'Kiến trúc Gô-tích (Gothic) thời trung đại châu Âu có đặc điểm nổi bật gì?','Nhà thờ cao vút với vòm nhọn, cửa kính màu lớn','Kim tự tháp bằng đá','Nhà sàn gỗ','Tháp gạch nung hình trụ'],
  [1,'Hình rồng thời Lý ở Việt Nam có đặc điểm gì?','Thân tròn trơn, uốn lượn mềm mại hình sin nhiều khúc, đầu ngẩng cao','Thân vuông góc cạnh','Có cánh lớn như chim','Thân ngắn, thẳng, mập và nhiều gai nhọn'],
  [2,'Thành tựu nổi bật của mĩ thuật thời Lý là gì?','Kiến trúc và điêu khắc Phật giáo như chùa, tượng Phật, hình rồng, hoa sen','Tranh sơn dầu','Tranh cổ động','Tượng bằng thép'],
  [2,'Ba họa sĩ – nhà điêu khắc tiêu biểu của Phục Hưng I-ta-li-a là ai?','Lê-ô-na đờ Vanh-xi, Mi-ken-lăng-giơ, Ra-pha-en','Mô-nê, Van Gốc, Pi-cát-xô','Nguyễn Phan Chánh, Tô Ngọc Vân, Trần Văn Cẩn','An-đi Oa-hôn, Đa-li'],
  [2,'Nghệ thuật Phục Hưng khác với nghệ thuật trung đại trước đó ở điểm nào?','Chú trọng tỉ lệ cơ thể người, luật xa gần, ánh sáng và vẻ đẹp con người theo khoa học','Chỉ vẽ hoa văn hình học','Không vẽ con người','Chỉ dùng màu đen trắng'],
  [3,'Nêu một số đặc điểm chính của mĩ thuật thời Phục Hưng.','Đề cao con người và khoa học; nghiên cứu giải phẫu, tỉ lệ cơ thể; áp dụng luật xa gần, sáng tối tạo khối, không gian; đề tài tôn giáo, thần thoại, chân dung; nhiều danh họa, công trình kiến trúc, điêu khắc lớn ở I-ta-li-a.'],
  [3,'Kể tên một số công trình, tác phẩm mĩ thuật Việt Nam thời Lý, Trần, Lê mà em biết.','Thời Lý: chùa Một Cột, tượng Phật A-di-đà chùa Phật Tích, chùa Dạm; thời Trần: tháp Phổ Minh, tháp Bình Sơn; thời Lê: Lam Kinh, bia Vĩnh Lăng, chạm khắc đình làng (Tây Đằng, Chu Quyến).'],
  [3,'Nêu một số đặc điểm của điêu khắc đình làng Việt Nam thời Lê trung hưng (thế kỉ XVI – XVIII).','Chạm khắc gỗ trên các bộ phận kiến trúc đình; đề tài sinh hoạt dân gian: đấu vật, chèo thuyền, uống rượu, gánh con, múa; hình khỏe khoắn, mộc mạc, hóm hỉnh, tự nhiên; thể hiện tinh thần dân gian vui tươi.'],
  [4,'So sánh mĩ thuật Phục Hưng châu Âu và mĩ thuật Việt Nam thời trung đại (Lý – Trần – Lê) về đề tài, chất liệu và tinh thần.','Phục Hưng tập trung vào con người, khoa học, tôn giáo Ki-tô và thần thoại; chất liệu sơn dầu, bích họa, đá cẩm thạch; tinh thần đề cao cá nhân, lí tưởng hóa cái đẹp cơ thể. Mĩ thuật Việt Nam trung đại gắn với Phật giáo, cung đình và làng xã; chất liệu gỗ, đá, gạch nung, gốm; tinh thần hướng đến sự hài hòa với thiên nhiên, trang trí giàu tính biểu tượng (rồng, hoa sen) và sau là tính dân gian mộc mạc ở đình làng. Hai nền mĩ thuật khác bối cảnh văn hóa nhưng đều phản ánh đời sống tinh thần của thời đại.']
 ]);
 add(M,7,'Yếu tố và nguyên lí tạo hình',[
  [1,'Nguyên lí "nhấn mạnh" trong tạo hình nhằm mục đích gì?','Làm nổi bật một yếu tố hoặc khu vực quan trọng để thu hút mắt người xem','Làm mọi phần giống nhau','Che giấu hình chính','Tô màu đều toàn tranh'],
  [1,'Tỉ lệ trong tạo hình là gì?','Mối quan hệ về kích thước giữa các phần với nhau và với tổng thể','Số màu được dùng','Độ dày của giấy','Tên của bố cục'],
  [1,'Khối trong tạo hình có thể được diễn tả trên mặt phẳng nhờ yếu tố nào?','Đậm nhạt (sáng tối)','Chữ viết','Khung tranh','Chất giấy'],
  [1,'Yếu tố không gian trong tranh thể hiện điều gì?','Cảm giác về khoảng cách, gần xa, chiều sâu giữa các hình','Số lượng hình trong tranh','Màu sắc nền','Tên tác phẩm'],
  [2,'Khi vẽ lại cùng một họa tiết với kích cỡ giảm dần theo hàng, em đã vận dụng nguyên lí nào?','Lặp lại kết hợp với nhịp điệu và tỉ lệ','Tương phản màu','Cân bằng đối xứng','Không gian xa gần'],
  [2,'Hài hòa trong tạo hình đạt được khi nào?','Các yếu tố thống nhất, bổ trợ nhau, không có phần nào gây rối hoặc lạc lõng','Mọi yếu tố đều đối lập gắt gao','Chỉ có một yếu tố duy nhất','Dùng tất cả các màu với lượng bằng nhau'],
  [2,'Chuyển động trong tranh được gợi ra bằng cách nào?','Hướng của nét, tư thế hình, sự sắp xếp lặp lại và đường dẫn mắt','Tranh được treo nghiêng','Màu đen chiếm phần lớn','Hình đặt đối xứng tuyệt đối'],
  [3,'Phân biệt hai nguyên lí "tương phản" và "hài hòa", mỗi nguyên lí cho một ví dụ vận dụng.','Tương phản là đặt yếu tố đối lập cạnh nhau để nổi bật (hình sáng trên nền tối, mảng to cạnh mảng nhỏ); hài hòa là sự ăn nhập, thống nhất giữa các yếu tố (dùng gam màu tương đồng, nét cùng kiểu). Tranh đẹp thường hài hòa tổng thể và có tương phản ở điểm nhấn.'],
  [3,'Nêu cách vận dụng yếu tố chất cảm khi làm tranh từ vật liệu tổng hợp (giấy, vải, hạt, cát).','Dùng vật liệu thô, sần (cát, hạt, vỏ) cho mặt đất, tường cổ; vật liệu mềm (vải, len) cho mây, nước; giấy bóng, nhũ cho ánh sáng; đặt chất cảm đối lập cạnh nhau để tăng tương phản; giữ số loại chất liệu vừa phải để hài hòa.'],
  [3,'Trình bày cách diễn tả khối một vật hình trụ (chiếc cốc) bằng đậm nhạt với bút chì.','Xác định nguồn sáng; phần hướng sáng để nhạt, chuyển dần sang trung gian rồi đậm ở phía khuất; mép đối diện nguồn sáng có phản quang nhạt hơn một chút; bóng đổ trên mặt bàn đậm, chuyển nhạt dần khi xa vật.'],
  [4,'Vì sao trong một tác phẩm cần có sự thống nhất (hài hòa) nhưng cũng cần có sự đa dạng (tương phản, biến đổi)? Phân tích hậu quả khi thiếu một trong hai.','Thống nhất tạo cảm giác trọn vẹn, có trật tự, giúp các yếu tố gắn thành một tổng thể; đa dạng tạo sức sống, hấp dẫn và điểm nhấn. Thiếu thống nhất, tranh rối, các phần tranh nhau, người xem không biết nhìn vào đâu; thiếu đa dạng, tranh đơn điệu, nhàm chán, không có trọng tâm. Nghệ thuật tạo hình là tìm sự cân bằng: tổng thể hài hòa về gam màu, kiểu nét, nhưng có biến đổi về to nhỏ, đậm nhạt ở những chỗ cần nhấn mạnh.']
 ]);
 add(M,7,'Thưởng thức và ứng dụng',[
  [1,'Khi thiết kế sản phẩm lưu niệm về di tích (móc khóa, bưu thiếp), hình ảnh di tích thường được xử lí như thế nào?','Cách điệu, đơn giản hóa nhưng giữ đặc điểm nhận diện','Chép y nguyên như ảnh chụp','Bỏ hẳn hình di tích','Vẽ thật nhiều chi tiết nhỏ'],
  [1,'Hình ảnh hoa sen, rồng thời Lý được ứng dụng ngày nay vào lĩnh vực nào?','Trang trí kiến trúc, lô-gô, họa tiết trang phục, sản phẩm lưu niệm','Chỉ trưng bày trong bảo tàng','Không còn được dùng','Chỉ dùng trong sách lịch sử'],
  [1,'Cửa kính màu trong nhà thờ Gô-tích gợi ý điều gì cho thiết kế hiện đại?','Dùng mảng màu trong suốt ghép bởi nét viền đen tạo hiệu ứng ánh sáng','Dùng toàn màu xám','Bỏ hết màu sắc','Chỉ dùng chất liệu gỗ'],
  [2,'Khi thưởng thức một tác phẩm điêu khắc ngoài trời, em nên quan tâm đến điều gì?','Hình khối, chất liệu, tỉ lệ với không gian xung quanh và cách tác phẩm đổi vẻ theo góc nhìn, ánh sáng','Chỉ xem tên tác giả','Chỉ xem cân nặng','Chỉ xem màu nền'],
  [2,'Thiết kế trang phục lấy cảm hứng từ họa tiết trên cửa kính màu hoặc hoa văn cổ cần đảm bảo điều gì?','Họa tiết phù hợp với dáng, chất liệu trang phục và người mặc, màu sắc hài hòa','Họa tiết càng nhiều càng tốt','Giống hệt bản gốc về kích cỡ','Không cần quan tâm người mặc'],
  [2,'Ý nghĩa của việc học sinh làm sản phẩm giới thiệu di tích quê hương là gì?','Hiểu, yêu quý, góp phần quảng bá và giữ gìn di sản','Chỉ để lấy điểm','Thay thế việc bảo vệ di tích thật','Không có ý nghĩa'],
  [3,'Nêu các bước thiết kế một tấm bưu thiếp giới thiệu di tích ở địa phương em.','Chọn di tích và hình ảnh tiêu biểu; xác định khổ bưu thiếp; phác bố cục: hình chính, tên di tích, dòng chữ ngắn; vẽ hoặc cắt dán hình cách điệu; chọn gam màu phù hợp không khí di tích; hoàn thiện, kiểm tra chữ rõ ràng.'],
  [3,'Nêu cách vận dụng hình tượng rồng hoặc hoa sen thời Lý vào thiết kế một mẫu lô-gô cho câu lạc bộ mĩ thuật.','Chọn một đặc điểm tiêu biểu (đường cong hình sin của rồng, cánh sen); đơn giản hóa thành nét, mảng cơ bản; kết hợp với chữ tên câu lạc bộ; dùng ít màu (1–2 màu), bảo đảm lô-gô rõ khi thu nhỏ và cân bằng.'],
  [3,'Khi so sánh một tác phẩm mĩ thuật xưa và một sản phẩm thiết kế hiện đại lấy cảm hứng từ nó, em sẽ nhận xét theo tiêu chí nào?','Đặc điểm nào của bản gốc được giữ lại; cách cách điệu, màu sắc, chất liệu mới; sự phù hợp với công dụng sản phẩm; tính sáng tạo và tôn trọng giá trị di sản.'],
  [4,'Vì sao sản phẩm thiết kế mang hình ảnh di tích, di sản vừa có giá trị thẩm mĩ vừa có giá trị văn hóa và kinh tế? Phân tích.','Về thẩm mĩ, hình ảnh di sản đã được chọn lọc qua thời gian, mang vẻ đẹp đặc trưng; về văn hóa, sản phẩm nhắc nhớ lịch sử, lan tỏa niềm tự hào và kiến thức về di sản tới nhiều người, nhất là qua du lịch; về kinh tế, sản phẩm lưu niệm, quà tặng gắn với di tích tạo thu nhập cho địa phương và nguồn kinh phí bảo tồn. Vì vậy cần thiết kế có trách nhiệm, đúng tinh thần di sản để giá trị được phát huy bền vững.']
 ]);
 add(M,7,'(Bổ sung) Màu sắc và bố cục',[
  [1,'Hòa sắc có gam nóng chủ đạo thường gợi không khí gì?','Ấm áp, sôi nổi, rực rỡ','Lạnh lẽo, buồn','Mờ nhạt','Không gợi gì'],
  [1,'Bố cục đường chéo trong tranh tạo cảm giác gì?','Động, mạnh mẽ, có hướng chuyển động','Yên tĩnh tuyệt đối','Nặng nề, tĩnh','Trống trải'],
  [1,'Trong tranh, khoảng trống (nền) có vai trò gì?','Làm nổi hình chính, tạo không gian và sự cân bằng cho bố cục','Không có vai trò','Chỉ để tiết kiệm màu','Làm tranh xấu đi'],
  [1,'Màu của vật khi ở xa thường có xu hướng như thế nào so với khi ở gần?','Nhạt hơn, ngả xanh lam hoặc xám, kém rõ','Đậm hơn, rực hơn','Giữ nguyên hoàn toàn','Chuyển sang màu đỏ'],
  [2,'Khi vẽ tranh đề tài "Cuộc sống xưa và nay" trong một bố cục, em có thể dùng màu sắc để phân biệt hai thời kì bằng cách nào?','Dùng hai gam màu khác nhau, ví dụ gam trầm ấm cho xưa, gam tươi sáng cho nay','Dùng cùng một màu cho cả hai','Chỉ dùng màu đen trắng cho cả hai','Không dùng màu'],
  [2,'Đường dẫn mắt trong bố cục là gì?','Hướng của các nét, mảng, màu dẫn người xem nhìn từ phần này đến phần khác của tranh','Đường kẻ khung tranh','Chữ kí tác giả','Tên tranh'],
  [2,'Vì sao họa sĩ hạn chế số lượng màu trong một bức tranh thay vì dùng tất cả các màu?','Để tranh có hòa sắc thống nhất, dễ tạo trọng tâm, tránh rối','Vì không có đủ màu','Vì màu đắt tiền','Vì quy định bắt buộc'],
  [3,'Trình bày cách xây dựng hòa sắc cho bức tranh về di tích cổ kính.','Chọn gam trầm ấm (nâu, vàng đất, xám ấm) làm chủ đạo gợi cổ kính; thêm màu lạnh (lam xám, lục xám) ở bóng, trời để tương phản nhẹ; điểm nhấn nhỏ màu tươi ở nhân vật hoặc cờ; giữ đậm nhạt rõ giữa công trình và nền.'],
  [3,'Nêu cách bố cục một bức tranh có nhiều nhân vật (ví dụ cảnh lễ hội) để không bị rối.','Chia thành nhóm chính và nhóm phụ; nhóm chính to, ở gần trung tâm, có tương phản màu mạnh; nhóm phụ nhỏ hơn, màu gần nền; dùng hướng nhìn, động tác nhân vật dẫn mắt về nhóm chính; để khoảng trống cân bằng với mảng đông người.'],
  [3,'Thế nào là nhịp điệu màu sắc trong tranh? Cho ví dụ.','Là sự lặp lại có biến đổi của một hoặc vài màu ở nhiều vị trí trong tranh, dẫn mắt và tạo thống nhất. Ví dụ: màu đỏ xuất hiện ở áo nhân vật chính, lặp lại nhỏ hơn ở cờ, đèn lồng ở xa.'],
  [4,'Phân tích vì sao cùng một bố cục nhưng khi thay đổi hòa sắc (từ gam nóng sang gam lạnh) thì cảm xúc của bức tranh thay đổi.','Màu sắc tác động trực tiếp đến cảm giác: gam nóng gợi ấm, vui, gần gũi, sôi động; gam lạnh gợi mát, tĩnh, xa xăm hay buồn. Bố cục giữ nguyên nội dung và cấu trúc hình, nhưng màu quyết định không khí, thời gian (sáng, chiều, đêm), mùa và tâm trạng. Vì vậy họa sĩ chọn hòa sắc theo ý đồ cảm xúc, không chỉ theo màu thật của sự vật; một cảnh làng quê có thể yên bình trong gam lạnh hoặc rộn ràng trong gam nóng.']
 ]);

 /* ===== LỚP 8 ===== */
 add(M,8,'Kiến thức tạo hình',[
  [1,'Theo tỉ lệ thường dùng trong mĩ thuật, chiều cao người trưởng thành bằng khoảng bao nhiêu lần chiều cao đầu?','Khoảng 7 – 7,5 lần','Khoảng 3 lần','Khoảng 12 lần','Khoảng 2 lần'],
  [1,'Khi vẽ dáng người, "trục" của cơ thể là gì?','Đường tưởng tượng chạy dọc giữa cơ thể thể hiện hướng của đầu, thân, chân','Đường viền quanh người','Bóng đổ của người','Đường chân trời'],
  [1,'Hình tượng con người trong mĩ thuật được thể hiện qua những thể loại nào?','Tranh chân dung, tranh sinh hoạt, tượng người, phù điêu','Chỉ tranh phong cảnh','Chỉ tranh tĩnh vật','Chỉ hoa văn hình học'],
  [1,'Khi tạo hình nhân vật bằng dây thép và giấy bồi, dây thép có vai trò gì?','Làm cốt (khung) định hình tư thế nhân vật','Làm màu trang trí','Làm nền tranh','Làm khung tranh'],
  [2,'Vì sao khi vẽ dáng người đang hoạt động cần xác định trục và các điểm khớp trước?','Để dáng người đúng tư thế, cân đối và có chuyển động tự nhiên','Để tô màu nhanh hơn','Để không cần quan sát mẫu','Để tiết kiệm giấy'],
  [2,'Thể hiện chủ đề "Niềm vui, hạnh phúc" bằng hình tượng con người, em cần chú ý điều gì?','Biểu cảm khuôn mặt, động tác cơ thể, sự tương tác giữa các nhân vật và màu sắc tươi sáng','Chỉ vẽ người đứng im','Vẽ càng nhiều người càng tốt','Dùng gam màu tối lạnh'],
  [2,'Tranh sinh hoạt là gì?','Tranh miêu tả hoạt động của con người trong đời sống hằng ngày, lao động, lễ hội','Tranh chỉ vẽ hoa quả','Tranh chỉ vẽ núi sông','Tranh trang trí hoa văn'],
  [3,'Nêu các bước vẽ một dáng người đang hoạt động (ví dụ đá bóng).','Quan sát hoặc tưởng tượng tư thế; vẽ trục đầu – thân – chân và vị trí các khớp; phác khối đầu, thân, tay, chân theo tỉ lệ; vẽ hình bao ngoài, trang phục; chỉnh sửa cho tự nhiên; vẽ chi tiết, đậm nhạt hoặc màu.'],
  [3,'So sánh tỉ lệ cơ thể trẻ em và người trưởng thành khi vẽ.','Trẻ em: đầu to so với thân, cơ thể cao khoảng 4 – 6 lần đầu tùy tuổi, tay chân ngắn, tròn. Người trưởng thành: cao khoảng 7 – 7,5 lần đầu, vai rộng, tay chân dài, các bộ phận thon hơn. Nắm tỉ lệ giúp vẽ đúng lứa tuổi nhân vật.'],
  [3,'Trình bày cách tạo một nhóm tượng nhỏ về chủ đề gia đình bằng đất nặn hoặc giấy bồi.','Xác định số nhân vật, tư thế, sự tương tác (nắm tay, ôm, ngồi cạnh); làm cốt từng nhân vật đúng tỉ lệ; đắp khối thân, đầu, tay chân; tạo trang phục, chi tiết khuôn mặt; sắp xếp nhóm trên một đế chung sao cho cân đối, có chính phụ.'],
  [4,'Vì sao hình tượng con người luôn là đề tài trung tâm của mĩ thuật từ thời cổ đại đến nay? Phân tích vai trò của việc nắm vững tỉ lệ và động tác trong việc thể hiện đề tài này.','Con người là chủ thể của đời sống, qua hình tượng con người nghệ sĩ nói về lao động, tình cảm, lí tưởng, lịch sử của thời đại nên đề tài này luôn giàu ý nghĩa. Để hình tượng thuyết phục, người vẽ phải nắm tỉ lệ để cơ thể cân đối, đúng lứa tuổi, và nắm động tác, trục, khớp để tư thế tự nhiên, có cảm xúc; khi đã vững, họa sĩ còn chủ động biến đổi tỉ lệ (kéo dài, phóng đại) để tạo phong cách và biểu cảm riêng.']
 ]);
 add(M,8,'Thường thức mĩ thuật',[
  [1,'Trường phái Ấn tượng ra đời ở nước nào và vào thời gian nào?','Pháp, cuối thế kỉ XIX','I-ta-li-a, thế kỉ XV','Ai Cập cổ đại','Việt Nam, thế kỉ XX'],
  [1,'Đặc điểm nổi bật của hội họa Ấn tượng là gì?','Vẽ ngoài trời, ghi lại ánh sáng và màu sắc thay đổi bằng nét bút ngắn, màu tươi','Vẽ trong xưởng với màu tối, nét tỉa kĩ','Chỉ vẽ hình học','Chỉ vẽ đen trắng'],
  [1,'Họa sĩ nào là đại diện tiêu biểu của trường phái Ấn tượng?','Clốt Mô-nê (Claude Monet)','Pi-cát-xô (Picasso)','Lê-ô-na đờ Vanh-xi','Mi-ken-lăng-giơ'],
  [1,'Trường Mĩ thuật Đông Dương, cái nôi của hội họa hiện đại Việt Nam, được thành lập năm nào?','Năm 1925','Năm 1945','Năm 1900','Năm 1975'],
  [2,'Trường phái Lập thể (đầu thế kỉ XX, tiêu biểu là Pi-cát-xô) có đặc điểm gì?','Phân tích đối tượng thành các mảng hình học, thể hiện nhiều góc nhìn cùng lúc','Vẽ ánh sáng lung linh ngoài trời','Vẽ giống như ảnh chụp','Chỉ vẽ phong cảnh'],
  [2,'Chất liệu nào được các họa sĩ Việt Nam thời Trường Mĩ thuật Đông Dương phát triển thành chất liệu hội họa độc đáo?','Sơn mài và lụa','Sơn dầu và màu nước','Chì và than','Kính và sắt'],
  [2,'Họa sĩ Nguyễn Phan Chánh nổi tiếng với chất liệu nào?','Tranh lụa','Tranh sơn dầu','Tranh khắc gỗ','Tượng đồng'],
  [3,'Kể tên một số trường phái mĩ thuật hiện đại phương Tây và mỗi trường phái nêu một họa sĩ tiêu biểu.','Ấn tượng: Mô-nê; Hậu Ấn tượng: Van Gốc, Xê-dan, Gô-ganh; Dã thú: Ma-tít-xơ; Lập thể: Pi-cát-xô, Brắc; Trừu tượng: Can-đin-xki; Siêu thực: Đa-li.'],
  [3,'Nêu một số đặc điểm của mĩ thuật Việt Nam thời kì hiện đại (từ 1925 đến nay).','Hình thành từ Trường Mĩ thuật Đông Dương, kết hợp kĩ thuật phương Tây với chất liệu, tâm hồn Việt (lụa, sơn mài); giai đoạn kháng chiến phát triển tranh cổ động, kí họa chiến trường; sau 1975 và Đổi mới đa dạng về đề tài, phong cách, chất liệu.'],
  [3,'Kể tên một số họa sĩ tiêu biểu của mĩ thuật hiện đại Việt Nam và chất liệu họ gắn bó.','Nguyễn Phan Chánh (lụa), Nguyễn Gia Trí (sơn mài), Tô Ngọc Vân (sơn dầu), Trần Văn Cẩn (sơn dầu, sơn mài), Bùi Xuân Phái (sơn dầu, đề tài phố Hà Nội), Nguyễn Sáng, Nguyễn Tư Nghiêm (sơn mài).'],
  [4,'Vì sao sự ra đời của trường phái Ấn tượng được coi là bước ngoặt của hội họa phương Tây? Phân tích ảnh hưởng của nó đến các trường phái sau.','Ấn tượng từ bỏ cách vẽ hàn lâm tỉa tót trong xưởng, đưa giá vẽ ra ngoài trời để ghi lại cảm giác tức thời về ánh sáng, màu sắc; nét bút rời, màu đặt cạnh nhau cho mắt tự hòa trộn; đề tài là đời sống đương thời. Điều này giải phóng họa sĩ khỏi việc tả thực, mở đường cho Hậu Ấn tượng nhấn mạnh cảm xúc, cấu trúc, rồi Dã thú với màu tự do, Lập thể với hình học và Trừu tượng bỏ hẳn hình, tức là cả hội họa hiện đại thế kỉ XX.']
 ]);
 add(M,8,'Yếu tố và nguyên lí tạo hình',[
  [1,'Trong tranh có nhiều nhân vật, nguyên lí "nhấn mạnh" được dùng để làm gì?','Làm nhân vật chính nổi bật hơn các nhân vật phụ','Làm mọi nhân vật giống nhau','Che khuất nhân vật chính','Bỏ nhân vật phụ'],
  [1,'Yếu tố tạo hình nào quyết định chủ yếu cảm giác về khối và không gian trong tranh đen trắng?','Đậm nhạt','Màu sắc','Chữ viết','Khung tranh'],
  [1,'Quy tắc chia ba (một phần ba) trong bố cục dùng để làm gì?','Xác định vị trí đặt hình chính sao cho bố cục hài hòa, tránh đặt chính giữa đơn điệu','Đo kích cỡ khung tranh','Tính giá tranh','Chọn màu'],
  [1,'Chuyển động trong một tác phẩm điêu khắc được tạo nên bởi điều gì?','Tư thế, hướng của các khối và đường nét của hình','Màu của bệ tượng','Tên tác phẩm','Chất liệu giấy'],
  [2,'Khi sắp xếp một nhóm người trong tranh theo hình tam giác, bố cục mang lại cảm giác gì?','Ổn định, vững chắc, tập trung vào nhân vật ở đỉnh','Rối, không trọng tâm','Bay bổng, mất thăng bằng','Trống trải'],
  [2,'Tương phản về kích cỡ giữa hình người và bối cảnh có thể dùng để diễn tả điều gì?','Sự rộng lớn của không gian hoặc tầm quan trọng của nhân vật','Chỉ để tiết kiệm giấy','Không có ý nghĩa','Để che lỗi vẽ'],
  [2,'Sự lặp lại động tác của nhiều nhân vật trong tranh (ví dụ hàng người kéo lưới) tạo nên nguyên lí nào?','Nhịp điệu','Cân bằng đối xứng','Tương phản màu','Không gian xa gần'],
  [3,'Nêu cách vận dụng nguyên lí cân bằng khi bố cục một bức tranh có nhóm nhân vật chính lệch về một bên.','Đặt ở phía đối diện một mảng hình phụ nhỏ hơn, hoặc mảng màu đậm, chi tiết thu hút để tạo đối trọng; dùng hướng nhìn, động tác nhân vật hướng về khoảng trống; cân bằng bất đối xứng dựa trên cảm giác nặng nhẹ chứ không phải kích cỡ bằng nhau.'],
  [3,'Phân tích cách sử dụng đậm nhạt để tạo trọng tâm trong một bức tranh sinh hoạt.','Đặt tương phản đậm nhạt mạnh nhất ở nhân vật chính (sáng trên nền tối hoặc ngược lại); các nhân vật phụ có tương phản nhẹ, gần với sắc độ nền; vùng xa và nền chuyển đậm nhạt êm; đường ranh đậm nhạt dẫn mắt về trọng tâm.'],
  [3,'Trình bày cách tạo nhịp điệu trong một bức tranh về lễ hội đua thuyền.','Lặp lại hình các thuyền, mái chèo, người chèo theo hướng chung nhưng thay đổi kích cỡ, khoảng cách (gần to thưa, xa nhỏ dày); lặp lại màu cờ, áo ở nhiều vị trí; nét sóng nước cùng hướng tạo đường dẫn; biến đổi nhịp bằng một thuyền dẫn đầu nổi bật.'],
  [4,'Phân tích vì sao cùng một nhóm nhân vật, nếu thay đổi tỉ lệ và vị trí của họ trong khung tranh thì ý nghĩa và cảm xúc tác phẩm có thể thay đổi.','Tỉ lệ nhân vật so với khung tranh nói lên tầm quan trọng và quan hệ với không gian: nhân vật lớn choán khung gợi gần gũi, mạnh mẽ; nhân vật nhỏ giữa không gian rộng gợi cô đơn hoặc sự hùng vĩ của thiên nhiên. Vị trí cao thấp, trung tâm hay lệch góc tạo cảm giác trang trọng, ổn định hoặc động, bất an; khoảng cách giữa các nhân vật thể hiện quan hệ gắn bó hay xa cách. Vì vậy tỉ lệ và bố cục là phương tiện biểu đạt nội dung, không chỉ là sắp xếp cho đẹp.']
 ]);
 add(M,8,'Thưởng thức và ứng dụng',[
  [1,'Nghệ thuật truyền thống Việt Nam được vận dụng vào thiết kế hiện đại thường lấy chất liệu từ đâu?','Hoa văn, hình tượng, màu sắc của gốm, tranh dân gian, chạm khắc, trang phục dân tộc','Chỉ từ tranh nước ngoài','Từ phim hoạt hình hiện đại','Từ logo thương hiệu nước ngoài'],
  [1,'Thiết kế đồ họa là gì?','Lĩnh vực sáng tạo hình ảnh, chữ, bố cục để truyền đạt thông tin như áp phích, lô-gô, bìa sách, giao diện','Chỉ vẽ tranh sơn dầu','Chỉ tạc tượng','Chỉ xây nhà'],
  [1,'Khi thưởng thức một bức tranh sơn mài Việt Nam, điểm đặc trưng về chất liệu là gì?','Mặt tranh bóng, sâu, có thể gắn vỏ trứng, vàng bạc, mài nhiều lớp','Mặt tranh thô ráp như vải bố','Vẽ trên giấy mỏng','Dùng bút sáp'],
  [1,'Tranh cổ động có đặc điểm gì?','Hình ảnh khái quát, màu mạnh, chữ ngắn gọn để truyền đạt thông điệp nhanh','Nhiều chi tiết nhỏ, màu nhạt, không có chữ','Chỉ vẽ phong cảnh','Chỉ dùng chất liệu lụa'],
  [2,'Khi thiết kế áp phích về đề tài "Vẻ đẹp đất nước", em nên ưu tiên điều gì?','Một hình ảnh tiêu biểu, nổi bật kết hợp dòng chữ ngắn, màu sắc gây ấn tượng từ xa','Thật nhiều hình ảnh nhỏ','Chữ dài nhiều dòng','Màu sắc mờ nhạt'],
  [2,'Vì sao các họa sĩ Việt Nam đầu thế kỉ XX dùng lụa, sơn mài thay cho sơn dầu để sáng tác?','Để tạo bản sắc riêng, phù hợp với thẩm mĩ và chất liệu truyền thống dân tộc','Vì sơn dầu không có ở châu Á','Vì bị cấm dùng sơn dầu','Vì lụa, sơn mài rẻ hơn'],
  [2,'Mĩ thuật đa phương tiện là gì?','Kết hợp hình ảnh, âm thanh, chuyển động, công nghệ số để tạo sản phẩm nghệ thuật','Chỉ vẽ tranh bằng bút chì','Chỉ làm tượng đá','Chỉ in tranh khắc gỗ'],
  [3,'Nêu các bước thiết kế một bìa sách giới thiệu vẻ đẹp quê hương em.','Xác định nội dung sách và đối tượng đọc; chọn hình ảnh tiêu biểu; bố cục tên sách (chữ to, rõ), tên tác giả, hình minh họa trên khổ bìa; chọn kiểu chữ, màu sắc hài hòa với hình; phác thảo vài phương án, chọn và hoàn thiện.'],
  [3,'Nêu cách vận dụng họa tiết trên trang phục dân tộc thiểu số vào thiết kế một sản phẩm hiện đại (túi, áo).','Nghiên cứu họa tiết gốc (hình học, hoa, chim) và màu đặc trưng; chọn một mô-típ, cách điệu đơn giản; sắp xếp lặp lại theo đường viền hoặc nhấn ở một vị trí; phối màu hiện đại nhưng giữ tinh thần gốc; chú ý công dụng và chất liệu sản phẩm.'],
  [3,'Khi phân tích một tác phẩm hội họa hiện đại Việt Nam, em cần đề cập những nội dung gì?','Tác giả, năm sáng tác, chất liệu; đề tài và nội dung; bố cục, hình tượng nhân vật; màu sắc, đậm nhạt, kĩ thuật thể hiện chất liệu; giá trị nghệ thuật, ý nghĩa thời đại và cảm nhận cá nhân.'],
  [4,'Vì sao tranh cổ động thời kì kháng chiến của Việt Nam vừa là tác phẩm mĩ thuật vừa là vũ khí tuyên truyền hiệu quả? Phân tích về ngôn ngữ tạo hình.','Tranh cổ động dùng hình tượng khái quát, khỏe khoắn, dễ hiểu (người chiến sĩ, người nông dân, lá cờ), bố cục đơn giản tập trung, màu tương phản mạnh (đỏ, vàng, đen trắng) và khẩu hiệu ngắn gọn nên người xem nắm được thông điệp chỉ trong vài giây, dù đặt ngoài trời, in số lượng lớn. Tính khái quát và cảm xúc mạnh của ngôn ngữ tạo hình khiến tranh cổ động có giá trị nghệ thuật riêng, đồng thời động viên tinh thần, kêu gọi hành động, góp phần vào thắng lợi chung.']
 ]);
 add(M,8,'(Bổ sung) Màu sắc và bố cục',[
  [1,'Màu sắc trong tranh Ấn tượng có đặc điểm gì?','Tươi sáng, đặt các nét màu cạnh nhau để mắt tự hòa trộn, diễn tả ánh sáng','Tối, nâu đất, tỉa kĩ','Chỉ đen trắng','Mảng phẳng không chuyển sắc'],
  [1,'Màu sắc trong tranh cổ động thường như thế nào?','Ít màu, tương phản mạnh, mảng phẳng rõ ràng','Rất nhiều màu nhạt, chuyển sắc tinh tế','Chỉ dùng màu xám','Không dùng màu'],
  [1,'Bố cục mở trong tranh là gì?','Hình ảnh kéo dài ra ngoài khung tranh, gợi không gian tiếp diễn','Hình nằm gọn hoàn toàn trong khung','Không có hình nào','Chỉ có một chấm giữa tranh'],
  [1,'Khi vẽ tranh sinh hoạt về đề tài gia đình hạnh phúc, gam màu nào thường phù hợp?','Gam ấm, tươi sáng','Gam lạnh, tối','Chỉ màu đen','Chỉ màu xám'],
  [2,'Đặt nhân vật chính ở điểm giao của các đường chia ba khung tranh thay cho chính giữa có tác dụng gì?','Bố cục sinh động, tự nhiên hơn và vẫn giữ được trọng tâm','Làm tranh mất cân đối hoàn toàn','Không có tác dụng','Làm nhân vật bị khuất'],
  [2,'Màu sắc của ánh sáng ảnh hưởng thế nào đến màu của vật trong tranh?','Vật nhận sắc của ánh sáng: nắng chiều ngả vàng cam, ánh trăng ngả lam','Màu vật không bao giờ thay đổi','Vật luôn tối hơn','Vật luôn chuyển thành trắng'],
  [2,'Khi nhiều nhân vật cùng mặc màu tương tự, hình nào sẽ trở thành trọng tâm nếu em đổi màu áo của nó sang màu bổ túc với nền?','Nhân vật được đổi màu trở thành trọng tâm','Không nhân vật nào','Nhân vật ở góc tranh','Nhân vật nhỏ nhất'],
  [3,'Nêu cách xây dựng hòa sắc và bố cục cho bức tranh "Niềm vui ngày mùa".','Gam chủ đạo vàng, cam ấm của lúa, nắng; màu lục, lam ở cây, trời tạo tương phản; nhân vật chính (người gặt, gánh lúa) đặt ở khoảng một phần ba khung với màu áo nổi bật; nhóm phụ ở xa nhỏ dần; đường bờ ruộng dẫn mắt về trọng tâm.'],
  [3,'Phân biệt bố cục mở và bố cục đóng; mỗi dạng phù hợp với đề tài nào?','Bố cục đóng: hình gọn trong khung, hướng nhìn, động tác quy về bên trong, gợi tập trung, ổn định, phù hợp chân dung, tĩnh vật, nhóm người thân mật. Bố cục mở: hình cắt bởi mép tranh, gợi không gian rộng, chuyển động, phù hợp phong cảnh, lễ hội, lao động đông người.'],
  [3,'Hãy nêu cách thể hiện ánh sáng và màu sắc theo tinh thần Ấn tượng khi vẽ cảnh sân trường buổi sáng.','Vẽ ngoài trời hoặc quan sát thực tế; chọn thời điểm nắng sớm; dùng nét bút ngắn, màu tươi đặt cạnh nhau; bóng đổ dùng màu lam, tím thay cho đen; màu vật chịu ảnh hưởng ánh nắng vàng; không viền đen, tập trung diễn tả không khí sáng trong.'],
  [4,'Phân tích vì sao các họa sĩ hiện đại thường không tô màu "đúng như thật" mà chủ động thay đổi màu để biểu đạt cảm xúc. Điều đó có làm tranh kém giá trị không?','Mục đích của hội họa hiện đại không còn là sao chép hiện thực (ảnh chụp đã làm việc đó) mà là biểu đạt cảm xúc, ý tưởng; màu sắc có sức gợi tâm trạng mạnh nên họa sĩ dùng gam nóng để diễn tả vui, sôi động, gam lạnh để diễn tả buồn, tĩnh, hay màu tương phản để tạo kịch tính. Việc thay đổi màu có chủ ý, thống nhất với bố cục và nội dung làm tranh giàu biểu cảm và cá tính, nên không làm giảm mà tăng giá trị nghệ thuật, miễn là hòa sắc vẫn hài hòa và phục vụ ý đồ rõ ràng.']
 ]);

 /* ===== LỚP 9 ===== */
 add(M,9,'Kiến thức tạo hình',[
  [1,'Nghệ thuật sắp đặt (installation) là gì?','Hình thức nghệ thuật bố trí các vật thể, chất liệu trong một không gian để tạo trải nghiệm cho người xem','Tranh vẽ trên giá vẽ truyền thống','Tượng chân dung bằng đá','Tranh in khắc gỗ dân gian'],
  [1,'Tranh in khắc nổi (như khắc gỗ, khắc cao su) tạo hình bằng cách nào?','Khắc bỏ phần không in, phần nổi còn lại nhận màu và in lên giấy','Vẽ trực tiếp bằng màu nước','Chụp ảnh rồi in bằng máy','Dán giấy màu lên bảng'],
  [1,'Nghệ thuật chữ (typography) trong thiết kế quan tâm đến điều gì?','Kiểu chữ, kích cỡ, khoảng cách và sắp xếp chữ để vừa đọc được vừa đẹp','Chỉ số lượng chữ','Chỉ màu nền','Chỉ khung tranh'],
  [1,'Khi thực hiện tác phẩm bằng kĩ thuật số (vẽ trên máy tính, máy tính bảng), người vẽ dùng công cụ nào?','Phần mềm đồ họa với bút vẽ điện tử hoặc chuột','Bút sáp và giấy vẽ','Đất nặn','Ván khắc gỗ'],
  [2,'Điểm khác biệt giữa tranh in khắc nổi và in độc bản là gì?','In khắc nổi có khuôn nên in được nhiều bản giống nhau; in độc bản chỉ cho một bản duy nhất','In độc bản luôn nhiều màu hơn','In khắc nổi không cần màu','Hai kĩ thuật hoàn toàn giống nhau'],
  [2,'Khi sáng tác tranh bằng kĩ thuật số, ưu điểm so với chất liệu truyền thống là gì?','Dễ chỉnh sửa, thử nhiều phương án màu, sao lưu và chia sẻ nhanh','Không cần ý tưởng và bố cục','Luôn đẹp hơn tranh vẽ tay','Không cần học về màu sắc'],
  [2,'Tạo hình nhân vật cho truyện tranh, hoạt hình cần chú ý điều gì?','Đặc điểm nhận diện rõ, tỉ lệ nhất quán ở mọi góc nhìn và biểu cảm phong phú','Mỗi khung vẽ nhân vật một kiểu khác nhau','Không cần biểu cảm','Chỉ vẽ một góc nhìn'],
  [3,'Nêu các bước thực hiện một bức tranh in khắc nổi trên tấm cao su hoặc xốp.','Vẽ phác thảo và chuyển hình (lật ngược) lên tấm khắc; dùng dao khắc bỏ phần không in, chú ý an toàn; lăn màu đều lên bề mặt nổi; đặt giấy, xoa ép đều; nhấc ra, để khô; có thể in nhiều bản hoặc nhiều màu bằng nhiều bản khắc.'],
  [3,'Trình bày quy trình thiết kế một nhân vật hoạt hình đơn giản.','Xác định tính cách, vai trò nhân vật; phác nhiều dáng từ hình cơ bản; chọn tỉ lệ (đầu to với nhân vật ngộ nghĩnh); thiết kế trang phục, màu sắc nhận diện; vẽ nhân vật ở các góc (trước, nghiêng, sau) và các biểu cảm; thống nhất bảng màu.'],
  [3,'Nghệ thuật sắp đặt khác tượng tròn truyền thống ở điểm nào?','Sắp đặt sử dụng nhiều vật thể, chất liệu đa dạng (kể cả đồ vật có sẵn, ánh sáng, âm thanh), gắn với một không gian cụ thể và người xem có thể đi vào, tương tác; tượng tròn là một khối hoàn chỉnh, độc lập, xem từ bên ngoài.'],
  [4,'Vì sao kĩ thuật số không thay thế hoàn toàn các chất liệu tạo hình truyền thống dù có nhiều ưu điểm? Phân tích mối quan hệ giữa hai hình thức này.','Chất liệu truyền thống cho chất cảm thật (độ bóng sơn mài, nét bút trên lụa, vân gỗ bản khắc), tính duy nhất và trải nghiệm tay chạm vật liệu mà màn hình không có; kĩ thuật số mạnh về tốc độ, chỉnh sửa, lan truyền. Nghệ sĩ ngày nay thường kết hợp: phác thảo và thử màu trên máy rồi thực hiện bằng chất liệu thật, hoặc số hóa tác phẩm thật để quảng bá. Hai hình thức bổ sung cho nhau và cùng dựa trên kiến thức tạo hình cơ bản như bố cục, màu sắc, hình khối.']
 ]);
 add(M,9,'Thường thức mĩ thuật',[
  [1,'Nghệ thuật Pốp (Pop Art) ra đời vào khoảng thời gian nào?','Thập niên 1950 – 1960','Thế kỉ XV','Cuối thế kỉ XIX','Thời cổ đại'],
  [1,'Pop Art lấy chất liệu, hình ảnh từ đâu?','Văn hóa đại chúng: quảng cáo, truyện tranh, sản phẩm tiêu dùng, ngôi sao giải trí','Thần thoại Hy Lạp','Tranh hang động','Kinh Phật'],
  [1,'Nghệ sĩ nào là đại diện tiêu biểu của Pop Art?','An-đi Oa-hôn (Andy Warhol)','Mô-nê','Lê-ô-na đờ Vanh-xi','Nguyễn Gia Trí'],
  [1,'Nghệ thuật đương đại là thuật ngữ chỉ nghệ thuật của thời kì nào?','Từ khoảng nửa sau thế kỉ XX đến nay','Thời Phục Hưng','Thời cổ đại','Thời tiền sử'],
  [2,'Đặc điểm chung của nghệ thuật đương đại là gì?','Đa dạng về hình thức (sắp đặt, trình diễn, video, kĩ thuật số), nhấn mạnh ý tưởng và sự tương tác với người xem','Chỉ vẽ tranh phong cảnh bằng sơn dầu','Tuân theo quy tắc hàn lâm chặt chẽ','Chỉ dùng đá và đồng'],
  [2,'Nghệ thuật trình diễn (performance art) có đặc điểm gì?','Nghệ sĩ dùng chính cơ thể, hành động trong thời gian và không gian cụ thể làm tác phẩm','Chỉ là tranh treo tường','Là tượng đá ngoài trời','Là tranh in dân gian'],
  [2,'Nghệ thuật đương đại Việt Nam phát triển mạnh từ giai đoạn nào?','Sau Đổi mới (từ cuối thập niên 1980), khi giao lưu quốc tế mở rộng','Thời Lý','Thời Trường Mĩ thuật Đông Dương mới thành lập','Thời tiền sử'],
  [3,'Nêu một số hình thức của nghệ thuật đương đại và đặc điểm ngắn gọn của mỗi hình thức.','Sắp đặt: bố trí vật thể trong không gian; trình diễn: hành động của nghệ sĩ là tác phẩm; video art: dùng hình ảnh động; nghệ thuật đường phố (graffiti): vẽ trên tường nơi công cộng; nghệ thuật kĩ thuật số: sáng tác bằng công nghệ; nghệ thuật khái niệm: đặt ý tưởng lên hàng đầu.'],
  [3,'So sánh Pop Art với hội họa Ấn tượng về đề tài và cách thể hiện.','Ấn tượng (cuối thế kỉ XIX) vẽ phong cảnh, sinh hoạt với ánh sáng tự nhiên, nét bút rời, màu tươi, vẽ tay. Pop Art (1950 – 1960) lấy hình ảnh tiêu dùng, quảng cáo, truyện tranh; mảng màu phẳng, rực, đường viền rõ, dùng kĩ thuật in lưới nhân bản; mang tính phê phán hoặc tôn vinh văn hóa đại chúng.'],
  [3,'Nêu một số đặc điểm của mĩ thuật Việt Nam đương đại.','Đa dạng về chất liệu và hình thức (sơn mài, sơn dầu bên cạnh sắp đặt, trình diễn, video, kĩ thuật số); đề tài mở rộng về đời sống đô thị, môi trường, bản sắc; nhiều nghệ sĩ tham gia triển lãm quốc tế; vẫn khai thác giá trị truyền thống theo cách mới.'],
  [4,'Vì sao nghệ thuật đương đại thường gây tranh cãi về việc "có phải là nghệ thuật không"? Theo em, nên tiếp cận một tác phẩm đương đại như thế nào?','Nghệ thuật đương đại đặt ý tưởng và trải nghiệm cao hơn kĩ năng tả thực, sử dụng đồ vật thường ngày, hành động, công nghệ nên khác xa quan niệm quen thuộc về tranh, tượng đẹp; người xem thiếu thông tin dễ thấy khó hiểu. Khi tiếp cận, nên tìm hiểu bối cảnh, ý tưởng của nghệ sĩ, chất liệu và cách tác phẩm tương tác với không gian, người xem; mở lòng cảm nhận trước khi phán xét, đồng thời vẫn có quyền đánh giá dựa trên tính sáng tạo, ý nghĩa và sự chân thành của tác phẩm.']
 ]);
 add(M,9,'Yếu tố và nguyên lí tạo hình',[
  [1,'Trong thiết kế bao bì, nguyên lí nào giúp người mua nhận ra sản phẩm nhanh từ xa?','Nhấn mạnh (điểm nhấn) và tương phản','Dàn đều mọi chi tiết','Dùng chữ thật nhỏ','Màu nhạt đồng đều'],
  [1,'Lưới bố cục trong thiết kế đồ họa dùng để làm gì?','Căn chỉnh, sắp xếp chữ và hình thống nhất, cân đối trên trang','Tô màu nền','Vẽ chân dung','Tính giá sản phẩm'],
  [1,'Trong tác phẩm sắp đặt, yếu tố tạo hình "không gian" có vai trò gì?','Là thành phần của tác phẩm, quyết định cách bố trí và cách người xem trải nghiệm','Không có vai trò','Chỉ là chỗ để treo tranh','Chỉ là nền trắng'],
  [1,'Nguyên lí lặp lại trong thiết kế họa tiết vải nhằm mục đích gì?','Tạo mô-típ liên tục, thống nhất trên bề mặt lớn','Làm mỗi chỗ một kiểu khác nhau','Làm vải rách','Giảm số màu về một'],
  [2,'Khi thiết kế một bộ nhận diện (lô-gô, danh thiếp, bao bì), yếu tố nào cần được giữ thống nhất?','Màu sắc chủ đạo, kiểu chữ và hình biểu tượng','Kích cỡ giấy duy nhất','Chỉ tên người thiết kế','Không cần thống nhất'],
  [2,'Tỉ lệ giữa phần chữ và phần hình trên một áp phích ảnh hưởng đến điều gì?','Sự rõ ràng của thông điệp và sức hút thị giác','Giá in áp phích','Độ dày giấy','Không ảnh hưởng'],
  [2,'Trong một tác phẩm trừu tượng không có hình cụ thể, người xem cảm nhận tác phẩm qua yếu tố nào?','Màu sắc, nét, mảng, nhịp điệu và cân bằng của bố cục','Tên nhân vật','Cốt truyện','Chữ viết trong tranh'],
  [3,'Nêu cách vận dụng nguyên lí tương phản và nhấn mạnh khi thiết kế bao bì cho một sản phẩm nông sản địa phương.','Chọn hình ảnh sản phẩm hoặc biểu tượng địa phương làm điểm nhấn, đặt ở vị trí trung tâm phía trên; tên sản phẩm chữ to, màu tương phản với nền; nền dùng gam gợi thiên nhiên, mộc mạc; thông tin phụ chữ nhỏ, màu gần nền; hạn chế 2–3 màu chính.'],
  [3,'Trình bày cách sắp xếp một tác phẩm sắp đặt từ vật liệu tái chế về đề tài bảo vệ môi trường trong không gian lớp học.','Xác định thông điệp; chọn vật liệu (chai nhựa, túi ni-lông, giấy); quyết định hình thức (treo, xếp khối, trải sàn) phù hợp không gian; tạo điểm nhấn bằng khối lớn hoặc màu nổi; tận dụng ánh sáng; bố trí lối đi để người xem tương tác; ghi bảng giới thiệu ngắn.'],
  [3,'Phân tích vai trò của nhịp điệu và cân bằng trong thiết kế họa tiết trang trí trên vải.','Nhịp điệu nhờ lặp lại mô-típ theo hàng, ô, so le làm họa tiết liên tục, sinh động; biến đổi kích cỡ hoặc màu tránh đơn điệu. Cân bằng về mật độ và màu giữa họa tiết và nền giúp vải không bị nặng một chỗ, dễ ứng dụng cho trang phục; hai nguyên lí phối hợp tạo họa tiết đẹp và dễ sản xuất.'],
  [4,'Vì sao các yếu tố và nguyên lí tạo hình học ở trường vẫn là nền tảng cho cả nghệ thuật đương đại và thiết kế hiện đại dù hình thức của chúng rất mới? Phân tích bằng ví dụ.','Dù chất liệu, công nghệ thay đổi, tác phẩm vẫn tác động đến người xem qua mắt nhìn, tức qua hình, màu, khối, không gian và cách tổ chức chúng. Một tác phẩm sắp đặt cần cân bằng khối trong không gian, có điểm nhấn và nhịp điệu để dẫn người xem; một giao diện ứng dụng cần tương phản chữ nền, tỉ lệ, lưới thống nhất để dễ dùng; một đoạn phim hoạt hình cần hòa sắc và bố cục từng khung. Hiểu nguyên lí giúp người sáng tạo chủ động phá vỡ quy tắc có ý đồ chứ không làm tùy tiện.']
 ]);
 add(M,9,'Thưởng thức và ứng dụng',[
  [1,'Ngành nghề nào sau đây thuộc lĩnh vực mĩ thuật ứng dụng?','Thiết kế đồ họa, thiết kế thời trang, thiết kế nội thất','Bác sĩ, kĩ sư xây dựng','Kế toán, ngân hàng','Lái xe, đầu bếp'],
  [1,'Người làm nghề thiết kế thời trang cần những kiến thức, kĩ năng mĩ thuật nào?','Hiểu màu sắc, tỉ lệ cơ thể, vẽ phác thảo mẫu, chất liệu vải','Chỉ cần biết may','Chỉ cần biết bán hàng','Không cần kiến thức mĩ thuật'],
  [1,'Kiến trúc sư làm công việc gì?','Thiết kế không gian, hình khối công trình vừa đẹp vừa tiện dụng, an toàn','Vẽ tranh lụa','Làm tượng gỗ dân gian','In tranh dân gian'],
  [1,'Ngành mĩ thuật đa phương tiện đào tạo người làm việc trong lĩnh vực nào?','Hoạt hình, kĩ xảo, thiết kế game, đồ họa động, giao diện số','Nông nghiệp','Y tế','Giao thông đường bộ'],
  [2,'Khi định hướng chọn nghề liên quan đến mĩ thuật, em nên dựa vào điều gì?','Sở thích, năng lực bản thân, nhu cầu xã hội và tìm hiểu kĩ công việc thực tế của nghề','Chỉ vì bạn bè chọn','Chỉ vì nghề đó đang nổi','Không cần tìm hiểu'],
  [2,'Vì sao nhà thiết kế đồ họa cần hiểu về tâm lí người xem và thông điệp sản phẩm?','Vì thiết kế phải truyền đạt đúng thông tin, gây ấn tượng và thuyết phục đối tượng cụ thể','Vì để vẽ nhanh hơn','Vì để không cần phần mềm','Vì chỉ cần đẹp theo ý mình'],
  [2,'Tổ chức một triển lãm sản phẩm mĩ thuật của lớp cuối năm có ý nghĩa gì?','Tổng kết, chia sẻ kết quả học tập, rèn kĩ năng trưng bày, giới thiệu và nhận xét tác phẩm','Chỉ để trang trí lớp','Thay cho kiểm tra toán','Không có ý nghĩa'],
  [3,'Kể tên một số ngành nghề liên quan đến mĩ thuật và cho biết công việc chính của hai ngành trong số đó.','Họa sĩ, nhà điêu khắc, kiến trúc sư, nhà thiết kế đồ họa, thiết kế thời trang, thiết kế nội thất, họa sĩ hoạt hình, nhiếp ảnh gia, giáo viên mĩ thuật, giám tuyển, phục chế di sản. Ví dụ: thiết kế đồ họa tạo lô-gô, áp phích, giao diện; thiết kế nội thất bố trí không gian, màu sắc, đồ đạc trong nhà.'],
  [3,'Nêu các bước tổ chức một triển lãm nhỏ trưng bày sản phẩm mĩ thuật của lớp.','Chọn chủ đề và sản phẩm; lập kế hoạch, phân công; thiết kế không gian, cách treo, đặt theo nhóm chủ đề hoặc chất liệu, ngang tầm mắt; làm nhãn tên tác phẩm, tác giả; thiết kế áp phích, thư mời; tổ chức khai mạc, giới thiệu, thu nhận ý kiến; đánh giá sau triển lãm.'],
  [3,'Em thích một nghề thuộc lĩnh vực mĩ thuật. Hãy nêu nghề đó, công việc cụ thể và những môn học, kĩ năng em cần rèn luyện.','HS nêu một nghề (ví dụ thiết kế đồ họa): công việc tạo lô-gô, bao bì, áp phích, giao diện; cần rèn vẽ phác thảo, hiểu màu sắc, bố cục, chữ, sử dụng phần mềm đồ họa, kĩ năng giao tiếp với khách hàng, cập nhật xu hướng; học tốt Mĩ thuật, Tin học, Ngữ văn.'],
  [4,'Vì sao trong xã hội hiện đại, các ngành nghề liên quan đến mĩ thuật ứng dụng ngày càng phát triển và cần nhiều nhân lực? Phân tích và liên hệ với việc học Mĩ thuật ở trường.','Mọi sản phẩm, dịch vụ ngày nay đều cần hình ảnh đẹp để cạnh tranh: bao bì, quảng cáo, giao diện ứng dụng, phim, game, không gian sống; kinh tế sáng tạo và công nghệ số mở ra nhiều việc làm mới như thiết kế trải nghiệm người dùng, đồ họa động, hoạt hình. Vì vậy người có nền tảng thẩm mĩ, tư duy sáng tạo và kĩ năng tạo hình có nhiều cơ hội. Việc học Mĩ thuật ở trường không chỉ để vẽ đẹp mà rèn quan sát, tư duy hình ảnh, sáng tạo và cảm thụ cái đẹp, là nền tảng cho nhiều nghề và cho đời sống văn hóa của mỗi người.']
 ]);
 add(M,9,'(Bổ sung) Màu sắc và bố cục',[
  [1,'Màu sắc trong Pop Art có đặc điểm gì?','Rực rỡ, phẳng, tương phản mạnh, thường là màu công nghiệp','Trầm, nâu đất, chuyển sắc tinh tế','Chỉ đen trắng','Mờ nhạt, loang'],
  [1,'Bảng màu trong thiết kế là gì?','Bộ màu được chọn giới hạn dùng thống nhất cho một sản phẩm hoặc bộ nhận diện','Hộp màu nước của học sinh','Màu của giấy in','Tên của một phần mềm'],
  [1,'Khoảng trắng (không gian âm) trong thiết kế đồ họa có tác dụng gì?','Giúp mắt nghỉ, làm nổi nội dung chính và bố cục thoáng, sang trọng','Là phần bị bỏ phí','Làm thiết kế xấu đi','Không có tác dụng'],
  [1,'Màu sắc trong thiết kế nhận diện thương hiệu có vai trò gì?','Tạo ấn tượng, gợi tính cách thương hiệu và giúp nhận ra sản phẩm nhanh','Chỉ để lấp kín bề mặt','Không có vai trò','Chỉ phụ thuộc máy in'],
  [2,'Khi thiết kế áp phích về môi trường, gam màu nào thường được dùng và vì sao?','Gam lục, lam gợi thiên nhiên, kết hợp điểm nhấn tương phản để cảnh báo','Toàn màu hồng vì dễ thương','Chỉ màu đen vì nghiêm túc','Màu nào cũng được'],
  [2,'Hệ thống phân cấp thị giác trong bố cục thiết kế là gì?','Sắp xếp các thành phần theo mức quan trọng để người xem đọc đúng thứ tự: tiêu đề, hình, thông tin phụ','Xếp mọi thành phần bằng nhau','Chỉ dùng một kiểu chữ','Tên một trường phái hội họa'],
  [2,'Vì sao thiết kế trên màn hình (giao diện, mạng xã hội) cần chú ý độ tương phản màu chữ và nền?','Để chữ dễ đọc trên nhiều thiết bị, kể cả người kém thị lực','Để tốn ít pin','Để in ra rẻ hơn','Không cần chú ý'],
  [3,'Nêu cách xây dựng bảng màu cho bộ nhận diện của một câu lạc bộ trong trường.','Xác định tính cách câu lạc bộ (năng động, sáng tạo, nghiêm túc); chọn 1 màu chính thể hiện tính cách, 1–2 màu phụ hài hòa hoặc tương phản làm điểm nhấn, 1 màu trung tính cho nền, chữ; thử trên lô-gô, áp phích, áo; kiểm tra độ tương phản và sự thống nhất.'],
  [3,'Trình bày cách bố cục một trang bìa tạp chí hoặc bài đăng mạng xã hội giới thiệu sự kiện của trường.','Xác định thông tin bắt buộc (tên sự kiện, thời gian, địa điểm); chọn một hình ảnh chủ đạo; đặt tiêu đề to ở vị trí ưu tiên theo lưới, thông tin phụ nhỏ hơn; dùng khoảng trắng tách các nhóm; màu thống nhất với nhận diện trường; kiểm tra khi thu nhỏ trên điện thoại.'],
  [3,'So sánh cách dùng màu sắc trong hội họa (tranh) và trong thiết kế đồ họa (áp phích, bao bì).','Hội họa dùng màu để biểu đạt cảm xúc, ánh sáng, không gian, có thể chuyển sắc phong phú tùy ý họa sĩ. Thiết kế đồ họa dùng màu có mục đích truyền thông: giới hạn bảng màu, chú ý nhận diện thương hiệu, độ tương phản để đọc được, tâm lí người dùng, khả năng in ấn và hiển thị trên màn hình.'],
  [4,'Phân tích vì sao trong thiết kế đồ họa hiện đại, "ít mà đủ" (bố cục tối giản, ít màu, nhiều khoảng trắng) thường hiệu quả hơn bố cục nhiều hình, nhiều màu.','Người xem tiếp nhận thông tin rất nhanh và trong môi trường đầy hình ảnh cạnh tranh; bố cục tối giản tạo phân cấp thị giác rõ, mắt đi thẳng đến thông điệp chính, khoảng trắng làm nổi điểm nhấn và tạo cảm giác tin cậy, hiện đại. Nhiều hình, nhiều màu làm các yếu tố tranh nhau, tương phản bị triệt tiêu, khó đọc và dễ bị bỏ qua, nhất là trên màn hình nhỏ. Tuy nhiên tối giản phải đi cùng ý tưởng mạnh và lựa chọn chính xác từng yếu tố, nếu không sẽ thành trống rỗng, thiếu thông tin.']
 ]);
})();
