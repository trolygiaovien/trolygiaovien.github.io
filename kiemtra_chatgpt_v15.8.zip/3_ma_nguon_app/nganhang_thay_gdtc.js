/* NGÂN HÀNG GIÁO DỤC THỂ CHẤT – LỚP 2–9 — bù câu đặc thù theo lớp. Câu hỏi nguyên bản, bám SGK Kết nối tri thức. */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Giáo dục thể chất';
 /* Bảo đảm chủ đề tồn tại đúng tên (tránh khớp mờ giữa "Sức khỏe và vận động" và "(Bổ sung) Sức khỏe và vận động") */
 function pre(lop,cd){
  if(!NH[M])NH[M]={};
  if(!Array.isArray(NH[M][lop]))NH[M][lop]=[];
  if(!NH[M][lop].some(function(x){return x.cd===cd;}))NH[M][lop].push({cd:cd,q:[]});
 }
 [7,8,9].forEach(function(l){pre(l,'Sức khỏe và vận động');pre(l,'(Bổ sung) Sức khỏe và vận động');});

 /* ===== LỚP 2 ===== */
 add(M,2,'Đội hình đội ngũ',[
  [1,'Khi điểm số theo chu kì 1–2 trong hàng dọc, bạn đứng ở vị trí thứ ba sẽ hô số nào?','1','2','3','Không hô'],
  [2,'Khi biến đổi từ đội hình một hàng dọc thành hai hàng dọc, những bạn vừa điểm số 2 sẽ di chuyển như thế nào?','Bước sang bên trái (hoặc bên phải theo chỉ dẫn) một bước để đứng thành hàng mới','Chạy lên đứng trước hàng','Đứng yên tại chỗ','Quay đằng sau'],
  [3,'Nêu các bước để lớp chuyển từ đội hình hàng ngang thành đội hình vòng tròn theo khẩu lệnh của giáo viên.','Giáo viên hô khẩu lệnh "Thành vòng tròn – đi thường… bước!"; bạn đứng đầu hàng đi vòng theo chiều tay trái (hoặc theo chỉ dẫn), các bạn khác nối theo sau giữ đúng khoảng cách một cánh tay; khi hai đầu hàng gặp nhau giáo viên hô "Đứng lại – đứng!" và cả lớp quay mặt vào tâm vòng tròn.']
 ]);
 add(M,2,'Vệ sinh và an toàn trong tập luyện',[
  [1,'Trước giờ học ở sân trường, nếu thấy trên sân có mảnh thủy tinh hoặc đá nhọn, em cần làm gì?','Báo ngay cho thầy cô để dọn trước khi tập','Tránh ra chỗ khác rồi tập tiếp một mình','Tự nhặt bằng tay rồi vứt sang chỗ khác','Không cần quan tâm'],
  [2,'Khi tập ném bóng bằng hai tay ở lớp 2, vì sao các bạn phải đứng cùng một hàng và ném về cùng một hướng?','Để bóng không bay trúng bạn khác, bảo đảm an toàn','Để ném xa hơn','Để dễ nhặt bóng hơn','Để giáo viên dễ chấm điểm'],
  [3,'Sau giờ học thể dục ngoài trời, em cần làm những việc vệ sinh cá nhân nào trước khi vào lớp học tiếp?','Rửa tay, rửa mặt bằng nước sạch; lau khô mồ hôi, thay hoặc chỉnh lại quần áo gọn gàng; uống một ít nước; cất dụng cụ đúng chỗ rồi mới vào lớp.']
 ]);
 add(M,2,'Vận động cơ bản và trò chơi',[
  [1,'Khi thực hiện tư thế đứng kiễng gót, trọng tâm cơ thể dồn vào bộ phận nào?','Nửa trước bàn chân (mũi chân)','Gót chân','Mép ngoài bàn chân','Đầu gối'],
  [2,'Khi tung và bắt bóng bằng hai tay, lúc bắt bóng em cần làm gì để bóng không rơi?','Mắt nhìn theo bóng, hai tay đón bóng rồi kéo nhẹ về trước ngực','Nhắm mắt, giơ hai tay lên thật cao','Đứng thẳng chân, hai tay để sát người','Quay lưng lại với bóng'],
  [3,'Trình bày cách thực hiện động tác đi kiễng gót theo đường kẻ thẳng ở lớp 2.','Đứng ở đầu đường kẻ, mắt nhìn phía trước; kiễng hai gót lên, trọng tâm dồn vào mũi chân; bước đi nhẹ, hai chân luôn đặt trên đường kẻ; thân người thẳng, hai tay dang ngang hoặc chống hông để giữ cân bằng; đi hết đường kẻ thì hạ gót về tư thế đứng bình thường.']
 ]);
 add(M,2,'Thói quen vận động hằng ngày',[
  [1,'Buổi sáng sau khi thức dậy, hoạt động vận động nào phù hợp nhất với học sinh lớp 2?','Tập vài động tác thể dục buổi sáng như vươn thở, tay, chân','Chạy thật nhanh ngay khi vừa rời giường','Ngồi xem ti vi để tỉnh ngủ','Nằm thêm trên giường chơi điện thoại'],
  [2,'Giờ ra chơi, em nên chọn hoạt động nào để vừa vui vừa có lợi cho sức khỏe?','Chơi nhảy dây, đá cầu, chơi trò chơi vận động với bạn','Ngồi một chỗ chơi trò chơi trên điện thoại','Chạy đuổi nhau trên cầu thang','Đứng ở hành lang xem bạn chơi'],
  [3,'Em hãy kể ba việc vận động em có thể tự làm mỗi ngày ở nhà và nêu lợi ích của một việc trong số đó.','Ví dụ: tập thể dục buổi sáng; đi bộ cùng bố mẹ sau bữa tối; giúp quét nhà, tưới cây, dọn đồ chơi. Lợi ích: tập thể dục buổi sáng giúp cơ thể tỉnh táo, dẻo dai, học tập tập trung hơn.']
 ]);

 /* ===== LỚP 3 ===== */
 add(M,3,'Đội hình đội ngũ',[
  [1,'Khi thực hiện động tác "Đằng sau – quay!", em quay người theo hướng nào và dùng chân nào làm trụ?','Quay về bên phải 180 độ, gót chân phải và mũi chân trái làm trụ','Quay về bên trái 90 độ, chân trái làm trụ','Quay về bên phải 90 độ, cả hai chân nhảy lên','Quay tùy ý, miễn nhìn về phía sau'],
  [2,'Khi đi đều, chân nào bước ra trước ở nhịp "một" và tay vung như thế nào?','Chân trái bước trước, tay phải vung ra trước, tay trái vung ra sau','Chân phải bước trước, hai tay cùng vung ra trước','Chân trái bước trước, hai tay giữ sát thân','Chân nào cũng được, tay vung tự do'],
  [3,'Hãy mô tả cách lớp em chuyển từ đội hình một hàng ngang thành đội hình một hàng dọc theo khẩu lệnh.','Giáo viên hô "Bên phải (hoặc bên trái) – quay!" để cả hàng ngang quay cùng một hướng; sau khi quay, hàng ngang trở thành hàng dọc; bạn đầu hàng đứng yên làm chuẩn, các bạn còn lại dóng theo, giữ khoảng cách một cánh tay với bạn phía trước.']
 ]);
 add(M,3,'Vệ sinh và an toàn trong tập luyện',[
  [1,'Khi tập bài thể dục với vòng, trước khi tập em cần kiểm tra vòng như thế nào?','Vòng không nứt, không gãy, không có cạnh sắc','Vòng càng to càng tốt','Vòng phải có màu giống nhau','Không cần kiểm tra'],
  [2,'Khi nhảy dây cá nhân trong sân, vì sao em cần đứng cách xa bạn khác ít nhất một sải tay?','Để dây không quất vào bạn và không bị vướng dây vào nhau','Để giáo viên dễ quan sát','Để nhảy được nhiều lần hơn','Để dễ đếm số lần nhảy'],
  [3,'Khi tập bài thể dục với vòng theo đội hình hàng ngang, em cần sắp xếp chỗ đứng và thực hiện động tác như thế nào để không va vào bạn?','Dàn hàng với giãn cách đủ rộng (ít nhất một sải tay cả hai bên); xác định không gian động tác đưa vòng lên cao, sang ngang, xuống thấp trước khi tập; thực hiện đúng nhịp hô, không tự ý xoay người hay di chuyển khỏi vị trí; cầm vòng chắc tay, không tung vòng.']
 ]);
 add(M,3,'Vận động cơ bản và trò chơi',[
  [1,'Trong bài thể dục với vòng, khi thực hiện động tác vươn thở, vòng được đưa lên vị trí nào lúc hít vào?','Đưa vòng lên cao trên đầu, hai tay thẳng','Đặt vòng xuống đất','Giữ vòng sát ngực','Đưa vòng ra sau lưng'],
  [2,'Khi nhảy dây cá nhân kiểu chụm hai chân, dây được quay bằng bộ phận nào của tay?','Chủ yếu bằng cổ tay, khuỷu tay hơi co','Bằng cả cánh tay vung thật mạnh','Bằng vai, hai tay thẳng','Bằng ngón tay, giữ tay cao ngang đầu'],
  [3,'Em hãy mô tả cách thực hiện động tác bật xa tại chỗ (chuẩn bị, bật, tiếp đất).','Chuẩn bị: hai chân đứng rộng bằng vai sát vạch, gối khuỵu, thân hơi ngả trước, hai tay đưa ra sau. Bật: hai chân đạp mạnh xuống đất, duỗi gối, đồng thời vung hai tay từ sau ra trước lên cao để bật người về trước. Tiếp đất: chụm hai chân, khuỵu gối để giảm chấn, hai tay đưa ra trước giữ cân bằng, không ngã về sau.']
 ]);
 add(M,3,'Thói quen vận động hằng ngày',[
  [1,'Trò chơi nào dưới đây giúp rèn luyện sự khéo léo và phối hợp tay – mắt?','Tung bắt bóng với bạn','Đứng xem đá bóng','Ngồi nghe nhạc','Nằm đọc truyện'],
  [2,'Vì sao sau khi ăn no em không nên chạy nhảy ngay?','Dạ dày đang làm việc, vận động mạnh dễ gây đau bụng, buồn nôn','Sau khi ăn cơ thể quá khỏe nên dễ bị ngã','Chạy nhảy làm thức ăn ngon hơn','Vì không có ai chơi cùng'],
  [3,'Hãy lập bảng theo dõi vận động trong một tuần của em (ghi hoạt động và thời gian mỗi ngày) và cho biết em cần thay đổi gì nếu có ngày không vận động.','Bảng gồm 7 ngày, mỗi ngày ghi hoạt động (thể dục sáng, nhảy dây, đá cầu, đi bộ, giúp việc nhà…) và thời gian (ví dụ 15–30 phút). Nếu có ngày trống, cần bổ sung hoạt động đơn giản như tập thể dục buổi sáng hoặc đi bộ sau bữa tối để bảo đảm ngày nào cũng vận động.']
 ]);

 /* ===== LỚP 4 ===== */
 add(M,4,'Đội hình đội ngũ',[
  [1,'Khi đi đều mà bước sai nhịp (chân phải rơi vào nhịp "một"), em đổi chân bằng cách nào?','Bước thêm một bước ngắn đệm để chân trái trở lại nhịp "một"','Dừng hẳn lại rồi đi tiếp','Nhảy lên bằng hai chân','Đi lùi một bước'],
  [2,'Khi đi đều vòng bên trái, bạn đứng ở hàng bên trái (sát tâm vòng) cần bước như thế nào?','Bước ngắn hơn và giữ nhịp để hàng đi đều, không xô lệch','Bước dài hơn để dẫn hàng','Đứng lại chờ hàng ngoài đi hết vòng','Chạy nhanh về đầu hàng'],
  [3,'Hãy mô tả cách tổ trưởng tập hợp tổ thành một hàng ngang, dóng hàng và điểm số để báo cáo giáo viên.','Tổ trưởng chọn vị trí, quay mặt về phía tổ, hô "Thành một hàng ngang – tập hợp!"; các bạn đứng bên trái tổ trưởng theo thứ tự. Hô "Nhìn phải – thẳng!" để dóng hàng rồi "Thôi!"; hô "Từ một đến hết – điểm số!", lần lượt từng bạn hô số và quay mặt về bạn kế tiếp, bạn cuối hô "Hết!". Tổ trưởng kiểm tra số lượng rồi báo cáo giáo viên.']
 ]);
 add(M,4,'Vệ sinh và an toàn trong tập luyện',[
  [1,'Khi tập chạy vượt chướng ngại vật ở lớp 4, chướng ngại vật phù hợp và an toàn là loại nào?','Vật thấp, mềm, dễ đổ như hộp giấy, xốp, nấm giao thông','Ghế gỗ cao, nặng','Gạch, đá xếp chồng','Dây căng ngang ở độ cao ngang cổ'],
  [2,'Khi trời nắng gắt, giờ thể dục ngoài trời cần được tổ chức như thế nào để bảo đảm sức khỏe?','Tập nơi có bóng mát, đội mũ, uống đủ nước và nghỉ giữa các lượt tập','Tập nhanh hơn để kết thúc sớm','Tập như bình thường vì nắng tốt cho sức khỏe','Cởi áo để mát hơn'],
  [3,'Một bạn trong lớp bị chuột rút ở bắp chân khi đang chạy. Em và các bạn cần làm gì?','Cho bạn dừng chạy, ngồi hoặc nằm xuống chỗ an toàn; nhẹ nhàng duỗi thẳng chân và kéo mũi bàn chân về phía người, xoa bóp bắp chân cho cơ giãn ra; báo giáo viên; sau khi hết đau cho bạn nghỉ, uống nước, không tiếp tục chạy gắng sức.']
 ]);
 add(M,4,'Vận động cơ bản và trò chơi',[
  [1,'Khi ném bóng trúng đích bằng một tay trên vai, chân nào đặt phía trước nếu ném bằng tay phải?','Chân trái đặt trước, chân phải ở sau','Chân phải đặt trước, chân trái ở sau','Hai chân đứng song song','Chân nào cũng được'],
  [2,'Khi di chuyển vượt qua chướng ngại vật thấp bằng cách bước qua, điều gì giúp em không bị vướng chân?','Nâng cao đùi, ước lượng khoảng cách và nhìn về phía chướng ngại vật trước khi bước','Chạy thật nhanh và không nhìn xuống','Hai tay dang ngang, bước chậm từng bước ngắn','Nhảy chụm hai chân qua mọi chướng ngại vật'],
  [3,'Mô tả cách thực hiện bài tập chạy đổi hướng theo tín hiệu (còi hoặc hiệu lệnh) của giáo viên.','Chạy chậm hoặc chạy vừa về phía trước, mắt quan sát và tai lắng nghe tín hiệu; khi có tín hiệu, hạ thấp trọng tâm, đạp chân phía ngoài, xoay người và đổi hướng chạy theo yêu cầu (trái, phải hoặc quay lại); sau đó lấy lại nhịp chạy; chú ý giữ khoảng cách với bạn để không va chạm.']
 ]);
 add(M,4,'Thói quen vận động hằng ngày',[
  [1,'Khi tập luyện, nhận biết mình đã vận động "vừa sức" nhờ dấu hiệu nào?','Thở nhanh hơn, hơi ra mồ hôi nhưng vẫn nói được thành câu','Thở hổn hển, không nói được, chóng mặt','Không thấy thay đổi gì so với lúc ngồi','Đau nhói ở ngực'],
  [2,'Vì sao học sinh lớp 4 không nên ngồi học hoặc xem màn hình liên tục quá lâu mà cần đứng dậy vận động giữa giờ?','Giúp mắt được nghỉ, cột sống không bị cong vẹo, máu lưu thông tốt','Để tiết kiệm điện','Để làm bài tập nhanh hơn','Vì ngồi lâu sẽ bị phạt'],
  [3,'Em hãy xây dựng một bài tập thể dục buổi sáng khoảng 10 phút cho bản thân gồm ít nhất 5 động tác và nêu thứ tự thực hiện.','Ví dụ: 1) Vươn thở; 2) Động tác tay; 3) Động tác chân; 4) Động tác lườn; 5) Động tác bụng; 6) Nhảy; 7) Điều hòa. Mỗi động tác tập 2 × 8 nhịp. Thứ tự: bắt đầu bằng động tác nhẹ (vươn thở) để khởi động, tăng dần cường độ (chân, bụng, nhảy), kết thúc bằng điều hòa để cơ thể trở lại trạng thái bình thường.']
 ]);

 /* ===== LỚP 5 ===== */
 add(M,5,'Đội hình đội ngũ',[
  [1,'Trong đội hình hàng ngang, "giãn cách" được quy định là khoảng cách giữa hai bạn đứng cạnh nhau bằng khoảng nào?','Một cánh tay (tay dang ngang chạm vai bạn)','Một bước chân','Hai mét','Sát vai nhau'],
  [2,'Khi dàn hàng ngang từ bạn làm chuẩn, các bạn còn lại di chuyển như thế nào?','Bước sang ngang cách bạn chuẩn theo giãn cách quy định, dóng hàng cho thẳng','Chạy tản ra tùy ý rồi đứng lại','Đi lùi về phía sau','Đứng nguyên vị trí'],
  [3,'Lớp trưởng cần làm gì để tập hợp lớp thành bốn hàng dọc, dóng hàng, điểm số và báo cáo giáo viên khi bắt đầu giờ học?','Hô "Thành bốn hàng dọc – tập hợp!", đứng làm chuẩn để các tổ xếp thành bốn hàng dọc; hô "Nhìn trước – thẳng!" để dóng hàng, "Thôi!"; hô "Từng tổ – điểm số!" để các tổ điểm số; hô "Nghiêm!", quay về phía giáo viên, báo cáo tổng số học sinh và số bạn vắng, sau đó hô "Nghỉ!" hoặc theo lệnh giáo viên.']
 ]);
 add(M,5,'Vệ sinh và an toàn trong tập luyện',[
  [1,'Trong khi tập, nếu thấy chóng mặt, hoa mắt, buồn nôn em nên làm gì?','Dừng tập ngay, ngồi nghỉ ở nơi thoáng mát và báo giáo viên','Cố tập hết bài rồi mới nghỉ','Chạy nhanh hơn để hết chóng mặt','Uống nhiều nước đá thật nhanh'],
  [2,'Vì sao sau khi chạy bền không nên dừng đột ngột mà cần đi lại nhẹ nhàng vài phút?','Giúp tim mạch và nhịp thở trở về bình thường từ từ, tránh choáng ngất','Để không bị giáo viên nhắc nhở','Để chạy thêm được vòng nữa','Để tiết kiệm sức cho buổi sau'],
  [3,'Em hãy nêu các bước kiểm tra an toàn trước một buổi tập ném bóng xa ngoài sân trường.','Kiểm tra sân: bằng phẳng, không có vật sắc nhọn, khu vực ném không có người qua lại; kiểm tra bóng không hỏng, không quá trơn; xác định vạch ném và hướng ném chung cho cả lớp; quy ước hiệu lệnh ném và hiệu lệnh đi nhặt bóng; mọi người chỉ ném khi có lệnh và chỉ nhặt bóng khi tất cả đã ném xong.']
 ]);
 add(M,5,'Vận động cơ bản và trò chơi',[
  [1,'Khi ném bóng xa bằng một tay trên vai, lực ném chủ yếu bắt đầu từ đâu?','Từ chân đạp đất, chuyển qua thân rồi đến tay','Chỉ từ cổ tay','Chỉ từ cánh tay','Từ đầu và cổ'],
  [2,'Trong bài tập phối hợp chạy – nhảy, vì sao bước cuối trước khi giậm nhảy cần ngắn và nhanh hơn?','Để hạ thấp trọng tâm, đặt chân giậm chính xác và chuyển tốc độ chạy thành lực bật','Để nghỉ lấy sức trước khi nhảy','Để nhìn rõ hố cát hơn','Để bạn phía sau không đuổi kịp'],
  [3,'Nêu cách thực hiện động tác bật cao với tay chạm vật treo trên cao.','Đứng dưới vật treo, hai chân rộng bằng vai, khuỵu gối, hai tay đưa ra sau; đạp mạnh hai chân duỗi thẳng người, đồng thời vung tay từ sau ra trước lên cao, tay thuận với lên chạm vật; tiếp đất bằng nửa trước bàn chân, khuỵu gối để giảm chấn, giữ thăng bằng.']
 ]);
 add(M,5,'Thói quen vận động hằng ngày',[
  [1,'Khi chọn giày để tập luyện và chơi thể thao, em nên chọn loại nào?','Giày thể thao vừa chân, đế mềm, chống trơn trượt','Dép lê cho thoáng chân','Giày da cứng, đế trơn','Giày rộng hơn chân hai số để dễ đi'],
  [2,'Vì sao học sinh lớp 5 cần ngủ đủ giấc bên cạnh việc tập luyện hằng ngày?','Giấc ngủ giúp cơ thể phục hồi, phát triển chiều cao và tinh thần tỉnh táo','Vì ngủ nhiều sẽ không cần tập thể dục','Vì ngủ giúp giảm cân nhanh','Vì thức khuya giúp học tốt hơn'],
  [3,'Em hãy lập kế hoạch tập luyện trong một tuần với mục tiêu cải thiện sức bền, ghi rõ hoạt động, thời gian và cách em tự kiểm tra tiến bộ.','Ví dụ: Thứ 2, 4, 6: chạy chậm hoặc đi bộ nhanh 15–20 phút; Thứ 3, 5: nhảy dây 3 lượt × 2 phút, nghỉ 1 phút giữa các lượt; Thứ 7: đạp xe hoặc đá cầu cùng bạn 30 phút; Chủ nhật: nghỉ hoặc đi bộ nhẹ. Kiểm tra tiến bộ: ghi lại quãng đường chạy được trong 5 phút hoặc số lần nhảy dây trong 1 phút đầu tuần và cuối tuần để so sánh; nếu tăng là tiến bộ.']
 ]);

 /* ===== LỚP 7 ===== */
 add(M,7,'Kiến thức chung về thể dục thể thao',[
  [1,'Khi rèn luyện cơ thể bằng không khí, điều kiện tốt nhất là tập luyện ở đâu?','Nơi thoáng đãng, nhiều cây xanh, không khí trong lành vào buổi sáng','Trong phòng kín đóng cửa sổ','Ven đường có nhiều xe cộ','Nơi có khói đốt rác'],
  [2,'Vì sao chế độ dinh dưỡng của học sinh thường xuyên tập luyện cần đủ cả bốn nhóm chất (bột đường, đạm, béo, vitamin – khoáng chất)?','Mỗi nhóm chất đảm nhiệm vai trò riêng: cung cấp năng lượng, xây dựng cơ bắp, hỗ trợ chuyển hóa và phục hồi','Để bữa ăn trông đẹp mắt hơn','Vì chỉ cần ăn nhiều thịt là đủ','Để tăng cân nhanh'],
  [3,'Nêu những lưu ý khi sử dụng ánh nắng mặt trời để rèn luyện sức khỏe.','Tắm nắng vào sáng sớm hoặc chiều muộn, khi nắng dịu; thời gian ngắn rồi tăng dần (khoảng 10–20 phút); không tắm nắng khi nắng gắt giữa trưa; đội mũ che đầu, không để mắt nhìn trực tiếp vào mặt trời; uống đủ nước; người đang ốm, sốt không nên tắm nắng.']
 ]);
 add(M,7,'Kĩ thuật và luật cơ bản',[
  [1,'Trong chạy cự li ngắn 60 m, khẩu lệnh xuất phát gồm những lệnh nào theo thứ tự?','"Vào chỗ!" – "Sẵn sàng!" – "Chạy!" (hoặc tiếng súng/còi)','"Chuẩn bị!" – "Chạy!"','"Nghiêm!" – "Chạy!"','"Sẵn sàng!" – "Vào chỗ!" – "Chạy!"'],
  [2,'Trong nhảy xa kiểu ngồi, tư thế "ngồi" trên không được hình thành như thế nào?','Sau giậm nhảy, chân giậm thu lên ngang chân lăng, hai đùi nâng cao gần như ngồi trên không, tay vung ra trước','Hai chân duỗi thẳng ra sau như nằm','Co một chân, duỗi một chân thẳng xuống đất','Ngồi xổm ngay tại vạch giậm nhảy'],
  [3,'Nêu các lỗi phạm quy thường gặp khi thi nhảy xa và cách khắc phục một trong các lỗi đó.','Lỗi phạm quy thường gặp: giậm nhảy vượt quá ván giậm (bàn chân chạm phía trước mép ván); sau khi rơi xuống hố lại đi ngược về phía ván để rời hố. Ngoài ra có lỗi kĩ thuật không bị phạm quy nhưng làm giảm thành tích: chân giậm không trúng ván (giậm xa ván), ngã ngồi hoặc chống tay ra sau điểm tiếp đất. Khắc phục lỗi vượt ván: đo và điều chỉnh lại số bước đà, đánh dấu điểm xuất phát, tập chạy đà nhiều lần để đặt chân giậm chính xác.']
 ]);
 add(M,7,'Sức khỏe và vận động',[
  [1,'Khi chạy cự li trung bình, bước chạy hợp lí có đặc điểm gì?','Bước dài vừa phải, nhịp đều, thân người hơi ngả trước, tay vung thoải mái','Bước thật dài và cao như chạy nước rút','Bước ngắn, thân người ngả hẳn về sau','Chạy bằng gót chân, tay giữ cố định'],
  [2,'Sau khi vượt qua "cực điểm" trong chạy bền, trạng thái của cơ thể thường được gọi là gì?','"Hô hấp lần hai" – cơ thể dễ chịu, thở đều trở lại','Mệt mỏi hoàn toàn, phải dừng chạy','Chuột rút','Say nắng'],
  [3,'Trình bày cách tự kiểm tra sức bền của bản thân bằng bài chạy trong thời gian quy định và cách sử dụng kết quả đó để tập luyện.','Chạy liên tục trong một thời gian quy định (ví dụ 5 hoặc 6 phút) trên đường chạy đã đo, ghi lại quãng đường đạt được và cảm giác cơ thể, nhịp tim ngay sau chạy. Sau 4–6 tuần tập luyện kiểm tra lại cùng điều kiện; nếu quãng đường tăng và nhịp tim phục hồi nhanh hơn là sức bền tiến bộ; từ đó điều chỉnh tăng dần thời gian hoặc quãng đường chạy trong các buổi tập.']
 ]);
 add(M,7,'Kĩ thuật và luật thi đấu',[
  [1,'Trong bóng chuyền, kĩ thuật dùng hai bàn tay tạo hình "chén" tiếp xúc bóng phía trên trán để đưa bóng đi gọi là gì?','Chuyền bóng cao tay bằng hai tay','Đệm bóng','Phát bóng thấp tay','Đập bóng'],
  [2,'Trong bóng chuyền, khi phát bóng, người phát phải đứng ở khu vực nào?','Khu vực sau vạch cuối sân của đội mình','Bất kì vị trí nào trên sân','Sát lưới','Trong vòng 3 m trước lưới'],
  [3,'Nêu cách thực hiện kĩ thuật đệm bóng (chuyền bóng thấp tay) trong bóng chuyền.','Tư thế chuẩn bị: hai chân rộng bằng vai, gối khuỵu, thân hơi ngả trước; hai tay duỗi thẳng, hai bàn tay đan hoặc chồng vào nhau tạo mặt phẳng ở cẳng tay. Khi bóng tới: di chuyển đến vị trí bóng rơi, đệm bóng bằng phần cẳng tay (trên cổ tay), đồng thời duỗi chân, nâng thân để đẩy bóng đi theo hướng mong muốn; không vung tay quá mạnh.']
 ]);
 add(M,7,'(Bổ sung) Sức khỏe và vận động',[
  [1,'Bữa ăn trước buổi tập luyện nên cách thời điểm tập ít nhất khoảng bao lâu?','Khoảng 1,5–2 giờ','5 phút','4–5 giờ','Không cần ăn trước khi tập'],
  [2,'Khi tập luyện vào mùa nóng, dấu hiệu nào cho thấy cơ thể đang bị mất nước và cần nghỉ, bổ sung nước ngay?','Khô miệng, chóng mặt, nước tiểu ít và sẫm màu','Đổ nhiều mồ hôi nhưng vẫn tỉnh táo','Cảm thấy đói','Thở nhanh hơn một chút'],
  [3,'Lập thực đơn một ngày hợp lí cho học sinh lớp 7 có buổi tập thể thao vào buổi chiều, nêu lí do sắp xếp.','Ví dụ: Sáng: cơm hoặc phở/bánh mì, trứng, sữa, trái cây (cung cấp năng lượng cho buổi học). Trưa (trước tập khoảng 2 giờ): cơm, thịt hoặc cá, rau xanh, canh (đủ bột đường, đạm, vitamin; không quá nhiều dầu mỡ để dễ tiêu). Bữa phụ nhẹ 30–60 phút trước tập: chuối hoặc sữa chua. Sau tập: uống nước, ăn tối với cơm, đạm, rau, trái cây để phục hồi. Uống đủ nước rải đều trong ngày.']
 ]);

 /* ===== LỚP 8 ===== */
 add(M,8,'Kiến thức chung về thể dục thể thao',[
  [1,'Nguyên nhân chủ quan nào dưới đây dễ dẫn đến chấn thương khi tập luyện thể dục thể thao?','Không khởi động kĩ, tập quá sức, thực hiện sai kĩ thuật','Sân tập có bóng mát','Có giáo viên hướng dẫn','Dụng cụ được kiểm tra trước khi tập'],
  [2,'Vì sao cần tăng dần lượng vận động (nguyên tắc tăng tiến) trong quá trình tập luyện?','Cơ thể cần thời gian thích nghi; tăng đột ngột dễ gây chấn thương và mệt mỏi quá mức','Để buổi tập kéo dài hơn','Để giáo viên dễ theo dõi','Vì tập ít thì không ra mồ hôi'],
  [3,'Nêu các biện pháp phòng tránh chấn thương trong tập luyện và thi đấu thể thao ở trường học.','Khởi động đầy đủ, thả lỏng sau tập; thực hiện đúng kĩ thuật, tập từ dễ đến khó; chọn trang phục, giày phù hợp; kiểm tra sân bãi, dụng cụ trước tập; tập vừa sức, không tập khi mệt hoặc đang ốm; tuân thủ luật và sự hướng dẫn của giáo viên; biết cách bảo hiểm, giúp đỡ nhau khi tập các động tác khó.']
 ]);
 add(M,8,'Kĩ thuật và luật cơ bản',[
  [1,'Trong nhảy cao kiểu bước qua, chân giậm nhảy là chân nào so với xà khi chạy đà từ phía bên?','Chân xa xà (chân ngoài)','Chân gần xà','Cả hai chân cùng giậm','Chân nào thuận thì giậm bất kể vị trí'],
  [2,'Trong nhảy cao kiểu bước qua, khi qua xà người nhảy thực hiện động tác gì để không làm rơi xà?','Chân lăng đá lên cao qua xà trước, thân người ngả về xà rồi chân giậm nhanh chóng đá qua theo','Co hai chân lại như ngồi','Lộn người qua xà','Nhảy chụm hai chân qua xà'],
  [3,'Nêu các giai đoạn của bài tập thể dục liên hoàn và những yêu cầu khi thực hiện bài liên hoàn ở lớp 8.','Bài liên hoàn gồm nhiều động tác nối tiếp nhau không ngắt quãng (vươn thở, tay – ngực, lườn, vặn mình, bụng, chân, nhảy, điều hòa… theo nhịp). Yêu cầu: nhớ đúng thứ tự động tác và nhịp đếm; thực hiện động tác đúng biên độ, dứt khoát; chuyển tiếp giữa các động tác liền mạch; kết hợp hít thở đều; tập theo nhóm cần đồng đều về nhịp.']
 ]);
 add(M,8,'Sức khỏe và vận động',[
  [1,'Tố chất thể lực nào thể hiện khả năng khắc phục lực cản bên ngoài bằng sự nỗ lực của cơ bắp?','Sức mạnh','Sức nhanh','Sức bền','Mềm dẻo'],
  [2,'Bài tập nào dưới đây chủ yếu phát triển sức mạnh của chân?','Bật nhảy liên tục, bật cóc, bật xa tại chỗ','Chạy 800 m','Xoạc ngang, ép dẻo','Đi bộ chậm 30 phút'],
  [3,'Em hãy thiết kế một buổi tập khoảng 30 phút phát triển sức bền cho bản thân, nêu rõ các phần và cách kiểm soát cường độ.','Khởi động 5–7 phút: đi bộ nhanh, xoay các khớp, chạy nhẹ. Phần chính 18–20 phút: chạy chậm liên tục hoặc chạy xen kẽ đi bộ (chạy 3 phút – đi 1 phút) với cường độ vừa, kiểm soát bằng cảm giác vẫn nói được câu ngắn hoặc nhịp tim khoảng 60–70% nhịp tim tối đa. Thả lỏng 5 phút: đi bộ, hít thở sâu, căng giãn cơ chân. Tăng thời gian chạy liên tục mỗi tuần một ít.']
 ]);
 add(M,8,'Kĩ thuật và luật thi đấu',[
  [1,'Trong bóng chuyền, mỗi đội có bao nhiêu vận động viên thi đấu trên sân cùng một lúc?','6','5','7','11'],
  [2,'Trong bóng chuyền, lỗi "chạm lưới" xảy ra khi nào?','Vận động viên chạm vào lưới trong lúc thực hiện động tác đánh bóng, cản trở trận đấu','Bóng chạm lưới khi phát bóng rồi bay sang sân đối phương','Bóng bay sát mép lưới','Vận động viên đứng gần lưới chờ bóng'],
  [3,'Nêu cách thực hiện kĩ thuật phát bóng thấp tay trong bóng chuyền.','Đứng chân trước chân sau (chân khác bên tay đánh ở trước), thân hơi ngả trước; tay không thuận cầm bóng đưa ra trước thấp ngang hông; tay đánh bóng vung từ sau ra trước; tung hoặc thả bóng nhẹ lên thấp, dùng phần lòng bàn tay hoặc cạnh bàn tay đánh vào phía dưới – sau của bóng, đồng thời chuyển trọng tâm lên chân trước để bóng bay qua lưới sang sân đối phương.']
 ]);
 add(M,8,'(Bổ sung) Sức khỏe và vận động',[
  [1,'Khi nghi ngờ bạn bị bong gân cổ chân trong giờ tập, việc nào KHÔNG nên làm?','Xoa bóp mạnh và cố bẻ, nắn khớp cho "về chỗ"','Cho bạn ngừng vận động, ngồi nghỉ','Chườm lạnh vùng sưng đau','Kê cao chân và băng cố định nhẹ'],
  [2,'Nguyên tắc sơ cứu chấn thương phần mềm thường được tóm tắt gồm những bước nào?','Nghỉ ngơi – chườm lạnh – băng ép – kê cao vùng tổn thương','Chườm nóng – xoa dầu – tiếp tục tập','Chạy nhẹ – uống nước – chườm nóng','Nắn khớp – băng chặt – đi lại nhiều'],
  [3,'Một bạn bị choáng, mặt tái, vã mồ hôi sau khi chạy bền dưới trời nắng. Em hãy nêu cách xử lí ban đầu.','Đưa bạn vào chỗ thoáng mát, có bóng râm; cho nằm xuống, kê cao chân, nới lỏng quần áo; lau mát bằng khăn ẩm ở mặt, cổ, nách; khi bạn tỉnh táo cho uống từng ngụm nước nhỏ (có thể pha chút muối hoặc dung dịch điện giải); theo dõi, báo giáo viên hoặc nhân viên y tế; nếu bạn không tỉnh, co giật hoặc nôn nhiều phải gọi cấp cứu.']
 ]);

 /* ===== LỚP 9 ===== */
 add(M,9,'Kiến thức chung về thể dục thể thao',[
  [1,'Nguyên tắc tập luyện nào yêu cầu bài tập phải phù hợp với lứa tuổi, giới tính và trình độ của từng người?','Nguyên tắc vừa sức (phù hợp cá nhân)','Nguyên tắc tăng tiến','Nguyên tắc hệ thống','Nguyên tắc tự giác tích cực'],
  [2,'Vì sao học sinh lớp 9 nên duy trì tập luyện nhẹ nhàng, đều đặn thay vì bỏ hẳn thể dục trong giai đoạn ôn thi?','Vận động giúp giải tỏa căng thẳng, cải thiện giấc ngủ và khả năng tập trung, tăng hiệu quả ôn tập','Vì tập luyện giúp đạt điểm thi môn Toán cao hơn','Vì bỏ tập sẽ bị trừ điểm thi','Vì ôn thi không tốn năng lượng'],
  [3,'Hãy xây dựng kế hoạch tự tập luyện trong 4 tuần giai đoạn ôn thi, nêu mục tiêu, nội dung mỗi tuần và cách đánh giá kết quả.','Mục tiêu: duy trì sức khỏe, giảm căng thẳng, không giảm thể lực. Tuần 1–2: mỗi ngày 20–25 phút đi bộ nhanh hoặc chạy nhẹ, xen 2 buổi bài tập mềm dẻo – căng giãn; Tuần 3–4: tăng lên 25–30 phút, thêm 1 buổi chơi thể thao ưa thích (cầu lông, đá cầu); giữ giờ ngủ đủ 8 tiếng. Đánh giá: đo nhịp tim lúc nghỉ và thời gian chạy bền trước – sau 4 tuần, tự ghi mức độ căng thẳng, khả năng tập trung học mỗi tuần.']
 ]);
 add(M,9,'Kĩ thuật và luật cơ bản',[
  [1,'Trong chạy cự li ngắn, khi thực hiện lệnh "Sẵn sàng!" ở xuất phát thấp, trọng tâm cơ thể và hông chuyển như thế nào?','Hông nâng cao hơn vai một chút, trọng tâm dồn về trước lên hai tay','Hông hạ thấp sát mặt đất, ngồi xổm','Đứng thẳng người, hai tay buông thõng','Nằm sấp xuống đường chạy'],
  [2,'Khi về đích trong chạy cự li ngắn, động tác đánh đích đúng là gì?','Giữ tốc độ tối đa, bước cuối ngả thân trên, đưa ngực hoặc vai chạm dây đích rồi chạy tiếp vài bước để giảm tốc','Nhảy chụm hai chân vào dây đích','Dừng hẳn ngay tại vạch đích','Giơ hai tay chạm dây đích trước'],
  [3,'So sánh xuất phát thấp (chạy cự li ngắn) và xuất phát cao (chạy cự li trung bình) về tư thế và mục đích sử dụng.','Xuất phát thấp: dùng bàn đạp, hai tay chống đất sau vạch, hông cao hơn vai khi "Sẵn sàng", giúp tạo lực đạp mạnh và đạt tốc độ tối đa thật nhanh – phù hợp cự li ngắn 60–100 m. Xuất phát cao: đứng, chân trước sát vạch, thân hơi ngả trước, không chống tay; không yêu cầu tốc độ xuất phát tối đa mà cần giữ sức, phân phối đều – phù hợp cự li trung bình và dài.']
 ]);
 add(M,9,'Sức khỏe và vận động',[
  [1,'Vùng nhịp tim tập luyện hiệu quả để phát triển sức bền thường được xác định vào khoảng bao nhiêu phần trăm nhịp tim tối đa?','Khoảng 60–80%','Dưới 30%','Khoảng 95–100%','Đúng 50%'],
  [2,'Vì sao sau buổi tập nặng nên ăn bữa có đủ chất đạm và chất bột đường trong khoảng 1–2 giờ?','Giúp phục hồi năng lượng dự trữ và tái tạo cơ bắp, giảm mệt mỏi','Để tăng cân nhanh','Vì sau tập không hấp thụ được chất béo','Để tránh bị chuột rút ngay lập tức'],
  [3,'Em hãy trình bày cách theo dõi nhịp tim trong một buổi tập sức bền và cách điều chỉnh cường độ dựa trên nhịp tim đo được.','Đo nhịp tim lúc nghỉ trước tập; sau phần chính dừng lại đo nhịp tim trong 10 giây rồi nhân 6 (hoặc dùng thiết bị đo). Tính nhịp tim tối đa ước tính bằng 220 trừ tuổi; nếu nhịp tim thấp hơn 60% nhịp tim tối đa thì tăng tốc độ hoặc thời gian; nếu vượt 80–85% hoặc thấy khó thở, chóng mặt thì giảm tốc độ, chuyển sang đi bộ; cuối buổi đo lại sau 1–2 phút thả lỏng để đánh giá khả năng phục hồi.']
 ]);
 add(M,9,'Kĩ thuật và luật thi đấu',[
  [1,'Trong bóng đá, cầu thủ bị thổi phạt "việt vị" khi nào?','Đứng gần vạch cầu môn đối phương hơn bóng và cầu thủ đối phương thứ hai cuối cùng vào thời điểm đồng đội chuyền bóng, rồi tham gia tấn công','Chạm bóng bằng tay trong khu phạt đền','Đá bóng ra ngoài biên dọc','Đứng trong khu vực cầu môn của đội mình'],
  [2,'Trong cầu lông, khi phát cầu đúng luật, điểm tiếp xúc giữa vợt và cầu phải ở độ cao như thế nào?','Dưới thắt lưng (theo luật mới không cao quá 1,15 m so với mặt sân)','Trên đầu','Ngang vai','Tùy ý, không giới hạn'],
  [3,'Nêu cách tổ chức một giải thi đấu thể thao tự chọn (cầu lông hoặc đá cầu) cấp lớp theo thể thức vòng tròn và cách xếp hạng.','Lập danh sách các đội/cá nhân tham gia; mỗi đội thi đấu với tất cả các đội còn lại một lần theo lịch sắp sẵn; mỗi trận đấu theo luật rút gọn (ví dụ một ván 21 điểm hoặc 15 điểm); thắng được 2 điểm (hoặc 1 điểm tùy quy ước), thua 0 điểm; xếp hạng theo tổng điểm, nếu bằng điểm thì xét kết quả trận đối đầu hoặc hiệu số điểm thắng – thua; phân công trọng tài, thư kí ghi điểm, chuẩn bị sân, dụng cụ và bảo đảm an toàn.']
 ]);
 add(M,9,'(Bổ sung) Sức khỏe và vận động',[
  [1,'Bài tập nào dưới đây giúp phát triển sức nhanh?','Chạy tăng tốc cự li ngắn 20–30 m, chạy theo tín hiệu','Chạy chậm liên tục 15 phút','Ép dẻo, xoạc dọc','Đi bộ nhanh'],
  [2,'Vì sao thuốc lá điện tử và các chất kích thích gây hại cho thành tích tập luyện của học sinh?','Làm giảm khả năng hấp thụ oxy, ảnh hưởng tim mạch và phổi, giảm sức bền','Chỉ ảnh hưởng đến răng miệng','Giúp tăng sức mạnh nhưng gây mất ngủ','Không ảnh hưởng đến tập luyện'],
  [3,'Em hãy lập kế hoạch dinh dưỡng và nghỉ ngơi trong ngày trước và ngày thi đấu môn thể thao tự chọn, giải thích lí do.','Ngày trước thi: ăn đủ bữa, tăng chất bột đường (cơm, bánh mì, khoai) để dự trữ năng lượng, hạn chế đồ chiên rán, lạ miệng; uống đủ nước; ngủ sớm đủ 8 tiếng; tập nhẹ hoặc nghỉ để cơ thể hồi phục. Ngày thi: ăn sáng dễ tiêu, cách giờ thi ít nhất 2 giờ; bổ sung nước từng ngụm trước và trong lúc chờ; khởi động kĩ trước thi; sau thi ăn nhẹ, bù nước, thả lỏng. Lí do: bảo đảm năng lượng, tránh đầy bụng, giúp cơ thể và tinh thần ở trạng thái tốt nhất.']
 ]);
})();
