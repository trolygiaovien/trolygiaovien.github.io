/* ============================================================
   NGÂN HÀNG CÂU HỎI THEO TỪNG BÀI (THCS) — liên kết bằng "Bài N:"
   Khi chọn bài trong "Theo bài SGK", hệ thống tự tick đúng mục này.
   Định dạng: [mức, 'câu hỏi', 'đáp án đúng', 'nhiễu', 'nhiễu', 'nhiễu']  (TN)
              [mức, 'câu hỏi', 'đáp án']  (tự luận)
   ============================================================ */
(function(){
 if(typeof NH==='undefined'||!NH['Giáo dục công dân'])return;
 const G=NH['Giáo dục công dân'];

 /* -------------------- GDCD LỚP 6 -------------------- */
 G[6].push(
  {cd:'Bài 1: Tự hào về truyền thống gia đình, dòng họ',q:[
   [1,'Truyền thống gia đình, dòng họ là những giá trị tốt đẹp được hình thành và lưu truyền như thế nào?','truyền từ đời này sang đời khác','chỉ có ở gia đình giàu có','do nhà nước quy định','tự nhiên mà có'],
   [2,'Việc làm nào thể hiện giữ gìn và phát huy truyền thống tốt đẹp của gia đình, dòng họ?','trân trọng và tiếp nối nghề truyền thống của gia đình','chê bai nghề của ông bà','quên đi nguồn gốc gia đình','phá bỏ các giá trị cũ'],
   [3,'Em hãy kể một truyền thống tốt đẹp của gia đình, dòng họ em và nêu cách em giữ gìn truyền thống đó.','Ví dụ: truyền thống hiếu học – em chăm chỉ học tập, noi gương ông bà cha mẹ (HS tự nêu).']]},
  {cd:'Bài 2: Yêu thương con người',q:[
   [1,'Yêu thương con người là quan tâm, giúp đỡ và làm những điều gì cho người khác?','những điều tốt đẹp','những điều có lợi cho mình','mọi yêu cầu vô lí','điều mình thích'],
   [2,'Hành vi nào thể hiện lòng yêu thương con người?','giúp đỡ người gặp khó khăn, hoạn nạn','thờ ơ trước nỗi đau của người khác','chế giễu người khuyết tật','ích kỉ chỉ nghĩ cho mình'],
   [3,'Nêu một việc làm thể hiện tình yêu thương con người mà em đã thực hiện.','Ví dụ: giúp bạn chép bài khi bạn ốm, ủng hộ đồng bào vùng lũ (HS tự nêu).']]},
  {cd:'Bài 3: Siêng năng, kiên trì',q:[
   [1,'Siêng năng là đức tính thể hiện sự cần cù, tự giác và miệt mài trong việc gì?','trong công việc','trong vui chơi','trong việc đòi hỏi','trong việc trốn tránh'],
   [2,'Kiên trì là quyết tâm làm đến cùng dù gặp điều gì?','gặp khó khăn','gặp thuận lợi','gặp người giúp','gặp may mắn'],
   [3,'Vì sao siêng năng, kiên trì giúp con người thành công? Cho một ví dụ.','Vì chăm chỉ và bền bỉ giúp vượt khó, tích lũy kết quả; ví dụ: học đều mỗi ngày thì tiến bộ (HS tự nêu).']]},
  {cd:'Bài 4: Tôn trọng sự thật',q:[
   [1,'Tôn trọng sự thật là suy nghĩ, nói và làm theo điều gì?','đúng sự thật','ý muốn cá nhân','lời đồn đại','điều có lợi cho mình'],
   [2,'Hành vi nào thể hiện tôn trọng sự thật?','dám nhận lỗi và nói đúng những gì đã xảy ra','bao che cái sai của bạn','nói dối để có lợi','xuyên tạc sự việc'],
   [3,'Nêu ý nghĩa của việc tôn trọng sự thật trong cuộc sống.','Giúp con người tin tưởng nhau, sống trung thực, xã hội tốt đẹp hơn (HS tự nêu).']]},
  {cd:'Bài 5: Tự lập',q:[
   [1,'Tự lập là tự làm lấy, tự giải quyết công việc của mình, không làm điều gì vào người khác?','trông chờ, dựa dẫm','học hỏi','hợp tác','chia sẻ'],
   [2,'Biểu hiện nào thể hiện tính tự lập của học sinh?','tự giác học bài và làm việc nhà phù hợp','việc gì cũng nhờ bố mẹ làm hộ','ỷ lại vào bạn bè','né tránh trách nhiệm'],
   [3,'Kể một việc em đã tự làm để rèn tính tự lập.','Ví dụ: tự sắp xếp góc học tập, tự chuẩn bị sách vở, tự dậy đúng giờ (HS tự nêu).']]},
  {cd:'Bài 6: Tự nhận thức bản thân',q:[
   [1,'Tự nhận thức bản thân là biết nhìn nhận đúng về điều gì của mình?','điểm mạnh, điểm yếu và khả năng','chỉ khuyết điểm','chỉ ưu điểm','tài sản'],
   [2,'Việc làm nào giúp em tự nhận thức bản thân tốt hơn?','lắng nghe góp ý và tự đánh giá mình','phớt lờ mọi góp ý','so sánh hơn thua với người khác','giấu khuyết điểm'],
   [3,'Vì sao cần tự nhận thức bản thân?','Để phát huy điểm mạnh, khắc phục điểm yếu và hoàn thiện bản thân (HS tự nêu).']]},
  {cd:'Bài 7: Ứng phó với tình huống nguy hiểm',q:[
   [1,'Khi gặp tình huống nguy hiểm, điều quan trọng đầu tiên cần làm là gì?','bình tĩnh, tìm cách tự bảo vệ và gọi trợ giúp','hoảng loạn','im lặng chịu đựng','giấu người lớn'],
   [2,'Ở Việt Nam, số điện thoại gọi lực lượng cứu hỏa là số nào?','114','113','115','119'],
   [3,'Nêu cách ứng phó khi gặp mưa dông, sấm sét lúc đang ở ngoài trời.','Tìm nơi trú an toàn, tránh gốc cây to và cột điện, không đứng nơi trống trải (HS tự nêu).']]},
  {cd:'Bài 8: Tiết kiệm',q:[
   [1,'Tiết kiệm là biết sử dụng hợp lí những gì?','của cải, thời gian, điện, nước','chỉ tiền của người khác','tài sản của công','đồ của bạn bè'],
   [2,'Hành vi nào thể hiện tiết kiệm?','tắt điện, khóa nước khi không dùng','để vòi nước chảy lãng phí','vứt bỏ đồ còn dùng được','tiêu xài phung phí'],
   [3,'Kể hai việc em làm để tiết kiệm điện, nước ở nhà hoặc ở trường.','Ví dụ: tắt đèn, quạt khi ra khỏi phòng; dùng nước vừa đủ (HS tự nêu).']]},
  {cd:'Bài 9: Công dân nước Cộng hòa xã hội chủ nghĩa Việt Nam',q:[
   [1,'Công dân là người dân của một nước, có quan hệ gì với nhà nước đó?','có quốc tịch','có hộ khẩu tạm trú','có thẻ học sinh','có giấy khen'],
   [2,'Căn cứ để xác định công dân Việt Nam là gì?','quốc tịch Việt Nam','nơi đang sinh sống','nghề nghiệp','tôn giáo'],
   [3,'Theo em, học sinh tiểu học, trung học có phải là công dân Việt Nam không? Vì sao?','Có, nếu mang quốc tịch Việt Nam; công dân không phân biệt tuổi tác (HS tự nêu).']]},
  {cd:'Bài 10: Quyền và nghĩa vụ cở bản của công dân',q:[
   [1,'Quyền và nghĩa vụ cơ bản của công dân được quy định trong văn bản pháp lí cao nhất nào?','Hiến pháp','nội quy trường','hương ước làng','điều lệ câu lạc bộ'],
   [2,'Đâu là một nghĩa vụ cơ bản của công dân?','tuân theo Hiến pháp và pháp luật','muốn làm gì thì làm','không cần đóng thuế','trốn nghĩa vụ quân sự'],
   [3,'Nêu một quyền và một nghĩa vụ cơ bản của công dân mà em biết.','Ví dụ: quyền học tập; nghĩa vụ tuân theo pháp luật (HS tự nêu).']]},
  {cd:'Bài 11: Quyền cơ bản của trẻ em',q:[
   [1,'Nhóm quyền nào bảo đảm trẻ em được nuôi dưỡng, chăm sóc để tồn tại và phát triển?','quyền được sống còn','quyền im lặng','quyền kinh doanh','quyền bầu cử'],
   [2,'Trẻ em có bốn nhóm quyền cơ bản: sống còn, bảo vệ, phát triển và nhóm quyền nào?','tham gia','lao động','kinh doanh','bầu cử'],
   [3,'Kể tên hai nhóm quyền cơ bản của trẻ em và cho ví dụ.','Ví dụ: quyền phát triển (được học tập); quyền được bảo vệ (không bị bạo hành) (HS tự nêu).']]},
  {cd:'Bài 12: Thực hiện quyền trẻ em',q:[
   [1,'Để thực hiện tốt quyền trẻ em, bản thân trẻ em cần làm gì?','thực hiện tốt bổn phận và tôn trọng quyền của người khác','chỉ đòi hỏi quyền lợi','không cần có bổn phận','phụ thuộc hoàn toàn'],
   [2,'Trách nhiệm thực hiện quyền trẻ em thuộc về ai?','gia đình, nhà trường, xã hội và chính trẻ em','chỉ nhà nước','chỉ cha mẹ','chỉ nhà trường'],
   [3,'Nêu một bổn phận của trẻ em đối với gia đình.','Ví dụ: yêu quý, kính trọng, giúp đỡ ông bà, cha mẹ (HS tự nêu).']]}
 );

 /* -------------------- GDCD LỚP 7 -------------------- */
 G[7].push(
  {cd:'Bài 1: Tự hào về truyền thống quê hương',q:[
   [1,'Truyền thống quê hương là những giá trị như thế nào được lưu truyền qua các thế hệ?','tốt đẹp','lạc hậu','nhất thời','vay mượn'],
   [2,'Việc làm nào thể hiện tự hào về truyền thống quê hương?','giới thiệu, quảng bá nét đẹp văn hóa quê mình','chê quê mình nghèo nàn','quên nguồn gốc','phá hoại di tích'],
   [3,'Kể một truyền thống tốt đẹp của quê hương em.','Ví dụ: truyền thống hiếu học, lễ hội, nghề truyền thống (HS tự nêu).']]},
  {cd:'Bài 2: Quan tâm, cảm thông và chia sẻ',q:[
   [1,'Cảm thông là đặt mình vào vị trí người khác để làm gì?','thấu hiểu cảm xúc của họ','lợi dụng họ','chê bai họ','xa lánh họ'],
   [2,'Hành vi nào thể hiện sự quan tâm, chia sẻ?','an ủi, giúp đỡ bạn khi bạn gặp chuyện buồn','thờ ơ với bạn','trêu chọc bạn','bỏ mặc bạn'],
   [3,'Nêu một việc em đã làm thể hiện sự quan tâm, chia sẻ với người khác.','Ví dụ: thăm hỏi bạn ốm, giúp đỡ người già neo đơn (HS tự nêu).']]},
  {cd:'Bài 3: Học tập tự giác, tích cực',q:[
   [1,'Học tập tự giác, tích cực là chủ động, nỗ lực học tập mà không cần điều gì?','không cần ai nhắc nhở','không cần sách vở','không cần thầy cô','không cần mục tiêu'],
   [2,'Biểu hiện của học tập tự giác, tích cực là gì?','lập kế hoạch học tập và thực hiện nghiêm túc','học khi bị ép buộc','quay cóp khi kiểm tra','học đối phó'],
   [3,'Vì sao cần học tập tự giác, tích cực?','Giúp đạt kết quả tốt, rèn tính chủ động và tự lập (HS tự nêu).']]},
  {cd:'Bài 4: Giữ chữ tín',q:[
   [1,'Giữ chữ tín là coi trọng lòng tin, biết làm gì với lời hứa?','giữ đúng lời hứa','quên lời hứa','thay đổi tùy ý','phá bỏ lời hứa'],
   [2,'Hành vi nào thể hiện giữ chữ tín?','thực hiện đúng điều đã hứa','hứa rồi quên','nói một đằng làm một nẻo','trốn tránh trách nhiệm'],
   [3,'Vì sao giữ chữ tín lại quan trọng trong cuộc sống?','Giúp được người khác tin tưởng, tạo uy tín và quan hệ tốt đẹp (HS tự nêu).']]},
  {cd:'Bài 5: Bảo tồn di sản văn hóa',q:[
   [1,'Di sản văn hóa gồm di sản văn hóa vật thể và di sản văn hóa loại nào?','phi vật thể','hiện đại','nhập khẩu','cá nhân'],
   [2,'Việc làm nào góp phần bảo tồn di sản văn hóa?','giữ gìn, bảo vệ di tích và không xâm hại','viết, vẽ bậy lên di tích','lấy cắp cổ vật','phá hoại di tích'],
   [3,'Kể tên một di sản văn hóa của Việt Nam mà em biết.','Ví dụ: Vịnh Hạ Long, Phố cổ Hội An, Nhã nhạc cung đình Huế (HS tự nêu).']]},
  {cd:'Bài 6: Ứng phó với tâm lí căng thẳng',q:[
   [1,'Khi bị căng thẳng kéo dài, em nên làm gì?','nghỉ ngơi, chia sẻ và thư giãn tích cực','giữ kín và chịu đựng một mình','cáu gắt với mọi người','bỏ học'],
   [2,'Cách nào giúp giảm căng thẳng một cách tích cực?','tập thể dục, trò chuyện với người tin cậy','thức khuya chơi game','ăn uống vô độ','tự cô lập mình'],
   [3,'Nêu hai cách em thường dùng để giảm căng thẳng trong học tập.','Ví dụ: nghe nhạc, chơi thể thao, trò chuyện với bạn bè (HS tự nêu).']]},
  {cd:'Bài 7: Phòng chống bạo lực học đường',q:[
   [1,'Bạo lực học đường là hành vi gây tổn hại về mặt nào xảy ra trong trường học?','thể chất hoặc tinh thần','vật chất của nhà trường','môi trường','giao thông'],
   [2,'Khi chứng kiến bạo lực học đường, em nên làm gì?','báo thầy cô, người lớn và không cổ vũ','quay video để đăng mạng','hùa theo đánh bạn','làm ngơ bỏ đi'],
   [3,'Nêu một cách phòng tránh bạo lực học đường.','Ví dụ: sống hòa đồng, kiềm chế cảm xúc, báo người lớn khi có mâu thuẫn (HS tự nêu).']]},
  {cd:'Bài 8: Quản lí tiền',q:[
   [1,'Quản lí tiền hiệu quả là biết sử dụng tiền như thế nào?','hợp lí, có kế hoạch','tùy hứng','phung phí','giấu giếm'],
   [2,'Việc làm nào thể hiện quản lí tiền tốt?','lập kế hoạch chi tiêu và tiết kiệm','tiêu hết ngay khi có','vay mượn để mua đồ không cần','mua theo đám đông'],
   [3,'Nêu một cách em có thể tiết kiệm tiền tiêu vặt.','Ví dụ: bỏ ống tiết kiệm, chỉ mua thứ cần thiết (HS tự nêu).']]},
  {cd:'Bài 9: Phòng, chống tệ nạn xã hội',q:[
   [1,'Đâu là một tệ nạn xã hội?','ma túy, cờ bạc, mại dâm','học tập','lao động','thể thao'],
   [2,'Học sinh cần làm gì để phòng, chống tệ nạn xã hội?','sống lành mạnh, tránh xa và tố giác','tò mò thử cho biết','che giấu cho bạn vi phạm','tham gia cùng bạn'],
   [3,'Nêu tác hại của tệ nạn ma túy đối với bản thân và gia đình.','Hủy hoại sức khỏe, nhân cách, gây tốn kém, làm tan vỡ gia đình (HS tự nêu).']]},
  {cd:'Bài 10: Quyền và nghĩa vụ của công dân trong gia đình',q:[
   [1,'Trong gia đình, con cháu có bổn phận như thế nào với ông bà, cha mẹ?','yêu quý, kính trọng, chăm sóc','coi thường','phụ thuộc hoàn toàn','xa lánh'],
   [2,'Cha mẹ có nghĩa vụ gì đối với con?','nuôi dưỡng, giáo dục và bảo vệ con','bỏ mặc con','phân biệt đối xử','bắt con nghỉ học'],
   [3,'Nêu một việc em làm thể hiện bổn phận của con cháu trong gia đình.','Ví dụ: giúp việc nhà, chăm sóc ông bà, vâng lời cha mẹ (HS tự nêu).']]}
 );

 /* -------------------- GDCD LỚP 8 -------------------- */
 G[8].push(
  {cd:'Bài 1: Tự hào về truyền thống dân tộc Việt Nam',q:[
   [1,'Đâu là một truyền thống tốt đẹp của dân tộc Việt Nam?','yêu nước, đoàn kết, hiếu học','lãng phí','ỷ lại','chia rẽ'],
   [2,'Việc làm nào thể hiện tự hào về truyền thống dân tộc?','học tập, lao động góp phần xây dựng đất nước','chê bai đất nước','sùng ngoại mù quáng','quên cội nguồn'],
   [3,'Kể một truyền thống tốt đẹp của dân tộc và nêu cách em phát huy.','Ví dụ: truyền thống yêu nước – chăm học, giữ gìn văn hóa dân tộc (HS tự nêu).']]},
  {cd:'Bài 2: Tôn trọng sự đa dạng của các dân tộc',q:[
   [1,'Tôn trọng sự đa dạng của các dân tộc là tôn trọng điều gì của mỗi dân tộc?','bản sắc, truyền thống, văn hóa','sự giàu nghèo','vũ khí','lãnh thổ chiếm được'],
   [2,'Thái độ nào thể hiện tôn trọng sự đa dạng của các dân tộc?','học hỏi, tiếp thu có chọn lọc tinh hoa văn hóa','kì thị dân tộc khác','áp đặt văn hóa của mình','bài xích cái khác biệt'],
   [3,'Vì sao cần tôn trọng sự đa dạng của các dân tộc?','Giúp các dân tộc hiểu biết, hợp tác, cùng phát triển trong hòa bình (HS tự nêu).']]},
  {cd:'Bài 3: Lao động cần cù, sáng tạo',q:[
   [1,'Lao động sáng tạo là luôn tìm tòi, cải tiến để làm gì với công việc?','nâng cao hiệu quả','giảm hiệu quả','giữ nguyên như cũ','làm chậm lại'],
   [2,'Biểu hiện của lao động cần cù, sáng tạo là gì?','chăm chỉ và tìm cách làm việc tốt hơn','làm cho xong chuyện','lười biếng','sao chép máy móc'],
   [3,'Nêu lợi ích của lao động cần cù, sáng tạo.','Tạo ra kết quả tốt, nâng cao năng suất, phát triển bản thân và xã hội (HS tự nêu).']]},
  {cd:'Bài 4: Bảo vệ lẽ phải',q:[
   [1,'Bảo vệ lẽ phải là công nhận, ủng hộ và làm theo những điều như thế nào?','đúng đắn','có lợi cho mình','được số đông thích','dễ dàng'],
   [2,'Hành vi nào thể hiện bảo vệ lẽ phải?','dám bênh vực cái đúng dù gặp khó khăn','a dua theo cái sai','im lặng trước điều sai','bao che vi phạm'],
   [3,'Nêu ý nghĩa của việc bảo vệ lẽ phải.','Giúp xã hội công bằng, lành mạnh; được mọi người tôn trọng (HS tự nêu).']]},
  {cd:'Bài 5: Bảo vệ môi trường và tài nguyên thiên nhiên',q:[
   [1,'Việc làm nào góp phần bảo vệ môi trường?','trồng cây, vứt rác đúng nơi quy định','xả rác bừa bãi','chặt phá rừng','săn bắt động vật hoang dã'],
   [2,'Tài nguyên nào có thể bị cạn kiệt nếu khai thác bừa bãi?','khoáng sản, rừng, nước ngầm','ánh sáng mặt trời','không khí','gió'],
   [3,'Nêu hai việc học sinh có thể làm để bảo vệ môi trường.','Ví dụ: tiết kiệm điện nước, hạn chế túi ni lông, trồng và chăm sóc cây (HS tự nêu).']]},
  {cd:'Bài 6: Xác định mục tiêu cá nhân',q:[
   [1,'Mục tiêu cá nhân nên được đặt ra như thế nào?','cụ thể, rõ ràng, phù hợp khả năng','mơ hồ','viển vông','theo người khác'],
   [2,'Việc xác định mục tiêu cá nhân giúp em điều gì?','có động lực và kế hoạch để đạt điều mong muốn','ỷ lại','lãng phí thời gian','mất phương hướng'],
   [3,'Nêu một mục tiêu học tập của em trong học kì này và cách thực hiện.','Ví dụ: đạt học sinh giỏi – học đều đặn, làm bài đầy đủ (HS tự nêu).']]},
  {cd:'Bài 7: Phòng, chống bạo lực gia đình',q:[
   [1,'Bạo lực gia đình là hành vi gây tổn hại giữa những ai?','các thành viên trong gia đình','người ngoài xã hội','bạn bè cùng lớp','hàng xóm'],
   [2,'Khi chứng kiến bạo lực gia đình, nên làm gì?','tìm sự giúp đỡ của người lớn, cơ quan chức năng','làm ngơ','cổ vũ','giấu kín'],
   [3,'Nêu một việc em có thể làm để góp phần xây dựng gia đình hòa thuận.','Ví dụ: lễ phép, chia sẻ việc nhà, tránh gây mâu thuẫn (HS tự nêu).']]},
  {cd:'Bài 8: Lập kế hoạch chi tiêu',q:[
   [1,'Lập kế hoạch chi tiêu giúp em sử dụng tiền như thế nào?','hợp lí, tránh lãng phí','nhiều hơn','tùy hứng','không cần tiết kiệm'],
   [2,'Bước đầu tiên khi lập kế hoạch chi tiêu là gì?','xác định các khoản thu và khoản cần chi','mua sắm ngay','vay tiền','bỏ qua tiết kiệm'],
   [3,'Hãy nêu khoản chi cần thiết và khoản có thể cắt giảm của một học sinh.','Cần thiết: đồ dùng học tập; có thể cắt giảm: quà vặt, đồ chơi không cần (HS tự nêu).']]},
  {cd:'Bài 9: Phòng ngừa tai nạn vũ khí, cháy, nổ và các chất độc hại',q:[
   [1,'Việc làm nào giúp phòng ngừa cháy, nổ?','tắt thiết bị điện khi không dùng, tránh xa chất dễ cháy','nghịch diêm, bật lửa','để xăng dầu gần bếp','đốt pháo'],
   [2,'Khi phát hiện đám cháy, em nên làm gì?','báo động, gọi 114 và thoát ra nơi an toàn','tự dập một mình','trốn vào phòng kín','đứng quay phim'],
   [3,'Nêu một số chất độc hại cần tránh xa trong đời sống.','Ví dụ: thuốc trừ sâu, hóa chất tẩy rửa, thủy ngân (HS tự nêu).']]},
  {cd:'Bài 10: Quyền và nghĩa vụ lao động của công dân',q:[
   [1,'Đối với mỗi công dân, lao động vừa là quyền vừa là gì?','nghĩa vụ','đặc ân','sự ép buộc','lựa chọn tùy thích'],
   [2,'Theo quy định, người lao động chưa thành niên là người bao nhiêu tuổi?','dưới 18 tuổi','dưới 15 tuổi','dưới 20 tuổi','trên 18 tuổi'],
   [3,'Nêu ý nghĩa của lao động đối với con người và xã hội.','Tạo ra của cải, nuôi sống bản thân và phát triển xã hội (HS tự nêu).']]}
 );

 /* -------------------- GDCD LỚP 9 -------------------- */
 G[9].push(
  {cd:'Bài 1: Sống có lí tưởng',q:[
   [1,'Sống có lí tưởng là xác định được điều gì cao đẹp và nỗ lực thực hiện?','mục đích sống','tài sản','địa vị','thú vui'],
   [2,'Lí tưởng sống cao đẹp của thanh niên Việt Nam hiện nay gắn với điều gì?','xây dựng và bảo vệ Tổ quốc, vì hạnh phúc nhân dân','chỉ lo cho bản thân','hưởng thụ','làm giàu bất chính'],
   [3,'Nêu một việc làm của em thể hiện sống có lí tưởng.','Ví dụ: học tập tốt để góp sức xây dựng đất nước (HS tự nêu).']]},
  {cd:'Bài 2: Khoan dung',q:[
   [1,'Khoan dung là rộng lòng và biết làm gì với lỗi lầm của người khác?','tha thứ','trừng phạt','chấp nhặt','để bụng'],
   [2,'Hành vi nào thể hiện lòng khoan dung?','bỏ qua lỗi lầm khi người khác biết hối lỗi','để bụng trả thù','chê bai','xa lánh người mắc lỗi'],
   [3,'Vì sao khoan dung lại cần thiết trong cuộc sống?','Giúp quan hệ tốt đẹp, mọi người gần gũi, bản thân thanh thản (HS tự nêu).']]},
  {cd:'Bài 3: Tích cực tham gia các hoạt động cộng đồng',q:[
   [1,'Hoạt động cộng đồng là hoạt động vì lợi ích của ai?','của cộng đồng','của riêng cá nhân','của một nhóm nhỏ','để kinh doanh'],
   [2,'Việc làm nào thể hiện tích cực tham gia hoạt động cộng đồng?','tham gia dọn vệ sinh, giúp đỡ người khó khăn','thờ ơ','trốn tránh','phá hoại'],
   [3,'Kể một hoạt động cộng đồng em đã tham gia và ý nghĩa của nó.','Ví dụ: ủng hộ vùng lũ, dọn vệ sinh khu phố (HS tự nêu).']]},
  {cd:'Bài 4: Khách quan và công bằng',q:[
   [1,'Khách quan là nhìn nhận sự việc theo điều gì, không thiên vị?','đúng bản chất, đúng thực tế','ý thích cá nhân','lời đồn','cảm tính'],
   [2,'Hành vi nào thể hiện sự công bằng?','đối xử bình đẳng, không thiên vị','ưu ái người thân quen','phân biệt đối xử','bênh vực cái sai'],
   [3,'Nêu ý nghĩa của khách quan và công bằng.','Giúp đánh giá đúng, tạo niềm tin và xã hội công bằng (HS tự nêu).']]},
  {cd:'Bài 5: Bảo vệ hoà bình',q:[
   [1,'Hòa bình là tình trạng không có điều gì, con người được sống yên ổn?','chiến tranh','lao động','học tập','giao lưu'],
   [2,'Việc làm nào góp phần bảo vệ hòa bình?','xây dựng quan hệ hữu nghị, giải quyết mâu thuẫn bằng thương lượng','dùng bạo lực','kích động chia rẽ','gây xung đột'],
   [3,'Nêu một việc học sinh có thể làm để góp phần bảo vệ hòa bình.','Ví dụ: sống hòa đồng, tôn trọng bạn bè, không gây gổ (HS tự nêu).']]},
  {cd:'Bài 6: Quản lí thời gian hiệu quả',q:[
   [1,'Quản lí thời gian hiệu quả là biết sắp xếp công việc như thế nào?','có kế hoạch, hợp lí','tùy tiện','chồng chéo','bỏ dở'],
   [2,'Việc làm nào giúp quản lí thời gian tốt?','lập thời gian biểu và làm việc đúng kế hoạch','trì hoãn công việc','làm nhiều việc qua loa','lãng phí thời gian'],
   [3,'Nêu lợi ích của việc quản lí thời gian hiệu quả.','Hoàn thành công việc tốt, giảm căng thẳng, có thời gian nghỉ ngơi (HS tự nêu).']]},
  {cd:'Bài 7: Thích ứng với thay đổi',q:[
   [1,'Thích ứng với thay đổi là biết điều chỉnh bản thân để làm gì với hoàn cảnh mới?','phù hợp','chống đối','né tránh','phụ thuộc'],
   [2,'Thái độ nào giúp em thích ứng tốt với thay đổi?','bình tĩnh, chủ động tìm giải pháp','hoảng sợ, buông xuôi','đổ lỗi','bỏ cuộc'],
   [3,'Nêu một thay đổi trong cuộc sống và cách em thích ứng.','Ví dụ: chuyển cấp học – chủ động làm quen bạn mới và phương pháp học mới (HS tự nêu).']]},
  {cd:'Bài 8: Tiêu dùng thông minh',q:[
   [1,'Tiêu dùng thông minh là mua và sử dụng hàng hóa như thế nào?','hợp lí, hiệu quả','phung phí','theo đám đông','bốc đồng'],
   [2,'Việc làm nào thể hiện tiêu dùng thông minh?','so sánh giá, chọn hàng phù hợp nhu cầu và chất lượng','mua theo quảng cáo','chạy theo mốt','mua đồ không cần'],
   [3,'Nêu các bước em thực hiện khi mua một món đồ cần thiết.','Xác định nhu cầu, tìm hiểu giá và chất lượng, cân nhắc khả năng rồi mới mua (HS tự nêu).']]},
  {cd:'Bài 9: Vi phạm pháp luật và trách nhiệm pháp lí',q:[
   [1,'Vi phạm pháp luật là hành vi như thế nào, có lỗi, do người có năng lực trách nhiệm pháp lí thực hiện?','trái pháp luật','đúng pháp luật','hợp đạo đức','được khuyến khích'],
   [2,'Đâu là các loại trách nhiệm pháp lí?','hình sự, dân sự, hành chính, kỉ luật','đạo đức','gia đình','cá nhân'],
   [3,'Nêu ý nghĩa của việc thực hiện đúng pháp luật đối với học sinh.','Giúp sống an toàn, có trật tự, tránh vi phạm và chịu trách nhiệm pháp lí (HS tự nêu).']]},
  {cd:'Bài 10: Quyền tự do kinh doanh và nghĩa vụ nộp thuế',q:[
   [1,'Công dân có quyền tự do kinh doanh trong những ngành nghề mà ai không cấm?','pháp luật','gia đình','hàng xóm','nhà trường'],
   [2,'Đối với người kinh doanh, nộp thuế là gì?','nghĩa vụ bắt buộc','quyền lợi tùy chọn','việc không bắt buộc','sự tự nguyện'],
   [3,'Nêu ý nghĩa của việc nộp thuế đối với đất nước.','Tạo nguồn thu để xây dựng đất nước, phát triển y tế, giáo dục, quốc phòng (HS tự nêu).']]}
 );

 /* ==================== TIN HỌC ==================== */
 const T=NH['Tin học'];
 if(T){
 T[6].push(
  {cd:'Bài 1: Thông tin và dữ liệu',q:[
   [1,'Thông tin là gì?','những gì đem lại hiểu biết cho con người về sự vật, sự việc','các bộ phận cứng của máy tính','thiết bị lưu trữ','dây cáp mạng'],
   [1,'Dữ liệu là gì?','thông tin được ghi lại bằng chữ, số, hình ảnh, âm thanh','chỉ là phần mềm','chỉ là màn hình','chỉ là con chuột'],
   [3,'Phân biệt thông tin và dữ liệu, cho một ví dụ.','Dữ liệu là dạng ghi lại (số, chữ, hình, tiếng); thông tin là ý nghĩa rút ra từ dữ liệu. VD: "28 độ C" là dữ liệu, "trời nóng" là thông tin (HS tự nêu).']]},
  {cd:'Bài 2: Xử lý thông tin',q:[
   [1,'Quá trình xử lí thông tin gồm các hoạt động cơ bản nào?','thu nhận, lưu trữ, xử lí và truyền thông tin','chỉ thu nhận','chỉ in ra','chỉ lưu trữ'],
   [2,'Bộ phận nào của máy tính thực hiện việc xử lí thông tin?','bộ xử lí trung tâm (CPU)','màn hình','bàn phím','loa'],
   [3,'Nêu một ví dụ về quá trình xử lí thông tin trong đời sống.','VD: nghe dự báo thời tiết (thu nhận) rồi quyết định mang áo mưa (xử lí) (HS tự nêu).']]},
  {cd:'Bài 3: Thông tin trong máy tính',q:[
   [1,'Trong máy tính, thông tin được biểu diễn dưới dạng dãy kí hiệu nào?','các bit 0 và 1','chữ cái a, b, c','số La Mã','hình vẽ'],
   [2,'Đơn vị cơ bản để đo lượng dữ liệu là gì?','bit','mét','gam','giây'],
   [2,'1 byte bằng bao nhiêu bit?','8 bit','2 bit','4 bit','16 bit']]},
  {cd:'Bài 4: Mạng máy tính',q:[
   [1,'Mạng máy tính là gì?','nhiều máy tính được kết nối để trao đổi dữ liệu','một máy tính đơn lẻ','một phần mềm soạn thảo','một con chuột'],
   [2,'Thiết bị nào thường dùng để kết nối các máy tính trong mạng?','bộ định tuyến (router), bộ chuyển mạch (switch)','máy in','loa','webcam'],
   [3,'Nêu lợi ích của mạng máy tính.','Chia sẻ dữ liệu, thiết bị, tài nguyên và trao đổi thông tin nhanh chóng (HS tự nêu).']]},
  {cd:'Bài 5: Internet',q:[
   [1,'Internet là gì?','mạng kết nối hàng tỉ máy tính trên toàn thế giới','một phần mềm soạn thảo','một loại máy in','một trò chơi'],
   [2,'Đâu là một dịch vụ phổ biến trên Internet?','tìm kiếm, thư điện tử, mạng xã hội','gọt bút chì','may quần áo','nấu ăn'],
   [3,'Nêu một lợi ích và một tác hại có thể gặp khi dùng Internet.','Lợi ích: học tập, liên lạc; tác hại: nghiện, gặp thông tin xấu nếu dùng không đúng cách (HS tự nêu).']]},
  {cd:'Bài 6: Mạng thông tin toàn cầu',q:[
   [1,'World Wide Web (WWW) là gì?','dịch vụ cung cấp các trang web liên kết với nhau trên Internet','một loại máy tính','một thiết bị mạng','một con chuột'],
   [2,'Phần mềm dùng để truy cập và xem các trang web gọi là gì?','trình duyệt web','hệ điều hành','bảng tính','trình chiếu'],
   [2,'Địa chỉ của một trang web còn được gọi là gì?','địa chỉ web (URL)','CPU','RAM','USB']]},
  {cd:'Bài 7: Tìm kiếm thông tin trên Internet',q:[
   [1,'Công cụ nào giúp tìm kiếm thông tin trên Internet?','máy tìm kiếm','máy in','máy quét','loa'],
   [2,'Để kết quả tìm kiếm chính xác hơn, em nên làm gì?','dùng từ khóa ngắn gọn, đúng trọng tâm','gõ cả đoạn văn dài dòng','gõ sai chính tả','không dùng từ khóa'],
   [3,'Nêu cách đánh giá một thông tin tìm được trên Internet có đáng tin không.','Xem nguồn gốc, tác giả, so sánh nhiều nguồn, ưu tiên trang chính thống (HS tự nêu).']]},
  {cd:'Bài 8: Thư điện tử',q:[
   [1,'Thư điện tử (email) dùng để làm gì?','gửi và nhận thư qua Internet','in tài liệu','vẽ hình','tính toán'],
   [2,'Một địa chỉ email luôn có kí hiệu đặc trưng nào?','dấu @','dấu #','dấu %','dấu &'],
   [3,'Nêu một lợi ích của thư điện tử so với thư truyền thống.','Gửi nhanh, miễn phí, đính kèm được tệp, gửi cho nhiều người cùng lúc (HS tự nêu).']]},
  {cd:'Bài 9: An toàn thông tin trên Internet',q:[
   [1,'Để bảo vệ tài khoản, em nên đặt mật khẩu như thế nào?','đủ mạnh (dài, có chữ, số, kí tự đặc biệt) và giữ bí mật','dễ đoán như 123456','ghi công khai','dùng chung cho mọi tài khoản'],
   [2,'Khi nhận được liên kết hoặc tệp lạ, em nên làm gì?','không mở, cảnh giác với lừa đảo và mã độc','mở ngay để xem','tải về chạy thử','gửi tiếp cho bạn bè'],
   [3,'Nêu hai việc nên làm để an toàn khi dùng Internet.','VD: không chia sẻ thông tin cá nhân, không kết bạn với người lạ, cài phần mềm diệt virus (HS tự nêu).']]},
  {cd:'Bài 10: Sơ đồ tư duy',q:[
   [1,'Sơ đồ tư duy dùng để làm gì?','tóm tắt, sắp xếp và trình bày ý tưởng một cách trực quan','soạn thảo văn bản dài','tính toán số liệu','gửi thư'],
   [2,'Trung tâm của sơ đồ tư duy thường là gì?','chủ đề chính','một con số','ngày tháng','chữ kí'],
   [3,'Nêu lợi ích của việc dùng sơ đồ tư duy trong học tập.','Giúp ghi nhớ, hệ thống kiến thức, nhìn tổng quát và sáng tạo hơn (HS tự nêu).']]},
  {cd:'Bài 11: Định dạng văn bản',q:[
   [1,'Định dạng văn bản là gì?','thay đổi cách trình bày như phông chữ, cỡ chữ, màu sắc, căn lề','gõ nội dung văn bản','in văn bản','lưu văn bản'],
   [2,'Thao tác nào giúp làm cho chữ in đậm?','chọn chữ rồi nhấn nút in đậm (Bold)','xóa chữ','đổi trang','phóng to màn hình'],
   [3,'Kể tên ba kiểu định dạng kí tự thường dùng.','VD: in đậm, in nghiêng, gạch chân, đổi màu, đổi cỡ chữ (HS tự nêu).']]},
  {cd:'Bài 12: Trình bày thông tin ở dạng bảng',q:[
   [1,'Trình bày thông tin ở dạng bảng có ưu điểm gì?','giúp so sánh, tra cứu thông tin dễ dàng, rõ ràng','làm văn bản dài hơn','khó đọc hơn','làm mất thông tin'],
   [2,'Một bảng được tạo bởi các thành phần nào?','các hàng và các cột','chỉ các dòng chữ','chỉ hình ảnh','chỉ số trang'],
   [3,'Nêu một tình huống nên trình bày thông tin bằng bảng.','VD: thời khóa biểu, bảng điểm, danh sách lớp (HS tự nêu).']]},
  {cd:'Bài 13: Thực hành: Tìm kiếm và thay thế',q:[
   [1,'Chức năng Tìm kiếm trong phần mềm soạn thảo giúp gì?','nhanh chóng tìm một từ hoặc cụm từ trong văn bản','in văn bản','đổi màu nền','phóng to chữ'],
   [2,'Chức năng Thay thế (Replace) dùng để làm gì?','thay một từ hoặc cụm từ bằng từ, cụm từ khác','xóa toàn bộ văn bản','lưu văn bản','gửi email'],
   [3,'Nêu lợi ích của chức năng tìm kiếm và thay thế khi chỉnh sửa văn bản dài.','Tiết kiệm thời gian, sửa đồng loạt, tránh bỏ sót (HS tự nêu).']]},
  {cd:'Bài 14: Thực hành tổng hợp: Hoàn thiện Sổ lưu niệm',q:[
   [1,'Khi hoàn thiện sổ lưu niệm trên máy tính, em thường kết hợp những gì?','văn bản, hình ảnh, bảng và định dạng trình bày','chỉ các con số','chỉ công thức tính','chỉ âm thanh'],
   [2,'Để sổ lưu niệm đẹp và dễ đọc, cần chú ý điều gì?','bố cục hợp lí, phông chữ và màu sắc hài hòa','viết chữ thật nhỏ','dùng nhiều màu lòe loẹt','không có hình ảnh'],
   [3,'Nêu các bước cơ bản để tạo một trang trong sổ lưu niệm.','Chọn nội dung, chèn hình ảnh, định dạng văn bản, sắp xếp bố cục và lưu lại (HS tự nêu).']]},
  {cd:'Bài 15: Thuật toán',q:[
   [1,'Thuật toán là gì?','dãy các bước được sắp xếp theo thứ tự để giải quyết một công việc','một thiết bị máy tính','một con số','một màn hình'],
   [2,'Một thuật toán cần có đặc điểm nào?','rõ ràng, thực hiện theo thứ tự và cho kết quả','mơ hồ, tùy ý','không có kết quả','kéo dài vô tận'],
   [3,'Mô tả thuật toán cho công việc pha một cốc nước chanh.','VD theo thứ tự: lấy cốc; vắt chanh; thêm đường, nước; khuấy đều (HS tự nêu).']]},
  {cd:'Bài 16: Cấu trúc điều khiển',q:[
   [1,'Ba dạng cấu trúc điều khiển cơ bản trong thuật toán là gì?','tuần tự, rẽ nhánh và lặp','cộng, trừ, nhân','trên, dưới, giữa','đỏ, xanh, vàng'],
   [2,'Cấu trúc rẽ nhánh dùng khi nào?','khi cần thực hiện tùy theo một điều kiện đúng hay sai','khi lặp lại nhiều lần','khi làm theo thứ tự','khi tắt máy'],
   [3,'Cho một ví dụ về cấu trúc lặp trong đời sống.','VD: đánh răng mỗi sáng; chạy 5 vòng sân (lặp lại thao tác) (HS tự nêu).']]},
  {cd:'Bài 17: Chương trình máy tính',q:[
   [1,'Chương trình máy tính là gì?','thuật toán được viết bằng ngôn ngữ lập trình để máy tính thực hiện','một thiết bị phần cứng','một con chuột','một màn hình'],
   [2,'Vì sao cần viết chương trình để máy tính thực hiện công việc?','vì máy tính chỉ làm theo các lệnh được lập trình sẵn','vì máy tính tự biết làm','để trang trí','để tiết kiệm điện'],
   [3,'Nêu mối quan hệ giữa thuật toán và chương trình máy tính.','Thuật toán là ý tưởng các bước; chương trình là thuật toán được viết bằng ngôn ngữ lập trình (HS tự nêu).']]}
 );
 T[7].push(
  {cd:'Bài 1: Thiết bị vào - ra',q:[
   [1,'Thiết bị vào dùng để làm gì?','đưa thông tin, dữ liệu vào máy tính','đưa thông tin ra ngoài','lưu trữ lâu dài','xử lí dữ liệu'],
   [2,'Đâu là các thiết bị ra?','màn hình, máy in, loa','bàn phím, chuột','micro, webcam','máy quét'],
   [2,'Bàn phím và chuột thuộc loại thiết bị nào?','thiết bị vào','thiết bị ra','thiết bị lưu trữ','bộ xử lí']]},
  {cd:'Bài 2: Phần mềm máy tính',q:[
   [1,'Phần mềm máy tính là gì?','các chương trình điều khiển máy tính hoạt động','các bộ phận cứng của máy','dây cáp điện','vỏ máy'],
   [2,'Hệ điều hành thuộc loại phần mềm nào?','phần mềm hệ thống','phần mềm ứng dụng','phần cứng','thiết bị vào'],
   [2,'Phần mềm soạn thảo văn bản, bảng tính thuộc loại nào?','phần mềm ứng dụng','phần mềm hệ thống','phần cứng','thiết bị ra']]},
  {cd:'Bài 3: Quản lí dữ liệu trong máy tính',q:[
   [1,'Dữ liệu trong máy tính thường được tổ chức, lưu trữ dưới dạng gì?','tệp (file) và thư mục (folder)','chỉ một khối duy nhất','chỉ hình ảnh','chỉ âm thanh'],
   [2,'Thư mục dùng để làm gì?','chứa và sắp xếp các tệp, thư mục con có tổ chức','xử lí số liệu','in tài liệu','kết nối mạng'],
   [3,'Nêu lợi ích của việc tổ chức tệp và thư mục khoa học.','Dễ tìm, dễ quản lí, tránh thất lạc và nhầm lẫn dữ liệu (HS tự nêu).']]},
  {cd:'Bài 4: Mạng xã hội và một số kênh trao đổi thông tin trên internet',q:[
   [1,'Mạng xã hội là gì?','dịch vụ trên Internet giúp mọi người kết nối, chia sẻ thông tin','một loại máy in','một phần cứng','một hệ điều hành'],
   [2,'Đâu là lợi ích của mạng xã hội khi dùng đúng cách?','kết nối bạn bè, học tập, chia sẻ thông tin hữu ích','gây nghiện','lan truyền tin giả','xâm phạm riêng tư'],
   [3,'Nêu hai điều cần lưu ý để sử dụng mạng xã hội an toàn.','VD: không chia sẻ thông tin cá nhân, kiểm chứng tin trước khi chia sẻ, ứng xử văn minh (HS tự nêu).']]},
  {cd:'Bài 5: Ứng xử trên mạng',q:[
   [1,'Khi giao tiếp trên mạng, em nên ứng xử như thế nào?','lịch sự, tôn trọng người khác và đúng pháp luật','thô lỗ','xúc phạm người khác','lan tin sai'],
   [2,'Hành vi nào là KHÔNG nên khi dùng mạng?','bình luận xúc phạm, bắt nạt người khác trên mạng','chia sẻ kiến thức bổ ích','hỏi bài bạn bè','cảm ơn người giúp'],
   [3,'Nêu cách xử lí khi bị bắt nạt hoặc gặp nội dung xấu trên mạng.','Không trả đũa, lưu bằng chứng, báo người lớn tin cậy hoặc thầy cô (HS tự nêu).']]},
  {cd:'Bài 6: Làm quen với phần mềm bảng tính',q:[
   [1,'Phần mềm bảng tính dùng để làm gì?','nhập, tính toán và xử lí dữ liệu dạng bảng','vẽ tranh nghệ thuật','gửi thư','chơi nhạc'],
   [2,'Giao của một hàng và một cột trong bảng tính gọi là gì?','ô tính','trang','tệp','biểu đồ'],
   [2,'Địa chỉ ô được xác định bởi điều gì?','tên cột và số hàng (ví dụ A1, B3)','chỉ số hàng','chỉ tên cột','màu của ô']]},
  {cd:'Bài 7: Tính toán tự động trên bảng tính',q:[
   [1,'Trong bảng tính, công thức thường bắt đầu bằng dấu gì?','dấu bằng (=)','dấu cộng (+)','dấu hỏi (?)','dấu sao (*)'],
   [2,'Công thức =A1+A2 cho kết quả gì?','tổng giá trị của ô A1 và ô A2','hiệu của hai ô','tích của hai ô','không có kết quả'],
   [3,'Nêu lợi ích của việc dùng công thức trong bảng tính.','Tự động tính lại khi dữ liệu thay đổi, nhanh, chính xác, ít sai sót (HS tự nêu).']]},
  {cd:'Bài 8: Công cụ hỗ trợ tính toán',q:[
   [1,'Hàm trong bảng tính là gì?','công thức được định nghĩa sẵn để tính toán nhanh','một loại biểu đồ','một trang tính','một tệp'],
   [2,'Hàm SUM dùng để làm gì?','tính tổng các giá trị','tính trung bình','tìm giá trị lớn nhất','đếm số ô'],
   [2,'Hàm AVERAGE dùng để làm gì?','tính trung bình cộng','tính tổng','đếm số ô','tìm số nhỏ nhất']]},
  {cd:'Bài 9: Trình bày bảng tính',q:[
   [1,'Trình bày (định dạng) bảng tính nhằm mục đích gì?','giúp bảng tính rõ ràng, dễ đọc, đẹp hơn','làm sai kết quả','xóa dữ liệu','tăng dung lượng'],
   [2,'Thao tác nào giúp làm nổi bật tiêu đề của bảng?','in đậm, căn giữa, tô màu nền','xóa tiêu đề','để trống','thu nhỏ hết cỡ'],
   [3,'Nêu một vài cách định dạng giúp bảng tính dễ đọc.','VD: căn lề số, kẻ đường viền, tô màu xen kẽ, định dạng số (HS tự nêu).']]},
  {cd:'Bài 10: Hoàn thiện bảng tính',q:[
   [1,'Khi hoàn thiện một bảng tính, em cần kiểm tra điều gì?','tính đúng của công thức và cách trình bày','màu áo','thời tiết','tên trường'],
   [2,'Biểu đồ trong bảng tính giúp ích gì?','minh họa dữ liệu trực quan, dễ so sánh','làm chậm máy','xóa dữ liệu','mã hóa dữ liệu'],
   [3,'Nêu các bước cơ bản để hoàn thiện một bảng tính thống kê.','Nhập dữ liệu, lập công thức tính, định dạng, tạo biểu đồ, kiểm tra và lưu (HS tự nêu).']]},
  {cd:'Bài 11: Tạo bài trình chiếu',q:[
   [1,'Phần mềm trình chiếu dùng để làm gì?','tạo các trang chiếu trình bày nội dung trước nhiều người','tính toán số liệu','gửi thư','lưu trữ phim'],
   [2,'Mỗi trang nội dung trong bài trình chiếu gọi là gì?','trang chiếu (slide)','ô tính','thư mục','biểu đồ'],
   [3,'Nêu một lưu ý để bài trình chiếu hiệu quả.','Nội dung ngắn gọn, cỡ chữ đủ lớn, ít chữ nhiều ý chính, hình minh họa phù hợp (HS tự nêu).']]},
  {cd:'Bài 12: Định dạng đối tượng trên trang chiếu',q:[
   [1,'Trên trang chiếu, em có thể chèn những đối tượng nào?','văn bản, hình ảnh, bảng, biểu đồ','chỉ văn bản','chỉ số','chỉ âm thanh nền'],
   [2,'Hiệu ứng động trên trang chiếu nên dùng như thế nào?','vừa phải, làm nổi bật nội dung','càng nhiều càng tốt','gây rối mắt','che hết nội dung'],
   [3,'Nêu tác dụng của việc định dạng đối tượng trên trang chiếu.','Giúp trang chiếu sinh động, làm nổi bật ý chính, thu hút người xem (HS tự nêu).']]},
  {cd:'Bài 13: Thực hành tổng hợp: Hoàn thiện bài trình chiếu',q:[
   [1,'Khi hoàn thiện bài trình chiếu, cần đảm bảo điều gì?','nội dung chính xác, bố cục nhất quán, trình bày hợp lí','nhiều hiệu ứng rối mắt','chữ thật nhỏ','không có hình'],
   [2,'Bước cuối cùng trước khi trình bày nên làm gì?','xem lại (chạy thử) toàn bộ bài trình chiếu','tắt máy','xóa slide','đổi tên tệp'],
   [3,'Nêu các bước cơ bản để tạo và hoàn thiện một bài trình chiếu.','Chọn chủ đề, tạo slide, nhập nội dung, chèn hình và định dạng, thêm hiệu ứng, chạy thử và lưu (HS tự nêu).']]},
  {cd:'Bài 14: Thuật toán tìm kiếm tuần tự',q:[
   [1,'Thuật toán tìm kiếm tuần tự hoạt động như thế nào?','lần lượt so sánh từng phần tử từ đầu đến khi tìm thấy','chia đôi dãy để tìm','chỉ xem phần tử cuối','không cần so sánh'],
   [2,'Tìm kiếm tuần tự có thể áp dụng cho dãy dữ liệu như thế nào?','dãy bất kì, không cần sắp xếp trước','chỉ dãy đã sắp xếp','chỉ dãy số chẵn','chỉ dãy rỗng'],
   [3,'Cho dãy 5, 8, 3, 9, 2. Mô tả cách tìm số 9 bằng tìm kiếm tuần tự.','So sánh lần lượt: 5 khác 9, 8 khác 9, 3 khác 9, 9 bằng 9 nên tìm thấy ở vị trí thứ tư (HS tự nêu).']]},
  {cd:'Bài 15: Thuật toán tìm kiếm nhị phân',q:[
   [1,'Thuật toán tìm kiếm nhị phân yêu cầu dãy dữ liệu phải như thế nào?','đã được sắp xếp','chưa sắp xếp','rỗng','chỉ có số lẻ'],
   [2,'Tìm kiếm nhị phân thực hiện bằng cách nào?','so sánh với phần tử ở giữa rồi thu hẹp phạm vi tìm một nửa','xem lần lượt từ đầu','chỉ xem phần tử đầu','chọn ngẫu nhiên'],
   [3,'Vì sao tìm kiếm nhị phân thường nhanh hơn tìm kiếm tuần tự?','Vì mỗi bước loại bỏ được một nửa số phần tử nên số lần so sánh ít hơn (HS tự nêu).']]},
  {cd:'Bài 16: Thuật toán sắp xếp',q:[
   [1,'Thuật toán sắp xếp dùng để làm gì?','sắp xếp các phần tử theo thứ tự tăng hoặc giảm','tìm một phần tử','xóa dữ liệu','mã hóa dữ liệu'],
   [2,'Sau khi sắp xếp tăng dần dãy 3, 1, 2 ta được dãy nào?','1, 2, 3','3, 2, 1','2, 1, 3','3, 1, 2'],
   [3,'Nêu một ví dụ cần sắp xếp dữ liệu trong thực tế.','VD: xếp bảng điểm từ cao xuống thấp, xếp danh sách theo bảng chữ cái (HS tự nêu).']]}
 );
 T[8].push(
  {cd:'Bài 1: Lược sử công cụ tính toán',q:[
   [1,'Công cụ tính toán thô sơ đầu tiên của con người thường là gì?','bàn tính','máy tính điện tử','điện thoại thông minh','máy tính bảng'],
   [2,'Máy tính điện tử hiện đại hoạt động dựa trên hệ đếm nào?','hệ nhị phân (0 và 1)','hệ thập phân','hệ La Mã','hệ chữ cái'],
   [3,'Nêu xu hướng phát triển của công cụ tính toán qua các thời kì.','Từ thô sơ (bàn tính) đến cơ khí rồi điện tử, ngày càng nhỏ gọn, nhanh và mạnh hơn (HS tự nêu).']]},
  {cd:'Bài 2: Thông tin trong môi trường số',q:[
   [1,'Thông tin số là thông tin được biểu diễn, lưu trữ và xử lí bằng gì?','thiết bị số (máy tính, điện thoại)','giấy bút','bảng đen','tranh vẽ tay'],
   [2,'Đặc điểm nào là của thông tin số?','dễ nhân bản, lan truyền nhanh, khó thu hồi','không thể sao chép','chỉ tồn tại trên giấy','không truyền được'],
   [3,'Vì sao cần cẩn trọng khi đăng thông tin lên môi trường số?','Vì thông tin lan nhanh, khó xóa bỏ hoàn toàn, có thể ảnh hưởng lâu dài (HS tự nêu).']]},
  {cd:'Bài 3: Thực hành: Khai thác thông tin số',q:[
   [1,'Khi khai thác thông tin số, điều quan trọng là gì?','đánh giá độ tin cậy của nguồn thông tin','tin mọi thứ đọc được','chỉ xem tiêu đề','bỏ qua nguồn gốc'],
   [2,'Dấu hiệu nào cho thấy thông tin có thể KHÔNG đáng tin?','không rõ nguồn, giật gân, nhiều lỗi','có nguồn chính thống','được nhiều nơi uy tín xác nhận','có tác giả rõ ràng'],
   [3,'Nêu các bước đánh giá một thông tin tìm được trên mạng.','Xác định nguồn và tác giả, kiểm tra tính cập nhật, đối chiếu nhiều nguồn tin cậy (HS tự nêu).']]},
  {cd:'Bài 4: Đạo đức và văn hóa trong sử dụng công nghệ kĩ thuật số',q:[
   [1,'Hành vi nào thể hiện văn hóa khi dùng công nghệ số?','tôn trọng bản quyền, ứng xử lịch sự','sao chép trái phép','lan truyền tin giả','xâm phạm riêng tư'],
   [2,'Sử dụng sản phẩm của người khác (bài viết, hình ảnh) cần làm gì?','xin phép hoặc ghi rõ nguồn, tôn trọng bản quyền','lấy dùng tùy ý','nhận là của mình','xóa tên tác giả'],
   [3,'Nêu một việc nên làm và một việc không nên làm khi dùng công nghệ số.','Nên: ghi nguồn, ứng xử lịch sự; Không nên: sao chép trái phép, bắt nạt trên mạng (HS tự nêu).']]},
  {cd:'Bài 5: Sử dụng bảng tính giải quyết bài toán thực tế',q:[
   [1,'Bảng tính giúp giải quyết bài toán thực tế như thế nào?','nhập dữ liệu và dùng công thức, hàm để tính toán tự động','vẽ tranh','soạn thơ','chơi nhạc'],
   [2,'Để tính tổng chi tiêu trong một bảng, ta nên dùng gì?','hàm SUM','hàm MAX','hàm COUNT','hàm MIN'],
   [3,'Nêu một bài toán thực tế có thể giải bằng bảng tính.','VD: quản lí thu chi, tính điểm trung bình, thống kê số liệu lớp (HS tự nêu).']]},
  {cd:'Bài 6: Sắp xếp và lọc dữ liệu',q:[
   [1,'Chức năng sắp xếp (Sort) trong bảng tính dùng để làm gì?','sắp xếp dữ liệu theo thứ tự tăng hoặc giảm','xóa dữ liệu','in bảng','đổi màu'],
   [2,'Chức năng lọc (Filter) dùng để làm gì?','chỉ hiển thị những dòng dữ liệu thỏa điều kiện','xóa cột','tính tổng','vẽ biểu đồ'],
   [3,'Nêu một tình huống cần dùng lọc dữ liệu.','VD: lọc ra các học sinh có điểm trên 8, lọc sản phẩm còn hàng (HS tự nêu).']]},
  {cd:'Bài 7: Trình bày dữ liệu bằng biểu đồ',q:[
   [1,'Biểu đồ dùng để làm gì?','biểu diễn dữ liệu trực quan, dễ so sánh và nhận xét','lưu trữ tệp','gõ văn bản','gửi email'],
   [2,'Loại biểu đồ nào phù hợp để so sánh số lượng giữa các nhóm?','biểu đồ cột','không có loại nào','biểu đồ không nhãn','bảng chữ'],
   [3,'Nêu một ví dụ dữ liệu nên biểu diễn bằng biểu đồ.','VD: số học sinh giỏi các lớp, doanh thu theo tháng, tỉ lệ phần trăm (HS tự nêu).']]},
  {cd:'Bài 12: Từ thuật toán đến chương trình',q:[
   [1,'Để máy tính thực hiện, thuật toán cần được chuyển thành gì?','chương trình viết bằng ngôn ngữ lập trình','một bức tranh','một bảng tính','một email'],
   [2,'Môi trường lập trình trực quan (kéo thả khối lệnh) thường dùng là gì?','Scratch','Word','Excel','PowerPoint'],
   [3,'Nêu các bước chính từ thuật toán đến chương trình.','Xác định bài toán, xây dựng thuật toán, viết chương trình, chạy thử và sửa lỗi (HS tự nêu).']]},
  {cd:'Bài 13: Biểu diễn dữ liệu',q:[
   [1,'Trong lập trình, biến dùng để làm gì?','lưu trữ giá trị dữ liệu và có thể thay đổi','in ra màn hình','kết nối mạng','vẽ hình'],
   [2,'Kiểu dữ liệu nào dùng để lưu các con số?','kiểu số','kiểu xâu kí tự','kiểu âm thanh','kiểu hình ảnh'],
   [3,'Nêu ví dụ về một biến và giá trị của nó trong chương trình.','VD: biến diem có giá trị 8; biến ten có giá trị "An" (HS tự nêu).']]},
  {cd:'Bài 14: Cấu trúc điều khiển',q:[
   [1,'Cấu trúc rẽ nhánh (nếu...thì) dùng để làm gì?','thực hiện lệnh tùy theo điều kiện đúng hay sai','lặp lại lệnh','làm tuần tự','kết thúc chương trình'],
   [2,'Cấu trúc lặp dùng khi nào?','khi cần thực hiện lặp lại một công việc nhiều lần','khi chỉ làm một lần','khi không có điều kiện','khi tắt máy'],
   [3,'Cho ví dụ dùng cấu trúc lặp để in các số từ 1 đến 5.','Dùng vòng lặp cho biến i chạy từ 1 đến 5, mỗi lần in giá trị i (HS tự nêu).']]},
  {cd:'Bài 15: Gỡ lỗi',q:[
   [1,'Gỡ lỗi (debug) trong lập trình là gì?','tìm và sửa các lỗi trong chương trình','thêm lỗi vào chương trình','xóa chương trình','in chương trình'],
   [2,'Khi chương trình chạy ra kết quả sai, em nên làm gì?','kiểm tra lại thuật toán và từng lệnh để tìm lỗi','xóa hết làm lại ngay','bỏ qua','đổ lỗi cho máy'],
   [3,'Nêu một cách giúp phát hiện lỗi trong chương trình.','In (hiển thị) giá trị trung gian để kiểm tra, chạy thử với dữ liệu đã biết kết quả (HS tự nêu).']]},
  {cd:'Bài 16: Tin học với nghề nghiệp',q:[
   [1,'Tin học có vai trò như thế nào đối với các ngành nghề hiện nay?','hỗ trợ hầu hết các ngành nghề, nâng cao hiệu quả công việc','không liên quan','chỉ dùng trong trò chơi','chỉ để giải trí'],
   [2,'Đâu là một nghề thuộc lĩnh vực tin học?','lập trình viên','nông dân','thợ may','đầu bếp'],
   [3,'Kể tên một vài nghề nghiệp cần sử dụng kiến thức tin học.','VD: lập trình viên, thiết kế đồ họa, phân tích dữ liệu, kĩ sư mạng (HS tự nêu).']]}
 );
 T[9].push(
  {cd:'Bài 1: Thế giới kĩ thuật số',q:[
   [1,'Thế giới kĩ thuật số là gì?','môi trường thông tin được số hóa, kết nối qua các thiết bị số','thế giới chỉ có giấy bút','một trò chơi điện tử','một loại máy in'],
   [2,'Đâu là một thành tựu của công nghệ số?','trí tuệ nhân tạo, dữ liệu lớn, Internet vạn vật','máy hơi nước','bánh xe gỗ','đèn dầu'],
   [3,'Nêu một lợi ích và một thách thức của thế giới kĩ thuật số.','Lợi ích: kết nối, tiện lợi; thách thức: an toàn thông tin, dễ phụ thuộc thiết bị (HS tự nêu).']]},
  {cd:'Bài 2: Thông tin trong giải quyết vấn đề',q:[
   [1,'Thông tin có vai trò gì trong giải quyết vấn đề?','giúp hiểu vấn đề và đưa ra quyết định đúng','không có vai trò','làm rối thêm','chỉ để lưu trữ'],
   [2,'Bước đầu tiên khi giải quyết một vấn đề bằng thông tin là gì?','thu thập và xác định thông tin cần thiết','kết luận ngay','bỏ qua dữ liệu','đoán mò'],
   [3,'Nêu các bước sử dụng thông tin để giải quyết một vấn đề.','Thu thập, chọn lọc, phân tích thông tin rồi đưa ra quyết định (HS tự nêu).']]},
  {cd:'Bài 3: Thực hành: Đánh giá chất lượng thông tin',q:[
   [1,'Thông tin chất lượng cần đảm bảo tiêu chí nào?','chính xác, đầy đủ, cập nhật và đáng tin cậy','giật gân','không rõ nguồn','sai lệch'],
   [2,'Để đánh giá thông tin, em nên dựa vào điều gì?','nguồn gốc, tác giả và đối chiếu nhiều nguồn','số lượt thích','màu sắc trang web','độ dài bài viết'],
   [3,'Nêu cách nhận biết một thông tin sai lệch (tin giả).','Nguồn không rõ ràng, tiêu đề giật gân, thiếu bằng chứng, các nguồn uy tín không xác nhận (HS tự nêu).']]},
  {cd:'Bài 4: Một số vấn đề pháp lí về sử dụng dịch vụ Internet',q:[
   [1,'Khi sử dụng Internet, công dân cần tuân thủ điều gì?','quy định của pháp luật','không cần quy tắc nào','chỉ ý thích cá nhân','luật của nước khác'],
   [2,'Hành vi nào là vi phạm pháp luật khi dùng Internet?','phát tán tin giả, xâm phạm bản quyền, lừa đảo trên mạng','học trực tuyến','gửi email công việc','tra cứu tài liệu'],
   [3,'Nêu một số việc nên làm để sử dụng Internet đúng pháp luật.','Tôn trọng bản quyền, không phát tán thông tin sai, bảo vệ thông tin cá nhân (HS tự nêu).']]},
  {cd:'Bài 5: Tìm hiểu phần mềm mô phỏng',q:[
   [1,'Phần mềm mô phỏng dùng để làm gì?','tái hiện sự vật, hiện tượng để quan sát, thử nghiệm','gửi thư','soạn thảo văn bản','chỉ để chơi game'],
   [2,'Lợi ích của phần mềm mô phỏng trong học tập là gì?','quan sát hiện tượng khó thực hiện thật, an toàn, tiết kiệm','làm bài khó hơn','gây nguy hiểm','không có lợi ích'],
   [3,'Nêu một ví dụ ứng dụng phần mềm mô phỏng.','VD: mô phỏng chuyển động hành tinh, thí nghiệm hóa học, hệ tuần hoàn (HS tự nêu).']]},
  {cd:'Bài 6: Thực hành: Khai thác phần mềm mô phỏng',q:[
   [1,'Khi khai thác phần mềm mô phỏng, em cần làm gì để hiểu bài?','thay đổi tham số và quan sát kết quả','tắt phần mềm ngay','không tương tác','chỉ nhìn một lần'],
   [2,'Phần mềm mô phỏng giúp em học tốt hơn nhờ điều gì?','trực quan, có thể thử nhiều trường hợp','làm mất thời gian','gây rối','không liên quan bài học'],
   [3,'Nêu các bước khai thác một phần mềm mô phỏng để tìm hiểu hiện tượng.','Chọn hiện tượng, thiết lập tham số, chạy mô phỏng, quan sát và rút ra nhận xét (HS tự nêu).']]},
  {cd:'Bài 7: Trình bày thông tin trong trao đổi và hợp tác',q:[
   [1,'Trình bày thông tin rõ ràng giúp ích gì khi làm việc nhóm?','mọi người hiểu đúng và hợp tác hiệu quả','gây hiểu lầm','làm chậm công việc','không cần thiết'],
   [2,'Công cụ nào hỗ trợ trao đổi, hợp tác trực tuyến?','tài liệu chia sẻ, bảng tính trực tuyến, email','chỉ giấy bút','máy ảnh','loa đài'],
   [3,'Nêu một lợi ích của việc dùng công cụ trực tuyến khi làm việc nhóm.','Nhiều người cùng chỉnh sửa, lưu lịch sử, làm việc từ xa, tiết kiệm thời gian (HS tự nêu).']]},
  {cd:'Bài 8: Thực hành: Sử dụng công cụ trực quan trình bày thông tin trong trao đổi và hợp tác',q:[
   [1,'Công cụ trực quan (sơ đồ, biểu đồ) giúp trình bày thông tin như thế nào?','dễ hiểu, dễ so sánh, hấp dẫn','khó hiểu hơn','làm mất thông tin','gây rối'],
   [2,'Khi trình bày kết quả làm việc nhóm, nên dùng hình thức nào?','kết hợp văn bản, sơ đồ, biểu đồ hợp lí','chỉ đọc chay','chỉ số liệu rời rạc','không chuẩn bị'],
   [3,'Nêu các bước tạo một sản phẩm trình bày thông tin của nhóm.','Thu thập dữ liệu, chọn công cụ trực quan, thiết kế, kiểm tra và trình bày (HS tự nêu).']]},
  {cd:'Bài 14: Giải quyết vấn đề',q:[
   [1,'Giải quyết vấn đề bằng máy tính bắt đầu bằng việc gì?','xác định rõ bài toán (đầu vào, đầu ra)','viết chương trình ngay','chạy thử bừa','bỏ qua phân tích'],
   [2,'Sau khi xác định bài toán, bước tiếp theo là gì?','xây dựng thuật toán','in kết quả','tắt máy','vẽ tranh'],
   [3,'Nêu các bước cơ bản để giải quyết một vấn đề bằng máy tính.','Xác định bài toán, xây dựng thuật toán, viết chương trình, chạy thử và hoàn thiện (HS tự nêu).']]},
  {cd:'Bài 15: Bài toán tin học',q:[
   [1,'Trong tin học, một bài toán thường được xác định bởi những yếu tố nào?','đầu vào (Input) và đầu ra (Output)','chỉ màu sắc','chỉ tên bài','chỉ thời gian'],
   [2,'Input của bài toán là gì?','thông tin, dữ liệu đã cho','kết quả cần tìm','tên chương trình','lỗi chương trình'],
   [3,'Hãy xác định Input và Output của bài toán "tính tổng hai số a và b".','Input: hai số a và b; Output: tổng a cộng b (HS tự nêu).']]},
  {cd:'Bài 16: Thực hành: Lập chương trình máy tính',q:[
   [1,'Khi lập chương trình, sau khi viết lệnh xong em cần làm gì?','chạy thử và kiểm tra kết quả','tắt máy ngay','xóa chương trình','không kiểm tra'],
   [2,'Nếu chương trình báo lỗi, em nên làm gì?','đọc thông báo lỗi và sửa từng bước','bỏ cuộc','đập máy','viết lại từ đầu không suy nghĩ'],
   [3,'Nêu các bước lập một chương trình máy tính đơn giản.','Xác định bài toán, viết thuật toán, viết lệnh, chạy thử, gỡ lỗi và hoàn thiện (HS tự nêu).']]},
  {cd:'Bài 17: Tin học và thế giới nghề nghiệp',q:[
   [1,'Tin học ảnh hưởng đến nghề nghiệp hiện nay như thế nào?','có mặt trong hầu hết các ngành, tạo nhiều nghề mới','không ảnh hưởng gì','chỉ dùng để chơi','làm mất việc làm hoàn toàn'],
   [2,'Đâu là nhóm nghề thuộc lĩnh vực công nghệ thông tin?','lập trình, an toàn mạng, phân tích dữ liệu, trí tuệ nhân tạo','trồng lúa','đánh cá','dệt vải thủ công'],
   [3,'Theo em, học tốt tin học giúp ích gì cho nghề nghiệp tương lai?','Có kĩ năng số, dễ thích ứng công việc, mở ra nhiều cơ hội nghề nghiệp (HS tự nêu).']]}
 );
 }


 /* ==================== CÔNG NGHỆ ==================== */
 const CN=NH['Công nghệ'];
 if(CN){
 CN[6].push(
  {cd:'Bài 1: Khái quát về nhà ở',q:[
   [1,'Nhà ở có vai trò gì đối với con người?','là nơi trú ngụ, bảo vệ con người khỏi ảnh hưởng của thiên nhiên','chỉ để trang trí','chỉ để chứa đồ','không cần thiết'],
   [2,'Nhà ở thường gồm các khu vực chức năng chính nào?','nơi thờ cúng, tiếp khách, ngủ nghỉ, nấu ăn, vệ sinh','chỉ phòng ngủ','chỉ bếp','chỉ sân vườn'],
   [3,'Kể tên các khu vực chính trong ngôi nhà của em.','VD: phòng khách, phòng ngủ, bếp, nhà vệ sinh, nơi thờ cúng (HS tự nêu).']]},
  {cd:'Bài 2: Xây dựng nhà ở',q:[
   [1,'Quá trình xây dựng nhà ở thường gồm mấy bước chính?','ba bước: chuẩn bị, thi công, hoàn thiện','một bước duy nhất','không cần chuẩn bị','chỉ thi công'],
   [2,'Vật liệu nào thường dùng để xây dựng nhà ở?','gạch, cát, xi măng, thép, gỗ','chỉ giấy','chỉ nhựa','chỉ vải'],
   [3,'Nêu các bước chính để xây dựng một ngôi nhà.','Chuẩn bị (thiết kế, vật liệu), thi công (móng, khung, tường, mái), hoàn thiện (HS tự nêu).']]},
  {cd:'Bài 3: Ngôi nhà thông minh',q:[
   [1,'Ngôi nhà thông minh là ngôi nhà được trang bị gì?','các thiết bị tự động điều khiển, giám sát','chỉ đồ cổ','không có điện','chỉ đồ gỗ'],
   [2,'Đặc điểm nào là của ngôi nhà thông minh?','tiện nghi, an toàn, tiết kiệm năng lượng','tốn điện, kém an toàn','không điều khiển được','thủ công hoàn toàn'],
   [3,'Kể một thiết bị thông minh thường có trong ngôi nhà thông minh.','VD: hệ thống đèn tự động, camera an ninh, điều khiển từ xa qua điện thoại (HS tự nêu).']]},
  {cd:'Bài 4: Thực phẩm và dinh dưỡng',q:[
   [1,'Nhóm chất dinh dưỡng nào cung cấp năng lượng chính cho cơ thể?','chất bột đường (tinh bột)','vitamin','chất khoáng','nước'],
   [2,'Thực phẩm giàu chất đạm (protein) gồm những loại nào?','thịt, cá, trứng, sữa, đậu','chỉ rau xanh','chỉ cơm','chỉ đường'],
   [3,'Vì sao cần ăn uống đủ chất và cân đối các nhóm thực phẩm?','Để cơ thể phát triển khỏe mạnh, đủ năng lượng và phòng bệnh (HS tự nêu).']]},
  {cd:'Bài 5: Phương pháp bảo quản và chế biến thực phẩm',q:[
   [1,'Phương pháp nào dùng để bảo quản thực phẩm?','làm lạnh, phơi khô, ướp muối','để ngoài trời nắng nóng','để nơi ẩm thấp','không cần bảo quản'],
   [2,'Chế biến thực phẩm có sử dụng nhiệt gồm cách nào?','luộc, nướng, rán, hấp','trộn gỏi','muối chua','ngâm giấm'],
   [3,'Nêu lợi ích của việc bảo quản thực phẩm đúng cách.','Giữ thực phẩm tươi lâu, tránh hư hỏng, bảo đảm an toàn và dinh dưỡng (HS tự nêu).']]},
  {cd:'Bài 6: Dự án: Bữa ăn kết nối yêu thương',q:[
   [1,'Khi xây dựng thực đơn cho bữa ăn gia đình, cần đảm bảo điều gì?','đủ chất dinh dưỡng, hợp khẩu vị và điều kiện gia đình','chỉ chọn món đắt tiền','chỉ một món','không cần cân đối'],
   [2,'Một bữa ăn hợp lí nên có đủ các nhóm thực phẩm nào?','bột đường, đạm, béo, vitamin và khoáng','chỉ chất béo','chỉ đường','chỉ thịt'],
   [3,'Hãy đề xuất thực đơn một bữa ăn đủ dinh dưỡng cho gia đình.','VD: cơm, canh rau, cá kho, rau luộc, trái cây (đủ các nhóm chất) (HS tự nêu).']]},
  {cd:'Bài 7: Trang phục trong đời sống',q:[
   [1,'Trang phục có vai trò gì trong đời sống?','bảo vệ cơ thể và làm đẹp cho con người','chỉ để khoe của','không có vai trò','chỉ để chơi'],
   [2,'Trang phục được phân loại theo tiêu chí nào?','theo thời tiết, công dụng, lứa tuổi, giới tính','theo giá tiền duy nhất','theo màu duy nhất','không phân loại'],
   [3,'Nêu cách lựa chọn trang phục phù hợp.','Phù hợp vóc dáng, lứa tuổi, hoàn cảnh, thời tiết và điều kiện kinh tế (HS tự nêu).']]},
  {cd:'Bài 8: Sử dụng và bảo quản trang phục',q:[
   [1,'Bảo quản trang phục gồm những công việc nào?','giặt, phơi, là (ủi) và cất giữ','chỉ mua mới','vứt bỏ sau một lần mặc','để bẩn lâu ngày'],
   [2,'Kí hiệu trên nhãn quần áo dùng để làm gì?','hướng dẫn cách giặt, là, bảo quản phù hợp','trang trí','ghi giá tiền','không có ý nghĩa'],
   [3,'Nêu cách bảo quản trang phục để dùng được bền lâu.','Giặt đúng cách, phơi nơi thoáng, là ở nhiệt độ phù hợp, gấp hoặc treo gọn gàng (HS tự nêu).']]},
  {cd:'Bài 9: Thời trang',q:[
   [1,'Thời trang là gì?','xu hướng sử dụng trang phục, phụ kiện phổ biến trong một thời kì','chỉ quần áo cũ','một loại thực phẩm','một loại nhà ở'],
   [2,'Khi chạy theo thời trang, học sinh cần lưu ý điều gì?','phù hợp lứa tuổi, hoàn cảnh và điều kiện gia đình','mua bằng mọi giá','đua đòi','bỏ học để theo mốt'],
   [3,'Nêu suy nghĩ của em về việc ăn mặc phù hợp với lứa tuổi học sinh.','Nên gọn gàng, lịch sự, phù hợp môi trường học đường, không đua đòi (HS tự nêu).']]},
  {cd:'Bài 10: Khái quát về đồ dùng điện trong gia đình',q:[
   [1,'Trên đồ dùng điện thường ghi các thông số kĩ thuật nào?','điện áp định mức và công suất định mức','chỉ màu sắc','chỉ tên người dùng','chỉ ngày mua'],
   [2,'Đơn vị đo công suất điện là gì?','oát (W)','mét (m)','gam (g)','giây (s)'],
   [3,'Vì sao cần chọn đồ dùng điện có điện áp định mức phù hợp với nguồn điện?','Để thiết bị hoạt động đúng, an toàn, tránh hỏng hóc hoặc cháy nổ (HS tự nêu).']]},
  {cd:'Bài 11: Đèn điện',q:[
   [1,'Loại đèn nào tiết kiệm điện năng hơn?','đèn LED','đèn sợi đốt','đèn dầu','đèn nến'],
   [2,'Đèn điện có công dụng chính là gì?','chiếu sáng','nấu ăn','làm mát','giặt quần áo'],
   [3,'Nêu một cách sử dụng đèn điện tiết kiệm và an toàn.','Tắt đèn khi không dùng, dùng đèn LED, không chạm tay ướt vào công tắc (HS tự nêu).']]},
  {cd:'Bài 12: Nồi cơm điện',q:[
   [1,'Nồi cơm điện dùng để làm gì?','nấu cơm và giữ ấm cơm','giặt quần áo','làm lạnh thực phẩm','chiếu sáng'],
   [2,'Bộ phận nào của nồi cơm điện sinh nhiệt để nấu cơm?','mâm nhiệt (bộ phận đốt nóng)','nắp nồi','tay cầm','dây điện'],
   [3,'Nêu cách sử dụng nồi cơm điện an toàn và bền.','Lau khô đáy nồi, đặt đúng mâm nhiệt, không dùng vật cứng cạo nồi, rút điện khi không dùng (HS tự nêu).']]},
  {cd:'Bài 13: Bếp hồng ngoại',q:[
   [1,'Bếp hồng ngoại dùng để làm gì?','đun nấu thức ăn bằng nhiệt từ bức xạ hồng ngoại','làm lạnh','chiếu sáng','giặt đồ'],
   [2,'Ưu điểm của bếp hồng ngoại là gì?','nấu được nhiều loại nồi, dễ vệ sinh','chỉ dùng nồi gang','tốn nhiều than','gây khói nhiều'],
   [3,'Nêu lưu ý khi sử dụng bếp hồng ngoại để bảo đảm an toàn.','Không chạm mặt bếp khi còn nóng, đặt bếp nơi khô ráo, rút điện sau khi dùng (HS tự nêu).']]},
  {cd:'Bài 14: Dự án: An toàn và tiết kiệm trong gia đình',q:[
   [1,'Biện pháp nào giúp tiết kiệm điện trong gia đình?','tắt thiết bị khi không dùng, dùng đèn LED','để thiết bị chạy suốt ngày','mở nhiều đèn cùng lúc','dùng thiết bị cũ hao điện'],
   [2,'Để an toàn khi dùng điện, em KHÔNG nên làm gì?','chạm tay ướt vào ổ điện, thiết bị điện','rút phích cắm khi không dùng','dùng dây điện còn tốt','báo người lớn khi có sự cố'],
   [3,'Nêu hai việc em có thể làm để sử dụng điện an toàn và tiết kiệm.','VD: tắt điện khi ra khỏi phòng, không dùng tay ướt chạm công tắc, dùng thiết bị tiết kiệm điện (HS tự nêu).']]}
 );
 CN[7].push(
  {cd:'Bài 1: Giới thiệu về trồng trọt',q:[
   [1,'Trồng trọt có vai trò gì trong đời sống?','cung cấp lương thực, thực phẩm, nguyên liệu','chỉ để làm cảnh','không có vai trò','chỉ gây ô nhiễm'],
   [2,'Nhóm cây trồng nào cung cấp lương thực chính?','cây lúa, ngô, khoai, sắn','cây hoa','cây cảnh','cỏ dại'],
   [3,'Kể tên một vài loại cây trồng và sản phẩm của chúng.','VD: lúa cho gạo, ngô cho hạt, rau cho thực phẩm (HS tự nêu).']]},
  {cd:'Bài 2: Làm đất trồng cây',q:[
   [1,'Làm đất trồng cây nhằm mục đích gì?','làm đất tơi xốp, sạch cỏ dại, giữ ẩm cho cây phát triển','làm đất cứng hơn','để nhiều cỏ','không có mục đích'],
   [2,'Công việc làm đất thường gồm những bước nào?','cày, bừa, lên luống','chỉ tưới nước','chỉ bón phân','chỉ gieo hạt'],
   [3,'Vì sao cần làm đất trước khi gieo trồng?','Giúp đất tơi xốp, thoáng khí, sạch cỏ, cây dễ bén rễ và phát triển tốt (HS tự nêu).']]},
  {cd:'Bài 3: Gieo trồng, chăm sóc và phòng trừ sâu, bệnh cho cây trồng',q:[
   [1,'Công việc chăm sóc cây trồng gồm những việc nào?','tưới nước, bón phân, làm cỏ, vun xới','chỉ để tự nhiên','chỉ thu hoạch','chỉ nhổ bỏ'],
   [2,'Biện pháp phòng trừ sâu bệnh an toàn, thân thiện môi trường là gì?','biện pháp sinh học (dùng thiên địch)','phun nhiều thuốc hóa học bừa bãi','đốt cả ruộng','bỏ mặc cây'],
   [3,'Nêu một số biện pháp phòng trừ sâu, bệnh cho cây trồng.','VD: biện pháp canh tác, sinh học, thủ công, hóa học (dùng đúng, hợp lí) (HS tự nêu).']]},
  {cd:'Bài 4: Thu hoạch sản phẩm trồng trọt',q:[
   [1,'Thu hoạch đúng thời điểm giúp gì?','bảo đảm năng suất và chất lượng sản phẩm','làm giảm năng suất','gây hư hỏng','không ảnh hưởng'],
   [2,'Phương pháp thu hoạch nào thường dùng?','hái, cắt, nhổ, đào tùy loại cây','chỉ đốt','chỉ để rụng','chỉ phun thuốc'],
   [3,'Vì sao cần thu hoạch đúng thời điểm và đúng cách?','Để sản phẩm đạt chất lượng tốt, ít hao hụt, bảo quản được lâu (HS tự nêu).']]},
  {cd:'Bài 5: Nhân giống vô tính cây trồng',q:[
   [1,'Nhân giống vô tính là tạo cây mới từ bộ phận nào của cây mẹ?','từ rễ, thân, lá (không qua hạt)','chỉ từ hạt','từ hoa thụ phấn','từ quả chín'],
   [2,'Đâu là phương pháp nhân giống vô tính?','giâm cành, chiết cành, ghép cây','gieo hạt','thụ phấn','trồng bằng quả'],
   [3,'Nêu một ưu điểm của nhân giống vô tính.','Giữ được đặc tính tốt của cây mẹ, cây nhanh cho thu hoạch (HS tự nêu).']]},
  {cd:'Bài 6: Dự án trồng rau an toàn',q:[
   [1,'Rau an toàn là rau được trồng và chăm sóc như thế nào?','theo quy trình bảo đảm an toàn, hạn chế hóa chất','phun nhiều thuốc trừ sâu','bón phân tùy ý','không kiểm soát'],
   [2,'Để trồng rau an toàn, cần chú ý điều gì?','chọn giống tốt, đất sạch, dùng phân và thuốc hợp lí','dùng nhiều hóa chất','tưới nước bẩn','bỏ qua sâu bệnh'],
   [3,'Nêu các bước cơ bản để trồng một luống rau an toàn.','Chuẩn bị đất, gieo trồng, chăm sóc (tưới, bón, làm cỏ), phòng trừ sâu bệnh hợp lí, thu hoạch (HS tự nêu).']]},
  {cd:'Bài 7: Giới thiệu về rừng',q:[
   [1,'Rừng có vai trò gì đối với môi trường?','điều hòa khí hậu, giữ đất, giữ nước, cung cấp gỗ','gây lũ lụt','làm ô nhiễm','không có vai trò'],
   [2,'Loại rừng nào có vai trò bảo vệ đất, chống xói mòn, điều tiết nước?','rừng phòng hộ','rừng chỉ để chặt','rừng bỏ hoang','không có loại nào'],
   [3,'Vì sao cần bảo vệ và phát triển rừng?','Rừng điều hòa khí hậu, giữ đất nước, bảo vệ môi trường và đa dạng sinh học (HS tự nêu).']]},
  {cd:'Bài 8: Trồng, chăm sóc và bảo vệ rừng',q:[
   [1,'Công việc chăm sóc rừng sau khi trồng gồm những gì?','làm cỏ, vun gốc, tỉa cành, phòng chống cháy rừng','chặt phá rừng','đốt rừng','bỏ mặc'],
   [2,'Hành vi nào gây hại cho rừng?','chặt phá rừng bừa bãi, đốt rừng làm nương','trồng cây gây rừng','chăm sóc cây con','phòng cháy rừng'],
   [3,'Nêu một số biện pháp bảo vệ rừng.','Trồng rừng, phòng chống cháy, ngăn chặn chặt phá trái phép, tuyên truyền bảo vệ rừng (HS tự nêu).']]},
  {cd:'Bài 9: Giới thiệu về chăn nuôi',q:[
   [1,'Chăn nuôi cung cấp sản phẩm gì cho con người?','thịt, trứng, sữa và nguyên liệu','chỉ gỗ','chỉ rau','chỉ hoa'],
   [2,'Vật nuôi nào thuộc nhóm gia cầm?','gà, vịt, ngan','trâu, bò','lợn','cá'],
   [3,'Nêu vai trò của chăn nuôi trong đời sống và kinh tế.','Cung cấp thực phẩm giàu đạm, nguyên liệu, phân bón và tăng thu nhập (HS tự nêu).']]},
  {cd:'Bài 10: Nuôi dưỡng và chăm sóc vật nuôi',q:[
   [1,'Nuôi dưỡng vật nuôi tốt cần đảm bảo điều gì?','cho ăn đủ chất, đủ lượng và nước sạch','bỏ đói','cho ăn thức ăn ôi thiu','không cho uống nước'],
   [2,'Chăm sóc vật nuôi gồm những việc nào?','vệ sinh chuồng trại, tiêm phòng, theo dõi sức khỏe','để chuồng bẩn','không tiêm phòng','bỏ mặc'],
   [3,'Vì sao cần giữ vệ sinh chuồng trại trong chăn nuôi?','Giúp vật nuôi khỏe mạnh, phòng bệnh, giảm ô nhiễm môi trường (HS tự nêu).']]},
  {cd:'Bài 11: Phòng và trị bệnh cho vật nuôi',q:[
   [1,'Biện pháp quan trọng để phòng bệnh cho vật nuôi là gì?','tiêm vắc xin và giữ vệ sinh chuồng trại','để vật nuôi tự khỏi','nuôi chung con bệnh với con khỏe','không tiêm phòng'],
   [2,'Khi vật nuôi có dấu hiệu bị bệnh, nên làm gì?','cách li và báo cán bộ thú y','thả ra ngoài','giết bỏ ngay','mặc kệ'],
   [3,'Nêu phương châm trong phòng, trị bệnh cho vật nuôi.','"Phòng bệnh hơn chữa bệnh": chăm sóc tốt, tiêm phòng, vệ sinh để ngăn bệnh (HS tự nêu).']]},
  {cd:'Bài 12: Chăn nuôi gà thịt trong nông hộ',q:[
   [1,'Chuồng nuôi gà thịt cần đảm bảo yêu cầu nào?','thoáng mát, khô ráo, sạch sẽ','ẩm thấp, bẩn','chật chội','tối tăm'],
   [2,'Thức ăn cho gà thịt cần đảm bảo điều gì?','đủ dinh dưỡng, sạch, phù hợp từng giai đoạn','ôi thiu','thiếu chất','chỉ nước'],
   [3,'Nêu các công việc chính khi nuôi gà thịt trong nông hộ.','Chuẩn bị chuồng, chọn giống, cho ăn uống, vệ sinh phòng bệnh, theo dõi và xuất bán (HS tự nêu).']]},
  {cd:'Bài 13: Thực hành. Lập kế hoạch nuôi vật nuôi trong gia đình',q:[
   [1,'Khi lập kế hoạch nuôi vật nuôi, cần xác định điều gì đầu tiên?','chọn vật nuôi phù hợp điều kiện gia đình','mua thật nhiều giống','nuôi không cần kế hoạch','bỏ qua chi phí'],
   [2,'Kế hoạch nuôi vật nuôi nên bao gồm nội dung nào?','chuồng trại, con giống, thức ăn, chăm sóc và chi phí','chỉ tên vật nuôi','chỉ màu lông','chỉ ngày mua'],
   [3,'Nêu các bước lập kế hoạch nuôi một loại vật nuôi trong gia đình.','Chọn vật nuôi, chuẩn bị chuồng và giống, lên kế hoạch thức ăn, chăm sóc, dự tính chi phí và thu nhập (HS tự nêu).']]},
  {cd:'Bài 14: Giới thiệu về thủy sản',q:[
   [1,'Thủy sản là những sinh vật sống ở đâu được con người nuôi, khai thác?','dưới nước','trên cạn','trên cây','trong không khí'],
   [2,'Sản phẩm thủy sản cung cấp cho con người chủ yếu là gì?','thực phẩm giàu đạm (cá, tôm, cua)','gỗ','vải','xăng dầu'],
   [3,'Nêu vai trò của ngành thủy sản.','Cung cấp thực phẩm, nguyên liệu chế biến, xuất khẩu và tạo việc làm (HS tự nêu).']]},
  {cd:'Bài 15: Nuôi cá ao',q:[
   [1,'Ao nuôi cá cần đảm bảo yêu cầu nào?','nguồn nước sạch, đủ oxygen, diện tích phù hợp','nước ô nhiễm','khô cạn','quá nhỏ hẹp'],
   [2,'Công việc chăm sóc cá trong ao gồm những gì?','cho ăn, quản lí nước, phòng bệnh cho cá','để cá tự kiếm ăn','không thay nước','bỏ mặc'],
   [3,'Nêu các công việc chính khi nuôi cá ao.','Chuẩn bị ao, thả cá giống, cho ăn, quản lí chất lượng nước, phòng bệnh và thu hoạch (HS tự nêu).']]},
  {cd:'Bài 16: Thực hành. Lập kế hoạch nuôi cá cảnh',q:[
   [1,'Khi nuôi cá cảnh, cần chuẩn bị điều gì?','bể nuôi, nước sạch, thức ăn phù hợp cho cá','chỉ một cái cốc','nước bẩn','không cần chuẩn bị'],
   [2,'Để cá cảnh khỏe và đẹp, cần làm gì?','thay nước định kì, cho ăn vừa đủ, giữ bể sạch','cho ăn thật nhiều','không thay nước','nuôi quá nhiều cá một bể'],
   [3,'Nêu các bước lập kế hoạch nuôi cá cảnh.','Chọn loại cá, chuẩn bị bể và dụng cụ, lên kế hoạch cho ăn và chăm sóc, dự tính chi phí (HS tự nêu).']]}
 );
 CN[8].push(
  {cd:'Bài 1: Một số tiêu chuẩn trình bày bản vẽ kĩ thuật',q:[
   [1,'Bản vẽ kĩ thuật được lập theo các quy tắc gì?','các tiêu chuẩn thống nhất (khổ giấy, tỉ lệ, nét vẽ, chữ)','tùy ý mỗi người','không có quy tắc','theo cảm hứng'],
   [2,'Khổ giấy A4 có kích thước là bao nhiêu?','210 mm x 297 mm','100 mm x 100 mm','300 mm x 400 mm','150 mm x 200 mm'],
   [3,'Vì sao bản vẽ kĩ thuật cần tuân theo tiêu chuẩn chung?','Để mọi người đọc và hiểu bản vẽ thống nhất, chính xác khi chế tạo, thi công (HS tự nêu).']]},
  {cd:'Bài 2: Hình chiếu vuông góc',q:[
   [1,'Hình chiếu vuông góc dùng để làm gì?','biểu diễn hình dạng vật thể trên các mặt phẳng chiếu','tô màu vật thể','chụp ảnh vật','cân vật'],
   [2,'Ba hình chiếu thường dùng của một vật thể là gì?','hình chiếu đứng, hình chiếu bằng, hình chiếu cạnh','hình chiếu trái, phải, trên','chỉ một hình chiếu','hình chiếu tròn'],
   [3,'Nêu vị trí của hình chiếu bằng so với hình chiếu đứng trên bản vẽ.','Hình chiếu bằng đặt ở phía dưới hình chiếu đứng (HS tự nêu).']]},
  {cd:'Bài 3: Bản vẽ chi tiết',q:[
   [1,'Bản vẽ chi tiết dùng để làm gì?','thể hiện hình dạng, kích thước và yêu cầu kĩ thuật của một chi tiết','vẽ toàn bộ ngôi nhà','trang trí','ghi nhật kí'],
   [2,'Bản vẽ chi tiết thường gồm những nội dung nào?','hình biểu diễn, kích thước, yêu cầu kĩ thuật và khung tên','chỉ hình vẽ','chỉ khung tên','chỉ màu sắc'],
   [3,'Bản vẽ chi tiết dùng trong công việc gì?','Dùng để chế tạo và kiểm tra chi tiết máy (HS tự nêu).']]},
  {cd:'Bài 4: Bản vẽ lắp',q:[
   [1,'Bản vẽ lắp dùng để làm gì?','thể hiện cách lắp ghép các chi tiết của một sản phẩm','vẽ một chi tiết riêng lẻ','trang trí nhà','ghi công thức'],
   [2,'Bản vẽ lắp thường có thêm nội dung nào so với bản vẽ chi tiết?','bảng kê các chi tiết','chỉ màu nền','chỉ chữ kí','không có gì thêm'],
   [3,'Bản vẽ lắp dùng trong giai đoạn nào?','Dùng khi lắp ráp và kiểm tra sản phẩm (HS tự nêu).']]},
  {cd:'Bài 5: Bản vẽ nhà',q:[
   [1,'Bản vẽ nhà dùng để làm gì?','thể hiện hình dạng, kích thước và cấu tạo của ngôi nhà','vẽ chi tiết máy','ghi thực đơn','vẽ bản đồ'],
   [2,'Mặt bằng trong bản vẽ nhà thể hiện điều gì?','vị trí, kích thước các phòng, tường, cửa','màu sơn tường','giá tiền','tên chủ nhà'],
   [3,'Nêu các hình biểu diễn chính của một bản vẽ nhà.','Mặt bằng, mặt đứng, mặt cắt của ngôi nhà (HS tự nêu).']]},
  {cd:'Bài 6: Vật liệu cơ khí',q:[
   [1,'Vật liệu cơ khí được chia thành hai nhóm chính nào?','vật liệu kim loại và vật liệu phi kim loại','gỗ và giấy','nước và khí','vải và nhựa'],
   [2,'Đâu là vật liệu kim loại?','thép, gang, đồng, nhôm','nhựa','cao su','gỗ'],
   [3,'Nêu một tính chất của kim loại và một ứng dụng của nó.','VD: thép cứng, bền nên làm khung máy, cầu; nhôm nhẹ nên làm xoong nồi (HS tự nêu).']]},
  {cd:'Bài 7: Truyền và biến đổi chuyển động',q:[
   [1,'Cơ cấu truyền chuyển động dùng để làm gì?','truyền chuyển động từ bộ phận này sang bộ phận khác','dừng máy','trang trí','đo nhiệt độ'],
   [2,'Bộ truyền động đai, bánh răng thuộc loại cơ cấu nào?','truyền chuyển động quay','biến chuyển động quay thành tịnh tiến','đứng yên','không truyền'],
   [3,'Nêu một ví dụ về cơ cấu truyền chuyển động trong đời sống.','VD: xích và đĩa của xe đạp truyền chuyển động từ bàn đạp đến bánh xe (HS tự nêu).']]},
  {cd:'Bài 8: Gia công cơ khí bằng tay',q:[
   [1,'Gia công cơ khí bằng tay sử dụng chủ yếu là gì?','dụng cụ cầm tay (cưa, giũa, đục...)','máy móc tự động hoàn toàn','không dùng dụng cụ','chỉ dùng điện'],
   [2,'Khi gia công cơ khí bằng tay, cần chú ý điều gì?','bảo đảm an toàn lao động','làm thật nhanh bất chấp','không cần dụng cụ bảo hộ','đùa nghịch khi làm'],
   [3,'Kể tên một số dụng cụ gia công cơ khí bằng tay.','VD: cưa, giũa, đục, búa, kìm, mỏ lết (HS tự nêu).']]},
  {cd:'Bài 9: Ngành nghề trong lĩnh vực cơ khí',q:[
   [1,'Đâu là một nghề thuộc lĩnh vực cơ khí?','thợ tiện, thợ hàn, kĩ sư cơ khí','đầu bếp','giáo viên văn','bác sĩ'],
   [2,'Người làm trong lĩnh vực cơ khí cần có phẩm chất nào?','cẩn thận, kiên trì, có sức khỏe và kĩ năng','lười biếng','cẩu thả','ngại học hỏi'],
   [3,'Nêu một số ngành nghề trong lĩnh vực cơ khí.','VD: kĩ sư cơ khí, thợ tiện, thợ phay, thợ hàn, kĩ thuật viên (HS tự nêu).']]},
  {cd:'Bài 10: Dự án: Gia công chi tiết bằng dụng cụ cầm tay',q:[
   [1,'Trước khi gia công một chi tiết, cần làm gì?','đọc bản vẽ và chuẩn bị dụng cụ, vật liệu','làm ngay không chuẩn bị','bỏ qua bản vẽ','đoán kích thước'],
   [2,'Trong quá trình gia công, điều quan trọng nhất là gì?','bảo đảm an toàn và đúng kích thước bản vẽ','làm thật nhanh','không đo đạc','bỏ qua an toàn'],
   [3,'Nêu các bước gia công một chi tiết đơn giản bằng dụng cụ cầm tay.','Đọc bản vẽ, chuẩn bị, vạch dấu, gia công (cưa, giũa), kiểm tra kích thước (HS tự nêu).']]},
  {cd:'Bài 11: Tai nạn điện',q:[
   [1,'Nguyên nhân nào thường gây tai nạn điện?','chạm trực tiếp vào vật mang điện, dây điện hở','dùng đồ gỗ','uống nước','đọc sách'],
   [2,'Khi thấy dây điện bị đứt rơi xuống đất, em nên làm gì?','tránh xa và báo người lớn, cơ quan điện lực','cầm lên xem','đạp lên dây','để tay ướt sờ vào'],
   [3,'Nêu một số nguyên nhân gây tai nạn điện trong gia đình.','Chạm vào dây hở, dùng thiết bị hỏng, tay ướt chạm điện, vi phạm khoảng cách an toàn (HS tự nêu).']]},
  {cd:'Bài 12: Biện pháp an toàn điện',q:[
   [1,'Biện pháp an toàn điện nào nên thực hiện?','không chạm tay ướt vào thiết bị điện, dùng dây dẫn có vỏ cách điện','dùng dây điện trần','cắm nhiều thiết bị vào một ổ','chạm điện bằng tay ướt'],
   [2,'Trước khi sửa chữa đồ dùng điện, cần làm gì?','ngắt nguồn điện (rút phích cắm, tắt cầu dao)','để nguyên điện','dùng tay ướt','vừa sửa vừa cắm điện'],
   [3,'Nêu hai biện pháp an toàn khi sử dụng điện trong gia đình.','VD: dùng thiết bị có vỏ cách điện, không chạm tay ướt, lắp cầu dao chống giật (HS tự nêu).']]},
  {cd:'Bài 13: Sơ cứu người bị tai nạn điện',q:[
   [1,'Việc đầu tiên khi cứu người bị điện giật là gì?','nhanh chóng tách nạn nhân ra khỏi nguồn điện một cách an toàn','chạm ngay vào nạn nhân','bỏ chạy','tưới nước lên nạn nhân'],
   [2,'Khi tách nạn nhân khỏi nguồn điện, em nên làm gì?','ngắt nguồn điện hoặc dùng vật cách điện khô','dùng tay không kéo nạn nhân','dùng vật bằng kim loại','không làm gì cả'],
   [3,'Nêu các bước sơ cứu cơ bản người bị điện giật.','Ngắt nguồn điện, tách nạn nhân an toàn, gọi cấp cứu 115, sơ cứu (hô hấp) nếu cần (HS tự nêu).']]},
  {cd:'Bài 14: Khái quát về mạch điện',q:[
   [1,'Mạch điện đơn giản gồm những thành phần cơ bản nào?','nguồn điện, dây dẫn và thiết bị tiêu thụ điện','chỉ nguồn điện','chỉ dây dẫn','chỉ công tắc'],
   [2,'Công tắc trong mạch điện có chức năng gì?','đóng, ngắt mạch điện','phát sáng','sinh nhiệt','tạo nguồn điện'],
   [3,'Nêu vai trò của các thành phần trong một mạch điện đơn giản.','Nguồn cấp điện, dây dẫn truyền điện, thiết bị tiêu thụ điện (bóng đèn), công tắc đóng ngắt (HS tự nêu).']]},
  {cd:'Bài 15: Cảm biến và mô đun cảm biến',q:[
   [1,'Cảm biến dùng để làm gì?','phát hiện và đo các đại lượng (ánh sáng, nhiệt độ, độ ẩm...)','phát sáng','sinh nhiệt','tạo điện'],
   [2,'Cảm biến ánh sáng phản ứng với đại lượng nào?','cường độ ánh sáng','âm thanh','mùi vị','khối lượng'],
   [3,'Nêu một ứng dụng của cảm biến trong đời sống.','VD: đèn tự động bật khi trời tối (cảm biến ánh sáng), cửa tự động (HS tự nêu).']]},
  {cd:'Bài 16: Mạch điện điều khiển sử dụng mô đun cảm biến',q:[
   [1,'Mạch điện điều khiển dùng mô đun cảm biến có ưu điểm gì?','tự động đóng ngắt theo điều kiện môi trường','phải điều khiển bằng tay','không hoạt động','tốn công'],
   [2,'Mạch đèn dùng cảm biến ánh sáng sẽ hoạt động như thế nào?','tự bật khi tối, tự tắt khi sáng','luôn tắt','luôn bật','không đổi'],
   [3,'Nêu một ví dụ mạch điện điều khiển dùng cảm biến.','VD: mạch đèn tự động theo ánh sáng, quạt tự bật theo nhiệt độ (HS tự nêu).']]},
  {cd:'Bài 17: Ngành nghề trong lĩnh vực kĩ thuật điện',q:[
   [1,'Đâu là một nghề thuộc lĩnh vực kĩ thuật điện?','thợ điện, kĩ sư điện','đầu bếp','nông dân','thợ may'],
   [2,'Người làm nghề điện cần đặc biệt chú ý điều gì?','an toàn điện','ăn mặc đẹp','nói to','đi nhanh'],
   [3,'Kể tên một số ngành nghề trong lĩnh vực kĩ thuật điện.','VD: kĩ sư điện, thợ điện, kĩ thuật viên điện, công nhân vận hành điện (HS tự nêu).']]},
  {cd:'Bài 18: Giới thiệu về thiết kế kĩ thuật',q:[
   [1,'Thiết kế kĩ thuật là gì?','quá trình tạo ra giải pháp, sản phẩm để giải quyết một vấn đề','sao chép nguyên mẫu','vẽ tranh tùy ý','không có mục đích'],
   [2,'Mục đích của thiết kế kĩ thuật là gì?','tạo ra sản phẩm đáp ứng nhu cầu con người','làm cho phức tạp','gây lãng phí','không giải quyết gì'],
   [3,'Nêu vai trò của thiết kế kĩ thuật trong đời sống.','Tạo ra sản phẩm mới, cải tiến sản phẩm, giải quyết vấn đề thực tiễn (HS tự nêu).']]},
  {cd:'Bài 19: Các bước cơ bản trong thiết kế kĩ thuật',q:[
   [1,'Bước đầu tiên trong quy trình thiết kế kĩ thuật là gì?','xác định vấn đề, yêu cầu cần giải quyết','làm sản phẩm ngay','bỏ qua khảo sát','sao chép'],
   [2,'Sau khi có ý tưởng, bước tiếp theo thường là gì?','lựa chọn giải pháp và làm sản phẩm mẫu','bán sản phẩm','ngừng lại','vứt bỏ ý tưởng'],
   [3,'Nêu các bước cơ bản trong thiết kế kĩ thuật.','Xác định vấn đề, tìm hiểu, đề xuất ý tưởng, lựa chọn giải pháp, làm mẫu, thử nghiệm và hoàn thiện (HS tự nêu).']]},
  {cd:'Bài 20: Dự án: Thiết kế hệ thống tưới cây tự động',q:[
   [1,'Hệ thống tưới cây tự động giúp ích gì?','tưới cây đúng lúc, tiết kiệm nước và công sức','làm hỏng cây','tốn nước hơn','không có tác dụng'],
   [2,'Bộ phận nào giúp hệ thống tưới cây tự động nhận biết đất khô?','cảm biến độ ẩm đất','bóng đèn','loa','quạt'],
   [3,'Nêu ý tưởng thiết kế một hệ thống tưới cây tự động đơn giản.','Dùng cảm biến độ ẩm; khi đất khô, mạch điều khiển bật máy bơm tưới nước (HS tự nêu).']]}
 );
 CN[9].push(
  {cd:'Bài 1: Thành phần dinh dưỡng trong thực phẩm',q:[
   [1,'Các nhóm chất dinh dưỡng chính trong thực phẩm gồm những gì?','chất đạm, chất béo, chất bột đường, vitamin và khoáng','chỉ chất béo','chỉ đường','chỉ nước'],
   [2,'Nhóm chất nào giúp xây dựng và phát triển cơ thể?','chất đạm (protein)','chỉ nước','chỉ chất xơ','chỉ vitamin'],
   [3,'Vì sao cần ăn phối hợp nhiều loại thực phẩm?','Để cung cấp đủ và cân đối các chất dinh dưỡng cho cơ thể (HS tự nêu).']]},
  {cd:'Bài 2: Lựa chọn và bảo quản thực phẩm',q:[
   [1,'Khi lựa chọn thực phẩm tươi, cần chú ý điều gì?','còn tươi, màu sắc và mùi tự nhiên, rõ nguồn gốc','đã ôi thiu','hết hạn','mốc hỏng'],
   [2,'Phương pháp bảo quản thực phẩm bằng nhiệt độ thấp là gì?','làm lạnh, cấp đông','phơi nắng nóng','để ngoài trời','ướp đường'],
   [3,'Nêu cách bảo quản thực phẩm tươi sống trong gia đình.','Rửa sạch, để ngăn mát hoặc đông lạnh, đậy kín, dùng trong thời gian phù hợp (HS tự nêu).']]},
  {cd:'Bài 3: Một số ngành nghề liên quan đến chế biến thực phẩm',q:[
   [1,'Đâu là một nghề liên quan đến chế biến thực phẩm?','đầu bếp, kĩ sư công nghệ thực phẩm','thợ điện','thợ cơ khí','kĩ sư xây dựng'],
   [2,'Người làm nghề chế biến thực phẩm cần đảm bảo điều gì?','vệ sinh an toàn thực phẩm','làm bẩn thực phẩm','không rửa tay','dùng nguyên liệu hỏng'],
   [3,'Kể tên một vài nghề liên quan đến chế biến thực phẩm.','VD: đầu bếp, nhân viên chế biến, kĩ sư công nghệ thực phẩm, thợ làm bánh (HS tự nêu).']]},
  {cd:'Bài 4: An toàn lao động và an toàn vệ sinh thực phẩm',q:[
   [1,'An toàn vệ sinh thực phẩm nhằm mục đích gì?','bảo đảm thực phẩm sạch, không gây hại cho sức khỏe','làm thực phẩm bẩn','gây ngộ độc','không cần thiết'],
   [2,'Việc làm nào bảo đảm an toàn vệ sinh thực phẩm?','rửa tay, dụng cụ sạch, nấu chín, bảo quản đúng','dùng thực phẩm ôi thiu','để ruồi nhặng đậu','không rửa rau'],
   [3,'Nêu một số nguyên tắc bảo đảm an toàn vệ sinh thực phẩm khi nấu ăn.','Chọn thực phẩm sạch, rửa tay và dụng cụ, nấu chín, ăn ngay, bảo quản đúng (HS tự nêu).']]},
  {cd:'Bài 5: Dự án: Tính toán chi phí bữa ăn theo thực đơn',q:[
   [1,'Để tính chi phí bữa ăn, cần biết điều gì?','giá và lượng của từng nguyên liệu','chỉ tên món','chỉ màu món ăn','không cần gì'],
   [2,'Chi phí bữa ăn được tính như thế nào?','cộng chi phí các nguyên liệu dùng trong bữa ăn','lấy một món nhân hai','đoán đại','không tính được'],
   [3,'Nêu các bước tính chi phí cho một bữa ăn theo thực đơn.','Liệt kê món và nguyên liệu, xác định lượng và giá, tính tiền từng loại rồi cộng tổng (HS tự nêu).']]},
  {cd:'Bài 6: Chế biến thực phẩm có sử dụng nhiệt',q:[
   [1,'Phương pháp nào là chế biến thực phẩm có sử dụng nhiệt?','luộc, nướng, rán, hấp, kho','trộn gỏi','muối chua','ngâm giấm'],
   [2,'Chế biến thực phẩm bằng nhiệt có tác dụng gì?','làm chín, dễ tiêu hóa và an toàn hơn','làm thực phẩm sống','gây ôi thiu','làm mất hoàn toàn dinh dưỡng'],
   [3,'Kể tên một số món ăn được chế biến có sử dụng nhiệt.','VD: thịt kho, cá rán, rau luộc, bánh nướng (HS tự nêu).']]},
  {cd:'Bài 7: Chế biến thực phẩm không sử dụng nhiệt',q:[
   [1,'Phương pháp nào là chế biến thực phẩm không sử dụng nhiệt?','trộn (gỏi, nộm), muối chua','luộc','nướng','rán'],
   [2,'Món ăn chế biến không dùng nhiệt cần đặc biệt chú ý điều gì?','vệ sinh an toàn thực phẩm (nguyên liệu sạch)','nấu thật kĩ','dùng lửa to','để lâu ngoài trời'],
   [3,'Kể tên một số món ăn chế biến không sử dụng nhiệt.','VD: nộm (gỏi), dưa muối, rau sống, salad (HS tự nêu).']]}
 );
 }


 /* ==================== KHOA HỌC TỰ NHIÊN ==================== */
 const KH=NH['Khoa học tự nhiên'];
 if(KH){
 KH[6].push(
  {cd:'Bài 1: Giới thiệu về Khoa học tự nhiên',q:[
   [1,'Khoa học tự nhiên là ngành khoa học nghiên cứu về điều gì?','các sự vật, hiện tượng của thế giới tự nhiên','lịch sử loài người','ngôn ngữ','luật pháp'],
   [2,'Lĩnh vực nào sau đây thuộc Khoa học tự nhiên?','Vật lí, Hóa học, Sinh học','Văn học','Lịch sử','Âm nhạc'],
   [3,'Nêu vai trò của Khoa học tự nhiên trong đời sống.','Giúp con người hiểu, ứng dụng vào sản xuất, y học, bảo vệ môi trường và nâng cao đời sống (HS tự nêu).']]},
  {cd:'Bài 2: An toàn trong phòng thực hành',q:[
   [1,'Khi làm thí nghiệm trong phòng thực hành, em cần làm gì?','tuân thủ nội quy và hướng dẫn của giáo viên','tự ý làm theo ý thích','nếm thử hóa chất','đùa nghịch'],
   [2,'Kí hiệu cảnh báo trong phòng thực hành dùng để làm gì?','báo hiệu nguy hiểm để phòng tránh','trang trí','ghi tên','không có ý nghĩa'],
   [3,'Nêu một số quy tắc an toàn khi làm thí nghiệm.','Không nếm, ngửi trực tiếp hóa chất; đeo dụng cụ bảo hộ; làm theo hướng dẫn; dọn dẹp sau khi làm (HS tự nêu).']]},
  {cd:'Bài 3: Sử dụng kính lúp',q:[
   [1,'Kính lúp dùng để làm gì?','phóng to ảnh của vật nhỏ để quan sát rõ hơn','đo khối lượng','đo thời gian','nghe âm thanh'],
   [2,'Bộ phận chính của kính lúp là gì?','một tấm kính lồi (thấu kính hội tụ)','một sợi dây','một cục nam châm','một chiếc gương phẳng'],
   [3,'Nêu một trường hợp cần dùng kính lúp.','VD: quan sát gân lá, chân con kiến, chi tiết nhỏ của vật (HS tự nêu).']]},
  {cd:'Bài 4: Sử dụng kính hiển vi quang học',q:[
   [1,'Kính hiển vi quang học dùng để làm gì?','quan sát những vật rất nhỏ mà mắt thường không thấy được','đo chiều dài','nghe âm','nấu ăn'],
   [2,'Kính hiển vi quang học có độ phóng đại như thế nào so với kính lúp?','lớn hơn nhiều','nhỏ hơn','bằng nhau','không phóng đại'],
   [3,'Kể một đối tượng cần quan sát bằng kính hiển vi.','VD: tế bào, vi khuẩn, cấu tạo nhỏ của lá cây (HS tự nêu).']]},
  {cd:'Bài 5: Đo chiều dài',q:[
   [1,'Dụng cụ nào dùng để đo chiều dài?','thước','cân','đồng hồ','nhiệt kế'],
   [2,'Đơn vị đo chiều dài trong hệ đo lường chính thức là gì?','mét (m)','kilôgam (kg)','giây (s)','độ C'],
   [3,'Nêu các bước cơ bản khi đo chiều dài một vật.','Ước lượng, chọn thước phù hợp, đặt thước đúng, đọc và ghi kết quả theo vạch gần nhất (HS tự nêu).']]},
  {cd:'Bài 6: Đo khối lượng',q:[
   [1,'Dụng cụ nào dùng để đo khối lượng?','cân','thước','đồng hồ','nhiệt kế'],
   [2,'Đơn vị đo khối lượng thường dùng là gì?','kilôgam (kg)','mét (m)','giây (s)','newton'],
   [3,'Nêu lưu ý khi dùng cân để đo khối lượng.','Chọn cân phù hợp, điều chỉnh cân về 0, đặt vật nhẹ nhàng, đọc đúng kết quả (HS tự nêu).']]},
  {cd:'Bài 7: Đo thời gian',q:[
   [1,'Dụng cụ nào dùng để đo thời gian?','đồng hồ','thước','cân','nhiệt kế'],
   [2,'Đơn vị đo thời gian trong hệ chính thức là gì?','giây (s)','mét (m)','kilôgam (kg)','lít'],
   [3,'Nêu cách đo thời gian của một hoạt động bằng đồng hồ bấm giây.','Bấm bắt đầu khi hoạt động bắt đầu, bấm dừng khi kết thúc, đọc kết quả (HS tự nêu).']]},
  {cd:'Bài 8: Đo nhiệt độ',q:[
   [1,'Dụng cụ nào dùng để đo nhiệt độ?','nhiệt kế','cân','thước','đồng hồ'],
   [2,'Đơn vị đo nhiệt độ thường dùng ở Việt Nam là gì?','độ C (°C)','mét','giây','kilôgam'],
   [3,'Nêu một số loại nhiệt kế thường gặp.','VD: nhiệt kế y tế, nhiệt kế rượu, nhiệt kế điện tử (HS tự nêu).']]},
  {cd:'Bài 9: Sự đa dạng của chất',q:[
   [1,'Vật thể được tạo nên từ cái gì?','chất','không có gì','chỉ năng lượng','chỉ ánh sáng'],
   [2,'Đâu là vật thể tự nhiên?','cây, đá, nước','bàn ghế','xe máy','nhà cửa'],
   [3,'Phân biệt vật thể và chất, cho một ví dụ.','Vật thể là vật cụ thể (cái cốc), chất là thành phần tạo nên vật thể (thủy tinh) (HS tự nêu).']]},
  {cd:'Bài 10: Các thể của chất và sự chuyển thể',q:[
   [1,'Chất thường tồn tại ở mấy thể cơ bản?','ba thể: rắn, lỏng, khí','một thể','hai thể','năm thể'],
   [2,'Quá trình nước lỏng biến thành hơi gọi là gì?','sự bay hơi','sự đông đặc','sự nóng chảy','sự ngưng tụ'],
   [3,'Nêu ví dụ về sự chuyển thể của nước.','Nước đá (rắn) nóng chảy thành nước (lỏng), bay hơi thành hơi (khí), ngưng tụ lại thành nước (HS tự nêu).']]},
  {cd:'Bài 11: Oxygen. Không khí',q:[
   [1,'Oxygen trong không khí chiếm khoảng bao nhiêu phần trăm thể tích?','khoảng 21%','khoảng 78%','khoảng 50%','khoảng 100%'],
   [2,'Khí nào chiếm tỉ lệ lớn nhất trong không khí?','khí nitrogen','khí oxygen','khí carbon dioxide','hơi nước'],
   [3,'Nêu vai trò của oxygen đối với sự sống.','Cần cho hô hấp của con người, động vật và sự cháy (HS tự nêu).']]},
  {cd:'Bài 12: Một số vật liệu',q:[
   [1,'Vật liệu nào thường dùng để làm dây dẫn điện?','kim loại (đồng, nhôm)','gỗ','nhựa','thủy tinh'],
   [2,'Khi sử dụng vật liệu, cần chú ý điều gì?','sử dụng hợp lí, an toàn và bảo vệ môi trường','dùng lãng phí','vứt bừa bãi','không tái chế'],
   [3,'Kể tên một số vật liệu thông dụng và ứng dụng của chúng.','VD: kim loại (làm máy móc), gỗ (làm bàn ghế), nhựa, thủy tinh (HS tự nêu).']]},
  {cd:'Bài 13: Một số nguyên liệu',q:[
   [1,'Nguyên liệu là gì?','vật liệu tự nhiên dùng để sản xuất ra sản phẩm','sản phẩm cuối cùng','rác thải','năng lượng'],
   [2,'Đá vôi là nguyên liệu để sản xuất ra sản phẩm nào?','xi măng, vôi','xăng dầu','vải','giấy'],
   [3,'Vì sao cần sử dụng nguyên liệu tiết kiệm, hiệu quả?','Vì nhiều nguyên liệu có hạn, khai thác nhiều gây cạn kiệt và ô nhiễm môi trường (HS tự nêu).']]},
  {cd:'Bài 14: Một số nhiên liệu',q:[
   [1,'Nhiên liệu là những chất khi cháy sinh ra điều gì?','nhiệt và ánh sáng','nước sạch','không khí','tiếng ồn'],
   [2,'Đâu là nhiên liệu?','than, củi, xăng, dầu, khí gas','nước','đá','sắt'],
   [3,'Nêu cách sử dụng nhiên liệu an toàn và tiết kiệm.','Dùng vừa đủ, để xa nguồn lửa khi không dùng, dùng nhiên liệu sạch khi có thể (HS tự nêu).']]},
  {cd:'Bài 15: Một số lương thực, thực phẩm',q:[
   [1,'Nhóm nào cung cấp tinh bột (chất bột đường) cho cơ thể?','gạo, ngô, khoai, sắn','thịt, cá','dầu mỡ','rau xanh'],
   [2,'Thực phẩm giàu chất đạm gồm những loại nào?','thịt, cá, trứng, sữa, đậu','chỉ cơm','chỉ đường','chỉ muối'],
   [3,'Vì sao cần ăn phối hợp nhiều loại lương thực, thực phẩm?','Để cung cấp đủ và cân đối các chất dinh dưỡng cho cơ thể khỏe mạnh (HS tự nêu).']]},
  {cd:'Bài 16: Hỗn hợp các chất',q:[
   [1,'Hỗn hợp là gì?','gồm hai hay nhiều chất trộn lẫn với nhau','chỉ một chất tinh khiết','một nguyên tử','một phân tử'],
   [2,'Nước muối là loại hỗn hợp nào?','dung dịch (hỗn hợp đồng nhất)','chất tinh khiết','hỗn hợp không đồng nhất','một nguyên tố'],
   [3,'Phân biệt chất tinh khiết và hỗn hợp, cho ví dụ.','Chất tinh khiết chỉ một chất (nước cất); hỗn hợp gồm nhiều chất (nước muối) (HS tự nêu).']]},
  {cd:'Bài 17: Tách chất khỏi hỗn hợp',q:[
   [1,'Phương pháp nào dùng để tách chất rắn không tan ra khỏi nước?','lọc','đun sôi','để yên mãi','trộn thêm'],
   [2,'Để thu muối ăn từ nước muối, người ta dùng cách nào?','cô cạn (làm bay hơi nước)','lọc','gạn','để lạnh'],
   [3,'Nêu một số phương pháp tách chất ra khỏi hỗn hợp.','Lọc, cô cạn, chiết, gạn tùy vào tính chất của các chất (HS tự nêu).']]},
  {cd:'Bài 18: Tế bào – Đơn vị cơ bản của sự sống',q:[
   [1,'Đơn vị cơ bản cấu tạo nên cơ thể sống là gì?','tế bào','nguyên tử','phân tử','mô'],
   [2,'Vì sao nói tế bào là đơn vị cơ bản của sự sống?','vì mọi cơ thể sống đều được cấu tạo từ tế bào','vì tế bào không sống','vì tế bào rất lớn','vì tế bào là kim loại'],
   [3,'Nêu một ví dụ cho thấy cơ thể được cấu tạo từ tế bào.','Cơ thể người, cây xanh đều gồm rất nhiều tế bào (HS tự nêu).']]},
  {cd:'Bài 19: Cấu tạo và chức năng các thành phần của tế bào',q:[
   [1,'Ba thành phần chính của tế bào là gì?','màng tế bào, tế bào chất và nhân (hoặc vùng nhân)','chỉ màng','chỉ nhân','rễ, thân, lá'],
   [2,'Thành phần nào điều khiển mọi hoạt động của tế bào?','nhân tế bào','màng tế bào','thành tế bào','không bào'],
   [3,'Nêu chức năng của màng tế bào.','Bao bọc tế bào, kiểm soát các chất đi vào và ra khỏi tế bào (HS tự nêu).']]},
  {cd:'Bài 20: Sự lớn lên và sinh sản của tế bào',q:[
   [1,'Tế bào lớn lên rồi sinh sản bằng cách nào?','phân chia (một tế bào tạo thành hai tế bào con)','không thay đổi','biến mất','hóa đá'],
   [2,'Sự sinh sản (phân chia) của tế bào giúp cơ thể làm gì?','lớn lên và thay thế các tế bào chết','nhỏ đi','ngừng phát triển','không có tác dụng'],
   [3,'Vì sao cơ thể lớn lên được?','Nhờ tế bào lớn lên và phân chia làm tăng số lượng tế bào (HS tự nêu).']]},
  {cd:'Bài 21: Thực hành: Quan sát và phân biệt một số loại tế bào',q:[
   [1,'Để quan sát tế bào nhỏ, ta thường dùng dụng cụ nào?','kính hiển vi','cái cân','thước dây','đồng hồ'],
   [2,'Tế bào thực vật khác tế bào động vật ở chỗ có thêm thành phần nào?','thành tế bào','nhân','màng tế bào','tế bào chất'],
   [3,'Nêu các bước cơ bản để quan sát tế bào bằng kính hiển vi.','Chuẩn bị tiêu bản, đặt lên bàn kính, điều chỉnh để nhìn rõ và quan sát (HS tự nêu).']]},
  {cd:'Bài 22: Cơ thể sinh vật',q:[
   [1,'Cơ thể sinh vật được cấu tạo từ gì?','tế bào','kim loại','đá','nhựa'],
   [2,'Cơ thể đơn bào là cơ thể được cấu tạo từ bao nhiêu tế bào?','một tế bào','nhiều tế bào','không có tế bào','hai cơ thể'],
   [3,'Phân biệt cơ thể đơn bào và cơ thể đa bào, cho ví dụ.','Đơn bào có một tế bào (vi khuẩn); đa bào có nhiều tế bào (cây, người) (HS tự nêu).']]},
  {cd:'Bài 23: Tổ chức cơ thể đa bào',q:[
   [1,'Các cấp tổ chức của cơ thể đa bào từ nhỏ đến lớn là gì?','tế bào, mô, cơ quan, hệ cơ quan, cơ thể','cơ thể, tế bào','chỉ tế bào','chỉ cơ quan'],
   [2,'Mô là gì?','nhóm tế bào giống nhau cùng thực hiện một chức năng','một tế bào','một cơ quan riêng lẻ','một cơ thể'],
   [3,'Nêu ví dụ về một cơ quan và hệ cơ quan trong cơ thể người.','VD: dạ dày (cơ quan) thuộc hệ tiêu hóa (hệ cơ quan) (HS tự nêu).']]},
  {cd:'Bài 24: Thực hành: Quan sát và mô tả cơ thể đơn bào, cơ thể đa bào',q:[
   [1,'Cơ thể đơn bào thường được quan sát bằng dụng cụ nào?','kính hiển vi','mắt thường dễ dàng','cái cân','nhiệt kế'],
   [2,'Đâu là ví dụ cơ thể đa bào?','cây xanh, con người','vi khuẩn','trùng roi','trùng giày'],
   [3,'Nêu điểm khác nhau giữa cơ thể đơn bào và đa bào khi quan sát.','Đơn bào chỉ một tế bào, rất nhỏ; đa bào gồm nhiều tế bào, thường thấy được bằng mắt (HS tự nêu).']]},
  {cd:'Bài 25: Hệ thống phân loại sinh vật',q:[
   [1,'Phân loại sinh vật nhằm mục đích gì?','sắp xếp sinh vật thành các nhóm để dễ nghiên cứu','làm sinh vật biến mất','gây rối','không có mục đích'],
   [2,'Đơn vị phân loại nhỏ nhất, cơ bản của sinh vật là gì?','loài','giới','ngành','lớp'],
   [3,'Nêu ý nghĩa của việc phân loại sinh vật.','Giúp nhận biết, sắp xếp, gọi tên và nghiên cứu, bảo vệ sinh vật thuận tiện (HS tự nêu).']]},
  {cd:'Bài 26: Khóa lưỡng phân',q:[
   [1,'Khóa lưỡng phân dùng để làm gì?','phân loại, nhận biết sinh vật dựa trên các đặc điểm đối lập','đo khối lượng','đo nhiệt độ','nấu ăn'],
   [2,'Mỗi bước trong khóa lưỡng phân thường chia sinh vật thành mấy nhóm?','hai nhóm','ba nhóm','bốn nhóm','một nhóm'],
   [3,'Nêu cách xây dựng khóa lưỡng phân đơn giản.','Dựa vào các đặc điểm đối lập để chia dần sinh vật thành hai nhóm cho đến khi nhận ra từng loài (HS tự nêu).']]},
  {cd:'Bài 27: Vi khuẩn',q:[
   [1,'Vi khuẩn là sinh vật có kích thước như thế nào?','rất nhỏ, chỉ nhìn thấy qua kính hiển vi','rất lớn','nhìn bằng mắt thường','không tồn tại'],
   [2,'Vai trò nào sau đây là có lợi của vi khuẩn?','giúp lên men sữa chua, phân hủy chất hữu cơ','chỉ gây bệnh','không có vai trò','phá hủy mọi thứ'],
   [3,'Nêu một vai trò có lợi và một tác hại của vi khuẩn.','Có lợi: làm sữa chua, phân hủy xác; tác hại: gây một số bệnh (HS tự nêu).']]},
  {cd:'Bài 28: Thực hành: Làm sữa chua và quan sát vi khuẩn',q:[
   [1,'Quá trình làm sữa chua nhờ hoạt động của sinh vật nào?','vi khuẩn lên men','virus','nấm độc','động vật'],
   [2,'Để làm sữa chua, cần ủ ở điều kiện nào?','ấm (nhiệt độ thích hợp)','rất lạnh','rất nóng','trong tủ đông'],
   [3,'Nêu các bước cơ bản để làm sữa chua.','Pha sữa, cho men (sữa chua cái), ủ ấm vài giờ cho lên men rồi làm lạnh (HS tự nêu).']]},
  {cd:'Bài 29: Virus',q:[
   [1,'Virus có đặc điểm nào sau đây?','kích thước rất nhỏ, chỉ sống và nhân lên trong tế bào vật chủ','có cấu tạo tế bào hoàn chỉnh','tự sống ngoài tự nhiên dễ dàng','là một loài động vật lớn'],
   [2,'Virus có thể gây ra điều gì?','gây bệnh cho người, động vật, thực vật','luôn có lợi','không ảnh hưởng gì','tạo ra oxygen'],
   [3,'Nêu một số biện pháp phòng bệnh do virus gây ra.','Tiêm vắc xin, giữ vệ sinh, đeo khẩu trang, rửa tay, ăn uống đủ chất (HS tự nêu).']]},
  {cd:'Bài 30: Nguyên sinh vật',q:[
   [1,'Nguyên sinh vật phần lớn là cơ thể như thế nào?','cơ thể đơn bào, kích thước nhỏ','cây to','động vật lớn','không sống'],
   [2,'Đâu là một nguyên sinh vật?','trùng roi, trùng giày','con gà','cây lúa','con mèo'],
   [3,'Nêu môi trường sống của nguyên sinh vật.','Thường sống trong nước (ao, hồ), nơi ẩm ướt (HS tự nêu).']]},
  {cd:'Bài 31: Thực hành: Quan sát nguyên sinh vật',q:[
   [1,'Để quan sát nguyên sinh vật, ta dùng dụng cụ nào?','kính hiển vi','cái cân','thước','đồng hồ'],
   [2,'Mẫu vật để quan sát nguyên sinh vật thường lấy từ đâu?','nước ao, hồ','không khí khô','đá khô','kim loại'],
   [3,'Nêu các bước quan sát nguyên sinh vật bằng kính hiển vi.','Lấy mẫu nước, làm tiêu bản, đặt lên kính hiển vi và quan sát (HS tự nêu).']]},
  {cd:'Bài 32: Nấm',q:[
   [1,'Nấm thuộc nhóm sinh vật nào?','giới Nấm (không phải thực vật, không phải động vật)','thực vật','động vật','vi khuẩn'],
   [2,'Vai trò nào là có lợi của nấm?','làm thực phẩm, lên men, phân hủy chất hữu cơ','chỉ gây hại','không có vai trò','tạo ra kim loại'],
   [3,'Nêu một nấm có lợi và một nấm có hại.','Có lợi: nấm rơm, nấm men; có hại: nấm độc, nấm mốc gây hỏng thức ăn (HS tự nêu).']]},
  {cd:'Bài 33: Thực hành: Quan sát các loại nấm',q:[
   [1,'Nấm lớn (như nấm rơm) có thể quan sát bằng cách nào?','bằng mắt thường','chỉ bằng kính hiển vi','không quan sát được','bằng nhiệt kế'],
   [2,'Khi quan sát và sử dụng nấm, cần chú ý điều gì?','không ăn nấm lạ vì có thể là nấm độc','ăn thử mọi loại nấm','bỏ qua an toàn','không rửa tay'],
   [3,'Nêu đặc điểm giúp nhận biết một số nấm.','Hình dạng (mũ nấm, cuống nấm), màu sắc, nơi mọc (HS tự nêu).']]},
  {cd:'Bài 34: Thực vật',q:[
   [1,'Thực vật có khả năng đặc trưng nào?','tự tổng hợp chất hữu cơ nhờ quang hợp','di chuyển nhanh','ăn thịt','bay'],
   [2,'Nhóm thực vật nào có hoa?','thực vật hạt kín','rêu','dương xỉ','tảo'],
   [3,'Nêu vai trò của thực vật đối với đời sống.','Cung cấp oxygen, thức ăn, gỗ, điều hòa khí hậu, giữ đất, giữ nước (HS tự nêu).']]},
  {cd:'Bài 35: Thực hành: Quan sát và phân biệt một số nhóm thực vật',q:[
   [1,'Các nhóm thực vật chính gồm những nhóm nào?','rêu, dương xỉ, hạt trần, hạt kín','chỉ cây lúa','chỉ rêu','chỉ nấm'],
   [2,'Thực vật hạt kín có đặc điểm nào?','có hoa và quả, hạt được bao kín','không có hoa','không có hạt','sống dưới nước hết'],
   [3,'Nêu đặc điểm giúp phân biệt rêu với cây hạt kín.','Rêu nhỏ, chưa có mạch dẫn, không hoa; cây hạt kín có rễ, thân, lá, hoa, quả (HS tự nêu).']]},
  {cd:'Bài 36: Động vật',q:[
   [1,'Động vật khác thực vật ở đặc điểm nào?','không tự tổng hợp chất hữu cơ, phải lấy thức ăn từ sinh vật khác','có khả năng quang hợp','có rễ','có lá'],
   [2,'Động vật có xương sống gồm những nhóm nào?','cá, lưỡng cư, bò sát, chim, thú','chỉ côn trùng','chỉ giun','chỉ sâu'],
   [3,'Nêu vai trò của động vật đối với con người.','Cung cấp thực phẩm, sức kéo, nguyên liệu; một số có hại cần phòng tránh (HS tự nêu).']]},
  {cd:'Bài 37: Thực hành: Quan sát và nhận biết một số nhóm động vật ngoài thiên nhiên',q:[
   [1,'Động vật không xương sống gồm nhóm nào?','côn trùng, giun, thân mềm','cá','chim','thú'],
   [2,'Khi quan sát động vật ngoài thiên nhiên, cần chú ý điều gì?','bảo đảm an toàn, không làm hại động vật và môi trường','bắt giết động vật','phá tổ','gây ồn ào'],
   [3,'Nêu cách phân biệt động vật có xương sống và không xương sống.','Động vật có xương sống có bộ xương trong (cột sống); không xương sống thì không có (HS tự nêu).']]},
  {cd:'Bài 38: Đa dạng sinh học',q:[
   [1,'Đa dạng sinh học là gì?','sự phong phú về số lượng loài, số cá thể và môi trường sống','chỉ có một loài','sự nghèo nàn sinh vật','không có sinh vật'],
   [2,'Nguyên nhân nào làm suy giảm đa dạng sinh học?','phá rừng, săn bắt quá mức, ô nhiễm môi trường','trồng rừng','bảo vệ động vật','giữ sạch môi trường'],
   [3,'Nêu một số biện pháp bảo vệ đa dạng sinh học.','Bảo vệ rừng, cấm săn bắt động vật quý hiếm, bảo vệ môi trường, xây khu bảo tồn (HS tự nêu).']]},
  {cd:'Bài 39: Tìm hiểu sinh vật ngoài thiên nhiên',q:[
   [1,'Khi tìm hiểu sinh vật ngoài thiên nhiên, cần chuẩn bị gì?','dụng cụ quan sát, ghi chép và bảo đảm an toàn','không chuẩn bị gì','chỉ đi chơi','phá hoại cây cối'],
   [2,'Thái độ đúng khi quan sát sinh vật ngoài thiên nhiên là gì?','tôn trọng, bảo vệ sinh vật và môi trường','bắt giết tùy ý','chặt phá cây','xả rác'],
   [3,'Nêu lợi ích của việc tìm hiểu sinh vật ngoài thiên nhiên.','Giúp hiểu biết về sinh vật, yêu thiên nhiên và có ý thức bảo vệ môi trường (HS tự nêu).']]},
  {cd:'Bài 40: Lực là gì?',q:[
   [1,'Lực là gì?','tác dụng đẩy hoặc kéo của vật này lên vật khác','một loại năng lượng ăn được','một chất lỏng','một âm thanh'],
   [2,'Lực có thể gây ra những kết quả nào?','làm vật biến dạng hoặc thay đổi chuyển động','làm vật biến mất','tạo ra âm thanh duy nhất','không gây gì'],
   [3,'Nêu một ví dụ về lực làm thay đổi chuyển động của vật.','VD: đá quả bóng làm bóng chuyển động; phanh xe làm xe chậm lại (HS tự nêu).']]},
  {cd:'Bài 41: Biểu diễn lực',q:[
   [1,'Lực được biểu diễn bằng gì?','một mũi tên (có gốc, phương, chiều và độ lớn)','một con số đơn thuần','một đường tròn','một dấu chấm'],
   [2,'Đơn vị đo lực là gì?','niutơn (N)','kilôgam','mét','giây'],
   [3,'Nêu các yếu tố của một lực.','Điểm đặt, phương, chiều và độ lớn của lực (HS tự nêu).']]},
  {cd:'Bài 42: Biến dạng của lò xo',q:[
   [1,'Khi kéo giãn lò xo rồi buông ra, lò xo có xu hướng gì?','trở về hình dạng ban đầu','giữ nguyên biến dạng','biến mất','nóng chảy'],
   [2,'Dụng cụ nào dùng lò xo để đo lực?','lực kế','cân đồng hồ','thước','nhiệt kế'],
   [3,'Nêu mối quan hệ giữa độ giãn của lò xo và lực tác dụng (trong giới hạn đàn hồi).','Lực càng lớn thì lò xo giãn càng nhiều (độ giãn tỉ lệ với lực) (HS tự nêu).']]},
  {cd:'Bài 43: Trọng lực, lực hấp dẫn',q:[
   [1,'Trọng lực là lực hút của vật nào?','của Trái Đất tác dụng lên vật','của Mặt Trăng','của con người','của gió'],
   [2,'Trọng lực có phương và chiều như thế nào?','phương thẳng đứng, chiều hướng xuống (về phía Trái Đất)','hướng lên','nằm ngang','không xác định'],
   [3,'Nêu một biểu hiện của trọng lực trong đời sống.','VD: quả táo rơi xuống đất, nước chảy từ cao xuống thấp (HS tự nêu).']]},
  {cd:'Bài 44: Lực ma sát',q:[
   [1,'Lực ma sát xuất hiện ở đâu?','ở bề mặt tiếp xúc giữa hai vật','trong chân không','trên trời','không tồn tại'],
   [2,'Lực ma sát có tác dụng cản trở điều gì?','chuyển động của vật','ánh sáng','âm thanh','mùi vị'],
   [3,'Nêu một ví dụ ma sát có lợi và một ví dụ ma sát có hại.','Có lợi: ma sát giúp ta đi lại, phanh xe; có hại: ma sát làm mòn chi tiết máy (HS tự nêu).']]},
  {cd:'Bài 45: Lực cản của nước',q:[
   [1,'Khi vật chuyển động trong nước sẽ chịu lực nào?','lực cản của nước','không có lực nào','chỉ trọng lực','lực đẩy lên vô hạn'],
   [2,'Lực cản của nước phụ thuộc vào yếu tố nào?','diện tích mặt cản và tốc độ của vật','màu sắc của vật','tên của vật','âm thanh'],
   [3,'Vì sao tàu, thuyền thường có mũi nhọn?','Để giảm lực cản của nước, giúp di chuyển dễ dàng hơn (HS tự nêu).']]},
  {cd:'Bài 46: Năng lượng và sự truyền năng lượng',q:[
   [1,'Năng lượng có vai trò gì?','giúp vật thực hiện công, làm vật biến đổi','không có vai trò','làm vật biến mất','chỉ để trang trí'],
   [2,'Năng lượng có thể được truyền từ vật này sang vật khác không?','có','không','chỉ tự sinh','chỉ tự mất'],
   [3,'Nêu một ví dụ về sự truyền năng lượng.','VD: Mặt Trời truyền năng lượng ánh sáng, nhiệt tới Trái Đất; bếp truyền nhiệt cho nồi (HS tự nêu).']]},
  {cd:'Bài 47: Một số dạng năng lượng',q:[
   [1,'Đâu là một dạng năng lượng?','điện năng, nhiệt năng, quang năng, cơ năng','khối lượng','thể tích','màu sắc'],
   [2,'Thức ăn cung cấp cho cơ thể dạng năng lượng nào?','hóa năng','điện năng','âm thanh','ánh sáng'],
   [3,'Kể tên một số dạng năng lượng mà em biết.','VD: cơ năng, nhiệt năng, điện năng, quang năng, hóa năng (HS tự nêu).']]},
  {cd:'Bài 48: Sự chuyển hóa năng lượng',q:[
   [1,'Năng lượng có thể chuyển từ dạng này sang dạng khác không?','có thể chuyển hóa','không thể','tự biến mất','không tồn tại'],
   [2,'Bóng đèn điện biến điện năng thành các dạng năng lượng nào?','quang năng và nhiệt năng','chỉ âm thanh','chỉ cơ năng','không biến đổi'],
   [3,'Nêu một ví dụ về sự chuyển hóa năng lượng.','VD: quạt điện biến điện năng thành cơ năng; bếp điện biến điện năng thành nhiệt năng (HS tự nêu).']]},
  {cd:'Bài 49: Năng lượng hao phí',q:[
   [1,'Khi sử dụng năng lượng, luôn có một phần năng lượng bị gì?','hao phí (chuyển thành dạng không có ích)','tăng lên','tự sinh ra','biến mất hoàn toàn khỏi vũ trụ'],
   [2,'Năng lượng hao phí thường xuất hiện dưới dạng nào?','nhiệt năng tỏa ra môi trường','điện năng','hóa năng','không có'],
   [3,'Nêu cách giảm năng lượng hao phí khi sử dụng thiết bị.','Dùng thiết bị tiết kiệm, bảo dưỡng tốt, tắt khi không dùng (HS tự nêu).']]},
  {cd:'Bài 50: Năng lượng tái tạo',q:[
   [1,'Năng lượng tái tạo là năng lượng như thế nào?','có sẵn trong tự nhiên và liên tục được bổ sung','sẽ cạn kiệt nhanh','gây ô nhiễm nặng','không tồn tại'],
   [2,'Đâu là nguồn năng lượng tái tạo?','năng lượng mặt trời, gió, nước','than đá','dầu mỏ','khí đốt'],
   [3,'Nêu ưu điểm của năng lượng tái tạo.','Sạch, thân thiện môi trường, không cạn kiệt (HS tự nêu).']]},
  {cd:'Bài 51: Tiết kiệm năng lượng',q:[
   [1,'Vì sao cần tiết kiệm năng lượng?','vì nhiều nguồn năng lượng có hạn và để bảo vệ môi trường','vì năng lượng vô hạn','để lãng phí','không có lí do'],
   [2,'Việc làm nào giúp tiết kiệm năng lượng?','tắt điện khi không dùng, dùng thiết bị tiết kiệm','để thiết bị chạy suốt','mở nhiều đèn vô ích','dùng đồ hao điện'],
   [3,'Nêu hai việc em có thể làm để tiết kiệm năng lượng.','VD: tắt đèn, quạt khi ra khỏi phòng; tận dụng ánh sáng tự nhiên (HS tự nêu).']]},
  {cd:'Bài 52: Chuyển động nhìn thấy của Mặt Trời. Thiên thể',q:[
   [1,'Hằng ngày ta thấy Mặt Trời mọc ở hướng nào?','hướng đông','hướng tây','hướng bắc','hướng nam'],
   [2,'Chuyển động nhìn thấy của Mặt Trời là do đâu?','do Trái Đất tự quay quanh trục','do Mặt Trời quay quanh Trái Đất','do Mặt Trăng','do gió'],
   [3,'Thiên thể là gì? Cho ví dụ.','Là các vật thể trong vũ trụ như sao, hành tinh, Mặt Trăng, Mặt Trời (HS tự nêu).']]},
  {cd:'Bài 53: Mặt Trăng',q:[
   [1,'Mặt Trăng là gì của Trái Đất?','vệ tinh tự nhiên','một ngôi sao','một hành tinh riêng','Mặt Trời'],
   [2,'Ta nhìn thấy Mặt Trăng sáng là nhờ đâu?','Mặt Trăng phản chiếu ánh sáng Mặt Trời','Mặt Trăng tự phát sáng','do đèn điện','do Trái Đất phát sáng'],
   [3,'Vì sao ta thấy Mặt Trăng có các hình dạng khác nhau (các pha)?','Do vị trí của Mặt Trăng so với Trái Đất và Mặt Trời thay đổi nên phần được chiếu sáng ta thấy khác nhau (HS tự nêu).']]},
  {cd:'Bài 54: Hệ Mặt Trời',q:[
   [1,'Hệ Mặt Trời gồm Mặt Trời và bao nhiêu hành tinh?','tám hành tinh','năm hành tinh','mười hành tinh','một hành tinh'],
   [2,'Trái Đất là hành tinh thứ mấy tính từ Mặt Trời?','thứ ba','thứ nhất','thứ năm','thứ tám'],
   [3,'Kể tên một vài hành tinh trong hệ Mặt Trời.','VD: Thủy tinh, Kim tinh, Trái Đất, Hỏa tinh, Mộc tinh (HS tự nêu).']]},
  {cd:'Bài 55: Ngân hà',q:[
   [1,'Ngân Hà là gì?','một tập hợp rất nhiều sao và vật chất trong vũ trụ','một hành tinh','một ngôi sao duy nhất','Mặt Trăng'],
   [2,'Hệ Mặt Trời nằm ở đâu?','nằm trong Ngân Hà','nằm ngoài vũ trụ','trong lòng Trái Đất','trên Mặt Trăng'],
   [3,'Nêu hiểu biết của em về vị trí của Trái Đất trong vũ trụ.','Trái Đất thuộc hệ Mặt Trời, hệ Mặt Trời nằm trong Ngân Hà, Ngân Hà là một trong rất nhiều thiên hà (HS tự nêu).']]}
 );
 KH[7].push(
  {cd:'Bài 1: Phương pháp và kĩ năng học tập môn Khoa học tự nhiên',q:[
   [1,'Các bước cơ bản của phương pháp tìm hiểu tự nhiên gồm những gì?','quan sát, đặt câu hỏi, dự đoán, làm thí nghiệm và kết luận','chỉ đọc sách','chỉ đoán mò','không cần thí nghiệm'],
   [2,'Kĩ năng quan trọng khi học Khoa học tự nhiên là gì?','quan sát, đo đạc và ghi chép chính xác','học thuộc lòng không hiểu','đoán bừa','bỏ qua số liệu'],
   [3,'Nêu các bước tìm hiểu một hiện tượng tự nhiên.','Quan sát, đặt câu hỏi, đưa ra giả thuyết, làm thí nghiệm kiểm tra và rút ra kết luận (HS tự nêu).']]},
  {cd:'Bài 2: Nguyên tử',q:[
   [1,'Nguyên tử được cấu tạo từ những loại hạt nào?','hạt nhân (proton, neutron) và lớp vỏ electron','chỉ proton','chỉ electron','chỉ neutron'],
   [2,'Hạt nào mang điện tích âm trong nguyên tử?','electron','proton','neutron','hạt nhân'],
   [3,'Nêu đặc điểm về điện tích của proton, neutron và electron.','Proton mang điện dương, electron mang điện âm, neutron không mang điện (HS tự nêu).']]},
  {cd:'Bài 3: Nguyên tố hóa học',q:[
   [1,'Nguyên tố hóa học là tập hợp những nguyên tử có cùng đặc điểm nào?','cùng số proton trong hạt nhân','cùng số neutron','cùng khối lượng','cùng màu sắc'],
   [2,'Số proton trong hạt nhân còn gọi là gì?','số hiệu nguyên tử','số khối','hóa trị','nồng độ'],
   [3,'Nêu ví dụ về một vài nguyên tố hóa học.','VD: hydrogen, oxygen, carbon, nitrogen (HS tự nêu).']]},
  {cd:'Bài 4: Sơ lược về bảng tuần hoàn các nguyên tố hóa học',q:[
   [1,'Các nguyên tố trong bảng tuần hoàn được sắp xếp theo chiều tăng dần của đại lượng nào?','số hiệu nguyên tử (số proton)','khối lượng riêng','màu sắc','giá tiền'],
   [2,'Hàng ngang trong bảng tuần hoàn gọi là gì?','chu kì','nhóm','cột','ô'],
   [3,'Nêu ý nghĩa của bảng tuần hoàn các nguyên tố hóa học.','Giúp sắp xếp, tra cứu và dự đoán tính chất của các nguyên tố (HS tự nêu).']]},
  {cd:'Bài 5: Phân tử - Đơn chất - Hợp chất',q:[
   [1,'Đơn chất là chất được tạo nên từ mấy nguyên tố hóa học?','một nguyên tố','hai nguyên tố','ba nguyên tố','nhiều nguyên tố'],
   [2,'Hợp chất là chất được tạo nên từ bao nhiêu nguyên tố?','hai nguyên tố trở lên','chỉ một nguyên tố','không có nguyên tố','không xác định'],
   [3,'Nêu ví dụ về một đơn chất và một hợp chất.','Đơn chất: khí oxygen (O2); hợp chất: nước (H2O), muối ăn (NaCl) (HS tự nêu).']]},
  {cd:'Bài 6: Giới thiệu về liên kết hóa học',q:[
   [1,'Liên kết hóa học được hình thành nhằm mục đích gì?','giúp các nguyên tử đạt lớp electron ngoài cùng bền vững','làm nguyên tử biến mất','tạo ra điện','không có mục đích'],
   [2,'Hai loại liên kết hóa học cơ bản là gì?','liên kết ion và liên kết cộng hóa trị','liên kết nước','liên kết gỗ','liên kết nhựa'],
   [3,'Nêu đặc điểm cơ bản của liên kết ion.','Hình thành do sự cho và nhận electron giữa các nguyên tử, tạo thành các ion trái dấu hút nhau (HS tự nêu).']]},
  {cd:'Bài 7: Hóa trị và công thức hóa học',q:[
   [1,'Hóa trị cho biết điều gì?','khả năng liên kết của nguyên tử nguyên tố này với nguyên tử nguyên tố khác','màu sắc của chất','khối lượng của chất','nhiệt độ'],
   [2,'Trong phân tử nước H2O, một nguyên tử O liên kết với mấy nguyên tử H?','hai nguyên tử H','một nguyên tử H','ba nguyên tử H','bốn nguyên tử H'],
   [3,'Công thức hóa học cho biết những gì về một chất?','Nguyên tố tạo nên chất và số nguyên tử mỗi nguyên tố trong phân tử (HS tự nêu).']]},
  {cd:'Bài 8: Tốc độ chuyển động',q:[
   [1,'Tốc độ cho biết điều gì về chuyển động?','sự nhanh hay chậm của chuyển động','màu của vật','khối lượng vật','âm thanh'],
   [2,'Công thức tính tốc độ là gì?','v = s / t (quãng đường chia thời gian)','v = s . t','v = t / s','v = s + t'],
   [3,'Một người đi 2,4 km hết 0,5 giờ. Tính tốc độ.','v = s/t = 2,4 / 0,5 = 4,8 km/h (HS tự nêu).']]},
  {cd:'Bài 9: Đo tốc độ',q:[
   [1,'Để tính tốc độ, cần đo những đại lượng nào?','quãng đường và thời gian','khối lượng và nhiệt độ','màu sắc và âm thanh','thể tích'],
   [2,'Dụng cụ nào thường dùng để đo thời gian khi đo tốc độ?','đồng hồ bấm giây','cân','thước đo góc','nhiệt kế'],
   [3,'Nêu cách đo tốc độ của một vật chuyển động.','Đo quãng đường đi được và thời gian tương ứng, rồi tính v = s/t (HS tự nêu).']]},
  {cd:'Bài 10: Đồ thị quãng đường - thời gian',q:[
   [1,'Đồ thị quãng đường - thời gian cho biết điều gì?','quãng đường vật đi được theo thời gian','khối lượng vật','nhiệt độ vật','màu sắc vật'],
   [2,'Nếu đồ thị quãng đường - thời gian là đường nằm ngang thì vật đang làm gì?','đứng yên (không đi thêm)','chuyển động nhanh','chuyển động đều','tăng tốc'],
   [3,'Nêu ý nghĩa của độ dốc đồ thị quãng đường - thời gian.','Độ dốc càng lớn thì vật chuyển động càng nhanh (tốc độ càng lớn) (HS tự nêu).']]},
  {cd:'Bài 11: Thảo luận về ảnh hưởng của tốc độ trong an toàn giao thông',q:[
   [1,'Vì sao cần quy định tốc độ giới hạn cho phương tiện giao thông?','để bảo đảm an toàn, giảm tai nạn','để đi chậm cho vui','không có lí do','để tốn xăng'],
   [2,'Khi tốc độ càng lớn thì quãng đường phanh (dừng xe) như thế nào?','càng dài, càng khó dừng kịp','càng ngắn','không đổi','bằng 0'],
   [3,'Nêu một số biện pháp bảo đảm an toàn giao thông liên quan đến tốc độ.','Đi đúng tốc độ quy định, giảm tốc khi trời mưa, giữ khoảng cách an toàn (HS tự nêu).']]},
  {cd:'Bài 12: Sóng âm',q:[
   [1,'Sóng âm được tạo ra từ đâu?','từ các vật dao động','từ vật đứng yên','từ ánh sáng','từ màu sắc'],
   [2,'Sóng âm truyền được trong các môi trường nào?','rắn, lỏng, khí','chỉ trong chân không','chỉ trong ánh sáng','không truyền được'],
   [3,'Vì sao trong chân không không truyền được âm?','Vì không có môi trường vật chất (hạt) để dao động truyền đi (HS tự nêu).']]},
  {cd:'Bài 13: Độ to và độ cao của âm',q:[
   [1,'Độ to của âm phụ thuộc vào đại lượng nào của sóng âm?','biên độ dao động','màu sắc','khối lượng','nhiệt độ'],
   [2,'Độ cao của âm (bổng, trầm) phụ thuộc vào đại lượng nào?','tần số dao động','biên độ','ánh sáng','trọng lượng'],
   [3,'Nêu mối quan hệ giữa tần số và độ cao của âm.','Tần số càng lớn thì âm càng cao (bổng); tần số càng nhỏ thì âm càng thấp (trầm) (HS tự nêu).']]},
  {cd:'Bài 14: Phản xạ âm, chống ô nhiễm tiếng ồn',q:[
   [1,'Tiếng vang là do hiện tượng gì của âm?','phản xạ âm','khúc xạ âm','âm tự sinh','âm biến mất'],
   [2,'Vật nào phản xạ âm tốt?','mặt phẳng cứng, nhẵn (tường gạch)','vật mềm, xốp','rèm nhung','bông'],
   [3,'Nêu một số biện pháp chống ô nhiễm tiếng ồn.','Trồng cây xanh, dùng vật liệu cách âm, giảm nguồn gây ồn, treo rèm (HS tự nêu).']]},
  {cd:'Bài 15: Năng lượng ánh sáng. Tia sáng, vùng tối',q:[
   [1,'Ánh sáng mang dạng năng lượng nào?','quang năng (năng lượng ánh sáng)','chỉ âm thanh','chỉ khối lượng','không mang năng lượng'],
   [2,'Trong môi trường trong suốt và đồng tính, ánh sáng truyền đi theo đường nào?','đường thẳng','đường cong','đường gấp khúc','đường tròn'],
   [3,'Vùng tối là gì?','Vùng phía sau vật cản sáng, không nhận được ánh sáng từ nguồn (HS tự nêu).']]},
  {cd:'Bài 16: Sự phản xạ ánh sáng',q:[
   [1,'Theo định luật phản xạ ánh sáng, góc phản xạ như thế nào so với góc tới?','bằng góc tới','lớn hơn góc tới','nhỏ hơn góc tới','bằng 90 độ'],
   [2,'Tia phản xạ nằm trong mặt phẳng nào?','mặt phẳng chứa tia tới và pháp tuyến tại điểm tới','mặt phẳng bất kì','mặt phẳng nằm ngang','không xác định'],
   [3,'Phát biểu định luật phản xạ ánh sáng.','Góc phản xạ bằng góc tới; tia phản xạ nằm trong mặt phẳng tới và ở bên kia pháp tuyến so với tia tới (HS tự nêu).']]},
  {cd:'Bài 17: Ảnh của vật qua gương phẳng',q:[
   [1,'Ảnh của một vật qua gương phẳng là ảnh gì?','ảnh ảo, không hứng được trên màn','ảnh thật','ảnh ngược chiều','ảnh nhỏ hơn vật'],
   [2,'Độ lớn ảnh của vật qua gương phẳng so với vật như thế nào?','bằng vật','lớn hơn vật','nhỏ hơn vật','gấp đôi vật'],
   [3,'Nêu đặc điểm ảnh của một vật tạo bởi gương phẳng.','Ảnh ảo, bằng vật, đối xứng với vật qua gương, không hứng được trên màn (HS tự nêu).']]},
  {cd:'Bài 18: Nam châm',q:[
   [1,'Mỗi nam châm có mấy cực?','hai cực (cực Bắc và cực Nam)','một cực','ba cực','không có cực'],
   [2,'Khi đưa hai cực cùng tên của hai nam châm lại gần nhau thì chúng sẽ như thế nào?','đẩy nhau','hút nhau','không tác dụng','dính chặt'],
   [3,'Nam châm hút được những vật làm bằng vật liệu nào?','sắt, thép (vật liệu từ)','gỗ','nhựa','thủy tinh']]},
  {cd:'Bài 19: Từ trường',q:[
   [1,'Từ trường tồn tại ở đâu?','xung quanh nam châm và dòng điện','chỉ trong nước','chỉ trong chân không hoàn toàn','không tồn tại'],
   [2,'Dụng cụ nào dùng để phát hiện từ trường?','kim nam châm (la bàn)','cái cân','thước','nhiệt kế'],
   [3,'Nêu cách nhận biết sự tồn tại của từ trường.','Đưa kim nam châm lại gần, nếu kim bị lệch (quay) thì nơi đó có từ trường (HS tự nêu).']]},
  {cd:'Bài 20: Chế tạo nam châm điện đơn giản',q:[
   [1,'Nam châm điện hoạt động dựa trên hiện tượng nào?','dòng điện chạy qua cuộn dây sinh ra từ trường','ánh sáng','âm thanh','trọng lực'],
   [2,'Nam châm điện có đặc điểm nào khác nam châm vĩnh cửu?','chỉ có từ tính khi có dòng điện chạy qua','luôn có từ tính','không có từ tính','không dùng điện'],
   [3,'Nêu cách làm tăng lực từ của nam châm điện.','Tăng số vòng dây hoặc tăng cường độ dòng điện qua cuộn dây (HS tự nêu).']]},
  {cd:'Bài 21: Khái quát về trao đổi chất và chuyển hóa năng lượng',q:[
   [1,'Trao đổi chất là quá trình gì?','cơ thể lấy các chất từ môi trường và thải chất ra môi trường','cơ thể đứng yên','cơ thể ngừng hoạt động','không có gì xảy ra'],
   [2,'Trao đổi chất và chuyển hóa năng lượng có vai trò gì?','cung cấp vật chất và năng lượng cho mọi hoạt động sống','không có vai trò','làm cơ thể chết','làm cơ thể biến mất'],
   [3,'Nêu vai trò của trao đổi chất đối với sinh vật.','Giúp cơ thể sinh trưởng, phát triển, vận động và duy trì sự sống (HS tự nêu).']]},
  {cd:'Bài 22: Quang hợp ở thực vật',q:[
   [1,'Quang hợp diễn ra chủ yếu ở bộ phận nào của cây?','lá (trong lục lạp)','rễ','hoa','quả'],
   [2,'Nguyên liệu của quang hợp là gì?','nước và khí carbon dioxide','khí oxygen và muối','chỉ ánh sáng','chỉ đất'],
   [3,'Viết tóm tắt quá trình quang hợp (nguyên liệu, sản phẩm).','Nước + khí carbon dioxide, nhờ ánh sáng và chất diệp lục, tạo thành chất hữu cơ (glucose) và thải khí oxygen (HS tự nêu).']]},
  {cd:'Bài 23: Một số yếu tố ảnh hưởng đến quang hợp',q:[
   [1,'Yếu tố nào ảnh hưởng đến quang hợp?','ánh sáng, nước, khí carbon dioxide, nhiệt độ','màu của chậu','tên của cây','âm thanh'],
   [2,'Khi thiếu ánh sáng, quá trình quang hợp sẽ như thế nào?','giảm (yếu đi)','mạnh hơn','không đổi','tăng gấp đôi'],
   [3,'Nêu ý nghĩa của việc trồng cây với mật độ hợp lí.','Giúp cây nhận đủ ánh sáng, không che nhau, quang hợp tốt, cho năng suất cao (HS tự nêu).']]},
  {cd:'Bài 24: Thực hành: Chứng minh quang hợp ở cây xanh',q:[
   [1,'Thí nghiệm chứng minh quang hợp thường cho thấy cây thải ra khí nào?','khí oxygen','khí carbon dioxide','khí nitrogen','hơi nước'],
   [2,'Chất nào trong lá tạo thành khi cây quang hợp (nhận biết bằng dung dịch iodine)?','tinh bột','chất đạm','chất béo','muối'],
   [3,'Nêu điều kiện cần để cây quang hợp trong thí nghiệm.','Cần ánh sáng, nước, khí carbon dioxide và chất diệp lục (lá xanh) (HS tự nêu).']]},
  {cd:'Bài 25: Hô hấp tế bào',q:[
   [1,'Hô hấp tế bào là quá trình phân giải chất hữu cơ để làm gì?','giải phóng năng lượng cho hoạt động sống','tạo ra chất hữu cơ','tạo ánh sáng','làm mát cơ thể'],
   [2,'Hô hấp tế bào sử dụng khí nào và thải ra khí nào?','dùng khí oxygen, thải khí carbon dioxide','dùng carbon dioxide, thải oxygen','không dùng khí','chỉ thải hơi nước'],
   [3,'Viết tóm tắt quá trình hô hấp tế bào.','Chất hữu cơ (glucose) + khí oxygen tạo thành khí carbon dioxide + nước và giải phóng năng lượng (HS tự nêu).']]},
  {cd:'Bài 26: Một số yếu tố ảnh hưởng hô hấp tế bào',q:[
   [1,'Yếu tố nào ảnh hưởng đến hô hấp tế bào?','nhiệt độ, độ ẩm, nồng độ khí oxygen và carbon dioxide','màu sắc','âm thanh','tên gọi'],
   [2,'Vì sao không nên để nhiều cây xanh trong phòng ngủ kín vào ban đêm?','vì ban đêm cây hô hấp lấy oxygen, thải carbon dioxide','vì cây phát sáng','vì cây gây ồn','vì cây tỏa nhiệt mạnh'],
   [3,'Nêu ứng dụng của việc điều chỉnh hô hấp trong bảo quản nông sản.','Bảo quản lạnh, giảm oxygen để hạn chế hô hấp, giúp nông sản tươi lâu (HS tự nêu).']]},
  {cd:'Bài 27: Thực hành: Hô hấp tế bào ở thực vật',q:[
   [1,'Thí nghiệm hô hấp ở hạt đang nảy mầm cho thấy hạt thải ra khí nào?','khí carbon dioxide','khí oxygen','khí nitrogen','hơi nước'],
   [2,'Hạt đang nảy mầm hô hấp mạnh sẽ tỏa ra điều gì?','nhiệt (làm ấm)','ánh sáng','âm thanh','mùi thơm'],
   [3,'Nêu dấu hiệu chứng tỏ hạt nảy mầm đang hô hấp.','Hạt tỏa nhiệt, hút khí oxygen và thải khí carbon dioxide (làm đục nước vôi trong) (HS tự nêu).']]},
  {cd:'Bài 28: Trao đổi khí ở sinh vật',q:[
   [1,'Trao đổi khí ở người diễn ra chủ yếu ở cơ quan nào?','phổi','dạ dày','gan','thận'],
   [2,'Ở thực vật, khí được trao đổi chủ yếu qua bộ phận nào của lá?','khí khổng','gân lá','cuống lá','rễ'],
   [3,'Nêu các khí được trao đổi ở sinh vật khi hô hấp.','Lấy vào khí oxygen, thải ra khí carbon dioxide (HS tự nêu).']]},
  {cd:'Bài 29: Vai trò của nước và các chất dinh dưỡng đối với cơ thể sinh vật',q:[
   [1,'Nước có vai trò gì đối với cơ thể sinh vật?','là thành phần chủ yếu, tham gia các hoạt động sống','không cần thiết','chỉ để trang trí','gây hại'],
   [2,'Chất dinh dưỡng cung cấp cho cơ thể điều gì?','vật chất và năng lượng để sống và phát triển','chỉ màu sắc','chỉ âm thanh','không có gì'],
   [3,'Vì sao cần cung cấp đủ nước và chất dinh dưỡng cho cơ thể?','Để cơ thể khỏe mạnh, sinh trưởng, phát triển và thực hiện các hoạt động sống (HS tự nêu).']]},
  {cd:'Bài 30: Trao đổi nước và chất dinh dưỡng ở thực vật',q:[
   [1,'Cây hút nước và chất khoáng chủ yếu qua bộ phận nào?','rễ (lông hút)','lá','hoa','quả'],
   [2,'Nước và chất khoáng được vận chuyển trong cây nhờ bộ phận nào?','mạch dẫn (mạch gỗ)','vỏ cây','hoa','quả'],
   [3,'Nêu con đường vận chuyển nước trong cây.','Rễ hút nước, nước theo mạch gỗ lên thân, lá và thoát hơi ra ngoài qua khí khổng (HS tự nêu).']]},
  {cd:'Bài 31: Trao đổi nước và chất dinh dưỡng ở động vật',q:[
   [1,'Ở động vật, chất dinh dưỡng được hấp thụ chủ yếu ở cơ quan nào?','ruột (ruột non)','phổi','da','tai'],
   [2,'Chất dinh dưỡng sau khi hấp thụ được vận chuyển đi khắp cơ thể nhờ hệ nào?','hệ tuần hoàn (máu)','hệ hô hấp','hệ thần kinh','hệ xương'],
   [3,'Nêu con đường thức ăn đi trong ống tiêu hóa của người.','Miệng, thực quản, dạ dày, ruột non, ruột già và thải ra ngoài (HS tự nêu).']]},
  {cd:'Bài 32: Thực hành: Thân vận chuyển nước và lá thoát hơi nước',q:[
   [1,'Thí nghiệm cắm cành hoa vào nước màu chứng minh điều gì?','thân vận chuyển nước lên các bộ phận của cây','lá tự tạo nước','rễ không hút nước','cây không cần nước'],
   [2,'Lá cây thoát hơi nước chủ yếu qua bộ phận nào?','khí khổng','gân lá','cuống lá','vỏ thân'],
   [3,'Nêu ý nghĩa của sự thoát hơi nước ở lá.','Giúp hút nước từ rễ lên, làm mát cây và tạo điều kiện cho quang hợp (HS tự nêu).']]},
  {cd:'Bài 33: Cảm ứng ở sinh vật và tập tính ở động vật',q:[
   [1,'Cảm ứng ở sinh vật là gì?','khả năng phản ứng lại các kích thích của môi trường','khả năng bay','khả năng phát sáng','khả năng biến mất'],
   [2,'Hiện tượng lá cây trinh nữ cụp lại khi chạm vào là ví dụ của gì?','cảm ứng ở thực vật','quang hợp','hô hấp','sinh sản'],
   [3,'Nêu một ví dụ về tập tính ở động vật.','VD: chim làm tổ, ong lấy mật, mèo rình bắt chuột (HS tự nêu).']]},
  {cd:'Bài 34: Vận dụng hiện tượng cảm ứng ở sinh vật vào thực tiễn',q:[
   [1,'Vì sao người ta làm giàn cho cây mướp, bầu, bí?','vì chúng có tính hướng tiếp xúc, cần giá bám để leo','vì cây sợ nắng','vì cây cần giàn để ăn','không có lí do'],
   [2,'Hiện tượng rễ cây hướng về phía có nước là ví dụ của tính gì?','tính hướng nước','tính hướng sáng','tính hướng tiếp xúc','không phải cảm ứng'],
   [3,'Nêu một ứng dụng của cảm ứng ở sinh vật trong trồng trọt, chăn nuôi.','VD: làm giàn cho cây leo, dùng ánh sáng điều khiển gà đẻ, chiếu sáng cho cây (HS tự nêu).']]},
  {cd:'Bài 35: Thực hành: Cảm ứng ở sinh vật',q:[
   [1,'Thí nghiệm trồng cây gần cửa sổ cho thấy ngọn cây có xu hướng gì?','hướng về phía ánh sáng','quay về bóng tối','mọc xuống đất','không thay đổi'],
   [2,'Hiện tượng ngọn cây hướng về phía ánh sáng gọi là gì?','tính hướng sáng','tính hướng nước','hô hấp','quang hợp'],
   [3,'Nêu một thí nghiệm đơn giản chứng minh cảm ứng ở thực vật.','VD: đặt cây gần nguồn sáng một bên, sau vài ngày ngọn cây hướng về phía sáng (HS tự nêu).']]},
  {cd:'Bài 36: Khái quát về sinh trưởng và phát triển ở sinh vật',q:[
   [1,'Sinh trưởng là gì?','sự tăng lên về kích thước và khối lượng của cơ thể','sự giảm kích thước','sự biến mất','sự đứng yên'],
   [2,'Phát triển ở sinh vật bao gồm những biến đổi nào?','sinh trưởng, phân hóa tế bào và phát sinh hình thái','chỉ to lên','chỉ nhỏ đi','không thay đổi'],
   [3,'Phân biệt sinh trưởng và phát triển, cho ví dụ.','Sinh trưởng là tăng kích thước (cây cao lên); phát triển gồm cả biến đổi về chất (cây ra hoa, kết quả) (HS tự nêu).']]},
  {cd:'Bài 37: Ứng dụng sinh trưởng và phát triển ở sinh vật vào thực tiễn',q:[
   [1,'Yếu tố nào ảnh hưởng đến sinh trưởng và phát triển của sinh vật?','nhiệt độ, ánh sáng, nước, chất dinh dưỡng','màu sắc','tên gọi','âm thanh'],
   [2,'Việc chiếu sáng, bón phân hợp lí nhằm mục đích gì?','thúc đẩy sinh trưởng, tăng năng suất cây trồng','làm cây chết','không có tác dụng','gây hại cây'],
   [3,'Nêu một ứng dụng hiểu biết về sinh trưởng, phát triển trong sản xuất.','VD: dùng đèn kích thích cây ra hoa, điều chỉnh nhiệt độ nuôi vật nuôi để lớn nhanh (HS tự nêu).']]},
  {cd:'Bài 38: Thực hành: quan sát, mô tả sự sinh trưởng và phát triển ở một số loài sinh vật',q:[
   [1,'Khi quan sát sự sinh trưởng của cây, ta thường theo dõi đại lượng nào?','chiều cao, số lá theo thời gian','màu của chậu','tên của cây','âm thanh'],
   [2,'Vòng đời của bướm trải qua các giai đoạn nào?','trứng, sâu, nhộng, bướm','chỉ trứng','chỉ bướm','trứng và bướm'],
   [3,'Nêu cách theo dõi sự sinh trưởng của một cây trồng.','Đo chiều cao, đếm số lá, ghi lại theo thời gian và nhận xét sự thay đổi (HS tự nêu).']]},
  {cd:'Bài 39: Sinh sản vô tính ở sinh vật',q:[
   [1,'Sinh sản vô tính là hình thức sinh sản như thế nào?','không có sự kết hợp của giao tử đực và cái','có sự thụ tinh','cần hai bố mẹ','chỉ ở động vật'],
   [2,'Đâu là ví dụ sinh sản vô tính ở thực vật?','giâm cành, chiết cành, mọc chồi','thụ phấn tạo hạt','ghép đôi','đẻ trứng'],
   [3,'Nêu một đặc điểm của cơ thể con tạo ra bằng sinh sản vô tính.','Con giống hệt cơ thể mẹ (giữ đặc tính của mẹ) (HS tự nêu).']]},
  {cd:'Bài 40: Sinh sản hữu tính ở sinh vật',q:[
   [1,'Sinh sản hữu tính có sự kết hợp của những yếu tố nào?','giao tử đực và giao tử cái','chỉ một cơ thể','không cần giao tử','chỉ rễ cây'],
   [2,'Hoa lưỡng tính là hoa có đặc điểm gì?','có cả nhị và nhụy','chỉ có nhị','chỉ có nhụy','không có gì'],
   [3,'Nêu một ưu điểm của sinh sản hữu tính.','Con sinh ra đa dạng, kết hợp đặc điểm của bố và mẹ, thích nghi tốt hơn (HS tự nêu).']]},
  {cd:'Bài 41: Một số yếu tố ảnh hưởng và điều hòa, điều khiển sinh sản ở sinh vật',q:[
   [1,'Yếu tố nào ảnh hưởng đến sinh sản của sinh vật?','nhiệt độ, ánh sáng, thức ăn, độ ẩm','màu sắc','tên gọi','âm thanh ngẫu nhiên'],
   [2,'Con người điều khiển sinh sản ở vật nuôi, cây trồng nhằm mục đích gì?','tăng năng suất, chất lượng sản phẩm','làm giảm năng suất','gây hại','không có mục đích'],
   [3,'Nêu một biện pháp điều khiển sinh sản ở cây trồng.','VD: thụ phấn nhân tạo, dùng ánh sáng, chất kích thích để điều chỉnh ra hoa, kết quả (HS tự nêu).']]},
  {cd:'Bài 42: Cơ thể sinh vật là một thể thống nhất',q:[
   [1,'Các hoạt động sống trong cơ thể (trao đổi chất, sinh trưởng, sinh sản...) có mối quan hệ như thế nào?','liên quan, thống nhất với nhau','hoàn toàn độc lập','không liên quan','trái ngược nhau'],
   [2,'Cơ thể và môi trường có mối quan hệ như thế nào?','tác động qua lại lẫn nhau','không liên quan','môi trường không ảnh hưởng','cơ thể tách rời môi trường'],
   [3,'Vì sao nói cơ thể sinh vật là một thể thống nhất?','Vì các cơ quan, hệ cơ quan và các hoạt động sống phối hợp nhịp nhàng, liên quan chặt chẽ với nhau và với môi trường (HS tự nêu).']]}
 );
 }

 /* ---- KHTN lớp 8 và 9 ---- */
 if(typeof KH!=='undefined' && KH){
 KH[8].push(
  {cd:'Bài 1: Sử dụng một số hóa chất, thiết bị cơ bản trong phòng thí nghiệm',q:[
   [1,'Khi sử dụng hóa chất trong phòng thí nghiệm, em cần làm gì?','tuân thủ hướng dẫn, không nếm, không ngửi trực tiếp','nếm thử hóa chất','đổ lẫn tùy ý','đùa nghịch'],
   [2,'Dụng cụ nào dùng để đong thể tích chất lỏng trong phòng thí nghiệm?','ống đong, cốc chia độ','cái cân','thước kẻ','nhiệt kế'],
   [3,'Nêu một số quy tắc an toàn khi làm thí nghiệm hóa học.','Đeo dụng cụ bảo hộ, không nếm ngửi hóa chất, làm theo hướng dẫn, rửa tay sau khi làm (HS tự nêu).']]},
  {cd:'Bài 2: Phản ứng hóa học',q:[
   [1,'Phản ứng hóa học là quá trình gì?','biến đổi chất này thành chất khác','chỉ thay đổi hình dạng','chỉ thay đổi màu bề ngoài','không có gì thay đổi'],
   [2,'Chất ban đầu bị biến đổi trong phản ứng gọi là gì?','chất tham gia (chất phản ứng)','chất sản phẩm','chất xúc tác','tạp chất'],
   [3,'Nêu dấu hiệu nhận biết có phản ứng hóa học xảy ra.','Có chất mới tạo thành: đổi màu, tạo kết tủa, sủi bọt khí, tỏa nhiệt hoặc phát sáng (HS tự nêu).']]},
  {cd:'Bài 3: Mol và tỉ khối chất khí',q:[
   [1,'1 mol chất chứa bao nhiêu hạt (nguyên tử hoặc phân tử)?','khoảng 6,022 × 10²³ hạt','100 hạt','1000 hạt','1 hạt'],
   [2,'Số 6,022 × 10²³ được gọi là gì?','số Avogadro','số Pi','số proton','số khối'],
   [3,'Mol dùng để làm gì trong hóa học?','Để đo lượng chất, thuận tiện cho việc tính toán theo phản ứng hóa học (HS tự nêu).']]},
  {cd:'Bài 4: Dung dịch và nồng độ',q:[
   [1,'Dung dịch là hỗn hợp đồng nhất gồm những thành phần nào?','chất tan và dung môi','chỉ chất rắn','chỉ chất khí','chỉ kim loại'],
   [2,'Trong nước muối, nước đóng vai trò là gì?','dung môi','chất tan','chất kết tủa','chất xúc tác'],
   [3,'Nêu ý nghĩa của nồng độ dung dịch.','Cho biết lượng chất tan có trong một lượng dung dịch (hoặc dung môi) xác định (HS tự nêu).']]},
  {cd:'Bài 5: Định luật bảo toàn khối lượng và phương trình hóa học',q:[
   [1,'Theo định luật bảo toàn khối lượng, tổng khối lượng các chất trước và sau phản ứng như thế nào?','bằng nhau','tăng lên','giảm đi','thay đổi tùy ý'],
   [2,'Phương trình hóa học biểu diễn điều gì?','phản ứng hóa học bằng công thức hóa học của các chất','khối lượng riêng','nhiệt độ','màu sắc'],
   [3,'Phát biểu định luật bảo toàn khối lượng.','Trong một phản ứng hóa học, tổng khối lượng các chất tham gia bằng tổng khối lượng các chất sản phẩm (HS tự nêu).']]},
  {cd:'Bài 6: Tính theo phương trình hóa học',q:[
   [1,'Để tính lượng chất trong phản ứng, ta dựa vào đâu?','phương trình hóa học đã cân bằng','màu của chất','tên của chất','giá tiền'],
   [2,'Tỉ lệ số mol các chất trong phản ứng được xác định bởi gì?','hệ số trong phương trình hóa học','khối lượng riêng','nhiệt độ','thể tích cốc'],
   [3,'Nêu các bước tính theo phương trình hóa học.','Viết và cân bằng phương trình, tính số mol chất đã biết, dựa vào tỉ lệ để tính chất cần tìm (HS tự nêu).']]},
  {cd:'Bài 7: Tốc độ phản ứng và chất xúc tác',q:[
   [1,'Yếu tố nào ảnh hưởng đến tốc độ phản ứng?','nhiệt độ, nồng độ, diện tích tiếp xúc, chất xúc tác','màu sắc','tên gọi','âm thanh'],
   [2,'Chất xúc tác có vai trò gì trong phản ứng?','làm tăng tốc độ phản ứng nhưng không bị tiêu hao','làm chậm phản ứng','tạo ra sản phẩm mới hoàn toàn','không có vai trò'],
   [3,'Nêu một ví dụ làm tăng tốc độ phản ứng trong thực tế.','VD: đập nhỏ than, tăng nhiệt độ để than cháy nhanh hơn (HS tự nêu).']]},
  {cd:'Bài 8: Acid',q:[
   [1,'Dung dịch acid làm quỳ tím chuyển sang màu gì?','màu đỏ','màu xanh','màu vàng','không đổi màu'],
   [2,'Đâu là một acid thường gặp?','hydrochloric acid, sulfuric acid','muối ăn','vôi','đường'],
   [3,'Nêu một ứng dụng của acid trong đời sống.','VD: giấm ăn (acetic acid) dùng chế biến thực phẩm, tẩy cặn; acid trong công nghiệp (HS tự nêu).']]},
  {cd:'Bài 9: Base - thang pH',q:[
   [1,'Dung dịch base (kiềm) làm quỳ tím chuyển sang màu gì?','màu xanh','màu đỏ','màu vàng','không đổi màu'],
   [2,'Trên thang pH, dung dịch có pH bằng 7 là dung dịch gì?','trung tính','acid mạnh','base mạnh','không xác định'],
   [3,'Nêu ý nghĩa của thang pH.','Cho biết độ acid hay base: pH < 7 là acid, pH = 7 trung tính, pH > 7 là base (HS tự nêu).']]},
  {cd:'Bài 10: Oxide',q:[
   [1,'Oxide là hợp chất của oxygen với bao nhiêu nguyên tố khác?','một nguyên tố khác','hai nguyên tố khác','ba nguyên tố','không có'],
   [2,'Vôi sống (CaO) là loại oxide nào?','oxide base','oxide acid','muối','kim loại'],
   [3,'Nêu một ví dụ về oxide và ứng dụng.','VD: CaO (vôi sống) dùng khử chua đất; CO2 dùng trong nước giải khát (HS tự nêu).']]},
  {cd:'Bài 11: Muối',q:[
   [1,'Muối ăn có công thức hóa học là gì?','NaCl','H2O','CO2','O2'],
   [2,'Muối thường được tạo thành từ phản ứng giữa những chất nào?','acid và base (hoặc kim loại với acid)','nước và khí','gỗ và nhựa','ánh sáng và nhiệt'],
   [3,'Nêu một ứng dụng của muối trong đời sống.','VD: muối ăn dùng nêm nếm, bảo quản thực phẩm; một số muối dùng làm phân bón (HS tự nêu).']]},
  {cd:'Bài 12: Phân bón hóa học',q:[
   [1,'Phân bón hóa học cung cấp cho cây các nguyên tố dinh dưỡng nào là chính?','đạm (N), lân (P), kali (K)','vàng, bạc','nhựa, cao su','đá, cát'],
   [2,'Vì sao cần bón phân hợp lí cho cây trồng?','để cây đủ dinh dưỡng, cho năng suất cao và tránh ô nhiễm','để cây chết','để lãng phí','không có lí do'],
   [3,'Nêu tác hại của việc bón quá nhiều phân hóa học.','Gây ô nhiễm đất, nước, ảnh hưởng sức khỏe và làm chai đất (HS tự nêu).']]},
  {cd:'Bài 13: Khối lượng riêng',q:[
   [1,'Khối lượng riêng của một chất được tính bằng công thức nào?','D = m / V (khối lượng chia thể tích)','D = m . V','D = V / m','D = m + V'],
   [2,'Đơn vị của khối lượng riêng thường là gì?','kg/m³','kg','m³','N'],
   [3,'Nêu ý nghĩa của khối lượng riêng.','Cho biết khối lượng của một đơn vị thể tích chất đó; giúp so sánh chất nào nặng hơn khi cùng thể tích (HS tự nêu).']]},
  {cd:'Bài 14: Thực hành xác định khối lượng riêng',q:[
   [1,'Để xác định khối lượng riêng của vật, cần đo những đại lượng nào?','khối lượng và thể tích','chỉ khối lượng','chỉ thể tích','nhiệt độ'],
   [2,'Dụng cụ nào dùng để đo thể tích vật rắn không thấm nước?','bình chia độ (bằng cách đo thể tích nước dâng lên)','cái cân','thước đo góc','nhiệt kế'],
   [3,'Nêu cách xác định khối lượng riêng của một vật rắn.','Đo khối lượng bằng cân, đo thể tích bằng bình chia độ, rồi tính D = m/V (HS tự nêu).']]},
  {cd:'Bài 15: Áp suất trên một bề mặt',q:[
   [1,'Áp suất được tính bằng công thức nào?','p = F / S (áp lực chia diện tích bị ép)','p = F . S','p = S / F','p = F + S'],
   [2,'Khi diện tích bị ép càng nhỏ (áp lực không đổi) thì áp suất như thế nào?','càng lớn','càng nhỏ','không đổi','bằng 0'],
   [3,'Vì sao lưỡi dao, mũi kim được làm nhọn?','Để giảm diện tích tiếp xúc, tăng áp suất nên dễ cắt, dễ đâm hơn (HS tự nêu).']]},
  {cd:'Bài 16: Áp suất chất lỏng. Áp suất khí quyển',q:[
   [1,'Áp suất chất lỏng tác dụng theo hướng nào?','theo mọi hướng lên vật trong lòng nó','chỉ hướng xuống','chỉ hướng lên','chỉ nằm ngang'],
   [2,'Càng xuống sâu trong lòng chất lỏng, áp suất như thế nào?','càng tăng','càng giảm','không đổi','bằng 0'],
   [3,'Áp suất khí quyển là gì?','Áp suất do lớp không khí bao quanh Trái Đất tác dụng lên mọi vật (HS tự nêu).']]},
  {cd:'Bài 17: Lực đẩy Archimedes',q:[
   [1,'Lực đẩy Archimedes có phương và chiều như thế nào?','phương thẳng đứng, chiều hướng từ dưới lên','hướng xuống','nằm ngang','không xác định'],
   [2,'Một vật nhúng trong chất lỏng chịu lực đẩy Archimedes phụ thuộc vào yếu tố nào?','thể tích phần chất lỏng bị vật chiếm chỗ và khối lượng riêng chất lỏng','màu của vật','tên của vật','nhiệt độ phòng'],
   [3,'Vì sao tàu thuyền bằng thép nặng nhưng vẫn nổi được trên nước?','Vì tàu có khoang rỗng, chiếm thể tích lớn nên lực đẩy Archimedes đủ lớn nâng tàu nổi (HS tự nêu).']]},
  {cd:'Bài 18: Tác dụng làm quay của lực. Moment lực',q:[
   [1,'Moment lực đặc trưng cho tác dụng gì của lực?','tác dụng làm quay vật quanh một trục','làm vật đứng yên','làm vật biến mất','làm vật nóng lên'],
   [2,'Moment lực càng lớn khi nào (cùng một lực)?','khi cánh tay đòn (khoảng cách tới trục quay) càng lớn','khi đặt sát trục quay','khi lực bằng 0','không phụ thuộc gì'],
   [3,'Vì sao khi mở cửa, ta nên đẩy ở xa bản lề?','Vì cánh tay đòn lớn làm moment lực lớn, cửa dễ quay (mở) hơn (HS tự nêu).']]},
  {cd:'Bài 19: Đòn bẩy và ứng dụng',q:[
   [1,'Đòn bẩy giúp ích gì cho con người?','nâng vật nặng dễ dàng hơn (được lợi về lực)','làm vật nặng hơn','không có tác dụng','phá hỏng vật'],
   [2,'Đòn bẩy quay quanh một điểm cố định gọi là gì?','điểm tựa','điểm đặt tải','trọng tâm','điểm giữa'],
   [3,'Nêu một ví dụ về đòn bẩy trong đời sống.','VD: cái bập bênh, xà beng, kéo, búa nhổ đinh (HS tự nêu).']]},
  {cd:'Bài 20: Hiện tượng nhiễm điện do cọ xát',q:[
   [1,'Khi cọ xát hai vật, chúng có thể bị gì?','nhiễm điện (mang điện tích)','nóng chảy','biến mất','phát ra âm thanh lớn'],
   [2,'Vật bị nhiễm điện có khả năng gì?','hút các vật nhẹ','đẩy mọi vật','phát sáng mạnh','tạo ra nước'],
   [3,'Nêu một ví dụ về hiện tượng nhiễm điện do cọ xát.','VD: chải tóc khô bằng lược nhựa, tóc bị hút; thước nhựa cọ xát hút vụn giấy (HS tự nêu).']]},
  {cd:'Bài 21: Dòng điện, nguồn điện',q:[
   [1,'Dòng điện là gì?','dòng các hạt mang điện dịch chuyển có hướng','dòng nước','dòng không khí','một loại ánh sáng'],
   [2,'Nguồn điện có vai trò gì?','cung cấp và duy trì dòng điện trong mạch','tiêu thụ điện','làm tắt điện','ngăn dòng điện'],
   [3,'Kể tên một số nguồn điện thường gặp.','VD: pin, acquy, máy phát điện, tấm pin mặt trời (HS tự nêu).']]},
  {cd:'Bài 22: Mạch điện đơn giản',q:[
   [1,'Để bóng đèn sáng, mạch điện phải ở trạng thái nào?','mạch kín (khép kín)','mạch hở','không có nguồn','không có dây'],
   [2,'Công tắc trong mạch điện dùng để làm gì?','đóng, ngắt mạch điện','làm sáng đèn vĩnh viễn','tạo nguồn điện','đo dòng điện'],
   [3,'Nêu các bộ phận cơ bản của một mạch điện đơn giản.','Nguồn điện, dây dẫn, công tắc và thiết bị tiêu thụ điện (bóng đèn) (HS tự nêu).']]},
  {cd:'Bài 23: Tác dụng của dòng điện',q:[
   [1,'Dòng điện có những tác dụng nào?','tác dụng nhiệt, phát sáng, từ, hóa học và sinh lí','chỉ phát ra mùi','chỉ tạo âm thanh','không có tác dụng'],
   [2,'Bàn là (bàn ủi) điện hoạt động dựa trên tác dụng nào của dòng điện?','tác dụng nhiệt','tác dụng từ','tác dụng hóa học','tác dụng phát sáng'],
   [3,'Nêu một ví dụ ứng dụng tác dụng từ của dòng điện.','VD: chế tạo nam châm điện, chuông điện, động cơ điện (HS tự nêu).']]},
  {cd:'Bài 24: Cường độ dòng điện và hiệu điện thế',q:[
   [1,'Đơn vị đo cường độ dòng điện là gì?','ampe (A)','vôn (V)','oát (W)','ôm'],
   [2,'Dụng cụ nào dùng để đo hiệu điện thế?','vôn kế','ampe kế','cân','nhiệt kế'],
   [3,'Cường độ dòng điện và hiệu điện thế được đo bằng dụng cụ nào?','Cường độ dòng điện đo bằng ampe kế; hiệu điện thế đo bằng vôn kế (HS tự nêu).']]},
  {cd:'Bài 25: Thực hành đo cường độ dòng điện và hiệu điện thế',q:[
   [1,'Ampe kế được mắc như thế nào vào mạch để đo cường độ dòng điện?','mắc nối tiếp với dụng cụ cần đo','mắc song song','không mắc vào mạch','mắc ngoài nguồn'],
   [2,'Vôn kế được mắc như thế nào để đo hiệu điện thế hai đầu dụng cụ?','mắc song song với dụng cụ','mắc nối tiếp','không cần mắc','mắc vào nguồn riêng'],
   [3,'Nêu lưu ý khi mắc ampe kế, vôn kế vào mạch.','Mắc ampe kế nối tiếp, vôn kế song song, chú ý chốt (+) và (-) đúng chiều (HS tự nêu).']]},
  {cd:'Bài 26: Năng lượng nhiệt và nhiệt năng',q:[
   [1,'Nhiệt năng của một vật là gì?','tổng động năng của các phân tử cấu tạo nên vật','khối lượng của vật','thể tích của vật','màu của vật'],
   [2,'Khi nhiệt độ của vật tăng thì nhiệt năng của vật như thế nào?','tăng','giảm','không đổi','bằng 0'],
   [3,'Nêu các cách làm thay đổi nhiệt năng của một vật.','Thực hiện công (cọ xát) hoặc truyền nhiệt (đun nóng, làm lạnh) (HS tự nêu).']]},
  {cd:'Bài 27: Thực hành đo năng lượng nhiệt bằng Joulemeter',q:[
   [1,'Joulemeter (nhiệt lượng kế điện) dùng để đo đại lượng nào?','năng lượng nhiệt','khối lượng','chiều dài','thời gian'],
   [2,'Đơn vị đo năng lượng (nhiệt lượng) là gì?','jun (J)','mét','gam','giây'],
   [3,'Nêu nguyên tắc đo năng lượng nhiệt khi đun nước.','Dùng dụng cụ đo lượng nhiệt mà nước thu vào khi nhiệt độ tăng (HS tự nêu).']]},
  {cd:'Bài 28: Sự truyền nhiệt',q:[
   [1,'Năng lượng nhiệt có thể truyền bằng những hình thức nào?','dẫn nhiệt, đối lưu và bức xạ nhiệt','chỉ bằng âm thanh','chỉ bằng ánh sáng','không truyền được'],
   [2,'Chất rắn truyền nhiệt chủ yếu bằng hình thức nào?','dẫn nhiệt','đối lưu','bức xạ','không truyền'],
   [3,'Nêu ví dụ cho mỗi hình thức truyền nhiệt.','Dẫn nhiệt: thìa kim loại trong nước nóng; đối lưu: đun nước; bức xạ: hơi ấm từ Mặt Trời (HS tự nêu).']]},
  {cd:'Bài 29: Sự nở vì nhiệt',q:[
   [1,'Khi nóng lên, hầu hết các chất rắn sẽ như thế nào?','nở ra (tăng thể tích)','co lại','biến mất','không đổi'],
   [2,'Khi làm lạnh, các chất thường như thế nào?','co lại','nở ra','phát sáng','tan chảy'],
   [3,'Nêu một ứng dụng của sự nở vì nhiệt trong đời sống.','VD: để khe hở giữa các đoạn ray đường sắt, đường ống để tránh cong vênh khi nóng (HS tự nêu).']]},
  {cd:'Bài 30: Khái quát về cơ thể người',q:[
   [1,'Cơ thể người được cấu tạo từ đơn vị cơ bản nào?','tế bào','kim loại','đá','nhựa'],
   [2,'Các cấp tổ chức của cơ thể người từ nhỏ đến lớn là gì?','tế bào, mô, cơ quan, hệ cơ quan, cơ thể','chỉ tế bào','chỉ cơ quan','ngược lại'],
   [3,'Kể tên một vài hệ cơ quan trong cơ thể người.','VD: hệ tiêu hóa, hệ tuần hoàn, hệ hô hấp, hệ thần kinh (HS tự nêu).']]},
  {cd:'Bài 31: Hệ vận động ở người',q:[
   [1,'Hệ vận động gồm những bộ phận nào?','xương và cơ','tim và phổi','dạ dày và ruột','não và tủy'],
   [2,'Chức năng chính của hệ vận động là gì?','nâng đỡ và giúp cơ thể vận động, di chuyển','tiêu hóa thức ăn','lọc máu','trao đổi khí'],
   [3,'Nêu một số biện pháp giữ gìn hệ vận động khỏe mạnh.','Ngồi học đúng tư thế, tập thể dục, ăn đủ chất, tránh mang vác nặng lệch (HS tự nêu).']]},
  {cd:'Bài 32: Dinh dưỡng và tiêu hóa ở người',q:[
   [1,'Tiêu hóa là quá trình gì?','biến đổi thức ăn thành chất dinh dưỡng cơ thể hấp thụ được','tạo ra thức ăn','thải chất độc qua da','trao đổi khí'],
   [2,'Chất dinh dưỡng được hấp thụ chủ yếu ở cơ quan nào?','ruột non','dạ dày','thực quản','miệng'],
   [3,'Nêu một số nguyên tắc để có bữa ăn hợp lí, bảo vệ hệ tiêu hóa.','Ăn đủ chất, ăn chín uống sôi, nhai kĩ, ăn đúng giờ, vệ sinh an toàn thực phẩm (HS tự nêu).']]},
  {cd:'Bài 33: Máu và hệ tuần hoàn của cơ thể người',q:[
   [1,'Thành phần nào của máu vận chuyển khí oxygen?','hồng cầu','bạch cầu','tiểu cầu','huyết tương'],
   [2,'Cơ quan nào co bóp để đẩy máu đi khắp cơ thể?','tim','phổi','gan','thận'],
   [3,'Nêu vai trò của máu đối với cơ thể.','Vận chuyển oxygen, chất dinh dưỡng, thải chất thải và bảo vệ cơ thể (HS tự nêu).']]},
  {cd:'Bài 34: Hệ hô hấp ở người',q:[
   [1,'Cơ quan trao đổi khí chính của hệ hô hấp là gì?','phổi','dạ dày','gan','thận'],
   [2,'Khi hít vào, cơ thể lấy vào khí nào?','khí oxygen','khí carbon dioxide','khí nitrogen','hơi nước'],
   [3,'Nêu một số biện pháp bảo vệ hệ hô hấp.','Giữ không khí trong lành, đeo khẩu trang, không hút thuốc, trồng cây xanh (HS tự nêu).']]},
  {cd:'Bài 35: Hệ bài tiết ở người',q:[
   [1,'Cơ quan bài tiết nước tiểu chủ yếu của cơ thể là gì?','thận','gan','phổi','tim'],
   [2,'Hệ bài tiết có vai trò gì?','lọc và thải các chất thải, chất độc ra khỏi cơ thể','tiêu hóa thức ăn','vận chuyển máu','trao đổi khí'],
   [3,'Nêu một số biện pháp bảo vệ hệ bài tiết (thận).','Uống đủ nước, ăn uống hợp lí, không nhịn tiểu, giữ vệ sinh (HS tự nêu).']]},
  {cd:'Bài 36: Điều hòa môi trường trong của cơ thể người',q:[
   [1,'Môi trường trong của cơ thể gồm những thành phần nào?','máu, nước mô và bạch huyết','không khí','đất','nước biển'],
   [2,'Việc giữ ổn định môi trường trong cơ thể có vai trò gì?','giúp tế bào và cơ thể hoạt động bình thường','làm cơ thể yếu đi','không có vai trò','gây bệnh'],
   [3,'Vì sao cần duy trì ổn định môi trường trong cơ thể?','Để các tế bào, cơ quan hoạt động bình thường; nếu rối loạn sẽ gây bệnh (HS tự nêu).']]},
  {cd:'Bài 37: Hệ thần kinh và các giác quan ở người',q:[
   [1,'Hệ thần kinh gồm những bộ phận chính nào?','não, tủy sống và các dây thần kinh','tim và phổi','xương và cơ','dạ dày và ruột'],
   [2,'Cơ quan nào giúp con người nhìn thấy sự vật?','mắt','tai','mũi','lưỡi'],
   [3,'Nêu một số biện pháp bảo vệ hệ thần kinh và giác quan.','Ngủ đủ giấc, học tập nghỉ ngơi hợp lí, bảo vệ mắt và tai, tránh căng thẳng (HS tự nêu).']]},
  {cd:'Bài 38: Hệ nội tiết ở người',q:[
   [1,'Hệ nội tiết tiết ra chất gì để điều hòa hoạt động cơ thể?','hormone (nội tiết tố)','nước bọt','mồ hôi','nước tiểu'],
   [2,'Hormone được vận chuyển đi khắp cơ thể nhờ hệ nào?','hệ tuần hoàn (máu)','hệ xương','hệ hô hấp','hệ bài tiết'],
   [3,'Nêu vai trò của hệ nội tiết.','Điều hòa quá trình sinh trưởng, phát triển và các hoạt động sống của cơ thể (HS tự nêu).']]},
  {cd:'Bài 39: Da và điều hòa thân nhiệt ở người',q:[
   [1,'Da có vai trò gì đối với cơ thể?','bảo vệ cơ thể và tham gia điều hòa thân nhiệt','tiêu hóa thức ăn','bơm máu','lọc nước tiểu'],
   [2,'Khi trời nóng, cơ thể tiết mồ hôi nhằm mục đích gì?','giúp hạ nhiệt (làm mát cơ thể)','làm cơ thể nóng hơn','không có tác dụng','giữ nhiệt'],
   [3,'Nêu một số biện pháp giữ vệ sinh và bảo vệ da.','Tắm rửa sạch, mặc đồ thoáng, tránh nắng gắt, không dùng chung đồ cá nhân (HS tự nêu).']]},
  {cd:'Bài 40: Sinh sản ở người',q:[
   [1,'Ở tuổi dậy thì, cơ thể có những thay đổi nào?','thay đổi về thể chất và tâm sinh lí','không thay đổi gì','chỉ cao lên một chút','nhỏ đi'],
   [2,'Để bảo vệ sức khỏe tuổi dậy thì, cần làm gì?','giữ vệ sinh, ăn uống đủ chất, học tập và nghỉ ngơi hợp lí','ăn uống thất thường','thức khuya nhiều','lười vận động'],
   [3,'Nêu một số việc nên làm để chăm sóc sức khỏe tuổi dậy thì.','Giữ vệ sinh cá nhân, ăn uống đủ chất, tập thể dục, ngủ đủ, tìm hiểu kiến thức đúng đắn (HS tự nêu).']]},
  {cd:'Bài 41: Môi trường và các nhân tố sinh thái',q:[
   [1,'Môi trường sống của sinh vật là gì?','nơi sinh vật sinh sống, gồm tất cả những gì bao quanh nó','chỉ không khí','chỉ nước','chỉ đất'],
   [2,'Nhân tố sinh thái được chia thành mấy nhóm chính?','hai nhóm: vô sinh và hữu sinh','một nhóm','ba nhóm','năm nhóm'],
   [3,'Kể tên một số nhân tố sinh thái vô sinh và hữu sinh.','Vô sinh: ánh sáng, nhiệt độ, nước, đất; hữu sinh: thực vật, động vật, con người (HS tự nêu).']]},
  {cd:'Bài 42: Quần thể sinh vật',q:[
   [1,'Quần thể sinh vật là gì?','tập hợp các cá thể cùng loài, sống trong một khu vực nhất định','nhiều loài khác nhau','một cá thể','một hệ sinh thái'],
   [2,'Đâu là ví dụ về một quần thể sinh vật?','đàn voi trong rừng','rừng nhiệt đới có nhiều loài','một cái ao','cả Trái Đất'],
   [3,'Nêu một đặc trưng cơ bản của quần thể.','VD: mật độ, tỉ lệ giới tính, thành phần nhóm tuổi, kích thước quần thể (HS tự nêu).']]},
  {cd:'Bài 43: Quần xã sinh vật',q:[
   [1,'Quần xã sinh vật là gì?','tập hợp nhiều quần thể của các loài khác nhau cùng sống trong một khu vực','một cá thể','một loài duy nhất','không có sinh vật'],
   [2,'Đâu là ví dụ về một quần xã sinh vật?','các sinh vật trong một khu rừng','một đàn gà','một con cá','một hạt giống'],
   [3,'Phân biệt quần thể và quần xã.','Quần thể gồm các cá thể cùng loài; quần xã gồm nhiều quần thể của các loài khác nhau (HS tự nêu).']]},
  {cd:'Bài 44: Hệ sinh thái',q:[
   [1,'Hệ sinh thái bao gồm những thành phần nào?','quần xã sinh vật và môi trường sống của chúng','chỉ sinh vật','chỉ môi trường','chỉ một loài'],
   [2,'Trong hệ sinh thái, cây xanh đóng vai trò là gì?','sinh vật sản xuất','sinh vật tiêu thụ','sinh vật phân giải','không có vai trò'],
   [3,'Nêu một ví dụ về hệ sinh thái.','VD: một khu rừng, một cái ao, một cánh đồng lúa (HS tự nêu).']]},
  {cd:'Bài 45: Sinh quyển',q:[
   [1,'Sinh quyển là gì?','toàn bộ nơi có sự sống trên Trái Đất','chỉ mặt đất','chỉ đại dương','chỉ bầu trời'],
   [2,'Sinh quyển gồm những môi trường sống nào?','trên cạn, dưới nước và trong đất','chỉ trên cạn','chỉ dưới nước','chỉ trong không khí'],
   [3,'Vì sao cần bảo vệ sinh quyển?','Vì sinh quyển là nơi sống của mọi sinh vật, bảo vệ nó là bảo vệ sự sống (HS tự nêu).']]},
  {cd:'Bài 46: Cân bằng tự nhiên',q:[
   [1,'Cân bằng tự nhiên là trạng thái như thế nào?','ổn định tương đối của số lượng cá thể và các thành phần trong tự nhiên','hỗn loạn','luôn thay đổi mạnh','không tồn tại'],
   [2,'Hoạt động nào của con người làm mất cân bằng tự nhiên?','phá rừng, săn bắt quá mức, gây ô nhiễm','trồng rừng','bảo vệ động vật','xử lí rác'],
   [3,'Nêu ý nghĩa của cân bằng tự nhiên.','Giúp duy trì sự ổn định của hệ sinh thái và sự sống trên Trái Đất (HS tự nêu).']]},
  {cd:'Bài 47: Bảo vệ môi trường',q:[
   [1,'Việc làm nào giúp bảo vệ môi trường?','trồng cây, xử lí rác, tiết kiệm tài nguyên','xả rác bừa bãi','chặt phá rừng','gây ô nhiễm'],
   [2,'Ô nhiễm môi trường gây ra hậu quả gì?','ảnh hưởng xấu đến sức khỏe và sự sống','không ảnh hưởng gì','làm môi trường tốt hơn','tạo đa dạng sinh học'],
   [3,'Nêu hai việc học sinh có thể làm để bảo vệ môi trường.','VD: bỏ rác đúng nơi, tiết kiệm điện nước, trồng và chăm sóc cây, hạn chế túi ni lông (HS tự nêu).']]}
 );
 KH[9].push(
  {cd:'Bài 1: Nhận biết một số dụng cụ, hóa chất. Thuyết trình một vấn đề khoa học',q:[
   [1,'Khi lựa chọn dụng cụ, hóa chất cho thí nghiệm, cần bảo đảm điều gì?','phù hợp và an toàn','đắt tiền nhất','nhiều nhất','màu đẹp nhất'],
   [2,'Khi thuyết trình một vấn đề khoa học cần chú ý gì?','trình bày rõ ràng, có số liệu, dẫn chứng tin cậy','nói qua loa','bịa số liệu','không chuẩn bị'],
   [3,'Nêu các bước chuẩn bị một bài thuyết trình khoa học.','Chọn chủ đề, thu thập thông tin tin cậy, xây dựng nội dung, chuẩn bị minh họa và trình bày (HS tự nêu).']]},
  {cd:'Bài 2: Động năng. Thế năng',q:[
   [1,'Động năng của một vật là năng lượng có được do đâu?','do vật chuyển động','do vật đứng yên','do vật có màu','do vật nóng'],
   [2,'Thế năng trọng trường của vật phụ thuộc vào yếu tố nào?','khối lượng và độ cao của vật','màu sắc vật','tên vật','âm thanh'],
   [3,'Khi chơi xích đu, ở vị trí cao nhất và thấp nhất, năng lượng của người thay đổi thế nào?','Ở cao nhất thế năng lớn, động năng nhỏ; ở thấp nhất động năng lớn, thế năng nhỏ (HS tự nêu).']]},
  {cd:'Bài 3: Cơ năng',q:[
   [1,'Cơ năng của một vật bằng gì?','tổng động năng và thế năng của vật','chỉ động năng','chỉ thế năng','khối lượng vật'],
   [2,'Trong quá trình vật rơi, động năng và thế năng có mối quan hệ gì?','chuyển hóa qua lại cho nhau','không đổi riêng lẻ','tự mất đi','không liên quan'],
   [3,'Nêu một ví dụ về sự chuyển hóa giữa động năng và thế năng.','VD: viên bi lăn từ trên dốc xuống: thế năng giảm, động năng tăng (HS tự nêu).']]},
  {cd:'Bài 4: Công và công suất',q:[
   [1,'Công suất cho biết điều gì?','tốc độ thực hiện công (công thực hiện trong một đơn vị thời gian)','khối lượng vật','nhiệt độ','màu sắc'],
   [2,'Đơn vị đo công suất là gì?','oát (W)','jun (J)','niutơn (N)','ampe (A)'],
   [3,'Viết công thức tính công suất.','P = A / t (công thực hiện chia thời gian) (HS tự nêu).']]},
  {cd:'Bài 5: Khúc xạ ánh sáng',q:[
   [1,'Khúc xạ ánh sáng là hiện tượng gì?','tia sáng bị gãy (đổi hướng) khi truyền từ môi trường trong suốt này sang môi trường khác','ánh sáng biến mất','ánh sáng phản xạ trở lại','ánh sáng dừng lại'],
   [2,'Hiện tượng nào giải thích vì sao chiếc đũa cắm trong cốc nước trông như bị gãy?','khúc xạ ánh sáng','phản xạ toàn phần','nhiễm điện','dẫn nhiệt'],
   [3,'Nêu một ví dụ về hiện tượng khúc xạ ánh sáng trong thực tế.','VD: nhìn đáy bể nước thấy nông hơn thực tế; đũa trong cốc nước như gãy khúc (HS tự nêu).']]},
  {cd:'Bài 6: Phản xạ toàn phần',q:[
   [1,'Phản xạ toàn phần xảy ra khi ánh sáng truyền từ môi trường nào sang môi trường nào?','từ môi trường chiết quang hơn sang chiết quang kém, với góc tới đủ lớn','từ không khí vào nước','trong chân không','khi góc tới bằng 0'],
   [2,'Hiện tượng phản xạ toàn phần được ứng dụng trong thiết bị nào?','cáp quang','bóng đèn sợi đốt','cái cân','nhiệt kế'],
   [3,'Nêu một ứng dụng của phản xạ toàn phần.','VD: truyền tín hiệu trong cáp quang dùng cho internet, viễn thông (HS tự nêu).']]},
  {cd:'Bài 7: Lăng kính',q:[
   [1,'Khi chiếu ánh sáng trắng qua lăng kính, ta thu được gì?','dải màu từ đỏ đến tím','chỉ màu trắng','chỉ màu đen','không có gì'],
   [2,'Hiện tượng ánh sáng trắng bị phân tích thành nhiều màu gọi là gì?','sự tán sắc ánh sáng','phản xạ','khúc xạ toàn phần','nhiễm điện'],
   [3,'Nêu một hiện tượng tự nhiên liên quan đến sự tán sắc ánh sáng.','VD: cầu vồng xuất hiện sau mưa do ánh sáng Mặt Trời bị tán sắc qua giọt nước (HS tự nêu).']]},
  {cd:'Bài 8: Thấu kính',q:[
   [1,'Thấu kính hội tụ có đặc điểm gì?','phần giữa dày hơn phần rìa','phần rìa dày hơn giữa','phẳng hoàn toàn','trong suốt như gương'],
   [2,'Thấu kính phân kì có đặc điểm gì?','phần rìa dày hơn phần giữa','phần giữa dày hơn rìa','không trong suốt','là một tấm gương'],
   [3,'Nêu một ứng dụng của thấu kính trong đời sống.','VD: kính lúp, kính cận, máy ảnh, kính hiển vi dùng thấu kính (HS tự nêu).']]},
  {cd:'Bài 9: Thực hành đo tiêu cự của thấu kính hội tụ',q:[
   [1,'Tiêu cự của thấu kính là khoảng cách từ đâu đến đâu?','từ quang tâm đến tiêu điểm chính','từ mép này sang mép kia','từ vật đến mắt','từ đèn đến tường'],
   [2,'Khi chiếu chùm sáng song song với trục chính vào thấu kính hội tụ, chùm tia ló sẽ đi qua điểm nào?','tiêu điểm chính','quang tâm','mép thấu kính','ra vô cực'],
   [3,'Nêu một cách đo tiêu cự của thấu kính hội tụ.','Tạo ảnh rõ nét của vật ở xa (ánh sáng song song) trên màn; khoảng cách từ thấu kính đến màn gần bằng tiêu cự (HS tự nêu).']]},
  {cd:'Bài 10: Kính lúp. Bài tập thấu kính',q:[
   [1,'Kính lúp là loại thấu kính gì?','thấu kính hội tụ có tiêu cự ngắn','thấu kính phân kì','gương phẳng','gương cầu'],
   [2,'Kính lúp giúp ta quan sát vật như thế nào?','thấy ảnh ảo lớn hơn vật','thấy ảnh nhỏ hơn','thấy ảnh ngược','không thấy gì'],
   [3,'Vì sao người thợ sửa đồng hồ dùng kính lúp?','Để nhìn rõ các chi tiết rất nhỏ (ảnh được phóng to) (HS tự nêu).']]},
  {cd:'Bài 11: Điện trở. Định luật Ohm',q:[
   [1,'Theo định luật Ohm, cường độ dòng điện qua một điện trở được tính bằng công thức nào?','I = U / R','I = U . R','I = R / U','I = U + R'],
   [2,'Đơn vị của điện trở là gì?','ôm (Ω)','ampe (A)','vôn (V)','oát (W)'],
   [3,'Phát biểu định luật Ohm.','Cường độ dòng điện qua một điện trở tỉ lệ thuận với hiệu điện thế hai đầu và tỉ lệ nghịch với điện trở: I = U/R (HS tự nêu).']]},
  {cd:'Bài 12: Đoạn mạch nối tiếp, song song',q:[
   [1,'Trong đoạn mạch nối tiếp, cường độ dòng điện tại mọi điểm như thế nào?','bằng nhau','khác nhau','bằng 0','gấp đôi nhau'],
   [2,'Nếu muốn một bóng đèn cháy thì bóng kia vẫn sáng, ta mắc chúng như thế nào?','mắc song song','mắc nối tiếp','không mắc','mắc vào nguồn khác nhau'],
   [3,'Nêu đặc điểm của đoạn mạch nối tiếp và song song về dòng điện, hiệu điện thế.','Nối tiếp: dòng điện như nhau, hiệu điện thế cộng lại; song song: hiệu điện thế như nhau, dòng điện chia ra (HS tự nêu).']]},
  {cd:'Bài 13: Năng lượng của dòng điện và công suất điện',q:[
   [1,'Công suất điện cho biết điều gì?','lượng điện năng tiêu thụ trong một đơn vị thời gian','khối lượng thiết bị','màu của đèn','nhiệt độ phòng'],
   [2,'Số ghi trên bóng đèn như 220V - 40W cho biết gì?','hiệu điện thế định mức và công suất định mức','khối lượng và thể tích','giá tiền và năm sản xuất','màu và kích thước'],
   [3,'Nêu ý nghĩa của các số liệu ghi trên thiết bị điện.','Cho biết hiệu điện thế và công suất định mức để sử dụng đúng và an toàn (HS tự nêu).']]},
  {cd:'Bài 14: Cảm ứng điện từ. Nguyên tắc tạo ra dòng điện xoay chiều',q:[
   [1,'Hiện tượng cảm ứng điện từ là gì?','dòng điện xuất hiện khi số đường sức từ qua cuộn dây biến thiên','nam châm hút sắt','dòng điện làm nóng dây','điện phân'],
   [2,'Máy phát điện hoạt động dựa trên hiện tượng nào?','cảm ứng điện từ','nhiễm điện do cọ xát','khúc xạ ánh sáng','phản xạ âm'],
   [3,'Nêu nguyên tắc tạo ra dòng điện xoay chiều.','Cho cuộn dây quay trong từ trường (hoặc nam châm quay) làm số đường sức từ biến thiên, sinh ra dòng điện xoay chiều (HS tự nêu).']]},
  {cd:'Bài 15: Tác dụng của dòng điện xoay chiều',q:[
   [1,'Dòng điện xoay chiều có những tác dụng nào?','tác dụng nhiệt, phát sáng, từ','chỉ phát ra mùi','không có tác dụng','chỉ tạo âm thanh'],
   [2,'Bếp từ hoạt động dựa trên tác dụng nào của dòng điện xoay chiều?','tác dụng từ (cảm ứng điện từ)','tác dụng hóa học','phản xạ ánh sáng','khúc xạ'],
   [3,'Kể tên một số thiết bị sử dụng dòng điện xoay chiều.','VD: quạt điện, bếp từ, bình nóng lạnh, đèn, máy sấy tóc (HS tự nêu).']]},
  {cd:'Bài 16: Vòng năng lượng trên Trái Đất. Năng lượng hóa thạch',q:[
   [1,'Nguồn năng lượng khởi đầu cho hầu hết các vòng năng lượng trên Trái Đất là gì?','năng lượng Mặt Trời','năng lượng gió','năng lượng than','năng lượng hạt nhân'],
   [2,'Nhiên liệu hóa thạch gồm những loại nào?','than đá, dầu mỏ, khí thiên nhiên','gỗ, rơm','nước, gió','ánh sáng'],
   [3,'Nêu nhược điểm của việc sử dụng nhiên liệu hóa thạch.','Gây ô nhiễm, phát thải khí nhà kính và sẽ cạn kiệt (HS tự nêu).']]},
  {cd:'Bài 17: Một số dạng năng lượng tái tạo',q:[
   [1,'Đâu là nguồn năng lượng tái tạo?','năng lượng mặt trời, gió, sóng biển, dòng nước','than đá','dầu mỏ','khí thiên nhiên'],
   [2,'Ưu điểm của năng lượng tái tạo là gì?','sạch, không cạn kiệt','gây ô nhiễm nặng','sẽ cạn kiệt nhanh','rất độc hại'],
   [3,'Nêu một ưu điểm và một hạn chế của năng lượng tái tạo.','Ưu điểm: sạch, vô tận; hạn chế: phụ thuộc thời tiết, chi phí đầu tư ban đầu cao (HS tự nêu).']]},
  {cd:'Bài 18: Tính chất chung của kim loại',q:[
   [1,'Kim loại có tính chất vật lí chung nào?','dẫn điện, dẫn nhiệt tốt, có ánh kim','không dẫn điện','giòn, dễ vỡ','trong suốt'],
   [2,'Kim loại nào dẫn điện tốt và thường dùng làm dây dẫn?','đồng','gỗ','nhựa','thủy tinh'],
   [3,'Nêu một số tính chất chung của kim loại.','Dẫn điện, dẫn nhiệt tốt, có ánh kim, dẻo (có thể dát mỏng, kéo sợi) (HS tự nêu).']]},
  {cd:'Bài 19: Dãy hoạt động hóa học',q:[
   [1,'Dãy hoạt động hóa học của kim loại cho biết điều gì?','mức độ hoạt động hóa học mạnh hay yếu của các kim loại','màu của kim loại','giá của kim loại','khối lượng kim loại'],
   [2,'Trong dãy hoạt động, kim loại đứng trước có đặc điểm gì so với kim loại đứng sau?','hoạt động hóa học mạnh hơn','yếu hơn','giống hệt','không liên quan'],
   [3,'Nêu ý nghĩa của dãy hoạt động hóa học.','Giúp dự đoán khả năng phản ứng của kim loại, kim loại mạnh có thể đẩy kim loại yếu ra khỏi dung dịch muối (HS tự nêu).']]},
  {cd:'Bài 20: Tách kim loại và việc sử dụng hợp kim',q:[
   [1,'Hợp kim là gì?','vật liệu gồm kim loại trộn với một hay nhiều nguyên tố khác','một kim loại nguyên chất','một loại nhựa','một loại khí'],
   [2,'Thép là hợp kim chủ yếu của nguyên tố nào?','sắt (iron) và carbon','nhôm và nhựa','đồng và gỗ','vàng và bạc'],
   [3,'Nêu lí do con người sử dụng hợp kim thay cho kim loại nguyên chất.','Hợp kim thường bền, cứng, chống gỉ tốt hơn và phù hợp nhiều mục đích sử dụng (HS tự nêu).']]},
  {cd:'Bài 21: Sự khác nhau cơ bản giữa phi kim và kim loại',q:[
   [1,'Phi kim thường có tính chất nào khác kim loại?','thường không dẫn điện, không có ánh kim','dẫn điện tốt','đều có ánh kim','đều là chất rắn dẻo'],
   [2,'Đâu là một phi kim?','carbon, lưu huỳnh, chlorine','sắt','đồng','nhôm'],
   [3,'Nêu một điểm khác nhau cơ bản giữa kim loại và phi kim.','Kim loại dẫn điện, dẫn nhiệt tốt, có ánh kim; phi kim thường không dẫn điện, không có ánh kim (HS tự nêu).']]},
  {cd:'Bài 22: Giới thiệu về hợp chất hữu cơ',q:[
   [1,'Hợp chất hữu cơ là hợp chất của nguyên tố nào (trừ một số ít)?','carbon','sắt','vàng','oxygen'],
   [2,'Đâu là một hợp chất hữu cơ?','đường, rượu, khí methane','muối ăn','nước','vôi'],
   [3,'Nêu đặc điểm chung của hợp chất hữu cơ.','Là hợp chất của carbon (thường có H), nhiều loại dễ cháy, có vai trò quan trọng với sự sống (HS tự nêu).']]},
  {cd:'Bài 23: Alkane',q:[
   [1,'Alkane là hydrocarbon có đặc điểm liên kết nào?','chỉ có liên kết đơn giữa các nguyên tử carbon','có liên kết đôi','có liên kết ba','không có liên kết'],
   [2,'Khí nào là một alkane được dùng làm nhiên liệu (khí gas, bật lửa)?','methane, butane','oxygen','nitrogen','carbon dioxide'],
   [3,'Nêu một ứng dụng của alkane trong đời sống.','VD: làm nhiên liệu (khí gas, xăng, dầu) để đun nấu, chạy động cơ (HS tự nêu).']]},
  {cd:'Bài 24: Alkene',q:[
   [1,'Alkene là hydrocarbon có đặc điểm liên kết nào?','có một liên kết đôi giữa hai nguyên tử carbon','chỉ có liên kết đơn','có ba liên kết','không có carbon'],
   [2,'Khí ethylene (một alkene) có tác dụng gì với trái cây?','thúc đẩy quá trình chín của trái cây','làm trái cây thối ngay','làm trái cây đông cứng','không tác dụng'],
   [3,'Nêu một ứng dụng của alkene.','VD: ethylene dùng làm chín trái cây, sản xuất nhựa (polyethylene) (HS tự nêu).']]},
  {cd:'Bài 25: Nguồn nhiên liệu',q:[
   [1,'Dầu mỏ, khí thiên nhiên có thành phần chính là gì?','các hydrocarbon','kim loại','muối','nước'],
   [2,'Nhiên liệu hóa thạch được hình thành từ đâu?','xác sinh vật bị vùi lấp qua hàng triệu năm','từ nước biển','từ đá núi lửa','tự nhiên sinh ra liên tục'],
   [3,'Vì sao cần sử dụng tiết kiệm nguồn nhiên liệu hóa thạch?','Vì chúng có hạn, mất rất lâu để hình thành và gây ô nhiễm khi sử dụng (HS tự nêu).']]},
  {cd:'Bài 26: Ethylic alcohol',q:[
   [1,'Ethylic alcohol (rượu etylic) thường được tạo ra bằng cách nào?','lên men các sản phẩm có tinh bột, đường','nung đá vôi','điện phân nước','đốt than'],
   [2,'Ethylic alcohol có tính chất nào?','là chất lỏng, dễ cháy, tan vô hạn trong nước','là chất rắn','không cháy','là kim loại'],
   [3,'Nêu một ứng dụng của ethylic alcohol.','VD: làm dung môi, nhiên liệu, sát khuẩn (cồn y tế) (HS tự nêu).']]},
  {cd:'Bài 27: Acetic acid',q:[
   [1,'Chất nào tạo nên vị chua của giấm ăn?','acetic acid','đường','muối','rượu'],
   [2,'Acetic acid có tính chất hóa học của loại chất nào?','acid (làm quỳ tím hóa đỏ)','base','muối trung tính','kim loại'],
   [3,'Nêu một ứng dụng của acetic acid.','VD: giấm ăn dùng chế biến thực phẩm, tẩy cặn; dùng trong công nghiệp (HS tự nêu).']]},
  {cd:'Bài 28: Lipid',q:[
   [1,'Lipid (chất béo) gồm những loại nào thường gặp?','dầu thực vật và mỡ động vật','muối và đường','nước và khí','kim loại'],
   [2,'Lipid có vai trò gì đối với cơ thể?','dự trữ và cung cấp năng lượng','không có vai trò','chỉ gây hại','tạo ra oxygen'],
   [3,'Nêu lưu ý khi sử dụng chất béo trong khẩu phần ăn.','Dùng vừa phải, cân đối; nên dùng dầu thực vật, hạn chế mỡ động vật và đồ chiên rán nhiều (HS tự nêu).']]},
  {cd:'Bài 29: Carbohydrate glucose và saccharose',q:[
   [1,'Glucose và saccharose thuộc nhóm chất nào?','carbohydrate (chất bột đường)','chất đạm','chất béo','muối khoáng'],
   [2,'Saccharose (đường mía) có vị gì và dùng để làm gì?','vị ngọt, làm thực phẩm, gia vị','vị chua','vị mặn','vị đắng'],
   [3,'Nêu vai trò của carbohydrate đối với cơ thể.','Là nguồn cung cấp năng lượng chính cho các hoạt động sống (HS tự nêu).']]},
  {cd:'Bài 30: Tinh bột và cellulose',q:[
   [1,'Tinh bột có nhiều trong loại thực phẩm nào?','gạo, ngô, khoai, sắn','thịt','dầu ăn','muối'],
   [2,'Cellulose là thành phần chính tạo nên bộ phận nào của thực vật?','thành tế bào thực vật (chất xơ)','nhân tế bào','máu','xương'],
   [3,'Nêu vai trò của tinh bột và cellulose.','Tinh bột cung cấp năng lượng; cellulose (chất xơ) giúp tiêu hóa tốt, làm nguyên liệu (giấy, vải) (HS tự nêu).']]},
  {cd:'Bài 31: Protein',q:[
   [1,'Protein (chất đạm) có vai trò gì đối với cơ thể?','cấu tạo tế bào và tham gia nhiều hoạt động sống','chỉ tạo năng lượng dự trữ','không có vai trò','chỉ tạo màu da'],
   [2,'Thực phẩm nào giàu protein?','thịt, cá, trứng, sữa, đậu','dầu ăn','đường','muối'],
   [3,'Nêu vai trò quan trọng của protein đối với cơ thể.','Xây dựng và tái tạo tế bào, tham gia cấu tạo enzyme, kháng thể và nhiều hoạt động sống (HS tự nêu).']]},
  {cd:'Bài 32: Polymer',q:[
   [1,'Polymer là những phân tử có đặc điểm gì?','có khối lượng phân tử rất lớn, gồm nhiều mắt xích lặp lại','rất nhỏ','chỉ có một nguyên tử','là kim loại'],
   [2,'Đâu là một polymer thường gặp?','chất dẻo (nhựa), cao su','muối ăn','nước','oxygen'],
   [3,'Nêu một ứng dụng của polymer và một vấn đề môi trường do nó gây ra.','Ứng dụng: làm nhựa, cao su, sợi; vấn đề: rác thải nhựa khó phân hủy gây ô nhiễm (HS tự nêu).']]},
  {cd:'Bài 33: Sơ lược về hóa học vỏ Trái Đất và khai thác tài nguyên từ vỏ Trái Đất',q:[
   [1,'Nguyên tố nào chiếm tỉ lệ lớn trong vỏ Trái Đất?','oxygen và silicon','vàng','bạc','kim cương'],
   [2,'Khoáng sản trong vỏ Trái Đất là loại tài nguyên như thế nào?','có hạn, cần khai thác hợp lí','vô hạn','tự sinh ra liên tục','không có giá trị'],
   [3,'Vì sao cần khai thác tài nguyên khoáng sản hợp lí?','Vì khoáng sản có hạn, khó tái tạo; khai thác bừa bãi gây cạn kiệt và ô nhiễm (HS tự nêu).']]},
  {cd:'Bài 34: Khai thác đá vôi. Công nghiệp silicate',q:[
   [1,'Thành phần chính của đá vôi là chất nào?','calcium carbonate (CaCO3)','muối ăn','cát','sắt'],
   [2,'Đá vôi là nguyên liệu để sản xuất sản phẩm nào?','vôi, xi măng','xăng dầu','nhựa','vải'],
   [3,'Nêu một ứng dụng của đá vôi và sản phẩm từ công nghiệp silicate.','Đá vôi làm vôi, xi măng; công nghiệp silicate làm thủy tinh, gốm sứ (HS tự nêu).']]},
  {cd:'Bài 35: Khai thác nhiên liệu hóa thạch. Nguồn carbon. Chu trình carbon và sự ấm lên toàn cầu',q:[
   [1,'Việc đốt nhiên liệu hóa thạch thải ra khí nào gây hiệu ứng nhà kính?','khí carbon dioxide (CO2)','khí oxygen','khí nitrogen','hơi nước sạch'],
   [2,'Sự ấm lên toàn cầu chủ yếu do nguyên nhân nào?','tăng khí nhà kính từ hoạt động của con người','do Mặt Trăng','do trồng rừng','do mưa nhiều'],
   [3,'Nêu một số biện pháp giảm phát thải khí nhà kính.','Dùng năng lượng tái tạo, tiết kiệm năng lượng, trồng rừng, giảm đốt nhiên liệu hóa thạch (HS tự nêu).']]},
  {cd:'Bài 36: Khái quát về di truyền học',q:[
   [1,'Di truyền là hiện tượng gì?','con cái mang những đặc điểm giống bố mẹ','con cái hoàn toàn khác bố mẹ','sinh vật biến mất','sinh vật không thay đổi'],
   [2,'Biến dị là hiện tượng gì?','con sinh ra có những đặc điểm khác bố mẹ và khác nhau','giống hệt bố mẹ','không có đặc điểm','không tồn tại'],
   [3,'Nêu mối quan hệ giữa di truyền và biến dị.','Di truyền giữ lại đặc điểm của loài; biến dị tạo ra sự khác nhau, giúp sinh vật đa dạng (HS tự nêu).']]},
  {cd:'Bài 37: Các quy luật di truyền của Mendel',q:[
   [1,'Mendel đã tiến hành thí nghiệm trên đối tượng nào?','cây đậu Hà Lan','cây lúa','con ruồi giấm','con người'],
   [2,'Khi lai hai cây đậu thuần chủng hoa tím với hoa trắng, đời F1 (theo Mendel) thường có kiểu hình nào?','đồng loạt hoa tím (tính trạng trội)','đồng loạt hoa trắng','nửa tím nửa trắng','không có hoa'],
   [3,'Nêu nội dung cơ bản quy luật phân li của Mendel.','Mỗi tính trạng do một cặp nhân tố di truyền quy định; khi hình thành giao tử, các nhân tố phân li, mỗi giao tử chỉ chứa một nhân tố (HS tự nêu).']]},
  {cd:'Bài 38: Nucleic acid và gene',q:[
   [1,'DNA được cấu tạo từ đơn phân nào?','nucleotide','amino acid','glucose','acid béo'],
   [2,'Gene là gì?','một đoạn của phân tử DNA mang thông tin di truyền','một loại protein','một tế bào','một nhiễm sắc thể hoàn chỉnh'],
   [3,'Nêu vai trò của DNA đối với sinh vật.','Lưu giữ và truyền đạt thông tin di truyền từ thế hệ này sang thế hệ khác (HS tự nêu).']]},
  {cd:'Bài 39: Tái bản DNA và phiên mã tạo ra RNA',q:[
   [1,'Quá trình tái bản DNA tạo ra kết quả gì?','hai phân tử DNA con giống phân tử DNA mẹ','một protein','một tế bào mới hoàn chỉnh','một loại đường'],
   [2,'Phiên mã là quá trình tổng hợp phân tử nào từ DNA?','RNA','protein','lipid','glucose'],
   [3,'Nêu ý nghĩa của quá trình tái bản DNA.','Giúp thông tin di truyền được sao chép chính xác và truyền cho các tế bào con (HS tự nêu).']]},
  {cd:'Bài 40: Dịch mã và mối quan hệ từ gene đến tính trạng',q:[
   [1,'Dịch mã là quá trình tổng hợp phân tử nào?','protein (chuỗi polypeptide)','DNA','RNA','glucose'],
   [2,'Mối quan hệ từ gene đến tính trạng diễn ra theo sơ đồ nào?','gene (DNA) tạo ra RNA, RNA tạo ra protein, protein biểu hiện tính trạng','tính trạng tạo ra gene','protein tạo ra DNA','ngẫu nhiên'],
   [3,'Nêu vai trò của protein trong biểu hiện tính trạng.','Protein tham gia cấu tạo và hoạt động của tế bào, qua đó biểu hiện thành tính trạng của cơ thể (HS tự nêu).']]},
  {cd:'Bài 41: Đột biến gene',q:[
   [1,'Đột biến gene là gì?','những biến đổi trong cấu trúc của gene','sự nhân đôi bình thường','sự phân chia tế bào','sự lớn lên của cơ thể'],
   [2,'Đột biến gene có thể gây ra điều gì?','làm thay đổi tính trạng, có thể có lợi, có hại hoặc trung tính','luôn có lợi','luôn vô hại','không ảnh hưởng gì'],
   [3,'Nêu một ứng dụng của đột biến trong thực tế.','VD: tạo giống cây trồng mới có năng suất cao, đặc tính tốt (HS tự nêu).']]},
  {cd:'Bài 42: Di truyền nhiễm sắc thể',q:[
   [1,'Nhiễm sắc thể nằm ở đâu trong tế bào?','trong nhân tế bào','ở màng tế bào','ngoài tế bào','trong máu'],
   [2,'Nhiễm sắc thể được cấu tạo chủ yếu từ những thành phần nào?','DNA và protein','chỉ nước','chỉ lipid','kim loại'],
   [3,'Nêu vai trò của nhiễm sắc thể trong di truyền.','Mang gene (DNA), lưu giữ và truyền thông tin di truyền qua các thế hệ tế bào và cơ thể (HS tự nêu).']]},
  {cd:'Bài 43: Nguyên phân và giảm phân',q:[
   [1,'Nguyên phân là hình thức phân chia tạo ra các tế bào con như thế nào?','có bộ nhiễm sắc thể giống tế bào mẹ','có bộ nhiễm sắc thể giảm một nửa','không có nhiễm sắc thể','gấp đôi tế bào mẹ'],
   [2,'Giảm phân tạo ra giao tử có bộ nhiễm sắc thể như thế nào so với tế bào mẹ?','giảm đi một nửa','giống hệt','gấp đôi','gấp ba'],
   [3,'Nêu ý nghĩa của nguyên phân và giảm phân.','Nguyên phân giúp cơ thể lớn lên, thay thế tế bào; giảm phân tạo giao tử cho sinh sản hữu tính (HS tự nêu).']]},
  {cd:'Bài 44: Nhiễm sắc thể giới tính và cơ chế xác định giới tính',q:[
   [1,'Ở người, cặp nhiễm sắc thể giới tính của nữ là gì?','XX','XY','YY','XO'],
   [2,'Ở người, cặp nhiễm sắc thể giới tính của nam là gì?','XY','XX','YY','OO'],
   [3,'Giới tính của con do bố hay mẹ quyết định? Giải thích.','Do bố, vì bố cho giao tử mang X (sinh con gái) hoặc Y (sinh con trai), mẹ luôn cho X (HS tự nêu).']]},
  {cd:'Bài 45: Di truyền liên kết',q:[
   [1,'Di truyền liên kết là hiện tượng các gene như thế nào?','cùng nằm trên một nhiễm sắc thể và thường di truyền cùng nhau','nằm rời rạc, di truyền độc lập','không di truyền','luôn tách rời'],
   [2,'Hiện tượng di truyền liên kết được phát hiện trên đối tượng nào?','ruồi giấm','đậu Hà Lan','con người','vi khuẩn'],
   [3,'Nêu ý nghĩa của di truyền liên kết.','Giúp các nhóm tính trạng tốt được di truyền cùng nhau, có ý nghĩa trong chọn giống (HS tự nêu).']]},
  {cd:'Bài 46: Đột biến nhiễm sắc thể',q:[
   [1,'Đột biến nhiễm sắc thể là những biến đổi về đâu?','cấu trúc hoặc số lượng nhiễm sắc thể','màu da','chiều cao bình thường','tên gọi'],
   [2,'Đột biến nhiễm sắc thể có thể gây ra điều gì?','thay đổi lớn về tính trạng, có thể có hại hoặc được ứng dụng trong chọn giống','luôn vô hại','không ảnh hưởng gì','làm sinh vật biến mất'],
   [3,'Nêu một ứng dụng của đột biến nhiễm sắc thể.','VD: tạo giống dưa hấu không hạt, cây trồng đa bội cho năng suất cao (HS tự nêu).']]},
  {cd:'Bài 47: Di truyền học với con người',q:[
   [1,'Vì sao Luật Hôn nhân và gia đình cấm kết hôn gần trong phạm vi ba đời?','vì làm tăng khả năng con sinh ra mắc bệnh, dị tật di truyền','vì không đủ tuổi','vì khác quê','không có lí do'],
   [2,'Di truyền y học giúp ích gì cho con người?','phòng, chẩn đoán và tư vấn về các bệnh di truyền','gây bệnh','không có tác dụng','làm hại sức khỏe'],
   [3,'Nêu ý nghĩa của việc tư vấn di truyền.','Giúp phòng tránh và giảm nguy cơ sinh con mắc bệnh, dị tật di truyền (HS tự nêu).']]},
  {cd:'Bài 48: Ứng dụng công nghệ di truyền vào đời sống',q:[
   [1,'Công nghệ di truyền sử dụng đối tượng nào để tạo ra sản phẩm?','tế bào sống và các quá trình sinh học','chỉ máy móc','chỉ kim loại','chỉ hóa chất vô cơ'],
   [2,'Đâu là một ứng dụng của công nghệ di truyền?','sản xuất thuốc, tạo giống cây trồng, vật nuôi mới','làm cầu đường','sản xuất xi măng','khai thác than'],
   [3,'Kể tên một số sản phẩm của công nghệ di truyền.','VD: insulin, giống cây kháng sâu bệnh, vật nuôi năng suất cao (HS tự nêu).']]},
  {cd:'Bài 49: Khái niệm tiến hóa và các hình thức chọn lọc',q:[
   [1,'Tiến hóa là quá trình gì?','biến đổi của sinh vật qua nhiều thế hệ tạo nên sự đa dạng và thích nghi','sinh vật đứng yên','sinh vật biến mất','sự lớn lên của một cá thể'],
   [2,'Chọn lọc tự nhiên giữ lại những sinh vật như thế nào?','thích nghi tốt với môi trường','yếu nhất','to nhất','có màu đẹp nhất'],
   [3,'Nêu vai trò của chọn lọc tự nhiên trong tiến hóa.','Giữ lại và tích lũy các đặc điểm thích nghi, loại bỏ đặc điểm kém thích nghi, hình thành loài mới (HS tự nêu).']]},
  {cd:'Bài 50: Cơ chế tiến hóa',q:[
   [1,'Nguồn nguyên liệu cho tiến hóa chủ yếu là gì?','các biến dị di truyền (đột biến)','màu sắc môi trường','âm thanh','ánh sáng'],
   [2,'Chọn lọc tự nhiên tác động lên đối tượng nào?','các cá thể có biến dị khác nhau trong quần thể','vật không sống','chỉ môi trường','chỉ con người'],
   [3,'Nêu vai trò của biến dị và chọn lọc tự nhiên trong tiến hóa.','Biến dị tạo nguyên liệu, chọn lọc tự nhiên giữ lại đặc điểm thích nghi, qua nhiều thế hệ hình thành loài mới (HS tự nêu).']]},
  {cd:'Bài 51: Sự phát sinh và phát triển của sự sống trên Trái Đất',q:[
   [1,'Theo khoa học, sự sống trên Trái Đất phát sinh từ đâu?','từ các chất vô cơ, qua quá trình tiến hóa lâu dài thành chất hữu cơ và sinh vật','từ sinh vật có sẵn ngoài vũ trụ mang tới','tự nhiên có ngay từ đầu','không giải thích được'],
   [2,'Sự sống trên Trái Đất phát triển theo chiều hướng nào?','từ đơn giản đến phức tạp, từ chưa hoàn thiện đến hoàn thiện','từ phức tạp đến đơn giản','không thay đổi','ngẫu nhiên hỗn loạn'],
   [3,'Nêu nhận xét về quá trình phát triển của sự sống trên Trái Đất.','Sự sống phát sinh và phát triển qua hàng tỉ năm, ngày càng đa dạng, phức tạp và thích nghi hơn (HS tự nêu).']]}
 );
 }


 /* ==================== LỊCH SỬ VÀ ĐỊA LÍ ==================== */
 const SD=NH['Lịch sử và Địa lí'];
 if(SD){
 SD[6].push(
  {cd:'Bài 1 (Lịch sử): Lịch sử và cuộc sống',q:[
   [1,'Lịch sử là gì?','những gì đã diễn ra trong quá khứ','những gì sẽ xảy ra','chuyện tưởng tượng','dự báo tương lai'],
   [2,'Học lịch sử để làm gì?','biết cội nguồn, rút ra bài học cho hiện tại và tương lai','để quên quá khứ','không có ích gì','chỉ để thi'],
   [3,'Vì sao chúng ta cần học lịch sử?','Để biết về cội nguồn dân tộc, trân trọng giá trị cha ông và rút ra bài học cho hiện tại (HS tự nêu).']]},
  {cd:'Bài 2 (Lịch sử): Dựa vào đâu để biết và phục dựng lại lịch sử',q:[
   [1,'Tư liệu lịch sử gồm những loại chính nào?','tư liệu hiện vật, chữ viết, truyền miệng','chỉ tranh vẽ','chỉ phim ảnh','không có tư liệu'],
   [2,'Trống đồng Đông Sơn là loại tư liệu lịch sử nào?','tư liệu hiện vật','tư liệu chữ viết','tư liệu truyền miệng','tư liệu bằng phim'],
   [3,'Nêu các loại tư liệu giúp tìm hiểu lịch sử.','Tư liệu hiện vật, tư liệu chữ viết, tư liệu truyền miệng và tư liệu gốc (HS tự nêu).']]},
  {cd:'Bài 3 (Lịch sử): Thời gian trong lịch sử',q:[
   [1,'Một thế kỉ có bao nhiêu năm?','100 năm','10 năm','1000 năm','50 năm'],
   [2,'Cách tính thời gian phổ biến hiện nay dựa theo loại lịch nào?','Dương lịch (theo Mặt Trời)','chỉ Âm lịch','không có lịch','mỗi nước một lịch riêng'],
   [3,'Trước Công nguyên (TCN) được tính như thế nào so với Công nguyên?','Là khoảng thời gian trước năm được coi là năm 1 Công nguyên (HS tự nêu).']]},
  {cd:'Bài 4 (Lịch sử): Nguồn gốc loài người',q:[
   [1,'Theo khoa học, loài người có nguồn gốc tiến hóa từ đâu?','từ một loài vượn cổ','từ loài cá','tự nhiên có sẵn','từ loài chim'],
   [2,'Quá trình tiến hóa từ vượn thành người diễn ra trong thời gian như thế nào?','rất lâu dài (hàng triệu năm)','vài ngày','một năm','một thế kỉ'],
   [3,'Nêu nhận định về nguồn gốc loài người theo khoa học.','Loài người tiến hóa từ một loài vượn cổ qua quá trình lao động lâu dài (HS tự nêu).']]},
  {cd:'Bài 5 (Lịch sử): Xã hội nguyên thủy',q:[
   [1,'Người nguyên thủy sống chủ yếu bằng cách nào?','săn bắt, hái lượm','buôn bán','làm công nghiệp','trồng lúa nước'],
   [2,'Công cụ lao động ban đầu của người nguyên thủy chủ yếu làm bằng gì?','đá','sắt','nhựa','vàng'],
   [3,'Nêu đặc điểm đời sống của người nguyên thủy.','Sống thành bầy, săn bắt hái lượm, dùng công cụ bằng đá, chưa có của cải riêng (HS tự nêu).']]},
  {cd:'Bài 6 (Lịch sử): Sự biến chuyển và phân hóa của xã hội nguyên thủy',q:[
   [1,'Nhờ công cụ bằng kim loại, sản xuất của con người thay đổi như thế nào?','tạo ra nhiều sản phẩm hơn, có của cải dư thừa','giảm sản xuất','không thay đổi','ngừng lao động'],
   [2,'Khi có của cải dư thừa, xã hội nguyên thủy dần xuất hiện điều gì?','sự phân hóa giàu nghèo','sự bình đẳng tuyệt đối','không có gì','biến mất'],
   [3,'Nêu nguyên nhân dẫn đến sự tan rã của xã hội nguyên thủy.','Công cụ kim loại làm sản xuất phát triển, có của cải dư thừa dẫn đến phân hóa giàu nghèo (HS tự nêu).']]},
  {cd:'Bài 7 (Lịch sử): Ai Cập và Lưỡng Hà cổ đại',q:[
   [1,'Nền văn minh Ai Cập cổ đại hình thành bên lưu vực con sông nào?','sông Nin (Nile)','sông Hồng','sông Trường Giang','sông Hằng'],
   [2,'Công trình kiến trúc nổi tiếng của Ai Cập cổ đại là gì?','Kim tự tháp','Vạn Lí Trường Thành','đấu trường La Mã','Tháp Eiffel'],
   [3,'Vì sao các nền văn minh cổ đại thường hình thành bên các dòng sông lớn?','Vì có đất phù sa màu mỡ, nguồn nước thuận lợi cho trồng trọt và sinh sống (HS tự nêu).']]},
  {cd:'Bài 8 (Lịch sử): Ấn Độ cổ đại',q:[
   [1,'Văn minh Ấn Độ cổ đại gắn với lưu vực những con sông nào?','sông Ấn và sông Hằng','sông Nin','sông Hoàng Hà','sông Mê Công'],
   [2,'Tôn giáo nào ra đời ở Ấn Độ cổ đại?','Phật giáo','Hồi giáo','Thiên Chúa giáo','không có'],
   [3,'Nêu một thành tựu văn hóa của Ấn Độ cổ đại.','VD: chữ viết, Phật giáo, chữ số (có số 0), kiến trúc đền tháp (HS tự nêu).']]},
  {cd:'Bài 9 (Lịch sử): Trung Quốc cổ đại',q:[
   [1,'Văn minh Trung Quốc cổ đại hình thành bên lưu vực sông nào?','sông Hoàng Hà và Trường Giang','sông Nin','sông Hằng','sông Hồng'],
   [2,'Công trình nổi tiếng của Trung Quốc thời cổ - trung đại là gì?','Vạn Lí Trường Thành','Kim tự tháp','đấu trường La Mã','đền Taj Mahal'],
   [3,'Kể một thành tựu văn hóa của Trung Quốc cổ đại.','VD: chữ Hán, giấy, la bàn, tư tưởng Nho giáo (HS tự nêu).']]},
  {cd:'Bài 10 (Lịch sử): Hy Lạp và La Mã cổ đại',q:[
   [1,'Hy Lạp và La Mã cổ đại nằm ở khu vực nào?','ven Địa Trung Hải (châu Âu)','châu Á','châu Phi','châu Mỹ'],
   [2,'Thành tựu nổi bật của văn minh Hy Lạp - La Mã là gì?','triết học, khoa học, kiến trúc, luật pháp','không có gì','chỉ nông nghiệp','chỉ săn bắt'],
   [3,'Nêu một thành tựu của văn minh Hy Lạp - La Mã còn ảnh hưởng đến ngày nay.','VD: hệ chữ cái La-tinh, các định lí toán học, kiến trúc, dương lịch (HS tự nêu).']]},
  {cd:'Bài 11 (Lịch sử): Các quốc gia sơ kì ở Đông Nam Á',q:[
   [1,'Các quốc gia sơ kì ở Đông Nam Á hình thành dựa trên nền kinh tế nào?','nông nghiệp trồng lúa nước','công nghiệp','chăn nuôi du mục','buôn bán vũ khí'],
   [2,'Đông Nam Á có vị trí như thế nào trên các tuyến giao thương?','là nơi giao thương quan trọng giữa các nền văn minh','biệt lập hoàn toàn','không có giao thương','ở Bắc Cực'],
   [3,'Nêu một điều kiện thuận lợi cho sự hình thành các quốc gia cổ ở Đông Nam Á.','Khí hậu nhiệt đới, đất đai màu mỡ, nhiều sông ngòi thuận lợi trồng lúa nước (HS tự nêu).']]},
  {cd:'Bài 13 (Lịch sử): Giao lưu văn hóa ở Đông Nam Á từ đầu Công nguyên đến thế kỉ X',q:[
   [1,'Đông Nam Á chịu ảnh hưởng của những nền văn hóa lớn nào?','Ấn Độ và Trung Quốc','châu Mỹ','châu Phi','Bắc Cực'],
   [2,'Tôn giáo nào được truyền bá vào Đông Nam Á trong thời kì này?','Phật giáo, Hindu giáo','không tôn giáo','chỉ đạo Hồi hiện đại','Thiên Chúa giáo'],
   [3,'Nêu biểu hiện của sự giao lưu văn hóa ở Đông Nam Á.','Tiếp thu chữ viết, tôn giáo, kiến trúc đền tháp từ Ấn Độ, Trung Quốc rồi sáng tạo riêng (HS tự nêu).']]},
  {cd:'Bài 14 (Lịch sử): Nhà nước Văn Lang, Âu Lạc',q:[
   [1,'Nhà nước đầu tiên của người Việt là nhà nước nào?','Văn Lang','Âu Lạc','Đại Việt','Đại Cồ Việt'],
   [2,'Đứng đầu nhà nước Văn Lang là ai?','Vua Hùng','An Dương Vương','Ngô Quyền','Lý Công Uẩn'],
   [3,'Ai là người lập ra nước Âu Lạc và xây thành Cổ Loa?','An Dương Vương (Thục Phán) (HS tự nêu).']]},
  {cd:'Bài 16 (Lịch sử): Các cuộc khởi nghĩa tiêu biểu giành độc lập trước thế kỉ X',q:[
   [1,'Cuộc khởi nghĩa Hai Bà Trưng nổ ra vào năm nào?','năm 40','năm 938','năm 1010','năm 1945'],
   [2,'Hai Bà Trưng lãnh đạo nhân dân khởi nghĩa chống ách đô hộ của triều đại nào?','nhà Hán (phương Bắc)','thực dân Pháp','đế quốc Mỹ','quân Mông - Nguyên'],
   [3,'Kể tên một vài cuộc khởi nghĩa tiêu biểu thời Bắc thuộc.','VD: khởi nghĩa Hai Bà Trưng, Bà Triệu, Lý Bí, Mai Thúc Loan, Phùng Hưng (HS tự nêu).']]},
  {cd:'Bài 17 (Lịch sử): Cuộc đấu tranh bảo tồn và phát triển văn hóa dân tộc của người Việt',q:[
   [1,'Trong thời Bắc thuộc, nhân dân ta có thái độ như thế nào với văn hóa dân tộc?','giữ gìn tiếng nói, phong tục, tập quán của dân tộc','từ bỏ hoàn toàn','không quan tâm','chỉ theo văn hóa ngoại lai'],
   [2,'Phong tục nào của người Việt được giữ gìn trong thời Bắc thuộc?','ăn trầu, làm bánh chưng, thờ cúng tổ tiên','không có phong tục nào','chỉ theo phong tục phương Bắc','bỏ hết tập quán'],
   [3,'Vì sao nhân dân ta giữ được bản sắc văn hóa dân tộc qua hơn 1000 năm Bắc thuộc?','Nhờ ý thức giữ gìn tiếng nói, phong tục, tập quán và tinh thần đoàn kết dân tộc (HS tự nêu).']]},
  {cd:'Bài 18 (Lịch sử): Bước ngoặt lịch sử đầu thế kỉ X',q:[
   [1,'Chiến thắng Bạch Đằng năm 938 do ai lãnh đạo?','Ngô Quyền','Hai Bà Trưng','Lê Lợi','Quang Trung'],
   [2,'Chiến thắng Bạch Đằng năm 938 có ý nghĩa gì?','chấm dứt hơn 1000 năm Bắc thuộc, mở ra thời kì độc lập','mất nước','không có ý nghĩa','bắt đầu Bắc thuộc'],
   [3,'Nêu ý nghĩa của chiến thắng Bạch Đằng năm 938.','Chấm dứt hơn một nghìn năm Bắc thuộc, mở ra thời kì độc lập lâu dài cho dân tộc (HS tự nêu).']]},
  {cd:'Bài 19 (Lịch sử): Vương quốc Chăm-pa từ thế kỉ II đến thế kỉ X',q:[
   [1,'Vương quốc Chăm-pa hình thành ở khu vực nào của Việt Nam ngày nay?','ven biển miền Trung','đồng bằng Bắc Bộ','Tây Nguyên','Nam Bộ'],
   [2,'Công trình kiến trúc tiêu biểu của người Chăm là gì?','các đền tháp Chăm (tháp Chàm)','Kim tự tháp','Vạn Lí Trường Thành','chùa Một Cột'],
   [3,'Nêu một thành tựu văn hóa của vương quốc Chăm-pa.','VD: kiến trúc đền tháp (Thánh địa Mỹ Sơn), chữ viết, nghệ thuật điêu khắc (HS tự nêu).']]},
  {cd:'Bài 20 (Lịch sử): Vương quốc Phù Nam',q:[
   [1,'Vương quốc Phù Nam hình thành ở khu vực nào?','vùng Nam Bộ Việt Nam ngày nay','Bắc Bộ','miền Trung','Tây Bắc'],
   [2,'Kinh tế của Phù Nam phát triển mạnh nhờ hoạt động nào?','thương mại đường biển','săn bắt','du mục','khai thác than'],
   [3,'Nêu một đặc điểm của vương quốc Phù Nam.','Là quốc gia cổ ở Nam Bộ, phát triển thương mại biển, văn hóa chịu ảnh hưởng Ấn Độ (HS tự nêu).']]},
  {cd:'Bài 1 (Địa lí): Hệ thống kinh, vĩ tuyến',q:[
   [1,'Kinh tuyến gốc (0 độ) đi qua đài thiên văn nào?','Greenwich (ở nước Anh)','Hà Nội','Paris','New York'],
   [2,'Vĩ tuyến gốc (0 độ) là đường nào?','đường Xích đạo','chí tuyến Bắc','vòng cực','kinh tuyến gốc'],
   [3,'Nêu công dụng của hệ thống kinh, vĩ tuyến.','Giúp xác định vị trí (tọa độ địa lí) của một điểm bất kì trên Trái Đất (HS tự nêu).']]},
  {cd:'Bài 2 (Địa lí): Bản đồ',q:[
   [1,'Bản đồ là gì?','hình vẽ thu nhỏ một phần hay toàn bộ bề mặt Trái Đất lên mặt phẳng','một bức ảnh chụp','một quả địa cầu','một đoạn phim'],
   [2,'Bản đồ dùng để làm gì?','thể hiện vị trí, đặc điểm các đối tượng địa lí','nấu ăn','đo thời gian','nghe nhạc'],
   [3,'Nêu một số yếu tố cơ bản của bản đồ.','Tỉ lệ, kí hiệu, bảng chú giải, phương hướng (HS tự nêu).']]},
  {cd:'Bài 3 (Địa lí): Tỉ lệ bản đồ',q:[
   [1,'Tỉ lệ bản đồ cho biết điều gì?','mức độ thu nhỏ của bản đồ so với thực tế','màu của bản đồ','tên bản đồ','ngày vẽ'],
   [2,'Tỉ lệ 1 : 100 000 nghĩa là 1 cm trên bản đồ bằng bao nhiêu ngoài thực tế?','100 000 cm (tức 1 km)','100 cm','1 cm','10 cm'],
   [3,'Nêu ý nghĩa của tỉ lệ bản đồ.','Cho biết khoảng cách trên bản đồ đã thu nhỏ bao nhiêu lần so với thực tế (HS tự nêu).']]},
  {cd:'Bài 4 (Địa lí): Kí hiệu và bảng chú giải bản đồ',q:[
   [1,'Bảng chú giải bản đồ dùng để làm gì?','giải thích ý nghĩa các kí hiệu trên bản đồ','trang trí','ghi tên tác giả','đo nhiệt độ'],
   [2,'Trên bản đồ, sông ngòi thường được thể hiện bằng màu gì?','màu xanh','màu đỏ','màu đen','màu vàng'],
   [3,'Vì sao cần đọc bảng chú giải khi xem bản đồ?','Để hiểu đúng ý nghĩa các kí hiệu, đọc được thông tin trên bản đồ (HS tự nêu).']]},
  {cd:'Bài 5 (Địa lí): Lược đồ trí nhớ',q:[
   [1,'Lược đồ trí nhớ là gì?','hình ảnh về không gian được ghi nhớ trong trí óc mỗi người','bản đồ chính xác tuyệt đối','ảnh vệ tinh','biểu đồ số liệu'],
   [2,'Lược đồ trí nhớ giúp ích gì?','định hướng, di chuyển và ghi nhớ đường đi quen thuộc','đo khối lượng','nấu ăn','tính tiền'],
   [3,'Nêu một ví dụ em dùng lược đồ trí nhớ trong đời sống.','VD: nhớ đường từ nhà đến trường, vị trí các phòng trong nhà (HS tự nêu).']]},
  {cd:'Bài 6 (Địa lí): Trái Đất trong hệ Mặt Trời',q:[
   [1,'Trái Đất là hành tinh thứ mấy tính từ Mặt Trời?','thứ ba','thứ nhất','thứ năm','thứ tám'],
   [2,'Trái Đất có dạng hình gì?','hình cầu (hơi dẹt ở hai cực)','hình phẳng','hình vuông','hình tam giác'],
   [3,'Nêu vị trí của Trái Đất trong hệ Mặt Trời.','Là hành tinh thứ ba tính từ Mặt Trời, có sự sống (HS tự nêu).']]},
  {cd:'Bài 7 (Địa lí): Chuyển động tự quay quanh trục của Trái Đất và hệ quả',q:[
   [1,'Trái Đất tự quay quanh trục theo hướng nào?','từ tây sang đông','từ đông sang tây','từ bắc xuống nam','không quay'],
   [2,'Hệ quả của sự tự quay quanh trục của Trái Đất là gì?','hiện tượng ngày và đêm luân phiên','các mùa','không có hệ quả','Trái Đất đứng yên'],
   [3,'Trái Đất tự quay một vòng quanh trục hết bao lâu?','Khoảng 24 giờ (một ngày đêm) (HS tự nêu).']]},
  {cd:'Bài 8 (Địa lí): Chuyển động của Trái Đất quanh Mặt Trời và hệ quả',q:[
   [1,'Trái Đất quay một vòng quanh Mặt Trời hết khoảng bao lâu?','khoảng 365 ngày (một năm)','24 giờ','một tháng','100 năm'],
   [2,'Hệ quả của chuyển động quanh Mặt Trời là gì?','sinh ra các mùa trong năm','chỉ sinh ngày đêm','không có gì','Trái Đất nóng lên mãi'],
   [3,'Vì sao có các mùa trong năm?','Do Trái Đất chuyển động quanh Mặt Trời với trục nghiêng không đổi nên lượng ánh sáng nhận được thay đổi theo thời gian (HS tự nêu).']]},
  {cd:'Bài 9 (Địa lí): Xác định phương hướng ngoài thực địa',q:[
   [1,'Dụng cụ nào giúp xác định phương hướng?','la bàn','cái cân','thước kẻ','nhiệt kế'],
   [2,'Ban ngày có thể dựa vào đâu để xác định hướng?','vị trí Mặt Trời (mọc ở đông, lặn ở tây)','màu của cây','tiếng chim','gió'],
   [3,'Nêu cách xác định phương hướng khi không có la bàn.','Dựa vào Mặt Trời mọc ở hướng đông, lặn ở hướng tây; ban đêm dựa vào sao (HS tự nêu).']]},
  {cd:'Bài 10 (Địa lí): Cấu tạo của Trái Đất',q:[
   [1,'Trái Đất gồm mấy lớp chính?','ba lớp: vỏ, man-ti và nhân','một lớp','hai lớp','năm lớp'],
   [2,'Lớp ngoài cùng của Trái Đất là lớp nào?','lớp vỏ Trái Đất','nhân','man-ti','khí quyển'],
   [3,'Nêu đặc điểm lớp vỏ Trái Đất.','Là lớp ngoài cùng, mỏng nhất nhưng rất quan trọng, là nơi tồn tại của các thành phần tự nhiên và con người (HS tự nêu).']]},
  {cd:'Bài 11 (Địa lí): Quá trình nội sinh và quá trình ngoại sinh',q:[
   [1,'Quá trình nội sinh có nguồn gốc từ đâu?','từ bên trong Trái Đất','từ Mặt Trời','từ gió','từ con người'],
   [2,'Quá trình ngoại sinh thường có xu hướng làm gì với địa hình?','san bằng, hạ thấp địa hình','nâng cao mãi','không tác động','làm Trái Đất to ra'],
   [3,'Phân biệt quá trình nội sinh và ngoại sinh.','Nội sinh từ bên trong (tạo núi, động đất), nâng cao địa hình; ngoại sinh từ bên ngoài (gió, nước), bào mòn, san bằng địa hình (HS tự nêu).']]},
  {cd:'Bài 12 (Địa lí): Núi lửa và động đất',q:[
   [1,'Núi lửa và động đất là kết quả của quá trình nào?','nội sinh (hoạt động bên trong Trái Đất)','ngoại sinh','do con người','do gió'],
   [2,'Khi có động đất mạnh, con người nên làm gì?','tìm nơi trú ẩn an toàn, tránh vật dễ đổ','đứng dưới đồ nặng','không làm gì','chạy lung tung'],
   [3,'Nêu tác hại của núi lửa và động đất.','Gây thiệt hại về người và của, phá hủy nhà cửa, công trình (HS tự nêu).']]},
  {cd:'Bài 13 (Địa lí): Các dạng địa hình chính trên Trái Đất',q:[
   [1,'Các dạng địa hình chính trên Trái Đất gồm những dạng nào?','núi, đồi, cao nguyên, đồng bằng','chỉ núi','chỉ đồng bằng','chỉ sông'],
   [2,'Dạng địa hình nào thấp, bằng phẳng, thuận lợi trồng trọt và cư trú?','đồng bằng','núi cao','cao nguyên dốc','vực sâu'],
   [3,'Nêu đặc điểm của địa hình núi.','Nhô cao, độ cao lớn, sườn dốc, đỉnh nhọn hoặc tròn (HS tự nêu).']]},
  {cd:'Bài 14 (Địa lí): Thực hành: Đọc lược đồ địa hình tỉ lệ lớn và lát cắt địa hình',q:[
   [1,'Trên lược đồ địa hình, các đường đồng mức nối những điểm có đặc điểm gì?','cùng độ cao','cùng nhiệt độ','cùng dân số','cùng tên'],
   [2,'Các đường đồng mức càng sát nhau thì sườn địa hình như thế nào?','càng dốc','càng thoải','bằng phẳng','không xác định'],
   [3,'Nêu ý nghĩa của việc đọc lược đồ địa hình.','Giúp hình dung độ cao, độ dốc và hình dạng bề mặt địa hình một khu vực (HS tự nêu).']]},
  {cd:'Bài 15 (Địa lí): Lớp vỏ khí của Trái Đất',q:[
   [1,'Trong lớp vỏ khí, chất khí nào chiếm tỉ lệ lớn nhất?','khí nitrogen','khí oxygen','khí carbon dioxide','hơi nước'],
   [2,'Lớp vỏ khí có vai trò gì đối với sự sống?','bảo vệ Trái Đất và cung cấp không khí cho sinh vật','không có vai trò','gây hại','làm Trái Đất lạnh đi'],
   [3,'Nêu vai trò của lớp vỏ khí đối với Trái Đất.','Cung cấp khí cho sự sống, điều hòa nhiệt độ và bảo vệ Trái Đất khỏi tia có hại (HS tự nêu).']]},
  {cd:'Bài 16 (Địa lí): Nhiệt độ không khí',q:[
   [1,'Dụng cụ nào dùng để đo nhiệt độ không khí?','nhiệt kế','khí áp kế','ẩm kế','la bàn'],
   [2,'Càng lên cao, nhiệt độ không khí thay đổi như thế nào?','càng giảm','càng tăng','không đổi','tăng rồi dừng'],
   [3,'Nêu các nhân tố ảnh hưởng đến nhiệt độ không khí.','Vĩ độ, độ cao, gần hay xa biển (HS tự nêu).']]},
  {cd:'Bài 17 (Địa lí): Thời tiết và khí hậu',q:[
   [1,'Thời tiết là gì?','trạng thái của khí quyển tại một nơi trong thời gian ngắn','trạng thái lâu dài nhiều năm','tên một mùa','một loại gió'],
   [2,'Khí hậu là gì?','sự lặp đi lặp lại của tình hình thời tiết trong nhiều năm','thời tiết trong một ngày','một cơn mưa','một trận bão'],
   [3,'Phân biệt thời tiết và khí hậu.','Thời tiết diễn ra trong thời gian ngắn, hay thay đổi; khí hậu là tình hình thời tiết lặp lại nhiều năm, có tính ổn định (HS tự nêu).']]},
  {cd:'Bài 18 (Địa lí): Thực hành: Phân tích biểu đồ nhiệt độ, lượng mưa',q:[
   [1,'Trên biểu đồ khí hậu, nhiệt độ thường được thể hiện bằng yếu tố nào?','đường biểu diễn','hình tròn','không thể hiện','bảng chữ'],
   [2,'Lượng mưa trên biểu đồ khí hậu thường được thể hiện bằng gì?','các cột','đường cong','hình quạt','chữ số đơn thuần'],
   [3,'Nêu cách đọc một biểu đồ nhiệt độ, lượng mưa.','Xem trục nhiệt độ và trục lượng mưa, nhận xét tháng nóng/lạnh nhất, mưa nhiều/ít nhất (HS tự nêu).']]},
  {cd:'Bài 19 (Địa lí): Thủy quyển và vòng tuần hoàn lớn của nước',q:[
   [1,'Thủy quyển là gì?','toàn bộ nước trên Trái Đất (biển, sông, hồ, băng, nước ngầm, hơi nước)','chỉ nước biển','chỉ nước sông','không khí'],
   [2,'Nước trên Trái Đất tồn tại ở những thể nào?','rắn, lỏng, khí','chỉ lỏng','chỉ rắn','chỉ khí'],
   [3,'Nêu các giai đoạn chính của vòng tuần hoàn nước.','Nước bốc hơi, ngưng tụ thành mây, mưa rơi xuống, chảy ra sông biển rồi lại bốc hơi (HS tự nêu).']]},
  {cd:'Bài 20 (Địa lí): Sông và hồ',q:[
   [1,'Sông là gì?','dòng chảy thường xuyên tương đối ổn định trên bề mặt lục địa','vùng nước đọng','biển nhỏ','ao tù'],
   [2,'Lưu vực sông là gì?','vùng đất cung cấp nước thường xuyên cho sông','vùng biển','đỉnh núi','sa mạc'],
   [3,'Nêu vai trò của sông, hồ đối với đời sống.','Cung cấp nước, phù sa, thủy sản, giao thông, thủy điện và điều hòa khí hậu (HS tự nêu).']]},
  {cd:'Bài 21 (Địa lí): Biển và đại dương',q:[
   [1,'Nước biển và đại dương có vị gì?','vị mặn (do chứa muối)','vị ngọt','vị chua','không vị'],
   [2,'Đại dương bao phủ khoảng bao nhiêu phần bề mặt Trái Đất?','phần lớn (khoảng ba phần tư)','một phần mười','rất ít','không đáng kể'],
   [3,'Nêu vai trò của biển và đại dương.','Điều hòa khí hậu, cung cấp hải sản, muối, khoáng sản, giao thông và du lịch (HS tự nêu).']]},
  {cd:'Bài 22 (Địa lí): Lớp đất trên Trái Đất',q:[
   [1,'Thành phần quan trọng của đất giúp cây trồng phát triển là gì?','chất mùn (chất hữu cơ)','chỉ cát','chỉ đá','chỉ nước'],
   [2,'Đất được hình thành từ đâu?','từ đá mẹ bị phong hóa, cùng tác động của sinh vật và khí hậu','từ nhựa','từ kim loại','tự nhiên có sẵn ngay'],
   [3,'Nêu vai trò của đất đối với sinh vật và con người.','Là nơi sinh sống của sinh vật, cung cấp dinh dưỡng cho cây trồng, phục vụ sản xuất (HS tự nêu).']]},
  {cd:'Bài 23 (Địa lí): Sự sống trên Trái Đất',q:[
   [1,'Sinh vật trên Trái Đất phân bố như thế nào?','rộng khắp nhưng không đều, tùy điều kiện tự nhiên','đồng đều khắp nơi','chỉ ở Bắc Cực','chỉ dưới biển sâu'],
   [2,'Nơi nào thường có sinh vật phong phú, đa dạng?','vùng khí hậu nóng ẩm (nhiệt đới)','sa mạc khô hạn','vùng cực lạnh giá','đỉnh núi cao'],
   [3,'Nêu các nhân tố ảnh hưởng đến sự phân bố sinh vật.','Khí hậu, nước, đất, địa hình và con người (HS tự nêu).']]},
  {cd:'Bài 24 (Địa lí): Rừng nhiệt đới',q:[
   [1,'Rừng nhiệt đới phân bố chủ yếu ở khu vực nào?','vùng khí hậu nóng ẩm quanh Xích đạo','vùng cực','sa mạc','vùng núi cao lạnh'],
   [2,'Đặc điểm nổi bật của rừng nhiệt đới là gì?','đa dạng sinh học cao, nhiều tầng tán','ít loài','chỉ có cỏ','khô cằn'],
   [3,'Nêu vai trò của rừng nhiệt đới.','Điều hòa khí hậu, cung cấp oxygen, giữ đất nước và bảo tồn đa dạng sinh học (HS tự nêu).']]},
  {cd:'Bài 25 (Địa lí): Sự phân bố các đới thiên nhiên trên Trái Đất',q:[
   [1,'Trên Trái Đất có mấy đới khí hậu chính theo vĩ độ?','ba đới: nóng, ôn hòa, lạnh','một đới','hai đới','năm đới'],
   [2,'Đới nóng (nhiệt đới) nằm ở khu vực nào?','quanh Xích đạo (giữa hai chí tuyến)','ở hai cực','chỉ ở châu Âu','chỉ ở núi cao'],
   [3,'Nêu đặc điểm của đới nóng.','Quanh năm nóng, mưa nhiều, sinh vật phong phú (HS tự nêu).']]},
  {cd:'Bài 26 (Địa lí): Thực hành: Tìm hiểu môi trường tự nhiên địa phương',q:[
   [1,'Khi tìm hiểu môi trường tự nhiên địa phương, ta quan sát những yếu tố nào?','địa hình, khí hậu, sông ngòi, sinh vật','chỉ tên đường','chỉ số nhà','chỉ giá cả'],
   [2,'Thái độ đúng với môi trường tự nhiên địa phương là gì?','bảo vệ, giữ gìn và không gây ô nhiễm','xả rác','phá hoại','thờ ơ'],
   [3,'Nêu một việc em có thể làm để bảo vệ môi trường tự nhiên địa phương.','VD: trồng cây, dọn vệ sinh, không xả rác, tiết kiệm nước (HS tự nêu).']]},
  {cd:'Bài 27 (Địa lí): Dân số và sự phân bố dân cư trên thế giới',q:[
   [1,'Dân cư trên thế giới phân bố như thế nào?','không đều giữa các khu vực','hoàn toàn đồng đều','chỉ ở sa mạc','chỉ ở vùng cực'],
   [2,'Nơi nào thường tập trung đông dân cư?','vùng đồng bằng, ven biển, khí hậu thuận lợi','sa mạc','vùng cực','núi cao hiểm trở'],
   [3,'Nêu các nhân tố ảnh hưởng đến sự phân bố dân cư.','Điều kiện tự nhiên (địa hình, khí hậu, nước) và điều kiện kinh tế - xã hội (HS tự nêu).']]},
  {cd:'Bài 28 (Địa lí): Mối quan hệ giữa con người và thiên nhiên',q:[
   [1,'Con người và thiên nhiên có mối quan hệ như thế nào?','tác động qua lại lẫn nhau','không liên quan','tách rời hoàn toàn','thiên nhiên không ảnh hưởng con người'],
   [2,'Việc khai thác thiên nhiên quá mức gây ra hậu quả gì?','cạn kiệt tài nguyên, ô nhiễm, thiên tai','làm thiên nhiên tốt hơn','không ảnh hưởng gì','tăng tài nguyên'],
   [3,'Nêu biện pháp để con người và thiên nhiên cùng phát triển bền vững.','Khai thác hợp lí, bảo vệ môi trường, trồng rừng, sử dụng tiết kiệm tài nguyên (HS tự nêu).']]},
  {cd:'Bài 30 (Địa lí): Thực hành: Tìm hiểu mối quan hệ giữa con người và thiên nhiên',q:[
   [1,'Hoạt động nào của con người có tác động tích cực đến thiên nhiên?','trồng rừng, bảo vệ môi trường','chặt phá rừng','xả rác','săn bắt thú quý'],
   [2,'Để giảm tác động xấu đến thiên nhiên, con người cần làm gì?','sử dụng tài nguyên hợp lí, bảo vệ môi trường','khai thác cạn kiệt','gây ô nhiễm','phá rừng'],
   [3,'Nêu một ví dụ về tác động của con người đến thiên nhiên ở địa phương em.','VD: trồng cây gây rừng (tích cực); xả rác, đốt rơm rạ gây ô nhiễm (tiêu cực) (HS tự nêu).']]}
 );
 SD[7].push(
  {cd:'Bài 1 (Lịch sử): Quá trình hình thành và phát triển của chế độ phong kiến Tây Âu',q:[
   [1,'Chế độ phong kiến Tây Âu hình thành dựa trên hai giai cấp cơ bản nào?','lãnh chúa và nông nô','vua và quan','thợ thủ công','thương nhân'],
   [2,'Lãnh địa phong kiến là gì?','vùng đất rộng lớn của lãnh chúa','một thành phố','một nhà máy','một ngôi chùa'],
   [3,'Nêu đặc điểm cơ bản của chế độ phong kiến Tây Âu.','Xã hội gồm lãnh chúa và nông nô; kinh tế lãnh địa khép kín, nông nghiệp là chủ yếu (HS tự nêu).']]},
  {cd:'Bài 2 (Lịch sử): Các cuộc phát kiến địa lí và sự hình thành quan hệ sản xuất tư bản chủ nghĩa',q:[
   [1,'Các cuộc phát kiến địa lí thế kỉ XV - XVI do các nước nào đi đầu?','Bồ Đào Nha và Tây Ban Nha','Việt Nam','Trung Quốc','Ấn Độ'],
   [2,'Ai là người tìm ra châu Mỹ năm 1492?','Cri-xtốp Cô-lôm-bô (Columbus)','Ma-gien-lăng','Đi-a-xơ','Va-xcô đơ Ga-ma'],
   [3,'Nêu ý nghĩa của các cuộc phát kiến địa lí.','Mở ra những con đường mới, vùng đất mới, thúc đẩy giao thương và hiểu biết thế giới (HS tự nêu).']]},
  {cd:'Bài 3 (Lịch sử): Phong trào văn hóa Phục hưng và cải cách tôn giáo',q:[
   [1,'Phong trào Văn hóa Phục hưng khởi đầu ở nước nào?','I-ta-li-a (Ý)','Việt Nam','Trung Quốc','Ai Cập'],
   [2,'Phong trào Văn hóa Phục hưng đề cao điều gì?','giá trị con người và khoa học','chiến tranh','mê tín','sự lạc hậu'],
   [3,'Nêu ý nghĩa của phong trào Văn hóa Phục hưng.','Đề cao con người, khoa học; mở đường cho sự phát triển văn hóa châu Âu (HS tự nêu).']]},
  {cd:'Bài 4 (Lịch sử): Trung Quốc từ thế kỉ III TCN đến giữa thế kỉ XIX',q:[
   [1,'Trung Quốc thời phong kiến phát triển rực rỡ dưới các triều đại nào?','Đường, Tống, Minh, Thanh','không có triều đại','chỉ nhà Hán','không phát triển'],
   [2,'Phát minh nào sau đây là của Trung Quốc thời phong kiến?','giấy, la bàn, thuốc súng, kĩ thuật in','bóng đèn điện','máy hơi nước','điện thoại'],
   [3,'Kể một thành tựu văn hóa của Trung Quốc thời phong kiến.','VD: Vạn Lí Trường Thành, giấy, la bàn, thuốc súng, thơ Đường (HS tự nêu).']]},
  {cd:'Bài 5 (Lịch sử): Ấn Độ từ thế kỉ IV đến giữa thế kỉ XIX',q:[
   [1,'Vương triều nào đánh dấu thời kì thịnh vượng của Ấn Độ (thế kỉ IV - VI)?','vương triều Gúp-ta','không có','vương triều Đường','vương triều Lý'],
   [2,'Tôn giáo lớn nào có nguồn gốc từ Ấn Độ?','Phật giáo, Hindu giáo','Thiên Chúa giáo','không có','đạo Nho'],
   [3,'Nêu một thành tựu văn hóa của Ấn Độ thời phong kiến.','VD: kiến trúc đền tháp, văn học, chữ viết, tôn giáo (HS tự nêu).']]},
  {cd:'Bài 6 (Lịch sử): Các vương quốc phong kiến Đông Nam Á từ nửa sau thế kỉ X',q:[
   [1,'Từ nửa sau thế kỉ X, ở Đông Nam Á hình thành và phát triển các quốc gia nào?','các quốc gia phong kiến dân tộc','các đế quốc châu Âu','không có quốc gia','chỉ bộ lạc'],
   [2,'Kinh tế chủ yếu của các vương quốc phong kiến Đông Nam Á là gì?','nông nghiệp trồng lúa nước','công nghiệp nặng','du mục','khai khoáng'],
   [3,'Nêu một đặc điểm của các vương quốc phong kiến Đông Nam Á.','Phát triển nông nghiệp lúa nước, giao thương, văn hóa đa dạng chịu ảnh hưởng Ấn Độ, Trung Quốc (HS tự nêu).']]},
  {cd:'Bài 7 (Lịch sử): Vương quốc Lào',q:[
   [1,'Vương quốc Lan Xang là tiền thân của quốc gia nào ngày nay?','Lào','Cam-pu-chia','Thái Lan','Việt Nam'],
   [2,'Tôn giáo phổ biến ở vương quốc Lào là gì?','Phật giáo','Hồi giáo','Thiên Chúa giáo','không có'],
   [3,'Nêu một nét văn hóa của vương quốc Lào.','VD: Phật giáo phát triển, kiến trúc chùa tháp, lễ hội truyền thống (HS tự nêu).']]},
  {cd:'Bài 8 (Lịch sử): Vương quốc Cam-pu-chia',q:[
   [1,'Thời kì phát triển rực rỡ của Cam-pu-chia là thời kì nào?','thời kì Ăng-co','thời hiện đại','thời nguyên thủy','không có'],
   [2,'Công trình kiến trúc nổi tiếng của Cam-pu-chia là gì?','đền Ăng-co Vát','Kim tự tháp','Vạn Lí Trường Thành','Tháp Eiffel'],
   [3,'Nêu một thành tựu của vương quốc Cam-pu-chia thời Ăng-co.','Kiến trúc đền Ăng-co Vát, Ăng-co Thom; phát triển nông nghiệp và văn hóa (HS tự nêu).']]},
  {cd:'Bài 9 (Lịch sử): Đất nước buổi đầu độc lập (939 - 967)',q:[
   [1,'Sau chiến thắng Bạch Đằng, ai xưng vương, mở đầu thời kì độc lập?','Ngô Quyền','Đinh Bộ Lĩnh','Lê Hoàn','Lý Công Uẩn'],
   [2,'"Loạn 12 sứ quân" diễn ra trong hoàn cảnh nào?','đất nước bị chia cắt, các thế lực phong kiến nổi dậy','đất nước thống nhất','có giặc ngoại xâm lớn','thời bình thịnh vượng'],
   [3,'Ai là người dẹp "loạn 12 sứ quân", thống nhất đất nước?','Đinh Bộ Lĩnh (HS tự nêu).']]},
  {cd:'Bài 10 (Lịch sử): Đại Cồ Việt thời Đinh và Tiền Lê (968 - 1009)',q:[
   [1,'Đinh Bộ Lĩnh lên ngôi, đặt tên nước là gì?','Đại Cồ Việt','Văn Lang','Đại Việt','Âu Lạc'],
   [2,'Ai lãnh đạo cuộc kháng chiến chống Tống năm 981?','Lê Hoàn (Lê Đại Hành)','Ngô Quyền','Lý Thường Kiệt','Trần Hưng Đạo'],
   [3,'Nêu ý nghĩa việc Đinh Bộ Lĩnh đặt tên nước là Đại Cồ Việt và xưng Hoàng đế.','Khẳng định nền độc lập, tự chủ và vị thế ngang hàng của nước ta (HS tự nêu).']]},
  {cd:'Bài 11 (Lịch sử): Nhà Lý xây dựng và phát triển đất nước (1009 - 1225)',q:[
   [1,'Ai lập ra nhà Lý?','Lý Công Uẩn (Lý Thái Tổ)','Đinh Bộ Lĩnh','Ngô Quyền','Trần Cảnh'],
   [2,'Năm 1010, Lý Công Uẩn dời đô từ Hoa Lư về đâu?','Thăng Long (Hà Nội ngày nay)','Cổ Loa','Phú Xuân','Gia Định'],
   [3,'Nêu ý nghĩa của việc dời đô về Thăng Long.','Thăng Long ở trung tâm, đất rộng, thuận lợi phát triển lâu dài về kinh tế, chính trị (HS tự nêu).']]},
  {cd:'Bài 12 (Lịch sử): Cuộc kháng chiến chống quân xâm lược Tống (1075 - 1077)',q:[
   [1,'Ai là người lãnh đạo cuộc kháng chiến chống Tống (1075 - 1077)?','Lý Thường Kiệt','Trần Hưng Đạo','Lê Lợi','Quang Trung'],
   [2,'Bài thơ "Nam quốc sơn hà" (Sông núi nước Nam) gắn với cuộc kháng chiến nào?','chống Tống thời Lý','chống Mông - Nguyên','chống quân Thanh','chống Pháp'],
   [3,'Nêu nét độc đáo trong cách đánh giặc của Lý Thường Kiệt.','Chủ động tiến công trước để tự vệ và xây phòng tuyến sông Như Nguyệt để chặn giặc (HS tự nêu).']]},
  {cd:'Bài 13 (Lịch sử): Đại Việt thời Trần (1226 - 1400)',q:[
   [1,'Nhà Trần được thành lập vào năm nào?','năm 1226','năm 938','năm 1010','năm 1428'],
   [2,'Thời Trần, chữ viết nào của dân tộc được coi trọng và sử dụng?','chữ Nôm','chữ La-tinh','chữ Phạn','không có'],
   [3,'Nêu một thành tựu của Đại Việt thời Trần.','VD: ba lần đánh thắng Mông - Nguyên, phát triển kinh tế, văn hóa, chữ Nôm (HS tự nêu).']]},
  {cd:'Bài 14 (Lịch sử): Ba lần kháng chiến chống quân xâm lược Mông - Nguyên',q:[
   [1,'Ai là vị tướng tài lãnh đạo quân dân nhà Trần chống Mông - Nguyên?','Trần Hưng Đạo (Trần Quốc Tuấn)','Lý Thường Kiệt','Ngô Quyền','Lê Lợi'],
   [2,'Chiến thắng Bạch Đằng năm 1288 đánh tan đạo quân xâm lược nào?','quân Nguyên','quân Tống','quân Thanh','quân Minh'],
   [3,'Nêu nguyên nhân thắng lợi của ba lần kháng chiến chống Mông - Nguyên.','Tinh thần đoàn kết, yêu nước và sự lãnh đạo tài giỏi của nhà Trần, Trần Hưng Đạo (HS tự nêu).']]},
  {cd:'Bài 15 (Lịch sử): Nước Đại Ngu thời Hồ (1400 - 1407)',q:[
   [1,'Ai lập ra nhà Hồ?','Hồ Quý Ly','Lê Lợi','Trần Hưng Đạo','Nguyễn Huệ'],
   [2,'Nhà Hồ đổi tên nước thành gì?','Đại Ngu','Đại Việt','Đại Cồ Việt','Văn Lang'],
   [3,'Nêu một cải cách của Hồ Quý Ly.','VD: phát hành tiền giấy, hạn chế ruộng đất của quý tộc, cải cách giáo dục (HS tự nêu).']]},
  {cd:'Bài 16 (Lịch sử): Khởi nghĩa Lam Sơn (1418 - 1427)',q:[
   [1,'Ai là người lãnh đạo khởi nghĩa Lam Sơn?','Lê Lợi','Nguyễn Huệ','Trần Hưng Đạo','Ngô Quyền'],
   [2,'Khởi nghĩa Lam Sơn chống lại ách đô hộ của triều đại nào?','nhà Minh','nhà Tống','nhà Thanh','thực dân Pháp'],
   [3,'Nêu ý nghĩa của khởi nghĩa Lam Sơn.','Đánh đuổi quân Minh, giành lại độc lập, lập ra nhà Lê (HS tự nêu).']]},
  {cd:'Bài 17 (Lịch sử): Đại Việt thời Lê sơ (1428 - 1527)',q:[
   [1,'Ai lập ra nhà Lê sơ?','Lê Lợi (Lê Thái Tổ)','Lý Công Uẩn','Hồ Quý Ly','Nguyễn Huệ'],
   [2,'Bộ luật nổi tiếng thời Lê sơ là gì?','Quốc triều hình luật (luật Hồng Đức)','luật Gia Long','luật nhà Trần','không có'],
   [3,'Nêu một thành tựu của Đại Việt thời Lê sơ.','VD: luật Hồng Đức, phát triển giáo dục khoa cử, kinh tế, lãnh thổ mở rộng (HS tự nêu).']]},
  {cd:'Bài 18 (Lịch sử): Vương quốc Chăm-pa và vùng đất Nam Bộ từ đầu thế kỉ X đến đầu thế kỉ XVI',q:[
   [1,'Kiến trúc tiêu biểu của người Chăm là gì?','đền tháp Chăm','nhà sàn','lăng tẩm Huế','đình làng Bắc Bộ'],
   [2,'Vùng đất Nam Bộ thời kì này chịu ảnh hưởng của nền văn hóa nào?','văn hóa Ấn Độ','châu Âu','Bắc Cực','châu Mỹ'],
   [3,'Nêu một nét văn hóa của vương quốc Chăm-pa.','VD: đền tháp (Mỹ Sơn), điêu khắc, chữ viết, tín ngưỡng (HS tự nêu).']]},
  {cd:'Bài 1 (Địa lí): Vị trí địa lí, đặc điểm tự nhiên Châu Âu',q:[
   [1,'Châu Âu nằm chủ yếu trong đới khí hậu nào?','đới ôn hòa','đới nóng','đới lạnh hoàn toàn','xích đạo'],
   [2,'Châu Âu có đường bờ biển như thế nào?','bị cắt xẻ mạnh, nhiều biển, vịnh','thẳng, ít vịnh','không giáp biển','toàn sa mạc'],
   [3,'Nêu một đặc điểm tự nhiên của châu Âu.','Phần lớn nằm trong đới ôn hòa, địa hình đồng bằng và núi già, nhiều sông (HS tự nêu).']]},
  {cd:'Bài 2 (Địa lí): Đặc điểm dân cư, xã hội Châu Âu',q:[
   [1,'Dân cư châu Âu có đặc điểm nổi bật nào?','dân số già, tỉ lệ dân thành thị cao','dân số rất trẻ','chủ yếu sống ở nông thôn','dân số tăng rất nhanh'],
   [2,'Châu Âu có mức độ đô thị hóa như thế nào?','cao','rất thấp','không có đô thị','chỉ có nông thôn'],
   [3,'Nêu một đặc điểm dân cư - xã hội của châu Âu.','Dân số già, trình độ dân trí cao, mức đô thị hóa cao (HS tự nêu).']]},
  {cd:'Bài 3 (Địa lí): Khai thác, sử dụng và bảo vệ thiên nhiên ở Châu Âu',q:[
   [1,'Châu Âu chú trọng điều gì trong sử dụng thiên nhiên?','bảo vệ môi trường và phát triển bền vững','khai thác cạn kiệt','gây ô nhiễm','phá rừng bừa bãi'],
   [2,'Biện pháp nào được châu Âu áp dụng để bảo vệ môi trường?','sử dụng năng lượng tái tạo, giảm khí thải','đốt nhiều than','xả rác ra biển','chặt phá rừng'],
   [3,'Nêu một biện pháp bảo vệ môi trường ở châu Âu.','VD: dùng năng lượng sạch, trồng rừng, xử lí chất thải, giảm khí thải (HS tự nêu).']]},
  {cd:'Bài 4 (Địa lí): Liên minh Châu Âu',q:[
   [1,'Liên minh châu Âu viết tắt là gì?','EU','UN','ASEAN','WTO'],
   [2,'Liên minh châu Âu là một tổ chức mang tính chất gì?','liên kết kinh tế - chính trị khu vực','một quốc gia','một công ty','một đội thể thao'],
   [3,'Nêu một đặc điểm của Liên minh châu Âu (EU).','Là liên kết kinh tế - chính trị lớn, nhiều nước dùng chung đồng tiền ơ-rô (euro) (HS tự nêu).']]},
  {cd:'Bài 5 (Địa lí): Vị trí địa lí, đặc điểm tự nhiên Châu Á',q:[
   [1,'Châu Á có diện tích như thế nào so với các châu lục khác?','lớn nhất thế giới','nhỏ nhất','bằng châu Âu','không xác định'],
   [2,'Địa hình châu Á có đặc điểm nổi bật nào?','nhiều núi và cao nguyên đồ sộ','toàn đồng bằng','toàn sa mạc','rất bằng phẳng'],
   [3,'Nêu một đặc điểm tự nhiên của châu Á.','Diện tích lớn nhất, địa hình đa dạng, nhiều núi cao (dãy Hi-ma-lay-a), khí hậu phân hóa (HS tự nêu).']]},
  {cd:'Bài 6 (Địa lí): Đặc điểm dân cư, xã hội Châu Á',q:[
   [1,'Châu Á là châu lục có số dân như thế nào?','đông dân nhất thế giới','ít dân nhất','không có dân','bằng châu Phi'],
   [2,'Dân cư châu Á tập trung đông ở khu vực nào?','đồng bằng, ven biển','sa mạc','vùng núi cao','vùng cực'],
   [3,'Nêu một đặc điểm dân cư của châu Á.','Đông dân nhất thế giới, nhiều chủng tộc, phân bố không đều (HS tự nêu).']]},
  {cd:'Bài 7 (Địa lí): Bản đồ chính trị châu Á, các khu vực của châu Á',q:[
   [1,'Việt Nam thuộc khu vực nào của châu Á?','Đông Nam Á','Đông Á','Nam Á','Tây Nam Á'],
   [2,'Châu Á được chia thành nhiều khu vực, trong đó có khu vực nào?','Đông Á, Đông Nam Á, Nam Á, Tây Nam Á','chỉ một khu vực','không chia khu vực','chỉ Bắc Á'],
   [3,'Kể tên một vài khu vực của châu Á.','VD: Đông Á, Đông Nam Á, Nam Á, Tây Nam Á, Trung Á, Bắc Á (HS tự nêu).']]},
  {cd:'Bài 8 (Địa lí): Thực hành: Tìm hiểu về các nền kinh tế lớn và kinh tế mới nổi của châu Á',q:[
   [1,'Quốc gia nào ở châu Á có nền kinh tế lớn hàng đầu thế giới?','Trung Quốc, Nhật Bản','chỉ Lào','chỉ Cam-pu-chia','không có'],
   [2,'Nền kinh tế "mới nổi" là nền kinh tế như thế nào?','đang phát triển nhanh','suy thoái','không phát triển','đã ngừng hoạt động'],
   [3,'Kể tên một vài nền kinh tế lớn của châu Á.','VD: Trung Quốc, Nhật Bản, Hàn Quốc, Ấn Độ (HS tự nêu).']]},
  {cd:'Bài 9 (Địa lí): Vị trí địa lí, đặc điểm tự nhiên châu Phi',q:[
   [1,'Châu Phi nằm chủ yếu trong đới khí hậu nào?','đới nóng (nhiệt đới)','đới lạnh','ôn đới','hàn đới'],
   [2,'Hoang mạc lớn nhất thế giới nằm ở châu Phi là hoang mạc nào?','Xa-ha-ra (Sahara)','Gô-bi','không có','A-ta-ca-ma'],
   [3,'Nêu một đặc điểm tự nhiên của châu Phi.','Phần lớn nằm trong đới nóng, nhiều hoang mạc, có sông Nin dài (HS tự nêu).']]},
  {cd:'Bài 10 (Địa lí): Đặc điểm dân cư, xã hội châu Phi',q:[
   [1,'Dân số châu Phi có đặc điểm gì?','tăng nhanh, dân số trẻ','dân số già','không tăng','rất ít dân'],
   [2,'Châu Phi đang đối mặt với vấn đề xã hội nào?','đói nghèo, bệnh tật, xung đột ở một số nơi','thừa lương thực','dân số giảm mạnh','không có khó khăn'],
   [3,'Nêu một đặc điểm dân cư - xã hội của châu Phi.','Dân số tăng nhanh, đời sống còn nhiều khó khăn, nhiều quốc gia đang phát triển (HS tự nêu).']]},
  {cd:'Bài 11 (Địa lí): Phương thức con người khai thác, sử dụng và bảo vệ thiên nhiên ở châu Phi',q:[
   [1,'Thiên nhiên châu Phi cần được khai thác như thế nào?','hợp lí, đi đôi với bảo vệ','khai thác cạn kiệt','bỏ hoang hoàn toàn','không khai thác gì'],
   [2,'Vấn đề môi trường nổi bật ở châu Phi là gì?','hoang mạc hóa, thiếu nước','ngập lụt khắp nơi','thừa rừng','quá nhiều mưa'],
   [3,'Nêu một biện pháp bảo vệ thiên nhiên ở châu Phi.','VD: trồng rừng chống hoang mạc hóa, dùng nước tiết kiệm, bảo vệ động vật hoang dã (HS tự nêu).']]},
  {cd:'Bài 12 (Địa lí): Thực hành: Tìm hiểu khái quát Cộng hòa Nam Phi',q:[
   [1,'Cộng hòa Nam Phi nằm ở khu vực nào của châu Phi?','cực Nam châu Phi','phía Bắc','trung tâm','phía Đông Bắc'],
   [2,'Nam Phi có nền kinh tế như thế nào trong châu Phi?','phát triển hàng đầu châu Phi','kém phát triển nhất','không có kinh tế','chỉ nông nghiệp lạc hậu'],
   [3,'Nêu một đặc điểm của Cộng hòa Nam Phi.','Giàu khoáng sản, kinh tế phát triển hàng đầu châu Phi, đa dạng dân tộc (HS tự nêu).']]},
  {cd:'Bài 13 (Địa lí): Vị trí địa lí, phạm vi châu Mỹ',q:[
   [1,'Châu Mỹ nằm hoàn toàn ở bán cầu nào?','bán cầu Tây','bán cầu Đông','chỉ bán cầu Bắc','chỉ bán cầu Nam'],
   [2,'Châu Mỹ được chia thành mấy khu vực lớn?','Bắc Mỹ, Trung Mỹ và Nam Mỹ','một khu vực','năm khu vực','không chia'],
   [3,'Nêu một đặc điểm vị trí của châu Mỹ.','Nằm hoàn toàn ở bán cầu Tây, trải dài từ vùng cực Bắc đến gần cực Nam (HS tự nêu).']]},
  {cd:'Bài 14 (Địa lí): Đặc điểm tự nhiên Bắc Mỹ',q:[
   [1,'Phía tây Bắc Mỹ có dãy núi lớn nào?','dãy Coóc-đi-e (Cordillera)','dãy Hi-ma-lay-a','dãy An-pơ','dãy Trường Sơn'],
   [2,'Khí hậu Bắc Mỹ có đặc điểm gì?','phân hóa đa dạng theo chiều bắc - nam và tây - đông','chỉ nóng','chỉ lạnh','không thay đổi'],
   [3,'Nêu một đặc điểm tự nhiên của Bắc Mỹ.','Địa hình phân thành ba khu vực (núi phía tây, đồng bằng ở giữa, núi già phía đông), khí hậu đa dạng (HS tự nêu).']]},
  {cd:'Bài 15 (Địa lí): Đặc điểm dân cư, xã hội, phương thức khai thác tự nhiên Bắc Mỹ',q:[
   [1,'Dân cư Bắc Mỹ chủ yếu là người nhập cư từ đâu?','từ nhiều châu lục (chủ yếu châu Âu)','chỉ người bản địa','chỉ từ châu Á','không có dân'],
   [2,'Bắc Mỹ có trình độ đô thị hóa như thế nào?','cao','rất thấp','không có đô thị','chỉ nông thôn'],
   [3,'Nêu một đặc điểm dân cư - xã hội của Bắc Mỹ.','Thành phần dân cư đa dạng (nhập cư), mức đô thị hóa cao, kinh tế phát triển (HS tự nêu).']]},
  {cd:'Bài 16 (Địa lí): Đặc điểm tự nhiên Trung và Nam Mỹ',q:[
   [1,'Rừng nhiệt đới lớn nhất thế giới ở Nam Mỹ nằm ở lưu vực sông nào?','sông A-ma-dôn (Amazon)','sông Nin','sông Mê Công','sông Hoàng Hà'],
   [2,'Dãy núi lớn chạy dọc phía tây Nam Mỹ là dãy nào?','dãy An-đét (Andes)','dãy Coóc-đi-e','dãy Hi-ma-lay-a','dãy An-pơ'],
   [3,'Nêu một đặc điểm tự nhiên của Trung và Nam Mỹ.','Có rừng A-ma-dôn lớn nhất thế giới, dãy An-đét cao đồ sộ, khí hậu đa dạng (HS tự nêu).']]},
  {cd:'Bài 17 (Địa lí): Đặc điểm dân cư, xã hội Trung và Nam Mỹ, khai thác, sử dụng tài nguyên',q:[
   [1,'Dân cư Trung và Nam Mỹ có đặc điểm nổi bật gì?','thành phần đa dạng, nhiều người lai','thuần chủng một tộc','không có dân','chỉ người châu Á'],
   [2,'Vấn đề nổi bật trong khai thác rừng A-ma-dôn là gì?','rừng bị tàn phá, cần được bảo vệ','rừng ngày càng tăng','không ai khai thác','rừng không có giá trị'],
   [3,'Nêu một biện pháp bảo vệ rừng A-ma-dôn.','Hạn chế chặt phá, trồng lại rừng, khai thác bền vững, bảo vệ đa dạng sinh học (HS tự nêu).']]},
  {cd:'Bài 18 (Địa lí): Châu Đại Dương',q:[
   [1,'Quốc gia lớn nhất châu Đại Dương là nước nào?','Ô-xtrây-li-a (Australia)','Niu Di-lân','Việt Nam','Nhật Bản'],
   [2,'Châu Đại Dương gồm lục địa Ô-xtrây-li-a và gì?','nhiều đảo, quần đảo ở Thái Bình Dương','sa mạc châu Phi','vùng cực Bắc','châu Âu'],
   [3,'Nêu một đặc điểm của châu Đại Dương.','Gồm lục địa Ô-xtrây-li-a và nhiều đảo; phần lớn Ô-xtrây-li-a khô hạn, có nhiều động vật đặc hữu (HS tự nêu).']]},
  {cd:'Bài 19 (Địa lí): Châu Nam Cực',q:[
   [1,'Châu Nam Cực có đặc điểm khí hậu như thế nào?','lạnh giá nhất Trái Đất, bị băng bao phủ','nóng nhất','ôn hòa','nhiệt đới'],
   [2,'Vì sao châu Nam Cực hầu như không có cư dân sinh sống thường xuyên?','vì quá lạnh, khắc nghiệt','vì quá nóng','vì không có đất','vì bị cấm'],
   [3,'Nêu một đặc điểm của châu Nam Cực.','Lạnh nhất Trái Đất, bao phủ bởi băng dày, không có dân cư thường xuyên, chỉ có trạm nghiên cứu (HS tự nêu).']]}
 );
 }


 /* ---- Lịch sử và Địa lí lớp 8 và 9 ---- */
 if(typeof SD!=='undefined' && SD){
 SD[8].push(
  {cd:'Bài 1 (Lịch sử): Cách mạng tư sản Anh và chiến tranh giành độc lập của 13 thuộc địa',q:[
   [1,'Cách mạng tư sản Anh (thế kỉ XVII) lật đổ chế độ nào?','chế độ phong kiến chuyên chế','chế độ tư bản','chế độ nô lệ','chế độ xã hội chủ nghĩa'],
   [2,'Chiến tranh giành độc lập của 13 thuộc địa Anh ở Bắc Mỹ dẫn đến sự ra đời của quốc gia nào?','Hợp chúng quốc Hoa Kỳ (Mỹ)','nước Anh','nước Pháp','Ca-na-đa'],
   [3,'Nêu ý nghĩa của các cuộc cách mạng tư sản thời cận đại.','Lật đổ chế độ phong kiến, mở đường cho chủ nghĩa tư bản phát triển (HS tự nêu).']]},
  {cd:'Bài 2 (Lịch sử): Cách mạng tư sản Pháp cuối thế kỉ XVIII',q:[
   [1,'Cách mạng tư sản Pháp bùng nổ vào năm nào?','năm 1789','năm 1945','năm 1917','năm 1858'],
   [2,'Cách mạng tư sản Pháp lật đổ chế độ nào?','chế độ phong kiến chuyên chế','chế độ tư bản','chế độ cộng sản','chế độ nô lệ'],
   [3,'Nêu ý nghĩa của Cách mạng tư sản Pháp 1789.','Lật đổ chế độ phong kiến, mở đường cho chủ nghĩa tư bản phát triển, nêu cao khẩu hiệu Tự do - Bình đẳng - Bác ái (HS tự nêu).']]},
  {cd:'Bài 3 (Lịch sử): Cách mạng công nghiệp',q:[
   [1,'Cách mạng công nghiệp khởi đầu ở nước nào?','nước Anh','Việt Nam','Trung Quốc','Ấn Độ'],
   [2,'Phát minh tiêu biểu mở đầu cách mạng công nghiệp là gì?','máy hơi nước','máy tính','điện thoại','Internet'],
   [3,'Nêu ý nghĩa của cách mạng công nghiệp.','Làm thay đổi sản xuất từ thủ công sang cơ khí, tăng năng suất, thúc đẩy kinh tế phát triển mạnh (HS tự nêu).']]},
  {cd:'Bài 4 (Lịch sử): Đông Nam Á từ nửa sau thế kỉ XVI đến giữa thế kỉ XIX',q:[
   [1,'Từ thế kỉ XVI, các nước Đông Nam Á dần trở thành đối tượng xâm lược của ai?','các nước thực dân phương Tây','Trung Quốc','Nhật Bản','Ấn Độ'],
   [2,'Hậu quả của sự xâm lược thực dân đối với Đông Nam Á là gì?','trở thành thuộc địa, bị bóc lột','phát triển giàu mạnh','độc lập hoàn toàn','không ảnh hưởng gì'],
   [3,'Nêu tình hình chung của Đông Nam Á từ thế kỉ XVI đến XIX.','Lần lượt trở thành thuộc địa của các nước thực dân phương Tây, nhân dân bị áp bức, bóc lột (HS tự nêu).']]},
  {cd:'Bài 5 (Lịch sử): Cuộc xung đột Nam - Bắc triều và Trịnh - Nguyễn',q:[
   [1,'Cuộc xung đột Trịnh - Nguyễn dẫn đến hậu quả gì cho đất nước?','đất nước bị chia cắt (Đàng Trong - Đàng Ngoài)','đất nước thống nhất','phát triển mạnh','không ảnh hưởng gì'],
   [2,'Sông Gianh từng là ranh giới chia cắt đất nước giữa hai thế lực nào?','Trịnh (Đàng Ngoài) và Nguyễn (Đàng Trong)','Lý và Trần','Lê và Mạc','Pháp và Nhật'],
   [3,'Nêu hậu quả của các cuộc xung đột Nam - Bắc triều và Trịnh - Nguyễn.','Đất nước bị chia cắt kéo dài, nhân dân khổ cực, kìm hãm sự phát triển (HS tự nêu).']]},
  {cd:'Bài 6 (Lịch sử): Công cuộc khai phá vùng đất phía Nam từ thế kỉ XVI đến thế kỉ XVIII',q:[
   [1,'Công cuộc khai phá vùng đất phía Nam chủ yếu do ai tiến hành?','các chúa Nguyễn và nhân dân','thực dân Pháp','nhà Thanh','người châu Âu'],
   [2,'Kết quả của công cuộc khai phá vùng đất phía Nam là gì?','mở rộng lãnh thổ về phía Nam','mất đất','không thay đổi','thu hẹp lãnh thổ'],
   [3,'Nêu ý nghĩa của công cuộc khai phá vùng đất phía Nam.','Mở rộng lãnh thổ, xác lập chủ quyền và phát triển vùng đất phía Nam của Tổ quốc (HS tự nêu).']]},
  {cd:'Bài 7 (Lịch sử): Khởi nghĩa nông dân ở Đàng Ngoài thế kỉ XVIII',q:[
   [1,'Các cuộc khởi nghĩa nông dân Đàng Ngoài thế kỉ XVIII bùng nổ do nguyên nhân gì?','đời sống nhân dân cực khổ, bị áp bức bóc lột nặng nề','đất nước thái bình','nhân dân giàu có','không có nguyên nhân'],
   [2,'Các cuộc khởi nghĩa nông dân thể hiện điều gì?','tinh thần đấu tranh chống áp bức của nông dân','sự phục tùng','sự thờ ơ','sự hài lòng'],
   [3,'Nêu nguyên nhân chung của các cuộc khởi nghĩa nông dân Đàng Ngoài thế kỉ XVIII.','Chính quyền phong kiến suy yếu, tham nhũng, đời sống nhân dân cực khổ nên nổi dậy đấu tranh (HS tự nêu).']]},
  {cd:'Bài 8 (Lịch sử): Phong trào Tây Sơn',q:[
   [1,'Phong trào Tây Sơn do ba anh em nhà nào lãnh đạo?','Nguyễn Nhạc, Nguyễn Huệ, Nguyễn Lữ','nhà Trịnh','nhà Lê','nhà Mạc'],
   [2,'Năm 1789, Quang Trung - Nguyễn Huệ đại phá quân xâm lược nào?','quân Thanh','quân Minh','quân Tống','thực dân Pháp'],
   [3,'Nêu công lao của phong trào Tây Sơn và Quang Trung - Nguyễn Huệ.','Lật đổ các chính quyền phong kiến chia cắt, đánh tan quân Xiêm và quân Thanh, bảo vệ độc lập dân tộc (HS tự nêu).']]},
  {cd:'Bài 9 (Lịch sử): Tình hình kinh tế, văn hoá, tôn giáo trong các thế kỉ XVI - XVIII',q:[
   [1,'Trong các thế kỉ XVI - XVIII, loại chữ viết nào của nước ta bắt đầu hình thành?','chữ Quốc ngữ','chữ Hán','chữ Nôm','chữ Phạn'],
   [2,'Hoạt động kinh tế nào phát triển mạnh ở các đô thị thời kì này?','thủ công nghiệp và buôn bán','chỉ săn bắt','chỉ du mục','không có hoạt động'],
   [3,'Nêu một nét văn hóa nổi bật trong các thế kỉ XVI - XVIII.','VD: sự ra đời của chữ Quốc ngữ, phát triển văn học chữ Nôm, các đô thị buôn bán sầm uất (HS tự nêu).']]},
  {cd:'Bài 10 (Lịch sử): Sự hình thành chủ nghĩa đế quốc ở các nước Âu - Mỹ',q:[
   [1,'Cuối thế kỉ XIX - đầu thế kỉ XX, các nước tư bản Âu - Mỹ chuyển sang giai đoạn nào?','chủ nghĩa đế quốc','chế độ phong kiến','xã hội nguyên thủy','chế độ nô lệ'],
   [2,'Đặc điểm của chủ nghĩa đế quốc là gì?','tăng cường xâm lược thuộc địa, bóc lột','không mở rộng lãnh thổ','từ bỏ thuộc địa','chỉ phát triển trong nước'],
   [3,'Nêu một đặc điểm của chủ nghĩa đế quốc.','Đẩy mạnh xâm chiếm thuộc địa để vơ vét tài nguyên và thị trường (HS tự nêu).']]},
  {cd:'Bài 12 (Lịch sử): Chiến tranh thế giới thứ nhất (1914 - 1918) và Cách mạng tháng Mười Nga',q:[
   [1,'Chiến tranh thế giới thứ nhất diễn ra trong khoảng thời gian nào?','1914 - 1918','1939 - 1945','1945 - 1954','1858 - 1884'],
   [2,'Cách mạng tháng Mười Nga năm 1917 lập ra nhà nước đầu tiên theo chế độ nào?','nhà nước xã hội chủ nghĩa (của công nông)','phong kiến','tư bản','nô lệ'],
   [3,'Nêu hậu quả của Chiến tranh thế giới thứ nhất.','Gây thiệt hại to lớn về người và của cho nhiều nước, để lại hậu quả nặng nề (HS tự nêu).']]},
  {cd:'Bài 13 (Lịch sử): Sự phát triển của khoa học, kĩ thuật, văn học, nghệ thuật các thế kỉ XVIII - XIX',q:[
   [1,'Trong các thế kỉ XVIII - XIX, lĩnh vực nào đạt nhiều thành tựu lớn?','khoa học, kĩ thuật','không có lĩnh vực nào','chỉ chiến tranh','chỉ nông nghiệp'],
   [2,'Phát minh nào góp phần thúc đẩy sản xuất công nghiệp thời kì này?','máy hơi nước, điện','không có','chỉ cối xay tay','chỉ sức người'],
   [3,'Nêu một thành tựu khoa học - kĩ thuật thế kỉ XVIII - XIX.','VD: máy hơi nước, điện, đầu máy xe lửa, điện thoại, thuyết tiến hóa (HS tự nêu).']]},
  {cd:'Bài 14 (Lịch sử): Trung Quốc và Nhật Bản từ nửa sau thế kỉ XIX đến đầu thế kỉ XX',q:[
   [1,'Cuộc Duy tân Minh Trị (1868) ở Nhật Bản có ý nghĩa gì?','đưa Nhật Bản phát triển theo con đường tư bản, thoát khỏi nguy cơ bị xâm lược','làm Nhật Bản suy yếu','biến Nhật thành thuộc địa','không có ý nghĩa'],
   [2,'Cuối thế kỉ XIX, Trung Quốc dần trở thành gì?','nước nửa thuộc địa, nửa phong kiến','nước tư bản phát triển','nước độc lập giàu mạnh','đế quốc lớn'],
   [3,'Nêu ý nghĩa của cuộc Duy tân Minh Trị ở Nhật Bản.','Giúp Nhật Bản phát triển nhanh theo con đường tư bản và trở thành nước mạnh ở châu Á (HS tự nêu).']]},
  {cd:'Bài 15 (Lịch sử): Ấn Độ và Đông Nam Á từ nửa sau thế kỉ XIX đến đầu thế kỉ XX',q:[
   [1,'Đến cuối thế kỉ XIX, phần lớn các nước Đông Nam Á trở thành gì?','thuộc địa của thực dân phương Tây','nước tư bản phát triển','đế quốc hùng mạnh','độc lập hoàn toàn'],
   [2,'Nhân dân Ấn Độ và Đông Nam Á có thái độ như thế nào với ách thống trị thực dân?','đấu tranh chống thực dân giành độc lập','phục tùng hoàn toàn','hợp tác với thực dân','không quan tâm'],
   [3,'Nêu đặc điểm chung của Ấn Độ và Đông Nam Á cuối thế kỉ XIX - đầu XX.','Bị thực dân phương Tây xâm lược, thống trị; nhân dân nổi dậy đấu tranh giành độc lập (HS tự nêu).']]},
  {cd:'Bài 16 (Lịch sử): Việt Nam dưới thời Nguyễn (nửa đầu thế kỉ XIX)',q:[
   [1,'Ai lập ra triều Nguyễn (năm 1802)?','Nguyễn Ánh (vua Gia Long)','Quang Trung','Lê Lợi','Lý Công Uẩn'],
   [2,'Kinh đô của triều Nguyễn đặt ở đâu?','Phú Xuân (Huế)','Thăng Long','Hoa Lư','Gia Định'],
   [3,'Nêu một thành tựu hoặc công trình thời Nguyễn.','VD: Kinh thành Huế, bộ luật Gia Long, các công trình kiến trúc cung đình (HS tự nêu).']]},
  {cd:'Bài 17 (Lịch sử): Cuộc kháng chiến chống thực dân Pháp xâm lược từ năm 1858',q:[
   [1,'Thực dân Pháp nổ súng xâm lược Việt Nam vào năm nào, ở đâu?','năm 1858, ở Đà Nẵng','năm 1945 ở Hà Nội','năm 1930 ở Sài Gòn','năm 1789 ở Huế'],
   [2,'Thái độ của nhân dân ta khi Pháp xâm lược là gì?','anh dũng đứng lên kháng chiến chống Pháp','đầu hàng ngay','hợp tác với Pháp','không quan tâm'],
   [3,'Nêu tinh thần của nhân dân ta trong cuộc kháng chiến chống Pháp (1858 - 1884).','Nhân dân nhiều nơi anh dũng kháng chiến dù triều đình nhà Nguyễn từng bước đầu hàng (HS tự nêu).']]},
  {cd:'Bài 18 (Lịch sử): Phong trào chống Pháp trong những năm 1885 - 1896',q:[
   [1,'Phong trào Cần Vương kêu gọi nhân dân làm gì?','giúp vua đánh Pháp, giành lại độc lập','đầu hàng Pháp','hợp tác với Pháp','rời bỏ đất nước'],
   [2,'Khởi nghĩa Hương Khê (do Phan Đình Phùng lãnh đạo) thuộc phong trào nào?','phong trào Cần Vương','phong trào Tây Sơn','Cách mạng tháng Tám','phong trào Đông Du'],
   [3,'Nêu ý nghĩa của phong trào Cần Vương.','Thể hiện tinh thần yêu nước, ý chí chống Pháp của nhân dân ta cuối thế kỉ XIX (HS tự nêu).']]},
  {cd:'Bài 19 (Lịch sử): Phong trào yêu nước chống Pháp ở Việt Nam từ đầu thế kỉ XX đến năm 1917',q:[
   [1,'Phan Bội Châu chủ trương cứu nước bằng con đường nào?','dựa vào bên ngoài để đánh Pháp (phong trào Đông Du)','hợp tác với Pháp','đầu hàng','không làm gì'],
   [2,'Phan Châu Trinh chủ trương cứu nước theo hướng nào?','cải cách, nâng cao dân trí, dân quyền','bạo lực chống nhân dân','đầu hàng Pháp','không hành động'],
   [3,'Nêu điểm chung của các phong trào yêu nước đầu thế kỉ XX.','Đều thể hiện lòng yêu nước, tìm con đường cứu nước mới nhưng chưa thành công (HS tự nêu).']]},
  {cd:'Bài 1 (Địa lí): Vị trí địa lí và phạm vi lãnh thổ Việt Nam',q:[
   [1,'Việt Nam nằm ở khu vực nào của châu Á?','Đông Nam Á','Đông Á','Nam Á','Tây Á'],
   [2,'Việt Nam nằm trong đới khí hậu nào?','đới nóng (nhiệt đới)','đới ôn hòa','đới lạnh','hàn đới'],
   [3,'Nêu ý nghĩa của vị trí địa lí nước ta.','Thuận lợi giao lưu kinh tế, văn hóa; khí hậu nhiệt đới ẩm gió mùa, giàu tài nguyên biển (HS tự nêu).']]},
  {cd:'Bài 2 (Địa lí): Địa hình Việt Nam',q:[
   [1,'Địa hình phần đất liền Việt Nam chủ yếu là gì?','đồi núi (chiếm khoảng ba phần tư diện tích)','đồng bằng','sa mạc','cao nguyên băng'],
   [2,'Đồng bằng lớn nhất nước ta là đồng bằng nào?','đồng bằng sông Cửu Long','đồng bằng sông Hồng','đồng bằng ven biển miền Trung','không có'],
   [3,'Nêu đặc điểm chung của địa hình Việt Nam.','Đồi núi chiếm phần lớn, thấp dần từ tây bắc xuống đông nam, có hai đồng bằng châu thổ lớn (HS tự nêu).']]},
  {cd:'Bài 3 (Địa lí): Khoáng sản Việt Nam',q:[
   [1,'Nước ta có nguồn khoáng sản như thế nào?','phong phú, đa dạng','rất nghèo nàn','không có','chỉ có vàng'],
   [2,'Khoáng sản nào là nhiên liệu quan trọng của nước ta?','than đá, dầu mỏ, khí tự nhiên','vàng, bạc','kim cương','không có'],
   [3,'Vì sao cần khai thác và sử dụng khoáng sản hợp lí?','Vì khoáng sản có hạn, khó tái tạo; khai thác bừa bãi gây lãng phí và ô nhiễm (HS tự nêu).']]},
  {cd:'Bài 4 (Địa lí): Khí hậu Việt Nam',q:[
   [1,'Khí hậu Việt Nam mang tính chất gì?','nhiệt đới ẩm gió mùa','ôn đới lục địa','hàn đới','hoang mạc'],
   [2,'Khí hậu nước ta có mấy mùa gió chính?','hai mùa gió (gió mùa mùa đông và gió mùa mùa hạ)','một mùa','bốn mùa gió','không có gió mùa'],
   [3,'Nêu đặc điểm chung của khí hậu Việt Nam.','Nhiệt đới ẩm gió mùa, nhiệt độ cao, mưa nhiều, phân hóa theo mùa và theo vùng (HS tự nêu).']]},
  {cd:'Bài 5 (Địa lí): Thực hành: Đọc biểu đồ khí hậu',q:[
   [1,'Trên biểu đồ khí hậu, lượng mưa thường được biểu diễn bằng gì?','các cột','đường cong nhiệt độ','hình tròn','chữ số đơn'],
   [2,'Nhiệt độ trên biểu đồ khí hậu thường biểu diễn bằng gì?','đường biểu diễn','cột mưa','hình quạt','bảng chữ'],
   [3,'Nêu cách đọc biểu đồ khí hậu của một địa điểm.','Xem nhiệt độ và lượng mưa các tháng, nhận xét tháng nóng/lạnh nhất, mưa nhiều/ít nhất (HS tự nêu).']]},
  {cd:'Bài 6 (Địa lí): Thuỷ văn Việt Nam',q:[
   [1,'Nước ta có mạng lưới sông ngòi như thế nào?','dày đặc, nhiều nước','rất ít sông','khô hạn không sông','chỉ một con sông'],
   [2,'Hai hệ thống sông lớn nhất nước ta là gì?','sông Hồng và sông Cửu Long (Mê Công)','sông Nin và sông Hằng','sông Hoàng Hà','không có'],
   [3,'Nêu vai trò của sông ngòi đối với nước ta.','Cung cấp nước, phù sa cho nông nghiệp, thủy điện, giao thông và thủy sản (HS tự nêu).']]},
  {cd:'Bài 8 (Địa lí): Tác động của biến đổi khí hậu đối với khí hậu và thuỷ văn Việt Nam',q:[
   [1,'Biến đổi khí hậu gây ra hậu quả nào ở nước ta?','thiên tai nhiều hơn (bão, lũ, hạn hán), nước biển dâng','thời tiết ổn định hơn','hết thiên tai','không ảnh hưởng gì'],
   [2,'Biện pháp nào giúp ứng phó với biến đổi khí hậu?','trồng rừng, tiết kiệm năng lượng, giảm khí thải','chặt phá rừng','đốt nhiều than','xả rác'],
   [3,'Nêu một biện pháp ứng phó với biến đổi khí hậu ở nước ta.','VD: trồng và bảo vệ rừng, sử dụng năng lượng sạch, tiết kiệm điện, nước (HS tự nêu).']]},
  {cd:'Bài 9 (Địa lí): Thổ nhưỡng Việt Nam',q:[
   [1,'Nhóm đất chiếm diện tích lớn nhất ở nước ta là nhóm đất nào?','đất feralit (ở vùng đồi núi)','đất phù sa','đất mặn','đất cát'],
   [2,'Nhóm đất phù sa thích hợp cho hoạt động nào?','trồng lúa và hoa màu (ở đồng bằng)','khai thác than','nuôi cá biển','trồng rừng ngập mặn'],
   [3,'Nêu vai trò của tài nguyên đất đối với sản xuất nông nghiệp.','Là tư liệu sản xuất quan trọng, quyết định năng suất cây trồng; cần sử dụng và bảo vệ hợp lí (HS tự nêu).']]},
  {cd:'Bài 10 (Địa lí): Sinh vật Việt Nam',q:[
   [1,'Sinh vật Việt Nam có đặc điểm gì?','phong phú, đa dạng','nghèo nàn','chỉ có một loài','không có sinh vật'],
   [2,'Vì sao cần bảo vệ đa dạng sinh học ở nước ta?','vì nhiều loài đang bị suy giảm do khai thác quá mức','vì sinh vật vô hạn','vì không có giá trị','không cần bảo vệ'],
   [3,'Nêu một biện pháp bảo vệ sinh vật (đa dạng sinh học) ở nước ta.','VD: bảo vệ rừng, cấm săn bắt động vật quý hiếm, lập khu bảo tồn (HS tự nêu).']]},
  {cd:'Bài 11 (Địa lí): Phạm vi biển Đông',q:[
   [1,'Biển Đông là một bộ phận của đại dương nào?','Thái Bình Dương','Đại Tây Dương','Ấn Độ Dương','Bắc Băng Dương'],
   [2,'Hai quần đảo lớn thuộc chủ quyền Việt Nam trên Biển Đông là gì?','quần đảo Hoàng Sa và Trường Sa','quần đảo Phú Quốc','không có','quần đảo Ha-oai'],
   [3,'Nêu vai trò của Biển Đông đối với nước ta.','Cung cấp hải sản, dầu khí, muối, giao thông và có vị trí chiến lược quan trọng (HS tự nêu).']]},
  {cd:'Bài 12 (Địa lí): Môi trường và tài nguyên thiên nhiên biển đảo Việt Nam',q:[
   [1,'Tài nguyên biển của nước ta gồm những gì?','hải sản, dầu khí, muối, du lịch biển','chỉ có cát','chỉ có đá','không có tài nguyên'],
   [2,'Vì sao cần bảo vệ môi trường biển đảo?','vì biển cung cấp tài nguyên và có vai trò quan trọng, đang bị ô nhiễm','vì biển không có giá trị','không cần bảo vệ','vì biển vô hạn'],
   [3,'Nêu một biện pháp bảo vệ môi trường biển đảo.','VD: không xả rác ra biển, khai thác hải sản hợp lí, xử lí chất thải, bảo vệ rạn san hô (HS tự nêu).']]}
 );
 SD[9].push(
  {cd:'Bài 1 (Lịch sử): Nước Nga và Liên Xô từ năm 1918 đến năm 1945',q:[
   [1,'Sau Cách mạng tháng Mười, nước Nga Xô viết xây dựng chế độ nào?','xã hội chủ nghĩa','phong kiến','tư bản','nô lệ'],
   [2,'Liên Xô (thành lập năm 1922) đạt thành tựu gì trong công cuộc xây dựng đất nước?','trở thành cường quốc công nghiệp','tan rã ngay','vẫn nghèo nàn','không phát triển'],
   [3,'Nêu một thành tựu của Liên Xô trong những năm 1918 - 1945.','Từ nước nông nghiệp lạc hậu trở thành cường quốc công nghiệp, đạt nhiều thành tựu khoa học (HS tự nêu).']]},
  {cd:'Bài 2 (Lịch sử): Châu Âu và nước Mỹ từ năm 1918 đến năm 1945',q:[
   [1,'Cuộc khủng hoảng kinh tế thế giới 1929 - 1933 bắt đầu từ nước nào?','nước Mỹ','Việt Nam','Liên Xô','Nhật Bản'],
   [2,'Hậu quả của khủng hoảng kinh tế 1929 - 1933 là gì?','kinh tế suy sụp, thất nghiệp, tạo điều kiện cho chủ nghĩa phát xít xuất hiện','kinh tế phát triển mạnh','không ảnh hưởng gì','thế giới hòa bình'],
   [3,'Nêu hậu quả của cuộc khủng hoảng kinh tế thế giới 1929 - 1933.','Gây suy thoái nặng nề, thất nghiệp, dẫn tới sự xuất hiện của chủ nghĩa phát xít (HS tự nêu).']]},
  {cd:'Bài 3 (Lịch sử): Châu Á từ năm 1918 đến năm 1945',q:[
   [1,'Phong trào đấu tranh của nhân dân châu Á thời kì này nhằm mục tiêu gì?','giành độc lập dân tộc','ủng hộ thực dân','duy trì chế độ thuộc địa','không có mục tiêu'],
   [2,'Nhật Bản trong những năm 1930 đi theo con đường nào?','phát xít hóa, gây chiến tranh xâm lược','hòa bình, trung lập','từ bỏ quân sự','dân chủ hoàn toàn'],
   [3,'Nêu đặc điểm phong trào giải phóng dân tộc ở châu Á (1918 - 1945).','Phát triển mạnh mẽ nhằm chống đế quốc, thực dân, giành độc lập dân tộc (HS tự nêu).']]},
  {cd:'Bài 4 (Lịch sử): Chiến tranh thế giới thứ hai (1939 - 1945)',q:[
   [1,'Chiến tranh thế giới thứ hai diễn ra trong khoảng thời gian nào?','1939 - 1945','1914 - 1918','1945 - 1954','1858 - 1884'],
   [2,'Chiến tranh thế giới thứ hai kết thúc với sự thất bại của phe nào?','phe phát xít','phe Đồng minh','Liên Xô','nước Mỹ'],
   [3,'Nêu hậu quả của Chiến tranh thế giới thứ hai.','Là cuộc chiến tàn khốc nhất lịch sử, gây thiệt hại to lớn về người và của cho nhân loại (HS tự nêu).']]},
  {cd:'Bài 5 (Lịch sử): Phong trào dân tộc dân chủ trong những năm 1918 - 1930',q:[
   [1,'Phong trào dân tộc dân chủ ở Việt Nam những năm 1918 - 1930 nhằm mục tiêu gì?','đòi quyền lợi dân tộc, chống thực dân Pháp','ủng hộ Pháp','duy trì phong kiến','không có mục tiêu'],
   [2,'Giai cấp nào ngày càng trưởng thành và tham gia phong trào cách mạng thời kì này?','giai cấp công nhân','quý tộc phong kiến','thực dân','địa chủ'],
   [3,'Nêu đặc điểm của phong trào dân tộc dân chủ 1918 - 1930 ở Việt Nam.','Diễn ra sôi nổi với nhiều tầng lớp tham gia, giai cấp công nhân ngày càng trưởng thành (HS tự nêu).']]},
  {cd:'Bài 6 (Lịch sử): Hoạt động của Nguyễn Ái Quốc và sự thành lập Đảng Cộng sản Việt Nam',q:[
   [1,'Đảng Cộng sản Việt Nam được thành lập vào thời gian nào?','đầu năm 1930','năm 1945','năm 1954','năm 1975'],
   [2,'Ai là người sáng lập Đảng Cộng sản Việt Nam?','Nguyễn Ái Quốc (Hồ Chí Minh)','Phan Bội Châu','Phan Châu Trinh','Lê Lợi'],
   [3,'Nêu ý nghĩa của việc thành lập Đảng Cộng sản Việt Nam.','Là bước ngoặt của cách mạng Việt Nam, chấm dứt khủng hoảng về đường lối, lãnh đạo cách mạng đi tới thắng lợi (HS tự nêu).']]},
  {cd:'Bài 7 (Lịch sử): Phong trào cách mạng Việt Nam thời kì 1930 - 1939',q:[
   [1,'Phong trào cách mạng 1930 - 1931 với đỉnh cao là phong trào nào?','Xô viết Nghệ - Tĩnh','Cần Vương','Đông Du','Tây Sơn'],
   [2,'Phong trào cách mạng thời kì này do lực lượng nào lãnh đạo?','Đảng Cộng sản Việt Nam','thực dân Pháp','triều Nguyễn','vua Hùng'],
   [3,'Nêu ý nghĩa của phong trào cách mạng 1930 - 1931.','Khẳng định đường lối đúng đắn của Đảng và sức mạnh quần chúng, là cuộc tập dượt cho Cách mạng tháng Tám (HS tự nêu).']]},
  {cd:'Bài 8 (Lịch sử): Cách mạng tháng Tám năm 1945',q:[
   [1,'Cách mạng tháng Tám thành công, nước Việt Nam Dân chủ Cộng hòa ra đời vào ngày nào?','ngày 2 - 9 - 1945','ngày 30 - 4 - 1975','ngày 7 - 5 - 1954','ngày 3 - 2 - 1930'],
   [2,'Ai đọc bản Tuyên ngôn Độc lập khai sinh nước Việt Nam Dân chủ Cộng hòa?','Chủ tịch Hồ Chí Minh','Phan Bội Châu','Lê Lợi','Quang Trung'],
   [3,'Nêu ý nghĩa của Cách mạng tháng Tám năm 1945.','Lật đổ ách thống trị thực dân, phong kiến, giành độc lập, lập nên nước Việt Nam Dân chủ Cộng hòa (HS tự nêu).']]},
  {cd:'Bài 9 (Lịch sử): Chiến tranh lạnh (1947 - 1989)',q:[
   [1,'Chiến tranh lạnh là sự đối đầu giữa hai phe nào?','phe tư bản chủ nghĩa (Mỹ) và phe xã hội chủ nghĩa (Liên Xô)','hai nước châu Á','Pháp và Anh','không có'],
   [2,'Đặc điểm của Chiến tranh lạnh là gì?','căng thẳng, chạy đua vũ trang nhưng không xảy ra chiến tranh trực tiếp giữa hai siêu cường','chiến tranh nóng toàn cầu','hòa bình hoàn toàn','không có căng thẳng'],
   [3,'Nêu hậu quả của Chiến tranh lạnh.','Thế giới căng thẳng, chạy đua vũ trang tốn kém, nhiều cuộc xung đột khu vực (HS tự nêu).']]},
  {cd:'Bài 10 (Lịch sử): Liên Xô và Đông Âu từ năm 1945 đến năm 1991',q:[
   [1,'Sau năm 1945, Liên Xô có vai trò như thế nào trên thế giới?','là cường quốc, đứng đầu phe xã hội chủ nghĩa','là nước nhỏ yếu','là thuộc địa','không có vai trò'],
   [2,'Đến năm 1991, Liên Xô có sự kiện lớn nào?','tan rã','trở nên hùng mạnh nhất','thống nhất châu Âu','không có gì'],
   [3,'Nêu một thành tựu của Liên Xô sau năm 1945.','VD: đi đầu trong chinh phục vũ trụ, phát triển khoa học - kĩ thuật, giúp đỡ các nước (HS tự nêu).']]},
  {cd:'Bài 11 (Lịch sử): Nước Mỹ và Tây Âu từ năm 1945 đến năm 1991',q:[
   [1,'Sau Chiến tranh thế giới thứ hai, nước Mỹ trở thành gì?','cường quốc kinh tế, tài chính hàng đầu thế giới','nước nghèo','thuộc địa','nước nhỏ'],
   [2,'Các nước Tây Âu sau năm 1945 có xu hướng gì?','liên kết khu vực','chia rẽ, chiến tranh với nhau','trở thành thuộc địa','không hợp tác'],
   [3,'Nêu một đặc điểm của nước Mỹ sau Chiến tranh thế giới thứ hai.','Kinh tế phát triển mạnh, trở thành siêu cường, đứng đầu phe tư bản chủ nghĩa (HS tự nêu).']]},
  {cd:'Bài 12 (Lịch sử): Khu vực Mỹ La-tinh và châu Á từ năm 1945 đến năm 1991',q:[
   [1,'Phong trào đấu tranh ở Mỹ La-tinh và châu Á sau năm 1945 nhằm mục tiêu gì?','giành và bảo vệ độc lập dân tộc','ủng hộ thực dân','duy trì thuộc địa','không có mục tiêu'],
   [2,'Nhiều nước châu Á sau năm 1945 đã làm được điều gì?','giành được độc lập','trở thành thuộc địa','tan rã','không thay đổi'],
   [3,'Nêu đặc điểm phong trào giải phóng dân tộc ở châu Á, Mỹ La-tinh sau năm 1945.','Phát triển mạnh mẽ, nhiều nước giành được độc lập, xóa bỏ chế độ thuộc địa (HS tự nêu).']]},
  {cd:'Bài 13 (Lịch sử): Việt Nam trong năm đầu sau Cách mạng tháng Tám năm 1945',q:[
   [1,'Sau Cách mạng tháng Tám, nước ta gặp những khó khăn nào?','giặc đói, giặc dốt và giặc ngoại xâm','đất nước giàu mạnh','không có khó khăn','hòa bình hoàn toàn'],
   [2,'Để chống giặc dốt, Chủ tịch Hồ Chí Minh phát động phong trào gì?','Bình dân học vụ (xóa nạn mù chữ)','Đông Du','Cần Vương','không có'],
   [3,'Nêu những khó khăn của nước ta trong năm đầu sau Cách mạng tháng Tám.','Giặc đói, giặc dốt, khó khăn tài chính và thù trong giặc ngoài đe dọa nền độc lập (HS tự nêu).']]},
  {cd:'Bài 14 (Lịch sử): Việt Nam kháng chiến chống thực dân Pháp giai đoạn 1946 - 1950',q:[
   [1,'Cuộc kháng chiến toàn quốc chống thực dân Pháp bùng nổ vào thời gian nào?','cuối năm 1946','năm 1975','năm 1930','năm 1858'],
   [2,'Đường lối kháng chiến chống Pháp của ta là gì?','toàn dân, toàn diện, trường kì, tự lực cánh sinh','đầu hàng','dựa hoàn toàn vào nước ngoài','không kháng chiến'],
   [3,'Nêu tinh thần của nhân dân ta trong kháng chiến chống Pháp.','Toàn dân đoàn kết, quyết tâm kháng chiến bảo vệ độc lập dân tộc (HS tự nêu).']]},
  {cd:'Bài 15 (Lịch sử): Việt Nam kháng chiến chống thực dân Pháp giai đoạn 1951 - 1954',q:[
   [1,'Chiến thắng nào đã kết thúc cuộc kháng chiến chống thực dân Pháp?','Chiến thắng Điện Biên Phủ (năm 1954)','Chiến thắng Bạch Đằng','Cách mạng tháng Tám','Chiến dịch Hồ Chí Minh'],
   [2,'Hiệp định nào được kí kết năm 1954 về chấm dứt chiến tranh ở Đông Dương?','Hiệp định Giơ-ne-vơ','Hiệp định Pa-ri','Hiệp định Pốt-xđam','không có'],
   [3,'Nêu ý nghĩa của chiến thắng Điện Biên Phủ năm 1954.','Đánh bại thực dân Pháp, buộc Pháp kí Hiệp định Giơ-ne-vơ, chấm dứt chiến tranh, miền Bắc được giải phóng (HS tự nêu).']]},
  {cd:'Bài 16 (Lịch sử): Việt Nam kháng chiến chống Mỹ, cứu nước giai đoạn 1954 - 1965',q:[
   [1,'Sau Hiệp định Giơ-ne-vơ năm 1954, đất nước ta bị chia cắt như thế nào?','thành hai miền Nam - Bắc','thành ba miền','không chia cắt','thành bốn vùng'],
   [2,'Nhiệm vụ của cách mạng miền Nam thời kì này là gì?','đấu tranh chống Mỹ và chính quyền tay sai, giải phóng miền Nam','ủng hộ Mỹ','duy trì chia cắt','không làm gì'],
   [3,'Nêu nhiệm vụ cách mạng của hai miền sau năm 1954.','Miền Bắc xây dựng chủ nghĩa xã hội; miền Nam đấu tranh chống Mỹ, giải phóng miền Nam, thống nhất đất nước (HS tự nêu).']]},
  {cd:'Bài 17 (Lịch sử): Việt Nam kháng chiến chống Mỹ, cứu nước giai đoạn 1965 - 1975',q:[
   [1,'Cuộc kháng chiến chống Mỹ cứu nước kết thúc thắng lợi vào ngày nào?','ngày 30 - 4 - 1975','ngày 2 - 9 - 1945','ngày 7 - 5 - 1954','ngày 3 - 2 - 1930'],
   [2,'Chiến dịch lịch sử giải phóng hoàn toàn miền Nam năm 1975 mang tên gì?','Chiến dịch Hồ Chí Minh','Chiến dịch Điện Biên Phủ','Chiến dịch Biên giới','không có'],
   [3,'Nêu ý nghĩa của Đại thắng mùa Xuân năm 1975.','Kết thúc cuộc kháng chiến chống Mỹ, giải phóng miền Nam, thống nhất đất nước (HS tự nêu).']]},
  {cd:'Bài 18 (Lịch sử): Trật tự thế giới mới từ năm 1991 đến nay',q:[
   [1,'Sau khi Liên Xô tan rã (năm 1991), trật tự thế giới có xu hướng như thế nào?','chuyển sang đa cực, hòa bình, hợp tác và phát triển','chiến tranh thế giới mới','trở lại Chiến tranh lạnh','không thay đổi'],
   [2,'Xu thế chung của thế giới ngày nay là gì?','hòa bình, hợp tác và phát triển','chiến tranh liên miên','chia rẽ, đối đầu','biệt lập'],
   [3,'Nêu xu thế phát triển của thế giới từ năm 1991 đến nay.','Hòa bình, hợp tác, phát triển và toàn cầu hóa là xu thế chủ đạo (HS tự nêu).']]},
  {cd:'Bài 19 (Lịch sử): Châu Á từ năm 1991 đến nay',q:[
   [1,'Nhiều nước châu Á từ năm 1991 đến nay đạt được điều gì?','tăng trưởng kinh tế nhanh','suy thoái hoàn toàn','trở thành thuộc địa','không phát triển'],
   [2,'Quốc gia châu Á nào có nền kinh tế phát triển nhanh, trở thành nền kinh tế lớn?','Trung Quốc','Lào','Cam-pu-chia','không có'],
   [3,'Nêu đặc điểm phát triển của châu Á từ năm 1991 đến nay.','Nhiều nước phát triển kinh tế năng động, châu Á ngày càng có vai trò quan trọng trên thế giới (HS tự nêu).']]},
  {cd:'Bài 20 (Lịch sử): Việt Nam từ năm 1976 đến nay',q:[
   [1,'Công cuộc Đổi mới ở nước ta bắt đầu từ năm nào?','năm 1986','năm 1945','năm 1975','năm 1954'],
   [2,'Công cuộc Đổi mới đã mang lại kết quả gì cho đất nước?','kinh tế phát triển, đời sống nhân dân được cải thiện','đất nước nghèo đi','không thay đổi','chiến tranh'],
   [3,'Nêu một thành tựu của công cuộc Đổi mới ở nước ta.','Kinh tế tăng trưởng, đời sống nhân dân nâng cao, vị thế đất nước được nâng lên (HS tự nêu).']]},
  {cd:'Bài 21 (Lịch sử): Cách mạng khoa học – kĩ thuật và xu thế toàn cầu hoá',q:[
   [1,'Cuộc cách mạng khoa học - kĩ thuật hiện đại mang lại điều gì?','nhiều thành tựu to lớn, làm thay đổi đời sống','không có gì','làm con người lạc hậu','gây chiến tranh'],
   [2,'Toàn cầu hóa là xu thế như thế nào?','các nước trên thế giới liên kết, phụ thuộc lẫn nhau ngày càng chặt chẽ','các nước tách biệt','chỉ một nước phát triển','không có liên kết'],
   [3,'Nêu một tác động của cách mạng khoa học - kĩ thuật đối với đời sống.','VD: máy tính, Internet, điện thoại thông minh giúp thông tin nhanh chóng, nâng cao đời sống (HS tự nêu).']]},
  {cd:'Bài 1 (Địa lí): Dân tộc và dân số',q:[
   [1,'Việt Nam có bao nhiêu dân tộc?','54 dân tộc','một dân tộc','10 dân tộc','100 dân tộc'],
   [2,'Dân tộc nào có số dân đông nhất ở nước ta?','dân tộc Kinh','dân tộc Tày','dân tộc Thái','dân tộc Mường'],
   [3,'Nêu đặc điểm dân số nước ta.','Đông dân, nhiều thành phần dân tộc, dân số đang có xu hướng già hóa (HS tự nêu).']]},
  {cd:'Bài 2 (Địa lí): Phân bố dân cư và các loại hình quần cư',q:[
   [1,'Dân cư nước ta phân bố như thế nào?','không đều giữa các vùng','hoàn toàn đồng đều','chỉ ở miền núi','chỉ ở hải đảo'],
   [2,'Dân cư tập trung đông ở khu vực nào?','đồng bằng và đô thị','vùng núi cao','hoang mạc','vùng biên giới hẻo lánh'],
   [3,'Nêu các loại hình quần cư ở nước ta.','Quần cư nông thôn và quần cư thành thị (đô thị) (HS tự nêu).']]},
  {cd:'Bài 3 (Địa lí): Lao động và việc làm',q:[
   [1,'Nguồn lao động nước ta có đặc điểm gì?','dồi dào, tăng nhanh','rất ít','không có','giảm mạnh'],
   [2,'Vấn đề đặt ra đối với lao động nước ta là gì?','giải quyết việc làm và nâng cao chất lượng lao động','thừa việc làm','không cần đào tạo','không có vấn đề'],
   [3,'Nêu một giải pháp để giải quyết việc làm ở nước ta.','VD: phát triển kinh tế, đào tạo nghề, đẩy mạnh xuất khẩu lao động (HS tự nêu).']]},
  {cd:'Bài 4 (Địa lí): Thực hành: Tìm hiểu vấn đề việc làm ở địa phương',q:[
   [1,'Vấn đề việc làm ở nhiều địa phương hiện nay là gì?','thiếu việc làm, cần tạo thêm việc làm','thừa việc làm','không ai cần việc','đã giải quyết hết'],
   [2,'Giải pháp tạo việc làm ở địa phương có thể là gì?','phát triển ngành nghề, đào tạo nghề','không làm gì','để tự nhiên','di cư hết đi nơi khác'],
   [3,'Nêu một hướng tạo việc làm ở địa phương em.','VD: phát triển nghề truyền thống, du lịch, dịch vụ, đào tạo nghề cho lao động (HS tự nêu).']]},
  {cd:'Bài 5 (Địa lí): Nông nghiệp',q:[
   [1,'Cây lương thực quan trọng nhất của nước ta là cây gì?','cây lúa','cây cà phê','cây cao su','cây chè'],
   [2,'Ngành nông nghiệp nước ta gồm những bộ phận nào?','trồng trọt và chăn nuôi','chỉ công nghiệp','chỉ dịch vụ','chỉ khai khoáng'],
   [3,'Nêu vai trò của ngành nông nghiệp đối với nước ta.','Cung cấp lương thực, thực phẩm, nguyên liệu, xuất khẩu và tạo việc làm (HS tự nêu).']]},
  {cd:'Bài 6 (Địa lí): Lâm nghiệp và thuỷ sản',q:[
   [1,'Ngành lâm nghiệp bao gồm những hoạt động nào?','trồng, chăm sóc, bảo vệ rừng và khai thác lâm sản','chỉ nuôi cá','chỉ trồng lúa','chỉ khai thác than'],
   [2,'Nước ta có điều kiện thuận lợi để phát triển thủy sản nhờ gì?','có bờ biển dài, nhiều sông ngòi, ao hồ','không có nước','sa mạc rộng','khí hậu lạnh'],
   [3,'Nêu vai trò của ngành thủy sản đối với nước ta.','Cung cấp thực phẩm, nguyên liệu chế biến, xuất khẩu và tạo việc làm (HS tự nêu).']]},
  {cd:'Bài 7 (Địa lí): Thực hành: Viết báo cáo về một mô hình sản xuất nông nghiệp',q:[
   [1,'Một mô hình sản xuất nông nghiệp hiệu quả cần đảm bảo điều gì?','năng suất cao và bảo vệ môi trường','gây ô nhiễm','lãng phí tài nguyên','không quan tâm chất lượng'],
   [2,'Mô hình nông nghiệp bền vững hướng tới điều gì?','hiệu quả kinh tế đi đôi với bảo vệ môi trường','khai thác cạn kiệt','dùng nhiều hóa chất','phá rừng'],
   [3,'Nêu một ví dụ mô hình sản xuất nông nghiệp có hiệu quả.','VD: trồng rau sạch, mô hình vườn - ao - chuồng (VAC), nông nghiệp công nghệ cao (HS tự nêu).']]},
  {cd:'Bài 8 (Địa lí): Công nghiệp',q:[
   [1,'Ngành công nghiệp có vai trò gì đối với nền kinh tế?','thúc đẩy phát triển kinh tế, tạo ra nhiều sản phẩm','không có vai trò','làm kinh tế suy giảm','chỉ gây ô nhiễm'],
   [2,'Đâu là một ngành công nghiệp của nước ta?','khai thác, chế biến, dệt may, điện','trồng lúa','đánh cá','chăn nuôi'],
   [3,'Nêu vai trò của ngành công nghiệp đối với nước ta.','Tạo ra sản phẩm, thúc đẩy các ngành khác phát triển, tăng xuất khẩu và việc làm (HS tự nêu).']]},
  {cd:'Bài 9 (Địa lí): Thực hành: Xác định một số hình thức tổ chức lãnh thổ công nghiệp',q:[
   [1,'Hình thức tổ chức lãnh thổ công nghiệp phổ biến là gì?','khu công nghiệp, trung tâm công nghiệp','trang trại','đồng ruộng','bãi biển'],
   [2,'Khu công nghiệp thường được xây dựng ở đâu?','nơi có giao thông, nguồn lao động thuận lợi','vùng núi hiểm trở','giữa biển','hoang mạc'],
   [3,'Nêu lợi ích của việc hình thành các khu công nghiệp.','Tập trung sản xuất, sử dụng hiệu quả hạ tầng, tạo việc làm và thúc đẩy kinh tế (HS tự nêu).']]},
  {cd:'Bài 10 (Địa lí): Dịch vụ',q:[
   [1,'Ngành dịch vụ bao gồm những hoạt động nào?','thương mại, giao thông, du lịch, giáo dục, y tế','chỉ trồng trọt','chỉ khai khoáng','chỉ chăn nuôi'],
   [2,'Ngành dịch vụ có vai trò gì?','phục vụ đời sống và sản xuất, thúc đẩy kinh tế','không có vai trò','làm kinh tế kém đi','chỉ gây lãng phí'],
   [3,'Nêu vai trò của ngành dịch vụ đối với nền kinh tế.','Phục vụ sản xuất và đời sống, tạo nhiều việc làm, đóng góp lớn vào nền kinh tế (HS tự nêu).']]},
  {cd:'Bài 11 (Địa lí): Thực hành: Tìm hiểu xu hướng phát triển ngành thương mại, du lịch',q:[
   [1,'Ngành du lịch nước ta có tiềm năng nhờ điều gì?','nhiều danh lam thắng cảnh, di sản văn hóa','không có cảnh đẹp','khí hậu khắc nghiệt','không có di sản'],
   [2,'Xu hướng phát triển của ngành thương mại, du lịch hiện nay là gì?','ngày càng mở rộng, ứng dụng công nghệ số','thu hẹp dần','biến mất','không thay đổi'],
   [3,'Kể tên một địa điểm du lịch nổi tiếng của Việt Nam.','VD: Vịnh Hạ Long, Phố cổ Hội An, Cố đô Huế, Phong Nha - Kẻ Bàng (HS tự nêu).']]},
  {cd:'Bài 12 (Địa lí): Vùng Trung du và miền núi phía Bắc',q:[
   [1,'Vùng Trung du và miền núi Bắc Bộ có thế mạnh nổi bật nào?','khoáng sản, thủy điện, cây công nghiệp','trồng lúa nước là chính','đánh bắt hải sản xa bờ','không có thế mạnh'],
   [2,'Vùng Trung du và miền núi Bắc Bộ nằm ở phía nào của nước ta?','phía bắc','phía nam','miền Trung','Tây Nguyên'],
   [3,'Nêu một thế mạnh kinh tế của vùng Trung du và miền núi Bắc Bộ.','VD: khai thác khoáng sản, thủy điện, trồng cây công nghiệp (chè), chăn nuôi (HS tự nêu).']]},
  {cd:'Bài 13 (Địa lí): Vùng Đồng bằng sông Hồng',q:[
   [1,'Đồng bằng sông Hồng được bồi đắp bởi hệ thống sông nào?','sông Hồng và sông Thái Bình','sông Cửu Long','sông Đồng Nai','sông Mã'],
   [2,'Đồng bằng sông Hồng có thế mạnh nổi bật nào?','sản xuất lương thực (lúa), dân cư đông, kinh tế phát triển','khai thác dầu khí','trồng cà phê','nuôi tôm hùm'],
   [3,'Nêu một đặc điểm của vùng Đồng bằng sông Hồng.','Dân cư đông đúc, đất phù sa màu mỡ, là vựa lúa lớn, có thủ đô Hà Nội (HS tự nêu).']]},
  {cd:'Bài 14 (Địa lí): Vùng Bắc Trung Bộ',q:[
   [1,'Vùng Bắc Trung Bộ nằm ở khu vực nào của nước ta?','miền Trung (phía bắc Trung Bộ)','phía bắc đồng bằng','Nam Bộ','Tây Nguyên'],
   [2,'Vùng Bắc Trung Bộ thường chịu thiên tai nào?','bão, lũ lụt, hạn hán','động đất lớn','sóng thần hằng năm','băng tuyết'],
   [3,'Nêu một thế mạnh của vùng Bắc Trung Bộ.','VD: kinh tế biển, du lịch, trồng rừng, cây công nghiệp (HS tự nêu).']]},
  {cd:'Bài 16 (Địa lí): Vùng Duyên hải Nam Trung Bộ và Tây Nguyên',q:[
   [1,'Tây Nguyên có thế mạnh nổi bật về cây trồng nào?','cây công nghiệp (cà phê, cao su, hồ tiêu)','cây lúa nước','cây chè','không có'],
   [2,'Vùng Duyên hải Nam Trung Bộ có thế mạnh về ngành nào?','kinh tế biển (đánh bắt, nuôi trồng thủy sản, du lịch biển)','khai thác than','trồng lúa nước','không có'],
   [3,'Nêu một thế mạnh của Tây Nguyên.','VD: trồng cây công nghiệp (cà phê), thủy điện, lâm nghiệp (HS tự nêu).']]},
  {cd:'Bài 17 (Địa lí): Vùng Đông Nam Bộ',q:[
   [1,'Vùng Đông Nam Bộ là vùng kinh tế như thế nào của nước ta?','phát triển năng động nhất','kém phát triển nhất','không có kinh tế','chỉ nông nghiệp lạc hậu'],
   [2,'Trung tâm kinh tế lớn nhất của Đông Nam Bộ là thành phố nào?','Thành phố Hồ Chí Minh','Hà Nội','Huế','Đà Nẵng'],
   [3,'Nêu một thế mạnh của vùng Đông Nam Bộ.','VD: công nghiệp phát triển, dầu khí, dịch vụ, thu hút đầu tư (HS tự nêu).']]},
  {cd:'Bài 19 (Địa lí): Vùng Đồng bằng sông Cửu Long',q:[
   [1,'Đồng bằng sông Cửu Long là vựa lúa lớn nhất nước ta nhờ điều gì?','đất phù sa màu mỡ, sông ngòi dày đặc','khí hậu lạnh','nhiều núi cao','ít nước'],
   [2,'Đồng bằng sông Cửu Long đứng đầu cả nước về sản xuất gì?','lúa gạo và thủy sản','than đá','dầu mỏ','cà phê'],
   [3,'Nêu một thế mạnh của vùng Đồng bằng sông Cửu Long.','VD: sản xuất lúa gạo, nuôi trồng và đánh bắt thủy sản, cây ăn quả (HS tự nêu).']]},
  {cd:'Bài 20 (Địa lí): Thực hành: Tác động của biến đổi khí hậu đối với Đồng bằng sông Cửu Long',q:[
   [1,'Biến đổi khí hậu tác động như thế nào đến Đồng bằng sông Cửu Long?','ngập lụt, xâm nhập mặn, nước biển dâng','không ảnh hưởng gì','làm đất tốt hơn','hết thiên tai'],
   [2,'Biện pháp nào giúp ứng phó với biến đổi khí hậu ở vùng này?','chuyển đổi cây trồng phù hợp, trữ nước ngọt, trồng rừng ngập mặn','phá rừng','xả thải ra sông','không làm gì'],
   [3,'Nêu một biện pháp thích ứng với biến đổi khí hậu ở Đồng bằng sông Cửu Long.','VD: trồng rừng ngập mặn, chuyển đổi giống cây chịu mặn, trữ nước ngọt (HS tự nêu).']]},
  {cd:'Bài 21 (Địa lí): Phát triển tổng hợp kinh tế và bảo vệ tài nguyên, môi trường biển đảo',q:[
   [1,'Phát triển tổng hợp kinh tế biển gồm những ngành nào?','đánh bắt, nuôi trồng thủy sản, du lịch, giao thông, khai thác dầu khí','chỉ trồng lúa','chỉ khai thác than','chỉ chăn nuôi'],
   [2,'Vì sao cần bảo vệ tài nguyên, môi trường biển đảo?','vì biển cung cấp nhiều tài nguyên và có vị trí quan trọng, đang bị ô nhiễm','vì biển không có giá trị','không cần bảo vệ','vì biển vô hạn'],
   [3,'Nêu một biện pháp bảo vệ tài nguyên, môi trường biển đảo.','VD: khai thác hợp lí, không xả rác ra biển, bảo vệ rạn san hô và nguồn lợi hải sản (HS tự nêu).']]}
 );
 }


 /* ---- Ngữ văn: ngân hàng theo từng VĂN BẢN ĐỌC (Kết nối tri thức) ---- */
 if(typeof NH!=='undefined' && NH['Ngữ văn']){
 const NV=NH['Ngữ văn'];
 NV[6].push(
  {cd:'Nếu cậu muốn có một người bạn',q:[
   [1,'Văn bản "Nếu cậu muốn có một người bạn" được trích từ tác phẩm nào?','Hoàng tử bé','Dế Mèn phiêu lưu kí','Đất rừng phương Nam','Không gia đình'],
   [1,'Tác giả của "Hoàng tử bé" (có đoạn trích "Nếu cậu muốn có một người bạn") là ai?','Ăng-toan đơ Xanh-tơ Ê-xu-pe-ri','An-đéc-xen','Ta-go','Grimm'],
   [2,'Theo lời cáo, muốn có một người bạn thì cần phải làm gì?','cảm hóa nhau (kiên nhẫn làm quen, gắn bó)','mua quà cho nhau','ở gần nhà nhau','giống hệt nhau'],
   [3,'Qua cuộc trò chuyện giữa hoàng tử bé và con cáo, em hiểu thế nào là tình bạn?','HS tự nêu: tình bạn cần sự cảm hóa, thấu hiểu, gắn bó và trách nhiệm với nhau.']]},
  {cd:'Bắt nạt',q:[
   [1,'Bài thơ "Bắt nạt" của tác giả nào?','Nguyễn Thế Hoàng Linh','Xuân Quỳnh','Trần Đăng Khoa','Mai Văn Phấn'],
   [1,'"Bắt nạt" được viết theo thể loại nào?','thơ','truyện ngắn','kí','kịch'],
   [2,'Thái độ của tác giả đối với việc bắt nạt là gì?','phê phán, không đồng tình với hành vi bắt nạt','cổ vũ bắt nạt','thờ ơ','khuyên nên bắt nạt'],
   [3,'Theo em, vì sao không nên bắt nạt người khác?','HS tự nêu: bắt nạt gây tổn thương, là hành vi xấu; cần đối xử tôn trọng, thân thiện với bạn bè.']]},
  {cd:'Chuyện cổ tích về loài người',q:[
   [1,'Bài thơ "Chuyện cổ tích về loài người" của tác giả nào?','Xuân Quỳnh','Tố Hữu','Xuân Diệu','Huy Cận'],
   [1,'"Chuyện cổ tích về loài người" thuộc thể loại nào?','thơ','truyện cổ tích','truyện ngắn','kí'],
   [2,'Theo bài thơ, ai sinh ra trước nhất trên trái đất?','trẻ con','người mẹ','ông mặt trời','cây cối'],
   [3,'Bài thơ muốn nói lên điều gì về trẻ em?','HS tự nêu: trẻ em được yêu thương, chăm sóc; mọi thứ trên đời sinh ra là vì trẻ em.']]},
  {cd:'Mây và sóng',q:[
   [1,'Bài thơ "Mây và sóng" của tác giả nào?','Ta-go','Puskin','Lý Bạch','Ê-xu-pe-ri'],
   [1,'Ta-go là nhà thơ của nước nào?','Ấn Độ','Nga','Pháp','Trung Quốc'],
   [2,'Trong bài thơ, em bé đã từ chối lời rủ của mây và sóng để làm gì?','ở lại chơi cùng mẹ','đi theo mây','đi theo sóng','đi học'],
   [3,'Bài thơ "Mây và sóng" ca ngợi điều gì?','HS tự nêu: tình mẫu tử thiêng liêng, bất diệt và trí tưởng tượng phong phú của trẻ thơ.']]},
  {cd:'Cô bé bán diêm',q:[
   [1,'Truyện "Cô bé bán diêm" của tác giả nào?','An-đéc-xen','Grimm','Ta-go','Ê-xu-pe-ri'],
   [1,'An-đéc-xen là nhà văn của nước nào?','Đan Mạch','Đức','Pháp','Ấn Độ'],
   [2,'Mỗi lần quẹt que diêm, cô bé nhìn thấy gì?','những hình ảnh ấm áp, hạnh phúc (lò sưởi, bàn ăn, cây thông, bà)','bóng tối','tuyết rơi','người qua đường'],
   [3,'Qua số phận cô bé bán diêm, tác giả muốn gửi gắm điều gì?','HS tự nêu: niềm cảm thương với những em bé bất hạnh và lời nhắc về lòng yêu thương con người.']]},
  {cd:'Con chào mào',q:[
   [1,'Bài thơ "Con chào mào" của tác giả nào?','Mai Văn Phấn','Xuân Quỳnh','Thép Mới','Nguyên Hồng'],
   [1,'"Con chào mào" thuộc thể loại nào?','thơ','truyện','kí','kịch'],
   [2,'Hình ảnh con chào mào trong bài thơ gợi lên điều gì?','vẻ đẹp của thiên nhiên và khao khát được tự do','sự buồn bã','nỗi cô đơn','cảnh chiến tranh'],
   [3,'Qua bài thơ, em cảm nhận được tình cảm gì của tác giả với thiên nhiên?','HS tự nêu: tình yêu thiên nhiên, trân trọng vẻ đẹp và sự tự do của muôn loài.']]},
  {cd:'Chùm ca dao về quê hương, đất nước',q:[
   [1,'"Chùm ca dao về quê hương, đất nước" thuộc loại văn học nào?','văn học dân gian (ca dao)','văn học hiện đại','văn học trung đại','văn học nước ngoài'],
   [2,'Ca dao về quê hương, đất nước thường thể hiện tình cảm gì?','tình yêu, niềm tự hào về quê hương, đất nước','sự chán ghét','nỗi sợ hãi','sự dửng dưng'],
   [3,'Hãy nêu cảm nhận của em về một bài ca dao về quê hương mà em thích.','HS tự nêu theo cảm nhận cá nhân về vẻ đẹp quê hương, đất nước trong ca dao.']]},
  {cd:'Cây tre Việt Nam',q:[
   [1,'Văn bản "Cây tre Việt Nam" của tác giả nào?','Thép Mới','Nguyên Hồng','Tố Hữu','Nguyễn Tuân'],
   [2,'Hình ảnh cây tre trong văn bản tượng trưng cho điều gì?','con người và dân tộc Việt Nam (cần cù, kiên cường, thủy chung)','sự giàu sang','sự yếu đuối','thiên nhiên nước ngoài'],
   [3,'Vì sao cây tre được coi là biểu tượng của dân tộc Việt Nam?','HS tự nêu: tre gắn bó với đời sống, lao động, chiến đấu; mang phẩm chất ngay thẳng, bền bỉ, đoàn kết của người Việt.']]},
  {cd:'Cửu Long Giang ta ơi',q:[
   [1,'Bài thơ "Cửu Long Giang ta ơi" của tác giả nào?','Nguyên Hồng','Thép Mới','Tế Hanh','Xuân Quỳnh'],
   [1,'"Cửu Long Giang ta ơi" thuộc thể loại nào?','thơ','truyện ngắn','kí','kịch'],
   [2,'Bài thơ thể hiện tình cảm gì của tác giả?','tình yêu quê hương, đất nước, dòng sông Cửu Long','nỗi buồn chia li','sự tức giận','sự thờ ơ'],
   [3,'Hình ảnh dòng sông Cửu Long trong bài thơ gợi cho em suy nghĩ gì?','HS tự nêu: niềm tự hào về vẻ đẹp, sự trù phú của quê hương, đất nước.']]},
  {cd:'Sơn Tinh, Thủy Tinh',q:[
   [1,'"Sơn Tinh, Thủy Tinh" (Ngữ văn 6) thuộc thể loại nào?','truyền thuyết','cổ tích','ngụ ngôn','truyện cười'],
   [2,'Truyện "Sơn Tinh, Thủy Tinh" nhằm giải thích hiện tượng gì trong tự nhiên?','hiện tượng lũ lụt hằng năm','hiện tượng nhật thực','hiện tượng động đất','hiện tượng sấm sét'],
   [3,'Nhân vật Sơn Tinh tượng trưng cho điều gì?','HS tự nêu: tượng trưng cho sức mạnh và ước mơ chế ngự thiên tai, lũ lụt của người Việt cổ.']]},
  {cd:'Thạch Sanh',q:[
   [1,'Truyện "Thạch Sanh" thuộc thể loại nào?','cổ tích','truyền thuyết','ngụ ngôn','truyện cười'],
   [2,'Nhân vật Lí Thông trong truyện tiêu biểu cho loại người nào?','gian xảo, độc ác, tham lam','tốt bụng','dũng cảm','chăm chỉ'],
   [3,'Truyện "Thạch Sanh" thể hiện ước mơ gì của nhân dân?','HS tự nêu: ước mơ về cái thiện thắng cái ác, người tốt được đền đáp xứng đáng.']]},
  {cd:'Cây khế',q:[
   [1,'Truyện "Cây khế" thuộc thể loại nào?','cổ tích','truyền thuyết','ngụ ngôn','thần thoại'],
   [2,'Người em trong truyện "Cây khế" là người như thế nào?','hiền lành, thật thà, chăm chỉ','tham lam','độc ác','lười biếng'],
   [3,'Truyện "Cây khế" khuyên chúng ta điều gì?','HS tự nêu: ở hiền gặp lành, tham lam sẽ nhận hậu quả; đề cao lòng trung thực, nhân hậu.']]},
  {cd:'Vua chích chòe',q:[
   [1,'Truyện "Vua chích chòe" thuộc thể loại nào?','cổ tích','truyền thuyết','ngụ ngôn','truyện cười'],
   [2,'Qua truyện, nàng công chúa kiêu ngạo cuối cùng đã thay đổi như thế nào?','trở nên khiêm nhường, biết yêu lao động','kiêu ngạo hơn','không thay đổi','bỏ đi'],
   [3,'Truyện "Vua chích chòe" nhằm phê phán và khuyên nhủ điều gì?','HS tự nêu: phê phán thói kiêu ngạo, khuyên con người sống khiêm tốn, biết trân trọng lao động.']]},
  {cd:'Xem người ta kìa!',q:[
   [1,'Văn bản "Xem người ta kìa!" thuộc kiểu văn bản nào?','nghị luận','tự sự','miêu tả','biểu cảm'],
   [2,'Văn bản bàn về vấn đề gì?','cái riêng biệt của mỗi người (mỗi người cần được là chính mình)','cách nấu ăn','cách học toán','thời tiết'],
   [3,'Theo em, vì sao mỗi người cần biết tôn trọng sự khác biệt của mình và của người khác?','HS tự nêu: mỗi người là một cá thể riêng; tôn trọng khác biệt giúp mỗi người phát huy giá trị và sống hòa hợp.']]},
  {cd:'Các loài chung sống với nhau như thế nào?',q:[
   [1,'Văn bản "Các loài chung sống với nhau như thế nào?" thuộc kiểu văn bản nào?','văn bản thông tin','truyện cổ tích','thơ','truyện cười'],
   [2,'Văn bản cung cấp thông tin về điều gì?','mối quan hệ giữa các loài sinh vật trong tự nhiên','cách làm bánh','lịch sử Việt Nam','luật giao thông'],
   [3,'Qua văn bản, em rút ra bài học gì về việc bảo vệ sự đa dạng của các loài?','HS tự nêu: các loài phụ thuộc lẫn nhau; cần bảo vệ môi trường và đa dạng sinh học để giữ cân bằng tự nhiên.']]}
 );
 NV[7].push(
  {cd:'Đi lấy mật',q:[
   [1,'Đoạn trích "Đi lấy mật" được trích từ tác phẩm nào?','Đất rừng phương Nam','Dế Mèn phiêu lưu kí','Quê nội','Tuổi thơ dữ dội'],
   [1,'Tác giả của "Đất rừng phương Nam" (có đoạn trích "Đi lấy mật") là ai?','Đoàn Giỏi','Nguyễn Nhật Ánh','Tô Hoài','Võ Quảng'],
   [2,'Đoạn trích kể về công việc gì của người dân rừng U Minh?','đi lấy mật ong trong rừng','đánh cá','trồng lúa','săn thú'],
   [3,'Qua đoạn trích, em cảm nhận gì về thiên nhiên và con người vùng đất phương Nam?','HS tự nêu: thiên nhiên hoang sơ, trù phú; con người giàu kinh nghiệm, gắn bó với rừng.']]},
  {cd:'Ngàn sao làm việc',q:[
   [1,'Bài thơ "Ngàn sao làm việc" của tác giả nào?','Võ Quảng','Tế Hanh','Thanh Thảo','Hoàng Tố Nguyên'],
   [1,'"Ngàn sao làm việc" thuộc thể loại nào?','thơ','truyện ngắn','kí','kịch'],
   [2,'Bài thơ miêu tả cảnh gì?','bầu trời đêm với những ngôi sao','cảnh biển','cảnh chợ','cảnh chiến đấu'],
   [3,'Bài thơ gợi cho em cảm xúc gì về thiên nhiên?','HS tự nêu: cảm nhận vẻ đẹp kì diệu, sống động của bầu trời đêm và tình yêu thiên nhiên.']]},
  {cd:'Gặp lá cơm nếp',q:[
   [1,'Bài thơ "Gặp lá cơm nếp" của tác giả nào?','Thanh Thảo','Tế Hanh','Võ Quảng','Vũ Bằng'],
   [2,'Hình ảnh "lá cơm nếp" gợi cho người con nhớ về ai?','người mẹ và quê hương','người bạn','thầy cô','đồng đội'],
   [3,'Bài thơ thể hiện tình cảm gì?','HS tự nêu: tình yêu mẹ, tình yêu quê hương, đất nước sâu nặng của người lính.']]},
  {cd:'Quê hương',q:[
   [1,'Bài thơ "Quê hương" (Ngữ văn 7) của tác giả nào?','Tế Hanh','Đỗ Trung Quân','Giang Nam','Tố Hữu'],
   [2,'Bài thơ "Quê hương" của Tế Hanh viết về vùng quê nào?','một làng chài ven biển','một vùng núi','một thành phố','một đồng bằng lúa'],
   [3,'Bài thơ thể hiện tình cảm gì của tác giả?','HS tự nêu: nỗi nhớ và tình yêu tha thiết với quê hương làng chài.']]},
  {cd:'Gò Me',q:[
   [1,'Bài thơ "Gò Me" của tác giả nào?','Hoàng Tố Nguyên','Tế Hanh','Thanh Thảo','Võ Quảng'],
   [2,'Bài thơ "Gò Me" thể hiện tình cảm gì của tác giả?','nỗi nhớ và tình yêu quê hương Nam Bộ','sự chán ghét quê hương','nỗi sợ hãi','sự thờ ơ'],
   [3,'Hình ảnh quê hương trong bài thơ hiện lên như thế nào?','HS tự nêu: quê hương tươi đẹp, trù phú, bình dị và thân thương.']]},
  {cd:'Tháng Giêng, mơ về trăng non rét ngọt',q:[
   [1,'Văn bản "Tháng Giêng, mơ về trăng non rét ngọt" của tác giả nào?','Vũ Bằng','Thạch Lam','Nguyễn Tuân','Hoàng Phủ Ngọc Tường'],
   [1,'Văn bản "Tháng Giêng, mơ về trăng non rét ngọt" thuộc thể loại nào?','tùy bút','truyện ngắn','thơ','kịch'],
   [2,'Văn bản viết về cảnh sắc và không khí mùa nào ở miền Bắc?','mùa xuân (tháng Giêng)','mùa hè','mùa thu','mùa đông'],
   [3,'Qua văn bản, em cảm nhận được tình cảm gì của tác giả?','HS tự nêu: tình yêu thiên nhiên, nỗi nhớ quê hương miền Bắc tha thiết.']]},
  {cd:'Chuyện cơm hến',q:[
   [1,'Văn bản "Chuyện cơm hến" của tác giả nào?','Hoàng Phủ Ngọc Tường','Vũ Bằng','Thạch Lam','Nguyễn Tuân'],
   [2,'"Chuyện cơm hến" viết về món ăn đặc sản của vùng nào?','xứ Huế','Hà Nội','Sài Gòn','Nam Định'],
   [3,'Qua văn bản, tác giả thể hiện tình cảm gì?','HS tự nêu: tình yêu, niềm tự hào về món ăn và văn hóa ẩm thực quê hương xứ Huế.']]},
  {cd:'Một số câu tục ngữ Việt Nam',q:[
   [1,'"Một số câu tục ngữ Việt Nam" thuộc loại văn học nào?','văn học dân gian (tục ngữ)','văn học hiện đại','văn học trung đại','văn học nước ngoài'],
   [2,'Tục ngữ thường có đặc điểm gì về hình thức?','ngắn gọn, có vần, dễ nhớ','dài dòng','không vần điệu','viết thành đoạn văn dài'],
   [3,'Hãy nêu ý nghĩa của một câu tục ngữ Việt Nam mà em biết.','HS tự nêu: tục ngữ đúc kết kinh nghiệm sống, lao động, ứng xử của nhân dân.']]},
  {cd:'Con hổ có nghĩa',q:[
   [1,'Truyện "Con hổ có nghĩa" thuộc loại truyện nào?','truyện trung đại (có tính giáo huấn)','truyện cổ tích','truyện cười','truyện khoa học viễn tưởng'],
   [2,'Truyện "Con hổ có nghĩa" đề cao phẩm chất gì?','lòng biết ơn, ân nghĩa','lòng tham','sự dối trá','sự lười biếng'],
   [3,'Qua truyện, tác giả muốn khuyên con người điều gì?','HS tự nêu: sống phải biết ơn, trọng ân nghĩa; con vật còn có nghĩa, con người càng phải sống có tình nghĩa.']]},
  {cd:'Cuộc chạm trán trên đại dương',q:[
   [1,'Đoạn trích "Cuộc chạm trán trên đại dương" được trích từ tác phẩm nào?','Hai vạn dặm dưới đáy biển','Dế Mèn phiêu lưu kí','Đất rừng phương Nam','Robinson Crusoe'],
   [1,'Tác giả của "Hai vạn dặm dưới đáy biển" là ai?','Giuyn Véc-nơ','An-đéc-xen','Đoàn Giỏi','Ta-go'],
   [2,'"Cuộc chạm trán trên đại dương" thuộc loại truyện nào?','truyện khoa học viễn tưởng','truyện cổ tích','truyện lịch sử','truyện cười'],
   [3,'Đoạn trích thể hiện điều gì về trí tưởng tượng của nhà văn?','HS tự nêu: trí tưởng tượng phong phú về khoa học, khơi gợi khát vọng khám phá đại dương và thế giới.']]},
  {cd:'Đường vào trung tâm vũ trụ',q:[
   [1,'"Đường vào trung tâm vũ trụ" thuộc loại truyện nào?','truyện khoa học viễn tưởng','truyện cổ tích','truyện lịch sử','truyện cười'],
   [2,'Văn bản khơi gợi ở người đọc điều gì?','trí tưởng tượng và niềm say mê khám phá vũ trụ, khoa học','sự sợ hãi','lòng tham','sự chán nản'],
   [3,'Qua văn bản, em có suy nghĩ gì về vai trò của khoa học và trí tưởng tượng?','HS tự nêu: khoa học và trí tưởng tượng mở ra những chân trời khám phá mới cho con người.']]},
  {cd:'Bản đồ dẫn đường',q:[
   [1,'Văn bản "Bản đồ dẫn đường" thuộc kiểu văn bản nào?','nghị luận','tự sự','miêu tả','thuyết minh'],
   [2,'"Bản đồ dẫn đường" trong văn bản là hình ảnh ẩn dụ cho điều gì?','cách nhìn nhận cuộc sống và con người của mỗi người','một tấm bản đồ địa lí','một cuốn sách','một trò chơi'],
   [3,'Qua văn bản, tác giả khuyên chúng ta điều gì?','HS tự nêu: mỗi người cần tự tìm cho mình cách nhìn, lẽ sống và con đường riêng trong cuộc đời.']]},
  {cd:'Văn bản truyện ngụ ngôn',q:[
   [1,'Truyện ngụ ngôn thuộc loại văn học nào?','văn học dân gian','văn học hiện đại','văn học trung đại','văn học nước ngoài'],
   [2,'Truyện ngụ ngôn thường nhằm mục đích gì?','nêu bài học, lời khuyên về đạo lí, cách sống','giải trí đơn thuần','ghi chép lịch sử','miêu tả thiên nhiên'],
   [3,'Hãy nêu bài học rút ra từ một truyện ngụ ngôn mà em biết.','HS tự nêu: truyện ngụ ngôn mượn chuyện loài vật, đồ vật để khuyên răn con người bài học sống.']]}
 );
 NV[8].push(
  {cd:'Lá cờ thêu sáu chữ vàng',q:[
   [1,'Tác phẩm "Lá cờ thêu sáu chữ vàng" của tác giả nào?','Nguyễn Huy Tưởng','Nguyễn Nhật Ánh','Tô Hoài','Đoàn Giỏi'],
   [1,'"Lá cờ thêu sáu chữ vàng" thuộc thể loại nào?','truyện lịch sử','truyện cổ tích','thơ','kịch'],
   [2,'Nhân vật chính Trần Quốc Toản gắn với sáu chữ vàng nào trên lá cờ?','"Phá cường địch, báo hoàng ân"','"Sát Thát"','"Quyết chiến quyết thắng"','"Trung quân ái quốc"'],
   [3,'Nhân vật Trần Quốc Toản thể hiện phẩm chất gì?','HS tự nêu: lòng yêu nước, căm thù giặc, ý chí quyết tâm đánh giặc cứu nước dù tuổi còn nhỏ.']]},
  {cd:'Ca Huế trên sông Hương',q:[
   [1,'Văn bản "Ca Huế trên sông Hương" thuộc kiểu văn bản nào?','văn bản thông tin','truyện ngắn','thơ','kịch'],
   [2,'Văn bản giới thiệu nét văn hóa đặc sắc nào của xứ Huế?','ca Huế (nghe ca Huế trên sông Hương)','làng nghề gốm','lễ hội đua thuyền','ẩm thực đường phố'],
   [3,'Qua văn bản, em hiểu gì về giá trị của ca Huế?','HS tự nêu: ca Huế là di sản văn hóa độc đáo, cần được trân trọng và gìn giữ.']]},
  {cd:'Thu điếu',q:[
   [1,'Bài thơ "Thu điếu" của tác giả nào?','Nguyễn Khuyến','Tú Xương','Nguyễn Du','Hồ Xuân Hương'],
   [1,'"Thu điếu" được viết theo thể thơ nào?','thất ngôn bát cú Đường luật','lục bát','tự do','song thất lục bát'],
   [2,'"Thu điếu" có nghĩa là gì?','mùa thu câu cá','mùa thu ngắm trăng','mùa thu uống rượu','mùa thu tiễn bạn'],
   [3,'Bài thơ "Thu điếu" thể hiện điều gì?','HS tự nêu: vẻ đẹp tĩnh lặng của mùa thu làng quê Bắc Bộ và tâm trạng của nhà thơ.']]},
  {cd:'Tinh thần yêu nước của nhân dân ta',q:[
   [1,'Văn bản "Tinh thần yêu nước của nhân dân ta" của tác giả nào?','Hồ Chí Minh','Phạm Văn Đồng','Trường Chinh','Tố Hữu'],
   [1,'"Tinh thần yêu nước của nhân dân ta" thuộc kiểu văn bản nào?','nghị luận','tự sự','miêu tả','biểu cảm'],
   [2,'Văn bản khẳng định điều gì về nhân dân ta?','nhân dân ta có một lòng nồng nàn yêu nước','nhân dân ta thờ ơ','nhân dân ta chỉ lo làm ăn','nhân dân ta sợ giặc'],
   [3,'Theo em, tinh thần yêu nước cần được thể hiện như thế nào trong thời bình?','HS tự nêu: học tập, lao động, xây dựng và bảo vệ Tổ quốc, sống có trách nhiệm với cộng đồng.']]},
  {cd:'Lễ xướng danh khoa Đinh Dậu',q:[
   [1,'Bài thơ "Lễ xướng danh khoa Đinh Dậu" của tác giả nào?','Trần Tế Xương (Tú Xương)','Nguyễn Khuyến','Nguyễn Du','Hồ Xuân Hương'],
   [1,'"Lễ xướng danh khoa Đinh Dậu" thuộc loại thơ nào?','thơ trào phúng','thơ tình','thơ cách mạng','thơ thiếu nhi'],
   [2,'Bài thơ phê phán, châm biếm điều gì?','cảnh thi cử nhốn nháo, lố lăng thời thực dân phong kiến','thiên nhiên mùa thu','tình bạn','cảnh lao động'],
   [3,'Qua bài thơ, em cảm nhận được tâm trạng gì của tác giả?','HS tự nêu: nỗi đau xót, mỉa mai trước cảnh mất nước và sự suy đồi của nền khoa cử.']]},
  {cd:'Một số giọng điệu của tiếng cười trong thơ trào phúng',q:[
   [1,'Văn bản "Một số giọng điệu của tiếng cười trong thơ trào phúng" thuộc kiểu văn bản nào?','nghị luận văn học','truyện ngắn','thơ','kịch'],
   [2,'Văn bản bàn về điều gì?','các giọng điệu của tiếng cười trong thơ trào phúng','cách làm thơ lục bát','lịch sử dân tộc','cách nấu ăn'],
   [3,'Theo em, tiếng cười trong thơ trào phúng có tác dụng gì?','HS tự nêu: phê phán thói hư tật xấu, cái lố bịch trong xã hội, hướng con người tới cái tốt đẹp.']]},
  {cd:'Chùm truyện cười dân gian Việt Nam',q:[
   [1,'"Chùm truyện cười dân gian Việt Nam" thuộc loại văn học nào?','văn học dân gian (truyện cười)','văn học hiện đại','văn học trung đại','văn học nước ngoài'],
   [2,'Truyện cười dân gian nhằm mục đích gì?','mua vui và phê phán thói hư tật xấu','ghi chép lịch sử','miêu tả thiên nhiên','ca ngợi vua chúa'],
   [3,'Hãy nêu ý nghĩa của một truyện cười dân gian mà em biết.','HS tự nêu: truyện cười tạo tiếng cười giải trí, đồng thời phê phán, châm biếm thói xấu trong xã hội.']]},
  {cd:'Bếp lửa',q:[
   [1,'Bài thơ "Bếp lửa" của tác giả nào?','Bằng Việt','Chính Hữu','Nguyễn Đình Thi','Phạm Tiến Duật'],
   [2,'Hình ảnh "bếp lửa" trong bài thơ gắn với kỉ niệm về ai?','người bà','người mẹ','người cha','người bạn'],
   [3,'Bài thơ "Bếp lửa" thể hiện tình cảm gì?','HS tự nêu: tình bà cháu sâu nặng và lòng biết ơn, nỗi nhớ về bà, về quê hương.']]},
  {cd:'Lặng lẽ Sa Pa',q:[
   [1,'Truyện ngắn "Lặng lẽ Sa Pa" của tác giả nào?','Nguyễn Thành Long','Nguyễn Minh Châu','Kim Lân','Lê Minh Khuê'],
   [2,'Nhân vật chính anh thanh niên trong truyện làm công việc gì?','công tác khí tượng trên đỉnh núi cao','lái xe','dạy học','trồng rau'],
   [3,'Nhân vật anh thanh niên tiêu biểu cho vẻ đẹp nào của con người lao động mới?','HS tự nêu: thầm lặng cống hiến, yêu nghề, có tinh thần trách nhiệm và lẽ sống đẹp.']]},
  {cd:'Lá đỏ',q:[
   [1,'Bài thơ "Lá đỏ" của tác giả nào?','Nguyễn Đình Thi','Phạm Tiến Duật','Chính Hữu','Bằng Việt'],
   [2,'Bài thơ "Lá đỏ" viết về đề tài gì?','cuộc kháng chiến chống Mỹ (Trường Sơn)','mùa thu Hà Nội','tình bạn','lao động sản xuất'],
   [3,'Bài thơ thể hiện tình cảm, cảm hứng gì?','HS tự nêu: niềm tin, khí thế hào hùng và tình yêu đất nước trong kháng chiến.']]},
  {cd:'Những ngôi sao xa xôi',q:[
   [1,'Truyện ngắn "Những ngôi sao xa xôi" của tác giả nào?','Lê Minh Khuê','Nguyễn Thành Long','Kim Lân','Nguyễn Minh Châu'],
   [2,'Truyện viết về những nhân vật nào?','ba cô gái thanh niên xung phong trên tuyến đường Trường Sơn','ba người lính lái xe','ba học sinh','ba người nông dân'],
   [3,'Qua truyện, em cảm nhận gì về thế hệ trẻ Việt Nam thời kháng chiến chống Mỹ?','HS tự nêu: dũng cảm, lạc quan, giàu tình đồng đội và lí tưởng sống cao đẹp.']]},
  {cd:'Nhà thơ của quê hương làng cảnh Việt Nam',q:[
   [1,'Văn bản "Nhà thơ của quê hương làng cảnh Việt Nam" thuộc kiểu văn bản nào?','nghị luận văn học','truyện ngắn','thơ','kịch'],
   [2,'Văn bản viết về nhà thơ nào?','Nguyễn Khuyến','Tú Xương','Nguyễn Du','Hồ Xuân Hương'],
   [3,'Qua văn bản, em hiểu thêm điều gì về thơ viết về làng quê của Nguyễn Khuyến?','HS tự nêu: thơ Nguyễn Khuyến vẽ nên vẻ đẹp bình dị, thân thuộc của làng cảnh Việt Nam.']]},
  {cd:'Đọc văn - cuộc chơi tìm ý nghĩa',q:[
   [1,'Văn bản "Đọc văn - cuộc chơi tìm ý nghĩa" thuộc kiểu văn bản nào?','nghị luận','tự sự','miêu tả','thuyết minh'],
   [2,'Văn bản bàn về vấn đề gì?','việc đọc văn và tìm ý nghĩa của tác phẩm văn học','cách làm thơ','lịch sử dân tộc','cách nấu ăn'],
   [3,'Theo em, vì sao đọc văn được ví như "cuộc chơi tìm ý nghĩa"?','HS tự nêu: mỗi người đọc tự khám phá, cảm nhận và tạo ra ý nghĩa riêng cho tác phẩm.']]}
 );
 NV[9].push(
  {cd:'Sơn Tinh, Thủy Tinh',q:[
   [1,'Bài thơ "Sơn Tinh, Thủy Tinh" (Ngữ văn 9) của tác giả nào?','Nguyễn Nhược Pháp','Tản Đà','Thế Lữ','Xuân Diệu'],
   [1,'"Sơn Tinh, Thủy Tinh" (Ngữ văn 9) thuộc thể loại nào?','thơ','truyền thuyết','truyện cổ tích','kịch'],
   [2,'Bài thơ lấy cảm hứng từ câu chuyện dân gian nào?','truyền thuyết Sơn Tinh, Thủy Tinh','Thánh Gióng','Thạch Sanh','Tấm Cám'],
   [3,'Bài thơ của Nguyễn Nhược Pháp thể hiện điều gì?','HS tự nêu: cách kể mới mẻ, lãng mạn, hóm hỉnh về câu chuyện truyền thuyết quen thuộc.']]},
  {cd:'Dế chọi',q:[
   [1,'"Dế chọi" được trích từ tác phẩm nổi tiếng nào?','Liêu trai chí dị','Truyền kì mạn lục','Truyện Kiều','Hoàng Lê nhất thống chí'],
   [1,'"Dế chọi" thuộc loại truyện nào?','truyện truyền kì (có yếu tố kì ảo)','truyện cười','truyện khoa học viễn tưởng','truyện lịch sử'],
   [2,'Truyện "Dế chọi" phê phán điều gì?','thói ăn chơi, sưu thuế hà khắc gây khổ cho dân','lòng hiếu học','tình bạn','thiên nhiên'],
   [3,'Qua truyện, tác giả thể hiện thái độ gì?','HS tự nêu: cảm thương với số phận người dân và phê phán sự tàn bạo của chế độ phong kiến.']]},
  {cd:'Chuyện người con gái Nam Xương',q:[
   [1,'"Chuyện người con gái Nam Xương" được trích từ tác phẩm nào?','Truyền kì mạn lục','Liêu trai chí dị','Truyện Kiều','Hoàng Lê nhất thống chí'],
   [1,'Tác giả của "Truyền kì mạn lục" (có "Chuyện người con gái Nam Xương") là ai?','Nguyễn Dữ','Nguyễn Du','Nguyễn Trãi','Ngô Gia văn phái'],
   [2,'Nhân vật Vũ Nương trong truyện là người phụ nữ như thế nào?','thùy mị, nết na, thủy chung nhưng chịu oan khuất','độc ác','lười biếng','gian dối'],
   [3,'Qua số phận Vũ Nương, tác giả muốn nói lên điều gì?','HS tự nêu: cảm thương số phận oan nghiệt của người phụ nữ và phê phán xã hội phong kiến bất công.']]},
  {cd:'Tiếng đàn mưa',q:[
   [1,'"Tiếng đàn mưa" thuộc thể loại nào?','thơ','truyện ngắn','kí','kịch'],
   [2,'Bài thơ "Tiếng đàn mưa" gợi tả cảnh và cảm xúc gì?','cảnh mưa và nỗi buồn, nỗi nhớ man mác','cảnh vui chơi','cảnh chiến đấu','cảnh lao động'],
   [3,'Bài thơ thể hiện tâm trạng gì của nhân vật trữ tình?','HS tự nêu: nỗi buồn, sự cô đơn, nhớ nhung gợi lên từ âm thanh của mưa.']]},
  {cd:'Nỗi niềm chinh phụ',q:[
   [1,'"Nỗi niềm chinh phụ" được trích từ tác phẩm nào?','Chinh phụ ngâm','Truyện Kiều','Cung oán ngâm khúc','Truyền kì mạn lục'],
   [2,'"Chinh phụ" (người chinh phụ) trong tác phẩm là ai?','người vợ có chồng đi chinh chiến','người lính','người mẹ','người con gái'],
   [3,'Đoạn trích thể hiện tâm trạng gì của người chinh phụ?','HS tự nêu: nỗi cô đơn, buồn nhớ, mong mỏi và khát khao hạnh phúc lứa đôi.']]},
  {cd:'Kim - Kiều gặp gỡ',q:[
   [1,'Đoạn trích "Kim - Kiều gặp gỡ" thuộc tác phẩm nào?','Truyện Kiều','Chinh phụ ngâm','Lục Vân Tiên','Truyền kì mạn lục'],
   [1,'Tác giả của "Truyện Kiều" là ai?','Nguyễn Du','Nguyễn Dữ','Nguyễn Trãi','Hồ Xuân Hương'],
   [2,'Đoạn trích kể về cuộc gặp gỡ giữa hai nhân vật nào?','Thúy Kiều và Kim Trọng','Thúy Kiều và Từ Hải','Thúy Vân và Kim Trọng','Kiều và Thúc Sinh'],
   [3,'Đoạn trích thể hiện điều gì về tình cảm của Kim Trọng và Thúy Kiều?','HS tự nêu: mối tình đầu trong sáng, đẹp đẽ và những rung động đầu đời của đôi lứa.']]},
  {cd:'Tự tình (bài 2)',q:[
   [1,'Bài thơ "Tự tình (bài 2)" của tác giả nào?','Hồ Xuân Hương','Bà Huyện Thanh Quan','Đoàn Thị Điểm','Nguyễn Du'],
   [1,'"Tự tình (bài 2)" được viết theo thể thơ nào?','thất ngôn bát cú Đường luật','lục bát','song thất lục bát','tự do'],
   [2,'Bài thơ thể hiện tâm trạng gì của nhân vật trữ tình?','nỗi buồn, cô đơn và khát khao hạnh phúc của người phụ nữ','niềm vui sum họp','sự giận dữ','sự thờ ơ'],
   [3,'Qua bài thơ, em cảm nhận gì về thân phận người phụ nữ trong xã hội phong kiến?','HS tự nêu: chịu nhiều thiệt thòi, lỡ dở nhưng vẫn mạnh mẽ khát khao hạnh phúc.']]},
  {cd:'Phạm Xuân Ẩn - tên người như cuộc đời',q:[
   [1,'Văn bản "Phạm Xuân Ẩn - tên người như cuộc đời" thuộc kiểu văn bản nào?','văn bản thông tin (truyện kí về nhân vật)','truyện cổ tích','thơ','kịch'],
   [2,'Phạm Xuân Ẩn là nhân vật nổi tiếng trong lĩnh vực nào?','tình báo (nhà tình báo cách mạng Việt Nam)','âm nhạc','hội họa','thể thao'],
   [3,'Qua văn bản, em cảm nhận gì về nhân vật Phạm Xuân Ẩn?','HS tự nêu: một con người tài năng, mưu trí, giàu lòng yêu nước và cống hiến thầm lặng.']]},
  {cd:'Ba chàng sinh viên',q:[
   [1,'"Ba chàng sinh viên" thuộc loại truyện nào?','truyện trinh thám','truyện cổ tích','truyện lịch sử','truyện cười'],
   [2,'Đặc điểm nổi bật của truyện trinh thám là gì?','có vụ án, quá trình điều tra và suy luận để tìm ra sự thật','chỉ miêu tả thiên nhiên','chỉ kể chuyện tình cảm','ghi chép lịch sử'],
   [3,'Qua truyện, em thấy nhân vật thám tử cần có những phẩm chất gì?','HS tự nêu: quan sát tinh tường, suy luận logic, bình tĩnh và sắc sảo.']]},
  {cd:'Tình sông núi',q:[
   [1,'"Tình sông núi" thuộc thể loại nào?','thơ','truyện ngắn','kí','kịch'],
   [2,'Bài thơ "Tình sông núi" thể hiện tình cảm gì?','tình yêu quê hương, đất nước','nỗi buồn chia li','sự chán nản','sự thờ ơ'],
   [3,'Hình ảnh sông núi trong bài thơ gợi cho em suy nghĩ gì?','HS tự nêu: niềm tự hào, gắn bó và tình yêu sâu nặng với non sông đất nước.']]},
  {cd:'Văn hóa hoa – cây cảnh',q:[
   [1,'Văn bản "Văn hóa hoa – cây cảnh" thuộc kiểu văn bản nào?','văn bản thông tin','truyện cổ tích','thơ','kịch'],
   [2,'Văn bản cung cấp thông tin về điều gì?','thú chơi hoa, cây cảnh và ý nghĩa văn hóa của nó','cách nấu ăn','lịch sử chiến tranh','luật giao thông'],
   [3,'Qua văn bản, em hiểu gì về nét đẹp văn hóa chơi hoa, cây cảnh của người Việt?','HS tự nêu: thú chơi tao nhã, thể hiện tâm hồn, gu thẩm mĩ và đời sống tinh thần phong phú.']]}
 );
 }

})();
