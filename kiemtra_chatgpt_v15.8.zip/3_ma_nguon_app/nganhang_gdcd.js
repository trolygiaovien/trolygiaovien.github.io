/* ============================================================
   NGÂN HÀNG GIÁO DỤC CÔNG DÂN (THCS) — bổ sung cho đủ chuẩn
   Mỗi bài: ≥6 trắc nghiệm + ≥4 tự luận + có câu nâng cao (mức 4).
   Nguyên bản, bám SGK Kết nối tri thức. Lượt này: LỚP 6.
   TN [mức,'câu','ĐÚNG','sai','sai','sai'] · TL [mức,'câu','đáp án']
   ============================================================ */
(function(){
 if(typeof NH==='undefined')return;
 function add(mon,lop,cd,qs){
  if(!NH[mon])NH[mon]={};
  if(!Array.isArray(NH[mon][lop]))NH[mon][lop]=[];
  var arr=NH[mon][lop];
  var t=arr.find(function(x){return x.cd===cd;});
  if(!t){t=arr.find(function(x){return x.cd&&(x.cd.indexOf(cd)>=0||cd.indexOf(x.cd)>=0);});}
  if(!t){t={cd:cd,q:[]};arr.push(t);}
  if(!Array.isArray(t.q))t.q=[];
  qs.forEach(function(q){var tr=String(q[1]||'').trim();if(!t.q.some(function(e){return String(e[1]||'').trim()===tr;}))t.q.push(q);});
 }
 var M='Giáo dục công dân';

 /* -------- LỚP 6 -------- */
 add(M,6,'Bài 1: Tự hào về truyền thống gia đình, dòng họ',[
  [1,'Truyền thống gia đình, dòng họ là những giá trị tốt đẹp được hình thành và lưu truyền qua đâu?','Qua nhiều thế hệ','Qua một ngày','Chỉ của một người','Qua người ngoài'],
  [1,'Đâu là một truyền thống tốt đẹp của gia đình, dòng họ?','Hiếu học, yêu nước, nghề truyền thống','Lười lao động','Gây gổ','Cờ bạc'],
  [2,'Việc làm nào thể hiện giữ gìn truyền thống gia đình, dòng họ?','Tìm hiểu, trân trọng và tiếp nối nghề, nếp sống tốt đẹp','Chê bai dòng họ','Quên cội nguồn','Bỏ nghề truyền thống'],
  [2,'Vì sao cần tự hào về truyền thống gia đình, dòng họ?','Giúp ta có thêm kinh nghiệm, sức mạnh, sống tốt hơn và biết ơn tổ tiên','Để khoe khoang','Để coi thường người khác','Không có ý nghĩa gì'],
  [3,'Một bạn cho rằng gia đình không có ai nổi tiếng thì chẳng có gì để tự hào. Em có đồng ý không? Vì sao?','Không đồng ý. Mỗi gia đình đều có truyền thống tốt đẹp riêng (yêu thương, chăm chỉ, lương thiện...); tự hào không phải vì nổi tiếng mà vì những giá trị tốt đẹp được gìn giữ.'],
  [3,'Em sẽ làm gì để giữ gìn và phát huy truyền thống tốt đẹp của gia đình, dòng họ?','Tìm hiểu truyền thống; chăm ngoan, học giỏi; giữ nếp sống tốt; giới thiệu với mọi người; tiếp nối nghề hoặc nếp đẹp của gia đình.'],
  [4,'Theo em, giữ gìn truyền thống gia đình có mâu thuẫn với việc tiếp thu cái mới, hiện đại không? Vì sao?','Không mâu thuẫn. Cần giữ giá trị cốt lõi tốt đẹp đồng thời tiếp thu cái mới tiến bộ, loại bỏ hủ tục; kết hợp hài hòa giúp gia đình vừa giữ bản sắc vừa phát triển.']
 ]);
 add(M,6,'Bài 2: Yêu thương con người',[
  [1,'Yêu thương con người là gì?','Quan tâm, giúp đỡ, làm điều tốt cho người khác','Chỉ lo cho bản thân','Ghét bỏ người khác','Lợi dụng người khác'],
  [1,'Hành vi nào thể hiện lòng yêu thương con người?','Giúp đỡ người gặp khó khăn','Vô cảm trước nỗi đau của người khác','Bắt nạt bạn','Chế giễu người nghèo'],
  [2,'Biểu hiện nào trái với yêu thương con người?','Thờ ơ, ích kỉ, độc ác','Cảm thông','Chia sẻ','Giúp đỡ'],
  [2,'Vì sao cần yêu thương con người?','Mang lại niềm vui, giúp con người vượt khó, xã hội tốt đẹp hơn; người biết yêu thương được mọi người quý trọng','Để được trả ơn','Để nổi tiếng','Không cần thiết'],
  [3,'Thấy một cụ già ăn xin bên đường, có bạn thương giúp đỡ, có bạn lại xua đuổi. Em đồng tình với cách ứng xử nào? Vì sao?','Đồng tình với bạn giúp đỡ cụ (bằng khả năng của mình). Yêu thương con người là biết cảm thông, chia sẻ với người khó khăn; xua đuổi là vô cảm, thiếu nhân ái.'],
  [3,'Nêu những việc làm thể hiện lòng yêu thương con người mà học sinh có thể làm.','Giúp bạn học yếu, chia sẻ với bạn khó khăn, tham gia ủng hộ vùng lũ, kính trọng giúp đỡ người già, nhường nhịn em nhỏ.'],
  [4,'Có ý kiến: "Yêu thương con người là phải cho thật nhiều tiền của." Em có tán thành không? Vì sao?','Không hoàn toàn tán thành. Yêu thương thể hiện bằng sự quan tâm, cảm thông, hành động giúp đỡ phù hợp khả năng, không nhất thiết là tiền của; một lời động viên, một sự sẻ chia cũng là yêu thương.']
 ]);
 add(M,6,'Bài 3: Siêng năng, kiên trì',[
  [1,'Siêng năng là gì?','Cần cù, tự giác, miệt mài làm việc thường xuyên','Lười biếng','Làm việc hứng lên mới làm','Trông chờ người khác'],
  [1,'Kiên trì là gì?','Quyết tâm làm đến cùng dù khó khăn','Bỏ cuộc giữa chừng','Nản chí khi gặp khó','Làm qua loa'],
  [2,'Biểu hiện nào thể hiện siêng năng, kiên trì trong học tập?','Chăm học, làm bài đầy đủ, không nản khi gặp bài khó','Chép bài bạn','Bỏ bài khó','Học khi bị ép'],
  [2,'Câu tục ngữ nào nói về siêng năng, kiên trì?','"Có công mài sắt, có ngày nên kim"','"Ăn cây nào rào cây ấy"','"Gần mực thì đen"','"Đi một ngày đàng học một sàng khôn"'],
  [3,'Bạn A định bỏ học đàn vì thấy khó và lâu tiến bộ. Em khuyên bạn điều gì?','Khuyên bạn kiên trì luyện tập đều đặn, chia nhỏ mục tiêu; mọi kĩ năng đều cần thời gian; "có công mài sắt có ngày nên kim", bỏ cuộc sẽ không bao giờ thành công.'],
  [3,'Nêu lợi ích của siêng năng, kiên trì đối với mỗi người.','Giúp đạt mục tiêu, thành công trong học tập và cuộc sống, rèn ý chí, được mọi người tin yêu, quý trọng.'],
  [4,'Có người nói: "Chỉ cần thông minh là thành công, không cần siêng năng." Em có đồng ý không? Vì sao?','Không đồng ý. Thông minh là lợi thế nhưng nếu lười biếng thì không phát huy được; nhiều người bình thường nhờ siêng năng, kiên trì mà thành công. Siêng năng, kiên trì là yếu tố quan trọng dẫn tới thành công.']
 ]);
 add(M,6,'Bài 4: Tôn trọng sự thật',[
  [1,'Tôn trọng sự thật là gì?','Suy nghĩ, nói và làm theo đúng sự thật','Nói dối cho có lợi','Bịa đặt','Giấu giếm sự thật'],
  [1,'Hành vi nào thể hiện tôn trọng sự thật?','Nói thật, nhận lỗi khi làm sai','Gian lận trong thi cử','Làm chứng gian','Bao che cái sai'],
  [2,'Vì sao cần tôn trọng sự thật?','Giúp con người tin tưởng, gắn kết, xã hội tốt đẹp; bản thân thanh thản','Để bị ghét','Không có ích','Để thiệt thòi'],
  [2,'Biểu hiện nào trái với tôn trọng sự thật?','Dối trá, xuyên tạc, bao che điều sai','Thẳng thắn','Trung thực','Khách quan'],
  [3,'Em chứng kiến bạn thân quay cóp trong giờ kiểm tra. Em nên làm gì để tôn trọng sự thật mà vẫn giữ tình bạn?','Khuyên bạn không nên quay cóp vì đó là gian lận, hại chính bạn; nếu bạn tiếp tục, nhắc nhở hoặc báo thầy cô. Giúp bạn nhận ra cái đúng mới là tình bạn chân thành.'],
  [3,'Nêu ý nghĩa của việc tôn trọng sự thật trong cuộc sống.','Bảo vệ lẽ phải, công bằng; được mọi người tin cậy, quý trọng; giúp các mối quan hệ tốt đẹp và xã hội lành mạnh.'],
  [4,'Có ý kiến: "Đôi khi nói dối để người khác vui thì vẫn tốt." Em suy nghĩ thế nào?','Cần phân biệt: lời nói tế nhị, động viên khác với dối trá vụ lợi, bao che cái sai. Nhìn chung vẫn nên tôn trọng sự thật; nếu nói giảm nói tránh thì phải xuất phát từ thiện chí, không làm hại ai và không che giấu điều sai trái.']
 ]);
 add(M,6,'Bài 5: Tự lập',[
  [1,'Tự lập là gì?','Tự làm lấy, tự giải quyết công việc của mình','Dựa dẫm người khác','Ỷ lại bố mẹ','Trông chờ may rủi'],
  [1,'Hành vi nào thể hiện tính tự lập của học sinh?','Tự giác học bài, tự chuẩn bị đồ dùng, tự làm việc nhà','Chờ mẹ nhắc mới học','Nhờ người làm hộ bài','Ỷ lại anh chị'],
  [2,'Vì sao cần rèn tính tự lập?','Giúp ta tự tin, bản lĩnh, thành công và được tôn trọng','Để làm khổ mình','Không cần thiết','Để người khác lo'],
  [2,'Biểu hiện nào trái với tự lập?','Ỷ lại, dựa dẫm, phụ thuộc người khác','Chủ động','Tự giác','Tự tin'],
  [3,'Bạn B việc gì cũng nhờ bố mẹ làm hộ, kể cả soạn sách vở. Em nhận xét gì và khuyên bạn thế nào?','Bạn thiếu tính tự lập, dễ ỷ lại, khó trưởng thành. Khuyên bạn tập tự làm những việc của mình từ nhỏ đến lớn để rèn tự lập, tự tin.'],
  [3,'Nêu những việc em có thể tự làm để rèn tính tự lập.','Tự học, tự soạn sách vở, tự dọn phòng, giặt đồ cá nhân, sắp xếp thời gian, tự đi học, tự giải quyết việc vừa sức.'],
  [4,'Có bạn cho rằng tự lập là không cần ai giúp đỡ, việc gì cũng tự làm một mình. Em có đồng ý không? Vì sao?','Không hoàn toàn đồng ý. Tự lập là tự chủ, tự làm việc của mình, nhưng khi cần vẫn có thể hợp tác, nhờ giúp đỡ đúng lúc; tự lập không có nghĩa là cô lập hay từ chối mọi sự giúp đỡ.']
 ]);
 add(M,6,'Bài 6: Tự nhận thức bản thân',[
  [1,'Tự nhận thức bản thân là gì?','Biết rõ điểm mạnh, điểm yếu, sở thích, khả năng của mình','Bắt chước người khác','Không hiểu mình','Chỉ nhìn người khác'],
  [1,'Việc làm nào giúp em tự nhận thức bản thân?','Tự đánh giá, lắng nghe góp ý, so sánh với mục tiêu','Phớt lờ góp ý','Tự cao','Không suy xét'],
  [2,'Vì sao cần tự nhận thức bản thân?','Để phát huy điểm mạnh, khắc phục điểm yếu, sống phù hợp và tiến bộ','Để tự ti','Để khoe khoang','Không có ích'],
  [2,'Biểu hiện nào cho thấy người chưa biết tự nhận thức bản thân?','Ảo tưởng về mình hoặc tự ti quá mức','Hiểu đúng về mình','Biết sửa lỗi','Biết điểm mạnh yếu'],
  [3,'Bạn C luôn cho rằng mình giỏi nhất lớp và không nghe ai góp ý. Điều đó cho thấy gì và em khuyên bạn thế nào?','Bạn chưa tự nhận thức đúng về bản thân (tự cao). Khuyên bạn khiêm tốn, lắng nghe góp ý để thấy rõ điểm mạnh, điểm yếu mà tiến bộ.'],
  [3,'Nêu cách em rèn luyện để tự nhận thức bản thân tốt hơn.','Tự đánh giá hằng ngày, ghi lại điểm mạnh – yếu, lắng nghe nhận xét của thầy cô, bạn bè, đặt mục tiêu và theo dõi tiến bộ.'],
  [4,'Vì sao tự nhận thức bản thân được coi là cơ sở để rèn luyện và phát triển?','Chỉ khi hiểu rõ mình, ta mới biết phát huy thế mạnh, khắc phục hạn chế, chọn mục tiêu và cách học, nghề phù hợp; nhờ đó rèn luyện và phát triển đúng hướng, hiệu quả.']
 ]);
 add(M,6,'Bài 7: Ứng phó với tình huống nguy hiểm',[
  [1,'Tình huống nguy hiểm là gì?','Tình huống đe dọa đến tính mạng, sức khỏe, tài sản của con người','Trò chơi vui','Tình huống bình thường','Một bài học'],
  [1,'Khi gặp mưa dông, sấm sét, em KHÔNG nên làm gì?','Trú dưới cây to, cột điện','Vào nhà kiên cố','Tránh nơi trống','Tắt thiết bị điện'],
  [2,'Khi bị đuối nước, cách xử lí đúng là gì?','Bình tĩnh kêu cứu, bám vật nổi; người trên bờ ném phao, gọi người lớn','Vùng vẫy hoảng loạn','Tự ý nhảy xuống cứu khi không biết bơi','Im lặng'],
  [2,'Khi có người lạ bám theo trên đường vắng, em nên làm gì?','Đi nhanh đến nơi đông người, nhờ người lớn giúp, gọi điện cho người thân','Đi theo họ','Đứng lại nói chuyện','Trốn vào nơi vắng'],
  [3,'Khi phát hiện có đám cháy trong nhà, em cần làm gì để bảo đảm an toàn?','Bình tĩnh, báo động cho mọi người, thoát ra nơi an toàn theo lối thoát hiểm, cúi thấp người tránh khói, gọi 114; không trốn vào phòng kín, không quay lại lấy đồ.'],
  [3,'Nêu một số kĩ năng cần có để tự bảo vệ khi gặp tình huống nguy hiểm.','Bình tĩnh, nhận diện nguy hiểm, kêu cứu, chạy đến nơi an toàn, nhớ số điện thoại khẩn cấp (113, 114, 115), báo người lớn.'],
  [4,'Vì sao nói "bình tĩnh" là yếu tố quan trọng nhất khi ứng phó với tình huống nguy hiểm?','Khi bình tĩnh, ta mới suy nghĩ sáng suốt, nhận định đúng tình huống và chọn cách xử lí an toàn; hoảng loạn dễ dẫn đến hành động sai, làm tình huống nguy hiểm hơn.']
 ]);
 add(M,6,'Bài 8: Tiết kiệm',[
  [1,'Tiết kiệm là gì?','Biết sử dụng hợp lí, đúng mức của cải, thời gian, sức lực','Keo kiệt','Lãng phí','Hà tiện quá mức'],
  [1,'Hành vi nào thể hiện tiết kiệm?','Tắt điện khi ra khỏi phòng, giữ gìn đồ dùng','Để nước chảy lãng phí','Vứt đồ còn dùng được','Ăn uống thừa mứa'],
  [2,'Tiết kiệm khác với keo kiệt ở điểm nào?','Tiết kiệm là dùng hợp lí, keo kiệt là bủn xỉn, không dám chi cả khi cần','Giống hệt nhau','Đều là lãng phí','Đều là hào phóng'],
  [2,'Vì sao cần tiết kiệm?','Giúp tích lũy, bảo vệ tài nguyên, lo cho tương lai, góp phần phát triển đất nước','Để nghèo đi','Không cần thiết','Để bị chê'],
  [3,'Bạn D hay vứt bỏ đồ dùng học tập còn mới để mua đồ mới theo mốt. Em nhận xét và khuyên bạn thế nào?','Bạn lãng phí, chưa biết tiết kiệm. Khuyên bạn dùng hết đồ còn tốt, chỉ mua khi cần, biết quý trọng công sức của bố mẹ và tài nguyên.'],
  [3,'Nêu những việc học sinh nên làm để thực hành tiết kiệm.','Tiết kiệm điện, nước, giữ gìn sách vở đồ dùng, không tiêu xài hoang phí, quý trọng thời gian, tận dụng đồ dùng hợp lí.'],
  [4,'Có ý kiến cho rằng gia đình khá giả thì không cần tiết kiệm. Em có đồng ý không? Vì sao?','Không đồng ý. Tiết kiệm là phẩm chất cần có với mọi người, mọi hoàn cảnh; giúp quý trọng của cải, bảo vệ tài nguyên chung và phòng khi khó khăn. Giàu mà lãng phí cũng là thói xấu.']
 ]);
 add(M,6,'Bài 9: Công dân nước Cộng hòa xã hội chủ nghĩa Việt Nam',[
  [1,'Công dân là gì?','Người dân của một nước, có quốc tịch của nước đó','Người sống ở nước ngoài','Khách du lịch','Người không quốc tịch'],
  [1,'Căn cứ để xác định công dân của một nước là gì?','Quốc tịch','Nơi đang ở','Nghề nghiệp','Ngôn ngữ'],
  [2,'Theo quy định, trường hợp nào dưới đây là công dân Việt Nam?','Người có quốc tịch Việt Nam','Khách nước ngoài du lịch ở Việt Nam','Người đã thôi quốc tịch Việt Nam','Người không quốc tịch'],
  [2,'Quốc tịch Việt Nam thể hiện điều gì?','Mối quan hệ giữa một người với Nhà nước Cộng hòa xã hội chủ nghĩa Việt Nam','Nơi sinh sống tạm thời','Chỉ là giấy tờ','Quyền của người nước ngoài'],
  [3,'Vì sao mỗi người cần tự hào khi là công dân nước Cộng hòa xã hội chủ nghĩa Việt Nam?','Vì được Nhà nước bảo hộ, hưởng các quyền và làm nghĩa vụ công dân; tự hào về đất nước, truyền thống dân tộc, từ đó có trách nhiệm xây dựng và bảo vệ Tổ quốc.'],
  [3,'Là công dân Việt Nam, học sinh cần làm gì để xứng đáng?','Chăm học, rèn đạo đức, thực hiện tốt nội quy, pháp luật phù hợp lứa tuổi, yêu nước, giữ gìn bản sắc, góp phần xây dựng đất nước.'],
  [4,'Vì sao nói quốc tịch gắn liền với quyền và nghĩa vụ của công dân?','Có quốc tịch Việt Nam thì được Nhà nước bảo đảm các quyền công dân, đồng thời phải thực hiện nghĩa vụ với Nhà nước; quốc tịch là cơ sở pháp lí xác lập mối quan hệ quyền – nghĩa vụ giữa công dân và Nhà nước.']
 ]);
 add(M,6,'Bài 10: Quyền và nghĩa vụ cở bản của công dân',[
  [1,'Quyền cơ bản của công dân là gì?','Những lợi ích cơ bản mà công dân được hưởng, được Hiến pháp ghi nhận','Việc bị ép buộc','Điều bị cấm','Chỉ dành cho người lớn'],
  [1,'Nghĩa vụ cơ bản của công dân là gì?','Những việc công dân phải thực hiện theo quy định của Hiến pháp, pháp luật','Việc tùy thích','Quyền lợi','Điều không bắt buộc'],
  [2,'Đâu là một nghĩa vụ cơ bản của công dân?','Tuân theo Hiến pháp, pháp luật; bảo vệ Tổ quốc','Được học tập','Được vui chơi','Được bảo vệ'],
  [2,'Quyền và nghĩa vụ cơ bản của công dân được quy định chủ yếu trong văn bản nào?','Hiến pháp','Nội quy lớp','Hương ước làng','Thời khóa biểu'],
  [3,'Vì sao quyền và nghĩa vụ của công dân luôn gắn bó với nhau?','Công dân được hưởng quyền, đồng thời phải thực hiện nghĩa vụ; hưởng quyền phải đi đôi với làm tròn nghĩa vụ thì xã hội mới công bằng, ổn định và phát triển.'],
  [3,'Là học sinh, em thực hiện quyền và nghĩa vụ cơ bản của công dân như thế nào?','Thực hiện quyền học tập bằng việc chăm học; làm nghĩa vụ: tuân theo pháp luật, nội quy, bảo vệ môi trường, giữ gìn tài sản chung, yêu nước.'],
  [4,'Có bạn cho rằng học sinh còn nhỏ nên chỉ có quyền mà chưa phải thực hiện nghĩa vụ. Em có đồng ý không? Vì sao?','Không đồng ý. Dù còn nhỏ, công dân vẫn có những nghĩa vụ phù hợp lứa tuổi như tuân theo pháp luật, nội quy, bảo vệ môi trường, học tập tốt; quyền luôn đi đôi với nghĩa vụ.']
 ]);
 add(M,6,'Bài 11: Quyền cơ bản của trẻ em',[
  [1,'Theo Công ước của Liên hợp quốc, trẻ em có mấy nhóm quyền cơ bản?','Bốn nhóm quyền','Hai nhóm','Một nhóm','Năm nhóm'],
  [1,'Nhóm quyền nào bảo đảm cho trẻ em được sống, được chăm sóc để tồn tại?','Nhóm quyền được sống còn','Nhóm quyền tham gia','Nhóm quyền phát triển','Nhóm quyền bảo vệ'],
  [2,'Quyền được học tập, vui chơi, giải trí thuộc nhóm quyền nào?','Nhóm quyền phát triển','Nhóm quyền sống còn','Nhóm quyền bảo vệ','Nhóm quyền tham gia'],
  [2,'Quyền được bày tỏ ý kiến, được lắng nghe thuộc nhóm quyền nào?','Nhóm quyền tham gia','Nhóm quyền sống còn','Nhóm quyền bảo vệ','Nhóm quyền phát triển'],
  [3,'Kể tên bốn nhóm quyền cơ bản của trẻ em.','Nhóm quyền được sống còn; nhóm quyền được bảo vệ; nhóm quyền được phát triển; nhóm quyền được tham gia.'],
  [3,'Vì sao trẻ em cần được hưởng các quyền cơ bản?','Vì trẻ em còn non nớt, cần được chăm sóc, bảo vệ để phát triển toàn diện về thể chất, trí tuệ, tinh thần và đạo đức, trở thành người có ích.'],
  [4,'Theo em, vì sao quyền được bảo vệ của trẻ em lại đặc biệt quan trọng trong xã hội hiện nay?','Vì trẻ em dễ bị xâm hại, bạo hành, bóc lột, mua bán...; quyền được bảo vệ giúp trẻ tránh các nguy cơ đó, được an toàn để sống và phát triển; bảo vệ trẻ em là trách nhiệm của gia đình, nhà trường và xã hội.']
 ]);
 add(M,6,'Bài 12: Thực hiện quyền trẻ em',[
  [1,'Thực hiện quyền trẻ em là trách nhiệm của ai?','Gia đình, nhà trường, Nhà nước và toàn xã hội','Chỉ của trẻ em','Chỉ của nhà trường','Chỉ của công an'],
  [1,'Việc làm nào thể hiện thực hiện tốt quyền trẻ em?','Cho trẻ đi học, chăm sóc, lắng nghe ý kiến của trẻ','Bắt trẻ bỏ học đi làm','Đánh đập trẻ','Phân biệt đối xử'],
  [2,'Hành vi nào là vi phạm quyền trẻ em?','Bạo hành, bắt trẻ lao động nặng, không cho đi học','Cho trẻ vui chơi','Chăm sóc sức khỏe trẻ','Lắng nghe trẻ'],
  [2,'Bổn phận của trẻ em khi thực hiện quyền của mình là gì?','Thực hiện quyền đi đôi với bổn phận: chăm học, vâng lời, yêu thương gia đình','Chỉ đòi quyền lợi','Không cần bổn phận','Làm trái pháp luật'],
  [3,'Thấy một bạn hàng xóm bị bố mẹ bắt nghỉ học để đi bán hàng, em nên làm gì?','Động viên bạn, báo cho người lớn tin cậy, thầy cô hoặc chính quyền địa phương để can thiệp, giúp bạn được tiếp tục đi học (bảo vệ quyền học tập của trẻ em).'],
  [3,'Là trẻ em, em cần làm gì để góp phần thực hiện tốt quyền trẻ em?','Hiểu quyền và bổn phận của mình; chăm học, rèn luyện; tôn trọng quyền của bạn; lên tiếng hoặc báo người lớn khi thấy quyền trẻ em bị xâm phạm.'],
  [4,'Vì sao thực hiện quyền trẻ em phải gắn với việc trẻ em làm tròn bổn phận của mình?','Vì quyền luôn đi đôi với bổn phận; trẻ hưởng quyền được chăm sóc, học tập thì cũng cần chăm ngoan, học tốt, biết ơn và có trách nhiệm. Như vậy việc thực hiện quyền trẻ em mới trọn vẹn và có ý nghĩa.']
 ]);

 /* -------- LỚP 6: các chủ đề tổng hợp -------- */
 add(M,6,'Phẩm chất đạo đức',[
  [2,'Nhóm phẩm chất nào dưới đây là phẩm chất đạo đức tốt đẹp cần rèn luyện?','Yêu thương, siêng năng, trung thực, tiết kiệm','Ích kỉ, lười biếng','Dối trá, hoang phí','Vô cảm, ỷ lại'],
  [2,'"Siêng năng, kiên trì" giúp ích gì cho học sinh?','Học tập tiến bộ, đạt mục tiêu, rèn ý chí','Mau nản','Ỷ lại','Gian lận'],
  [3,'Nêu 3 phẩm chất đạo đức em thấy mình cần rèn luyện nhất và cách rèn.','HS nêu phẩm chất (VD: siêng năng, trung thực, tiết kiệm) kèm cách rèn cụ thể hằng ngày.'],
  [3,'Vì sao rèn luyện phẩm chất đạo đức lại quan trọng với mỗi người?','Giúp hoàn thiện nhân cách, sống tốt, được mọi người yêu quý, góp phần xây dựng gia đình và xã hội tốt đẹp.'],
  [4,'Theo em, giữa tài năng và đạo đức, yếu tố nào quan trọng hơn? Vì sao?','Cả hai đều cần, nhưng đạo đức là gốc; "có tài mà không có đức là người vô dụng". Người vừa có đức vừa có tài mới thực sự có ích cho xã hội.']
 ]);
 add(M,6,'Pháp luật và quyền công dân',[
  [1,'Quyền và nghĩa vụ cơ bản của công dân được ghi nhận trong văn bản pháp luật cao nhất nào?','Hiến pháp','Nội quy trường','Hương ước','Điều lệ Đội'],
  [2,'Công dân Việt Nam là người như thế nào?','Người có quốc tịch Việt Nam','Người đang du lịch ở Việt Nam','Người nước ngoài làm việc tại Việt Nam','Người không quốc tịch'],
  [2,'Việc tuân theo Hiến pháp và pháp luật là gì của công dân?','Nghĩa vụ cơ bản','Quyền tự do','Việc không bắt buộc','Việc tùy thích'],
  [3,'Nêu một số quyền và một số nghĩa vụ cơ bản của công dân.','Quyền: học tập, bất khả xâm phạm thân thể, tự do ngôn luận... Nghĩa vụ: tuân theo pháp luật, bảo vệ Tổ quốc, bảo vệ môi trường, nộp thuế (với người có nghĩa vụ).'],
  [4,'Vì sao công dân vừa được hưởng quyền vừa phải thực hiện nghĩa vụ?','Quyền và nghĩa vụ gắn bó nhau; hưởng quyền phải đi đôi làm nghĩa vụ để bảo đảm công bằng, trật tự xã hội; nếu chỉ đòi quyền mà không làm nghĩa vụ thì xã hội không thể ổn định, phát triển.']
 ]);
 add(M,6,'Ứng xử và kĩ năng sống',[
  [2,'Khi gặp tình huống nguy hiểm, điều quan trọng đầu tiên cần làm là gì?','Bình tĩnh để tìm cách xử lí an toàn','Hoảng loạn','Bỏ chạy lung tung','La hét vô ích'],
  [2,'Số điện thoại gọi cứu hỏa ở Việt Nam là số nào?','114','113','115','116'],
  [2,'Kĩ năng tự nhận thức bản thân giúp em điều gì?','Biết điểm mạnh, điểm yếu để rèn luyện phù hợp','Tự ti','Tự cao','Không hiểu mình'],
  [3,'Nêu các số điện thoại khẩn cấp và trường hợp sử dụng.','113 – công an (an ninh, trật tự); 114 – cứu hỏa (cháy, cứu nạn); 115 – cấp cứu y tế.'],
  [4,'Vì sao kĩ năng sống lại cần thiết với học sinh trong cuộc sống hiện nay?','Giúp các em tự bảo vệ mình, ứng phó với tình huống nguy hiểm, giao tiếp và giải quyết vấn đề tốt hơn, sống an toàn, tự tin và có trách nhiệm.']
 ]);
 add(M,6,'Công dân và cuộc sống',[
  [1,'Việc làm nào thể hiện trách nhiệm của công dân nhỏ tuổi?','Chăm học, giữ gìn môi trường, tuân theo pháp luật phù hợp lứa tuổi','Trốn học','Phá hoại của công','Vi phạm luật giao thông'],
  [2,'Giấy tờ nào thường dùng để chứng minh một người là công dân Việt Nam?','Giấy khai sinh, thẻ căn cước công dân','Vé xem phim','Thẻ học sinh nước ngoài','Hóa đơn mua hàng'],
  [2,'Hành vi nào thể hiện sống có trách nhiệm với cộng đồng?','Tham gia bảo vệ môi trường, giúp đỡ người khó khăn','Xả rác bừa bãi','Thờ ơ việc chung','Gây mất trật tự'],
  [3,'Là một công dân nhỏ tuổi, em làm gì để góp phần xây dựng quê hương, đất nước?','Chăm học, rèn đạo đức, giữ gìn vệ sinh và cảnh quan, chấp hành pháp luật, tham gia hoạt động cộng đồng phù hợp, giữ gìn truyền thống.'],
  [4,'Vì sao mỗi công dân đều có vai trò trong việc xây dựng đất nước, dù là việc nhỏ?','Vì đất nước là của chung; mỗi việc tốt (học tập, lao động, giữ gìn môi trường, chấp hành pháp luật) đều góp phần làm xã hội tốt đẹp hơn; nhiều đóng góp nhỏ tạo nên sức mạnh và sự phát triển chung.']
 ]);

 /* -------- LỚP 6: bù lẻ cho đủ chuẩn -------- */
 add(M,6,'Pháp luật và quyền công dân',[
  [2,'Hành vi nào dưới đây là thực hiện đúng nghĩa vụ của công dân?','Chấp hành luật giao thông','Vượt đèn đỏ','Trốn nghĩa vụ','Xả rác nơi công cộng'],
  [3,'Vì sao công dân phải sống và làm việc theo Hiến pháp, pháp luật?','Để bảo đảm quyền lợi của mình và người khác, giữ trật tự, kỉ cương, xây dựng xã hội công bằng, văn minh.']
 ]);
 add(M,6,'Ứng xử và kĩ năng sống',[
  [3,'Nêu cách ứng phó khi bị bạn bè rủ rê làm việc xấu (trốn học, hút thuốc).','Kiên quyết từ chối, nêu rõ việc đó là sai và có hại; tránh xa, tìm bạn tốt; kể với người lớn tin cậy khi cần.']
 ]);
 add(M,6,'Công dân và cuộc sống',[
  [2,'Hành vi nào thể hiện nếp sống văn minh nơi công cộng?','Xếp hàng, giữ trật tự, bỏ rác đúng nơi','Chen lấn','Nói to','Vứt rác bừa bãi'],
  [3,'Theo em, học sinh thể hiện trách nhiệm công dân qua những việc làm nào?','Chăm học, chấp hành pháp luật và nội quy, giữ vệ sinh môi trường, giúp đỡ mọi người, tham gia hoạt động cộng đồng phù hợp.']
 ]);
 add(M,6,'Bài 2: Yêu thương con người',[
  [1,'Câu ca dao, tục ngữ nào nói về lòng yêu thương con người?','"Thương người như thể thương thân"','"Ăn vóc học hay"','"Có chí thì nên"','"Tốt gỗ hơn tốt nước sơn"']
 ]);
 add(M,6,'Bài 4: Tôn trọng sự thật',[
  [1,'Người tôn trọng sự thật là người như thế nào?','Sống ngay thẳng, thật thà, dám bảo vệ sự thật','Hay nói dối','Ưa nịnh','Bao che điều sai'],
  [3,'Nêu ý nghĩa của câu "Thật thà là cha quỷ quái".','Khuyên con người sống thật thà, trung thực; người thật thà tuy có lúc thiệt nhưng lâu dài được tin yêu, còn gian dối sẽ bị phát hiện và mất lòng tin.']
 ]);
 add(M,6,'Bài 6: Tự nhận thức bản thân',[
  [1,'Cách nào giúp em tự nhận thức bản thân tốt hơn?','Lắng nghe nhận xét của người khác và tự đánh giá mình','Phớt lờ góp ý','Luôn cho mình đúng','So bì, đố kị']
 ]);
 add(M,6,'Bài 8: Tiết kiệm',[
  [1,'Câu tục ngữ nào khuyên con người biết tiết kiệm?','Tích tiểu thành đại','Há miệng chờ sung','Nước đổ lá khoai','Ăn cháo đá bát']
 ]);
 add(M,6,'Bài 10: Quyền và nghĩa vụ cở bản của công dân',[
  [1,'Quyền bất khả xâm phạm về thân thể, được pháp luật bảo hộ về tính mạng, sức khỏe là nhóm quyền gì của công dân?','Quyền cơ bản của công dân','Nghĩa vụ công dân','Việc bị cấm','Quy định nội bộ']
 ]);

 /* -------- LỚP 7 -------- */
 add(M,7,'Bài 1: Tự hào về truyền thống quê hương',[
  [1,'Truyền thống quê hương là những giá trị tốt đẹp được hình thành và lưu truyền như thế nào?','Qua nhiều thế hệ ở một vùng quê','Do một người nghĩ ra','Mới có gần đây','Của nước ngoài'],
  [1,'Đâu là truyền thống tốt đẹp của quê hương?','Yêu nước, hiếu học, cần cù lao động, nghề truyền thống','Mê tín dị đoan','Lười lao động','Gây mất đoàn kết'],
  [2,'Việc làm nào thể hiện giữ gìn, phát huy truyền thống quê hương?','Tìm hiểu, giới thiệu và tiếp nối các giá trị, nghề truyền thống','Chê bai quê mình','Bỏ nghề truyền thống','Phá di tích'],
  [2,'Hành vi nào làm mai một truyền thống quê hương?','Thờ ơ, quay lưng với văn hóa, nghề truyền thống','Học hỏi làng nghề','Tham gia lễ hội','Bảo vệ di tích'],
  [3,'Là học sinh, em làm gì để giữ gìn và phát huy truyền thống tốt đẹp của quê hương?','Tìm hiểu lịch sử, văn hóa địa phương; giữ gìn di tích, lễ hội; học tập tốt; giới thiệu, quảng bá nét đẹp quê hương; tham gia hoạt động phù hợp.'],
  [3,'Vì sao cần tự hào về truyền thống quê hương?','Giúp ta thêm yêu quê hương, có động lực phấn đấu, giữ gìn bản sắc và góp phần xây dựng quê hương giàu đẹp.'],
  [4,'Có ý kiến: "Quê hương nghèo thì chẳng có gì đáng tự hào." Em suy nghĩ thế nào?','Không đồng tình. Dù còn khó khăn, mỗi quê hương đều có truyền thống tốt đẹp (yêu nước, hiếu học, nghĩa tình...). Tự hào về quê hương là tự hào về những giá trị đó và có trách nhiệm góp phần xây dựng quê hương.']
 ]);
 add(M,7,'Bài 2: Quan tâm, cảm thông và chia sẻ',[
  [1,'Quan tâm là gì?','Thường xuyên chú ý đến người khác','Thờ ơ với người khác','Chỉ lo cho mình','Lợi dụng người khác'],
  [1,'Cảm thông là gì?','Đặt mình vào vị trí người khác để thấu hiểu họ','Chế giễu người khác','Vô cảm','Ghen tị'],
  [2,'Hành vi nào thể hiện quan tâm, cảm thông và chia sẻ?','Giúp đỡ, động viên người gặp khó khăn','Bỏ mặc bạn lúc khó','Trêu chọc người yếu thế','Khoe khoang'],
  [2,'Biểu hiện nào trái với quan tâm, cảm thông, chia sẻ?','Ích kỉ, vô cảm, thờ ơ','Sẻ chia','Giúp đỡ','Động viên'],
  [3,'Thấy bạn trong lớp có chuyện buồn, học sa sút, em sẽ làm gì?','Hỏi thăm, động viên, lắng nghe và giúp bạn (giảng bài, rủ bạn tham gia hoạt động), báo thầy cô nếu bạn cần hỗ trợ.'],
  [3,'Nêu ý nghĩa của quan tâm, cảm thông và chia sẻ trong cuộc sống.','Giúp mọi người gần gũi, gắn bó, vượt qua khó khăn; nuôi dưỡng tình yêu thương và làm xã hội nhân ái, tốt đẹp hơn.'],
  [4,'Vì sao nói quan tâm, cảm thông và chia sẻ đem lại niềm vui cho cả người nhận và người cho?','Người nhận được an ủi, giúp đỡ nên bớt khó khăn, thấy được yêu thương; người cho thấy mình sống có ý nghĩa, lan tỏa điều tốt, nhân lên niềm vui và sự gắn kết trong cộng đồng.']
 ]);
 add(M,7,'Bài 3: Học tập tự giác, tích cực',[
  [1,'Học tập tự giác, tích cực là gì?','Chủ động, nỗ lực học tập không cần ai nhắc nhở','Học khi bị ép','Chép bài bạn','Trốn học'],
  [1,'Biểu hiện nào thể hiện học tập tự giác, tích cực?','Tự lập kế hoạch học, hăng hái phát biểu, làm bài đầy đủ','Lười làm bài','Ngại khó','Ỷ lại bạn'],
  [2,'Việc làm nào KHÔNG thể hiện tính tự giác trong học tập?','Chỉ học khi bố mẹ nhắc nhở','Tự giác ôn bài','Chủ động hỏi bài','Lập thời gian biểu'],
  [2,'Vì sao học sinh cần học tập tự giác, tích cực?','Giúp đạt kết quả tốt, tiếp thu kiến thức sâu, rèn ý thức tự chủ và thành công trong tương lai','Để bị điểm kém','Để mệt mỏi','Không cần thiết'],
  [3,'Nêu những việc em làm để rèn tính tự giác, tích cực trong học tập.','Lập thời gian biểu và thực hiện; chuẩn bị bài trước; chủ động hỏi khi chưa hiểu; đặt mục tiêu; không để bố mẹ nhắc nhở mới học.'],
  [3,'Tự giác, tích cực học tập mang lại lợi ích gì cho bản thân?','Kết quả học tập tiến bộ, hiểu bài sâu, tự tin, được thầy cô bạn bè quý mến, tạo nền tảng cho tương lai.'],
  [4,'Có bạn cho rằng học giỏi là do thông minh, không cần tự giác. Em có đồng ý không? Vì sao?','Không đồng ý. Thông minh là lợi thế nhưng nếu không tự giác, chăm chỉ thì không phát huy được. Nhiều bạn nhờ tự giác, tích cực mà học tốt. Tự giác, tích cực là yếu tố quyết định sự tiến bộ.']
 ]);
 add(M,7,'Bài 4: Giữ chữ tín',[
  [1,'Giữ chữ tín là gì?','Coi trọng lòng tin, giữ đúng lời hứa và niềm tin của mọi người','Thất hứa','Lừa dối','Nói một đằng làm một nẻo'],
  [1,'Hành vi nào thể hiện giữ chữ tín?','Thực hiện đúng lời hứa, đúng hẹn','Hứa rồi quên','Nói dối','Làm sai cam kết'],
  [2,'Biểu hiện nào trái với giữ chữ tín?','Thất hứa, gian dối, không đáng tin','Đúng hẹn','Trung thực','Giữ lời'],
  [2,'Vì sao cần giữ chữ tín?','Được mọi người tin tưởng, tôn trọng; tạo quan hệ tốt đẹp và thành công trong cuộc sống','Để bị ghét','Không có lợi','Để thiệt thòi'],
  [3,'Em đã hứa giúp bạn ôn bài nhưng lại được rủ đi chơi. Em nên làm gì để giữ chữ tín?','Thực hiện lời hứa giúp bạn ôn bài trước; hẹn đi chơi dịp khác. Giữ chữ tín thể hiện sự tôn trọng bạn và trách nhiệm của bản thân.'],
  [3,'Nêu ý nghĩa của việc giữ chữ tín trong học tập và cuộc sống.','Tạo niềm tin, uy tín cho bản thân; giúp các mối quan hệ bền chặt; là cơ sở để hợp tác, thành công và được xã hội coi trọng.'],
  [4,'Vì sao người xưa nói "Một lần bất tín, vạn lần bất tin"?','Chỉ cần một lần thất hứa, gian dối thì sẽ mất lòng tin của người khác và rất khó lấy lại. Câu nói nhắc nhở phải luôn giữ chữ tín vì lòng tin rất quý và dễ mất.']
 ]);
 add(M,7,'Bài 5: Bảo tồn di sản văn hóa',[
  [1,'Di sản văn hóa là gì?','Những sản phẩm vật chất, tinh thần có giá trị lịch sử, văn hóa, khoa học được lưu truyền','Đồ dùng mới mua','Hàng hóa thông thường','Sản phẩm công nghiệp'],
  [1,'Di sản văn hóa gồm mấy loại?','Hai loại: di sản văn hóa vật thể và phi vật thể','Một loại','Ba loại','Bốn loại'],
  [2,'Đâu là di sản văn hóa phi vật thể?','Dân ca, lễ hội, nghề thủ công truyền thống','Đền, chùa','Trống đồng','Thành cổ'],
  [2,'Hành vi nào là bảo vệ di sản văn hóa?','Giữ gìn, tuyên truyền, không phá hoại di tích','Khắc tên lên di tích','Lấy cắp cổ vật','Xả rác ở di tích'],
  [3,'Khi đi tham quan di tích lịch sử, em cần có thái độ và hành vi như thế nào?','Giữ trật tự, vệ sinh; không sờ, khắc, viết bậy lên hiện vật; không lấy đồ; tìm hiểu và tôn trọng giá trị di tích; nhắc nhở người khác cùng bảo vệ.'],
  [3,'Vì sao phải bảo tồn di sản văn hóa?','Vì di sản là tài sản quý của dân tộc, thể hiện bản sắc, lịch sử; bảo tồn để giáo dục thế hệ sau, phát triển du lịch và gìn giữ cho mai sau.'],
  [4,'Theo em, phát triển du lịch và bảo tồn di sản văn hóa cần được giải quyết như thế nào?','Cần hài hòa: khai thác du lịch gắn với bảo vệ, không làm tổn hại di sản; tuyên truyền ý thức cho du khách; dùng nguồn thu để tu bổ, gìn giữ di sản bền vững.']
 ]);
 add(M,7,'Bài 6: Ứng phó với tâm lí căng thẳng',[
  [1,'Tâm lí căng thẳng là trạng thái như thế nào?','Căng thẳng về tinh thần, cảm xúc khi gặp áp lực','Vui vẻ, thoải mái','Khỏe mạnh','Bình thường'],
  [1,'Nguyên nhân nào thường gây căng thẳng cho học sinh?','Áp lực học tập, thi cử, mâu thuẫn bạn bè','Được nghỉ ngơi','Được khen','Chơi thể thao'],
  [2,'Cách nào giúp ứng phó tích cực với căng thẳng?','Nghỉ ngơi, hít thở sâu, chia sẻ, tập thể dục, sắp xếp việc hợp lí','Thức khuya lo lắng','Giấu kín, chịu đựng một mình','Trút giận lên người khác'],
  [2,'Biểu hiện nào cho thấy một người đang bị căng thẳng?','Mệt mỏi, lo lắng, khó ngủ, dễ cáu gắt','Vui tươi','Tập trung tốt','Thoải mái'],
  [3,'Trước kì thi em cảm thấy rất lo lắng, mất ngủ. Em nên làm gì để giảm căng thẳng?','Lập kế hoạch ôn tập hợp lí, ôn sớm; nghỉ ngơi, ngủ đủ, ăn uống điều độ; tập thể dục, hít thở sâu; chia sẻ với người thân, thầy cô; suy nghĩ tích cực.'],
  [3,'Nêu một số cách ứng phó với tâm lí căng thẳng mà em biết.','Tâm sự với người tin cậy; nghe nhạc, vận động, nghỉ ngơi; sắp xếp công việc; suy nghĩ lạc quan; nhờ chuyên gia khi cần.'],
  [4,'Vì sao nói biết ứng phó với căng thẳng là một kĩ năng quan trọng?','Căng thẳng kéo dài ảnh hưởng xấu đến sức khỏe, học tập, quan hệ. Biết ứng phó giúp giữ cân bằng tâm lí, học tập và sinh hoạt tốt hơn, sống tích cực và khỏe mạnh.']
 ]);
 add(M,7,'Bài 7: Phòng chống bạo lực học đường',[
  [1,'Bạo lực học đường là gì?','Hành vi hành hạ, đánh đập, xúc phạm... giữa học sinh trong trường học','Giúp đỡ bạn','Học nhóm','Chơi thể thao'],
  [1,'Hành vi nào là bạo lực học đường?','Đánh, dọa nạt, lăng mạ, cô lập bạn','Cho bạn mượn sách','Giảng bài cho bạn','Khen ngợi bạn'],
  [2,'Khi bị bạo lực học đường, em nên làm gì?','Bình tĩnh, tránh xa, báo thầy cô, gia đình; không tự giải quyết bằng bạo lực','Đánh lại thật mạnh','Im lặng chịu đựng','Rủ người đánh bạn'],
  [2,'Việc làm nào góp phần phòng, chống bạo lực học đường?','Sống hòa đồng, tôn trọng bạn, báo người lớn khi thấy bạo lực','Cổ vũ đánh nhau','Quay clip để tung lên mạng','Thờ ơ'],
  [3,'Chứng kiến một nhóm bạn đánh và quay clip bạn khác, em nên làm gì?','Không cổ vũ, quay clip; tìm cách can ngăn an toàn hoặc báo ngay thầy cô, bảo vệ, người lớn để ngăn chặn và giúp bạn bị hại.'],
  [3,'Nêu nguyên nhân và hậu quả của bạo lực học đường.','Nguyên nhân: thiếu kĩ năng kiểm soát cảm xúc, đua đòi, mâu thuẫn, ảnh hưởng xấu từ bên ngoài. Hậu quả: tổn thương thể chất, tinh thần, ảnh hưởng học tập, vi phạm pháp luật.'],
  [4,'Theo em, vì sao mỗi học sinh đều có trách nhiệm phòng, chống bạo lực học đường?','Vì bạo lực học đường gây hậu quả nặng nề cho nạn nhân và môi trường học tập chung. Mỗi học sinh sống thân thiện, không im lặng tiếp tay, dám lên tiếng và báo người lớn sẽ góp phần xây dựng trường học an toàn, hạnh phúc.']
 ]);
 add(M,7,'Bài 8: Quản lí tiền',[
  [1,'Quản lí tiền là gì?','Biết sử dụng tiền hợp lí, có kế hoạch','Tiêu xài phung phí','Giữ khư khư không dùng','Vay mượn tùy tiện'],
  [1,'Việc làm nào thể hiện quản lí tiền hiệu quả?','Lập kế hoạch chi tiêu, tiết kiệm, chi đúng mục đích','Mua sắm theo cảm hứng','Tiêu hết ngay','Vay để mua đồ chơi'],
  [2,'Nguyên tắc nào giúp quản lí tiền tốt?','Chi tiêu hợp lí, tiết kiệm, có khoản dự phòng','Tiêu nhiều hơn thu','Không ghi chép','Mua theo bạn bè'],
  [2,'Vì sao học sinh cần biết quản lí tiền?','Rèn tính tiết kiệm, tự chủ, biết quý trọng công sức lao động và chuẩn bị cho tương lai','Để tiêu nhiều hơn','Không cần thiết','Để khoe'],
  [3,'Em được cho 500 000 đồng tiêu trong một tháng. Hãy lập kế hoạch sử dụng hợp lí.','Chia khoản: tiết kiệm một phần; chi cho việc cần thiết (đồ dùng học tập, ăn sáng); dành ít cho giải trí; ghi chép lại các khoản chi để kiểm soát.'],
  [3,'Nêu một số cách tiết kiệm và tăng nguồn tiền phù hợp với học sinh.','Tiết kiệm: hạn chế mua đồ không cần, nuôi heo đất. Tăng nguồn thu phù hợp: làm việc nhà được thưởng, bán đồ tái chế, làm sản phẩm thủ công (phù hợp lứa tuổi, không ảnh hưởng học tập).'],
  [4,'Vì sao biết quản lí tiền từ nhỏ lại giúp ích cho cuộc sống sau này?','Hình thành thói quen chi tiêu hợp lí, tiết kiệm, có kế hoạch; tránh lãng phí, nợ nần; biết quý trọng giá trị lao động; tạo nền tảng tài chính vững vàng khi trưởng thành.']
 ]);
 add(M,7,'Bài 9: Phòng, chống tệ nạn xã hội',[
  [1,'Tệ nạn xã hội là gì?','Hiện tượng xấu, trái đạo đức, pháp luật, gây hậu quả xấu cho xã hội','Phong tục đẹp','Hoạt động thể thao','Lễ hội truyền thống'],
  [1,'Đâu là tệ nạn xã hội?','Ma túy, cờ bạc, mại dâm, mê tín dị đoan','Học tập','Lao động','Từ thiện'],
  [2,'Hành vi nào giúp phòng, chống tệ nạn xã hội?','Sống lành mạnh, tránh xa cám dỗ, tuyên truyền phòng chống','Thử ma túy một lần','Tham gia cờ bạc','Che giấu người nghiện'],
  [2,'Vì sao tệ nạn xã hội nguy hiểm?','Hủy hoại sức khỏe, nhân cách, gia đình; gây mất trật tự, vi phạm pháp luật','Không ảnh hưởng gì','Có lợi cho xã hội','Giúp kiếm tiền tốt'],
  [3,'Khi bị bạn rủ rê thử chất kích thích, chơi cờ bạc, em sẽ làm gì?','Kiên quyết từ chối, giải thích tác hại; tránh xa nhóm bạn xấu; báo thầy cô, gia đình; rủ bạn tham gia hoạt động lành mạnh.'],
  [3,'Nêu một số nguyên nhân khiến người ta sa vào tệ nạn xã hội và cách phòng tránh.','Nguyên nhân: tò mò, đua đòi, thiếu hiểu biết, bị dụ dỗ, thiếu quan tâm của gia đình. Phòng tránh: hiểu tác hại, sống lành mạnh, chọn bạn tốt, tránh xa cám dỗ, tuân thủ pháp luật.'],
  [4,'Theo em, vì sao phòng, chống tệ nạn xã hội là trách nhiệm của mọi người?','Vì tệ nạn ảnh hưởng đến sức khỏe, an ninh, hạnh phúc của cả cộng đồng. Mỗi người sống lành mạnh, không tham gia, tuyên truyền và tố giác sẽ giúp ngăn chặn, xây dựng xã hội an toàn, văn minh.']
 ]);
 add(M,7,'Bài 10: Quyền và nghĩa vụ của công dân trong gia đình',[
  [1,'Gia đình là gì?','Tập hợp những người gắn bó bằng hôn nhân, huyết thống hoặc nuôi dưỡng','Một nhóm bạn','Một lớp học','Một tổ chức xã hội'],
  [1,'Đâu là nghĩa vụ của con, cháu đối với ông bà, cha mẹ?','Kính trọng, yêu thương, chăm sóc, phụng dưỡng','Đòi hỏi','Vô lễ','Bỏ mặc'],
  [2,'Cha mẹ có quyền và nghĩa vụ gì đối với con?','Nuôi dưỡng, chăm sóc, giáo dục con','Bỏ rơi con','Ngược đãi con','Bắt con nghỉ học đi làm'],
  [2,'Hành vi nào vi phạm quyền và nghĩa vụ trong gia đình?','Ngược đãi, bạo hành, bỏ mặc người thân','Chăm sóc ông bà','Dạy dỗ con cái','Yêu thương nhau'],
  [3,'Là người con, người cháu trong gia đình, em thực hiện bổn phận của mình như thế nào?','Kính trọng, lễ phép, vâng lời ông bà cha mẹ; chăm học; giúp việc nhà; yêu thương, chăm sóc khi người thân ốm đau; giữ hòa thuận gia đình.'],
  [3,'Nêu ý nghĩa của việc mỗi thành viên thực hiện tốt quyền và nghĩa vụ trong gia đình.','Gia đình hòa thuận, hạnh phúc, êm ấm; các thành viên yêu thương, có trách nhiệm với nhau; là nền tảng cho xã hội ổn định, tốt đẹp.'],
  [4,'Vì sao nói gia đình hòa thuận, hạnh phúc là nền tảng của một xã hội tốt đẹp?','Gia đình là tế bào của xã hội; gia đình êm ấm thì mỗi người được yêu thương, giáo dục tốt, sống có trách nhiệm; nhiều gia đình tốt tạo nên cộng đồng, xã hội văn minh, ổn định và phát triển.']
 ]);

 /* -------- LỚP 7: chủ đề tổng hợp -------- */
 add(M,7,'Giá trị sống và kĩ năng',[
  [2,'Phẩm chất nào giúp con người được mọi người tin tưởng, quý trọng?','Giữ chữ tín, trung thực','Dối trá','Ích kỉ','Thất hứa'],
  [2,'Kĩ năng nào giúp em vượt qua áp lực học tập?','Ứng phó với tâm lí căng thẳng','Trốn tránh','Buông xuôi','Cáu gắt'],
  [2,'Biểu hiện của người học tập tự giác, tích cực là gì?','Chủ động, nỗ lực, không cần nhắc nhở','Lười biếng','Ỷ lại','Đối phó'],
  [3,'Nêu những giá trị sống và kĩ năng em thấy cần rèn luyện nhất ở lứa tuổi học sinh.','VD: quan tâm chia sẻ, giữ chữ tín, tự giác học tập, quản lí cảm xúc và thời gian; kèm cách rèn luyện cụ thể.'],
  [4,'Theo em, vì sao rèn kĩ năng sống lại quan trọng không kém việc học kiến thức?','Kiến thức giúp hiểu biết, còn kĩ năng sống giúp vận dụng, ứng phó tình huống thực tế, giao tiếp và giải quyết vấn đề; có cả hai thì mới phát triển toàn diện và thành công trong cuộc sống.']
 ]);
 add(M,7,'Phòng chống tệ nạn, bạo lực',[
  [1,'Khi chứng kiến bạo lực học đường, hành vi đúng là gì?','Can ngăn an toàn hoặc báo thầy cô, người lớn','Cổ vũ','Quay clip tung lên mạng','Thờ ơ'],
  [2,'Đâu là tệ nạn xã hội cần phòng, chống?','Ma túy, cờ bạc, mại dâm','Thể dục thể thao','Học tập','Lao động'],
  [2,'Cách phòng tránh tệ nạn xã hội hiệu quả nhất với học sinh là gì?','Sống lành mạnh, hiểu tác hại và tránh xa cám dỗ','Thử cho biết','Giấu giếm','Theo bạn xấu'],
  [3,'Nêu các bước xử lí khi em hoặc bạn bị đe dọa, bạo lực.','Giữ bình tĩnh, tránh xa nơi nguy hiểm; không dùng bạo lực đáp trả; báo ngay thầy cô, gia đình, người lớn tin cậy; lưu lại bằng chứng nếu có.'],
  [4,'Vì sao im lặng trước bạo lực và tệ nạn lại là hành vi không nên?','Im lặng khiến cái xấu tiếp diễn, nạn nhân không được giúp đỡ và bản thân có thể trở thành nạn nhân tiếp theo. Lên tiếng, báo người lớn giúp ngăn chặn kịp thời và bảo vệ mọi người.']
 ]);
 add(M,7,'Quyền và nghĩa vụ công dân',[
  [1,'Trong gia đình, con cháu có nghĩa vụ gì với ông bà, cha mẹ?','Kính trọng, chăm sóc, phụng dưỡng','Đòi hỏi','Ngược đãi','Bỏ mặc'],
  [2,'Hành vi nào vi phạm quyền và nghĩa vụ công dân trong gia đình?','Bạo hành, bỏ rơi người thân','Chăm sóc nhau','Yêu thương','Giúp đỡ nhau'],
  [2,'Việc giữ chữ tín và tôn trọng người khác thể hiện điều gì của công dân?','Sống có đạo đức, trách nhiệm','Vô trách nhiệm','Ích kỉ','Thiếu văn hóa'],
  [3,'Nêu một số quyền và nghĩa vụ cơ bản của công dân trong gia đình.','Quyền: được yêu thương, chăm sóc, giáo dục. Nghĩa vụ: kính trọng, chăm sóc ông bà cha mẹ; anh chị em thương yêu, giúp đỡ nhau.'],
  [4,'Vì sao thực hiện tốt quyền và nghĩa vụ trong gia đình góp phần xây dựng xã hội?','Gia đình là tế bào của xã hội; mỗi gia đình hòa thuận, các thành viên sống có trách nhiệm thì tạo nên cộng đồng ổn định, văn minh; ngược lại, gia đình lục đục ảnh hưởng xấu đến xã hội.']
 ]);
 add(M,7,'Ứng xử văn minh',[
  [1,'Ứng xử văn minh nơi công cộng là gì?','Lịch sự, tôn trọng người khác, giữ trật tự vệ sinh','Chen lấn','Nói tục','Xả rác'],
  [2,'Hành vi nào thể hiện quan tâm, cảm thông và chia sẻ?','Giúp đỡ, động viên người gặp khó khăn','Vô cảm','Chế giễu','Thờ ơ'],
  [2,'Khi có bất đồng với bạn, cách ứng xử văn minh là gì?','Bình tĩnh trao đổi, tôn trọng, tìm cách hòa giải','Cãi vã','Dùng bạo lực','Nói xấu bạn'],
  [3,'Nêu một số hành vi ứng xử văn minh mà học sinh nên thực hiện.','Chào hỏi lễ phép; xếp hàng, giữ trật tự; nhường nhịn, giúp đỡ; không nói tục, xả rác; tôn trọng sự khác biệt.'],
  [4,'Theo em, vì sao ứng xử văn minh góp phần làm cuộc sống tốt đẹp hơn?','Ứng xử văn minh tạo môi trường thân thiện, tôn trọng lẫn nhau, giảm mâu thuẫn; mọi người sống hòa thuận, vui vẻ, xã hội trở nên văn hóa và tốt đẹp hơn.']
 ]);

 /* -------- LỚP 7: bù lẻ cho đủ chuẩn -------- */
 add(M,7,'Giá trị sống và kĩ năng',[
  [3,'Nêu một tình huống em đã vận dụng kĩ năng sống để giải quyết và kết quả.','HS kể tình huống thực tế (ứng phó căng thẳng, từ chối điều xấu, hòa giải mâu thuẫn...) và cách giải quyết, kết quả.']
 ]);
 add(M,7,'Phòng chống tệ nạn, bạo lực',[
  [1,'Số điện thoại gọi công an khi gặp nguy hiểm, bị đe dọa là số nào?','113','114','115','116'],
  [3,'Nêu vai trò của nhà trường và gia đình trong phòng, chống bạo lực học đường.','Giáo dục, nhắc nhở học sinh sống thân thiện; lắng nghe, quan tâm; phát hiện và xử lí kịp thời mâu thuẫn; phối hợp bảo vệ, hỗ trợ học sinh.']
 ]);
 add(M,7,'Quyền và nghĩa vụ công dân',[
  [3,'Là học sinh, em thực hiện quyền và nghĩa vụ của mình trong gia đình như thế nào?','Kính trọng, vâng lời ông bà cha mẹ; chăm học; giúp việc nhà; yêu thương, chăm sóc người thân; giữ hòa thuận gia đình.']
 ]);
 add(M,7,'Ứng xử văn minh',[
  [1,'Lời nói nào thể hiện ứng xử văn minh, lịch sự?','"Cảm ơn", "Xin lỗi", "Làm ơn"','Lời chửi tục','Lời đe dọa','Lời mỉa mai'],
  [3,'Nêu cách ứng xử văn minh khi tham gia mạng xã hội.','Tôn trọng người khác, không nói xấu, bịa đặt, xúc phạm; không chia sẻ thông tin sai; giữ lời lẽ lịch sự; bảo vệ thông tin cá nhân.']
 ]);
 add(M,7,'Bài 4: Giữ chữ tín',[
  [1,'Người giữ chữ tín sẽ nhận được điều gì từ mọi người?','Sự tin tưởng, tôn trọng','Sự coi thường','Sự xa lánh','Sự nghi ngờ']
 ]);

 /* -------- LỚP 8 -------- */
 add(M,8,'Bài 1: Tự hào về truyền thống dân tộc Việt Nam',[
  [1,'Truyền thống dân tộc là những giá trị tốt đẹp được hình thành và lưu truyền như thế nào?','Qua nhiều thế hệ của dân tộc','Mới có gần đây','Do một người tạo ra','Của nước ngoài'],
  [1,'Đâu là truyền thống tốt đẹp của dân tộc Việt Nam?','Yêu nước, đoàn kết, nhân nghĩa, hiếu học, cần cù','Mê tín','Lười biếng','Chia rẽ'],
  [2,'Việc làm nào thể hiện giữ gìn, phát huy truyền thống dân tộc?','Tìm hiểu, trân trọng, tiếp nối và giới thiệu truyền thống tốt đẹp','Chê bai lịch sử','Lãng quên cội nguồn','Sùng ngoại, coi thường văn hóa dân tộc'],
  [2,'Hành vi nào làm mai một truyền thống dân tộc?','Quay lưng, coi thường giá trị văn hóa dân tộc','Học lịch sử','Giữ gìn lễ hội','Bảo vệ di sản'],
  [3,'Là học sinh, em làm gì để giữ gìn và phát huy truyền thống tốt đẹp của dân tộc?','Tìm hiểu lịch sử, văn hóa dân tộc; học tập, rèn luyện tốt; giữ gìn tiếng Việt, lễ hội, di sản; sống nhân nghĩa, yêu nước; quảng bá văn hóa dân tộc.'],
  [3,'Vì sao cần tự hào về truyền thống dân tộc Việt Nam?','Giúp bồi đắp lòng yêu nước, ý chí tự lực tự cường, tạo động lực xây dựng và bảo vệ Tổ quốc, giữ gìn bản sắc dân tộc.'],
  [4,'Theo em, tự hào về truyền thống dân tộc có mâu thuẫn với việc hội nhập quốc tế không? Vì sao?','Không mâu thuẫn. Cần giữ gìn, phát huy bản sắc dân tộc đồng thời tiếp thu tinh hoa văn hóa nhân loại; "hòa nhập chứ không hòa tan". Kết hợp hài hòa giúp dân tộc vừa giữ bản sắc vừa phát triển.']
 ]);
 add(M,8,'Bài 2: Tôn trọng sự đa dạng của các dân tộc',[
  [1,'Tôn trọng sự đa dạng của các dân tộc là gì?','Tôn trọng truyền thống, phong tục, văn hóa của các dân tộc, quốc gia khác','Kì thị dân tộc khác','Chỉ coi trọng dân tộc mình','Chê bai văn hóa khác'],
  [1,'Hành vi nào thể hiện tôn trọng sự đa dạng của các dân tộc?','Tìm hiểu, học hỏi, tôn trọng văn hóa các dân tộc','Kì thị','Phân biệt chủng tộc','Chế giễu phong tục khác'],
  [2,'Vì sao cần tôn trọng sự đa dạng của các dân tộc?','Giúp các dân tộc hiểu biết, hợp tác, cùng phát triển và giữ hòa bình','Để gây chia rẽ','Không cần thiết','Để coi thường nhau'],
  [2,'Biểu hiện nào trái với tôn trọng sự đa dạng của các dân tộc?','Kì thị, phân biệt chủng tộc, bài ngoại cực đoan','Học hỏi lẫn nhau','Giao lưu văn hóa','Hợp tác hữu nghị'],
  [3,'Nêu ý nghĩa của việc tôn trọng sự đa dạng của các dân tộc trên thế giới.','Giúp các dân tộc xích lại gần nhau, học hỏi tinh hoa của nhau, hợp tác phát triển, giữ gìn hòa bình và làm phong phú nền văn hóa nhân loại.'],
  [3,'Em thể hiện sự tôn trọng đa dạng văn hóa các dân tộc như thế nào?','Tìm hiểu, học hỏi văn hóa các dân tộc; không kì thị; tiếp thu có chọn lọc; tôn trọng sự khác biệt; ứng xử văn minh với người nước ngoài.'],
  [4,'Theo em, tiếp thu văn hóa nước ngoài cần có thái độ như thế nào mới đúng đắn?','Tiếp thu có chọn lọc: học cái hay, tiến bộ, phù hợp; giữ gìn bản sắc dân tộc; không sùng ngoại, không bài ngoại cực đoan; tránh tiếp thu những thứ xấu, không phù hợp thuần phong mĩ tục.']
 ]);
 add(M,8,'Bài 3: Lao động cần cù, sáng tạo',[
  [1,'Lao động cần cù là gì?','Chăm chỉ, chịu khó, làm việc thường xuyên','Lười biếng','Làm qua loa','Trốn việc'],
  [1,'Lao động sáng tạo là gì?','Luôn tìm tòi, cải tiến cách làm để đạt kết quả cao hơn','Làm theo lối mòn','Rập khuôn','Ngại đổi mới'],
  [2,'Biểu hiện nào thể hiện lao động cần cù, sáng tạo trong học tập?','Chăm học, tìm cách học hiệu quả, cải tiến phương pháp','Chép bài','Học vẹt','Ỷ lại'],
  [2,'Vì sao cần lao động cần cù, sáng tạo?','Nâng cao năng suất, chất lượng; giúp bản thân phát triển và xã hội tiến bộ','Để mệt mỏi','Không cần thiết','Để lãng phí'],
  [3,'Nêu những việc học sinh nên làm để rèn luyện lao động cần cù, sáng tạo.','Chăm chỉ học tập và lao động; tìm phương pháp học hiệu quả; chủ động cải tiến cách làm việc nhà, học tập; không ngại khó, không rập khuôn.'],
  [3,'Lao động cần cù, sáng tạo mang lại lợi ích gì cho mỗi người và xã hội?','Giúp cá nhân thành công, phát triển bản thân; tạo ra nhiều của cải, giá trị mới; thúc đẩy xã hội phát triển, văn minh.'],
  [4,'Có ý kiến: "Chỉ cần cần cù là đủ, không cần sáng tạo." Em có đồng ý không? Vì sao?','Không đồng ý. Cần cù giúp chăm chỉ nhưng nếu thiếu sáng tạo thì làm việc kém hiệu quả, lạc hậu. Cần kết hợp cần cù với sáng tạo để nâng cao năng suất, chất lượng và theo kịp sự phát triển.']
 ]);
 add(M,8,'Bài 4: Bảo vệ lẽ phải',[
  [1,'Lẽ phải là gì?','Những điều đúng đắn, phù hợp đạo lí và lợi ích chung','Điều sai trái','Ý muốn cá nhân','Điều có lợi riêng'],
  [1,'Bảo vệ lẽ phải là gì?','Công nhận, ủng hộ, tuân theo và bảo vệ điều đúng đắn','Bao che cái sai','Theo số đông','Im lặng trước cái sai'],
  [2,'Hành vi nào thể hiện bảo vệ lẽ phải?','Dám nói lên sự thật, bênh vực điều đúng','Dối trá','Xu nịnh','A dua theo cái sai'],
  [2,'Biểu hiện nào trái với bảo vệ lẽ phải?','Gió chiều nào che chiều ấy, bao che cái sai','Thẳng thắn','Công bằng','Trung thực'],
  [3,'Em chứng kiến một bạn bị đổ oan về việc mình không làm. Em nên làm gì để bảo vệ lẽ phải?','Dũng cảm nói lên sự thật mình biết để minh oan cho bạn; nếu cần báo thầy cô. Bảo vệ lẽ phải là bảo vệ điều đúng, dù có thể gặp khó khăn.'],
  [3,'Nêu ý nghĩa của việc bảo vệ lẽ phải trong cuộc sống.','Giúp duy trì công bằng, đẩy lùi cái xấu; được mọi người tin yêu, tôn trọng; góp phần xây dựng xã hội lành mạnh, tốt đẹp.'],
  [4,'Vì sao bảo vệ lẽ phải đôi khi đòi hỏi sự dũng cảm?','Vì bảo vệ lẽ phải có khi phải đấu tranh với cái sai, với số đông hoặc chịu thiệt thòi, áp lực. Người bảo vệ lẽ phải cần bản lĩnh, dũng cảm, kiên định với điều đúng.']
 ]);
 add(M,8,'Bài 5: Bảo vệ môi trường và tài nguyên thiên nhiên',[
  [1,'Tài nguyên thiên nhiên là gì?','Của cải có sẵn trong tự nhiên mà con người khai thác, sử dụng','Sản phẩm công nghiệp','Hàng hóa mua bán','Đồ dùng tự chế tạo'],
  [1,'Hành vi nào bảo vệ môi trường?','Trồng cây, phân loại rác, tiết kiệm tài nguyên','Xả rác bừa bãi','Chặt phá rừng','Đổ nước thải ra sông'],
  [2,'Hành vi nào gây ô nhiễm, hủy hoại môi trường?','Xả rác, nước thải chưa xử lí; chặt phá rừng; săn bắt động vật quý','Trồng rừng','Tái chế rác','Dùng năng lượng sạch'],
  [2,'Vì sao phải bảo vệ môi trường và tài nguyên thiên nhiên?','Vì môi trường, tài nguyên cần cho sự sống và phát triển; bảo vệ để phát triển bền vững cho hiện tại và tương lai','Để lãng phí','Không cần thiết','Để khai thác cạn kiệt'],
  [3,'Nêu những việc học sinh có thể làm để bảo vệ môi trường và tài nguyên thiên nhiên.','Tiết kiệm điện, nước, giấy; phân loại, bỏ rác đúng nơi; hạn chế túi ni-lông, đồ nhựa dùng một lần; trồng và chăm sóc cây; tuyên truyền bảo vệ môi trường.'],
  [3,'Nêu một số hậu quả của việc môi trường bị ô nhiễm, tài nguyên bị cạn kiệt.','Biến đổi khí hậu, thiên tai, bệnh tật; thiếu nước sạch, đất đai bạc màu; ảnh hưởng sức khỏe và đời sống con người, cản trở phát triển.'],
  [4,'Theo em, phát triển kinh tế và bảo vệ môi trường cần được giải quyết như thế nào?','Phải hài hòa, phát triển bền vững: khai thác, sử dụng tài nguyên hợp lí gắn với bảo vệ môi trường; không vì lợi ích trước mắt mà hủy hoại môi trường, gây hậu quả lâu dài cho thế hệ sau.']
 ]);
 add(M,8,'Bài 6: Xác định mục tiêu cá nhân',[
  [1,'Mục tiêu cá nhân là gì?','Kết quả cụ thể mà mỗi người mong muốn đạt được trong một thời gian nhất định','Điều viển vông','Việc của người khác','Điều không cần cố gắng'],
  [1,'Mục tiêu cá nhân được chia theo thời gian gồm những loại nào?','Mục tiêu ngắn hạn và dài hạn','Chỉ dài hạn','Chỉ ngắn hạn','Không phân loại'],
  [2,'Một mục tiêu được coi là phù hợp cần bảo đảm yêu cầu nào?','Cụ thể, đo lường được, khả thi, có thời hạn','Mơ hồ','Xa rời thực tế','Không có thời hạn'],
  [2,'Vì sao cần xác định mục tiêu cá nhân?','Giúp định hướng, có kế hoạch và động lực phấn đấu để thành công','Để lãng phí thời gian','Không cần thiết','Để bị động'],
  [3,'Hãy xác định một mục tiêu học tập trong học kì này của em và cách thực hiện.','HS nêu mục tiêu cụ thể (VD: đạt học sinh giỏi môn Toán) và các bước: lập kế hoạch, học đều, làm bài tập, nhờ thầy cô giúp, kiểm tra tiến độ.'],
  [3,'Nêu các bước để lập và thực hiện mục tiêu cá nhân.','Xác định mục tiêu cụ thể; lập kế hoạch, chia nhỏ việc cần làm; thực hiện và theo dõi; điều chỉnh khi cần; đánh giá kết quả.'],
  [4,'Vì sao mục tiêu cần cụ thể và khả thi thì mới dễ thực hiện?','Mục tiêu cụ thể giúp biết rõ phải làm gì, đo được tiến độ; khả thi giúp không nản lòng. Mục tiêu mơ hồ hoặc quá sức dễ khiến bỏ cuộc, không đạt kết quả.']
 ]);
 add(M,8,'Bài 7: Phòng, chống bạo lực gia đình',[
  [1,'Bạo lực gia đình là gì?','Hành vi gây tổn hại về thể chất, tinh thần, kinh tế... giữa các thành viên trong gia đình','Sự quan tâm','Việc giáo dục con đúng mực','Sự chia sẻ'],
  [1,'Hành vi nào là bạo lực gia đình?','Đánh đập, lăng mạ, hành hạ người thân','Chăm sóc nhau','Dạy con bằng lời khuyên','Yêu thương'],
  [2,'Khi chứng kiến hoặc là nạn nhân của bạo lực gia đình, nên làm gì?','Tìm nơi an toàn, báo người lớn tin cậy, cơ quan chức năng (gọi 111)','Im lặng chịu đựng','Giấu giếm','Dùng bạo lực đáp trả'],
  [2,'Việc làm nào góp phần phòng, chống bạo lực gia đình?','Yêu thương, tôn trọng, chia sẻ, giải quyết mâu thuẫn ôn hòa','Dùng vũ lực','Quát mắng','Xúc phạm nhau'],
  [3,'Nêu tác hại của bạo lực gia đình đối với các thành viên và xã hội.','Gây tổn thương thể chất, tinh thần; làm tan vỡ hạnh phúc gia đình; ảnh hưởng tâm lí, học tập của trẻ em; gây mất trật tự xã hội, vi phạm pháp luật.'],
  [3,'Là học sinh, em làm gì để góp phần phòng, chống bạo lực gia đình?','Sống yêu thương, lễ phép; biết chia sẻ, giúp đỡ người thân; khuyên can khi có mâu thuẫn; báo người lớn tin cậy hoặc tổng đài 111 khi có bạo lực.'],
  [4,'Vì sao nói phòng, chống bạo lực gia đình là trách nhiệm của mỗi người và toàn xã hội?','Vì gia đình là tế bào của xã hội; bạo lực gia đình gây hậu quả nặng nề cho cá nhân và cộng đồng. Mỗi người sống trách nhiệm, lên tiếng ngăn chặn và cùng xã hội, pháp luật bảo vệ nạn nhân mới xây dựng được gia đình, xã hội an toàn, hạnh phúc.']
 ]);
 add(M,8,'Bài 8: Lập kế hoạch chi tiêu',[
  [1,'Lập kế hoạch chi tiêu là gì?','Xác định các khoản thu, chi và cách sử dụng tiền hợp lí','Tiêu tùy hứng','Vay mượn bừa bãi','Không quản lí tiền'],
  [1,'Việc làm nào thể hiện chi tiêu có kế hoạch?','Ghi chép khoản thu chi, ưu tiên việc cần thiết, tiết kiệm','Mua theo cảm hứng','Tiêu hết ngay','Chạy theo mốt'],
  [2,'Bước đầu tiên khi lập kế hoạch chi tiêu là gì?','Xác định các khoản thu và nhu cầu chi tiêu','Mua sắm trước','Vay tiền','Tiêu hết rồi tính'],
  [2,'Vì sao cần lập kế hoạch chi tiêu?','Giúp sử dụng tiền hợp lí, tránh lãng phí, có khoản tiết kiệm, chủ động tài chính','Để tiêu nhiều hơn','Không cần thiết','Để mắc nợ'],
  [3,'Em được cho 600 000 đồng cho một tháng. Hãy lập kế hoạch chi tiêu hợp lí.','Phân bổ: khoản cần thiết (đồ dùng học tập, ăn sáng); khoản tiết kiệm; khoản dự phòng; khoản nhỏ cho giải trí; ghi chép và theo dõi để điều chỉnh.'],
  [3,'Nêu các bước lập kế hoạch chi tiêu hợp lí.','Xác định khoản thu; liệt kê và phân loại nhu cầu (thiết yếu – không thiết yếu); đặt hạn mức cho từng khoản; thực hiện, ghi chép; đánh giá, điều chỉnh.'],
  [4,'Vì sao lập kế hoạch chi tiêu giúp rèn luyện tính tự chủ và trách nhiệm?','Khi lập kế hoạch, ta phải cân nhắc nhu cầu, kiểm soát mong muốn, ưu tiên việc cần thiết và chịu trách nhiệm với quyết định chi tiêu; qua đó hình thành tính tự chủ, kỉ luật và trách nhiệm với bản thân, gia đình.']
 ]);
 add(M,8,'Bài 9: Phòng ngừa tai nạn vũ khí, cháy, nổ và các chất độc hại',[
  [1,'Vật nào dưới đây dễ gây cháy, nổ?','Xăng, dầu, ga, pháo','Nước lọc','Quyển sách','Cái bàn'],
  [1,'Hành vi nào có nguy cơ gây tai nạn cháy, nổ?','Để bật lửa, diêm gần nơi có xăng, ga; đốt pháo','Tắt bếp sau khi dùng','Để xa nguồn lửa','Kiểm tra bình ga'],
  [2,'Khi phát hiện rò rỉ khí ga trong nhà, em nên làm gì?','Khóa van ga, mở cửa thông thoáng, không bật lửa, công tắc điện','Bật quạt điện','Bật bếp kiểm tra','Dùng điện thoại trong phòng'],
  [2,'Số điện thoại gọi cứu hỏa khi có cháy là số nào?','114','113','115','111'],
  [3,'Nêu một số việc cần làm để phòng ngừa tai nạn vũ khí, cháy, nổ và chất độc hại.','Không nghịch, tàng trữ vũ khí, pháo, chất nổ; để xa lửa những vật dễ cháy; kiểm tra bếp, điện; không ăn uống chất không rõ nguồn gốc; tuân thủ quy định an toàn.'],
  [3,'Khi xảy ra cháy, em cần xử lí như thế nào để bảo đảm an toàn?','Bình tĩnh báo động, gọi 114; thoát theo lối thoát hiểm; cúi thấp tránh khói, dùng khăn ẩm che mũi miệng; không trốn vào nơi kín; không quay lại lấy tài sản.'],
  [4,'Vì sao phòng ngừa tai nạn vũ khí, cháy, nổ, chất độc hại là trách nhiệm của mọi công dân?','Vì những tai nạn này gây hậu quả nghiêm trọng về tính mạng, tài sản, môi trường cho cá nhân và cộng đồng. Mỗi người chấp hành quy định an toàn, cảnh giác, tố giác vi phạm sẽ giúp phòng ngừa, bảo vệ an toàn chung.']
 ]);
 add(M,8,'Bài 10: Quyền và nghĩa vụ lao động của công dân',[
  [1,'Lao động là gì?','Hoạt động có mục đích của con người tạo ra của cải vật chất và tinh thần','Việc vui chơi','Nghỉ ngơi','Hoạt động vô ích'],
  [1,'Lao động là quyền hay nghĩa vụ của công dân?','Vừa là quyền, vừa là nghĩa vụ của công dân','Chỉ là quyền','Chỉ là nghĩa vụ','Không bắt buộc'],
  [2,'Hành vi nào vi phạm pháp luật về lao động?','Thuê trẻ em làm công việc nặng nhọc, độc hại','Trả lương đúng hạn','Bảo đảm an toàn lao động','Kí hợp đồng lao động'],
  [2,'Vì sao lao động có vai trò quan trọng?','Tạo ra của cải, nuôi sống con người, phát triển xã hội; giúp con người hoàn thiện bản thân','Làm con người mệt mỏi vô ích','Không cần thiết','Chỉ để kiếm tiền'],
  [3,'Là học sinh, em thực hiện quyền và nghĩa vụ lao động như thế nào?','Lao động chính của học sinh là học tập; ngoài ra tự giác làm việc nhà, lao động tập thể, giữ vệ sinh trường lớp; quý trọng thành quả lao động.'],
  [3,'Nêu một số quy định của pháp luật nhằm bảo vệ người lao động.','Bảo đảm thời giờ làm việc, nghỉ ngơi; an toàn, vệ sinh lao động; trả lương đúng; cấm sử dụng lao động trẻ em trái pháp luật; kí hợp đồng lao động.'],
  [4,'Vì sao nói lao động là nghĩa vụ của công dân đối với bản thân, gia đình và xã hội?','Lao động nuôi sống bản thân, gia đình, tạo của cải cho xã hội; mỗi người lao động góp phần xây dựng đất nước. Không lao động, sống ỷ lại là trốn tránh nghĩa vụ, là gánh nặng cho gia đình và xã hội.']
 ]);
 add(M,8,'Đạo đức và lối sống',[
  [1,'Phẩm chất nào giúp con người đạt kết quả cao trong lao động, học tập?','Cần cù, sáng tạo','Lười biếng','Ỷ lại','Cẩu thả'],
  [2,'Hành vi nào thể hiện sống có đạo đức?','Bảo vệ lẽ phải, trung thực, yêu thương con người','Dối trá','Vô cảm','Bao che cái sai'],
  [2,'Tự hào về truyền thống dân tộc giúp mỗi người điều gì?','Thêm yêu nước, có ý chí vươn lên, giữ gìn bản sắc','Coi thường dân tộc khác','Tự ti','Sùng ngoại'],
  [3,'Nêu những phẩm chất đạo đức, lối sống tốt đẹp mà học sinh cần rèn luyện.','Yêu nước, nhân ái, trung thực, cần cù sáng tạo, bảo vệ lẽ phải, tôn trọng người khác, sống có trách nhiệm.'],
  [4,'Theo em, vì sao đạo đức là nền tảng để mỗi người phát triển và thành công bền vững?','Người có đạo đức được tin yêu, tạo quan hệ tốt, biết sống đúng và có trách nhiệm; tài năng phải đi cùng đạo đức mới có ích. "Có tài mà không có đức là người vô dụng" — đạo đức là gốc cho sự phát triển bền vững.']
 ]);
 add(M,8,'Pháp luật, kinh tế',[
  [1,'Lao động đối với công dân là gì?','Vừa là quyền vừa là nghĩa vụ','Chỉ là quyền','Chỉ là nghĩa vụ','Việc tùy thích'],
  [2,'Lập kế hoạch chi tiêu giúp ích gì?','Sử dụng tiền hợp lí, tiết kiệm, chủ động tài chính','Tiêu nhiều hơn','Mắc nợ','Lãng phí'],
  [2,'Hành vi nào vi phạm pháp luật lao động?','Sử dụng lao động trẻ em làm việc nặng, độc hại','Trả lương đúng hạn','Bảo đảm an toàn lao động','Kí hợp đồng'],
  [3,'Nêu ý nghĩa của việc biết quản lí tài chính, lập kế hoạch chi tiêu đối với học sinh.','Rèn tính tiết kiệm, tự chủ; biết quý trọng giá trị lao động; tránh lãng phí; tạo thói quen tốt cho cuộc sống sau này.'],
  [4,'Vì sao pháp luật quy định lao động vừa là quyền vừa là nghĩa vụ của công dân?','Vì lao động giúp công dân nuôi sống bản thân, phát triển và đóng góp cho xã hội. Là quyền để công dân được làm việc, có thu nhập; là nghĩa vụ vì mỗi người cần lao động góp phần xây dựng đất nước, không sống ỷ lại.']
 ]);
 add(M,8,'Trách nhiệm và kĩ năng công dân',[
  [1,'Khi gặp rò rỉ ga, nguy cơ cháy nổ, việc nên làm đầu tiên là gì?','Khóa van ga, mở cửa thông thoáng, không bật lửa/điện','Bật quạt','Bật đèn','Gọi điện ngay trong phòng'],
  [2,'Việc xác định mục tiêu cá nhân giúp em điều gì?','Có định hướng, kế hoạch và động lực phấn đấu','Lãng phí thời gian','Bị động','Mất phương hướng'],
  [2,'Khi là nạn nhân của bạo lực gia đình, em nên liên hệ tổng đài bảo vệ trẻ em nào?','111','113','114','115'],
  [3,'Nêu những kĩ năng cần thiết giúp công dân ứng phó với các tình huống nguy hiểm trong cuộc sống.','Bình tĩnh nhận diện nguy hiểm; biết thoát hiểm, sơ cứu cơ bản; nhớ số khẩn cấp (111, 113, 114, 115); biết tìm sự giúp đỡ; phòng ngừa tai nạn.'],
  [4,'Theo em, vì sao mỗi công dân cần rèn luyện kĩ năng sống và tinh thần trách nhiệm?','Để tự bảo vệ mình và người khác, ứng phó tốt với tình huống nguy hiểm, sống an toàn; đồng thời biết sống có trách nhiệm với bản thân, gia đình, cộng đồng, góp phần xây dựng xã hội an toàn, văn minh.']
 ]);
 add(M,8,'Quyền và bổn phận',[
  [1,'Bảo vệ môi trường và tài nguyên thiên nhiên là gì của công dân?','Quyền và nghĩa vụ','Việc tùy thích','Điều cấm','Việc của riêng Nhà nước'],
  [2,'Hành vi nào thực hiện đúng nghĩa vụ bảo vệ môi trường?','Phân loại rác, tiết kiệm tài nguyên, trồng cây','Xả rác bừa bãi','Phá rừng','Săn bắt động vật quý'],
  [2,'Học sinh thực hiện quyền và bổn phận của mình chủ yếu qua việc gì?','Học tập tốt, rèn đạo đức, chấp hành pháp luật','Trốn học','Vi phạm nội quy','Ỷ lại'],
  [3,'Nêu một số quyền và bổn phận cơ bản của công dân mà em biết.','Quyền: lao động, học tập, được bảo vệ... Bổn phận/nghĩa vụ: tuân theo pháp luật, bảo vệ môi trường, bảo vệ Tổ quốc, lao động, học tập tốt.'],
  [4,'Vì sao quyền của công dân luôn gắn liền với nghĩa vụ?','Vì hưởng quyền phải đi đôi với làm tròn nghĩa vụ thì xã hội mới công bằng, trật tự, phát triển. Nếu chỉ đòi quyền mà không thực hiện nghĩa vụ, hoặc ngược lại, đều không bảo đảm được lợi ích chung và sự ổn định xã hội.']
 ]);

 /* -------- LỚP 9 -------- */
 add(M,9,'Bài 1: Sống có lí tưởng',[
  [1,'Lí tưởng sống là gì?','Mục đích cao đẹp, lẽ sống mà con người mong muốn hướng tới','Việc làm tùy hứng','Điều viển vông','Lợi ích trước mắt'],
  [1,'Lí tưởng sống cao đẹp của thanh niên Việt Nam hiện nay là gì?','Phấn đấu vì dân giàu, nước mạnh, dân chủ, công bằng, văn minh','Chỉ lo hưởng thụ','Sống ích kỉ','Chạy theo đồng tiền bằng mọi giá'],
  [2,'Biểu hiện của người sống có lí tưởng là gì?','Có mục tiêu cao đẹp, nỗ lực học tập, cống hiến cho đất nước','Sống buông thả','Không có mục tiêu','Thờ ơ với cộng đồng'],
  [2,'Vì sao thanh niên cần sống có lí tưởng?','Giúp có động lực, định hướng phấn đấu, sống đẹp và cống hiến cho xã hội','Để lãng phí tuổi trẻ','Không cần thiết','Để sống ích kỉ'],
  [3,'Là học sinh, em xác định lí tưởng sống của mình và rèn luyện như thế nào?','Xác định mục tiêu học tập, rèn luyện để trở thành người có ích; chăm học, rèn đạo đức, tham gia hoạt động xã hội; góp sức xây dựng và bảo vệ Tổ quốc.'],
  [3,'Nêu ý nghĩa của việc sống có lí tưởng đối với bản thân và xã hội.','Giúp cá nhân sống có mục đích, nghị lực, thành công và hạnh phúc; đóng góp cho cộng đồng, thúc đẩy xã hội phát triển, đất nước giàu mạnh.'],
  [4,'Theo em, vì sao nói "sống không có lí tưởng là sống hoài, sống phí"?','Người không có lí tưởng thiếu mục tiêu, động lực, dễ buông thả, sống vô nghĩa, không đóng góp gì. Sống có lí tưởng giúp tuổi trẻ phấn đấu, cống hiến, để cuộc đời có ý nghĩa và giá trị.']
 ]);
 add(M,9,'Bài 2: Khoan dung',[
  [1,'Khoan dung là gì?','Rộng lòng tha thứ cho người khác khi họ biết lỗi và sửa chữa','Cố chấp','Thù hằn','Trừng phạt'],
  [1,'Hành vi nào thể hiện lòng khoan dung?','Tha thứ, cảm thông, tạo cơ hội sửa sai cho người khác','Chấp nhặt','Trả thù','Định kiến'],
  [2,'Biểu hiện nào trái với khoan dung?','Hẹp hòi, cố chấp, định kiến','Rộng lượng','Cảm thông','Tha thứ'],
  [2,'Vì sao cần có lòng khoan dung?','Giúp quan hệ tốt đẹp, mọi người gần gũi, bản thân thanh thản, xã hội hòa thuận','Để bị lợi dụng','Không cần thiết','Để dung túng cái sai'],
  [3,'Bạn đã lỡ làm em buồn và đã xin lỗi, nhận ra lỗi của mình. Em nên cư xử thế nào?','Vui vẻ tha thứ cho bạn, bỏ qua lỗi lầm; tiếp tục giữ tình bạn tốt. Khoan dung giúp cả hai nhẹ lòng và quan hệ bền chặt hơn.'],
  [3,'Nêu ý nghĩa của lòng khoan dung trong cuộc sống.','Giúp con người sống nhân ái, bao dung; hóa giải mâu thuẫn; tạo cơ hội để người mắc lỗi sửa chữa; làm cuộc sống và xã hội tốt đẹp, hòa thuận hơn.'],
  [4,'Khoan dung có nghĩa là bỏ qua, dung túng cho mọi lỗi lầm không? Vì sao?','Không. Khoan dung là tha thứ cho người biết lỗi và sửa chữa, không phải dung túng, bao che cái sai. Với hành vi sai trái, cần phê phán, giúp sửa chữa; khoan dung đi đôi với tôn trọng lẽ phải và công bằng.']
 ]);
 add(M,9,'Bài 3: Tích cực tham gia các hoạt động cộng đồng',[
  [1,'Hoạt động cộng đồng là gì?','Hoạt động do cộng đồng tổ chức nhằm mang lại lợi ích chung','Việc riêng của cá nhân','Hoạt động vô ích','Việc chỉ của Nhà nước'],
  [1,'Hoạt động nào là hoạt động cộng đồng?','Dọn vệ sinh khu phố, hiến máu, giúp đỡ người khó khăn','Chơi game một mình','Xem phim ở nhà','Đi du lịch riêng'],
  [2,'Việc tích cực tham gia hoạt động cộng đồng thể hiện điều gì?','Tinh thần trách nhiệm, sống vì mọi người','Ích kỉ','Thờ ơ','Vô cảm'],
  [2,'Vì sao cần tích cực tham gia các hoạt động cộng đồng?','Góp phần xây dựng cộng đồng, rèn kĩ năng, mở rộng hiểu biết và sống có ý nghĩa','Để mất thời gian','Không có lợi','Để được khen thưởng'],
  [3,'Kể một số hoạt động cộng đồng mà học sinh có thể tham gia.','Dọn vệ sinh trường lớp, khu phố; quyên góp ủng hộ; thăm hỏi gia đình chính sách, người già neo đơn; trồng cây; tuyên truyền an toàn giao thông, bảo vệ môi trường.'],
  [3,'Nêu ý nghĩa của việc tham gia hoạt động cộng đồng đối với bản thân và xã hội.','Giúp bản thân rèn kĩ năng, trưởng thành, sống có trách nhiệm; gắn kết mọi người, giải quyết vấn đề chung, xây dựng cộng đồng văn minh, tốt đẹp.'],
  [4,'Theo em, vì sao mỗi người đều có trách nhiệm với cộng đồng mình đang sống?','Vì mỗi người là một thành viên của cộng đồng, hưởng lợi ích chung và chịu ảnh hưởng của cộng đồng. Mỗi đóng góp dù nhỏ đều góp phần làm cộng đồng tốt đẹp hơn; sống vô trách nhiệm sẽ ảnh hưởng xấu đến mọi người.']
 ]);
 add(M,9,'Bài 4: Khách quan và công bằng',[
  [1,'Khách quan là gì?','Nhìn nhận sự vật, sự việc đúng bản chất, không thiên vị','Thiên vị','Áp đặt ý riêng','Nhìn phiến diện'],
  [1,'Công bằng là gì?','Đối xử bình đẳng, đúng lẽ phải, không thiên vị','Bất công','Ưu ái người thân','Phân biệt đối xử'],
  [2,'Hành vi nào thể hiện sự khách quan, công bằng?','Đánh giá đúng năng lực, đối xử bình đẳng với mọi người','Thiên vị bạn thân','Trù dập người mình ghét','Bao che người thân'],
  [2,'Vì sao cần sống khách quan, công bằng?','Bảo đảm lẽ phải, niềm tin, quan hệ tốt đẹp và xã hội công bằng','Để gây mất đoàn kết','Không cần thiết','Để có lợi riêng'],
  [3,'Là lớp trưởng, khi đánh giá thi đua các bạn, em cần làm gì để bảo đảm khách quan, công bằng?','Dựa vào kết quả, hành vi thực tế của từng bạn; không thiên vị bạn thân hay thành kiến với bạn khác; công khai, minh bạch tiêu chí đánh giá.'],
  [3,'Nêu ý nghĩa của khách quan và công bằng trong cuộc sống.','Giúp đánh giá đúng, giải quyết công việc hợp lí; tạo niềm tin, sự đoàn kết; bảo đảm quyền lợi chính đáng của mọi người; xây dựng xã hội công bằng, văn minh.'],
  [4,'Theo em, thiếu khách quan, công bằng sẽ dẫn đến hậu quả gì?','Dẫn đến đánh giá sai, bất công, làm mất niềm tin, gây mâu thuẫn, bất mãn; người tốt không được ghi nhận, cái sai không bị phê phán, ảnh hưởng xấu đến tập thể và xã hội.']
 ]);
 add(M,9,'Bài 5: Bảo vệ hoà bình',[
  [1,'Hòa bình là gì?','Tình trạng không có chiến tranh hay xung đột vũ trang','Chiến tranh','Xung đột','Bạo loạn'],
  [1,'Bảo vệ hòa bình là gì?','Giữ gìn cuộc sống bình yên, dùng thương lượng để giải quyết mâu thuẫn','Gây chiến','Dùng vũ lực','Kích động xung đột'],
  [2,'Hành vi nào thể hiện lòng yêu hòa bình?','Tôn trọng, sống hòa thuận; ủng hộ hoạt động vì hòa bình','Gây gổ, bạo lực','Kích động chia rẽ','Cổ vũ chiến tranh'],
  [2,'Vì sao cần bảo vệ hòa bình?','Vì hòa bình đem lại cuộc sống ấm no, hạnh phúc; chiến tranh gây đau thương, mất mát','Để gây chiến tranh','Không cần thiết','Để tranh giành'],
  [3,'Là học sinh, em làm gì để góp phần bảo vệ hòa bình?','Sống hòa đồng, thân ái, giải quyết mâu thuẫn bằng thương lượng; không bạo lực; tôn trọng sự khác biệt; tham gia hoạt động vì hòa bình, hữu nghị.'],
  [3,'Nêu ý nghĩa của việc bảo vệ hòa bình đối với mỗi quốc gia và nhân loại.','Hòa bình giúp các nước phát triển kinh tế, văn hóa, con người được sống ấm no, hạnh phúc; bảo vệ hòa bình là bảo vệ cuộc sống, là khát vọng của toàn nhân loại.'],
  [4,'Vì sao nói giải quyết mâu thuẫn bằng thương lượng, hòa bình tốt hơn dùng bạo lực?','Bạo lực gây tổn thương, thù hận, hậu quả nặng nề và không giải quyết tận gốc vấn đề. Thương lượng, đối thoại giúp các bên hiểu nhau, tìm giải pháp hợp lí, giữ quan hệ tốt đẹp và hòa bình lâu dài.']
 ]);
 add(M,9,'Bài 6: Quản lí thời gian hiệu quả',[
  [1,'Quản lí thời gian hiệu quả là gì?','Sắp xếp, sử dụng thời gian hợp lí để đạt mục tiêu','Lãng phí thời gian','Làm việc tùy hứng','Để nước đến chân mới nhảy'],
  [1,'Việc làm nào thể hiện quản lí thời gian tốt?','Lập thời gian biểu, làm việc đúng kế hoạch, ưu tiên việc quan trọng','Trì hoãn','Ôm đồm','Bỏ dở công việc'],
  [2,'Nguyên tắc nào giúp quản lí thời gian hiệu quả?','Xác định ưu tiên, phân bổ thời gian hợp lí, tránh trì hoãn','Làm việc không kế hoạch','Để tùy hứng','Ôm nhiều việc cùng lúc'],
  [2,'Vì sao cần quản lí thời gian hiệu quả?','Giúp hoàn thành công việc, học tập tốt, giảm căng thẳng, có thời gian nghỉ ngơi','Để mệt mỏi','Không cần thiết','Để lãng phí'],
  [3,'Hãy lập thời gian biểu một ngày học tập và sinh hoạt hợp lí của em.','HS lập thời gian biểu có các mốc: học trên lớp, tự học, giúp việc nhà, thể dục, giải trí, nghỉ ngơi; cân đối, khả thi.'],
  [3,'Nêu lợi ích của việc quản lí thời gian hiệu quả đối với học sinh.','Hoàn thành bài vở đúng hạn, học tập tiến bộ; có thời gian nghỉ ngơi, rèn luyện; giảm căng thẳng; hình thành tính kỉ luật, chủ động.'],
  [4,'Theo em, vì sao "thời gian là vàng bạc" nhưng nhiều người vẫn lãng phí thời gian?','Vì thời gian đã qua không lấy lại được, dùng tốt sẽ tạo ra giá trị. Nhiều người lãng phí do thiếu mục tiêu, hay trì hoãn, sa đà giải trí vô bổ. Cần ý thức quý trọng và quản lí thời gian để không bỏ phí tuổi trẻ.']
 ]);
 add(M,9,'Bài 7: Thích ứng với thay đổi',[
  [1,'Thích ứng với thay đổi là gì?','Điều chỉnh bản thân để phù hợp với hoàn cảnh mới','Bảo thủ','Chối bỏ thực tế','Buông xuôi'],
  [1,'Thái độ nào giúp con người thích ứng tốt với thay đổi?','Bình tĩnh, chủ động, tích cực tìm cách giải quyết','Hoảng loạn','Né tránh','Than vãn'],
  [2,'Khi gặp thay đổi bất ngờ (chuyển trường, hoàn cảnh khó khăn), nên làm gì?','Bình tĩnh chấp nhận, tìm cách thích nghi và giải quyết','Buông xuôi','Chán nản','Đổ lỗi hoàn cảnh'],
  [2,'Vì sao cần rèn khả năng thích ứng với thay đổi?','Cuộc sống luôn biến đổi; biết thích ứng giúp vượt qua khó khăn, phát triển và thành công','Để bị động','Không cần thiết','Để chối bỏ thực tế'],
  [3,'Nêu một tình huống thay đổi trong cuộc sống và cách em thích ứng.','HS nêu tình huống (chuyển cấp, xa bạn, hoàn cảnh gia đình...) và cách thích ứng tích cực: bình tĩnh, lập kế hoạch, nhờ giúp đỡ, cố gắng thích nghi.'],
  [3,'Nêu các kĩ năng giúp con người thích ứng với thay đổi.','Giữ bình tĩnh, suy nghĩ tích cực; chủ động học hỏi cái mới; lập kế hoạch; linh hoạt điều chỉnh; tìm sự hỗ trợ khi cần.'],
  [4,'Theo em, vì sao khả năng thích ứng với thay đổi ngày càng quan trọng trong xã hội hiện đại?','Vì xã hội hiện đại thay đổi nhanh (công nghệ, công việc, môi trường...). Người biết thích ứng sẽ nắm bắt cơ hội, vượt qua thách thức, không bị tụt hậu; thiếu khả năng thích ứng dễ bị động, khó phát triển.']
 ]);
 add(M,9,'Bài 8: Tiêu dùng thông minh',[
  [1,'Tiêu dùng thông minh là gì?','Mua và sử dụng hàng hóa hợp lí, hiệu quả, phù hợp nhu cầu và khả năng','Mua sắm tùy hứng','Chạy theo mốt','Lãng phí'],
  [1,'Việc làm nào thể hiện tiêu dùng thông minh?','Lập kế hoạch, so sánh giá, chọn hàng chất lượng, cần mới mua','Mua theo quảng cáo','Mua vì bạn có','Mua rồi bỏ'],
  [2,'Trước khi mua một món hàng, người tiêu dùng thông minh cần làm gì?','Xác định nhu cầu, tìm hiểu thông tin, so sánh chất lượng và giá','Mua ngay không suy nghĩ','Mua theo cảm hứng','Mua vì rẻ dù không cần'],
  [2,'Vì sao cần tiêu dùng thông minh?','Tiết kiệm, tránh lãng phí, bảo vệ quyền lợi và sử dụng tiền hiệu quả','Để tiêu nhiều hơn','Không cần thiết','Để chạy theo mốt'],
  [3,'Nêu các bước để trở thành người tiêu dùng thông minh.','Xác định nhu cầu thật sự; tìm hiểu thông tin, nguồn gốc, chất lượng; so sánh giá; cân nhắc khả năng tài chính; mua và sử dụng hợp lí, giữ hóa đơn.'],
  [3,'Nêu một số quyền cơ bản của người tiêu dùng.','Quyền được an toàn; được thông tin; được lựa chọn; được bảo vệ quyền lợi; được khiếu nại, bồi thường khi mua phải hàng kém chất lượng.'],
  [4,'Theo em, vì sao tiêu dùng thông minh còn góp phần bảo vệ môi trường?','Tiêu dùng thông minh là mua đúng nhu cầu, hạn chế lãng phí, ưu tiên sản phẩm thân thiện môi trường, tái sử dụng; nhờ đó giảm rác thải, tiết kiệm tài nguyên, góp phần bảo vệ môi trường và phát triển bền vững.']
 ]);
 add(M,9,'Bài 9: Vi phạm pháp luật và trách nhiệm pháp lí',[
  [1,'Vi phạm pháp luật là gì?','Hành vi trái pháp luật, có lỗi, do người có năng lực trách nhiệm pháp lí thực hiện','Hành vi đúng pháp luật','Việc tốt','Phong tục tập quán'],
  [1,'Trách nhiệm pháp lí là gì?','Nghĩa vụ mà người vi phạm pháp luật phải gánh chịu','Phần thưởng','Quyền lợi','Việc tùy thích'],
  [2,'Hành vi nào dưới đây là vi phạm pháp luật?','Vượt đèn đỏ, trộm cắp tài sản','Giúp đỡ người khác','Tham gia giao thông đúng luật','Nộp thuế đầy đủ'],
  [2,'Có mấy loại vi phạm pháp luật thường gặp?','Vi phạm hình sự, hành chính, dân sự, kỉ luật','Chỉ một loại','Chỉ hai loại','Không phân loại'],
  [3,'Vì sao công dân phải chịu trách nhiệm pháp lí khi vi phạm pháp luật?','Để bảo đảm pháp luật được tôn trọng, giữ trật tự, công bằng xã hội; răn đe, giáo dục người vi phạm và phòng ngừa vi phạm.'],
  [3,'Là học sinh, em cần làm gì để không vi phạm pháp luật?','Tìm hiểu, tuân thủ pháp luật và nội quy; sống trung thực, có trách nhiệm; tránh xa tệ nạn; rèn ý thức tôn trọng pháp luật.'],
  [4,'Theo em, vì sao nói "sống và làm việc theo Hiến pháp và pháp luật" là trách nhiệm của mỗi công dân?','Pháp luật bảo đảm trật tự, công bằng, quyền lợi của mọi người. Mỗi công dân tuân thủ pháp luật giúp xã hội ổn định, văn minh; nếu vi phạm sẽ bị xử lí và gây hại cho cộng đồng. Vì vậy tuân thủ pháp luật là trách nhiệm chung.']
 ]);
 add(M,9,'Bài 10: Quyền tự do kinh doanh và nghĩa vụ nộp thuế',[
  [1,'Quyền tự do kinh doanh là gì?','Quyền của công dân được lựa chọn hình thức, ngành nghề kinh doanh theo quy định pháp luật','Kinh doanh trái phép','Buôn lậu','Trốn thuế'],
  [1,'Thuế là gì?','Khoản tiền bắt buộc công dân, tổ chức phải nộp vào ngân sách nhà nước','Khoản tiền tự nguyện','Phần thưởng','Tiền phạt tùy ý'],
  [2,'Hành vi nào vi phạm pháp luật về kinh doanh và thuế?','Kinh doanh hàng cấm, trốn thuế','Kê khai, nộp thuế đầy đủ','Kinh doanh đúng ngành đăng kí','Bán hàng có nguồn gốc rõ ràng'],
  [2,'Nộp thuế có ý nghĩa gì?','Góp phần xây dựng đất nước: phát triển kinh tế, y tế, giáo dục, quốc phòng','Làm nghèo đất nước','Không có ý nghĩa','Chỉ có lợi cho người giàu'],
  [3,'Vì sao nộp thuế vừa là quyền lợi vừa là nghĩa vụ của công dân?','Nộp thuế là nghĩa vụ để góp phần xây dựng đất nước; đồng thời công dân được hưởng lợi từ các dịch vụ công (đường sá, trường học, bệnh viện, an ninh...) do ngân sách nhà nước chi trả.'],
  [3,'Là học sinh, em cần có nhận thức như thế nào về quyền tự do kinh doanh và nghĩa vụ nộp thuế?','Hiểu kinh doanh phải đúng pháp luật, trung thực; nộp thuế là nghĩa vụ góp phần xây dựng đất nước; tôn trọng pháp luật, ủng hộ kinh doanh lành mạnh, lên án trốn thuế, buôn lậu.'],
  [4,'Theo em, vì sao hành vi trốn thuế lại gây hại cho đất nước?','Thuế là nguồn thu để Nhà nước phát triển kinh tế, y tế, giáo dục, quốc phòng, an sinh. Trốn thuế làm giảm ngân sách, ảnh hưởng đến các dịch vụ công và sự phát triển chung, gây bất công với người nộp thuế nghiêm túc, nên là hành vi vi phạm pháp luật.']
 ]);
 add(M,9,'Công dân với đạo đức và pháp luật',[
  [1,'Hành vi trái pháp luật, có lỗi, do người có năng lực trách nhiệm thực hiện gọi là gì?','Vi phạm pháp luật','Việc tốt','Phong tục','Quyền công dân'],
  [2,'Phẩm chất nào giúp con người sống nhân ái, hóa giải mâu thuẫn?','Khoan dung','Cố chấp','Ích kỉ','Thù hằn'],
  [2,'Hành vi nào thể hiện sống có đạo đức và tuân theo pháp luật?','Trung thực, khách quan, chấp hành pháp luật','Trốn thuế','Gây gổ','Bao che cái sai'],
  [3,'Nêu mối quan hệ giữa đạo đức và pháp luật.','Đạo đức và pháp luật đều điều chỉnh hành vi con người; người có đạo đức thường tự giác tuân theo pháp luật; pháp luật góp phần bảo vệ, củng cố các giá trị đạo đức.'],
  [4,'Theo em, vì sao công dân cần vừa sống có đạo đức vừa tuân theo pháp luật?','Đạo đức giúp con người sống đúng, tốt đẹp một cách tự giác; pháp luật bảo đảm trật tự, công bằng bằng quy định bắt buộc. Kết hợp cả hai giúp mỗi người sống đúng mực, xã hội ổn định, văn minh; chỉ có đạo đức hoặc chỉ có pháp luật đều chưa đủ.']
 ]);
 add(M,9,'Quản lí bản thân, hướng nghiệp',[
  [1,'Kĩ năng nào giúp em hoàn thành công việc đúng hạn, giảm căng thẳng?','Quản lí thời gian hiệu quả','Trì hoãn','Ôm đồm','Buông xuôi'],
  [2,'Thái độ nào giúp con người vượt qua hoàn cảnh mới?','Thích ứng với thay đổi một cách tích cực','Bảo thủ','Né tránh','Than vãn'],
  [2,'Việc xác định mục tiêu và lí tưởng sống giúp em điều gì?','Có định hướng, động lực phấn đấu cho tương lai','Mất phương hướng','Lãng phí thời gian','Bị động'],
  [3,'Nêu những việc em làm để quản lí bản thân và chuẩn bị cho nghề nghiệp tương lai.','Xác định mục tiêu, sở thích, năng lực; quản lí thời gian; học tập, rèn kĩ năng; tìm hiểu các nghề; rèn đạo đức và thái độ làm việc.'],
  [4,'Theo em, vì sao học sinh cần sớm tìm hiểu về nghề nghiệp và định hướng tương lai?','Giúp hiểu bản thân và các nghề, chọn hướng học tập, rèn luyện phù hợp; chuẩn bị kiến thức, kĩ năng cần thiết; tránh chọn nghề sai, bị động khi trưởng thành; chủ động cho tương lai của mình.']
 ]);
 add(M,9,'Công dân với kinh tế và cộng đồng',[
  [1,'Mua và sử dụng hàng hóa hợp lí, hiệu quả gọi là gì?','Tiêu dùng thông minh','Tiêu xài phung phí','Chạy theo mốt','Lãng phí'],
  [2,'Hoạt động nào thể hiện trách nhiệm với cộng đồng?','Tham gia dọn vệ sinh, giúp đỡ người khó khăn, bảo vệ môi trường','Thờ ơ việc chung','Xả rác','Phá hoại của công'],
  [2,'Nộp thuế của công dân nhằm mục đích gì?','Góp phần xây dựng và phát triển đất nước','Làm giàu cho cá nhân','Không có mục đích','Gây khó khăn cho dân'],
  [3,'Là công dân, em thể hiện trách nhiệm với kinh tế và cộng đồng như thế nào?','Tiêu dùng thông minh, tiết kiệm; ủng hộ hàng hóa hợp pháp; tham gia hoạt động cộng đồng; bảo vệ môi trường; tôn trọng pháp luật kinh doanh và thuế.'],
  [4,'Theo em, vì sao sự phát triển kinh tế cần gắn với trách nhiệm cộng đồng và bảo vệ môi trường?','Phát triển kinh tế nhằm nâng cao đời sống, nhưng nếu chỉ chạy theo lợi nhuận mà bỏ qua cộng đồng, môi trường sẽ gây bất công, ô nhiễm, cạn kiệt tài nguyên. Phát triển bền vững đòi hỏi hài hòa lợi ích kinh tế với trách nhiệm xã hội và bảo vệ môi trường.']
 ]);
 add(M,9,'Trách nhiệm của công dân trẻ',[
  [1,'Lí tưởng sống cao đẹp của công dân trẻ hiện nay là gì?','Phấn đấu vì dân giàu, nước mạnh, dân chủ, công bằng, văn minh','Sống hưởng thụ','Sống ích kỉ','Thờ ơ với đất nước'],
  [2,'Hành vi nào thể hiện trách nhiệm của công dân trẻ với cộng đồng?','Tích cực tham gia hoạt động xã hội, bảo vệ môi trường','Vô cảm','Trốn tránh','Phá hoại'],
  [2,'Công dân trẻ cần làm gì để góp phần bảo vệ Tổ quốc?','Học tập tốt, rèn luyện, chấp hành pháp luật, sẵn sàng tham gia bảo vệ Tổ quốc','Trốn tránh nghĩa vụ','Thờ ơ','Gây rối'],
  [3,'Là một công dân trẻ, em xác định trách nhiệm của mình với bản thân, gia đình và đất nước như thế nào?','Với bản thân: học tập, rèn luyện, sống có lí tưởng. Với gia đình: hiếu thảo, trách nhiệm. Với đất nước: chấp hành pháp luật, tham gia hoạt động cộng đồng, góp phần xây dựng và bảo vệ Tổ quốc.'],
  [4,'Theo em, vì sao thế hệ trẻ được coi là tương lai của đất nước?','Vì thanh niên, học sinh là lực lượng kế tục, sẽ gánh vác công việc xây dựng và bảo vệ Tổ quốc. Thế hệ trẻ có tri thức, sức khỏe, lí tưởng sẽ quyết định sự phát triển của đất nước; vì vậy cần học tập, rèn luyện để xứng đáng với vai trò đó.']
 ]);

 /* -------- LỚP 8 + 9: bù lẻ cho đủ chuẩn -------- */
 add(M,8,'Đạo đức và lối sống',[
  [3,'Nêu một tấm gương (người thật hoặc nhân vật) về đạo đức, lối sống đẹp mà em biết và điều em học được.','HS nêu tấm gương cụ thể và bài học (cần cù, trung thực, nhân ái, vượt khó...).']
 ]);
 add(M,8,'Pháp luật, kinh tế',[
  [1,'Khoản tiền bắt buộc nộp vào ngân sách nhà nước gọi là gì?','Thuế','Tiền thưởng','Tiền phạt tùy ý','Quà tặng'],
  [3,'Vì sao công dân cần tuân thủ pháp luật trong lao động và kinh doanh?','Để bảo đảm quyền lợi của mình và người khác, cạnh tranh lành mạnh, giữ trật tự kinh tế, góp phần phát triển đất nước bền vững.']
 ]);
 add(M,8,'Trách nhiệm và kĩ năng công dân',[
  [3,'Nêu các số điện thoại khẩn cấp và trường hợp sử dụng.','111 – bảo vệ trẻ em; 113 – công an; 114 – cứu hỏa, cứu nạn; 115 – cấp cứu y tế.']
 ]);
 add(M,8,'Quyền và bổn phận',[
  [1,'Lao động đối với công dân vừa là quyền vừa là gì?','Nghĩa vụ','Việc cấm','Sở thích','Việc tùy ý'],
  [3,'Là học sinh, em thực hiện quyền và bổn phận của mình như thế nào?','Học tập tốt, rèn đạo đức; chấp hành pháp luật, nội quy; bảo vệ môi trường; giúp đỡ gia đình; tham gia hoạt động phù hợp.']
 ]);
 add(M,8,'Bài 2: Tôn trọng sự đa dạng của các dân tộc',[
  [1,'Hành vi nào trái với tôn trọng sự đa dạng của các dân tộc?','Kì thị, phân biệt chủng tộc','Giao lưu văn hóa','Học hỏi lẫn nhau','Hợp tác hữu nghị']
 ]);
 add(M,8,'Bài 4: Bảo vệ lẽ phải',[
  [1,'Người biết bảo vệ lẽ phải có đức tính nào?','Dũng cảm, trung thực, công bằng','Hèn nhát','Xu nịnh','A dua']
 ]);
 add(M,8,'Bài 8: Lập kế hoạch chi tiêu',[
  [1,'Nhu cầu nào dưới đây là nhu cầu thiết yếu cần ưu tiên chi tiêu?','Đồ dùng học tập, ăn uống','Đồ chơi đắt tiền','Hàng hiệu theo mốt','Quà vặt']
 ]);
 add(M,9,'Công dân với đạo đức và pháp luật',[
  [3,'Nêu một hành vi vi phạm pháp luật thường gặp và hậu quả của nó.','VD: vượt đèn đỏ → gây tai nạn, bị xử phạt; trộm cắp → bị xử lí hình sự, mất uy tín. Vi phạm pháp luật gây hại cho mình và xã hội, phải chịu trách nhiệm pháp lí.']
 ]);
 add(M,9,'Quản lí bản thân, hướng nghiệp',[
  [1,'Việc sắp xếp, sử dụng thời gian hợp lí để đạt mục tiêu gọi là gì?','Quản lí thời gian hiệu quả','Lãng phí thời gian','Trì hoãn','Làm việc tùy hứng'],
  [3,'Theo em, để chọn nghề phù hợp, cần căn cứ vào những yếu tố nào?','Sở thích, năng lực bản thân; nhu cầu xã hội và thị trường lao động; điều kiện gia đình; giá trị và ý nghĩa của nghề.']
 ]);
 add(M,9,'Công dân với kinh tế và cộng đồng',[
  [3,'Nêu một việc làm thể hiện trách nhiệm của em với cộng đồng nơi mình sinh sống.','VD: tham gia dọn vệ sinh khu phố, giúp đỡ người khó khăn, giữ gìn môi trường, tuyên truyền nếp sống văn minh.']
 ]);
 add(M,9,'Trách nhiệm của công dân trẻ',[
  [1,'Phẩm chất nào thể hiện công dân trẻ sống có trách nhiệm?','Tích cực, tự giác, cống hiến cho cộng đồng','Thờ ơ','Ích kỉ','Vô cảm'],
  [3,'Nêu những việc làm thể hiện trách nhiệm của công dân trẻ trong thời đại hội nhập.','Học tập, trau dồi tri thức và ngoại ngữ; giữ gìn bản sắc dân tộc; tiếp thu tinh hoa văn hóa; sống có lí tưởng; tham gia xây dựng và bảo vệ Tổ quốc.']
 ]);
 add(M,9,'Bài 2: Khoan dung',[
  [1,'Câu tục ngữ nào thể hiện lòng khoan dung?','Đánh kẻ chạy đi, không ai đánh người chạy lại','Ăn miếng trả miếng','Gậy ông đập lưng ông','Có vay có trả']
 ]);
 add(M,9,'Bài 8: Tiêu dùng thông minh',[
  [1,'Trước khi mua hàng, người tiêu dùng thông minh ưu tiên điều gì?','Xác định nhu cầu thật sự và khả năng tài chính','Mua theo quảng cáo','Mua vì bạn có','Mua cho bằng bạn']
 ]);

})();
