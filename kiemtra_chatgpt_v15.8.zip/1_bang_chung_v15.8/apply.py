import json,re,subprocess,sys
P='/home/claude/tro-ly-giao-vien/index.html'
src=open(P,encoding='utf-8').read()
H=json.load(open('/tmp/claude-0/v8/hts_all.json'));RB=json.load(open('/tmp/claude-0/v8/rebuild.json'))
def span(text,start):  # start at '[' ; return end index (exclusive) of matching ]
  d=0;i=start;q=None
  while i<len(text):
    c=text[i]
    if q:
      if c=='\\': i+=2; continue
      if c==q: q=None
    elif c in '"\'': q=c
    elif c=='[': d+=1
    elif c==']':
      d-=1
      if d==0: return i+1
    i+=1
  raise Exception('unbalanced')
def jsparse(lit): return json.loads(subprocess.run(['node','-e','const fs=require("fs");console.log(JSON.stringify(eval("("+fs.readFileSync(0,"utf8")+")")))'],input=lit,capture_output=True,text=True,check=True).stdout)
def mspan(key):
  m=re.search(r"MUCLUC\['"+re.escape(key)+r"'\]=",src); 
  if not m: return None
  s=src.index('[',m.end()-1); return s,span(src,s)
def bspan(key):
  m=re.search(r'^\s*"'+re.escape(key)+r'":\s*\[',src,re.M)
  if not m: return None
  s=m.end()-1; return s,span(src,s)
log=[]
def setM(key,data):
  global src; s,e=mspan(key); src=src[:s]+json.dumps(data,ensure_ascii=False)+src[e:]
def getM(key): s,e=mspan(key); return jsparse(src[s:e])
def SUB(key,old,new,n=1):
  global src; hit=0
  for f in (mspan,bspan):
    sp=f(key)
    if not sp: continue
    s,e=sp; seg=src[s:e]; c=seg.count(old)
    if c: hit+=c; src=src[:s]+seg.replace(old,new)+src[e:]
  if hit<n: log.append(f'!! MISS {key}: {old}')
  else: log.append(f'ok {key}: {old} -> {new} ({hit})')
# 1. rebuilt keys
for k,v in RB.items():
  lop,mon=k.split('|')
  if mspan(k): setM(k,v); log.append(f'rebuild {k}: {sum(len(x[1]) for x in v)} mục')
  else: log.append('!! no key '+k)
# 2. targeted fixes
F=[('1|Đạo đức','Gia đình của em','Gia đình em'),('2|Đạo đức','Thể hiện cảm xúc bản thân','Thể hiện cảm xúc cá nhân'),
('1|Hoạt động trải nghiệm','Yêu thương con người','Yêu thương mọi người'),('1|Hoạt động trải nghiệm','Ăn uống hợp li','Ăn uống hợp lí'),('1|Hoạt động trải nghiệm','Tham gia hoạt động cộng đồng','Xây dựng cộng đồng'),
('2|Hoạt động trải nghiệm','giữ tình bạn','giữ gìn tình bạn'),('2|Hoạt động trải nghiệm','Việc làm của mình không cần ai nhắc','Việc của mình không cần ai nhắc'),('2|Hoạt động trải nghiệm','Trường học hanh phúc','Trường học hạnh phúc'),
('4|Lịch sử và Địa lí','Đền Hùng và Giỗ Tổ Hùng Vương','Đền Hùng và lễ giỗ Tổ Hùng Vương'),('4|Khoa học','chất dinh dưỡng với cơ thể','chất dinh dưỡng đối với cơ thể'),
('4|Công nghệ','mô hình robot','mô hình rô-bốt'),('4|Tin học','Tạo chương trình máy tính điều khiển nhân vật theo ý tưởng','Tạo chương trình máy tính để diễn tả ý tưởng'),
('4|Tiếng Việt','Người thấy đầu tiên','Người thầy đầu tiên'),
('1|Mĩ thuật','Em là học sinh lớp 1','Em là học sinh lớp Một'),('4|Mĩ thuật','Một số dạng dân gian trong tranh dân gian Việt Nam','Một số dạng không gian trong tranh dân gian Việt Nam'),('4|Mĩ thuật','Môi trường yêu dấu','Mái trường yêu dấu'),
('7|Toán','Quan hệ giữa các yếu tố trong tam giác','Quan hệ giữa các yếu tố trong một tam giác'),('8|Toán','Phân tích dữ liệu thống kê dựa vào biểu đồ','Phân tích số liệu thống kê dựa vào biểu đồ'),
('6|Lịch sử và Địa lí','Bài 9: Trung Quốc cổ đại','Bài 9: Trung Quốc từ thời cổ đại đến thế kỉ VII'),('6|Lịch sử và Địa lí','phương hướng ngoài thực địa','phương hướng ngoài thực tế'),
('6|Giáo dục công dân','cở bản','cơ bản'),('6|Công nghệ','An toàn và tiết kiệm trong gia đình','An toàn và tiết kiệm điện trong gia đình'),('7|Công nghệ','trọng gia đình','trong gia đình'),
('7|Lịch sử và Địa lí','Trung Quốc từ thế kỉ III TCN đến giữa thế kỉ XIX','Trung Quốc từ thế kỉ VII đến giữa thế kỉ XIX'),('7|Lịch sử và Địa lí','phương thức con người khai thác tự nhiên bền vững ở Bắc Mỹ','phương thức khai thác tự nhiên bền vững ở Bắc Mỹ'),
('7|Khoa học tự nhiên','Vai trò của nước và các chất dinh dưỡng đối với cơ thể sinh vật','Vai trò của nước và chất dinh dưỡng đối với sinh vật'),('7|Khoa học tự nhiên','Thực hành: Thân vận chuyển nước','Thực hành: Chứng minh thân vận chuyển nước'),
('7|Khoa học tự nhiên','Thực hành: quan sát, mô tả sự sinh trưởng và phát triển ở một số loài sinh vật','Thực hành: Quan sát, mô tả sự sinh trưởng và phát triển ở một số sinh vật'),('7|Khoa học tự nhiên','Thực hành: Hô hấp tế bào ở thực vật','Thực hành: Hô hấp ở thực vật'),
('8|Khoa học tự nhiên','Năng lượng nhiệt và nhiệt năng','Năng lượng nhiệt và nội năng'),
('8|Lịch sử và Địa lí','từ nửa sau thế kỉ XVI đến thế kỉ XVII"','từ nửa sau thế kỉ XVI đến thế kỉ XVIII"'),('8|Lịch sử và Địa lí','Thực hành: Đọc biểu đồ khí hậu','Thực hành: Vẽ và phân tích biểu đồ khí hậu'),
('8|Lịch sử và Địa lí','Môi trường và tài nguyên thiên nhiên biển đảo','Môi trường và tài nguyên biển đảo'),('8|Lịch sử và Địa lí','Phạm vi biển đông','Phạm vi Biển Đông'),
('8|Lịch sử và Địa lí','văn học,nghệ thuật','văn học, nghệ thuật'),('8|Toán','với xác suất ứng dụng','với xác suất và ứng dụng'),
]
for k,o,n in F: SUB(k,o,n)
# 3. structural
def edit(key,fn):
  d=getM(key); fn(d); setM(key,d); log.append('struct '+key)
def tin4(d):
  for s in d:
    s[1]=sum([['Bài 12A. Thực hành sử dụng công cụ đa phương tiện','Bài 12B. Phần mềm luyện gõ bàn phím'] if x.startswith('Bài 12.') else [x] for x in s[1]],[])
edit('4|Tin học',tin4)
def lsdl8(d):
  for s in d:
    if s[0].startswith('Lịch sử · Chương 4'):
      s[1]=[x for x in s[1] if not x.startswith('Bài 13')]
      i=[j for j,x in enumerate(s[1]) if x.startswith('Bài 10')][0]
      s[1].insert(i+1,'Bài 11: Phong trào công nhân từ cuối thế kỉ XVIII đến đầu thế kỉ XX và sự ra đời của chủ nghĩa xã hội khoa học')
    if s[0].startswith('Địa lí · Chương 2'):
      i=[j for j,x in enumerate(s[1]) if x.startswith('Bài 6')][0]
      if not any(x.startswith('Bài 7') for x in s[1]): s[1].insert(i+1,'Bài 7: Vai trò của tài nguyên khí hậu và tài nguyên nước đối với sự phát triển kinh tế - xã hội của nước ta')
  d.append(['Chủ đề chung',['Chủ đề chung 1: Văn minh châu thổ sông Hồng và sông Cửu Long','Chủ đề chung 2: Bảo vệ chủ quyền, các quyền và lợi ích hợp pháp của Việt Nam ở Biển Đông']])
edit('8|Lịch sử và Địa lí',lsdl8)
def lsdl7(d):
  if not any(s[0]=='Chủ đề chung' for s in d): d.append(['Chủ đề chung',['Chủ đề chung 1: Các cuộc đại phát kiến địa lí','Chủ đề chung 2: Đô thị: Lịch sử và hiện tại']])
edit('7|Lịch sử và Địa lí',lsdl7)
def tin8(d):
  i=[j for j,s in enumerate(d) if s[0].startswith('Chủ đề 4')][0]
  d[i+1:i+1]=[['Chủ đề 4 (lựa chọn a): Soạn thảo văn bản và trình chiếu nâng cao',['Bài 8a: Làm việc với danh sách dạng liệt kê và hình ảnh trong văn bản','Bài 9a: Tạo đầu trang, chân trang cho văn bản','Bài 10a: Định dạng nâng cao cho trang chiếu','Bài 11a: Sử dụng bản mẫu tạo bài trình chiếu']],
   ['Chủ đề 4 (lựa chọn b): Làm quen với phần mềm chỉnh sửa ảnh',['Bài 8b: Phần mềm chỉnh sửa ảnh','Bài 9b: Thay đổi khung hình, kích thước ảnh','Bài 10b: Thêm văn bản, tạo hiệu ứng cho ảnh','Bài 11b: Thực hành tổng hợp']]]
edit('8|Tin học',tin8)
def toanHD(lop):
  def fn(d):
    if any('trải nghiệm' in s[0].lower() for s in d): return
    for tap,hk in (('Tập một','I'),('Tập hai','II')):
      b=[b for b in H if b['lop']==lop and b['ten'].startswith(f'Toán {lop} - {tap}')][0]; on=False; it=[]
      for l in b['lines']:
        dd=(len(l)-len(l.lstrip()))//2; t=l.strip()
        if dd==0: on=t.upper().startswith('HOẠT ĐỘNG THỰC HÀNH'); 
        elif on and not re.search(r'(?i)bảng tra|thuật ngữ',t): it.append(t.replace('chi tiêu các nhân','chi tiêu cá nhân').replace('BÀI TẬP ÔN TẬP CUỐI NĂM','Bài tập ôn tập cuối năm'))
      if it: d.append([f'Hoạt động thực hành trải nghiệm (Học kì {hk})',it])
  return fn
for l in (6,7,8): edit(f'{l}|Toán',toanHD(l))

def ins_after(d,pref,new):
  for sec in d:
    for j,x in enumerate(sec[1]):
      if x.startswith(pref) and not any(y.startswith(new.split(':')[0]+':') for y in sec[1]):
        sec[1].insert(j+1,new); return
def lsdl6(d):
  for sec in d:
    if sec[0].startswith('Lịch sử · Chương 4'): ins_after([sec],'Bài 11:','Bài 12: Sự hình thành và bước đầu phát triển của các vương quốc phong kiến ở Đông Nam Á (từ thế kỉ VII đến thế kỉ X)')
    if sec[0].startswith('Lịch sử · Chương 5'): ins_after([sec],'Bài 14:','Bài 15: Chính sách cai trị của các triều đại phong kiến phương Bắc và sự chuyển biến của xã hội Âu Lạc')
    if sec[0].startswith('Địa lí · Chương 7'): ins_after([sec],'Bài 28:','Bài 29: Bảo vệ tự nhiên và khai thác thông minh các tài nguyên thiên nhiên vì sự phát triển bền vững')
edit('6|Lịch sử và Địa lí',lsdl6)
def cnOn(d):
  import re as _r
  rm=['I','II','III','IV','V','VI']
  for sec in d:
    m=_r.match(r'Chương (\d+)',sec[0])
    if m and not any(x.startswith('Ôn tập') for x in sec[1]): sec[1].append('Ôn tập Chương '+rm[int(m.group(1))-1])
for l in (6,7,8): edit(f'{l}|Công nghệ',cnOn)
def toanCN(d):
  for sec in d:
    if sec[0]=='Hoạt động thực hành trải nghiệm (Học kì II)' and not any('ôn tập cuối năm' in x.lower() for x in sec[1]): sec[1].append('Bài tập ôn tập cuối năm')
for l in (7,8): edit(f'{l}|Toán',toanCN)
open(P,'w',encoding='utf-8').write(src)
print('\n'.join(log))
