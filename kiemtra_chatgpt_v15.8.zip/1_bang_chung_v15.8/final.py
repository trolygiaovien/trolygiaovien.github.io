import json,re,unicodedata,math
V='/tmp/claude-0/v8/'
O=json.load(open(V+'ct_yccd.json'));X=json.load(open(V+'xm.json'));A=json.load(open(V+'app_new.json'))
N=lambda s:unicodedata.normalize('NFC',s)
# ---------- 1. làm sạch + trạng thái xác minh từng YCCĐ ----------
VERB=re.compile(r'(được|biết|thực hiện|tham gia|hát|đọc|viết|kể|vẽ|tạo|sử dụng|thể hiện|nêu|trình bày|mô tả|giải thích|phân tích|so sánh|xác định|tìm|vận dụng|cảm nhận|nhận biết|chia sẻ|hợp tác|lựa chọn|làm|bước đầu|có ý thức|tự)',re.I)
def nhom(s):
  g=[]
  if not re.search(r'[.;:!?”)]$',s.strip()) or s[0].islower(): g.append('cat')      # bị cắt/thiếu đầu-cuối
  if re.search(r'\.\s+[a-zà-ỹđ]',s) or re.search(r'(Lớp \d+ Lớp \d+|PHƯƠNG PHÁP|ĐÁNH GIÁ KẾT QUẢ|Mạch nội dung)',s): g.append('dinh')  # dính cột/đoạn khác
  if len(s)>380 or s.count(' + ')>=4: g.append('gop')     # gộp nhiều ý / cấu trúc bất thường
  return g
C={};TK={'xm':0,'sua':0,'chua':0,'bo':0}
for mon in O:
  C[mon]={}
  for l,Y in O[mon].items():
    T=[]
    for i,(m,s) in enumerate(Y['T']):
      r=X[mon][l][i]; tt=r['tt']; txt=r.get('moi',s)
      if len(txt)<60 and not VERB.search(txt): TK['bo']+=1; continue        # tiêu đề/mẩu rác, không phải YCCĐ
      if tt=='chua' and re.search(r'(Lớp \d+ Lớp \d+|PHƯƠNG PHÁP|ĐÁNH GIÁ KẾT QUẢ|Mạch nội dung|bảng tổng hợp dưới đây)',txt): TK['bo']+=1; continue
      g=[] if tt in('xm','sua') else nhom(txt)
      T.append([m,txt,tt,r['p'],g]); TK[tt]+=1
    C[mon][l]=T
print('trạng thái YCCĐ:',TK)
# ---------- 2. địa danh / triều đại ----------
G=[ # (mã, mẫu regex, cha)
('vn',r'việt nam|nước ta',None),('tdmnbb',r'trung du và miền núi bắc bộ',  'vn'),('dbbb',r'đồng bằng bắc bộ|đồng bằng sông hồng','vn'),
('dhmt',r'duyên hải miền trung|ven biển miền trung|bắc trung bộ|nam trung bộ','vn'),('tn',r'tây nguyên','vn'),('nb',r'nam bộ','vn'),
('dbscl',r'đồng bằng sông cửu long','nb'),('dnb',r'đông nam bộ','nb'),('tl',r'thăng long|hà nội','dbbb'),('hue',r'cố đô huế|\bhuế\b','dhmt'),
('dp',r'địa phương em|địa phương nơi em|quê hương em',None),
('chaua',r'châu á',None),('dna',r'đông nam á','chaua'),('tq',r'trung quốc','chaua'),('ad',r'ấn độ','chaua'),('nhat',r'nhật bản','chaua'),
('lao',r'\blào\b','dna'),('cpc',r'cam-pu-chia|campuchia','dna'),('champa',r'chăm-pa|champa','dna'),('phunam',r'phù nam','dna'),
('chauau',r'châu âu|liên minh châu âu',None),('tayau',r'tây âu','chauau'),('hyl',r'hy lạp|la mã','chauau'),('anh',r'tư sản anh|nước anh|thuộc địa anh','chauau'),
('phap',r'tư sản pháp|nước pháp|thực dân pháp|chống pháp','chauau'),('nga',r'\bnga\b','chauau'),
('chauphi',r'châu phi',None),('namphi',r'nam phi','chauphi'),('aicap',r'ai cập','chauphi'),('luongha',r'lưỡng hà',None),
('chaumy',r'châu mỹ',None),('bacmy',r'bắc mỹ','chaumy'),('tnmy',r'trung và nam mỹ|trung nam mỹ|mỹ la-tinh|mĩ la-tinh','chaumy'),('amazon',r'a-ma-dôn|amazon','tnmy'),
('ddd',r'châu đại dương',None),('uc',r'ô-xtrây-li-a|australia','ddd'),('namcuc',r'nam cực',None),
('tong',r'\btống\b',None),('nguyen',r'mông – nguyên|mông - nguyên|mông cổ',None),('minh',r'nhà minh|quân minh|thời minh|minh – thanh|minh - thanh',None),
('ly',r'nhà lý|thời lý',None),('tran',r'nhà trần|thời trần',None),('ho',r'nhà hồ|thời hồ|đại ngu',None),('leso',r'lê sơ',None),
('ngodinh',r'ngô – đinh|ngô - đinh|tiền lê|thời ngô|thời đinh',None),('tayson',r'tây sơn',None),('triennguyen',r'thời nguyễn|nhà nguyễn|triều nguyễn',None)]
PAR={c:p for c,_,p in G};RX=[(c,re.compile(r,re.I)) for c,r,_ in G]
def places(s):
  s=N(s).lower(); f={c for c,r in RX if r.search(s)}
  if {'dbscl','dnb'}&f: f.discard('nb')
  if f-{'vn'}: f.discard('vn')
  return f
def anc(c):
  out={c}
  while PAR.get(c): c=PAR[c]; out.add(c)
  return out
def hop(a,b):  # tương thích nếu bằng nhau hoặc quan hệ chứa nhau
  return any(x in anc(y) or y in anc(x) for x in a for y in b)
# ---------- 3. gán gợi ý ----------
STOP=set('và của các một số trong với cho là được những về có không theo từ đến bài chủ đề chương phần em thực hành tiếp ôn tập luyện tập hoạt động nội dung bài học'.split())
def toks(s):
  s=N(s).lower(); s=re.sub(r'^(bài|chủ đề|chương|phần|tuần|nội dung)\s*[0-9ivxlc]*[ab]?\s*[:.\-–]?\s*','',s)
  w=re.findall(r'[0-9a-zà-ỹđ]+',s)
  bi={w[i]+' '+w[i+1] for i in range(len(w)-1) if not (w[i] in STOP and w[i+1] in STOP)}
  bi={x for x in bi if not re.match(r'^(thế kỉ|nửa sau|nửa đầu|(đầu|cuối|giữa|sau|kỉ) (thế|[ivxlc]+)|kỉ [ivxlc]+|[ivxlc]+ (đến|giữa|đầu|cuối)|đến (đầu|giữa|cuối|thế|năm)|việt nam|đơn giản|thực tế|cuộc sống|hằng ngày)$',x)}
  return bi,{x for x in w if x not in STOP and len(x)>2}
laOn=re.compile(r'(?i)ôn tập|luyện tập chung|đánh giá|củng cố|bài tập cuối')
OUT={};ROWS=[];CHAN=[]
for mon in C:
  OUT[mon]={}
  for l,T in C[mon].items():
    key=mon+'|'+l; B=A.get(key,[])
    TT=[toks(x[1]) for x in T]; df={}
    for yb,_ in TT:
      for x in yb: df[x]=df.get(x,0)+1
    NT=len(TT); M={}; ST={}
    for sec,items in B:
      sb,_=toks(sec)
      for t in items:
        if laOn.search(t) or re.match(r'(?i)thực hành tiếng việt',t): continue
        tt0=re.sub(r'\s*\(sau văn bản.*$','',t); b,u=toks(tt0); pt=places(tt0)
        sc=[]
        for i,(yb,yu) in enumerate(TT):
          if T[i][2]=='chua': continue                  # YCCĐ chưa xác minh với PDF: không dùng để gợi ý
          cm=b&yb; nb=len(cm)
          if not cm: continue
          s=sum(math.log(1+NT/df[x]) for x in cm)+0.2*len(u&yu)+0.3*len(sb&yb)
          if (nb>=2 or (nb>=1 and len(b)<=2 and len(u&yu)>=2)) and min(df[x] for x in cm)<=3:
            py=places(T[i][1])
            if pt and py and not hop(pt,py): CHAN.append([mon,l,t,T[i][1],round(s,2)]); continue   # mâu thuẫn địa lí → chặn
            sc.append((s,i,bool(pt and not py)))
        sc.sort(reverse=True)
        if sc:
          pick=[x for x in sc[:4] if x[0]>=sc[0][0]*0.6]
          M[t]=[i for _,i,_ in pick]
          ck=(mon=='Lịch sử và Địa lí') or sc[0][0]<9 or any(z for *_,z in pick)
          ST[t]='cankt' if ck else 'goiy'
          ROWS.append([mon,l,sec,t,round(sc[0][0],2),'CẦN KIỂM TRA' if ck else 'gợi ý',' || '.join(f'#{i} (tr.{T[i][3]}) {T[i][1]}' for i in M[t])])
    OUT[mon][l]={'T':[[x[0],x[1],x[2],x[3]] for x in T],'M':M,'S':ST}
json.dump(OUT,open(V+'ct_yccd_final.json','w'),ensure_ascii=False,separators=(',',':'))
json.dump({'rows':ROWS,'chan':CHAN,'C':{m:{l:T for l,T in v.items()} for m,v in C.items()}},open(V+'final_meta.json','w'),ensure_ascii=False)
print('bài có gợi ý:',len(ROWS),' cần kiểm tra:',sum(r[5]=='CẦN KIỂM TRA' for r in ROWS),' cặp bị chặn vì mâu thuẫn địa lí:',len(CHAN))
