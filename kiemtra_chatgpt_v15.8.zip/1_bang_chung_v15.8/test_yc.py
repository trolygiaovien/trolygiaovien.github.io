import json,re,sys
F=json.load(open('/tmp/claude-0/v8/ct_yccd_final.json'))
def get(mon,l,pref):
  Y=F[mon][l]; ks=[k for k in Y['M'] if k.startswith(pref)]
  return [(k,[Y['T'][i][1] for i in Y['M'][k]],Y['S'][k]) for k in ks]
ok=0;bad=0
def chk(name,cond):
  global ok,bad
  print(('ĐẠT ' if cond else 'TRƯỢT ')+name); ok+=cond; bad+=(not cond)
# 5 lỗi cũ (phải hết)
r=get('Lịch sử và Địa lí','4','Bài 15.'); chk('LSĐL4 Bài 15 Duyên hải không nhận YCCĐ đồng bằng Bắc Bộ',not any('đồng bằng Bắc Bộ' in y for _,ys,_ in r for y in ys))
r=get('Lịch sử và Địa lí','4','Bài 25.'); chk('LSĐL4 Bài 25 Nam Bộ không nhận YCCĐ Tây Nguyên/ĐB Bắc Bộ',not any(('Tây Nguyên' in y or 'Bắc Bộ' in y) for _,ys,_ in r for y in ys))
r=get('Lịch sử và Địa lí','4','Bài 2.'); chk('LSĐL4 Bài 2 địa phương em không nhận YCCĐ trung du miền núi Bắc Bộ',not any('trung du' in y for _,ys,_ in r for y in ys))
r=get('Lịch sử và Địa lí','7','Bài 3:'); chk('LSĐL7 Bài 3 (Châu Âu) không nhận YCCĐ Australia/Amazon',not any(('Australia' in y or 'Amazon' in y) for k,ys,_ in r if 'Âu' in k for y in ys))
r=get('Lịch sử và Địa lí','7','Bài 11:'); chk('LSĐL7 Bài 11 (châu Phi) không nhận YCCĐ Australia',not any('Australia' in y for k,ys,_ in r if 'Phi' in k for y in ys))
r=get('Lịch sử và Địa lí','7','Bài 12:'); chk('LSĐL7 Bài 12 (Tống) không nhận YCCĐ nhà Minh/Mông–Nguyên',not any(re.search('Minh|Mông',y) for k,ys,_ in r if 'Tống' in k for y in ys))
# mẫu đúng phải giữ
def has(mon,l,pref,sub):
  return any(sub in y for _,ys,_ in get(mon,l,pref) for y in ys)
chk('KHTN6 Bài 26 khoá lưỡng phân giữ',has('Khoa học tự nhiên','6','Bài 26:','khoá lưỡng phân'))
chk('KHTN9 Bài 21 phi kim–kim loại giữ',has('Khoa học tự nhiên','9','Bài 21:','phi kim và kim loại'))
chk('LSĐL6 Bài 15 chính sách cai trị giữ',has('Lịch sử và Địa lí','6','Bài 15:','chính sách cai trị'))
chk('LSĐL8 Bài 11 Karl Marx giữ',has('Lịch sử và Địa lí','8','Bài 11:','Karl Marx'))
chk('NV9 thơ tám chữ giữ',has('Ngữ văn','9','Viết đoạn văn ghi lại cảm nghĩ về một bài thơ tám chữ','tám chữ'))
# mọi gợi ý LS&ĐL đều 'cankt'
chk('Mọi gợi ý LS&ĐL là CẦN KIỂM TRA',all(st=='cankt' for l in F['Lịch sử và Địa lí'] for st in F['Lịch sử và Địa lí'][l]['S'].values()))
# không YCCĐ 'chua' nào nằm trong gợi ý
chk('Không gợi ý YCCĐ chưa xác minh',all(F[m][l]['T'][i][2]!='chua' for m in F for l in F[m] for k in F[m][l]['M'] for i in F[m][l]['M'][k]))
print(f'{ok}/{ok+bad} ĐẠT'); sys.exit(bad>0)
