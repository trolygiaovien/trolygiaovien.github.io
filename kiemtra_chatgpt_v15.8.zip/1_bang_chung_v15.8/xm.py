import json,re,unicodedata
D=json.load(open('/tmp/claude-0/v8/pg/pages.json'));SEC=D['SEC'];P={int(k):v for k,v in D['P'].items()}
O=json.load(open('/tmp/claude-0/v8/ct_yccd.json'))
N=lambda s:unicodedata.normalize('NFC',s)
def key(s): s=N(s).lower(); s=re.sub(r'[^0-9a-zà-ỹđ]+',' ',s); return ' '.join(s.split())
BUL={}
for mon,(a,b) in SEC.items():
  bl=[];cur=None
  for p in range(a,b+1):
    for ln in N(P[p]).split('\n'):
      t=ln.strip()
      if not t or re.fullmatch(r'\d+',t): continue
      m=re.match(r'^[–−\-•]\s*(.*)',t)
      if m:
        if cur: bl.append(cur)
        cur=[m.group(1),p]; continue
      if cur:
        if cur[0].rstrip().endswith(('.',';','!','?')) and (len(t.split())<=3 or t.isupper() or re.match(r'^[A-ZĐÀ-Ỹ]',t)):
          bl.append(cur);cur=None;continue   # hết gạch đầu dòng; dòng ngắn lẻ = chữ tràn cột
        cur[0]+=' '+t
  if cur: bl.append(cur)
  BUL[mon]=[(re.sub(r'\s+',' ',x).strip(),p,key(x)) for x,p in bl]
RT=json.load(open('/tmp/claude-0/v8/pg/right.json'))
RFULL={}
for mon,(a,b) in SEC.items():
  txt='';offs=[]
  for p in range(a,b+1):
    offs.append((len(txt),p));txt+=' '+key(RT[str(p)])
  RFULL[mon]=(txt,offs)
FULL={}
for mon,(a,b) in SEC.items():
  txt='';offs=[]
  for p in range(a,b+1):
    offs.append((len(txt),p));txt+=' '+key(P[p])
  FULL[mon]=(txt,offs)
st={};REP={}
for mon in O:
  if mon not in BUL: continue
  B=BUL[mon]
  for l in O[mon]:
    T=O[mon][l]['T'];R=[]
    for i,(m,s) in enumerate(T):
      k=key(s);hit=[b for b in B if b[2]==k]
      if not hit and len(k.split())>=5 and re.search(r'[.;:!?”)]$',s.strip()) and not s[0].islower() and (' '+k+' ') in (RFULL[mon][0]+' '):
        pos=RFULL[mon][0].index(k);pg=max(p for o,p in RFULL[mon][1] if o<=pos);R.append({'tt':'xm','p':pg});continue
      if hit: R.append({'tt':'xm','p':hit[0][1]});continue
      w=k.split()
      # (a) s là một câu trọn vẹn nằm ở ranh giới câu trong một gạch đầu dòng
      if re.search(r'[.;!?]$',s.strip()) and len(w)>=4:
        sb=[b for b in B if re.search(r'(^|[.;!?:] )'+re.escape(key(s)),b[2]) or (' '+k+' ') in (' '+b[2]+' ') and N(s).strip() in b[0]]
        if sb: R.append({'tt':'xm','p':sb[0][1]});continue
      # (b) sửa đuôi bị cắt: s là đầu của gạch đầu dòng, phần thiếu ngắn
      c=[b for b in B if len(w)>=5 and b[2].startswith(k) and 0<len(b[2].split())-len(w)<=8 and re.search(r'[.;:!?”)]$',b[0])]
      if c: R.append({'tt':'sua','p':c[0][1],'moi':c[0][0]});continue
      # (c) chỉ khác kí hiệu/chỉ số (công thức hoá học…)
      kk=re.sub(r'[0-9 ]','',k)
      c=[b for b in B if len(w)>=5 and re.sub(r'[0-9 ]','',b[2])==kk]
      if c: R.append({'tt':'sua','p':c[0][1],'moi':c[0][0]});continue
      clean=bool(re.match(r'^[A-ZĐÀ-Ỹ“"(]',s)) and bool(re.search(r'[.;!?”)]$',s.strip())) and len(s)<380 and not re.search(r'\.\s+[a-zà-ỹđ]',s)
      if clean and len(w)>=4:
        hb=[b for b in B if k in b[2]]
        if hb: R.append({'tt':'xm','p':hb[0][1]});continue
        if k in FULL[mon][0]:
          pos=FULL[mon][0].index(k);pg=max(p for o,p in FULL[mon][1] if o<=pos);R.append({'tt':'xm','p':pg});continue
      R.append({'tt':'chua','p':None})
    REP.setdefault(mon,{})[l]=R
    for r in R: st[r['tt']]=st.get(r['tt'],0)+1
json.dump(REP,open('/tmp/claude-0/v8/xm.json','w'),ensure_ascii=False)
print(st)
import random;random.seed(2)
sua=[(mon,l,i,O[mon][l]['T'][i][1],r['moi']) for mon in REP for l in REP[mon] for i,r in enumerate(REP[mon][l]) if r['tt']=='sua']
for x in random.sample(sua,8): print('---',x[0],x[1],'\n OLD',x[3][:200],'\n NEW',x[4][:200])
chua=[(mon,l,O[mon][l]['T'][i][1]) for mon in REP for l in REP[mon] for i,r in enumerate(REP[mon][l]) if r['tt']=='chua']
for x in random.sample(chua,8): print('CHUA',x[0],x[1],x[2][:160])
