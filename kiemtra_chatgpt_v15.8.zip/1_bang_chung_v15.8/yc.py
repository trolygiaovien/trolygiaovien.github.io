import json,re,unicodedata
D=json.load(open('/tmp/claude-0/v8/yccd_all.json'))
def clean(lst):
  out=[];mach=''
  for s in lst:
    s=unicodedata.normalize('NFC',s).strip()
    if not s: continue
    if re.fullmatch(r'[A-ZĐÀ-Ỹ0-9 ,–\-:()]+(?: [A-ZĐÀ-Ỹa-zà-ỹđ ]+)?',s) and s.split()[0].isupper() and len(s.split()[0])>1:
      mach=s; continue        # tiêu đề mạch/chủ đề viết hoa
    first=s[0]
    if out and (first.islower() or first in ',;)') and not re.match(r'^(nêu|trình bày|nhận biết|thực hiện|vận dụng|sử dụng|biết|hát|đọc|viết|kể|mô tả|giải thích|phân tích|so sánh|xác định|tìm|vẽ|thể hiện|tham gia)\b',s):
      out[-1][1]=out[-1][1].rstrip()+' '+s; continue
    if out and not re.search(r'[.:;!?)”]$',out[-1][1]) and len(out[-1][1])<40 and first.isupper() is False:
      out[-1][1]+=' '+s; continue
    out.append([mach,s])
  # bỏ mẩu rác: quá ngắn / không có động từ, mở đầu bằng chữ thường
  res=[]
  for m,s in out:
    if len(s)<18 or s[0].islower(): continue
    res.append([m,re.sub(r'\s+',' ',s)])
  return res
C={}
for mon,v in D.items():
  if mon in ('Toán','Tiếng Anh'): continue
  C[mon]={l:clean(x) for l,x in v.items()}
json.dump(C,open('/tmp/claude-0/v8/yc_clean.json','w'),ensure_ascii=False)
print({m:{l:len(x) for l,x in v.items()} for m,v in C.items()})
for m,l in [('Khoa học','4'),('Lịch sử và Địa lí','8'),('Ngữ văn','6'),('Tự nhiên và Xã hội','1')]:
  print('==',m,l); [print('  ',a[:40],'|',x[:170]) for a,x in C[m][l][:10]]
# ---- cắt mẩu thừa sau dấu chấm cuối (chữ tràn từ cột Nội dung)
for mon in C:
  for l in C[mon]:
    for it in C[mon][l]:
      s=it[1]; m=re.match(r'^(.*[.;!?”)])\s+([^.;!?]{1,30})$',s)
      if m and not m.group(2)[0].isupper(): it[1]=m.group(1)
# ---- gán YCCĐ gợi ý cho từng bài theo trùng cụm 2 tiếng
A=json.load(open('/tmp/claude-0/v8/app_new.json'))
STOP=set('và của các một số trong với cho là được những về có không theo từ đến bài chủ đề chương phần em thực hành tiếp ôn tập luyện tập hoạt động nội dung bài học'.split())
def toks(s):
  s=unicodedata.normalize('NFC',s).lower(); s=re.sub(r'^(bài|chủ đề|chương|phần|tuần|nội dung)\s*[0-9ivxlc]*[ab]?\s*[:.\-–]?\s*','',s)
  w=[x for x in re.findall(r'[0-9a-zà-ỹđ]+',s)]
  bi={w[i]+' '+w[i+1] for i in range(len(w)-1) if not (w[i] in STOP and w[i+1] in STOP)}
  uni={x for x in w if x not in STOP and len(x)>2}
  bi={x for x in bi if not re.match(r'^(thế kỉ|nửa sau|nửa đầu|(đầu|cuối|giữa|sau|kỉ) (thế|[ivxlc]+)|kỉ [ivxlc]+|[ivxlc]+ (đến|giữa|đầu|cuối)|đến (đầu|giữa|cuối|thế|năm)|việt nam|đơn giản|thực tế|cuộc sống|hằng ngày)$',x)}
  return bi,uni
MAP={};SCO={}
laOn=re.compile(r'(?i)ôn tập|luyện tập chung|đánh giá|củng cố|bài tập cuối')
for key,B in A.items():
  mon,lop=key.split('|')
  if mon not in C or lop not in C[mon]: continue
  T=C[mon][lop]; TT=[toks(m+' '+s) if False else toks(s) for m,s in T]
  import math
  df={}
  for yb,yu in TT:
    for x in yb: df[x]=df.get(x,0)+1
  NT=len(TT)
  M={}
  for sec,items in B:
    sb,su=toks(sec)
    for t in items:
      if laOn.search(t): continue
      b,u=toks(re.sub(r'\s*\(sau văn bản.*$','',t))
      if re.match(r'(?i)thực hành tiếng việt',t): continue
      sc=[]
      for i,(yb,yu) in enumerate(TT):
        cm=b&yb; nb=len(cm); s=sum(math.log(1+NT/df[x]) for x in cm)+0.2*len(u&yu)+0.3*len(sb&yb)
        if (nb>=2 or (nb>=1 and len(b)<=2 and len(u&yu)>=2)) and min(df[x] for x in cm)<=3: sc.append((s,i))
      sc.sort(reverse=True)
      if sc: M[t]=[i for s,i in sc[:4] if s>=sc[0][0]*0.6]; SCO.setdefault(key,{})[t]=round(sc[0][0],2)
  MAP[key]=M
OUT={}
for mon in C:
  OUT[mon]={l:{'T':C[mon][l],'M':MAP.get(mon+'|'+l,{})} for l in C[mon]}
json.dump(SCO,open('/tmp/claude-0/v8/yc_scores.json','w'),ensure_ascii=False)
json.dump(OUT,open('/tmp/claude-0/v8/ct_yccd.json','w'),ensure_ascii=False,separators=(',',':'))
tot=sum(sum(len(x) for _,x in B) for k,B in A.items() if k.split('|')[0] in C); got=sum(len(m) for m in MAP.values())
print('bài có YCCĐ gợi ý:',got,'/',tot)
for k in ['Khoa học|4','Lịch sử và Địa lí|8','Tự nhiên và Xã hội|2','Khoa học tự nhiên|7','Ngữ văn|6','Âm nhạc|7']:
  M=MAP.get(k,{}); print('==',k,len(M))
  for t,ids in list(M.items())[:4]: print('  ',t[:60],'=>',[C[k.split('|')[0]][k.split('|')[1]][i][1][:70] for i in ids[:2]])
