import json,re,unicodedata
H=json.load(open('/tmp/claude-0/v8/hts_all.json'));A=json.load(open('/tmp/claude-0/v8/app_all.json'))
N=lambda s:unicodedata.normalize('NFC',s)
SK=re.compile(r'hướng dẫn sử dụng|lời nói đầu|thuật ngữ|phụ lục|bảng tra cứu|danh sách ảnh|bảng phiên âm|bảng giải thích|nguồn ảnh|mục lục',re.I)
TY=[('dầu tiên','đầu tiên'),('Nếu cậu có một người bạn...','Nếu cậu muốn có một người bạn'),('quê hương đát nước','quê hương, đất nước'),('Xem người lạ kìa!','Xem người ta kìa!'),
('mồng 9 tháng 4','mồng chín tháng tư'),('Thực hành Tiếng Việt','Thực hành tiếng Việt'),('Trái đất - ngôi nhà chung','Trái Đất – ngôi nhà chung'),('trên trái đất','trên Trái Đất'),
('NHẢU XA','NHẢY XA'),('Thường thức','Thường thức'),('Nhơ ơn','Nhớ ơn'),('Cây chuyện','Câu chuyện'),('Nhạc sĩ  ','Nhạc sĩ '),('chi tiêu các nhân','chi tiêu cá nhân'),('(ngọc Phú)',''),('Chùm chuyện cười dân gian','Chùm truyện cười dân gian'),('Nói với con (Y Phương)','Nói với con'),('Đồng chí, Chính Hữu','Đồng chí'),('Lá đỏ, Nguyễn Đình Thi','Lá đỏ'),('Bài thơ "Đường núi" của Nguyễn Đình Thi, Vũ Quần Phương','Bài thơ "Đường núi" của Nguyễn Đình Thi'),('(Được gợi ra','(được gợi ra'),('CHỦ ĐÈ','CHỦ ĐỀ'),('Lý thuyết âm nhạc','Lí thuyết âm nhạc'),('  ',' ')]
def fx(s):
  s=N(s).strip(); s=re.sub(r'(\d+)\.:',r'\1:',s)
  for a,b in TY: s=s.replace(a,b)
  return re.sub(r'\s+',' ',s)
def cap(s):  # UPPER -> Sentence case
  m0=re.match(r'^((?:PHẦN|CHỦ ĐỀ|CHỦ ĐÈ|CHƯƠNG|Chủ đề|Bài|Phần)[^:]*:\s*)?(.*)$',s)
  g2=re.sub(r'\(.*?\)','',m0.group(2))
  if g2.upper()!=g2 or not re.search('[A-ZĐÀ-Ỹ]',m0.group(2)): return s
  s=s.replace('CHỦ ĐÈ','CHỦ ĐỀ')
  m=re.match(r'^((?:PHẦN|CHỦ ĐỀ|CHƯƠNG|Chủ đề|Bài|Phần)[^:]*:\s*)?(.*)$',s); p,r=m.group(1) or '',m.group(2)
  p=p.capitalize() if p.isupper() else p
  r=r.lower(); r=r[:1].upper()+r[1:]; r=re.sub(r'^(i+|iv|v)( - )',lambda m:m.group(1).upper()+m.group(2),r,flags=re.I)
  for w in ['Việt Nam','Bác Hồ','Biển Đông','Sông Hồng','Cửu Long','Trái Đất']: r=re.sub(w,w,r,flags=re.I)
  return p+r
def books(lop,pat): return [b for b in H if b['lop']==lop and re.match(pat,N(b['ten']),re.I)]
def lines(lop,pat):
  out=[]
  for b in books(lop,pat):
    for l in b['lines']:
      d=(len(l)-len(l.lstrip(' ')))//2; t=fx(l)
      if SK.search(t): continue
      out.append((d,t))
  return out
R={}
# ---- Âm nhạc: chủ đề = section, hoạt động = mục
def amnhac(lop):
  S=[]
  for d,t in lines(lop,r'Âm nhạc'):
    if re.match(r'(?i)chủ đề',t): S.append([cap(t).replace('Chủ đề','Chủ đề'),[]])
    elif S: S[-1][1].append(t)
  return S
for l in [1,2,3,4,6,7,8]: R[f'{l}|Âm nhạc']=amnhac(l)
# ---- Mĩ thuật 6-8: chủ đề + bài
def mithuat(lop):
  S=[]
  for d,t in lines(lop,r'Mĩ thuật'):
    if re.match(r'(?i)chủ đề',t): S.append([cap(t),[]])
    elif S and re.match(r'Bài',t): S[-1][1].append(t)
  for s in S:
    if not s[1]: s[1].append(s[0])
  return S
for l in [6,7,8]: R[f'{l}|Mĩ thuật']=mithuat(l)
# ---- HĐTN 6-8
def hdtn(lop):
  S=[]
  for d,t in lines(lop,r'Hoạt động'):
    if re.match(r'(?i)chủ đề',t): S.append([cap(t),[]])
    elif S: S[-1][1].append(re.sub(r'^(\d+):\s*',r'Nội dung \1: ',t))
  return S
for l in [6,7,8]: R[f'{l}|Hoạt động trải nghiệm']=hdtn(l)
# ---- GDTC 1-4,6-8
def gdtc(lop):
  S=[];phan=''
  for d,t in lines(lop,r'(?i)Giáo dục thể'):
    if re.match(r'(?i)phần',t): phan=cap(t); S.append([phan,[]]); continue
    if re.match(r'(?i)chủ đề',t): S.append([('Tự chọn · ' if re.search(r'(?i)3|ba|tự chọn',phan) else '')+cap(t),[]]); continue
    if S: S[-1][1].append(cap(t))
  S=[s for s in S if s[1] or not re.match(r'(?i)phần',s[0]) or True]
  out=[]
  for s in S:
    if re.match(r'Phần',s[0]) and not s[1]: continue
    if not s[1]: s[1]=[s[0]]
    out.append(s)
  return out
for l in [1,2,3,4,6,7,8]: R[f'{l}|Giáo dục thể chất']=gdtc(l)
# ---- Ngữ văn 6-8
def nguvan(lop):
  app={re.match(r'Bài \d+',s).group(0):s for s,_ in A[f'Ngữ văn|{lop}'] if re.match(r'Bài \d+',s)}
  S=[];last='';grp=None
  for d,t in lines(lop,r'Ngữ văn'):
    if d==0:
      m=re.match(r'(?i)Bài (\d+)',t)
      if m: S.append([app.get('Bài '+m.group(1),cap(t)),[]]); last='';grp=None; continue
      if re.match(r'(?i)ôn tập',t): tt=cap(t).replace('Ôn tập học kì ii','Ôn tập học kì II').replace('Ôn tập học kì i','Ôn tập học kì I'); S.append([tt,[tt]]); continue
      continue
    if not S or t in ('Việt',): continue
    tl=t.lower()
    if d==1 and tl.startswith('ôn tập'):
      tt=cap(t).replace('Ôn tập học kì ii','Ôn tập học kì II').replace('Ôn tập học kì i','Ôn tập học kì I'); S.append([tt,[tt]]); grp=None; continue
    if d==1:
      if tl.startswith('củng cố'): S[-1][1].append('Củng cố, mở rộng'); grp=None; continue
      if tl.startswith('thực hành đọc'): grp='Thực hành đọc: '; continue
      grp=cap(t)+' – '; continue
    # d>=2
    x=t
    if not re.match(r'(?i)(viết|trình bày|kể|thảo luận|tóm tắt|nói|giới thiệu|tập làm|chia sẻ|thực hành|sáng tạo)',x):
      x=re.sub(r'\s*\((?:trích|[A-ZĐÀ-Ỹ])[^)]*\)','',x).strip()
    if x=='Thực hành tiếng Việt': x='Thực hành tiếng Việt (sau văn bản «'+last+'»)' if last else x
    else:
      if grp is None or grp=='Thực hành đọc: ': last=x
    S[-1][1].append((grp or '')+x)
  return S
for l in [6,7,8]: R[f'{l}|Ngữ văn']=nguvan(l)
json.dump(R,open('/tmp/claude-0/v8/rebuild.json','w'),ensure_ascii=False,indent=0)
import sys
for k in (sys.argv[1:] or R):
  print('##',k)
  for s,ts in R[k]: print(' ',s,'=>',' ¦ '.join(ts))
