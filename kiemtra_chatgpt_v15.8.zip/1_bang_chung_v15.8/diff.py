import json,re,unicodedata,sys
H=json.load(open('/tmp/claude-0/v8/hts_all.json'));A=json.load(open(sys.argv[1] if len(sys.argv)>1 else '/tmp/claude-0/v8/app_all.json'))
SK=re.compile(r'hướng dẫn sử dụng|lời nói đầu|thuật ngữ|phụ lục|bảng tra cứu|danh sách ảnh|bảng phiên âm|bảng giải thích|nguồn ảnh|mục lục|^việt$')
def nz(s):
  s=unicodedata.normalize('NFC',s).lower()
  for a,b in [('hoá','hóa'),('khoẻ','khỏe'),('hoà','hòa'),('thuỷ','thủy'),('lý','lí'),('kỳ','kì'),('oả','ỏa'),('uỷ','ủy')]: s=s.replace(a,b)
  s=re.sub(r'[ˋˊˀ~`]','',s); s=re.sub(r'^\s*(bài|chủ đề|tuần|chương|phần|tiết)\s*[0-9ivxlc]*[ab]?\s*[:.\-–]?\s*','',s)
  s=re.sub(r'\(.*?\)','',s); s=re.sub(r'[^0-9a-zà-ỹđ ]',' ',s); return re.sub(r'\s+',' ',s).strip()
def mk(t,l):
  t=unicodedata.normalize('NFC',t); t=re.sub(r' - Tập.*','',t); t=re.sub(r'\s*\d+$','',t).lower()
  t=re.sub(r'hoạt động (và )?trải nghiệm(, hướng nghiệp)?','hoạt động trải nghiệm',t); return t+'|'+str(l)
ak={k.split('|')[0].lower()+'|'+k.split('|')[1]:k for k in A}
HH={}
for b in H: HH.setdefault(mk(b['ten'],b['lop']),[]).extend(x.strip() for x in b['lines'])
out={}
for k,lines in HH.items():
  if k not in ak: continue
  a=[x for s,ts in A[ak[k]] for x in [s]+ts]; an=[nz(x) for x in a if len(nz(x))>1]
  hn=[(x,nz(x)) for x in lines if not SK.search(x.lower())]; hn=[x for x in hn if len(x[1])>1 and not re.match(r'^(ôn tập|luyện tập chung|thực hành tiếng việt|củng cố mở rộng|thực hành đọc|vận dụng sáng tạo)$',x[1])]
  has=lambda arr,v: any(y==v or (len(v)>6 and v in y) or (len(y)>6 and y in v) for y in arr)
  miss=[x for x,v in hn if not has(an,v)]; hs=[v for _,v in hn]; extra=[x for x in a if len(nz(x))>1 and not has(hs,nz(x))]
  out[ak[k]]=(miss,extra)
for k in (sys.argv[2:] or out):
  if k in out: m,e=out[k]; print('##',k,len(m),len(e)); print(' -',' ¦ '.join(m)); print(' +',' ¦ '.join(e))
