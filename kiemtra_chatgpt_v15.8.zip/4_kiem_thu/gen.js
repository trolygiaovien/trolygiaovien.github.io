const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const p=await b.newPage();p.on('pageerror',e=>console.log('PE',e.message));
await p.addInitScript(()=>{localStorage.setItem('tlgv_dongy','1.2');});
await p.goto('http://localhost:8765/index.html');await p.waitForTimeout(2000);
const R=await p.evaluate(()=>{const err={},cnt={n:0,mc:0,gens:0};const N={},G={};const add=(k,s,msg)=>{(G[k]=G[k]||{})[s.id]=(G[k][s.id]||0)+1;(err[k]=err[k]||[]);N[k]=(N[k]||0)+1;if(err[k].length<400&&!err[k].some(z=>z.startsWith(s.id+' ')))err[k].push(s.id+' «'+s.ten+'» lớp?'+' '+msg)};
 const MAXL={1:100,2:1000,3:100000};const num=t=>(String(t).replace(/(\d)[ .](?=\d{3}\b)/g,'$1').match(/\d+/g)||[]).map(Number);
 const nz=x=>String(x).replace(/\s+/g,' ').trim().toLowerCase();
 for(let lop=1;lop<=9;lop++)for(const s of (TOAN[lop]||[])){cnt.gens++;
  for(let i=0;i<150;i++){let it;try{it=s.gen()}catch(e){add('ngoai_le',s,e.message);break}
   cnt.n++;if(!it||!it.q||it.a==null||String(it.a).trim()===''){add('thieu_dap_an',s,JSON.stringify(it).slice(0,80));continue}
   const all=it.q+' '+it.a;if(/NaN|undefined|Infinity|null|\[object/.test(all))add('gia_tri_hong',s,all.slice(0,100));
   if(lop<=5&&/(^|[\s=(:])[-−]\d/.test(String(it.a))&&!/[-−]\s*\d+\s*°/.test(it.a))add('so_am_tieu_hoc',s,it.q.slice(0,60)+' → '+it.a);
   if(MAXL[lop]&&!/năm|20\d\d|19\d\d/.test(it.q)){const mx=Math.max(0,...num(it.q),...num(it.a));if(mx>MAXL[lop])add('vuot_pham_vi_lop',s,it.q.slice(0,70)+' → '+it.a)}
   if(lop<=2&&/Tìm x/.test(it.q))add('tim_x_lop12',s,it.q.slice(0,60));
   let m;const q=it.q.replace(/(\d) (?=\d{3}\b)/g,'$1'),A=String(it.a).replace(/(\d) (?=\d{3}\b)/g,'$1');
   if((m=q.match(/^(?:Đặt tính rồi tính: |Tính: |Tính nhẩm: )?(\d+) ([×x:+−-]) (\d+)(?: = \?)?$/))&&!/dư/.test(A)&&/^\d+$/.test(A.trim())){const a=+m[1],c=+m[3];const ex={'×':a*c,'x':a*c,':':a/c,'+':a+c,'−':a-c,'-':a-c}[m[2]];if(+A!==ex)add('sai_phep_tinh',s,q+' → '+A)}
  }
  for(let i=0;i<60;i++){let it;try{it=genItem(s,true)}catch(e){add('ngoai_le_mc',s,e.message);break}if(!it)break;cnt.mc++;
   const o=it.mc.map(nz);if(new Set(o).size!==o.length)add('pa_trung',s,it.q.slice(0,50)+' | '+it.mc.join(' / '));
   const ri=it.mc.findIndex(x=>nz(x)===nz(it.right));if(ri<0)add('mc_khong_co_dap_an_trong_pa',s,it.q.slice(0,50)+' | '+it.mc.join('/')+' đúng='+it.right);
   else{const nr=num(it.right),na=num(it.a);const ok=nz(it.right)===nz(it.a)||nz(it.a).startsWith(nz(it.right))||(typeof chuan==='function'&&chuan(it.right)===chuan(it.a))||(nr.length&&nr.every(x=>na.includes(x))&&nz(it.right).replace(/[\d\s.,]/g,'').split(' ').every(w=>!w||nz(it.a).includes(w)));
    if(!ok)add('mc_dap_an_lech',s,'Q: '+it.q.slice(0,80)+' | a='+it.a+' | đúng='+it.right+' | PA='+it.mc.join(' / '));
    if(nr.length&&na.length>nr.length+1&&/(mỗi|và|;)/.test(String(it.a))&&/(mỗi bạn|mỗi số|hai số|nhiều nhất|và .* bao nhiêu)/i.test(it.q))add('mc_chi_tra_loi_mot_phan',s,'Q: '+it.q.slice(0,90)+' | a='+it.a+' | đúng(MC)='+it.right)}
   const vs=it.mc.map(x=>typeof chuan==='function'?chuan(x):x);if(new Set(vs).size!==vs.length)add('pa_trung_gia_tri',s,it.mc.join(' / '));
  }}
 const ex={};for(const k in G){ex[k]=Object.keys(G[k]).map(id=>{let s0;for(let l=1;l<=9;l++){const f=(TOAN[l]||[]).find(x=>x.id===id);if(f){s0=f;s0._l=l;break}}let smp='';try{const it=genItem(s0,true);const r=s0.gen();smp=r.q.slice(0,90)+' ⇒ '+String(r.a).slice(0,70)+(it?' || PA: '+it.mc.join(' / '):'')}catch(e){}return id+'(L'+s0._l+') '+s0.ten+' — '+smp})}return {err,cnt,N,ex}});
fs.writeFileSync('/tmp/claude-0/v8/gen.json',JSON.stringify(R));console.log(JSON.stringify(R.cnt));for(const k in R.ex){console.log('##',k,R.ex[k].length);R.ex[k].forEach(x=>console.log('  ',x))};process.exit(0);for(const k in R.err)console.log(k,R.N[k],'\n   '+R.err[k].join('\n   '));await b.close()})();
