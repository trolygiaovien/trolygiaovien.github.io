const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage();p.on('pageerror',e=>console.log('PAGEERR',e.message));await p.goto('http://localhost:8765/index.html');await p.waitForTimeout(2500);
const r=await p.evaluate(()=>{const err=[],sample=[];const num=s=>+String(s).replace(/[^\d]/g,'');let n=0;
for(const lop of [1,2,3,4,5]){for(const s of (TOAN[lop]||[]).filter(s=>s._tb)){const ten=s.ten.toLowerCase();for(let i=0;i<400;i++){const it=s.gen();n++;if(!it||!it.q){err.push(s.id+' null');break}
 const q=it.q.replace(/(\d) (?=\d{3}\b)/g,'$1');const A=String(it.a).replace(/(\d) (?=\d{3}\b)/g,'$1');let m;
 const nums=(q.match(/\d+/g)||[]).map(Number);const ansN=(A.match(/\d+/g)||[]).map(Number);
 if(lop===1&&[...nums,...ansN].some(x=>x>100))err.push(s.id+' >100 '+q+' '+A);
 if(lop===2&&/phạm vi 100\b|số có hai chữ số/.test(ten)&&[...nums,...ansN].some(x=>x>100))err.push(s.id+' >100 '+q+' '+A);
 if(/không nhớ/.test(ten)||lop===1){}
 if((m=q.match(/^Đặt tính rồi tính: (\d+) ([×:+−]) (\d+)$/))){const a=+m[1],c=+m[3];let ex=m[2]==='×'?a*c:m[2]===':'?a/c:m[2]==='+'?a+c:a-c;if(/dư/.test(A)){const [qq,rr]=ansN;if(qq*c+rr!==a||rr>=c||rr<1)err.push(s.id+' '+q+' '+A)}else if(num(A)!==ex)err.push(s.id+' '+q+' '+A);
  const mk=ten.match(/(nhân|chia) số có (\S+) chữ số (?:với|cho) số có (\S+) chữ số/);if(mk){const W={'một':1,'hai':2,'ba':3,'bốn':4,'năm':5};if(String(a).length!==W[mk[2]]||String(c).length!==W[mk[3]])err.push(s.id+' sai số chữ số '+q)}
  const mk2=ten.match(/(?:cho|với) số có (\S+) chữ số/);if(mk2&&!mk){const W={'một':1,'hai':2};if(String(c).length!==W[mk2[1]])err.push(s.id+' sai số chữ số chia/nhân '+q)}
  if(/có nhớ/.test(ten)||/không nhớ/.test(ten)){const ds=x=>String(x).split('').reverse().map(Number);const X=ds(a),Y=ds(c);let carry=false;for(let k=0;k<X.length;k++){const d=m[2]==='+'?X[k]+(Y[k]||0):X[k]-(Y[k]||0);if(m[2]==='+'?d>=10:d<0)carry=true}if(/có nhớ/.test(ten)!==carry)err.push(s.id+' nhớ sai '+q)}}
 else if((m=q.match(/^Tìm x: x ([×:+−]) (\d+) = (\d+)$/))){const b2=+m[2],c=+m[3],x=num(A);const ok=m[1]==='×'?x*b2===c:m[1]===':'?x/b2===c:m[1]==='+'?x+b2===c:x-b2===c;if(!ok)err.push(s.id+' '+q+' '+A)}
 else if((m=q.match(/^Tìm x: (\d+) ([+−]) x = (\d+)$/))){const a=+m[1],c=+m[3],x=num(A);if(!(m[2]==='+'?a+x===c:a-x===c))err.push(s.id+' '+q+' '+A)}
 else if((m=q.match(/^Số\? (…|\d+) ([+−×:]) (…|\?|\d+) = (\d+)$/))){const L=m[1]==='…'?num(A):+m[1],Rr=(m[3]==='…'||m[3]==='?')?num(A):+m[3],c=+m[4];const v=m[2]==='+'?L+Rr:m[2]==='−'?L-Rr:m[2]==='×'?L*Rr:L/Rr;if(v!==c)err.push(s.id+' '+q+' '+A)}
 else if((m=q.match(/^Số\? \? : (\d+) = (\d+)$/))){if(num(A)/+m[1]!==+m[2])err.push(s.id+' '+q+' '+A)}
 else if((m=q.match(/^Số\? (\d+) : \? = (\d+)$/))){if(+m[1]/num(A)!==+m[2])err.push(s.id+' '+q+' '+A)}
 else if((m=q.match(/^Số\? (\d+) × \? = (\d+)$/))){if(+m[1]*num(A)!==+m[2])err.push(s.id+' '+q+' '+A)}
 else if((m=q.match(/^(\d+) ([×:]) (\d+) = \?$/))){if(num(A)!==(m[2]==='×'?+m[1]*+m[3]:+m[1]/+m[3]))err.push(s.id+' '+q+' '+A)}
 else if(/^(Mỗi|Có|Một|Thùng|Ngày|\S+ có)/.test(q)){if(ansN.length&&ansN[0]<=0)err.push(s.id+' âm/0 '+q+' '+A)}
 // vocab level: lớp 1-2 không 'Tìm x'
 if(lop<=2&&/Tìm x/.test(q))err.push(s.id+' tìm x ở lớp '+lop);
 if(i<1)sample.push(s.id+' | '+q+' → '+A)}}}return {n,err:err.slice(0,40),nErr:err.length,sample}});
console.log('mẫu kiểm',r.n,'lỗi',r.nErr);r.err.forEach(x=>console.log('  ',x));if(process.argv[2])console.log(r.sample.join('\n'));await b.close()})();
