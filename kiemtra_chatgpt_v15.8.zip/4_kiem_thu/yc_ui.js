const {chromium}=require('playwright');const fs=require('fs');
const KHO=JSON.parse(fs.readFileSync('/tmp/claude-0/v8/kho.json','utf8')).out;
(async()=>{const b=await chromium.launch();const p=await b.newPage();const pe=[];p.on('pageerror',e=>pe.push(e.message));
await p.addInitScript(()=>{localStorage.setItem('tlgv_dongy','1.2');});
await p.goto('http://localhost:8765/index.html');await p.waitForTimeout(4500);
await p.evaluate(K=>{for(const k in K){const [m,l]=k.split('|');NH[m]=NH[m]||{};const a=K[k];Object.defineProperty(a,'_full',{value:1});NH[m][l]=a}},KHO);
const r=await p.evaluate(()=>{const o={loaded:!!CT_YC,ver:document.body.innerHTML.match(/Phiên bản [\d.]+/)[0]};
 const c1=ctBai(7,'Khoa học tự nhiên',...(()=>{const B=baiCua(7,'Khoa học tự nhiên');for(let ci=0;ci<B.length;ci++)for(let bi=0;bi<B[ci][1].length;bi++)if(/^Bài 5:/.test(B[ci][1][bi][0]))return[ci,bi]})());
 o.khtn=[c1.ma,c1.trangThai,c1.nguon,c1.yccd,c1.yccdLop.length];
 const c2=ctBai(6,'Ngữ văn',0,0);o.nv=[c2.ten,c2.trangThai,c2.yccd.length,c2.yccdLop.length];
 const c3=ctBai(5,'Khoa học',0,0);o.kh5=[c3.trangThai,c3.yccd.length];
 const c4=ctBai(9,'Tiếng Anh',0,0);o.ta9=[c4.trangThai,c4.yccdLop.length];
 return o});
console.log(JSON.stringify(r,null,1));
// KHBD THCS
await p.evaluate(()=>{document.querySelector('[data-tab="ai"]')&&document.querySelector('[data-tab="ai"]').click()});
await p.evaluate(()=>{$('#k-lop').value='7';$('#k-lop').dispatchEvent(new Event('change'))});await p.waitForTimeout(200);await p.evaluate(()=>{$('#k-mon').value='Khoa học tự nhiên';$('#k-mon').dispatchEvent(new Event('change'))});await p.waitForTimeout(300);
const v=await p.evaluate(()=>{const s=$('#k-baisgk');const o=[...s.options].find(x=>/^Bài 5:/.test(x.text));return o&&o.value});
await p.evaluate(v=>{$('#k-baisgk').value=v;$('#k-baisgk').onchange()},v);await p.waitForTimeout(300);
await p.evaluate(()=>taoKHBD());await p.waitForTimeout(1500);
const k=await p.evaluate(()=>{const t=$('#k-out').innerText;const i=t.indexOf('MỤC TIÊU');return t.slice(i,i+500)});
console.log(k);
// bài chọn ở phiếu
await p.evaluate(()=>{$('#p-lop').value='4';$('#p-lop').dispatchEvent(new Event('change'));});await p.waitForTimeout(200);
await p.evaluate(()=>{$('#p-mon').value='Khoa học';$('#p-mon').dispatchEvent(new Event('change'));});await p.waitForTimeout(300);
await p.evaluate(()=>{const s=$('#p-bai');s.value=[...s.options].find(x=>/^Bài 1:/.test(x.text)).value;s.dispatchEvent(new Event('change'))});await p.waitForTimeout(400);
console.log((await p.evaluate(()=>$('#p-bainote').innerText)).slice(0,700));
console.log('PE',pe);await b.close()})();
