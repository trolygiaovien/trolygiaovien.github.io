const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage();const pe=[];p.on('pageerror',e=>pe.push(e.message));p.on('dialog',d=>d.accept());
await p.addInitScript(()=>{localStorage.setItem('tlgv_dongy','1.2');localStorage.setItem('tlgv_cap','th');});
await p.goto('http://localhost:8765/index.html');await p.waitForTimeout(2000);
for(const k of [0,3,'__all']){await p.evaluate(k=>{const L=$('#lt-lop');L.value='3';L.dispatchEvent(new Event('change'));$('#lt-mon').value='Toán';$('#lt-mon').dispatchEvent(new Event('change'));$('#lt-loai').value=k==='__all'?'th':'cd';$('#lt-loai').dispatchEvent(new Event('change'));const cd=$('#lt-cd');if(k!=='__all')cd.selectedIndex=k;$('#lt-go').click()},k);
await p.waitForTimeout(1500);console.log(k,await p.evaluate(()=>[$('#lt-cd').value,$('#lt-quiz').children.length,$('#lt-wrap').className,$('#lt-st').textContent].join(' | ')));
await p.evaluate(()=>{$('#lt-lai')&&$('#lt-lai').click()});}
console.log(pe);await b.close()})();
