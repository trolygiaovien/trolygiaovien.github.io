const {chromium}=require('playwright');const fs=require('fs');
const KHO=JSON.parse(fs.readFileSync('/tmp/claude-0/v8/kho.json','utf8')).out;
(async()=>{const b=await chromium.launch();const p=await b.newPage();const pe=[];p.on('pageerror',e=>pe.push(e.message));
const CAP=process.argv[2]||'th';await p.addInitScript(c=>{localStorage.setItem('tlgv_dongy','1.2');localStorage.setItem('tlgv_cap',c);},CAP);
await p.goto('http://localhost:8765/index.html');await p.waitForTimeout(2000);
await p.evaluate(K=>{for(const k in K){const [m,l]=k.split('|');NH[m]=NH[m]||{};const a=K[k];Object.defineProperty(a,'_full',{value:1});NH[m][l]=a}},KHO);
const run=(px,lop,mon,src,opt)=>p.evaluate(([px,lop,mon,src,opt])=>{opt=opt||{};const re=new RegExp(src);try{localStorage.removeItem('tlgv_qdlim')}catch(e){};store.set('qdlim',{});
 const L=$('#'+px+'-lop');L.value=String(lop);L.dispatchEvent(new Event('change'));$('#'+px+'-mon').value=mon;$('#'+px+'-mon').dispatchEvent(new Event('change'));
 const o=[...$('#'+px+'-bai').options].find(o=>re.test(o.text));if(!o)return 'NO OPT';$('#'+px+'-bai').value=o.value;applyBai(px);
 if(opt.onb){const cs=[...document.querySelectorAll('#'+px+'-bainote [data-onb]')];opt.onb.forEach(k=>{if(cs[k]){cs[k].checked=true;cs[k].onchange()}})}
 if(opt.n&&px==='p'){$('#p-n').value=opt.n;document.querySelectorAll('#p-skills .ndn').forEach(e=>e.value=opt.n)}
 if(opt.loc)$('#'+px+'-locbai').checked=true;
 const checked=[...$('#'+px+'-skills').querySelectorAll('input:checked')].map(i=>i.parentElement.innerText.split('\n')[0].slice(0,50));
 const note=$('#'+px+'-bainote').innerText.slice(0,300);
 const go=$('#'+px+'-go');go._khoOK=true;try{go.click()}finally{go._khoOK=false}
 return {bai:o.text.slice(0,60),checked,note,title:px==='p'?$('#p-title').value:''}},[px,lop,mon,src,opt]).then(async r=>{await p.waitForTimeout(600);const out=await p.evaluate(px=>$('#'+px+'-out').innerText,px);r.out=out.slice(0,600);r.thang=(out.match(/hình thang/gi)||[]).length;return r});
const T0=[['p',5,'Toán','^Bài 25\\.'],['d',5,'Toán','^Bài 25\\.'],['p',4,'Khoa học','Bài 25'],['p',5,'Toán','^Bài 71\\. Ôn tập hình học',{onb:[0,1]}],['p',7,'Khoa học tự nhiên','Bài 12',{n:20}],['p',3,'Toán','^Bài 71\\.'],['d',9,'Giáo dục thể chất','Đá cầu'],['d',7,'Khoa học tự nhiên','Bài 12',{loc:1}]];
const T=T0.filter(t=>CAP==='thcs'?t[1]>=6:t[1]<=5);for(const t of T){const r=await run(...t);console.log('=====',t.slice(0,4).join(' | '));console.log(JSON.stringify(r,null,1))}
// cổng chặn câu ngoài phạm vi
console.log('GATE',await p.evaluate(()=>{const nd=noiDung(5,'Toán').filter(n=>n.s&&n.s.id==='dttg5');const it=genItem(TOAN[5].find(s=>s.id==='dtht5'),false);return kiemDinhDe([it],nd,5).slice(0,160)}));
console.log('GATE2',await p.evaluate(()=>kiemDinhDe([{q:'1+1=?',a:'NaN',cd:'X',gen:1}],[{ten:'X'}],1).slice(0,200)));
console.log('PE',pe);await b.close()})();
