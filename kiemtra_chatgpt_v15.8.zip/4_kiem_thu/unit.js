const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage();await p.addInitScript(()=>{localStorage.setItem('tlgv_dongy','1.2');});
await p.goto('http://localhost:8765/index.html');await p.waitForTimeout(2000);
const r=await p.evaluate(()=>{const T=[
 ['L-kg2 đáp án bớt sai',kiemDinhCau({q:'Mẹ mua 5 kg gạo, đã nấu hết 14 kg. Hỏi còn lại bao nhiêu ki-lô-gam gạo?',a:'1 kg'},2)!==''],
 ['L-kg2 đúng thì qua',kiemDinhCau({q:'Mẹ mua 25 kg gạo, đã nấu hết 14 kg. Hỏi còn lại bao nhiêu ki-lô-gam gạo?',a:'11 kg'},2)===''],
 ['NaN bị chặn',kiemDinhCau({q:'1 + 1 = ?',a:'NaN'},1)!==''],
 ['PA trùng bị chặn',kiemDinhCau({q:'x',a:'2',mc:['2','2','3','4'],right:'2'},1)!==''],
 ['Đáp án ngoài PA bị chặn',kiemDinhCau({q:'x',a:'5',mc:['2','3','4','6'],right:'5'},1)!==''],
 ['Số âm tiểu học bị chặn',kiemDinhCau({q:'3 − 5 = ?',a:'-2'},3)!==''],
 ['Vượt phạm vi lớp 1 bị chặn',kiemDinhCau({q:'60 + 70 = ?',a:'130'},1)!==''],
 ['Tìm x lớp 2 bị chặn',kiemDinhCau({q:'Tìm x: x + 3 = 9',a:'6'},2)!==''],
 ['Câu ngoài phạm vi bị chặn',kiemDinhDe([{q:'a',a:'b',cd:'Chủ đề khác'}],[{ten:'Chủ đề A'}],5)!==''],
 ['Câu đúng phạm vi qua',kiemDinhDe([{q:'a',a:'b',cd:'Chủ đề A'}],[{ten:'Chủ đề A'}],5)===''],
 ['Bộ sinh 2 đại lượng không ra TN',genItem(TOAN[4].find(s=>s.id==='th'),true)===null],
 ['Toán 5 Bài 25 chỉ tam giác',(()=>{const B=baiCua(5,'Toán');let ci,bi;B.forEach((c,i)=>c[1].forEach((x,j)=>{if(/^Bài 25\./.test(x[0])){ci=i;bi=j}}));const r=ndIdsTheoBai(5,'Toán',B,ci,bi,noiDung(5,'Toán'));return r.kind==='bai'&&r.ids.join()==='g_dttg5'})()],
 ['Khoa học 4 Bài 25 không tự tích',(()=>{const B=baiCua(4,'Khoa học');let ci,bi;B.forEach((c,i)=>c[1].forEach((x,j)=>{if(/^Bài 25/.test(x[0])){ci=i;bi=j}}));const r=ndIdsTheoBai(4,'Khoa học',B,ci,bi,noiDung(4,'Khoa học'));return r.kind==='thieu'&&!r.ids.length})()],
 ['Bài ôn tập không tự lấy',(()=>{const B=baiCua(5,'Toán');let ci,bi;B.forEach((c,i)=>c[1].forEach((x,j)=>{if(/^Bài 71\./.test(x[0])){ci=i;bi=j}}));const r=ndIdsTheoBai(5,'Toán',B,ci,bi,noiDung(5,'Toán'));return r.kind==='on'&&!r.ids.length&&r.dsBai.length>0})()],
 ['Tên bài KHTN sạch',!JSON.stringify(baiCua(7,'Khoa học tự nhiên')).includes('Xem lời giải')],
];return T.map(t=>(t[1]?'ĐẠT ':'HỎNG ')+t[0]).join('\n')});console.log(r);await b.close()})();
