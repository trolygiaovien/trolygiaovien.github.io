const {chromium}=require('playwright');const fs=require('fs');
const KHO=JSON.parse(fs.readFileSync('/tmp/claude-0/v8/kho.json','utf8')).out;
(async()=>{const b=await chromium.launch();for(const f of ['_old.html','index.html']){const p=await b.newPage();
await p.addInitScript(()=>{localStorage.setItem('tlgv_dongy','1.2');});
await p.goto('http://localhost:8765/'+f);await p.waitForTimeout(1500);
await p.evaluate(K=>{for(const k in K){const [m,l]=k.split('|');NH[m]=NH[m]||{};const a=K[k];Object.defineProperty(a,'_full',{value:1});NH[m][l]=a}},KHO);
const r=await p.evaluate(()=>{const o={};for(const [lop,mon] of [[7,'Ngữ văn'],[8,'Ngữ văn'],[8,'Lịch sử và Địa lí']]){const B=baiCua(lop,mon),nd=noiDung(lop,mon);o[lop+mon]=[];B.forEach((c,ci)=>c[1].forEach((x,bi)=>{const r=ndIdsTheoBai(lop,mon,B,ci,bi,nd);if(r.kind==='bai')o[lop+mon].push(x[0]+' => '+r.ids.map(i=>(nd.find(n=>n.id===i)||{}).ten).join(','))}))}return o});
console.log(f,JSON.stringify(r,null,1));await p.close()}await b.close()})();
