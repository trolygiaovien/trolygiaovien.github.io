const {chromium}=require('playwright');const fs=require('fs');
const KHO=JSON.parse(fs.readFileSync('/tmp/claude-0/v8/kho.json','utf8')).out;
(async()=>{const b=await chromium.launch();const p=await b.newPage();const pe=[];p.on('pageerror',e=>pe.push(e.message));
await p.addInitScript(()=>{localStorage.setItem('tlgv_dongy','1.2');});
await p.goto('http://localhost:8765/index.html');await p.waitForTimeout(2000);
await p.evaluate(K=>{for(const k in K){const [m,l]=k.split('|');NH[m]=NH[m]||{};const a=K[k];Object.defineProperty(a,'_full',{value:1});NH[m][l]=a}},KHO);
const R=await p.evaluate(()=>{const out={kind:{},bymon:{},tatca:0,toanbo:0,gateFail:0,gateRun:0,ngoai:0,exFuzzy:[],onKhong:0,longT:[]};
 for(let lop=1;lop<=9;lop++)for(const mon of monTheoLop(lop)){const B=baiCua(lop,mon),nd=noiDung(lop,mon);const nb=nd.filter(n=>n.kind==='bank').length;
  B.forEach((c,ci)=>c[1].forEach((x,bi)=>{const r=ndIdsTheoBai(lop,mon,B,ci,bi,nd);out.kind[r.kind]=(out.kind[r.kind]||0)+1;const bm=out.bymon[lop+"|"+mon]=out.bymon[lop+"|"+mon]||{};bm[r.kind]=(bm[r.kind]||0)+1;
   if(x[0].length>110)out.longT.push(mon+' '+lop+': '+x[0].slice(0,90));
   if(r.kind==='bai'&&nb>=3&&r.ids.filter(i=>/^b_/.test(i)).length>=Math.max(2,nb*0.8))out.tatca++;
   if(r.ids.length===nd.length&&nd.length>5)out.toanbo++;
   if(r.kind==='on'&&!(r.dsBai||[]).length)out.onKhong++;
   if(r.kind==='bai'&&r.ids.length===1&&/^b_/.test(r.ids[0])){const n=nd.find(z=>z.id===r.ids[0]);if(n&&!/^Bài\s*\d+/.test(n.ten)&&n.ten!==x[0])out.exFuzzy.push(mon+' '+lop+' | '+x[0].slice(0,50)+' ⇒ '+n.ten)}
   if(r.kind==='bai'){const sel=nd.filter(n=>r.ids.includes(n.id));for(let k=0;k<3;k++){const qs=cauTu(sel,10,'all');out.gateRun+=qs.length;const ok=new Set(sel.map(z=>z.ten));qs.forEach(q=>{if(!ok.has(q.cd))out.ngoai++});if(kiemDinhDe(qs,sel,lop))out.gateFail++}}
  }))}
 out.kd=KDINH;return out});
console.log(JSON.stringify({kind:R.kind,tatca:R.tatca,toanbo:R.toanbo,gateRun:R.gateRun,ngoai:R.ngoai,gateFail:R.gateFail,onKhong:R.onKhong,kdDem:R.kd.dem,kdLoi:R.kd.loi},null,0));
console.log(JSON.stringify(R.bymon));console.log('exFuzzy',R.exFuzzy.length);R.exFuzzy.forEach(x=>console.log('  ',x));console.log('longT',R.longT);console.log('PE',pe);
fs.writeFileSync('/tmp/claude-0/v8/audit3.json',JSON.stringify(R));await b.close()})();
